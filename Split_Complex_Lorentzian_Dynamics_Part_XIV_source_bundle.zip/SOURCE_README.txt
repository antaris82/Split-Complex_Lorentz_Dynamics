Split Complex Lorentzian Dynamics - Part XIV
Generated 3 September 2026.

Contents:
- Split_Complex_Lorentzian_Dynamics_Part_XIV.tex
- references.bib

The paper is based on the audited Aristotle Task-14 artifact. The PDF was compiled with latexmk/pdflatex and visually checked after rendering all 21 A4 pages.
