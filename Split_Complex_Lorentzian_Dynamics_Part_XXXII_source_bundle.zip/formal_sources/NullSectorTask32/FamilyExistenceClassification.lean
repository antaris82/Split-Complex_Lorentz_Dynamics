import RequestProject.NullSectorTask32.FamilyDefectNeutrality

/-!
# Task 32, Packages M, N, O, P: the family-level existence verdict

**HARD TARGET C (items 90–101), Package O (the outcome trichotomy) and Package P (the
conditional global object).**

* `UniversalFamilyLiftability` (item 90) is *stated* for the full inherited class of bare
  metric-oriented rank-three families.  It is **neither proved nor refuted** here.  Item 91 is
  respected: the Task-XXXI bad presentation says nothing about it, and indeed
  `GoodBad.badFamilyBase_familyLiftable` shows that the Task-XXXI family is *positive* evidence
  rather than a counterexample.
* Item 99/101: no genuine family-level negative example is produced.  Constructing one would
  require an invariant surviving *all* admissible ordinary presentations and refinements, which
  within the reconstructed layer is exactly the point at which standard obstruction theory
  would have to be imported — forbidden by the firewall.  The stop-on-hard-frontier rule is
  therefore applied and the outcome is **Verdict C**.
* Package P (items 102–105): family-level neutrality does produce, for a suitable presentation,
  the complete Task-XXX global glued internal object with surjective equivariant map and exact
  two-point kernel fibres.  Item 106 is applied to the *uniqueness* question across different
  liftable presentations: it is explicitly deferred, not claimed.
-/

set_option synthInstance.maxHeartbeats 400000
set_option maxHeartbeats 1000000

namespace NullSectorTask32

open NullSectorTask26 NullSectorTask27 NullSectorTask28 NullSectorTask29 NullSectorTask30
open NullSectorTask31

universe u v t y z

/-! ## Package P — the conditional global object at family level -/

section GlobalObject

variable {B : Type u} [TopologicalSpace B] {E : B → Type v} [∀ b, NormedAddCommGroup (E b)]
  [∀ b, InnerProductSpace ℝ (E b)] {F : BareMetricOrientedFamily B E}

/-- **PACKAGE P (items 102–103), REQUIRED ENDPOINT.**  If the bare family is family-level
liftable then *some* ordinary atlas presentation of it carries the complete Task-XXX global
glued internal object: a locally trivial internal total space with a continuous free fibrewise
transitive right internal action, a continuous surjective equivariant map onto the ordinary
frame total space of that presentation, exact kernel fibres and — for the certified
two-element kernel — exactly two points per fibre. -/
theorem familyLiftable_constructs_globalTwofoldInternalFrameLift
    {Fm : Type z} [TopologicalSpace Fm] [MulAction GvisModel Fm]
    (M : OrdinaryFrameModel GvisModel Fm) {Tot : Type y} [TopologicalSpace Tot]
    (h : FamilyLiftable.{u, v, t} F) :
    ∃ (ι₀ : Type t) (A : OrdinaryAtlasPresentation F ι₀),
      DirectAtlasLiftable A ∧
      ∀ FS : OrdinaryFrameSide (ofOrdinary (ordinarySystem A)) M Tot,
        ∃ (Etot : Type (max u t)) (_ : TopologicalSpace Etot)
          (Q : GluedInternalFrameSystem ModelBridge.modelInternalProjection
            (ofOrdinary (ordinarySystem A)) M FS Etot),
          Function.Surjective Q.toFrame ∧
          (∀ y : Tot, (∃ x : Etot, Q.toFrame x = y) ∧
            ∀ x x' : Etot, Q.toFrame x = y → Q.toFrame x' = y →
              ∃! z : ModelBridge.modelInternalProjection.Ker, Q.act x ↑z = x') ∧
          (Nat.card ModelBridge.modelInternalProjection.Ker = 2 →
            ∀ y : Tot, Nat.card {x : Etot // Q.toFrame x = y} = 2) := by
  obtain ⟨ι₀, A, hA⟩ := h
  refine ⟨ι₀, A, hA, fun FS => ?_⟩
  obtain ⟨Etot, inst, Q, hsurj, _heq, _htors, hfib, hcard⟩ :=
    neutralDefect_constructs_globalTwofoldInternalFrameLift FS
      (internalLiftable_iff_globalKernelDefect_neutral.1 hA)
  exact ⟨Etot, inst, Q, hsurj, hfib, hcard⟩

end GlobalObject

/-! ## Packages M, N, O — the family-level existence verdict -/

section Verdict

/-- **PACKAGE M (item 90), the universal question, stated for the full inherited class.**
This proposition is deliberately left undecided by Task XXXII: it is neither proved nor
refuted below. -/
def UniversalFamilyLiftability : Prop :=
  ∀ (B : Type) [TopologicalSpace B] (E : B → Type) [∀ b, NormedAddCommGroup (E b)]
    [∀ b, InnerProductSpace ℝ (E b)] (F : BareMetricOrientedFamily B E),
    FamilyLiftable.{0, 0, 0} F

/-- **PACKAGE M (item 91).**  The Task-XXXI bad presentation gives *no* evidence against
universal family liftability: the underlying bare family is family-level liftable. -/
theorem task31_family_is_positive_evidence :
    FamilyLiftable.{0, 0, 0} Examples.badFamilyBase :=
  GoodBad.badFamilyBase_familyLiftable

/-- **PACKAGE O.**  The three admissible Task-XXXII outcomes. -/
inductive Task32Verdict
  /-- Verdict A: every inherited underlying family is family-level liftable. -/
  | presentationObstructionDisappears
  /-- Verdict B: a genuine atlas-independent non-liftable family exists. -/
  | genuineGeometricObstruction
  /-- Verdict C: the exact family-level classification is proved, examples unresolved. -/
  | classificationOnly
  deriving DecidableEq, Repr

/-- **PACKAGE O, the frozen Task-XXXII verdict.**  Verdict **C**: the exact family-level
classification is proved; neither universal family liftability nor a genuine
atlas-independent non-neutral family is established. -/
def task32_verdict : Task32Verdict := Task32Verdict.classificationOnly

/-- **PACKAGE O (item 101), the content of Verdict C, as a formal statement.**

1. the exact family-level classification holds for every bare family of the inherited class;
2. the Task-XXXI constant family is correctly repaired at family level: one non-liftable fixed
   presentation, one liftable fixed presentation, and a family-level liftable bare family. -/
theorem task32_verdictC_content :
    (∀ {B : Type u} [TopologicalSpace B] {E : B → Type v} [∀ b, NormedAddCommGroup (E b)]
      [∀ b, InnerProductSpace ℝ (E b)] (F : BareMetricOrientedFamily B E),
        FamilyLiftable.{u, v, t} F ↔ FamilyKernelDefectNeutral.{u, v, t} F) ∧
    (¬ DirectAtlasLiftable GoodBad.badAtlas) ∧
    DirectAtlasLiftable GoodBad.trivialAtlas ∧
    FamilyLiftable.{0, 0, 0} Examples.badFamilyBase ∧
    FamilyKernelDefectNeutral.{0, 0, 0} Examples.badFamilyBase :=
  ⟨fun _ => familyLiftable_iff_familyKernelDefectNeutral,
    GoodBad.badAtlas_not_directAtlasLiftable, GoodBad.trivialAtlas_directAtlasLiftable,
    GoodBad.badFamilyBase_familyLiftable, badFamilyBase_familyKernelDefectNeutral⟩

end Verdict

end NullSectorTask32
