# TASK XXXII AUDIT

## Ordinary atlas change, cover refinement, and atlas-independent internal liftability

**Verdict: C — exact family-level classification proved; examples unresolved.**

---

## 0. Build environment

| Item | Value |
| --- | --- |
| Lean toolchain | `leanprover/lean4:v4.28.0` |
| Mathlib requirement | `git … mathlib4.git`, `rev = v4.28.0` |
| Mathlib revision (lake manifest) | `8f9d9cff6bd728b17a24e163c9402775d9e6a365` |
| New layer | `RequestProject/NullSectorTask32/` (9 modules) |
| Focused build | `lake build RequestProject.NullSectorTask32.Task32` — green |
| Whole-project build | `lake build` — green, **8360 jobs**, 0 errors |
| Warnings | 114, **all inherited**; **0** in any Task-XXXII module |
| Axioms | every Task-XXXII endpoint: `propext`, `Classical.choice`, `Quot.sound` only |
| Prohibited constructs | none (`sorry`, `admit`, custom `axiom`, `implemented_by`, `native_decide`, `bv_decide`, `unsafe`, `partial` all absent) |
| Prior sources | Tasks I–XXXI **unchanged**; `git diff` against the Task-XXXI endpoint shows only new files |

---

## 1. Module chain

```
UnderlyingFrameGeometry      (Package A)
  → OrdinaryAtlasChange      (Package B)
  → OrdinaryCoverRefinement  (Package D)
  → OrdinaryAtlasEquivalence (Package E)
  → FamilyLiftability        (Packages F, H)
  → AtlasChangeLiftability   (Packages G, J)
  → GoodBadAtlasComparison   (Packages C, H-negative, Q)
  → FamilyDefectNeutrality   (Packages I, K, L)
  → FamilyExistenceClassification (Packages M, N, O, P)
  → Task32                   (endpoints + axiom report)
```

Strictly linear; each module imports only its predecessor.

---

## 2. Exact definitions

| Name | Meaning |
| --- | --- |
| `BareMetricOrientedFamily B E` / `UnderlyingFrameGeometry B E` | neutral alias for the inherited `MetricOrientedRankThreeFamily B E` — the geometry with **no** atlas |
| `OrdinaryAtlasPresentation F ι` | neutral alias for the inherited `MetricOrientedFibreAtlas F ι` |
| `bareOf T`, `presentationOf T` | the two projections of an inherited `TopologicalFrameFamily` |
| `presentedFamily F A` | reassembly; `bareOf (presentedFamily F A) = F` by `rfl` |
| `ordinarySystem A` | the ordinary transition system of a presentation; equals the inherited `T.toOrdinaryTransitionSystem` by `rfl` |
| `chartGauge A A' i i' b` | ordinary chart-comparison map `Φ'_{i'}(b) ∘ Φ_i(b)⁻¹ ∈ GvisModel`, on `A.U i ∩ A'.U i'` |
| `JointOrdinaryAtlas F σ ι` | a σ-indexed family of presentations of one bare family on **one** cover, with continuous overlap maps *across* presentations |
| `J.gauge s t i` | the chart-comparison map of two labels of a joint atlas |
| `OrdinaryChartGaugeEquivalent A A'` | every chart comparison between `A` and `A'` is continuous |
| `restrictTriv Φ h` | restriction of a local trivialization to a smaller set |
| `OrdinaryCoverRefinement A κ` | ordinary refinement of the frame atlas: `r : κ → ι`, `V : κ → Set B`, open, covering, `V a ⊆ A.U (r a)` |
| `R.atlas` | the refined presentation (charts restricted) |
| `commonRefinementLeft/Right A A'` | the intersection construction `U i ∩ U' i'` as a refinement of `A` resp. `A'` |
| `Presentation F` | `Σ ι, OrdinaryAtlasPresentation F ι` |
| `OrdinaryAtlasEquivalent` | generated (finite zig-zag) relation: chart gauge, cover refinement, symmetry, transitivity |
| `refinedSystem S r V …` | restriction of an abstract transition system to a refined cover |
| `gaugedSystem S h hcont` | `g'_ij = h_j · g_ij · h_i⁻¹`, with the three transition laws proved |
| `DirectAtlasLiftable A` | the Task-XXXI `InternalLiftable` of `ordinarySystem A` (interface, definition unchanged) |
| `FamilyLiftable F` | `∃ ι A, DirectAtlasLiftable A` |
| `RefinementLiftable A` | `∃ κ R, DirectAtlasLiftable R.atlas` |
| `InternallyLiftableOrdinaryGauge P S h` | the chart gauge has continuous internal representatives compatible with `proj` |
| `FamilyKernelDefectNeutral F` | `∃ ι A`, the Task-XXXI fixed-system defect of `ordinarySystem A` is neutral |
| `UniversalFamilyLiftability` | `∀ F, FamilyLiftable F` — **stated, undecided** |
| `Task32Verdict`, `task32_verdict` | the outcome trichotomy and the frozen value `classificationOnly` |

---

## 3. Theorem inventory (principal endpoints)

### Package A — bare family exposed
1. `bareOf`, `presentationOf`, `presentedFamily` — the separation.
2. `bareOf_presentedFamily`, `presentationOf_presentedFamily`,
   `presentedFamily_bareOf_presentationOf`.
3. `ordinarySystem_eq`, `toOrdinaryTransitionSystem_eq` — the frozen Task-XXVII output is
   literally recovered.

### Package B — ordinary chart change
4. `chartGauge`, `chartGauge_apply`.
5. `chartGauge_self` (identity), `chartGauge_symm` (inverse), `chartGauge_comp` (composition).
6. **`chartChange_transition_law`** — `g'_{i'j'} = h_{jj'} · g_{ij} · h_{ii'}⁻¹`, derived.
7. `chartChange_tripleOverlap_compatible` — the gauge law is consistent with `g_ik = g_jk·g_ij`.
8. **`JointOrdinaryAtlas.continuous_gauge`** — continuity of every comparison map, *proved*.
9. `JointOrdinaryAtlas.gauge_self / gauge_symm / gauge_comp`.
10. `JointOrdinaryAtlas.transition_gauge_law` — item-24 endpoint.
11. `ordinaryChartGaugeEquivalent_refl / _symm / _trans`;
    `JointOrdinaryAtlas.ordinaryChartGaugeEquivalent`.

### Package D — ordinary cover refinement
12. `restrictTriv`, `transitionOn_restrictTriv`, `restrictTriv_self`, `restrictTriv_comp`.
13. `OrdinaryCoverRefinement`, `OrdinaryCoverRefinement.atlas`.
14. **`OrdinaryCoverRefinement.transitionFun_eq`** — exact restriction formula.
15. `atlas_idRefinement`, `comp`, `atlas_comp`, `transitionFun_comp`.
16. `commonRefinementLeft`, `commonRefinementRight`, **`commonRefinement_domains`**.

### Package E — ordinary atlas equivalence
17. `OrdinaryAtlasEquivalent` (generated relation), `OrdinaryAtlasEquivalent.refl`.
18. **`ordinaryAtlasEquivalent_equivalence`**.
19. `ordinaryAtlasEquivalent_refine`, `ordinaryAtlasEquivalent_commonRefinement`.

### Package C — the mandatory good/bad control
20. `GoodBad.trivialAtlas`, `GoodBad.badAtlas`, **`GoodBad.same_underlying_bare_family`**.
21. `GoodBad.goodBadJoint`, `goodBadJoint_atlas_false/​true` (both by `rfl`).
22. **`GoodBad.gauge_zero`** `h₀(b) = 1`, **`GoodBad.gauge_one`** `h₁(b) = b`.
23. `GoodBad.ordinaryChartGaugeEquivalent_trivial_bad`,
    `GoodBad.ordinaryAtlasEquivalent_trivial_bad`,
    `GoodBad.transition_gauge_law_trivial_bad`.
24. **`GoodBad.trivialAtlas_directAtlasLiftable`**, **`GoodBad.badAtlas_not_directAtlasLiftable`**,
    `GoodBad.trivialAtlas_neutral`, `GoodBad.badAtlas_not_neutral`.
25. **`GoodBad.fixedPresentation_neutrality_not_familyInvariant`**.

### Packages F, H — family liftability, refinement behaviour
26. `DirectAtlasLiftable`, `directAtlasLiftable_iff`, `directAtlasLiftable_presentationOf`.
27. **`FamilyLiftable`**, `familyLiftable_of_directAtlasLiftable`,
    `familyLiftable_depends_only_on_bare`.
28. `refinedSystem`, `internalLiftable_refinedSystem`,
    **`directAtlasLiftable_refine`**.
29. `RefinementLiftable`, `refinementLiftable_of_directAtlasLiftable`,
    `familyLiftable_of_refinementLiftable`, `refinementLiftable_of_refine`.
30. **`GoodBad.directLiftability_refinement_converse_refuted`**,
    `GoodBad.badAtlas_refinementLiftable`.

### Packages G, J — chart-gauge behaviour and defect transformation
31. `transitionSystem_ext`, `gaugedSystem` (+ its three transition laws).
32. `InternallyLiftableOrdinaryGauge`.
33. **`internalLiftable_gaugedSystem`** — the strongest correct transfer theorem.
34. `ofOrdinary_atlas_eq_gaugedSystem`, **`directAtlasLiftable_gauge_transfer`**.
35. **`GoodBad.goodBadGauge_not_internallyLiftable`** — the good/bad gauge fails the condition.
36. **`tripleDefect_conjugation`** — the triple defect is *unchanged* by an internally lifted
    ordinary chart change (centrality of the kernel).
37. `gauge_lift_difference_mem_ker`, **`conjugation_kernel_change`** — different auxiliary
    lifts change the comparison only by a kernel element.

### Packages I, K, L — family-level neutrality
38. **`FamilyKernelDefectNeutral`**.
39. **`familyLiftable_iff_familyKernelDefectNeutral`** — the central theorem.
40. `familyKernelDefectNeutral_of_presentation`,
    `familyKernelDefectNeutral_witness_independent`,
    `familyKernelDefectNeutral_atlasEquivalence_invariant`,
    `familyKernelDefectNeutral_refinement_invariant`,
    `refinementLiftable_imp_familyKernelDefectNeutral`.
41. **`badFamilyBase_familyKernelDefectNeutral`**,
    **`presentationLevel_nonNeutral_with_familyLevel_neutral`**.

### Packages M, O, P, Q — verdict, global object, repaired control
42. **`familyLiftable_constructs_globalTwofoldInternalFrameLift`**.
43. `UniversalFamilyLiftability` (stated, undecided), `task31_family_is_positive_evidence`.
44. `Task32Verdict`, `task32_verdict = classificationOnly`, `task32_verdictC_content`.
45. **`GoodBad.task31_bad_control_repaired`** — the required Package-Q chain.
46. `task32_ordinary_presentation_layer`, `task32_family_level_classification`,
    **`task32_closure`**.

---

## 4. Dependency graph

```
inherited TopologicalFrameFamily (Task XXVII, unchanged)
    │
    ├── bareOf ───────────────► BareMetricOrientedFamily          (Package A)
    └── presentationOf ───────► OrdinaryAtlasPresentation
                                     │
                 ┌───────────────────┼─────────────────────┐
                 ▼                   ▼                     ▼
        chartGauge (B)      OrdinaryCoverRefinement (D)   ordinarySystem (A)
                 │                   │                     │
        chartChange_transition_law   transitionFun_eq       │
                 │                   │                     ▼
                 └────► OrdinaryAtlasEquivalent (E) ◄──┐  DirectAtlasLiftable (F)
                                                       │        │
              gaugedSystem + InternallyLiftableGauge (G)│        ├──► RefinementLiftable (H)
                                │                      │        │
                 internalLiftable_gaugedSystem ─────────┘        ▼
                                │                          FamilyLiftable (F)
              tripleDefect_conjugation (J)                       │
                                                                 ▼
                                          FamilyKernelDefectNeutral (I)
                                                                 │
                            familyLiftable_iff_familyKernelDefectNeutral (L)
                                                                 │
                                    global glued internal object (P, via Task XXX/XXXI)
```

**Extra hypotheses attached to arrows (stated, never hidden).**

* *chart comparison ⇒ continuity*: requires the two presentations to lie inside one
  `JointOrdinaryAtlas` (their union is again an atlas).  Without it the comparison maps need
  not be continuous, and the arrow is false.
* *chart gauge ⇒ liftability transfer*: requires `InternallyLiftableOrdinaryGauge`.  The
  unrestricted arrow is **false** (good/bad control).
* *refinement ⇒ liftability*: unconditional in the easy direction; the converse is **false**.
* `FamilyLiftable` and `FamilyKernelDefectNeutral` quantify index types in one fixed universe;
  this is a scope note, recorded in §8.

---

## 5. Presentation-comparison table

| Datum | trivial presentation `A₀` | Task-XXXI presentation `A₁` |
| --- | --- | --- |
| bare family | `badFamilyBase` | `badFamilyBase` (identical, by `rfl`) |
| cover | `{univ, univ}` indexed by `Bool` | `{univ, univ}` indexed by `Bool` |
| chart `0` | `badTriv₀` (identity trivialization) | `badTriv₀` |
| chart `1` | `badTriv₀` | `badTriv₁` (twisted by the base element) |
| `g₀₁(b)` | `1` | `b` |
| chart gauge to `A₁` | `h₀(b) = 1`, `h₁(b) = b` | — |
| gauge internally liftable? | **no** (`goodBadGauge_not_internallyLiftable`) | — |
| directly liftable? | **yes** | **no** |
| fixed-system defect neutral? | **yes** | **no** |
| refinement liftable? | yes | **yes** (`badAtlas_refinementLiftable`) |
| family-level liftable? | yes | yes (same bare family) |

---

## 6. Liftability-transfer table

| Operation | Direct liftability | Family liftability |
| --- | --- | --- |
| ordinary cover refinement (forwards) | **preserved** (`directAtlasLiftable_refine`) | preserved |
| ordinary cover refinement (backwards) | **refuted** (`directLiftability_refinement_converse_refuted`) | preserved |
| ordinary chart gauge, internally liftable | **preserved** (`internalLiftable_gaugedSystem`) | preserved |
| ordinary chart gauge, arbitrary | **NOT preserved** (good/bad control) | preserved |
| internal kernel gauge | preserved (inherited Task XXXI) | preserved |
| choice of local internal representatives | preserved (inherited Task XXXI) | preserved |

---

## 7. Required decision table

| Question | Verdict |
| --- | --- |
| Bare underlying frame family separated from atlas data? | PROVED |
| Ordinary chart-change maps reconstructed? | PROVED |
| Exact transition gauge law proved? | PROVED |
| Ordinary chart gauges form coherent comparison data? | PROVED (identity, inverse, composition, triple-overlap) |
| Ordinary cover refinement formalized? | PROVED |
| Common ordinary refinement available? | PROVED (intersection construction) |
| Ordinary atlas equivalence defined? | PROVED (generated finite zig-zag relation) |
| Task-XXXI good/bad presentations same underlying family? | PROVED (by `rfl`) |
| Good/bad presentations ordinary-gauge related? | PROVED |
| Fixed-presentation neutrality family invariant? | NO, PROVED |
| Direct atlas liftability family invariant? | NO, PROVED |
| `FamilyLiftable` defined? | PROVED |
| Task-XXXI constant family family-level liftable? | PROVED |
| Direct liftability preserved by internally liftable chart gauges? | PROVED |
| Direct liftability preserved by arbitrary ordinary chart gauges? | NO |
| Direct liftability preserved under refinement? | PROVED (forwards); converse REFUTED |
| Family-level neutrality defined? | PROVED |
| Family neutrality atlas independent? | PROVED |
| Family neutrality cover-refinement independent? | PROVED |
| Full atlas-independent defect state reconstructed? | **NOT PACKAGED** (Package-K fallback taken) |
| Family liftability iff family neutrality? | PROVED |
| Task-XXXI bad presentation gives family obstruction? | NO, PROVED |
| Universal family liftability? | OPEN |
| Genuine atlas-independent non-liftable family? | NOT FOUND |
| Genuine geometric obstruction survives? | CLASSIFICATION ONLY |
| Global object follows from family neutrality? | PROVED |
| Conventional spatial Spin(3) identification? | DEFERRED |
| Experiment 1 / Experiment 2 joined? | NO |
| 3+1 Lorentzian spin structure? | NO |
| Physical spin/dynamics? | NO |

---

## 8. Unresolved mathematical obligations

1. **`GeometricKernelDefectState(E)`: PARTIAL / NOT PACKAGED.**  A single canonical quotient
   object across *all* covers is not constructed.  Following the explicit Package-K fallback,
   the Boolean family-level statement is proved instead, together with the exact
   transformation laws (`tripleDefect_conjugation`, `conjugation_kernel_change`) that such a
   quotient would be built from.
2. **Universal family liftability: OPEN.**  `UniversalFamilyLiftability` is stated and neither
   proved nor refuted.  No genuine family-level negative witness is produced; producing one
   inside the reconstructed layer is exactly where standard obstruction theory would have to
   be imported, which the firewall forbids.  Stop-on-hard-frontier rule applied → Verdict C.
3. **`RefinementLiftable` under further refinement:** the direction
   `RefinementLiftable R.atlas → RefinementLiftable A` is proved; the forward direction
   `RefinementLiftable A → RefinementLiftable R.atlas` is **not** proved and is not assumed.
   The obstruction is concrete: a refinement of `R.atlas` may use only charts of `R.atlas`, and
   comparing them with the charts of the liftable refinement requires exactly the chart gauge
   whose internal liftability is the open condition.
4. **Universe scope.**  `FamilyLiftable`, `RefinementLiftable` and `FamilyKernelDefectNeutral`
   quantify presentation index types within one universe parameter.  All examples live in
   `Type 0`, where the predicates are used as stated.
5. **Uniqueness of the global object.**  Whether the global glued objects obtained from two
   different liftable presentations of one family are equivariantly homeomorphic is **deferred**
   (item 106); only existence is claimed.
6. **Conventional comparison deferred.**  No identification with a Stiefel–Whitney class, Čech
   or singular cohomology, classifying space or standard spin obstruction is made anywhere; see
   §10.

---

## 9. Source ledger

### IMPORTED STANDARD RESULT (Mathlib, revision `8f9d9cff…`)

* `Continuous`, `ContinuousOn`, `ContinuousAt`, `continuous_iff_continuousAt`,
  `continuousOn_iff_continuous_restrict`, `ContinuousOn.comp`, `ContinuousOn.congr`,
  `IsOpen.mem_nhds`, `Continuous.subtype_mk`, `continuous_subtype_val`, `Continuous.prodMk`
  — `Mathlib.Topology.Basic`, `Mathlib.Topology.Constructions`, `Mathlib.Topology.Order`.
* `Continuous.mul`, `Continuous.inv` for topological groups — `Mathlib.Topology.Algebra.Group.Basic`.
* `MonoidHom.mem_ker`, `Subgroup.inv_mem`, `map_mul`, `map_inv`, `mul_inv_cancel`,
  `inv_mul_cancel_left`, `mul_inv_rev` — `Mathlib.Algebra.Group.*`, `Mathlib.GroupTheory.*`.
* `LinearIsometryEquiv`, `LinearIsometryEquiv.ext`, `LinearIsometryEquiv.refl` —
  `Mathlib.Analysis.InnerProductSpace.LinearIsometry` (used only through the inherited layers).
* `Nat.card`, `ExistsUnique`, `Function.Surjective` — Mathlib core.

### INHERITED PROJECT RESULT (Tasks XXVI–XXXI, unchanged)

* `MetricOrientedRankThreeFamily`, `LocalFibreTriv`, `MetricOrientedFibreAtlas`, `ovMap`,
  `fibreChart`, `transitionOn`, `transitionOn_self/_symm/_trans`,
  `MetricOrientedRankThreeFamily.transition` and its three laws, `MetricOrientedFibreAtlas.top`,
  `topTriv`, `continuous_transitionOn`, `TopologicalFrameFamily`, `OrdinaryTransitionSystem`
  — Task XXVI/XXVII.
* `InternalProjection`, `HasContinuousInternalRep`, `Certified.no_whole_domain_internal_rep`,
  `ModelBridge.modelInternalProjection`, `ModelBridge.gvisMulEquiv`, `TransitionSystem`,
  `ofOrdinary` — Task XXVIII.
* `CompatibleContinuousInternalTransitions`, `CanTrivialise` — Task XXIX.
* `GluedInternalFrameSystem`, `OrdinaryFrameModel`, `OrdinaryFrameSide` — Task XXX.
* `InternalLiftable`, `OrdinaryInternalLiftable`, `internalLiftable_of_transitions_trivial`,
  `IsNeutralGlobalKernelDefect`, `internalLiftable_iff_globalKernelDefect_neutral`,
  `neutralDefect_constructs_globalTwofoldInternalFrameLift`, `Examples.badFamilyBase`,
  `Examples.badTriv₀/₁`, `Examples.badFamily`, `Examples.continuousOn_badOverlap`,
  `Examples.badFamily_not_internalLiftable`, `badFamily_not_isNeutralGlobalKernelDefect`
  — Task XXXI.

### DERIVED IN TASK XXXII

Everything listed in §3.  In particular the chart-comparison map and its transition gauge law,
the joint-atlas continuity theorem, the ordinary cover-refinement theory, the generated atlas
equivalence, `gaugedSystem` and its transfer theorem, the defect conjugation laws,
`FamilyLiftable`, `FamilyKernelDefectNeutral`, their equivalence, the repaired good/bad control
and the Verdict-C closure.

### NOT USED ANYWHERE

Stiefel–Whitney classes; Čech, singular or sheaf cohomology; classifying spaces; any standard
spin-obstruction theorem; any named non-spin manifold or vector bundle; any pre-existing
notion of spin structure; general bundle-atlas equivalence machinery; smoothness, connections,
curvature; any physical statement.

---

## 10. Late conventional comparison (prose only)

Conventional spin geometry treats liftability as a property of the underlying oriented
orthonormal frame bundle rather than of one arbitrary atlas.  The present layer reproduces that
distinction *internally*: `DirectAtlasLiftable` is a property of a presentation, `FamilyLiftable`
of the bare geometry, and the two are formally separated by the good/bad control.  The
transformation law `g' = h_j g h_i⁻¹` together with `tripleDefect_conjugation` has the familiar
shape of a cocycle change of trivialization, but **no equality with any characteristic class is
asserted or proved** (items 111, 125), and since no genuine family-level non-neutral example was
reconstructed, **nothing here is claimed to be a real global spatial lift obstruction**
(item 112).

---

## 11. Preserved build failures

Every failing build during this task, with its exact repair.  No mathematical statement was
weakened by any repair, and no intended theorem turned out to be false.

| # | Command | Error | Diagnosis | Repair | Statement changed? |
| --- | --- | --- | --- | --- | --- |
| 1 | `lake build RequestProject.NullSectorTask32.UnderlyingFrameGeometry` | `failed to load header from … NegativeControls.setup.json: unexpected end of input` | truncated build artifact from an interrupted earlier invocation | re-ran the same command | no |
| 2 | same | `Invalid field 'underlying': the environment does not contain NullSectorTask27.TopologicalFrameFamily.underlying` | declaring `TopologicalFrameFamily.underlying` inside namespace `NullSectorTask32` produces `NullSectorTask32.TopologicalFrameFamily.underlying`, so dot notation cannot find it | renamed to plain `bareOf` / `presentationOf` | no |
| 3 | same | `Ambiguous term OrdinaryTransitionSystem` | Task XXVIII re-exports the Task-XXVII structure under the same name | fully qualified as `NullSectorTask27.OrdinaryTransitionSystem` | no |
| 4 | `lake build … OrdinaryCoverRefinement` | `unsolved goals` in `continuousOn_overlap` after the two `ovMap_apply` rewrites | the two sides agree only up to proof irrelevance of the membership proofs | appended `rfl` | no |
| 5 | same | `unexpected token 'omit'; expected 'lemma'` | `omit … in` was placed *after* a docstring | moved `omit … in` before the docstring | no |
| 6 | `lake build … FamilyLiftability` | `Type mismatch` in `v_symm` / `v_trans` of `internalLiftable_refinedSystem` | the implicit overlap point could not be inferred from the refined system | supplied the overlap points explicitly | no |
| 7 | same | `unused variable x`, `unused variable h'` | placeholders `_` hid the section variables | supplied the arguments explicitly | no |
| 8 | `lake build … GoodBadAtlasComparison` | `DirectAtlasLiftable.{0,0,0}` vs `DirectAtlasLiftable.{0,0,u_1}` | the statement `FamilyLiftable badFamilyBase` left the index universe free | pinned the universes: `FamilyLiftable.{0,0,0}` | no |
| 9 | same | `failed to compile definition, consider marking it as 'noncomputable'` for `badRefinement` | the inclusion proof mentions the noncomputable inherited atlas | marked `noncomputable` | no |
| 10 | same | `unused variable hzj` in `conjugation_kernel_change` | the hypothesis was genuinely unnecessary — only `zi` needs to be central | removed the hypothesis (statement became *more general*) | yes, strictly weaker hypotheses |
| 11 | `lake build … FamilyExistenceClassification` | `unused variable ι` | the binder existed only to fix a universe already fixed by the explicit universe annotation | removed the binder | no |

### Preserved false expectations

* **Arbitrary ordinary-gauge invariance of direct liftability** was *not* attempted as a
  theorem, because the good/bad control refutes it; the refutation is preserved as
  `fixedPresentation_neutrality_not_familyInvariant` and `task32_closure`.
* **The converse of the refinement theorem** was expected to be plausible and is **refuted**:
  `directLiftability_refinement_converse_refuted`.
* **Universal family liftability** was attempted only at the level of stating it; no proof was
  found and no counterexample was constructed.  It is recorded as OPEN, not silently dropped,
  and the base/family class was **not** narrowed afterwards.
