# TASK XXIX AUDIT — Defect-free descent and simultaneous kernel trivialization

Hardening the meaning of vanishing triple defect, solving the global kernel-adjustment
problem, and freezing the exact input for the next gluing stage.

Everything below is formalized in `RequestProject/NullSectorTask29/`.  No Task-XXVIII (or
earlier) source file is modified; `git diff` against the previous endpoint shows only new
files plus this audit and a new README section.

---

## 0. Build environment

| Item | Value |
| --- | --- |
| Lean | `leanprover/lean4:v4.28.0` (`lean-toolchain`) |
| Mathlib | tag `v4.28.0`, commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (`lake-manifest.json`) |
| New modules | 11, 2217 lines |
| Focused build | `lake build RequestProject.NullSectorTask29.Task29` — green, 8257 jobs |
| Whole project | `lake build` — green, 8328 jobs |
| Task-XXIX warnings | 0 |
| Inherited whole-project warnings | 114 (all in Task-11/14/21/23 sources, untouched here) |
| `sorry` / `admit` / custom axiom / `implemented_by` / `native_decide` / `bv_decide` / `unsafe` / `partial` | none |

Module chain (strictly linear except for the preserved counterexample, which branches off
`PairwiseDescent` and is re-imported by `Task29`):

```
Inherited                     (Package A: frozen Task-XXVIII endpoint, no new mathematics)
   ↓
DefectFreeHardening           (Package B: hard target A, first half)
   ↓
PairwiseDescent               (Packages C, D, E: κ, the descent verdict, conditional gluing)
   ↓                      ↘
KernelAdjustment              Counterexample   (Package D negative control, preserved)
   ↓
SimultaneousTrivialisation    (Packages G, H: hard target B)
   ↓
ChoiceInvariance              (Packages I, J: hard target C, first half)
   ↓
RefinementBehavior            (Packages K, L: hard target C, second half)
   ↓
CombinedCompatibility         (Packages M, N: the single-adjustment criterion)
   ↓
CompatibleTransitions         (Packages O, P, R + the settled refinement converse)
   ↓
Task29                        (Package Q, endpoints, axiom report)
```

---

## 1. Exact definitions

### 1.1 Inherited unchanged (Package A)

`InternalProjection` (continuous surjective homomorphism `proj : L →* G` with local continuous
sections, central and discrete kernel), `InternalProjection.Ker`, `IsInternalRepOn`,
`IsKerFunOn`, `relFactor u v = fun x => v x * (u x)⁻¹`, `tripleDefect uij ujk uik = fun x =>
(ujk x * uij x) * (uik x)⁻¹`, `TransitionSystem` (open cover `U i`, continuous `g i j`,
identity/inverse/triple laws), `tripleDom`, `incIJ/incJK/incIK`, `InternalTransitionCandidate`
(refined domains `V i j a` + stored representatives `u i j a`), `defect`, `defectDom`,
`triple_defect_change_of_rep`, `quadruple_defect_consistency`,
`IsCompatibleInternalTransitionSystem`, `CanTrivialiseSimultaneously`.  None is redefined.

### 1.2 Newly defined in Task XXIX

| Name | Statement |
| --- | --- |
| `TripleDefectFree C` | the inherited `IsCompatibleInternalTransitionSystem C`, i.e. every `δ_ijk` is `1`, for **all** index triples (repeated included) and all patches |
| `diagPt`, `swapPt`, `liftIII`, `liftIIJ`, `liftIJI` | the elementary reindexings of a point of a double overlap into a repeated-index triple overlap |
| `kappa C i j a b` | `relFactor (u i j a) (u i j b)`, i.e. `κ_ijαβ = u_ijβ * u_ijα⁻¹` |
| `kappaDom C i j a b` | `V i j a ∩ V i j b` |
| `PairwiseRefinementCoherent C` | `∀ i j a b, ∀ x ∈ V i j a ∩ V i j b, u i j a x = u i j b x` |
| `TripleDefectFreeDistinct C` | defect-freeness restricted to pairwise **distinct** index triples (negative control only) |
| `gluedRep C i j` | the glued map on the whole original overlap |
| `withReps C u' hu'` | the candidate with the same refined domains and other stored representatives |
| `KernelAdjustment P S Idx V` | one continuous kernel-valued function per refined domain; `Adj C` abbreviates it for `C` |
| `KernelAdjustment.one/comp/inv` | identity, composition, inverse adjustments |
| `adjust C ε` | the adjusted candidate, `u^ε_ij = ε_ij * u_ij`, on the same domains |
| `CanTrivialise C` | `∃ ε : Adj C, TripleDefectFree (adjust C ε)` |
| `DefectFreeRefinedInternalSystem P S` | a candidate together with a proof that all its triple defects are trivial |
| `DefectGaugeRelated C ε ε'` | `ε'` is obtained from `ε` by a further admissible kernel adjustment |
| `CandidateRefinement C`, `restrict C R`, `restrictAdj` | the elementary refinement datum, the restricted candidate, the pulled-back adjustment |
| `TrivialisableAfterRefinement C` | `∃ R, CanTrivialise (restrict C R)` |
| `RefinementConverse C R` | `CanTrivialise (restrict C R) → CanTrivialise C` (stated as a predicate, settled in `CompatibleTransitions`) |
| `CanDescendPairwise C` | `∃ ε : Adj C, PairwiseRefinementCoherent (adjust C ε)` |
| `CompatibilityReady C` | `CanTrivialise C` (justified by Package N) |
| `CompatibleContinuousInternalTransitions P S` | one continuous `v i j : U i ∩ U j → L` per **original** overlap with `proj (v i j) = g i j`, `v i i = 1`, `v j i = (v i j)⁻¹`, `v j k * v i j = v i k` |
| `LevelC`, `LevelD` | Package-Q levels |
| Counterexample carriers | `K2` (two-element discrete central group), `GTriv`, `Pt`, `Ix`, `projTriv`, `PTriv`, `trivSystem`, `badCandidate` |

---

## 2. Theorem inventory (principal endpoints)

Hard target A — the meaning of defect-free data:

1. `defectFree_identity_normalisation` — `δ = 1 ⇒ u_ii = 1`.
2. `defectFree_inverse_normalisation` — `δ = 1 ⇒ u_ji = u_ij⁻¹`.
3. `defectFree_exact_triple_law` — `δ = 1 ⇒ u_jk * u_ij = u_ik`.
4. `defectFree_implies_normalized_transition_laws_on_common_domain` — the packaged form.
5. `kappa` — the same-pair discrepancy, defined.
6. `kappa_isKerFunOn` — `κ` kernel-valued and continuous (for the certified projection: the
   inherited `KerSign`).
7. `kappa_isLocallyConstant` — `κ` locally constant.
8. `kappa_self`, `kappa_swap`, `kappa_comp` — `κ_ijαα = 1`, `κ_ijβα = κ_ijαβ⁻¹`,
   `κ_ijαγ = κ_ijβγ * κ_ijαβ`.
9. `pairwiseRefinementCoherent_iff_kappa_trivial`.
10. **`tripleDefectFree_imp_pairwiseRefinementCoherent`** — the verdict of Question A/D.
11. `Counterexample.tripleDefectFreeDistinct_not_imp_pairwiseRefinementCoherent` — the
    preserved negative control, plus `Counterexample.badCandidate_not_tripleDefectFree`.
12. `pairwise_refined_reps_glue`, `pairwise_refined_reps_glue_full` — conditional gluing.

Hard target B — simultaneous trivialization:

13. `adjust_isRep`, `proj_adjust`, `adjust_one`, `adjust_adjust`, `adjust_inv_adjust` —
    kernel adjustments preserve the ordinary projection and form the expected elementary
    operations.
14. `adjust_defect` — the inherited change law read on the interface.
15. **`simultaneous_trivialisation_iff_kernel_equations`** and
    `..._rearranged` (`ε_ik = ε_jk * ε_ij * δ_ijk`).
16. **`canTrivialise_iff_canTrivialiseSimultaneously`** — the Task-XXIX predicate *is* the
    inherited one (a theorem, not a restatement).
17. `canTrivialise_iff_kernel_equations_solvable`,
    `canTrivialise_iff_exists_defectFree_adjusted`, `defectFreeSystemOfSolution`.
18. `DefectFreeRefinedInternalSystem.proj_u / u_self / u_swap / u_trans / pairwiseCoherent`.

Hard target C — invariance:

19. **`simultaneous_trivialisability_rep_choice_invariant`**, with
    `canTrivialise_adjust_iff` and `rep_choice_difference_isKerFun`.
20. `defectGaugeRelated_refl / _symm / _trans`, `canTrivialise_constant_on_defectGauge`.
21. **`trivialisable_pullback_to_refinement`**; `trivialisableAfterRefinement_mono`;
    `trivialisableAfterRefinement_rep_choice_invariant`.
22. **`refinementConverse_holds`**, `canTrivialise_restrict_iff`,
    `trivialisableAfterRefinement_iff_canTrivialise`, `canTrivialise_candidate_independent`.

Synthesis:

23. `kappa_adjust` — the exact transformation law of `κ`.
24. `canDescendPairwise_iff_glue`, `canTrivialise_imp_canDescendPairwise`.
25. **`compatibility_ready_iff_single_adjustment_solves_all_required_kernel_equations`**,
    `compatibilityReady_iff_canTrivialise`, `compatibilityReady_rep_choice_invariant`.
26. `compatibleTransitionsOfDefectFree`, `compatibleTransitionsOfDefectFree_restricts`.
27. **`compatibilityReady_iff_exists_compatible_transitions`** and
    `canTrivialiseSimultaneously_iff_exists_compatible_transitions` — the principal success
    criterion.
28. `compatible_transitions_kernel_ambiguity`, `compatible_transitions_interface` —
    the frozen Task-XXX input.
29. `level_A_pointwise`, `level_B_refined_candidate`, `levelC_iff_levelD`,
    `levelD_iff_compatible_transitions` — the hierarchy.
30. `task29_inherited_candidate_exists`, `task29_inherited_defectFree_normalisation`,
    `task29_inherited_defect_forces_pairwise_descent`,
    `task29_inherited_solvability_iff_compatible_transitions` — everything applied to the
    inherited ordinary frame transitions through the certified projection.

---

## 3. Dependency graph

```
Task-XXVIII endpoint (unchanged)
        │
        ├─ frozen projection P, kernel Ker, IsInternalRepOn, IsKerFunOn, relFactor
        ├─ transition system S (U i, g i j, identity/inverse/triple laws)
        └─ candidate C (V i j a, u i j a), defect δ, change law, quadruple law
        ↓
Package B: δ = 1  ⇒  u_ii = 1  ⇒  u_ji = u_ij⁻¹ , u_jk u_ij = u_ik
        ↓                              ↓
Package C: κ_ijαβ = u_ijβ u_ijα⁻¹   (kernel-valued, continuous, locally constant)
        ↓
Package D: δ = 1  ⇒  κ = 1        (uses the repeated-index triple (i,i,j) and u_ii = 1)
        │                     ↘ negative control: distinct-index δ = 1  ⇏  κ = 1
        ↓
Package E: κ = 1  ⇒  unique continuous u_ij on the whole overlap U i ∩ U j
        ↓
Package F: admissible kernel adjustments ε (one/comp/inv), adjusted candidate C^ε
        ↓
Package G: C^ε defect-free ⇔ (ε_jk ε_ij ε_ik⁻¹) δ_ijk = 1 ⇔ ε_ik = ε_jk ε_ij δ_ijk
        ↓                              ↓
Package H: defect-free refined system   Package I: verdict independent of initial reps
        ↓                              ↓
Package J: defect-gauge relation (refl/symm/trans), verdict constant on it
        ↓
Package K/L: verdict preserved by refinement (and, via Package P, reflected by it)
        ↓
Package M: κ under adjustment; CanDescendPairwise ⇔ gluing of the adjusted reps
        ↓
Package N: one single adjustment solves δ and κ together  ⇔  CanTrivialise
        ↓
Package O/P: compatible normalized continuous internal transitions on the ORIGINAL overlaps
             ⇔ solvability of the kernel equations
        ↓
Package Q/R: Level A/B/C/D hierarchy; frozen Task-XXX interface (Level E not constructed)
```

Additional assumptions used by the arrows, stated explicitly:

* Package B and Package D use the defect-free hypothesis **including repeated index
  triples** and **all** patch indices.  With distinct indices only, the arrow
  `δ = 1 ⇒ κ = 1` fails (preserved counterexample).
* Package E uses only openness of the refined domains and their covering property
  (elementary gluing of continuous functions).
* Packages G, M use centrality of the kernel, as inherited.
* No arrow uses connectedness, manifold structure, smoothness, paracompactness, a
  partition of unity, a connection, cohomology, or any external obstruction theory.

---

## 4. Answers to the three central questions

**Question A — what does `δ = 1` really imply?**  Each implication was proved separately:
identity normalization (`defectFree_identity_normalisation`), inverse normalization
(`defectFree_inverse_normalisation`), the exact internal triple law
(`defectFree_exact_triple_law`), agreement of different refined representatives of the same
ordinary transition (`tripleDefectFree_imp_pairwiseRefinementCoherent`), and therefore
descent to a genuine coherent transition system on the original overlaps
(`compatibleTransitionsOfDefectFree`).  All five hold — *for the inherited quantification
over all index triples*.  The repeated-index instances are indispensable: with pairwise
distinct indices only, same-pair agreement is refuted by the preserved counterexample.

**Question B — can all defects be removed simultaneously?**  Exactly when the internally
derived kernel equations `(ε_jk ε_ij ε_ik⁻¹) δ_ijk = 1`, equivalently
`ε_ik = ε_jk ε_ij δ_ijk`, admit a solution by continuous kernel-valued functions on the
refined domains (`simultaneous_trivialisation_iff_kernel_equations`), and this is *exactly*
the inherited predicate `CanTrivialiseSimultaneously`
(`canTrivialise_iff_canTrivialiseSimultaneously`) and *exactly* the existence of a compatible
normalized continuous internal transition system on the original overlaps
(`compatibilityReady_iff_exists_compatible_transitions`).  Task XXIX does **not** claim that
such a solution exists for the certified projection over an arbitrary base: the results are
equivalences, not existence statements.

**Question C — is the solvability intrinsic?**  Yes, in the three senses proved: it is
independent of the initial local representatives
(`simultaneous_trivialisability_rep_choice_invariant`), of kernel gauge changes
(`canTrivialise_adjust_iff`, `canTrivialise_constant_on_defectGauge`) and of auxiliary
refinements (`trivialisable_pullback_to_refinement`, `refinementConverse_holds`,
`canTrivialise_restrict_iff`).  In fact the verdict depends only on the ordinary transition
system and the projection: `canTrivialise_candidate_independent`.

---

## 5. Causal comparison of the two defects (κ versus δ)

| | `δ_ijk` (inherited) | `κ_ijαβ` (Task XXIX) |
| --- | --- | --- |
| compares | the composition of three **different** ordinary transitions | two representatives of **one fixed** ordinary transition |
| lives on | a triple overlap `U i ∩ U j ∩ U k`, refined | an intersection `V i j α ∩ V i j β` of two refinement patches of one overlap |
| indices | three chart indices + three patch indices | one chart pair + two patch indices |
| algebraic law | quadruple consistency `δ_ijk δ_ikl = δ_jkl δ_ijl` | patch composition `κ_ijαγ = κ_ijβγ κ_ijαβ` |
| change of reps | `δ' = (ε_jk ε_ij ε_ik⁻¹) δ` | `κ' = (ε_ijβ ε_ijα⁻¹) κ` |
| relation proved | — | `δ = 1 ⇒ κ = 1` (repeated-index triples), **not** conversely by definition |

The two are kept formally distinct throughout; they are never identified merely because both
are kernel-valued.

---

## 6. Boost-free transformation table (kernel adjustments)

| Object | Under `u ↦ ε * u` |
| --- | --- |
| ordinary transition `g_ij` | unchanged (`proj_adjust`) |
| representative `u_ij` | `ε_ij * u_ij` |
| triple defect `δ_ijk` | `(ε_jk * ε_ij * ε_ik⁻¹) * δ_ijk` (inherited law, reused) |
| same-pair discrepancy `κ_ijαβ` | `(ε_ijβ * ε_ijα⁻¹) * κ_ijαβ` |
| solvability verdict | unchanged (`canTrivialise_adjust_iff`) |

---

## 7. Required decision table

| Question | Verdict |
| --- | --- |
| `δ = 1` implies exact triple law? | **PROVED** (`defectFree_exact_triple_law`) |
| `δ = 1` implies `u_ii = 1`? | **PROVED** (`defectFree_identity_normalisation`) |
| `δ = 1` implies inverse normalization? | **PROVED** (`defectFree_inverse_normalisation`) |
| Same-pair refinement discrepancy exists? | **PROVED** (`kappa`) |
| Same-pair discrepancy kernel-valued? | **PROVED** (`kappa_isKerFunOn`) |
| Same-pair discrepancy locally constant? | **PROVED** (`kappa_isLocallyConstant`) |
| `δ = 1` automatically forces same-pair agreement? | **PROVED** for the inherited (all-triples) predicate; **REFUTED** for the distinct-index restriction (preserved counterexample) |
| Agreeing refined reps glue continuously? | **PROVED** (`pairwise_refined_reps_glue_full`), conditional |
| Exact simultaneous-trivialization equation derived? | **PROVED** (`simultaneous_trivialisation_iff_kernel_equations`) |
| `CanTrivialiseSimultaneously` exactly characterized? | **PROVED** (`canTrivialise_iff_canTrivialiseSimultaneously`, `compatibilityReady_iff_exists_compatible_transitions`) |
| Solvability independent of initial reps? | **PROVED** (`simultaneous_trivialisability_rep_choice_invariant`) |
| Solvability preserved under refinement? | **PROVED** (`trivialisable_pullback_to_refinement`) |
| Converse from refinement valid? | **PROVED** (`refinementConverse_holds`) — as a corollary of the two-way theorem, *not* by a descent theorem across covers |
| Pairwise descent independent from triple triviality? | **NO, PROVED**: it is implied by it (`tripleDefectFree_imp_pairwiseRefinementCoherent`); independent only if the repeated-index triples are dropped |
| One kernel adjustment can solve every required condition? | **PROVED** (`compatibility_ready_iff_single_adjustment_solves_all_required_kernel_equations`) |
| Compatible normalized internal transitions obtained conditionally? | **PROVED** (`compatibleTransitionsOfDefectFree`) |
| Whole-original-overlap transitions obtained? | **PROVED** (conditionally on solvability) |
| Global total space constructed? | NO |
| Named global lifted structure constructed? | NO |
| Cohomology introduced? | NO |
| Characteristic class introduced? | NO |
| Physical spin derived? | NO |

---

## 8. Level hierarchy (Package Q)

| Level | Statement | Status |
| --- | --- | --- |
| A | pointwise internal representative exists | inherited (`level_A_pointwise`) |
| B | local continuous representatives after refinement | inherited from Task XXVIII (`level_B_refined_candidate`) |
| C | all triple defects simultaneously trivializable | characterized in Task XXIX (`LevelC`), **not** asserted to hold |
| D | one adjustment satisfies every descent requirement | `LevelC ↔ LevelD` (`levelC_iff_levelD`) |
| D′ | compatible whole-overlap transitions exist | `LevelD ↔` it (`levelD_iff_compatible_transitions`) |
| E | global internal total space | **not part of Task XXIX**; nothing in this layer constructs one |

---

## 9. Unresolved mathematical obligations

1. **Existence at Level C is not decided.**  For the certified projection over an arbitrary
   topological base, Task XXIX proves equivalences; whether the kernel equations actually
   admit a solution (equivalently, whether a compatible whole-overlap internal transition
   system exists) is left open, exactly as intended.
2. **No obstruction invariant is constructed.**  The defect-gauge relation is used as a
   relation only; it is not quotiented and receives no external name.  Whether the verdict
   can be encoded in a single invariant is not addressed.
3. **Base-topological hypotheses are never used.**  No connectedness, separation,
   paracompactness or local compactness assumption enters; consequently no statement about
   the *size* of the family of solutions (when solutions exist) is made.
4. **Level E is untouched.**  Nothing is proved about gluing local products into a total
   space, about a topology on such an object, or about a group action on it.

---

## 10. Build ledger, including every failed build (item 139)

All commands were run in the project root.

### 10.1 `lake build RequestProject.NullSectorTask29.Counterexample` — FAILED (first attempt)

```
error: RequestProject/NullSectorTask29/Counterexample.lean:53:36: Insufficient number of
  fields for `⟨...⟩` constructor: Constructor `IsTopologicalGroup.mk` does not have explicit
  fields, but 1 was provided
error: RequestProject/NullSectorTask29/Counterexample.lean:128:0: declaration
  `NullSectorTask29.Counterexample.badCandidate_not_pairwiseRefinementCoherent` contains
  universe level metavariables at the expression
error: RequestProject/NullSectorTask29/Counterexample.lean:146:0: declaration
  `NullSectorTask29.Counterexample.badCandidate_not_tripleDefectFree` contains universe level
  metavariables at the expression
```

*Diagnosis.*  (i) In this Mathlib revision `IsTopologicalGroup` extends `ContinuousMul` and
`ContinuousInv`, so its anonymous constructor takes no explicit field; the continuity of
inversion has to be supplied as a `ContinuousInv` instance.  (ii) The universe-polymorphic
`PUnit` was used directly as the base and as the index type, leaving the universe level of
`PUnit.unit` undetermined in the statements.

*Repair.*  Added `instance : ContinuousInv K2 := ⟨continuous_of_discreteTopology⟩` and
`instance : IsTopologicalGroup K2 := ⟨⟩`; introduced monomorphic wrappers
`def Pt : Type := PUnit`, `def Ix : Type := PUnit` with named points `ptB`, `ix`, and used
them everywhere.

*Mathematical content changed?*  **No.**  The counterexample and all its statements are the
same; only the carriers were made universe-monomorphic and one instance was supplied
differently.

### 10.2 `lake build RequestProject.NullSectorTask29.SimultaneousTrivialisation` — FAILED (first attempt)

```
error: RequestProject/NullSectorTask29/SimultaneousTrivialisation.lean:107:28: Application
  type mismatch: The argument h'' has type  A * E * D * F⁻¹ = 1  but is expected to have type
  A * E * D / F = 1  in the application  eq_of_div_eq_one h''
```

*Diagnosis.*  `eq_of_div_eq_one` is stated for the `/` notation, which is not syntactically
`* _⁻¹` in a general group.

*Repair.*  Replaced by `mul_inv_eq_one.1 h''`.

*Mathematical content changed?*  **No.**  Same statement, same proof idea.

### 10.3 Linter warnings in `DefectFreeHardening` — repaired at the root

```
warning: ... automatically included section variable(s) unused in theorem
  `NullSectorTask29.tripleDefect_repeated`: [TopologicalSpace L] [IsTopologicalGroup L]
  [TopologicalSpace X]
```
(and likewise for `eq_one_of_tripleDefect_repeated`, `inv_of_tripleDefect_repeated`)

*Repair.*  `omit [TopologicalSpace L] [IsTopologicalGroup L] [TopologicalSpace X] in` before
the three purely algebraic lemmas, following the convention already used in Task XXVIII.  No
linter was disabled.

### 10.4 Green builds

```
lake build RequestProject.NullSectorTask29.Inherited                    -> 8247 jobs, green
lake build RequestProject.NullSectorTask29.DefectFreeHardening          -> 8248 jobs, green
lake build RequestProject.NullSectorTask29.PairwiseDescent              -> 8249 jobs, green
lake build RequestProject.NullSectorTask29.Counterexample               -> 8250 jobs, green
lake build RequestProject.NullSectorTask29.KernelAdjustment             -> 8250 jobs, green
lake build RequestProject.NullSectorTask29.SimultaneousTrivialisation   -> 8251 jobs, green
lake build RequestProject.NullSectorTask29.ChoiceInvariance             -> 8252 jobs, green
lake build RequestProject.NullSectorTask29.RefinementBehavior           -> 8253 jobs, green
lake build RequestProject.NullSectorTask29.CombinedCompatibility        -> 8254 jobs, green
lake build RequestProject.NullSectorTask29.CompatibleTransitions        -> 8255 jobs, green
lake build RequestProject.NullSectorTask29.Task29                       -> 8257 jobs, green
lake build                                                              -> 8328 jobs, green
```

Warnings: **0** from `RequestProject/NullSectorTask29/*`; **114** inherited warnings in
Task-11/14/21/23 sources, none touched by this task.

### 10.5 Axiom report

`Task29.lean` runs `#print axioms` on every principal endpoint listed in §2 (59 declarations).
Every one reports exactly

```
[propext, Classical.choice, Quot.sound]
```

i.e. only the standard Lean/Mathlib axioms.  No custom axiom, no `native_decide`, no
`bv_decide`, no `implemented_by`, no `unsafe`, no `partial`, no `sorry`, no `admit`.

---

## 11. Source ledger

**IMPORTED STANDARD RESULT** (Mathlib `v4.28.0`; module paths located in the installed
revision):

| Declaration | Module | Used for |
| --- | --- | --- |
| `ContinuousOn.mono`, `ContinuousOn.comp`, `ContinuousOn.continuousAt` | `Mathlib/Topology/ContinuousOn.lean` | continuity of `κ`, of pulled-back kernel functions, of the glued map |
| `continuous_iff_continuousAt`, `ContinuousAt.congr` | `Mathlib/Topology/Continuous.lean` | the gluing theorem of Package E |
| `IsOpen.mem_nhds` | `Mathlib/Topology/Neighborhoods.lean` | the gluing theorem of Package E |
| `ContinuousOn.mul` | `Mathlib/Topology/Algebra/Monoid/Defs.lean` | continuity of products of kernel functions and representatives |
| `ContinuousOn.inv` | `Mathlib/Topology/Algebra/Group/Defs.lean` | continuity of inverses |
| `Subgroup.one_mem`, `Subgroup.mul_mem`, `Subgroup.inv_mem` | `Mathlib/Algebra/Group/Subgroup/Defs.lean` | kernel-function algebra |
| `MonoidHom.mem_ker` | `Mathlib/Algebra/Group/Subgroup/Ker.lean` | kernel membership |
| `mul_inv_eq_one` | `Mathlib/Algebra/Group/Basic.lean` | the rearranged trivialization equation |
| `eq_inv_of_mul_eq_one_left` | `Mathlib/Algebra/Group/Defs.lean` | inverse normalization |
| `Commute`, `Commute.inv_left` | `Mathlib/Algebra/Group/Commute/Defs.lean`, `Mathlib/Algebra/Group/Commute/Basic.lean` | centrality rearrangements in Packages G and M |
| `group` tactic | `Mathlib/Tactic/Group.lean` | routine group-word normalizations |
| `Multiplicative`, `ZMod` | `Mathlib/Data/ZMod/Defs.lean` | the preserved counterexample only |
| `continuous_of_discreteTopology` | `Mathlib/Topology/Order.lean` | the preserved counterexample only |

**DERIVED IN TASK XXIX**: everything in §2, i.e. all statements about `TripleDefectFree`,
`kappa`, `PairwiseRefinementCoherent`, gluing, `KernelAdjustment`, `adjust`, `CanTrivialise`,
`DefectFreeRefinedInternalSystem`, `DefectGaugeRelated`, `CandidateRefinement`, `restrict`,
`TrivialisableAfterRefinement`, `CanDescendPairwise`, `CompatibilityReady`,
`CompatibleContinuousInternalTransitions`, the Level hierarchy and the inherited
applications.

**INHERITED FROM TASK XXVIII** (used unchanged, never restated as new): the projection
interface and its kernel facts, `IsInternalRepOn`, `IsKerFunOn`, `relFactor`, the
kernel-ambiguity theorem, `tripleDefect` and its kernel-valuedness/continuity/local
constancy, `triple_defect_change_of_rep`, `quadruple_defect_consistency`,
`InternalTransitionCandidate`, `defect`, `defectDom`,
`IsCompatibleInternalTransitionSystem`, `CanTrivialiseSimultaneously`, `candidateOfSystem`,
`ModelBridge.modelInternalProjection`.

---

## 12. Scope firewall check

* Task-XXVIII statements: unmodified (only new files were added).
* Ordinary transition system, internal projection, kernel, triple defect: used as inherited,
  never redefined.
* No external obstruction theory, no cohomology, no Čech object as a primitive, no
  characteristic class, no principal bundle, no global internal total space, no named global
  lifted structure, no manifold or smoothness assumption, no connection or curvature, no
  physical spin statement.
* Conventional terminology appears only in comparison prose, never as mathematical input.
