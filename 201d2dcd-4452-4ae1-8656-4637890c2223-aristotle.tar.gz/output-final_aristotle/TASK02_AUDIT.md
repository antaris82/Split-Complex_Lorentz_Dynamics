# Task 02 — Projective Causal Boundary and Independent Scalar-Phase Audit

All statements below are machine-checked in `RequestProject/Task02/`.
No Task 01 source file was modified; Task 02 depends on Task 01 only by `import`.
Every reference of the form `Task02.foo` is a Lean theorem in this repository;
`Task01.…` references are the imported Task 01 theorems.

## 0. Conventions (inherited from Task 01, restated)

* Signature `(+,−)`: `Q_c(t,x) = c²t² − x²`; null coordinates `u = ct+x`,
  `w = ct−x`; `c > 0` throughout.
* Four-vector components `V = (V⁰, V¹)` with `minkNorm V = (V⁰)² − (V¹)²`
  (the factor `c` absorbed into `V⁰`, as in `Task01.Boundary.fourVelocity`);
  boost `Task01.Boundary.boostV θ`.
* Time orientation: *future* means `V⁰ > 0`.
* Direction coordinate `β = V¹/V⁰` (`Task02.betaOf`), normalized representative
  `(1, β)` (`Task02.causalRep`).  For a timelike vector `β = v/c`.
* Oriented null sector label `σ ∈ {+1, −1}`; `K_σ(E) = Task01.Boundary.nullMomentum E c σ = (E/c, σE/c)`.
* Sign conventions are unchanged from Task 01; every result is relative to them
  (**CONVENTION_DEPENDENT** where flagged).

---

## A. Lean files

| File | Contents |
|---|---|
| `RequestProject/Task02/Carriers.lean` | positive rays, Mathlib `Projectivization`, exactly what each quotient discards, boost action on all three carriers |
| `RequestProject/Task02/ProjectiveCone.lean` | future causal/timelike/null cones, `β`-coordinate, bijection with `[-1,1]`, fractional-linear boost action `F_θ`, group law, boundary fixed points, projective limits |
| `RequestProject/Task02/Orbits.lean` | orbits and stabilizers of the five carriers, null-orbit collapse, parity vs connected component, carrier-specific boundary summary |
| `RequestProject/Task02/ScalarPhase.lean` | the independent scalar phase `Θ = Θ₀ + Ωτ`, its two rates, transformation table, independence theorem, `sech η` vs `e^{±η}` |
| `RequestProject/Task02/Task01Audit.lean` | precision repairs of three Task 01 prose claims |

---

## B. Carrier comparison table (Deliverable B)

Let `X ≠ 0` in `V = ℝ^{1,1}`.

| Carrier | Definition | Retained | Discarded | Equality criterion | Theorem |
|---|---|---|---|---|---|
| vector `X` | the element of `V` | direction, orientation, scale | — | `X = Y` | — |
| positive ray `Ray₊(X)` | `Task02.RayPos X = {lX : l > 0}` | direction **and** orientation | the positive scale | `∃ l > 0, X = lY` | `Task02.RayPos_eq_RayPos_iff` |
| projective class `[X]` | `Task02.proj` = `Projectivization.mk ℝ X hX` | direction only (unoriented line) | scale **and** sign | `∃ l ≠ 0, X = lY` | `Task02.proj_eq_proj_iff` |

Precise loss statements:

* ray coarser than vector: `Task02.RayPos_smul_eq_but_ne` (`Ray₊(lX) = Ray₊(X)` while `lX ≠ X` for `l>0, l≠1`);
* projective coarser than ray: `Task02.proj_neg_eq` (`[X] = [−X]`) together with `Task02.RayPos_neg_ne` (`Ray₊(X) ≠ Ray₊(−X)`);
* ray refines projective: `Task02.proj_eq_of_RayPos_eq`;
* **on the future cone the two quotients coincide**: `Task02.proj_eq_iff_RayPos_eq` — a nonzero scalar relating two future-pointing vectors is automatically positive.  *This is the exact sense in which "positive ray" and "projective class" may be used interchangeably here, and it is a theorem, not a notation.*
* the boost acts on each carrier: `Task02.boostV_smul`, `Task02.boostV_image_RayPos`, `Task02.proj_boostV_congr`.

Status: **DERIVED**; the vector/ray/projective distinction is **QUOTIENT_DEPENDENT** by construction.

---

## C. Projective causal-boundary theorem (Deliverable C)

* Cones: `Task02.FutureCausal`, `Task02.FutureTimelike`, `Task02.FutureNull`
  (defined by `V⁰ > 0` and `minkNorm ≥ 0`, `> 0`, `= 0` respectively).
* Normalization: every future causal `V` satisfies `V = V⁰ · (1, β)`
  (`Task02.eq_smul_causalRep`), hence `Ray₊(V) = Ray₊((1,β))`
  (`Task02.RayPos_eq_RayPos_causalRep`).
* **Characterization (proved, not assumed)**:
  * causal ⟺ `|β| ≤ 1` — `Task02.mem_FutureCausal_iff`;
  * timelike ⟺ `|β| < 1` — `Task02.mem_FutureTimelike_iff`;
  * null ⟺ `|β| = 1` — `Task02.mem_FutureNull_iff`.
* **Equivalence with the interval**: `Task02.bijOn_causalRays` —
  `β ↦ Ray₊((1,β))` is a bijection of `[-1,1]` onto the set of future causal
  rays `Task02.FutureCausalRays`.  Interior `(-1,1)` = timelike directions,
  endpoints `{±1}` = the two null directions.

Status: **DERIVED**, **QUOTIENT_DEPENDENT** (the interval is the *ray/projective*
carrier; the vector carrier is not an interval).

### Boost action on the projective carrier

* `Task02.betaOf_boostV`: `β ↦ F_θ(β) = (β + tanh θ)/(1 + β tanh θ)`, derived
  from `boostV` (`Task02.boostV_fst_eq`, `Task02.boostV_snd_eq`; the denominator
  is positive by `Task02.one_add_mul_tanh_pos`).
* Group law: `Task02.Fmap_Fmap` (`F_{θ₁} ∘ F_{θ₂} = F_{θ₁+θ₂}` on `[-1,1]`),
  `Task02.Fmap_zero`.  The hyperbolic addition formula needed for it is proved
  here as `Task02.tanh_add` (absent from Mathlib).
* Interior: `Task02.Fmap_mem_Ioo`, `Task02.Fmap_tanh` (`F_θ(tanh η) = tanh(η+θ)`),
  `Task02.Fmap_transitive_Ioo` (**simply transitive** on `(-1,1)`).
* Boundary: `Task02.Fmap_one`, `Task02.Fmap_neg_one` — each of `β = ±1` is
  **individually fixed** by every boost (not exchanged, no nontrivial orbit).
* Timelike directions never reach null ones: `Task02.timelike_dir_not_null_dir`.

---

## D. Orbit / stabilizer table (Deliverable D, Sections 5–9)

Group: the connected boost group `{B_θ : θ ∈ ℝ} ≅ SO⁺(1,1)`.  Stabilizers are
recorded as subsets of the rapidity line (`Task02.StabVec`, `Task02.StabRay`,
`Task02.StabProj`).

| # | Carrier | Orbit | Stabilizer | Theorems |
|---|---|---|---|---|
| A | timelike unit vector `U(η)` | the whole future unit hyperbola | `{0}` | `Task02.orbVec_fourVelocity`, `Task02.stabVec_fourVelocity` (= Task 01 `stabilizer_trivial`) |
| B | timelike positive ray `Ray₊(U(η))` | all future timelike rays ≅ `(-1,1)` | `{0}` | `Task02.orbRay_fourVelocity`, `Task02.stabRay_fourVelocity`; projective version `Task02.stabProj_fourVelocity` |
| C | null vector `K_σ(E)`, `E>0` | **the whole positive null ray** | `{0}` | `Task02.orbVec_nullMomentum`, `Task02.stabVec_nullMomentum` |
| D | positive null ray `Ray₊(K_σ(E))` | a single point | **`ℝ` (all of the group)** | `Task02.orbRay_nullMomentum`, `Task02.stabRay_nullMomentum` |
| E | projective null direction `[K_σ(E)]` | a single point | **`ℝ`** | `Task02.stabProj_nullMomentum` |

* Boost law for both sectors: `Task02.nullMomentum_boost_sector`
  (`B_θ K_σ(E) = K_σ(e^{σθ}E)`), from `Task02.boostV_causalRep_null`.
* **Exact orbit of the null vector** (Section 6): `Task02.orbVec_nullMomentum`
  proves *both inclusions*; the rapidity realizing a prescribed rescaling `l>0`
  is `θ = σ log l`.
* **The collapse** (Section 6): `Task02.null_orbit_collapses` — the orbit
  contains vectors different from `K_σ(E)`, yet all of them have the *same*
  positive ray.  This, and only this, is why the isotropy jumps.
* Answer to acceptance question 1: **YES for the null carrier, NO for the
  timelike carrier.**  Status: **QUOTIENT_DEPENDENT**.

### Connected component versus parity (Section 9)

| Object | Connected group `SO⁺(1,1)` | Parity `P(V⁰,V¹) = (V⁰,−V¹)` |
|---|---|---|
| each projective null direction `β = ±1` | individually invariant (`Task02.null_directions_invariant_under_boosts`) | exchanged (`Task02.null_directions_exchanged_by_parity`, `Task02.parityV_nullMomentum`, `Task02.betaOf_parityV`) |
| future causal cone | preserved (`Task02.boostV_mem_FutureCausal`) | preserved (`Task02.parityV_mem_FutureCausal`) |
| time orientation | required for every statement above | not affected by parity; time reversal leaves the cone (`Task02.timeReversal_not_mem_FutureCausal`) |

No further discrete structure is claimed; Task 01's `discrete_structure_is_Z2`
remains the only classification statement (**NEW_INPUT_REQUIRED** for anything
beyond it).

### Timelike → null projective boundary (Section 7)

`Task02.projective_boundary_limits`:

* `|β(U(η))| < 1` for every finite `η` (`Task02.fourVelocity_dir_ne_null`) — the
  hyperbola contains no null vector, as in Task 01;
* `β(U(η)) = tanh η → +1` as `η → +∞` and `→ −1` as `η → −∞`
  (`Task02.tendsto_betaOf_fourVelocity_atTop/atBot`), and `(1,±1)` are exactly
  the two future null directions;
* while `U(η)` itself diverges: `(U(η))⁰ → ∞`
  (`Task02.tendsto_fourVelocity_fst_atTop`).

So "`U(η)` has no limit in the unit hyperbola" and "`[U(η)]` has a limit in the
projective carrier" are both true and are statements about **different
carriers**.  Status: **REPRESENTATION_DEPENDENT**.

---

## E. Scalar-phase / null-wave transformation table (Deliverable E)

Configuration: a timelike worldline of constant rapidity `η`
(`Task02.constRapWorldline`), proper time `τ(t) = t sech η`
(`Task02.properTime_constRap`), scalar phase `Θ(τ) = Θ₀ + Ωτ`
(`Task02.scalarPhase`).

| Quantity | Definition / value | Behaviour under a boost by `θ` | Weight | Theorem |
|---|---|---|---|---|
| `Ω = dΘ/dτ` | intrinsic rate | unchanged | `0` (invariant) | `Task02.hasDerivAt_scalarPhase_properTime`, `Task02.Omega_invariant` |
| `dΘ/dt = Ω sech η` | coordinate rate | `Ω sech(η+θ)` | not multiplicative; **not** invariant | `Task02.hasDerivAt_scalarPhase_coordTime`, `Task02.rhoCoord_eq_iff`, `Task02.rhoCoord_not_invariant` |
| `k_σ` | null wave number of sector `σ` | `e^{σθ} k_σ` | `e^{σθ}` | `Task02.waveBoost_nullCovector` |
| `ω_σ = σ c k_σ` | null frequency | `e^{σθ} ω_σ` | `e^{σθ}` | `Task02.waveBoost_nullCovector`, `Task02.nullSector_one_parameter` |
| `E` (null momentum scale) | `K_σ(E)` | `e^{σθ}E` | `e^{σθ}` | `Task02.nullMomentum_boost_sector` |
| `u`, `w` (null coordinates) | `ct±x` | `e^{+θ}u`, `e^{−θ}w` | `e^{±θ}` | Task 01 `nullU_boost`, `nullW_boost` |

Combined statement: `Task02.weight_table`.

Reading of the table (and nothing more): `Ω` is the only listed quantity of
weight `0`; `Ω sech η` is not of the form `weight × (frame-independent scalar)`;
`k_σ`, `ω_σ`, `E` share the sector weight `e^{σθ}` with the corresponding null
coordinate factor.  Same weight is **not** identification.

### `sech η` versus `e^{±η}` (Section 14, purely algebraic)

| Statement | Result | Theorem |
|---|---|---|
| `sech η = e^{+η}` | only `η = 0` | `Task02.sech_eq_exp_iff` |
| `sech η = e^{−η}` | only `η = 0` | `Task02.sech_eq_exp_neg_iff` |
| `e^{+η}/sech η` | `(e^{2η}+1)/2 = 1/(1−β)` | `Task02.exp_div_sech`, `Task02.exp_div_sech_beta` |
| `e^{−η}/sech η` | `(e^{−2η}+1)/2 = 1/(1+β)` | `Task02.exp_neg_div_sech`, `Task02.exp_neg_div_sech_beta` |
| `η → +∞` | `e^{+η}/sech η → ∞`; `e^{−η}/sech η → 1/2` (from the same formulas) | `Task02.tendsto_exp_div_sech_atTop` |
| `η → −∞` | `e^{+η}/sech η → 1/2` | `Task02.tendsto_exp_div_sech_atBot` |

The pairs agree only at `η = 0`, and the ratios are non-constant; no
cross-sector identification is inferred (Task 01 `exp_pair_ne_tanh_sech_pair`
remains the exact statement about the *pairs*).

### Intrinsic versus coordinate rate (Section 13)

| `η` | `ρ_intrinsic = dΘ/dτ` | `ρ_coord = dΘ/dt` |
|---|---|---|
| `η = 0` | `Ω` | `Ω` (`Task02.rhoCoord_zero_rapidity`) |
| finite `η` | `Ω` | `Ω sech η` |
| `|η| → ∞` | `Ω` (constant; `Task02.tendsto_rhoIntrinsic`) | `→ 0` (`Task02.tendsto_rhoCoord_atTop`, `…atBot`) |

`Task02.rhoCoord_eq_mul_properTimeRate`: the vanishing is *exactly* the factor
`dτ/dt` and nothing else.  No interpretation is attached.

---

## F. Independence theorem (Deliverable F, Sections 12 and 18)

**Automorphism argument.**  The independent positive rescalings

    Ω ↦ aΩ            (a > 0)
    (k_σ, ω_σ) ↦ b(k_σ, ω_σ)   (b > 0)

preserve every structure introduced so far:

* null dispersion: `Task02.nullDispersion_smul`;
* the wave-covector boost law: `Task02.waveBoost_smul`;
* the scalar-phase derivative structure: `Task02.scalarPhase_smul`;
* the Lorentz-geometric data (`β`, boosts, `τ`) are untouched — they do not
  involve `Ω` or `k_σ` at all;
* realizability of every pair: `Task02.configurations_fill_quadrant`.

**Theorem** (`Task02.no_canonical_cross_sector_relation`): any predicate
`P(Ω, k)` invariant under these rescalings and satisfied at one point of the
positive quadrant is satisfied on the *whole* positive quadrant.  Hence no
invariant relation cuts the quadrant down.

**Corollary** (`Task02.cross_sector_equality_not_invariant`): the specific
relation `Ω = c k` is *not* rescaling invariant, so it is not implied by the
listed structures; it can only be **imposed**.

Verdict: **NO CANONICAL CROSS-SECTOR RELATION IS DERIVED FROM THE CURRENT
INPUTS** — supported by the explicit rescaling automorphism above.
Status: **INDEPENDENT_DEGREES_OF_FREEDOM** / **NEW_INPUT_REQUIRED** for any
relation between `Ω` and a null-wave scale.

### Dependency-separation graph (Section 18)

```
Branch 1  Lorentz causal / projective geometry
  Q_c, boostV ──▶ FutureCausal/Timelike/Null ──▶ betaOf, causalRep
        │                                  └──▶ Fmap (F_θ), group law
        └──▶ RayPos, proj ──▶ orbit/stabilizer table

Branch 2  Scalar phase along a timelike curve
  τ (Task 01 properTime) ──▶ constRapWorldline ──▶ scalarPhase Θ₀ Ω
        └──▶ rhoIntrinsic = Ω        (weight 0)
        └──▶ rhoCoord   = Ω sech η   (uses only dτ/dt)

Branch 3  Null wave-covector sector
  phase, waveBoost (Task 01) ──▶ NullDispersion ──▶ nullCovector c σ k
        └──▶ k_σ ↦ e^{σθ} k_σ
```

Cross-branch edges actually present:

| Edge | Created by | Nature |
|---|---|---|
| Branch 1 → Branch 2 | `Task02.rhoCoord_eq_mul_properTimeRate` (`dτ/dt = sech η` is Lorentz-geometric) | **DERIVED**: the conversion factor only |
| Branch 1 → Branch 3 | `Task02.waveBoost_nullCovector`, `Task02.nullMomentum_boost_sector` (the boost acts on the sector scale) | **DERIVED** |
| Branch 2 ↔ Branch 3 | **none** | no theorem relates `Ω` to `k_σ`; adding one requires a new equation (`Task02.no_canonical_cross_sector_relation`) |

No cross-branch dependency is introduced by any definition in Task 02: `Ω`
appears in no definition of Branch 3, and `k_σ`, `ω_σ` appear in no definition
of Branch 2.

---

## G. Corrected Task 01 claims (Deliverable G)

| Task 01 prose claim | Exact theorem support | Keep / narrow / correct | Corrected statement |
|---|---|---|---|
| "NO ADDITIONAL BOUNDARY SYMMETRY FOLLOWS FROM THE STANDARD STRUCTURE." | Task 01 `stabilizer_trivial`, `stabilizer_null_trivial` (vector carrier only) | **NARROW** (`TASK01_STATEMENT_REQUIRES_NARROWING`) | *Carrier-specific* (`Task02.boundary_symmetry_carrier_specific`): for **vectors** the stabilizer is trivial everywhere (timelike and null); for the **positive ray / projective class** of a null vector the stabilizer is the whole boost group, because the boost orbit of a nonzero null vector is exactly its positive ray (`Task02.orbVec_nullMomentum`, `Task02.null_orbit_collapses`).  For timelike vectors the ray quotient changes nothing (`Task02.stabRay_fourVelocity`).  The isotropy jump is a property of the *quotient*, standard in Lorentz geometry, and requires no new structure. |
| "THE APPARENT VANISHING RATE IS EXACTLY THE STANDARD PROPER-TIME RATE (and introduces no new degree of freedom)." | Task 01 `Rtau_bijOn`, `exists_factor_through_Rtau`, `closingSpeed_eq_of_Rtau`, `dopplerRate_eq_of_Rtau` | **NARROW/CORRECT** | Two separate facts.  (i) *Factorization*: every function of speed on `[0,c)` equals some `f ∘ R_τ`, because `R_τ` is a bijection — this is a change of coordinate and carries **no** information (`Task02.factorization_is_not_equality`).  (ii) *Non-uniqueness*: `R_τ`, the closing speed and the Doppler rate are **pairwise distinct** functions on `0<v<c` (`Task02.vanishing_rates_pairwise_distinct`) although all three satisfy `R(0)=c` and `R(v)→0` as `v→c⁻` (`Task02.endpoint_data_do_not_select`).  Strongest proved replacement: **the endpoint data `R(0)=c`, `R(v)→0` do not single out any one standard scalar function; `R_τ` is one of at least three distinct natural standard rates, and every function of speed factors through `R_τ` trivially.** |
| "Null dispersion collapses Model C to **exactly two** solutions." | Task 01 `modelC_null_two_solutions` (two algebraic branches) | **CORRECT the prose; the theorem is untouched** | `Task02.modelCNullSolutions_zero_ncard`: for `r = 0` the branches coincide and the solution set has **exactly one** element, `(k,ω) = (0,0)`.  `Task02.modelCNullSolutions_ncard`: for `r ≠ 0` (and `|v|<c`, `c>0`) it has **exactly two**. |
| "`τ` ceases to exist at `m = 0`." | Task 01 `properTime_null_eq_zero`, `no_null_unit_normalisation` | **CORRECT the wording** | The Lorentz arclength functional **is defined** on a null line and its value is `0` (`Task02.null_arclength_defined_and_zero`); it is therefore **degenerate, not undefined**, and fails to be a nondegenerate parameter because it is not injective (`Task02.null_arclength_not_injective`).  Affine parameters **do** exist, with no canonical scale: every rescaling of the tangent is again null and none has unit norm (`Task02.null_affine_no_canonical_scale`, `Task02.null_affine_reparam`).  What genuinely does not exist is a *unit-normalized* four-velocity/proper-time parametrization. |

### Corrected carrier/type-level entries for the Task 01 limit table

| Structure | at `m = 0` (null) — Task 01 wording | corrected type-level statement |
|---|---|---|
| `τ` (Lorentz arclength) | "undefined / ceases to exist" | **defined, identically zero, degenerate** (not a parameter) |
| affine parameter | not discussed | **exists; scale not fixed by the metric** (a positive-scale family) |
| `u^μ` | undefined | **no unit-normalized representative exists** (Task 01 `no_null_unit_normalisation`); the null direction survives only as a *ray/projective* object |
| `η` | undefined | no rapidity labels a null direction; but the null *direction* is a fixed point of the induced `β`-action (`Task02.Fmap_one`, `Task02.Fmap_neg_one`) |

---

## H. Updated unresolved-obligation register

Task 01 obligations F1–F12 are **retained unchanged** (see `TASK01_AUDIT.md`,
section F).  Task 02 appends:

| # | Statement | Classification | Note |
|---|---|---|---|
| G1 | Any relation between the scalar-phase scale `Ω` and a null-wave scale `k_σ` | **NEW_INPUT_REQUIRED** / **INDEPENDENT_DEGREES_OF_FREEDOM** | `Task02.no_canonical_cross_sector_relation`, `Task02.cross_sector_equality_not_invariant` |
| G2 | Which carrier (vector, ray, projective class) is "the" causal state | **REPRESENTATION_DEPENDENT** | Existence of the scale quotient does not make it preferred; the stabilizer answer differs (`Task02.boundary_symmetry_carrier_specific`) |
| G3 | A canonical affine scale on a null line | **NOT_YET_DERIVED** / **NEW_INPUT_REQUIRED** | Sharpened form of Task 01 F8: parameters exist, scale does not (`Task02.null_affine_no_canonical_scale`) |
| G4 | Selection of one standard vanishing rate by the endpoint data | **NOT_IDENTIFIABLE** | At least three distinct standard rates satisfy them (`Task02.endpoint_data_do_not_select`) |
| G5 | Physical meaning of the isotropy jump at the null ray | Out of scope | It is a quotient artefact of standard Lorentz geometry, present already in `SO⁺(1,1)` acting on `ℙ(ℝ^{1,1})` |
| G6 | Time orientation and sector labelling | **CONVENTION_DEPENDENT** | All cone statements presuppose `V⁰>0`; parity exchanges `σ = ±1` |

---

## I. Source ledger (Deliverable I)

### I.1 IMPORTED STANDARD RESULT

| Result | Source | What exactly is imported |
|---|---|---|
| Projectivization of a vector space over a division ring, and the criterion `mk K v hv = mk K w hw ↔ ∃ a : Kˣ, a • w = v` | Mathlib `Mathlib/LinearAlgebra/Projectivization/Basic.lean`: `Projectivization`, `Projectivization.mk`, `Projectivization.mk_eq_mk_iff` | the definition of the projective quotient and its equality criterion (used in `Task02.proj`, `Task02.proj_eq_proj_iff`) |
| Real hyperbolic functions: `cosh`, `sinh`, `tanh`, `artanh`, identities `cosh² − sinh² = 1`, `cosh ± sinh = e^{±x}`, `cosh` even, `|tanh| < 1`, `tanh` injective, `tanh (artanh x) = x`, `cosh x ≤ cosh y ↔ |x| ≤ |y|` | Mathlib `Mathlib/Analysis/SpecialFunctions/Trigonometric/DerivHyp.lean`, `…/Artanh.lean` (`Real.cosh_add_sinh`, `Real.cosh_sub_sinh`, `Real.abs_tanh_lt_one`, `Real.tanh_injective`, `Real.tanh_artanh`, `Real.cosh_le_cosh`) | the standard algebraic and order properties of the hyperbolic functions |
| Limits: `Tendsto.inv_tendsto_atTop`, `tendsto_neg_atBot_atTop`, `Real.tendsto_exp_atTop`, `Real.tendsto_exp_atBot`, interval and division limit lemmas | Mathlib `Mathlib/Order/Filter/…`, `Mathlib/Analysis/SpecialFunctions/Exp.lean` | the limit machinery used for the boundary and asymptotic statements |
| Derivative calculus: `HasDerivAt` algebra (`const_mul`, `add_const`, `prodMk`) | Mathlib `Mathlib/Analysis/Calculus/Deriv/…` | differentiation of the scalar phase and of affine null parametrizations |
| Finite cardinality of sets: `Set.ncard_singleton`, `Set.ncard_pair` | Mathlib `Mathlib/Data/Set/Card.lean` | the exact Model C solution counts |
| Everything in Task 01 | this repository, `RequestProject/Task01/` | conventions, boost, `dτ/dt = sech η`, wave covector law, null momentum, Model A/B/C theorems (imported, never modified) |
| Minkowski geometry of `ℝ^{1,1}`, `SO⁺(1,1)`, projective compactification of a causal cone | standard textbook material, e.g. B. O'Neill, *Semi-Riemannian Geometry* (Academic Press, 1983), ch. 5; R. Penrose & W. Rindler, *Spinors and Space-Time* I (CUP, 1984), ch. 1 | the classical statements that boosts act on the null directions by the reciprocal factors `e^{±θ}` and that the projectivized causal cone of `ℝ^{1,1}` is a closed interval — re-derived here in Lean rather than assumed |

### I.2 DERIVED IN TASK 02

Everything in `RequestProject/Task02/`, in particular: the ray/projective loss
statements (B), the interval characterization of the projectivized future causal
cone (C), the fractional-linear boost action with its group law, the five-carrier
orbit/stabilizer table with the null-orbit collapse (D), the scalar-phase rates
and the transformation table (E), the rescaling automorphism and the
independence theorem (F), and the three Task 01 precision repairs (G).
`Task02.tanh_add` is proved here because Mathlib has no `Real.tanh_add`.

---

## J. Build and axiom report (Deliverable J)

| Item | Value |
|---|---|
| Lean version | `leanprover/lean4:v4.28.0` (from `lean-toolchain`) |
| Mathlib revision | `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (manifest `inputRev` `v4.28.0`) |
| Task 02 source files | `RequestProject/Task02/{Carriers, ProjectiveCone, Orbits, ScalarPhase, Task01Audit}.lean` |
| Build result | `lake build` succeeds; all Task 02 modules build |
| `sorry` count | 0 |
| `admit` count | 0 |
| custom axiom count | 0 (no `axiom` declaration anywhere in the project) |

Axiom dependencies (checked with `#print axioms`): each of

`bijOn_causalRays`, `Fmap_Fmap`, `boundary_symmetry_carrier_specific`,
`orbVec_nullMomentum`, `null_orbit_collapses`,
`no_canonical_cross_sector_relation`, `cross_sector_equality_not_invariant`,
`hasDerivAt_scalarPhase_coordTime`, `projective_boundary_limits`,
`vanishing_rates_pairwise_distinct`, `modelCNullSolutions_ncard`,
`modelCNullSolutions_zero_ncard`, `null_affine_no_canonical_scale`,
`sech_eq_exp_iff`, `proj_eq_iff_RayPos_eq`

depends only on `[propext, Classical.choice, Quot.sound]`.

---

## K. Theorem-level classifications (Section 19)

| Result | Status | Establishing theorem |
|---|---|---|
| ray and projective quotients discard exactly the scale, resp. scale and sign | **DERIVED** | `RayPos_smul_eq_but_ne`, `proj_neg_eq`, `RayPos_neg_ne` |
| on the future cone, ray = projective | **DERIVED** | `proj_eq_iff_RayPos_eq` |
| projectivized future causal cone ≅ `[-1,1]`, interior timelike, endpoints null | **DERIVED**, **QUOTIENT_DEPENDENT** | `bijOn_causalRays`, `mem_FutureTimelike_iff`, `mem_FutureNull_iff` |
| boost acts by `F_θ`, with group law | **DERIVED** | `betaOf_boostV`, `Fmap_Fmap` |
| null boundary points individually fixed; interior a single simply transitive orbit | **DERIVED** | `Fmap_one`, `Fmap_neg_one`, `Fmap_transitive_Ioo` |
| null vector stabilizer trivial; null ray/projective stabilizer everything | **QUOTIENT_DEPENDENT** | `stabVec_nullMomentum`, `stabRay_nullMomentum`, `stabProj_nullMomentum` |
| timelike stabilizer unchanged by the quotient | **DERIVED** | `stabRay_fourVelocity`, `stabProj_fourVelocity` |
| boost orbit of a null vector = its whole positive ray | **DERIVED** | `orbVec_nullMomentum` |
| `[U(η)]` has projective limits `±1`; `U(η)` has none | **REPRESENTATION_DEPENDENT** | `projective_boundary_limits` |
| parity exchanges the two null directions; boosts do not | **DERIVED**, **CONVENTION_DEPENDENT** (orientation choices) | `null_directions_exchanged_by_parity`, `null_directions_invariant_under_boosts` |
| `dΘ/dτ = Ω`, `dΘ/dt = Ω sech η` | **DERIVED** | `hasDerivAt_scalarPhase_properTime`, `hasDerivAt_scalarPhase_coordTime` |
| `Ω` invariant, `Ω sech η` not | **DERIVED** | `Omega_invariant`, `rhoCoord_eq_iff` |
| no relation between `Ω` and `k_σ` | **INDEPENDENT_DEGREES_OF_FREEDOM**, **NEW_INPUT_REQUIRED** | `no_canonical_cross_sector_relation`, `cross_sector_equality_not_invariant` |
| `sech η ∈ {e^{+η}, e^{−η}}` only at `η = 0` | **DERIVED** | `sech_eq_exp_iff`, `sech_eq_exp_neg_iff` |
| endpoint data do not select a rate | **NOT_IDENTIFIABLE** | `endpoint_data_do_not_select`, `vanishing_rates_pairwise_distinct` |
| Model C solution count `1` (`r=0`) / `2` (`r≠0`) | **DERIVED**, **TASK01_STATEMENT_REQUIRES_NARROWING** (prose only) | `modelCNullSolutions_zero_ncard`, `modelCNullSolutions_ncard` |
| null arclength defined, zero, degenerate; affine scale not canonical | **DERIVED**, **TASK01_STATEMENT_REQUIRES_NARROWING** (prose only) | `null_arclength_defined_and_zero`, `null_arclength_not_injective`, `null_affine_no_canonical_scale` |
| boundary-symmetry sentence carrier-specific | **TASK01_STATEMENT_REQUIRES_NARROWING** | `boundary_symmetry_carrier_specific` |

---

## L. Answers to the acceptance questions (Section 21)

1. **Does quotienting a nonzero null vector by scale change its Lorentz
   stabilizer?**  Yes: `{0}` → `ℝ` (`stabVec_nullMomentum` vs
   `stabRay_nullMomentum`, `stabProj_nullMomentum`).  For a timelike vector it
   does not (`stabRay_fourVelocity`).
2. **Exact boost orbits.**  Null vector: its whole positive ray
   (`orbVec_nullMomentum`).  Positive null ray and projective null direction:
   a single point (`orbRay_nullMomentum`).
3. **Is the projective future causal cone an interval with timelike interior and
   null boundary?**  Yes (`bijOn_causalRays` with `mem_FutureTimelike_iff`,
   `mem_FutureNull_iff`).
4. **Do normalized timelike directions have projective limits?**  Yes, `±1`
   (`projective_boundary_limits`); the vectors themselves diverge.
5. **Are the projective null directions distinguished from timelike ones?**  Yes,
   by orbit type (fixed points vs a single transitive orbit) and by isotropy
   (`ℝ` vs `{0}`): `Fmap_one`, `Fmap_neg_one`, `Fmap_transitive_Ioo`,
   `timelike_dir_not_null_dir`.
6. **Which parts depend on the carrier?**  Exactly the stabilizer/orbit answers
   for the null sector, and the existence of a boundary limit; the cone
   characterization is a statement about rays by construction (sections B–D).
7. **Is `Ω` forced to determine or be determined by a null-wave scale?**  No
   (`no_canonical_cross_sector_relation`).
8. **Which relations among `Ω`, `Ω sech η`, `k_σ`, `ω_σ`, `e^{±η}` are derived?**
   Only those in table E: `ω_σ = σ c k_σ` (imposed dispersion), the weights
   `e^{σθ}`, and `Ω sech η = Ω · (dτ/dt)`.  Everything relating `Ω` to the null
   sector is **NEW_INPUT_REQUIRED**.
9. **Does the endpoint behaviour select one standard scalar function?**  No
   (`endpoint_data_do_not_select`).
10. **Which Task 01 summary claims need narrowing?**  The four in section G;
    all other Task 01 verdicts stand unchanged.

---

## M. Conservation-of-difficulty checks (Section 22)

* A vector theorem was never reused as a ray theorem: `stabRay_*` and
  `stabProj_*` are proved separately from `stabVec_*`.
* The existence of the scale quotient is not treated as a preferred carrier;
  every carrier-dependent answer is flagged (G2).
* Common limits (`R_τ`, closing speed, Doppler rate all `→ 0`; `sech η` and
  `e^{−η}` both `→ 0`) are explicitly shown **not** to imply equality
  (`vanishing_rates_pairwise_distinct`, `sech_eq_exp_neg_iff`).
* Factorization through the bijection `R_τ` is explicitly shown to be vacuous
  (`factorization_is_not_equality`).
* `Ω` was introduced with no relation to any Task 01 parameter and remains
  unrelated; no definition in Task 02 mixes the two branches (section F graph).
* No interaction law, equation of motion, conservation law, or new physical
  model appears anywhere in Task 02.
