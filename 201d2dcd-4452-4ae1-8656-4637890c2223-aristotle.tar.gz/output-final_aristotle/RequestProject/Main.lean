import Mathlib
import RequestProject.Task01.SplitComplex
import RequestProject.Task01.Boost
import RequestProject.Task01.ProperTime
import RequestProject.Task01.Phase
import RequestProject.Task01.Boundary
import RequestProject.Task02.Carriers
import RequestProject.Task02.ProjectiveCone
import RequestProject.Task02.Orbits
import RequestProject.Task02.ScalarPhase
import RequestProject.Task02.Task01Audit

open scoped BigOperators
open scoped Real
open scoped Nat
open scoped Classical
open scoped Pointwise

set_option maxHeartbeats 8000000
set_option maxRecDepth 4000
set_option synthInstance.maxHeartbeats 20000
set_option synthInstance.maxSize 128

set_option relaxedAutoImplicit false
set_option autoImplicit false

set_option pp.fullNames true
set_option pp.structureInstances true
set_option pp.coercions.types true
set_option pp.funBinderTypes true
set_option pp.letVarTypes true
set_option pp.piBinderTypes true

set_option grind.warning false
