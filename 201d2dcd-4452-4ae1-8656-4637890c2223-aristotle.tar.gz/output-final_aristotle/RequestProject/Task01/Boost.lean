import RequestProject.Task01.SplitComplex

set_option autoImplicit false
set_option relaxedAutoImplicit false

/-!
# Task 01 — Part 2: (1+1) Lorentz geometry, boosts and rapidity

Signature convention (fixed once and used throughout the whole development):

  `Q c (t, x) = c² t² - x²`   (mostly-minus, "timelike positive")

Null coordinates (fixed normalisation):

  `u = c t + x`,  `w = c t - x`,   so   `Q = u · w`.

(The task text writes the second null coordinate as `v`; here it is called `w`
to avoid any collision with the velocity `v`.)

## Main results

* `Q_eq_nullU_mul_nullW` — the Lorentz form factorises in null coordinates.
* `toSC_mul_sexp` / `boost_toSC` — a boost of rapidity `η` is exactly
  multiplication by the unit split-complex number `sexp η = cosh η + j sinh η`.
* `nullU_boost`, `nullW_boost` — the reciprocal scaling law
  `(u, w) ↦ (e^{+η} u, e^{-η} w)`.
* `sexp_mul_ePlus`, `sexp_mul_eMinus` — the two reciprocal factors are exactly
  the eigenvalues of the boost on the two idempotent (null) sectors `ℝ e₊`,
  `ℝ e₋`.
* `boost_classification` — *derivation* of the boost: any linear map of
  Minkowski space preserving the Lorentz form, with unit determinant, and
  preserving the future null direction, is a boost `(u,w) ↦ (e^η u, e^{-η} w)`.
* `exp_pair_ne_tanh_sech_pair` — the pair `(e^{+η}, e^{-η})` is **never** equal
  to the pair `(tanh θ, sech θ)`, for any `η, θ`; the two pairs are different
  functions of rapidity, related by the explicit maps `exp_mul_sech_*`,
  `tanh_eq_exp`, `sech_eq_exp`.  The first pair lies on the hyperbola `XY = 1`,
  the second on the circle `X² + Y² = 1`, and these are disjoint.
-/

namespace Task01

open Real

/-- An event of `ℝ^{1,1}`, written in an inertial coordinate chart as `(t, x)`. -/
abbrev Event := ℝ × ℝ

namespace Lorentz

/-- The Lorentz bilinear form, signature `(+,-)`: `⟨X,Y⟩ = c² t_X t_Y - x_X x_Y`. -/
def bil (c : ℝ) (X Y : Event) : ℝ := c ^ 2 * X.1 * Y.1 - X.2 * Y.2

/-- The Lorentz quadratic form `Q c (t,x) = c² t² - x²`. -/
def Q (c : ℝ) (X : Event) : ℝ := c ^ 2 * X.1 ^ 2 - X.2 ^ 2

theorem Q_eq_bil (c : ℝ) (X : Event) : Q c X = bil c X X := by
  simp [Q, bil]; ring

/-- Right-moving null coordinate `u = c t + x`. -/
def nullU (c : ℝ) (X : Event) : ℝ := c * X.1 + X.2

/-- Left-moving null coordinate `w = c t - x`.  (Called `v` in the task text.) -/
def nullW (c : ℝ) (X : Event) : ℝ := c * X.1 - X.2

/-- `c² t² - x² = (ct+x)(ct-x)`: the Lorentz form is the product of the null
coordinates. -/
theorem Q_eq_nullU_mul_nullW (c : ℝ) (X : Event) : Q c X = nullU c X * nullW c X := by
  simp [Q, nullU, nullW]; ring

/-- Null coordinates are a linear change of chart (invertible for `c ≠ 0`). -/
theorem event_of_null (c : ℝ) (hc : c ≠ 0) (X : Event) :
    X = ((nullU c X + nullW c X) / (2 * c), (nullU c X - nullW c X) / 2) := by
  refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> (simp only [nullU, nullW]; field_simp; try ring)

/-! ### Identification with the split-complex algebra -/

/-- The standard identification of `ℝ^{1,1}` with the split-complex numbers:
`(t, x) ↦ c t + j x`. -/
def toSC (c : ℝ) (X : Event) : SC := ⟨c * X.1, X.2⟩

/-- Under `toSC`, the split norm *is* the Lorentz quadratic form. -/
theorem N_toSC (c : ℝ) (X : Event) : SC.N (toSC c X) = Q c X := by
  simp [SC.N, toSC, Q]; ring

/-- Under `toSC`, the algebraic null coordinates are the geometric ones. -/
theorem toNull_toSC (c : ℝ) (X : Event) :
    SC.toNull (toSC c X) = (nullU c X, nullW c X) := by
  refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> simp [toSC, nullU, nullW]

/-- The unit hyperbolic exponential `sexp η = cosh η + j sinh η`. -/
noncomputable def sexp (η : ℝ) : SC := ⟨Real.cosh η, Real.sinh η⟩

@[simp] theorem N_sexp (η : ℝ) : SC.N (sexp η) = 1 := by
  simp [SC.N, sexp, Real.cosh_sq_sub_sinh_sq]

@[simp] theorem sexp_zero : sexp 0 = 1 := by
  ext <;> simp [sexp]

/-- One-parameter group law: rapidities add. -/
theorem sexp_add (η θ : ℝ) : sexp (η + θ) = sexp η * sexp θ := by
  ext <;> (simp [sexp, Real.cosh_add, Real.sinh_add]; try ring)

/-- In null coordinates the boost element is `(e^{+η}, e^{-η})`. -/
theorem toNull_sexp (η : ℝ) : SC.toNull (sexp η) = (Real.exp η, Real.exp (-η)) := by
  refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;>
    simp [sexp, Real.cosh_add_sinh, Real.cosh_sub_sinh]

/-- **Sector eigenvalue, `+` sector.**  The idempotent `e₊` (the right-moving
null sector) is an eigenvector of the boost with eigenvalue `e^{+η}`. -/
theorem sexp_mul_ePlus (η : ℝ) : sexp η * SC.ePlus = SC.ofReal (Real.exp η) * SC.ePlus := by
  have h : Real.cosh η + Real.sinh η = Real.exp η := Real.cosh_add_sinh η
  ext <;> simp [sexp, SC.ePlus, SC.ofReal] <;> linarith

/-- **Sector eigenvalue, `-` sector.**  The idempotent `e₋` (the left-moving
null sector) is an eigenvector of the boost with eigenvalue `e^{-η}`. -/
theorem sexp_mul_eMinus (η : ℝ) :
    sexp η * SC.eMinus = SC.ofReal (Real.exp (-η)) * SC.eMinus := by
  have h : Real.cosh η - Real.sinh η = Real.exp (-η) := Real.cosh_sub_sinh η
  ext <;> simp [sexp, SC.eMinus, SC.ofReal] <;> linarith

/-! ### Boosts in coordinates -/

/-- The proper orthochronous boost of rapidity `η`. -/
noncomputable def boost (c η : ℝ) (X : Event) : Event :=
  (Real.cosh η * X.1 + (Real.sinh η / c) * X.2, c * Real.sinh η * X.1 + Real.cosh η * X.2)

/-- A boost is multiplication by `sexp η` in the split-complex picture. -/
theorem boost_toSC (c : ℝ) (hc : c ≠ 0) (η : ℝ) (X : Event) :
    toSC c (boost c η X) = sexp η * toSC c X := by
  ext <;> (simp [toSC, boost, sexp]; field_simp; try ring)

@[simp] theorem boost_zero (c : ℝ) (X : Event) : boost c 0 X = X := by
  refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> simp [boost]

/-- Boosts preserve the Lorentz form. -/
theorem Q_boost (c : ℝ) (hc : c ≠ 0) (η : ℝ) (X : Event) : Q c (boost c η X) = Q c X := by
  rw [← N_toSC, ← N_toSC, boost_toSC c hc, SC.N_mul, N_sexp, one_mul]

/-- Boosts compose by adding rapidities. -/
theorem boost_boost (c : ℝ) (hc : c ≠ 0) (η θ : ℝ) (X : Event) :
    boost c η (boost c θ X) = boost c (η + θ) X := by
  refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;>
    simp [boost, Real.cosh_add, Real.sinh_add] <;> field_simp <;> ring

/-- Boosts have unit determinant (they are *proper*). -/
theorem boost_det (c : ℝ) (hc : c ≠ 0) (η : ℝ) :
    Real.cosh η * Real.cosh η - (Real.sinh η / c) * (c * Real.sinh η) = 1 := by
  have h : (Real.sinh η / c) * (c * Real.sinh η) = Real.sinh η ^ 2 := by field_simp
  rw [h]
  nlinarith [Real.cosh_sq_sub_sinh_sq η]

/-- **Reciprocal scaling law, `+` sector**: `u ↦ e^{+η} u`. -/
theorem nullU_boost (c : ℝ) (hc : c ≠ 0) (η : ℝ) (X : Event) :
    nullU c (boost c η X) = Real.exp η * nullU c X := by
  simp only [nullU, boost]
  rw [← Real.cosh_add_sinh]
  field_simp
  ring

/-- **Reciprocal scaling law, `-` sector**: `w ↦ e^{-η} w`. -/
theorem nullW_boost (c : ℝ) (hc : c ≠ 0) (η : ℝ) (X : Event) :
    nullW c (boost c η X) = Real.exp (-η) * nullW c X := by
  simp only [nullW, boost]
  rw [← Real.cosh_sub_sinh]
  field_simp
  ring

/-- The two scaling factors are reciprocal: the boost has unit determinant in
null coordinates as well. -/
theorem exp_mul_exp_neg (η : ℝ) : Real.exp η * Real.exp (-η) = 1 := by
  rw [← Real.exp_add]; simp

/-! ### Velocity, rapidity, `γ` and `sech` -/

/-- `sech η = 1 / cosh η`.  (Not part of Mathlib; defined here.) -/
noncomputable def sech (η : ℝ) : ℝ := 1 / Real.cosh η

theorem sech_pos (η : ℝ) : 0 < sech η := by
  simpa [sech] using Real.cosh_pos η

theorem sech_le_one (η : ℝ) : sech η ≤ 1 := by
  rw [sech, div_le_one (Real.cosh_pos η)]
  exact Real.one_le_cosh η

@[simp] theorem sech_zero : sech 0 = 1 := by simp [sech]

/-- The circle identity `tanh² + sech² = 1`. -/
theorem tanh_sq_add_sech_sq (η : ℝ) : Real.tanh η ^ 2 + sech η ^ 2 = 1 := by
  have h := Real.cosh_pos η
  rw [Real.tanh_eq_sinh_div_cosh, sech]
  field_simp
  nlinarith [Real.cosh_sq_sub_sinh_sq η]

/-- Coordinate velocity attached to a rapidity: `v = c tanh η`. -/
noncomputable def vel (c η : ℝ) : ℝ := c * Real.tanh η

/-- The Lorentz factor as a function of velocity. -/
noncomputable def gammaOfVel (c v : ℝ) : ℝ := 1 / Real.sqrt (1 - (v / c) ^ 2)

theorem abs_vel_lt (c : ℝ) (hc : 0 < c) (η : ℝ) : |vel c η| < c := by
  rw [vel, abs_mul, abs_of_pos hc]
  have h1 : |Real.tanh η| < 1 := abs_lt.mpr ⟨Real.neg_one_lt_tanh η, Real.tanh_lt_one η⟩
  nlinarith

/-- `β = tanh η`. -/
theorem vel_div (c : ℝ) (hc : c ≠ 0) (η : ℝ) : vel c η / c = Real.tanh η := by
  rw [vel, mul_comm, mul_div_assoc, div_self hc, mul_one]

/-- `γ = cosh η`: the Lorentz factor of the velocity `c tanh η` is `cosh η`. -/
theorem gammaOfVel_vel (c : ℝ) (hc : c ≠ 0) (η : ℝ) : gammaOfVel c (vel c η) = Real.cosh η := by
  rw [gammaOfVel, vel_div c hc]
  have h : 1 - Real.tanh η ^ 2 = sech η ^ 2 := by
    have := tanh_sq_add_sech_sq η; linarith
  rw [h, Real.sqrt_sq (le_of_lt (sech_pos η)), sech]
  field_simp

/-- Rapidity attached to a subluminal velocity. -/
noncomputable def rap (c v : ℝ) : ℝ := Real.artanh (v / c)

theorem vel_rap (c : ℝ) (hc : 0 < c) (v : ℝ) (hv : |v| < c) : vel c (rap c v) = v := by
  have hmem : v / c ∈ Set.Ioo (-1 : ℝ) 1 := by
    rw [abs_lt] at hv
    constructor
    · rw [lt_div_iff₀ hc]; linarith [hv.1]
    · rw [div_lt_one hc]; linarith [hv.2]
  rw [vel, rap, Real.tanh_artanh hmem]
  field_simp

theorem rap_vel (c : ℝ) (hc : c ≠ 0) (η : ℝ) : rap c (vel c η) = η := by
  rw [rap, vel_div c hc, Real.artanh_tanh]

/-- **Rapidity is additive**, equivalently the relativistic velocity addition
law holds; this is `tanh` addition. -/
theorem vel_add (c : ℝ) (hc : c ≠ 0) (η θ : ℝ) :
    vel c (η + θ) = (vel c η + vel c θ) / (1 + vel c η * vel c θ / c ^ 2) := by
  have hcη : Real.cosh η ≠ 0 := ne_of_gt (Real.cosh_pos η)
  have hcθ : Real.cosh θ ≠ 0 := ne_of_gt (Real.cosh_pos θ)
  have hsum : 0 < Real.cosh η * Real.cosh θ + Real.sinh η * Real.sinh θ := by
    have := Real.cosh_pos (η + θ); rwa [Real.cosh_add] at this
  have h1 : 1 + vel c η * vel c θ / c ^ 2 = 1 + Real.tanh η * Real.tanh θ := by
    rw [vel, vel]; field_simp
  have h2 : 1 + Real.tanh η * Real.tanh θ
      = (Real.cosh η * Real.cosh θ + Real.sinh η * Real.sinh θ)
          / (Real.cosh η * Real.cosh θ) := by
    rw [Real.tanh_eq_sinh_div_cosh, Real.tanh_eq_sinh_div_cosh]; field_simp
  rw [h1, h2, vel, vel, vel, Real.tanh_eq_sinh_div_cosh, Real.tanh_eq_sinh_div_cosh,
    Real.tanh_eq_sinh_div_cosh, Real.sinh_add, Real.cosh_add]
  field_simp

/-! ### `(e^{+η}, e^{-η})` versus `(tanh η, sech η)` -/

theorem exp_mul_sech (η : ℝ) : Real.exp η * sech η = 1 + Real.tanh η := by
  have h : Real.cosh η ≠ 0 := ne_of_gt (Real.cosh_pos η)
  rw [sech, Real.tanh_eq_sinh_div_cosh, ← Real.cosh_add_sinh]
  field_simp

theorem exp_neg_mul_sech (η : ℝ) : Real.exp (-η) * sech η = 1 - Real.tanh η := by
  have h : Real.cosh η ≠ 0 := ne_of_gt (Real.cosh_pos η)
  rw [sech, Real.tanh_eq_sinh_div_cosh, ← Real.cosh_sub_sinh]
  field_simp

theorem tanh_eq_exp (η : ℝ) :
    Real.tanh η = (Real.exp η - Real.exp (-η)) / (Real.exp η + Real.exp (-η)) := by
  have h2 : Real.exp η + Real.exp (-η) ≠ 0 := by positivity
  rw [Real.tanh_eq_sinh_div_cosh, Real.sinh_eq, Real.cosh_eq]
  field_simp

theorem sech_eq_exp (η : ℝ) : sech η = 2 / (Real.exp η + Real.exp (-η)) := by
  have h2 : Real.exp η + Real.exp (-η) ≠ 0 := by positivity
  rw [sech, Real.cosh_eq]
  field_simp

/-- The pair `(e^{+η}, e^{-η})` lies on the hyperbola `XY = 1`. -/
theorem exp_pair_hyperbola (η : ℝ) : Real.exp η * Real.exp (-η) = 1 := exp_mul_exp_neg η

/-- The pair `(tanh η, sech η)` lies on the unit circle `X² + Y² = 1`. -/
theorem tanh_sech_pair_circle (η : ℝ) : Real.tanh η ^ 2 + sech η ^ 2 = 1 :=
  tanh_sq_add_sech_sq η

/-- **The two pairs are never equal.**  `(e^{+η}, e^{-η})` and `(tanh θ, sech θ)`
are different functions of rapidity: the first parametrises the hyperbola
`XY = 1`, the second the unit circle `X² + Y² = 1`, and these are disjoint. -/
theorem exp_pair_ne_tanh_sech_pair (η θ : ℝ) :
    (Real.exp η, Real.exp (-η)) ≠ (Real.tanh θ, sech θ) := by
  intro h
  have h1 : Real.exp η = Real.tanh θ := congrArg Prod.fst h
  have h2 : Real.exp (-η) = sech θ := congrArg Prod.snd h
  have hhyp : Real.tanh θ * sech θ = 1 := by rw [← h1, ← h2]; exact exp_mul_exp_neg η
  have hcir : Real.tanh θ ^ 2 + sech θ ^ 2 = 1 := tanh_sq_add_sech_sq θ
  nlinarith [sq_nonneg (Real.tanh θ - sech θ)]

/-! ### Derivation of the boost from the Lorentz structure -/

/-- Determinant of a linear map written in null coordinates. -/
def nullDet (L : (ℝ × ℝ) →ₗ[ℝ] (ℝ × ℝ)) : ℝ :=
  (L (1, 0)).1 * (L (0, 1)).2 - (L (0, 1)).1 * (L (1, 0)).2

/-- Pure algebra behind the dichotomy below. -/
theorem quad_dichotomy {a b d e : ℝ} (h10 : a * b = 0) (h01 : d * e = 0)
    (h11 : (a + d) * (b + e) = 1) :
    (b = 0 ∧ d = 0 ∧ a * e = 1) ∨ (a = 0 ∧ e = 0 ∧ d * b = 1) := by
  rcases mul_eq_zero.1 h10 with ha | hb
  · right
    subst ha
    have hdb : d * b = 1 := by nlinarith
    have hd : d ≠ 0 := by rintro rfl; simp at hdb
    have he : e = 0 := by
      rcases mul_eq_zero.1 h01 with h | h
      · exact absurd h hd
      · exact h
    exact ⟨rfl, he, hdb⟩
  · left
    subst hb
    have hae : a * e = 1 := by nlinarith
    have he : e ≠ 0 := by rintro rfl; simp at hae
    have hd : d = 0 := by
      rcases mul_eq_zero.1 h01 with h | h
      · exact h
      · exact absurd h he
    exact ⟨rfl, hd, hae⟩

/-- A linear map preserving the Lorentz form `u·w` in null coordinates is either
diagonal `(λ u, λ⁻¹ w)` or antidiagonal `(λ w, λ⁻¹ u)`. -/
theorem null_isometry_dichotomy (L : (ℝ × ℝ) →ₗ[ℝ] (ℝ × ℝ))
    (hL : ∀ p : ℝ × ℝ, (L p).1 * (L p).2 = p.1 * p.2) :
    (∃ lam : ℝ, lam ≠ 0 ∧ ∀ p : ℝ × ℝ, L p = (lam * p.1, lam⁻¹ * p.2)) ∨
    (∃ lam : ℝ, lam ≠ 0 ∧ ∀ p : ℝ × ℝ, L p = (lam * p.2, lam⁻¹ * p.1)) := by
  have hsplit : ∀ p : ℝ × ℝ, L p = (p.1 * (L (1,0)).1 + p.2 * (L (0,1)).1,
      p.1 * (L (1,0)).2 + p.2 * (L (0,1)).2) := by
    intro p
    have hp : p = p.1 • ((1, 0) : ℝ × ℝ) + p.2 • ((0, 1) : ℝ × ℝ) := by
      refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> simp
    rw [hp, map_add, map_smul, map_smul]
    refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> simp
  have h10 : (L (1,0)).1 * (L (1,0)).2 = 0 := by simpa using hL (1, 0)
  have h01 : (L (0,1)).1 * (L (0,1)).2 = 0 := by simpa using hL (0, 1)
  have h11 : ((L (1,0)).1 + (L (0,1)).1) * ((L (1,0)).2 + (L (0,1)).2) = 1 := by
    have h := hL (1, 1)
    rw [hsplit (1,1)] at h
    simpa using h
  rcases quad_dichotomy h10 h01 h11 with ⟨hb, hd, hae⟩ | ⟨ha, he, hdb⟩
  · left
    have ha : (L (1,0)).1 ≠ 0 := by rintro h; rw [h] at hae; simp at hae
    refine ⟨(L (1,0)).1, ha, fun p => ?_⟩
    have hinv : (L (0,1)).2 = ((L (1,0)).1)⁻¹ := by
      field_simp
      linarith [hae]
    rw [hsplit p, hb, hd, hinv]
    refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> simp <;> ring
  · right
    have hd : (L (0,1)).1 ≠ 0 := by rintro h; rw [h] at hdb; simp at hdb
    refine ⟨(L (0,1)).1, hd, fun p => ?_⟩
    have hinv : (L (1,0)).2 = ((L (0,1)).1)⁻¹ := by
      field_simp
      linarith [hdb]
    rw [hsplit p, ha, he, hinv]
    refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> simp <;> ring

/-- **Derivation of the proper orthochronous boost.**  In null coordinates, a
linear map that (i) preserves the Lorentz form, (ii) is proper (`det = 1`) and
(iii) is orthochronous (preserves the sign of the future null coordinate `u`)
is exactly `(u, w) ↦ (e^{η} u, e^{-η} w)` for some rapidity `η`. -/
theorem boost_classification (L : (ℝ × ℝ) →ₗ[ℝ] (ℝ × ℝ))
    (hL : ∀ p : ℝ × ℝ, (L p).1 * (L p).2 = p.1 * p.2)
    (hdet : nullDet L = 1) (horth : 0 < (L (1, 1)).1) :
    ∃ η : ℝ, ∀ p : ℝ × ℝ, L p = (Real.exp η * p.1, Real.exp (-η) * p.2) := by
  rcases null_isometry_dichotomy L hL with ⟨lam, hlam, hdiag⟩ | ⟨lam, hlam, hanti⟩
  · have hpos : 0 < lam := by
      have h := horth
      rw [hdiag (1, 1)] at h
      simpa using h
    refine ⟨Real.log lam, fun p => ?_⟩
    rw [hdiag p, Real.exp_log hpos, Real.exp_neg, Real.exp_log hpos]
  · exfalso
    have h1 : (L (1, 0)) = (0, lam⁻¹) := by
      rw [hanti (1, 0)]
      refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> simp
    have h2 : (L (0, 1)) = (lam, 0) := by
      rw [hanti (0, 1)]
      refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> simp
    rw [nullDet, h1, h2] at hdet
    have h3 : (0 : ℝ) * 0 - lam * lam⁻¹ = 1 := hdet
    rw [mul_inv_cancel₀ hlam] at h3
    norm_num at h3

end Lorentz

end Task01
