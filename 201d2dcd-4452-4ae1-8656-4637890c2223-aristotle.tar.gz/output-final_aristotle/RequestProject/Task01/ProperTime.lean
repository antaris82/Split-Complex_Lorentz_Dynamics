import RequestProject.Task01.Boost

set_option autoImplicit false
set_option relaxedAutoImplicit false

/-!
# Task 01 — Part 3: the massive timelike sector, proper time, and vanishing rates

For a timelike worldline `t ↦ (t, X t)` with `|X'| < c` the proper time is the
standard Lorentz arclength

  `τ(t) = ∫₀ᵗ √(1 - (X'(s)/c)²) ds`,

so that `dτ/dt = √(1 - β²) = sech η`.  Nothing else is assumed: `τ` is *defined*
as the Lorentz arclength and the rate formula is *derived* from the fundamental
theorem of calculus (`hasDerivAt_properTime`).

The quantity of the task is

  `R_τ(v) = c dτ/dt = c sech η`,

and the results here establish, in order:

* `Rtau_zero`, `tendsto_Rtau` : `R_τ(0) = c` and `R_τ(v) → 0` as `v → c⁻`;
* `vel_sq_add_Rtau_sq` : `v² + R_τ(v)² = c²` (a Euclidean identity between a
  coordinate velocity and a proper-time rate expressed in velocity units — it is
  *not* a statement about two spatial velocities);
* `Rtau_bijOn` and `exists_factor_through_Rtau` : `R_τ` is a strictly decreasing
  bijection `[0,c) → (0,c]`, hence **every** function of the speed alone
  factors uniquely through `R_τ`.  Consequently no quantity depending only on
  the speed — in particular no candidate rate satisfying `R(0)=c`,
  `R(v) → 0` — can be an independent degree of freedom: it is always an
  algebraic/functional expression in `dτ/dt`.
* `closingSpeed` and `dopplerRate` are worked examples of that phenomenon.

Interpreting `R_τ` (or any of the other rates) as a *transport velocity* of
something is not a consequence of these structures; that would be extra
input (NEW_INPUT_REQUIRED in the audit register).
-/

namespace Task01

open Real Filter Topology

namespace Kinematics

open Lorentz

/-! ### Proper time along a timelike worldline -/

/-- The proper-time rate `dτ/dt = √(1 - β²)`. -/
noncomputable def properTimeRate (c v : ℝ) : ℝ := Real.sqrt (1 - (v / c) ^ 2)

/-- Proper time along the worldline `t ↦ (t, X t)`, defined as Lorentz arclength. -/
noncomputable def properTime (c : ℝ) (X : ℝ → ℝ) (t : ℝ) : ℝ :=
  ∫ s in (0 : ℝ)..t, properTimeRate c (deriv X s)

/-- **Derivation of `dτ = dt √(1 - v²/c²)`.**  If the coordinate velocity
`v = X'` is continuous, then the proper time defined as Lorentz arclength has
derivative `√(1 - (v/c)²)` with respect to coordinate time. -/
theorem hasDerivAt_properTime (c : ℝ) (X : ℝ → ℝ) (hX : Continuous (deriv X)) (t : ℝ) :
    HasDerivAt (properTime c X) (properTimeRate c (deriv X t)) t := by
  have hf : Continuous fun s => properTimeRate c (deriv X s) := by
    unfold properTimeRate
    fun_prop
  exact intervalIntegral.integral_hasDerivAt_right (hf.intervalIntegrable _ _)
    (hf.stronglyMeasurableAtFilter _ _) hf.continuousAt

/-- `dτ/dt = sech η` when `v = c tanh η`. -/
theorem properTimeRate_vel (c : ℝ) (hc : c ≠ 0) (η : ℝ) :
    properTimeRate c (vel c η) = sech η := by
  rw [properTimeRate, vel_div c hc]
  have h : 1 - Real.tanh η ^ 2 = sech η ^ 2 := by
    have := tanh_sq_add_sech_sq η; linarith
  rw [h, Real.sqrt_sq (le_of_lt (sech_pos η))]

/-! ### The vanishing rate `R_τ` -/

/-- `R_τ(v) = c dτ/dt`, the proper-time rate expressed in velocity units. -/
noncomputable def Rtau (c v : ℝ) : ℝ := c * properTimeRate c v

theorem Rtau_eq_sqrt (c : ℝ) (hc : 0 < c) (v : ℝ) : Rtau c v = Real.sqrt (c ^ 2 - v ^ 2) := by
  have h : c ^ 2 - v ^ 2 = c ^ 2 * (1 - (v / c) ^ 2) := by
    field_simp
  rw [Rtau, properTimeRate, h, Real.sqrt_mul (by positivity), Real.sqrt_sq hc.le]

@[simp] theorem Rtau_zero (c : ℝ) (hc : 0 < c) : Rtau c 0 = c := by
  rw [Rtau_eq_sqrt c hc]
  simp [Real.sqrt_sq hc.le]

/-- `R_τ(v) → 0` as `v → c⁻`. -/
theorem tendsto_Rtau (c : ℝ) (hc : 0 < c) :
    Tendsto (Rtau c) (𝓝[<] c) (𝓝 0) := by
  have hcont : Continuous fun v : ℝ => Real.sqrt (c ^ 2 - v ^ 2) := by fun_prop
  have h0 : Real.sqrt (c ^ 2 - c ^ 2) = 0 := by simp
  have := (hcont.tendsto c).mono_left (nhdsWithin_le_nhds (s := Set.Iio c))
  rw [h0] at this
  refine this.congr fun v => ?_
  exact (Rtau_eq_sqrt c hc v).symm

/-- **The Euclidean identity** `v² + R_τ(v)² = c²`, valid for `|v| ≤ c`. -/
theorem vel_sq_add_Rtau_sq (c : ℝ) (hc : 0 < c) (v : ℝ) (hv : |v| ≤ c) :
    v ^ 2 + Rtau c v ^ 2 = c ^ 2 := by
  rw [Rtau_eq_sqrt c hc, Real.sq_sqrt]
  · ring
  · nlinarith [abs_nonneg v, sq_abs v, abs_le.mp hv]

/-- `R_τ = c sech η`. -/
theorem Rtau_vel (c : ℝ) (hc : c ≠ 0) (η : ℝ) : Rtau c (vel c η) = c * sech η := by
  rw [Rtau, properTimeRate_vel c hc]

/-! ### `R_τ` is a bijection `[0,c) → (0,c]` -/

theorem Rtau_pos (c : ℝ) (hc : 0 < c) {v : ℝ} (hv : |v| < c) : 0 < Rtau c v := by
  rw [Rtau_eq_sqrt c hc]
  apply Real.sqrt_pos.mpr
  nlinarith [abs_lt.mp hv, sq_abs v, abs_nonneg v]

theorem Rtau_le (c : ℝ) (hc : 0 < c) (v : ℝ) : Rtau c v ≤ c := by
  rw [Rtau_eq_sqrt c hc]
  calc Real.sqrt (c ^ 2 - v ^ 2) ≤ Real.sqrt (c ^ 2) := by
        apply Real.sqrt_le_sqrt; nlinarith [sq_nonneg v]
    _ = c := Real.sqrt_sq hc.le

theorem Rtau_strictAntiOn (c : ℝ) (hc : 0 < c) :
    StrictAntiOn (Rtau c) (Set.Icc 0 c) := by
  intro a ha b hb hab
  rw [Rtau_eq_sqrt c hc, Rtau_eq_sqrt c hc]
  apply Real.sqrt_lt_sqrt
  · nlinarith [hb.2, hb.1]
  · nlinarith [ha.1]

/-- `R_τ` is a bijection from the speed range `[0,c)` onto the rate range `(0,c]`. -/
theorem Rtau_bijOn (c : ℝ) (hc : 0 < c) :
    Set.BijOn (Rtau c) (Set.Ico 0 c) (Set.Ioc 0 c) := by
  refine ⟨?_, ?_, ?_⟩
  · intro v hv
    exact ⟨Rtau_pos c hc (by rw [abs_of_nonneg hv.1]; exact hv.2), Rtau_le c hc v⟩
  · intro a ha b hb hab
    have hsub : Set.Ico (0:ℝ) c ⊆ Set.Icc 0 c := fun x hx => ⟨hx.1, hx.2.le⟩
    exact (Rtau_strictAntiOn c hc).injOn (hsub ha) (hsub hb) hab
  · intro r hr
    refine ⟨Real.sqrt (c ^ 2 - r ^ 2), ⟨Real.sqrt_nonneg _, ?_⟩, ?_⟩
    · rw [Real.sqrt_lt' hc]
      nlinarith [hr.1]
    · rw [Rtau_eq_sqrt c hc, Real.sq_sqrt (by nlinarith [hr.1, hr.2]), sub_sub_cancel,
        Real.sqrt_sq hr.1.le]

/-- **No new degree of freedom.**  Every function of the speed alone factors
through the proper-time rate `R_τ` on `[0, c)`. -/
theorem exists_factor_through_Rtau (c : ℝ) (hc : 0 < c) (R : ℝ → ℝ) :
    ∃ f : ℝ → ℝ, ∀ v ∈ Set.Ico (0 : ℝ) c, R v = f (Rtau c v) := by
  refine ⟨fun r => R (Function.invFunOn (Rtau c) (Set.Ico 0 c) r), fun v hv => ?_⟩
  have hinj := (Rtau_bijOn c hc).injOn
  exact congrArg R (hinj.leftInvOn_invFunOn hv).symm

/-- ... and the factorising function is unique on the rate range `(0, c]`. -/
theorem factor_through_Rtau_unique (c : ℝ) (hc : 0 < c) (f g : ℝ → ℝ)
    (h : ∀ v ∈ Set.Ico (0 : ℝ) c, f (Rtau c v) = g (Rtau c v)) :
    ∀ r ∈ Set.Ioc (0 : ℝ) c, f r = g r := by
  intro r hr
  obtain ⟨v, hv, rfl⟩ := (Rtau_bijOn c hc).surjOn hr
  exact h v hv

/-! ### Two further "natural" vanishing rates, and their dependence on `R_τ` -/

/-- The closing speed `c - |v|`.  Coordinate/frame dependent. -/
def closingSpeed (c v : ℝ) : ℝ := c - |v|

theorem closingSpeed_zero (c : ℝ) : closingSpeed c 0 = c := by simp [closingSpeed]

theorem tendsto_closingSpeed (c : ℝ) (hc : 0 < c) :
    Tendsto (closingSpeed c) (𝓝[<] c) (𝓝 0) := by
  have hcont : Continuous (closingSpeed c) := by unfold closingSpeed; fun_prop
  have := (hcont.tendsto c).mono_left (nhdsWithin_le_nhds (s := Set.Iio c))
  simpa [closingSpeed, abs_of_pos hc] using this

/-- The closing speed is an algebraic function of the proper-time rate. -/
theorem closingSpeed_eq_of_Rtau (c : ℝ) (hc : 0 < c) (v : ℝ) (hv : v ∈ Set.Ico (0:ℝ) c) :
    closingSpeed c v = c - Real.sqrt (c ^ 2 - Rtau c v ^ 2) := by
  rw [Rtau_eq_sqrt c hc, Real.sq_sqrt (by nlinarith [hv.1, hv.2]), sub_sub_cancel,
    Real.sqrt_sq hv.1, closingSpeed, abs_of_nonneg hv.1]

/-- The relativistic Doppler rate `c √((c-v)/(c+v)) = c e^{-η}`. -/
noncomputable def dopplerRate (c v : ℝ) : ℝ := c * Real.sqrt ((c - v) / (c + v))

theorem dopplerRate_zero (c : ℝ) (hc : 0 < c) : dopplerRate c 0 = c := by
  simp [dopplerRate, div_self (ne_of_gt hc)]

theorem tendsto_dopplerRate (c : ℝ) (hc : 0 < c) :
    Tendsto (dopplerRate c) (𝓝[<] c) (𝓝 0) := by
  have hcont : ContinuousAt (dopplerRate c) c := by
    unfold dopplerRate
    have : ContinuousAt (fun v : ℝ => (c - v) / (c + v)) c := by
      apply ContinuousAt.div (by fun_prop) (by fun_prop)
      positivity
    exact (continuousAt_const.mul (Real.continuous_sqrt.continuousAt.comp this))
  have h0 : dopplerRate c c = 0 := by simp [dopplerRate]
  have := hcont.tendsto.mono_left (nhdsWithin_le_nhds (s := Set.Iio c))
  rwa [h0] at this

/-- The Doppler rate is `c e^{-η}`: it is the `-`-sector null scaling factor. -/
theorem dopplerRate_vel (c : ℝ) (hc : 0 < c) (η : ℝ) :
    dopplerRate c (vel c η) = c * Real.exp (-η) := by
  have hcosh : Real.cosh η ≠ 0 := ne_of_gt (Real.cosh_pos η)
  have hexp : Real.exp η ≠ 0 := (Real.exp_pos η).ne'
  have h1 : c - vel c η = c * Real.exp (-η) / Real.cosh η := by
    rw [vel, Real.tanh_eq_sinh_div_cosh, ← Real.cosh_sub_sinh]; field_simp
  have h2 : c + vel c η = c * Real.exp η / Real.cosh η := by
    rw [vel, Real.tanh_eq_sinh_div_cosh, ← Real.cosh_add_sinh]; field_simp
  have hkey : (c - vel c η) / (c + vel c η) = Real.exp (-η) ^ 2 := by
    rw [h1, h2, Real.exp_neg]
    field_simp
  rw [dopplerRate, hkey, Real.sqrt_sq (Real.exp_pos _).le]

/-- The Doppler rate is an algebraic function of the proper-time rate and the
speed, hence (by `exists_factor_through_Rtau`) of the proper-time rate alone on
`[0,c)`:  `c e^{-η} = c (c - v)/R_τ(v)`. -/
theorem dopplerRate_eq_of_Rtau (c : ℝ) (hc : 0 < c) (v : ℝ) (hv : v ∈ Set.Ico (0:ℝ) c) :
    dopplerRate c v = c * (c - v) / Rtau c v := by
  have hcv : (0:ℝ) < c + v := by linarith [hv.1]
  have hcv' : (0:ℝ) < c - v := by linarith [hv.2]
  have hs1 : 0 < Real.sqrt (c - v) := Real.sqrt_pos.mpr hcv'
  have hs2 : 0 < Real.sqrt (c + v) := Real.sqrt_pos.mpr hcv
  have hR : Rtau c v = Real.sqrt (c - v) * Real.sqrt (c + v) := by
    rw [Rtau_eq_sqrt c hc, show c ^ 2 - v ^ 2 = (c - v) * (c + v) by ring,
      Real.sqrt_mul hcv'.le]
  have hd : Real.sqrt ((c - v) / (c + v)) = Real.sqrt (c - v) / Real.sqrt (c + v) :=
    Real.sqrt_div hcv'.le _
  have hsq : Real.sqrt (c - v) * Real.sqrt (c - v) = c - v := Real.mul_self_sqrt hcv'.le
  rw [dopplerRate, hd, hR, eq_div_iff (by positivity)]
  field_simp
  nlinarith [hsq, hs1, hs2]

end Kinematics

end Task01
