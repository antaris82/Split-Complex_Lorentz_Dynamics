import RequestProject.Task01.ProperTime

set_option autoImplicit false
set_option relaxedAutoImplicit false

/-!
# Task 01 — Parts 4–7: phases, identifiability, models A/B/C, null dispersion

## Conventions

A plane phase is `φ(t,x) = k x - ω t`; `k` and `ω` are **a priori independent**
real parameters (no dispersion relation is assumed until it is imposed
explicitly).  The two counter-propagating sectors are distinguished by a sign
`σ = ±1`; the *null* (light-like) condition for a sector is `ω = σ c k`, and the
sign-free form of it is `ω² = c² k²`.  With the phase convention above, a mode
with `ω = +c k` has phase velocity `ω/k = +c` (right-moving, constant on
`w = ct - x`), and a mode with `ω = -c k` has phase velocity `-c` (left-moving,
constant on `u = ct + x`).

## Main results

* `phase_boost_invariant`, `waveCovector_unique` — the Lorentz transformation
  law of `(ω, k)` is *derived* from invariance of the phase under a boost, and
  it is the unique such law.
* `nullComp_u_boost`, `nullComp_w_boost` — in null components the wave covector
  scales by `e^{∓η}`, reciprocally to the coordinates.
* `hasDerivAt_phaseAlong` — `dφ/dt = k v - ω` along a trajectory `x = X(t)`.
* `phaseRate_properTime` — `dφ/dτ = γ (k v - ω)`.
* `obs_fibre`, `obs_not_injective` — **non-identifiability**: from
  trajectory-local phase rates at a single velocity, only the combination
  `k v - ω` is determined; the fibre of the parameter-to-observable map is a
  one-dimensional affine line.
* `two_velocities_identify` — the minimal additional observable which removes
  the degeneracy (a second trajectory with a different velocity).
* `nullDispersion_identifies` — imposing null dispersion *plus* a known sector
  sign also removes it, leaving no freedom at all.
* `modelB_matches_modelA` versus `modelB_null_const` — Models A and B are
  trajectory-locally indistinguishable, but a Model-B family with genuinely
  varying `ω` and fixed `k ≠ 0` is *not* a null structure: null dispersion plus
  continuity forces `ω` to be constant.
* `null_phase_speed` — a standard null mode has `|ω/k| = c` exactly.
-/

namespace Task01

open Real Filter Topology

namespace Phase

open Lorentz Kinematics

/-! ### Phases and the derivation of the covector transformation law -/

/-- The plane phase `φ(t,x) = k x - ω t`. -/
def phase (k ω : ℝ) (X : Event) : ℝ := k * X.2 - ω * X.1

/-- The boosted wave parameters, *derived* below from phase invariance:
`ω' = ω cosh η + c k sinh η`, `k' = k cosh η + (ω/c) sinh η`. -/
noncomputable def waveBoost (c η : ℝ) (K : ℝ × ℝ) : ℝ × ℝ :=
  (K.1 * Real.cosh η + c * K.2 * Real.sinh η, K.2 * Real.cosh η + (K.1 / c) * Real.sinh η)

/-- **Derivation of the wave-covector transformation law.**  The phase is a
scalar: with `K = (ω, k)` transformed by `waveBoost`, the phase of the boosted
event equals the original phase. -/
theorem phase_boost_invariant (c : ℝ) (hc : c ≠ 0) (η : ℝ) (ω k : ℝ) (X : Event) :
    phase (waveBoost c η (ω, k)).2 (waveBoost c η (ω, k)).1 (boost c η X)
      = phase k ω X := by
  have h : Real.cosh η ^ 2 - Real.sinh η ^ 2 = 1 := Real.cosh_sq_sub_sinh_sq η
  simp only [phase, waveBoost, boost]
  field_simp
  linear_combination (k * c * X.2 - c * ω * X.1) * h

/-- ... and it is the **unique** transformation law with that property: a pair
`(ω', k')` making the phase invariant is `waveBoost c η (ω, k)`. -/
theorem waveCovector_unique (c : ℝ) (hc : c ≠ 0) (η : ℝ) (ω k ω' k' : ℝ)
    (h : ∀ X : Event, phase k' ω' (boost c η X) = phase k ω X) :
    (ω', k') = waveBoost c η (ω, k) := by
  have hcs : Real.cosh η ^ 2 - Real.sinh η ^ 2 = 1 := Real.cosh_sq_sub_sinh_sq η
  have ht := h (1, 0)
  have hx := h (0, 1)
  simp only [phase, boost] at ht hx
  refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> simp only [waveBoost]
  · linear_combination (norm := (field_simp; ring))
      (-Real.cosh η) * ht + (c * Real.sinh η) * hx - ω' * hcs
  · linear_combination (norm := (field_simp; ring))
      (-(Real.sinh η) / c) * ht + Real.cosh η * hx - k' * hcs

/-! ### Null components of the wave covector -/

/-- The `u`-component of the wave covector: `φ = k_u u + k_w w`. -/
noncomputable def nullCompU (c ω k : ℝ) : ℝ := (k - ω / c) / 2

/-- The `w`-component of the wave covector. -/
noncomputable def nullCompW (c ω k : ℝ) : ℝ := -((k + ω / c) / 2)

/-- The phase in null coordinates. -/
theorem phase_eq_null (c : ℝ) (hc : c ≠ 0) (ω k : ℝ) (X : Event) :
    phase k ω X = nullCompU c ω k * nullU c X + nullCompW c ω k * nullW c X := by
  simp only [phase, nullCompU, nullCompW, nullU, nullW]
  field_simp
  ring

/-- The `u`-component scales by `e^{-η}` (reciprocally to `u`). -/
theorem nullCompU_boost (c : ℝ) (hc : c ≠ 0) (η ω k : ℝ) :
    nullCompU c (waveBoost c η (ω, k)).1 (waveBoost c η (ω, k)).2
      = Real.exp (-η) * nullCompU c ω k := by
  simp only [nullCompU, waveBoost, ← Real.cosh_sub_sinh]
  field_simp
  ring

/-- The `w`-component scales by `e^{+η}` (reciprocally to `w`). -/
theorem nullCompW_boost (c : ℝ) (hc : c ≠ 0) (η ω k : ℝ) :
    nullCompW c (waveBoost c η (ω, k)).1 (waveBoost c η (ω, k)).2
      = Real.exp η * nullCompW c ω k := by
  simp only [nullCompW, waveBoost, ← Real.cosh_add_sinh]
  field_simp
  ring

/-! ### Trajectory-local phase rates -/

/-- **`dφ/dt = k v - ω`** along a trajectory `x = X(t)`. -/
theorem hasDerivAt_phaseAlong (k ω : ℝ) (X : ℝ → ℝ) (v t : ℝ) (hX : HasDerivAt X v t) :
    HasDerivAt (fun s => phase k ω (s, X s)) (k * v - ω) t := by
  have h1 : HasDerivAt (fun s => k * X s) (k * v) t := hX.const_mul k
  have h2 : HasDerivAt (fun s : ℝ => ω * s) ω t := by
    simpa using (hasDerivAt_id t).const_mul ω
  simpa [phase] using h1.sub h2

/-- **`dφ/dτ = γ (k v - ω)`**: the proper-time phase rate is the coordinate
phase rate divided by `dτ/dt = sech η`. -/
theorem phaseRate_properTime (c : ℝ) (hc : c ≠ 0) (k ω η : ℝ) :
    (k * vel c η - ω) / properTimeRate c (vel c η)
      = (k * vel c η - ω) * Real.cosh η := by
  rw [properTimeRate_vel c hc, sech]
  field_simp

/-! ### The parameter-to-observable map and its fibres -/

/-- The trajectory-local observable at coordinate velocity `v`: `Θ_v(k,ω) = k v - ω`. -/
def obs (v k ω : ℝ) : ℝ := k * v - ω

/-- **The fibre of the observable map.**  Two parameter pairs give the same
trajectory-local phase rate iff they differ along the line `ω' - ω = v (k' - k)`. -/
theorem obs_fibre (v k ω k' ω' : ℝ) : obs v k ω = obs v k' ω' ↔ ω' - ω = v * (k' - k) := by
  simp only [obs]
  constructor <;> intro h <;> linarith

/-- **Non-identifiability.**  For every parameter pair and every alternative
wave number there is a frequency reproducing the same trajectory-local phase
rate; in particular `k` and `ω` are not separately determined. -/
theorem obs_not_injective (v k ω k' : ℝ) : obs v k ω = obs v k' (ω + v * (k' - k)) := by
  simp only [obs]; ring

/-- The fibre is exactly a one-dimensional affine line in the `(k, ω)` plane. -/
theorem obs_fibre_eq_line (v r : ℝ) :
    {p : ℝ × ℝ | obs v p.1 p.2 = r} = {p : ℝ × ℝ | ∃ s : ℝ, p = (s, s * v - r)} := by
  ext p
  simp only [Set.mem_setOf_eq, obs]
  constructor
  · intro h
    exact ⟨p.1, by refine Prod.ext_iff.mpr ⟨rfl, ?_⟩; linarith⟩
  · rintro ⟨s, rfl⟩
    simp

/-- Knowing the proper-time phase rate as well adds nothing: it is `γ` times the
coordinate phase rate and `γ` is fixed by `v` alone. -/
theorem properRate_no_extra_info (c : ℝ) (η k ω k' ω' : ℝ)
    (h : obs (vel c η) k ω = obs (vel c η) k' ω') :
    (k * vel c η - ω) * Real.cosh η = (k' * vel c η - ω') * Real.cosh η := by
  simp only [obs] at h
  rw [h]

/-- **The minimal additional observable.**  Phase rates on two trajectories with
*different* velocities determine `k` and `ω` separately. -/
theorem two_velocities_identify {v₁ v₂ k ω k' ω' : ℝ} (hv : v₁ ≠ v₂)
    (h1 : obs v₁ k ω = obs v₁ k' ω') (h2 : obs v₂ k ω = obs v₂ k' ω') :
    k = k' ∧ ω = ω' := by
  simp only [obs] at h1 h2
  have hk : (k - k') * (v₁ - v₂) = 0 := by nlinarith [h1, h2]
  have hk' : k = k' := by
    rcases mul_eq_zero.1 hk with h | h
    · linarith
    · exact absurd (by linarith : v₁ = v₂) hv
  refine ⟨hk', ?_⟩
  rw [hk'] at h1
  linarith

/-! ### Null dispersion -/

/-- The standard null (light-like) dispersion relation. -/
def NullDispersion (c ω k : ℝ) : Prop := ω ^ 2 = c ^ 2 * k ^ 2

/-- Null dispersion is equivalent to a choice of sector sign. -/
theorem nullDispersion_iff (c ω k : ℝ) : NullDispersion c ω k ↔ ω = c * k ∨ ω = -(c * k) := by
  unfold NullDispersion
  constructor
  · intro h
    have : (ω - c * k) * (ω + c * k) = 0 := by nlinarith
    rcases mul_eq_zero.1 this with h' | h'
    · exact Or.inl (by linarith)
    · exact Or.inr (by linarith)
  · rintro (rfl | rfl) <;> ring

/-- **A standard null mode propagates at exactly `c`.**  If `ω² = c²k²` and
`k ≠ 0` then the phase velocity satisfies `|ω/k| = c`. -/
theorem null_phase_speed (c ω k : ℝ) (h : NullDispersion c ω k) (hk : k ≠ 0) :
    |ω / k| = |c| := by
  rw [NullDispersion] at h
  have h2 : (ω / k) ^ 2 = c ^ 2 := by
    field_simp
    linarith
  calc |ω / k| = Real.sqrt ((ω / k) ^ 2) := (Real.sqrt_sq_eq_abs _).symm
    _ = Real.sqrt (c ^ 2) := by rw [h2]
    _ = |c| := Real.sqrt_sq_eq_abs c

/-- The group velocity of a null branch `ω = σ c k` is also `σ c`: on a null
branch phase velocity and group velocity coincide. -/
theorem null_group_velocity (c σ k : ℝ) :
    HasDerivAt (fun q : ℝ => σ * c * q) (σ * c) k := by
  simpa using (hasDerivAt_id k).const_mul (σ * c)

/-! ### Model A: null dispersion, variable wave number -/

/-- **Model A is rigid.**  Once the sector sign `σ` and the trajectory-local
observable `r` are fixed, the wave number is uniquely determined (`|v| < c`
guarantees `v - σ c ≠ 0`), and then so is `ω`. -/
theorem modelA_unique (c v r σ : ℝ) (hv : |v| < c) (hσ : σ = 1 ∨ σ = -1)
    (k ω : ℝ) (hnull : ω = σ * c * k) (hobs : obs v k ω = r) :
    k = r / (v - σ * c) ∧ ω = σ * c * (r / (v - σ * c)) := by
  have hne : v - σ * c ≠ 0 := by
    rcases hσ with rfl | rfl <;> rcases abs_lt.mp hv with ⟨h1, h2⟩ <;> intro h <;> nlinarith
  simp only [obs, hnull] at hobs
  have hk : k = r / (v - σ * c) := by
    field_simp
    nlinarith [hobs]
  exact ⟨hk, by rw [hnull, hk]⟩

/-! ### Model B: fixed wave number, variable frequency -/

/-- **Model B reproduces every Model-A observable.**  For any fixed `k₀` and any
target trajectory-local observable function `r`, the choice
`ω(v) = k₀ v - r v` reproduces it exactly.  Hence Models A and B are
trajectory-locally indistinguishable. -/
theorem modelB_matches_modelA (k₀ : ℝ) (r : ℝ → ℝ) :
    ∀ v : ℝ, obs v k₀ (k₀ * v - r v) = r v := by
  intro v
  simp only [obs]
  ring

/-- **But Model B is not a null structure.**  If `k₀ ≠ 0` is fixed and the
frequency function `ω(·)` is continuous and satisfies the null dispersion
relation at every velocity, then `ω` is constant.  A *genuinely variable*
frequency at fixed wave number is therefore incompatible with standard null
dispersion. -/
theorem modelB_null_const (c k₀ : ℝ) (hc : 0 < c) (hk : k₀ ≠ 0) (om : ℝ → ℝ)
    (hcont : Continuous om) (hnull : ∀ v, NullDispersion c (om v) k₀) :
    ∀ v₁ v₂ : ℝ, om v₁ = om v₂ := by
  have hval : ∀ v, om v = c * k₀ ∨ om v = -(c * k₀) := fun v =>
    (nullDispersion_iff c (om v) k₀).1 (hnull v)
  have hne : c * k₀ ≠ 0 := mul_ne_zero (ne_of_gt hc) hk
  have hzero : ∀ z, om z ≠ 0 := by
    intro z hz
    have h := hnull z
    rw [NullDispersion, hz] at h
    have hpos : 0 < c ^ 2 * k₀ ^ 2 := by positivity
    nlinarith [h, hpos]
  -- a continuous function taking both values `± c k₀` would have to vanish somewhere
  have key : ∀ a b : ℝ, om a = c * k₀ → om b = -(c * k₀) → False := by
    intro a b ha hb
    have hmem : (0 : ℝ) ∈ Set.uIcc (om a) (om b) := by
      rw [ha, hb]
      rcases lt_or_gt_of_ne hne with h | h
      · exact Set.mem_uIcc.mpr (Or.inl ⟨by linarith, by linarith⟩)
      · exact Set.mem_uIcc.mpr (Or.inr ⟨by linarith, by linarith⟩)
    obtain ⟨z, _, hz⟩ := intermediate_value_uIcc (a := a) (b := b) hcont.continuousOn hmem
    exact hzero z hz
  intro v₁ v₂
  rcases hval v₁ with h1 | h1 <;> rcases hval v₂ with h2 | h2
  · rw [h1, h2]
  · exact absurd (key v₁ v₂ h1 h2) (by simp)
  · exact absurd (key v₂ v₁ h2 h1) (by simp)
  · rw [h1, h2]

/-- A Model-B family satisfying null dispersion has constant phase speed `c`:
"variable propagation speed" is excluded. -/
theorem modelB_no_variable_speed (c k₀ : ℝ) (hk : k₀ ≠ 0) (om : ℝ → ℝ)
    (hnull : ∀ v, NullDispersion c (om v) k₀) : ∀ v, |om v / k₀| = |c| :=
  fun v => null_phase_speed c (om v) k₀ (hnull v) hk

/-! ### Model C: mixed variation -/

/-- **The residual freedom of Model C is exactly one free function.**  For any
prescribed observable function `r` and any prescribed wave-number function `k`,
there is a unique frequency function reproducing `r`. -/
theorem modelC_fibre (r k : ℝ → ℝ) : ∃! om : ℝ → ℝ, ∀ v, obs v (k v) (om v) = r v := by
  refine ⟨fun v => k v * v - r v, fun v => by simp only [obs]; ring, ?_⟩
  intro om hom
  funext v
  have := hom v
  simp only [obs] at this
  linarith

/-- **Null dispersion collapses Model C's free function to a sign choice.**  At a
fixed subluminal velocity, the parameter pairs compatible with a given
trajectory-local observable and with null dispersion are exactly two. -/
theorem modelC_null_two_solutions (c v r : ℝ) (hv : |v| < c) (k ω : ℝ) :
    (NullDispersion c ω k ∧ obs v k ω = r) ↔
      ((k, ω) = (r / (v - c), c * (r / (v - c))) ∨
       (k, ω) = (r / (v + c), -(c * (r / (v + c))))) := by
  obtain ⟨hv1, hv2⟩ := abs_lt.mp hv
  have hne1 : v - c ≠ 0 := by intro h; linarith
  have hne2 : v + c ≠ 0 := by intro h; linarith
  constructor
  · rintro ⟨hnull, hobs⟩
    simp only [obs] at hobs
    rcases (nullDispersion_iff c ω k).1 hnull with h | h
    · left
      have hk : k = r / (v - c) := by
        rw [eq_div_iff hne1]
        rw [h] at hobs
        linarith [hobs]
      refine Prod.ext_iff.mpr ⟨hk, ?_⟩
      rw [h, hk]
    · right
      have hk : k = r / (v + c) := by
        rw [eq_div_iff hne2]
        rw [h] at hobs
        linarith [hobs]
      refine Prod.ext_iff.mpr ⟨hk, ?_⟩
      rw [h, hk]
  · rintro (h | h)
    · obtain ⟨hk, hom⟩ := Prod.ext_iff.mp h
      simp only at hk hom
      subst hk
      subst hom
      refine ⟨?_, ?_⟩
      · rw [NullDispersion]; ring
      · simp only [obs]; field_simp
    · obtain ⟨hk, hom⟩ := Prod.ext_iff.mp h
      simp only at hk hom
      subst hk
      subst hom
      refine ⟨?_, ?_⟩
      · rw [NullDispersion]; ring
      · simp only [obs]; field_simp; ring

end Phase

end Task01
