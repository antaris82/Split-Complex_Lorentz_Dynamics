import RequestProject.Task01.Phase

set_option autoImplicit false
set_option relaxedAutoImplicit false

/-!
# Task 01 — Parts 9–11: the massive/null boundary, orbits, and the sign of rapidity

Four-vectors are written in components `(V⁰, V¹)` with respect to which the
Lorentz form is `minkNorm V = (V⁰)² - (V¹)²`; for a position vector
`V = (c t, x)` this is the `Q` of `Boost.lean`.

## Contents

* massive structures: `fourVelocity`, `fourMomentum`, `energy`, `momentum`,
  and the mass-shell identity `E² - c²p² = m²c⁴`;
* **Limit I** (`m → 0⁺` at fixed rapidity): `E → 0`, `p → 0`, `η` and `τ`
  untouched, and the limiting four-momentum is the *zero* vector — which is not
  a null direction at all (`zero_not_nullMomentum`);
* **Limit II** (`m → 0⁺` at fixed energy `E > 0`, parametrised by `η → ∞`):
  `γ = E/(mc²) → ∞`, `v → c⁻`, `p → E/c`, and the four-momentum converges to the
  genuine null vector `(E/c, E/c)`;
* the directly defined `m = 0` null structure, and the three ways in which it
  differs from *any* limit of massive structures: `no_null_unit_normalisation`
  (no four-velocity), `properTime_null_eq_zero` (no proper time),
  `nullMomentum_boost` (boosts rescale rather than fix a null momentum, so
  there is no rest frame and no invariant energy);
* **orbit/stabiliser audit**: the boost group acts simply transitively on the
  future unit hyperbola (`fourVelocity_unique`, `stabilizer_trivial`), so `v=0`
  and `0<v<c` are in the *same* orbit with the *same* (trivial) stabiliser:
  no invariant distinction exists.  Null vectors form separate orbits, and
  `v = c` is never attained (`vel_ne_c`);
* **rapidity sign**: `η ↦ -η` is exactly conjugation by the parity map
  (`boost_neg_eq_parity_conj`), it exchanges the two null sectors
  (`sexp_neg_eq_conj`), and — by `SC.ringAut_eq` — nothing beyond that ℤ/2 is
  canonically available.
-/

namespace Task01

open Real Filter Topology

namespace Boundary

open Lorentz Kinematics

/-! ### Four-vectors, four-velocity, four-momentum -/

/-- The Lorentz norm of a four-vector in components `(V⁰, V¹)`. -/
def minkNorm (V : ℝ × ℝ) : ℝ := V.1 ^ 2 - V.2 ^ 2

/-- Boost acting on four-vector components. -/
noncomputable def boostV (η : ℝ) (V : ℝ × ℝ) : ℝ × ℝ :=
  (Real.cosh η * V.1 + Real.sinh η * V.2, Real.sinh η * V.1 + Real.cosh η * V.2)

theorem minkNorm_boostV (η : ℝ) (V : ℝ × ℝ) : minkNorm (boostV η V) = minkNorm V := by
  simp only [minkNorm, boostV]
  have h := Real.cosh_sq_sub_sinh_sq η
  nlinarith [h, sq_nonneg V.1, sq_nonneg V.2]

/-- `u^μ = c (cosh η, sinh η)`. -/
noncomputable def fourVelocity (c η : ℝ) : ℝ × ℝ := (c * Real.cosh η, c * Real.sinh η)

/-- `p^μ = m c (cosh η, sinh η)`. -/
noncomputable def fourMomentum (m c η : ℝ) : ℝ × ℝ :=
  (m * c * Real.cosh η, m * c * Real.sinh η)

/-- `E = γ m c² = m c² cosh η`. -/
noncomputable def energy (m c η : ℝ) : ℝ := m * c ^ 2 * Real.cosh η

/-- `p = γ m v = m c sinh η`. -/
noncomputable def momentum (m c η : ℝ) : ℝ := m * c * Real.sinh η

@[simp] theorem minkNorm_fourVelocity (c η : ℝ) : minkNorm (fourVelocity c η) = c ^ 2 := by
  simp only [minkNorm, fourVelocity]
  nlinarith [Real.cosh_sq_sub_sinh_sq η]

@[simp] theorem minkNorm_fourMomentum (m c η : ℝ) :
    minkNorm (fourMomentum m c η) = m ^ 2 * c ^ 2 := by
  simp only [minkNorm, fourMomentum]
  nlinarith [Real.cosh_sq_sub_sinh_sq η]

/-- The mass shell `E² - c²p² = m²c⁴`. -/
theorem energy_sq_sub (m c η : ℝ) :
    energy m c η ^ 2 - c ^ 2 * momentum m c η ^ 2 = m ^ 2 * c ^ 4 := by
  simp only [energy, momentum]
  nlinarith [Real.cosh_sq_sub_sinh_sq η]

/-- `E = γ m c²` with `γ = cosh η`, and `p = γ m v` with `v = c tanh η`. -/
theorem momentum_eq_gamma_m_v (m c η : ℝ) (hc : c ≠ 0) :
    momentum m c η = Real.cosh η * m * vel c η := by
  simp only [momentum, vel, Real.tanh_eq_sinh_div_cosh]
  field_simp [Real.cosh_pos η |>.ne']

theorem boostV_fourVelocity (c η θ : ℝ) :
    boostV θ (fourVelocity c η) = fourVelocity c (η + θ) := by
  refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;>
    simp only [boostV, fourVelocity, Real.cosh_add, Real.sinh_add] <;> ring

/-! ### Limit I: `m → 0⁺` at fixed rapidity -/

theorem limitI_energy (c η : ℝ) : Tendsto (fun m : ℝ => energy m c η) (𝓝[>] 0) (𝓝 0) := by
  have h : Continuous fun m : ℝ => energy m c η := by unfold energy; fun_prop
  have := (h.tendsto 0).mono_left (nhdsWithin_le_nhds (s := Set.Ioi (0:ℝ)))
  simpa [energy] using this

theorem limitI_momentum (c η : ℝ) : Tendsto (fun m : ℝ => momentum m c η) (𝓝[>] 0) (𝓝 0) := by
  have h : Continuous fun m : ℝ => momentum m c η := by unfold momentum; fun_prop
  have := (h.tendsto 0).mono_left (nhdsWithin_le_nhds (s := Set.Ioi (0:ℝ)))
  simpa [momentum] using this

theorem limitI_fourMomentum (c η : ℝ) :
    Tendsto (fun m : ℝ => fourMomentum m c η) (𝓝[>] 0) (𝓝 (0, 0)) := by
  have h : Continuous fun m : ℝ => fourMomentum m c η := by unfold fourMomentum; fun_prop
  have := (h.tendsto 0).mono_left (nhdsWithin_le_nhds (s := Set.Ioi (0:ℝ)))
  simpa [fourMomentum] using this

/-! ### The genuine `m = 0` null structure -/

/-- A null four-momentum of energy `E > 0` and direction `σ = ±1`. -/
noncomputable def nullMomentum (E c σ : ℝ) : ℝ × ℝ := (E / c, σ * (E / c))

@[simp] theorem minkNorm_nullMomentum (E c σ : ℝ) (hσ : σ = 1 ∨ σ = -1) :
    minkNorm (nullMomentum E c σ) = 0 := by
  simp only [minkNorm, nullMomentum]
  rcases hσ with rfl | rfl <;> ring

/-- **The zero vector is not a null momentum.**  The Limit-I four-momentum
`(0,0)` carries no direction, so it is *not* the `m = 0` structure. -/
theorem zero_not_nullMomentum (E c σ : ℝ) (hE : 0 < E) (hc : 0 < c) :
    nullMomentum E c σ ≠ (0, 0) := by
  intro h
  have h1 : E / c = 0 := congrArg Prod.fst h
  have : 0 < E / c := div_pos hE hc
  linarith [h1 ▸ this]

/-- **A null vector admits no unit normalisation**: there is no rescaling of a
null four-momentum with Lorentz norm `c² > 0`, hence no four-velocity and no
rapidity for a null worldline.  This is not repairable by definition. -/
theorem no_null_unit_normalisation (c : ℝ) (hc : 0 < c) (K : ℝ × ℝ) (hK : minkNorm K = 0) :
    ¬ ∃ s : ℝ, minkNorm (s • K) = c ^ 2 := by
  rintro ⟨s, hs⟩
  have : minkNorm (s • K) = s ^ 2 * minkNorm K := by
    simp only [minkNorm, Prod.smul_fst, Prod.smul_snd, smul_eq_mul]
    ring
  rw [this, hK, mul_zero] at hs
  nlinarith [hs, hc]

/-- No rapidity describes a null direction: `u^μ` always has norm `c² ≠ 0`. -/
theorem fourVelocity_ne_null (c : ℝ) (hc : 0 < c) (η : ℝ) (K : ℝ × ℝ) (hK : minkNorm K = 0) :
    fourVelocity c η ≠ K := by
  intro h
  have := minkNorm_fourVelocity c η
  rw [h, hK] at this
  nlinarith [this, hc]

/-- **A null worldline has vanishing Lorentz arclength**: the massive proper
time degenerates identically to `0`; it is not a clock that continues. -/
theorem properTime_null_eq_zero (c x₀ t : ℝ) (hc : 0 < c) :
    properTime c (fun s => x₀ + c * s) t = 0 := by
  have hderiv : deriv (fun s : ℝ => x₀ + c * s) = fun _ => c := by
    funext s
    have h : HasDerivAt (fun s : ℝ => x₀ + c * s) c s := by
      simpa using ((hasDerivAt_id s).const_mul c).const_add x₀
    exact h.deriv
  simp only [properTime, hderiv, properTimeRate, div_self (ne_of_gt hc)]
  norm_num

/-- **Boosts rescale a null momentum.**  There is no rest frame and no invariant
energy for a null momentum: the energy is multiplied by `e^{η}` (right-moving
sector), which can be any positive number. -/
theorem nullMomentum_boost (E c η : ℝ) :
    boostV η (nullMomentum E c 1) = nullMomentum (Real.exp η * E) c 1 := by
  refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;>
    simp only [boostV, nullMomentum, ← Real.cosh_add_sinh] <;> ring

/-- A nonzero null momentum can never be brought to rest: its spatial component
vanishes only if the whole vector does. -/
theorem nullMomentum_no_rest_frame (E c η : ℝ) (hE : 0 < E) (hc : 0 < c) :
    (boostV η (nullMomentum E c 1)).2 ≠ 0 := by
  rw [nullMomentum_boost]
  simp only [nullMomentum, one_mul]
  positivity

/-! ### Limit II: `m → 0⁺` at fixed energy `E > 0` -/

section LimitII

variable (E c : ℝ)

/-- The mass required to have energy `E` at rapidity `η`. -/
noncomputable def massOfRapidity (E c η : ℝ) : ℝ := E / (c ^ 2 * Real.cosh η)

theorem tendsto_cosh_atTop : Tendsto Real.cosh atTop atTop := by
  have h : ∀ x : ℝ, Real.exp x / 2 ≤ Real.cosh x := by
    intro x
    rw [Real.cosh_eq]
    have := (Real.exp_pos (-x)).le
    linarith
  exact tendsto_atTop_mono h (Real.tendsto_exp_atTop.atTop_div_const (by norm_num))

theorem tendsto_tanh_atTop : Tendsto Real.tanh atTop (𝓝 1) := by
  have key : Real.tanh = fun x : ℝ => 1 - 2 / (Real.exp (2 * x) + 1) := by
    funext x
    rw [Real.tanh_eq_sinh_div_cosh, Real.sinh_eq, Real.cosh_eq]
    have h1 : Real.exp x > 0 := Real.exp_pos x
    have h3 : Real.exp (2 * x) = Real.exp x * Real.exp x := by rw [← Real.exp_add]; ring_nf
    have h4 : Real.exp (-x) = 1 / Real.exp x := by rw [Real.exp_neg]; field_simp
    rw [h3, h4]
    field_simp
    ring
  rw [key]
  have hlin : Tendsto (fun x : ℝ => 2 * x) atTop atTop := by
    apply Filter.tendsto_atTop_atTop.mpr
    intro b
    exact ⟨|b|, fun a ha => by
      have h1 : (0:ℝ) ≤ |b| := abs_nonneg b
      have h2 : b ≤ |b| := le_abs_self b
      linarith⟩
  have h0 : Tendsto (fun x : ℝ => 2 / (Real.exp (2 * x) + 1)) atTop (𝓝 0) := by
    apply Filter.Tendsto.div_atTop tendsto_const_nhds
    exact Filter.tendsto_atTop_add_const_right _ 1 (Real.tendsto_exp_atTop.comp hlin)
  simpa using Filter.Tendsto.const_sub 1 h0

/-- Along Limit II the mass tends to `0`. -/
theorem limitII_mass (hc : 0 < c) :
    Tendsto (fun η => massOfRapidity E c η) atTop (𝓝 0) := by
  apply Filter.Tendsto.div_atTop (tendsto_const_nhds)
  exact (tendsto_cosh_atTop.const_mul_atTop (by positivity))

/-- Along Limit II the energy is *constant* and equal to `E`. -/
theorem limitII_energy (hc : 0 < c) (η : ℝ) : energy (massOfRapidity E c η) c η = E := by
  have h1 : Real.cosh η ≠ 0 := ne_of_gt (Real.cosh_pos η)
  simp only [energy, massOfRapidity]
  field_simp

/-- Along Limit II the Lorentz factor `γ = E/(mc²)` diverges. -/
theorem limitII_gamma (hE : 0 < E) (hc : 0 < c) :
    Tendsto (fun η => E / (massOfRapidity E c η * c ^ 2)) atTop atTop := by
  have heq : ∀ η, E / (massOfRapidity E c η * c ^ 2) = Real.cosh η := by
    intro η
    have h1 : Real.cosh η ≠ 0 := ne_of_gt (Real.cosh_pos η)
    simp only [massOfRapidity]
    field_simp
  simpa [heq] using tendsto_cosh_atTop

/-- Along Limit II the coordinate velocity tends to `c` from below. -/
theorem limitII_vel : Tendsto (fun η => vel c η) atTop (𝓝 c) := by
  have := tendsto_tanh_atTop.const_mul c
  simpa [vel] using this

/-- Along Limit II the momentum tends to `E/c`. -/
theorem limitII_momentum (hc : 0 < c) :
    Tendsto (fun η => momentum (massOfRapidity E c η) c η) atTop (𝓝 (E / c)) := by
  have heq : ∀ η, momentum (massOfRapidity E c η) c η = (E / c) * Real.tanh η := by
    intro η
    have h1 : Real.cosh η ≠ 0 := ne_of_gt (Real.cosh_pos η)
    simp only [momentum, massOfRapidity, Real.tanh_eq_sinh_div_cosh]
    field_simp
  simpa [heq] using tendsto_tanh_atTop.const_mul (E / c)

/-- Along Limit II the four-momentum converges to the genuine null momentum
`(E/c, E/c)`. -/
theorem limitII_fourMomentum (hc : 0 < c) :
    Tendsto (fun η => fourMomentum (massOfRapidity E c η) c η) atTop
      (𝓝 (nullMomentum E c 1)) := by
  have heq : ∀ η, fourMomentum (massOfRapidity E c η) c η = (E / c, (E / c) * Real.tanh η) := by
    intro η
    have h1 : Real.cosh η ≠ 0 := ne_of_gt (Real.cosh_pos η)
    refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;>
      simp only [fourMomentum, massOfRapidity, Real.tanh_eq_sinh_div_cosh] <;> field_simp
  have h2 : Tendsto (fun η => (E / c) * Real.tanh η) atTop (𝓝 (E / c)) := by
    simpa using tendsto_tanh_atTop.const_mul (E / c)
  simp only [heq, nullMomentum, one_mul]
  exact Filter.Tendsto.prodMk_nhds tendsto_const_nhds h2

end LimitII

/-! ### Orbits, stabilisers and the absence of a boundary distinction -/

/-- The future unit hyperbola (mass shell of unit norm). -/
def futureUnit (c : ℝ) : Set (ℝ × ℝ) := {V | minkNorm V = c ^ 2 ∧ 0 < V.1}

theorem fourVelocity_mem (c : ℝ) (hc : 0 < c) (η : ℝ) : fourVelocity c η ∈ futureUnit c := by
  refine ⟨minkNorm_fourVelocity c η, ?_⟩
  simp only [fourVelocity]
  have := Real.cosh_pos η
  positivity

/-- **Simple transitivity.**  Every future unit vector is `u^μ` for exactly one
rapidity: the boost group acts simply transitively on the mass shell.  In
particular `v = 0` lies on the *same* orbit as every `0 < |v| < c`. -/
theorem fourVelocity_unique (c : ℝ) (hc : 0 < c) (V : ℝ × ℝ) (hV : V ∈ futureUnit c) :
    ∃! η : ℝ, fourVelocity c η = V := by
  obtain ⟨hnorm, hpos⟩ := hV
  simp only [minkNorm] at hnorm
  have hsq : (V.1 / c) ^ 2 - (V.2 / c) ^ 2 = 1 := by
    field_simp
    linarith [hnorm]
  refine ⟨Real.arsinh (V.2 / c), ?_, ?_⟩
  · have hsinh : Real.sinh (Real.arsinh (V.2 / c)) = V.2 / c := Real.sinh_arsinh _
    have hcosh : Real.cosh (Real.arsinh (V.2 / c)) = V.1 / c := by
      have hc1 : Real.cosh (Real.arsinh (V.2 / c)) ^ 2 = (V.1 / c) ^ 2 := by
        have := Real.cosh_sq_sub_sinh_sq (Real.arsinh (V.2 / c))
        rw [hsinh] at this
        linarith [hsq]
      have hpos1 : 0 < Real.cosh (Real.arsinh (V.2 / c)) := Real.cosh_pos _
      have hpos2 : 0 < V.1 / c := div_pos hpos hc
      nlinarith [hc1, hpos1, hpos2]
    refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> simp only [fourVelocity]
    · rw [hcosh]; field_simp
    · rw [hsinh]; field_simp
  · intro η hη
    have h2 : c * Real.sinh η = V.2 := congrArg Prod.snd hη
    have h3 : Real.sinh η = V.2 / c := by
      field_simp
      linear_combination h2
    rw [← h3, Real.arsinh_sinh]

/-- **Trivial stabilisers everywhere on the mass shell.**  No nonzero boost
fixes a timelike vector, whatever its velocity; `v = 0` is not distinguished by
its isotropy subgroup. -/
theorem stabilizer_trivial (c : ℝ) (hc : 0 < c) (η θ : ℝ)
    (h : boostV θ (fourVelocity c η) = fourVelocity c η) : θ = 0 := by
  rw [boostV_fourVelocity] at h
  have h2 : c * Real.sinh (η + θ) = c * Real.sinh η := congrArg Prod.snd h
  have h3 : Real.sinh (η + θ) = Real.sinh η := mul_left_cancel₀ (ne_of_gt hc) h2
  have h4 := Real.sinh_injective h3
  linarith

/-- The stabiliser of a nonzero null momentum is trivial as well. -/
theorem stabilizer_null_trivial (E c θ : ℝ) (hE : 0 < E) (hc : 0 < c)
    (h : boostV θ (nullMomentum E c 1) = nullMomentum E c 1) : θ = 0 := by
  rw [nullMomentum_boost] at h
  have h1 : Real.exp θ * E / c = E / c := congrArg Prod.fst h
  have hE' : E ≠ 0 := ne_of_gt hE
  have hc' : c ≠ 0 := ne_of_gt hc
  have hexp : Real.exp θ = 1 := by
    field_simp at h1
    exact h1
  exact (Real.exp_eq_one_iff θ).mp hexp

/-- Timelike and null orbits are disjoint: no boost carries a mass-shell vector
to a null vector. -/
theorem futureUnit_disjoint_null (c : ℝ) (hc : 0 < c) (V K : ℝ × ℝ)
    (hV : V ∈ futureUnit c) (hK : minkNorm K = 0) : V ≠ K := by
  intro h
  obtain ⟨hn, -⟩ := hV
  rw [h, hK] at hn
  nlinarith [hn, hc]

/-- `v = c` is never attained by a boost: the boundary is not in the orbit. -/
theorem vel_ne_c (c : ℝ) (hc : 0 < c) (η : ℝ) : vel c η ≠ c := by
  intro h
  have := abs_vel_lt c hc η
  rw [h, abs_of_pos hc] at this
  linarith

/-- The velocity range of the boost orbit is exactly the open interval. -/
theorem vel_range (c : ℝ) (hc : 0 < c) : Set.range (vel c) = Set.Ioo (-c) c := by
  ext v
  constructor
  · rintro ⟨η, rfl⟩
    exact abs_lt.mp (abs_vel_lt c hc η)
  · intro hv
    exact ⟨rap c v, vel_rap c hc v (abs_lt.mpr hv)⟩

/-! ### The sign of rapidity -/

/-- Spatial parity `P (t, x) = (t, -x)`. -/
def parity (X : Event) : Event := (X.1, -X.2)

theorem Q_parity (c : ℝ) (X : Event) : Q c (parity X) = Q c X := by
  simp only [Q, parity]
  ring

theorem parity_parity (X : Event) : parity (parity X) = X := by
  refine Prod.ext_iff.mpr ⟨rfl, ?_⟩
  simp [parity]

/-- Parity exchanges the two null coordinates. -/
theorem nullU_parity (c : ℝ) (X : Event) : nullU c (parity X) = nullW c X := by
  simp only [nullU, nullW, parity]
  ring

theorem nullW_parity (c : ℝ) (X : Event) : nullW c (parity X) = nullU c X := by
  simp only [nullU, nullW, parity]
  ring

/-- **`η ↦ -η` is conjugation by parity.**  Reversing the rapidity sign is
exactly the parity-conjugate boost; it exchanges the two oriented null sectors
and nothing more. -/
theorem boost_neg_eq_parity_conj (c : ℝ) (η : ℝ) (X : Event) :
    boost c (-η) X = parity (boost c η (parity X)) := by
  refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;>
    simp only [boost, parity, Real.cosh_neg, Real.sinh_neg] <;> ring

/-- On the split-complex side, `η ↦ -η` is split conjugation, which exchanges
the idempotents `e₊ ↔ e₋`. -/
theorem sexp_neg_eq_conj (η : ℝ) : sexp (-η) = SC.conj (sexp η) := by
  ext <;> simp [sexp, Real.cosh_neg, Real.sinh_neg]

theorem vel_neg (c η : ℝ) : vel c (-η) = -vel c η := by
  simp [vel, Real.tanh_neg]

/-- The two null scale factors are exchanged. -/
theorem exp_neg_swap (η : ℝ) :
    (Real.exp (-η), Real.exp (- -η)) = (Real.exp (-η), Real.exp η) := by
  simp

/-- **Nothing beyond the ℤ/2.**  Any further canonical discrete structure on the
split-complex algebra would be a ring automorphism, and there are exactly two:
the identity and the sector exchange.  (Restatement of `SC.ringAut_eq` at the
boundary-audit level.) -/
theorem discrete_structure_is_Z2 (F : SC ≃+* SC) :
    F = RingEquiv.refl SC ∨ F = SC.conj := SC.ringAut_eq F

end Boundary

end Task01
