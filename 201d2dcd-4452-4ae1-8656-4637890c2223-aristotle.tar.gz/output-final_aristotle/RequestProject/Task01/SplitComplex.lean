import Mathlib

set_option autoImplicit false
set_option relaxedAutoImplicit false

/-!
# Task 01 — Part 1: the split-complex (hyperbolic) algebra and null coordinates

This file contains the *algebraic* layer of the audit.  Nothing here refers to
kinematics; the only inputs are the field `ℝ` and its ring theory.

## Contents

* `SC`, the split-complex numbers `𝔻 = {a + j b : a, b ∈ ℝ, j² = +1}`;
* the complementary idempotents `e₊ = (1 + j)/2`, `e₋ = (1 - j)/2`;
* the split-norm `N (a + j b) = a² - b²`, which is multiplicative;
* the **null-coordinate isomorphism** `SC ≃+* ℝ × ℝ`, `a + j b ↦ (a + b, a - b)`,
  under which `N` becomes the product of the two coordinates and `e₊`, `e₋`
  become the two standard idempotents `(1,0)`, `(0,1)`;
* the classification of the idempotents, of the null cone and of the units;
* the classification of *all* ring automorphisms of `SC`: there are exactly two,
  the identity and the split-conjugation `j ↦ -j`, which exchanges the two null
  sectors.  This is the precise sense in which "no further canonical discrete
  structure" is available at the algebraic level.

## Conventions

`SC.mk a b` is the split-complex number `a + j b`.  The map to null coordinates
is fixed once and for all as `a + j b ↦ (a + b, a - b)`.
-/

namespace Task01

/-- A split-complex number `re + j * im`, with `j² = +1`. -/
@[ext] structure SC where
  re : ℝ
  im : ℝ

namespace SC

instance : Add SC := ⟨fun z w => ⟨z.re + w.re, z.im + w.im⟩⟩
instance : Zero SC := ⟨⟨0, 0⟩⟩
instance : Neg SC := ⟨fun z => ⟨-z.re, -z.im⟩⟩
instance : Sub SC := ⟨fun z w => ⟨z.re - w.re, z.im - w.im⟩⟩
instance : Mul SC := ⟨fun z w => ⟨z.re * w.re + z.im * w.im, z.re * w.im + z.im * w.re⟩⟩
instance : One SC := ⟨⟨1, 0⟩⟩

@[simp] lemma add_re (z w : SC) : (z + w).re = z.re + w.re := rfl
@[simp] lemma add_im (z w : SC) : (z + w).im = z.im + w.im := rfl
@[simp] lemma zero_re : (0 : SC).re = 0 := rfl
@[simp] lemma zero_im : (0 : SC).im = 0 := rfl
@[simp] lemma neg_re (z : SC) : (-z).re = -z.re := rfl
@[simp] lemma neg_im (z : SC) : (-z).im = -z.im := rfl
@[simp] lemma sub_re (z w : SC) : (z - w).re = z.re - w.re := rfl
@[simp] lemma sub_im (z w : SC) : (z - w).im = z.im - w.im := rfl
@[simp] lemma mul_re (z w : SC) : (z * w).re = z.re * w.re + z.im * w.im := rfl
@[simp] lemma mul_im (z w : SC) : (z * w).im = z.re * w.im + z.im * w.re := rfl
@[simp] lemma one_re : (1 : SC).re = 1 := rfl
@[simp] lemma one_im : (1 : SC).im = 0 := rfl

instance instCommRing : CommRing SC where
  add_assoc := by intros; ext <;> simp <;> ring
  zero_add := by intros; ext <;> simp
  add_zero := by intros; ext <;> simp
  add_comm := by intros; ext <;> simp <;> ring
  neg_add_cancel := by intros; ext <;> simp
  mul_assoc := by intros; ext <;> simp <;> ring
  one_mul := by intros; ext <;> simp
  mul_one := by intros; ext <;> simp
  left_distrib := by intros; ext <;> simp <;> ring
  right_distrib := by intros; ext <;> simp <;> ring
  mul_comm := by intros; ext <;> simp <;> ring
  zero_mul := by intros; ext <;> simp
  mul_zero := by intros; ext <;> simp
  sub_eq_add_neg := by intros; ext <;> simp <;> ring
  nsmul := nsmulRec
  zsmul := zsmulRec

/-- The hyperbolic unit `j`. -/
def j : SC := ⟨0, 1⟩

@[simp] lemma j_re : j.re = 0 := rfl
@[simp] lemma j_im : j.im = 1 := rfl

/-- The defining relation of the split-complex algebra: `j² = +1`. -/
theorem j_sq : j * j = 1 := by ext <;> simp [j]

theorem j_ne_one : j ≠ 1 := by
  intro h; have := congrArg SC.im h; simp at this

theorem j_ne_neg_one : j ≠ -1 := by
  intro h; have := congrArg SC.im h; simp at this

/-- The canonical embedding `ℝ → SC`. -/
def ofReal (a : ℝ) : SC := ⟨a, 0⟩

@[simp] lemma ofReal_re (a : ℝ) : (ofReal a).re = a := rfl
@[simp] lemma ofReal_im (a : ℝ) : (ofReal a).im = 0 := rfl

/-- `ℝ → SC` is a ring homomorphism. -/
def ofRealHom : ℝ →+* SC where
  toFun := ofReal
  map_one' := rfl
  map_mul' := by intros; ext <;> simp [ofReal]
  map_zero' := rfl
  map_add' := by intros; ext <;> simp [ofReal]

/-- Every split-complex number is `a + j b` with `a = re`, `b = im`. -/
theorem eq_ofReal_add_j_mul (z : SC) : z = ofReal z.re + j * ofReal z.im := by
  ext <;> simp [ofReal, j]

/-- ... and this decomposition is unique. -/
theorem ofReal_add_j_mul_inj {a b a' b' : ℝ}
    (h : ofReal a + j * ofReal b = ofReal a' + j * ofReal b') : a = a' ∧ b = b' := by
  constructor
  · simpa [ofReal, j] using congrArg SC.re h
  · simpa [ofReal, j] using congrArg SC.im h

/-! ### The complementary idempotents -/

/-- `e₊ = (1 + j)/2`. -/
noncomputable def ePlus : SC := ⟨1/2, 1/2⟩
/-- `e₋ = (1 - j)/2`. -/
noncomputable def eMinus : SC := ⟨1/2, -(1/2)⟩

@[simp] theorem ePlus_sq : ePlus * ePlus = ePlus := by ext <;> simp [ePlus] <;> ring
@[simp] theorem eMinus_sq : eMinus * eMinus = eMinus := by ext <;> simp [eMinus] <;> ring
@[simp] theorem ePlus_mul_eMinus : ePlus * eMinus = 0 := by ext <;> simp [ePlus, eMinus]
@[simp] theorem eMinus_mul_ePlus : eMinus * ePlus = 0 := by ext <;> simp [ePlus, eMinus]
theorem ePlus_add_eMinus : ePlus + eMinus = 1 := by ext <;> (simp [ePlus, eMinus]; try ring)
theorem ePlus_sub_eMinus : ePlus - eMinus = j := by ext <;> (simp [ePlus, eMinus, j]; try ring)
theorem ePlus_ne_zero : ePlus ≠ 0 := by
  intro h; have := congrArg SC.re h; norm_num [ePlus] at this
theorem eMinus_ne_zero : eMinus ≠ 0 := by
  intro h; have := congrArg SC.re h; norm_num [eMinus] at this
theorem ePlus_ne_one : ePlus ≠ 1 := by
  intro h; have := congrArg SC.re h; norm_num [ePlus] at this
theorem eMinus_ne_one : eMinus ≠ 1 := by
  intro h; have := congrArg SC.re h; norm_num [eMinus] at this
theorem ePlus_ne_eMinus : ePlus ≠ eMinus := by
  intro h; have := congrArg SC.im h; norm_num [ePlus, eMinus] at this

/-- The idempotent decomposition: `z = u e₊ + w e₋` with `u = re + im`, `w = re - im`. -/
theorem eq_idempotent_decomp (z : SC) :
    z = ofReal (z.re + z.im) * ePlus + ofReal (z.re - z.im) * eMinus := by
  ext <;> simp [ePlus, eMinus, ofReal] <;> ring

/-! ### The split norm -/

/-- The split norm `N(a + j b) = a² - b²`; this is the Lorentz quadratic form. -/
def N (z : SC) : ℝ := z.re ^ 2 - z.im ^ 2

@[simp] theorem N_one : N 1 = 1 := by simp [N]
@[simp] theorem N_ePlus : N ePlus = 0 := by norm_num [N, ePlus]
@[simp] theorem N_eMinus : N eMinus = 0 := by norm_num [N, eMinus]

/-- The split norm is multiplicative. -/
theorem N_mul (z w : SC) : N (z * w) = N z * N w := by simp [N]; ring

/-! ### Null coordinates -/

/-- The **null-coordinate map** `a + j b ↦ (a + b, a - b)`.  This is a ring
isomorphism onto `ℝ × ℝ` with componentwise operations: the split-complex
algebra *is* the algebra of pairs of null coordinates. -/
noncomputable def toNull : SC ≃+* (ℝ × ℝ) where
  toFun z := (z.re + z.im, z.re - z.im)
  invFun p := ⟨(p.1 + p.2) / 2, (p.1 - p.2) / 2⟩
  left_inv z := by ext <;> (simp; try ring)
  right_inv p := by ext <;> (simp; try ring)
  map_mul' z w := by ext <;> (simp; try ring)
  map_add' z w := by ext <;> (simp; try ring)

@[simp] lemma toNull_apply (z : SC) : toNull z = (z.re + z.im, z.re - z.im) := rfl

@[simp] lemma toNull_symm_apply (p : ℝ × ℝ) :
    toNull.symm p = ⟨(p.1 + p.2) / 2, (p.1 - p.2) / 2⟩ := rfl

@[simp] theorem toNull_ePlus : toNull ePlus = (1, 0) := by norm_num [ePlus]
@[simp] theorem toNull_eMinus : toNull eMinus = (0, 1) := by norm_num [eMinus]
@[simp] theorem toNull_j : toNull j = (1, -1) := by norm_num [j]

/-- In null coordinates the split norm is the product of the two coordinates:
`N z = u · w`.  This is the algebraic form of `c²t² - x² = (ct+x)(ct-x)`. -/
theorem N_eq_toNull_mul (z : SC) : N z = (toNull z).1 * (toNull z).2 := by
  simp [N]; ring

/-! ### Idempotents, null cone, units -/

/-- The only idempotents of `SC` are `0`, `1`, `e₊`, `e₋`. -/
theorem idempotent_iff (z : SC) :
    z * z = z ↔ z = 0 ∨ z = 1 ∨ z = ePlus ∨ z = eMinus := by
  constructor
  · intro h
    have h1 : z.re * z.re + z.im * z.im = z.re := congrArg SC.re h
    have h2 : z.re * z.im + z.im * z.re = z.im := congrArg SC.im h
    rcases eq_or_ne z.im 0 with hi | hi
    · rw [hi] at h1
      have hz : z.re * (z.re - 1) = 0 := by nlinarith
      rcases mul_eq_zero.1 hz with h0 | h0
      · exact Or.inl (by ext <;> simp [h0, hi])
      · refine Or.inr (Or.inl ?_)
        have : z.re = 1 := by linarith
        ext <;> simp [this, hi]
    · have hre : z.re = 1 / 2 := by
        have hz : z.im * (2 * z.re - 1) = 0 := by nlinarith
        rcases mul_eq_zero.1 hz with h0 | h0
        · exact absurd h0 hi
        · linarith
      have h4 : (z.im - 1/2) * (z.im + 1/2) = 0 := by rw [hre] at h1; nlinarith
      rcases mul_eq_zero.1 h4 with h0 | h0
      · refine Or.inr (Or.inr (Or.inl ?_))
        ext
        · simp [ePlus, hre]
        · simp [ePlus]; linarith
      · refine Or.inr (Or.inr (Or.inr ?_))
        ext
        · simp [eMinus, hre]
        · simp [eMinus]; linarith
  · rintro (rfl | rfl | rfl | rfl) <;> simp

/-- The null cone `N z = 0` is exactly the union of the two idempotent lines
`ℝ e₊` and `ℝ e₋`.  These are the two "null sectors". -/
theorem N_eq_zero_iff (z : SC) :
    N z = 0 ↔ (∃ a : ℝ, z = ofReal a * ePlus) ∨ (∃ a : ℝ, z = ofReal a * eMinus) := by
  constructor
  · intro h
    have hz : (z.re + z.im) * (z.re - z.im) = 0 := by
      have := N_eq_toNull_mul z; rw [h] at this; simpa using this.symm
    rcases mul_eq_zero.1 hz with h0 | h0
    · refine Or.inr ⟨z.re - z.im, ?_⟩
      ext <;> simp [eMinus, ofReal] <;> linarith
    · refine Or.inl ⟨z.re + z.im, ?_⟩
      ext <;> simp [ePlus, ofReal] <;> linarith
  · rintro (⟨a, rfl⟩ | ⟨a, rfl⟩) <;> rw [N_mul] <;> simp

/-- `z` is a unit iff its split norm is nonzero. -/
theorem isUnit_iff (z : SC) : IsUnit z ↔ N z ≠ 0 := by
  constructor
  · rintro ⟨u, rfl⟩ h
    have hu : N ((u : SC) * (↑u⁻¹ : SC)) = 1 := by rw [u.mul_inv]; simp
    rw [N_mul, h, zero_mul] at hu
    exact zero_ne_one hu
  · intro h
    refine ⟨⟨z, ⟨z.re / N z, -z.im / N z⟩, ?_, ?_⟩, rfl⟩ <;>
      · ext <;> simp [N] at h ⊢ <;> field_simp [N] <;> ring

/-! ### Automorphisms: split conjugation and the classification -/

/-- Split conjugation `a + j b ↦ a - j b`. -/
def conj : SC ≃+* SC where
  toFun z := ⟨z.re, -z.im⟩
  invFun z := ⟨z.re, -z.im⟩
  left_inv z := by ext <;> simp
  right_inv z := by ext <;> simp
  map_mul' z w := by ext <;> (simp; try ring)
  map_add' z w := by ext <;> (simp; try ring)

@[simp] lemma conj_apply (z : SC) : conj z = ⟨z.re, -z.im⟩ := rfl

theorem conj_j : conj j = -j := by ext <;> simp [j]
theorem conj_ePlus : conj ePlus = eMinus := by ext <;> simp [ePlus, eMinus]
theorem conj_eMinus : conj eMinus = ePlus := by ext <;> simp [ePlus, eMinus]

theorem conj_ne_refl : conj ≠ RingEquiv.refl SC := by
  intro h
  have h1 : conj ePlus = ePlus := by rw [h]; rfl
  rw [conj_ePlus] at h1
  exact ePlus_ne_eMinus h1.symm

theorem N_eq_self_mul_conj (z : SC) : ofReal (N z) = z * conj z := by
  ext <;> simp [N, ofReal] <;> ring

/-- Auxiliary: a ring automorphism of `ℝ × ℝ` fixing `(1,0)` is the identity.
Uses the rigidity of `ℝ` (the only ring endomorphism of `ℝ` is the identity). -/
theorem prod_ringAut_eq_refl (F : (ℝ × ℝ) ≃+* (ℝ × ℝ)) (h : F (1, 0) = (1, 0)) :
    F = RingEquiv.refl _ := by
  have hone : ((1, 0) : ℝ × ℝ) + (0, 1) = 1 := by
    refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> norm_num
  have h' : F (0, 1) = (0, 1) := by
    have hsum : F (1, 0) + F (0, 1) = 1 := by rw [← map_add, hone, map_one]
    rw [h] at hsum
    refine Prod.ext_iff.mpr ⟨?_, ?_⟩
    · have := congrArg Prod.fst hsum
      simp at this
      linarith
    · have := congrArg Prod.snd hsum
      simp at this
      linarith
  -- second component of `F (a,0)` vanishes
  have hsnd : ∀ a : ℝ, (F (a, 0)).2 = 0 := by
    intro a
    have hmul : ((a, 0) : ℝ × ℝ) * (1, 0) = (a, 0) := by
      refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> norm_num
    have key : F (a, 0) = F (a, 0) * (1, 0) := by
      conv_lhs => rw [← hmul]
      rw [map_mul, h]
    have h2 := congrArg Prod.snd key
    simp at h2
    exact h2
  have hfst : ∀ a : ℝ, (F (0, a)).1 = 0 := by
    intro a
    have hmul : ((0, a) : ℝ × ℝ) * (0, 1) = (0, a) := by
      refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> norm_num
    have key : F (0, a) = F (0, a) * (0, 1) := by
      conv_lhs => rw [← hmul]
      rw [map_mul, h']
    have h2 := congrArg Prod.fst key
    simp at h2
    exact h2
  -- the induced ring endomorphisms of `ℝ`
  have hmulpair : ∀ a b : ℝ, ((a, 0) : ℝ × ℝ) * (b, 0) = (a * b, 0) := by
    intro a b; refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> norm_num
  have haddpair : ∀ a b : ℝ, ((a, 0) : ℝ × ℝ) + (b, 0) = (a + b, 0) := by
    intro a b; refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> norm_num
  have hmulpair' : ∀ a b : ℝ, ((0, a) : ℝ × ℝ) * (0, b) = (0, a * b) := by
    intro a b; refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> norm_num
  have haddpair' : ∀ a b : ℝ, ((0, a) : ℝ × ℝ) + (0, b) = (0, a + b) := by
    intro a b; refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> norm_num
  have hzeropair : ((0, 0) : ℝ × ℝ) = 0 := rfl
  let φ : ℝ →+* ℝ :=
    { toFun := fun a => (F (a, 0)).1
      map_one' := congrArg Prod.fst h
      map_mul' := by
        intro a b
        have := map_mul F (a, 0) (b, 0)
        rw [hmulpair] at this
        exact congrArg Prod.fst this
      map_zero' := by
        have := map_zero F
        rw [← hzeropair] at this
        exact congrArg Prod.fst this
      map_add' := by
        intro a b
        have := map_add F (a, 0) (b, 0)
        rw [haddpair] at this
        exact congrArg Prod.fst this }
  let ψ : ℝ →+* ℝ :=
    { toFun := fun a => (F (0, a)).2
      map_one' := congrArg Prod.snd h'
      map_mul' := by
        intro a b
        have := map_mul F (0, a) (0, b)
        rw [hmulpair'] at this
        exact congrArg Prod.snd this
      map_zero' := by
        have := map_zero F
        rw [← hzeropair] at this
        exact congrArg Prod.snd this
      map_add' := by
        intro a b
        have := map_add F (0, a) (0, b)
        rw [haddpair'] at this
        exact congrArg Prod.snd this }
  have hφ : ∀ a : ℝ, (F (a, 0)).1 = a := by
    intro a
    have hid : φ = RingHom.id ℝ := Subsingleton.elim _ _
    exact congrArg (fun f : ℝ →+* ℝ => f a) hid
  have hψ : ∀ a : ℝ, (F (0, a)).2 = a := by
    intro a
    have hid : ψ = RingHom.id ℝ := Subsingleton.elim _ _
    exact congrArg (fun f : ℝ →+* ℝ => f a) hid
  refine RingEquiv.ext fun p => ?_
  have hp : ((p.1, 0) : ℝ × ℝ) + (0, p.2) = p := by
    refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> norm_num
  have hsplit : F p = F (p.1, 0) + F (0, p.2) := by
    conv_lhs => rw [← hp]
    rw [map_add]
  have e1 : F (p.1, 0) = (p.1, 0) := Prod.ext_iff.mpr ⟨hφ p.1, hsnd p.1⟩
  have e2 : F (0, p.2) = (0, p.2) := Prod.ext_iff.mpr ⟨hfst p.2, hψ p.2⟩
  rw [hsplit, e1, e2, hp]
  rfl

/-- **Classification of automorphisms.**  The split-complex algebra has exactly
two ring automorphisms: the identity and split conjugation.  Consequently the
only canonical discrete structure carried by `SC` alone is the ℤ/2 exchange of
the two null sectors. -/
theorem ringAut_eq (F : SC ≃+* SC) : F = RingEquiv.refl SC ∨ F = conj := by
  set G : (ℝ × ℝ) ≃+* (ℝ × ℝ) := (toNull.symm.trans F).trans toNull with hG
  have hFG : ∀ z : SC, F z = toNull.symm (G (toNull z)) := by
    intro z; simp [hG]
  have hz : G (1, 0) = toNull (F ePlus) := by
    have hgt : G (toNull ePlus) = toNull (F ePlus) := by simp [hG]
    rwa [toNull_ePlus] at hgt
  have hidem : G (1, 0) = (1, 0) ∨ G (1, 0) = (0, 1) := by
    have hidemSC : (F ePlus) * (F ePlus) = F ePlus := by rw [← map_mul, ePlus_sq]
    rcases (idempotent_iff _).1 hidemSC with h0 | h0 | h0 | h0
    · exact absurd (F.injective (by simpa using h0)) ePlus_ne_zero
    · exact absurd (F.injective (by simpa using h0)) ePlus_ne_one
    · exact Or.inl (by rw [hz, h0]; exact toNull_ePlus)
    · exact Or.inr (by rw [hz, h0]; exact toNull_eMinus)
  rcases hidem with h | h
  · left
    have hrefl := prod_ringAut_eq_refl G h
    refine RingEquiv.ext fun z => ?_
    rw [hFG z, hrefl]
    simp
  · right
    set H : (ℝ × ℝ) ≃+* (ℝ × ℝ) := (toNull.symm.trans conj).trans toNull with hH
    have hHval : ∀ p : ℝ × ℝ, H p = (p.2, p.1) := by
      intro p
      rw [hH]
      refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> simp <;> ring
    have hHG : H (1, 0) = (0, 1) := by rw [hHval]
    have hcomp : (G.trans H.symm) (1, 0) = (1, 0) := by
      rw [RingEquiv.trans_apply, h, ← hHG, RingEquiv.symm_apply_apply]
    have hrefl := prod_ringAut_eq_refl _ hcomp
    have hGH : G = H := by
      refine RingEquiv.ext fun p => ?_
      have hx : H.symm (G p) = p :=
        congrArg (fun (K : (ℝ × ℝ) ≃+* (ℝ × ℝ)) => K p) hrefl
      calc G p = H (H.symm (G p)) := by rw [RingEquiv.apply_symm_apply]
        _ = H p := by rw [hx]
    refine RingEquiv.ext fun z => ?_
    rw [hFG z, hGH, hH, RingEquiv.trans_apply, RingEquiv.trans_apply,
      RingEquiv.symm_apply_apply, RingEquiv.symm_apply_apply]

end SC

end Task01
