/-
# Task 02 — Orbits and stabilizers for the five carriers

Carriers compared (all under the connected boost group `{B_θ : θ ∈ ℝ}`, which is
the Task 01 realization of `SO⁺(1,1)`):

* **A** a future unit timelike vector `U(η)`;
* **B** its positive ray `Ray₊(U(η))`;
* **C** a nonzero future null vector `K_σ(E)` with fixed scale;
* **D** its positive null ray `Ray₊(K_σ(E))`;
* **E** its projective class `[K_σ(E)]`.

The headline results:

* the stabilizer of a *null vector* is trivial (Task 01), and stays trivial for a
  *timelike ray* and a *timelike projective direction*;
* but the stabilizer of a *null ray* (and of a *projective null direction*) is
  the **whole** boost group, because the boost orbit of a nonzero null vector is
  exactly its whole positive ray, which the quotient collapses to a point.

So the answer to "does quotienting by scale change the Lorentz stabilizer?" is
carrier-dependent: **no** in the timelike case, **yes** in the null case.
-/
import RequestProject.Task02.ProjectiveCone

namespace Task02

open Task01 Task01.Boundary Filter Topology

/-! ## 0. Orbits and stabilizers as sets -/

/-- Boost orbit of a vector. -/
def OrbVec (X : ℝ × ℝ) : Set (ℝ × ℝ) := {Y | ∃ θ : ℝ, boostV θ X = Y}

/-- Stabilizer (set of rapidities) of a vector. -/
def StabVec (X : ℝ × ℝ) : Set ℝ := {θ | boostV θ X = X}

/-- Boost orbit of a positive ray, inside the set of positive rays. -/
def OrbRay (X : ℝ × ℝ) : Set (Set (ℝ × ℝ)) := {S | ∃ θ : ℝ, RayPos (boostV θ X) = S}

/-- Stabilizer of a positive ray. -/
def StabRay (X : ℝ × ℝ) : Set ℝ := {θ | RayPos (boostV θ X) = RayPos X}

/-- Stabilizer of a projective class. -/
def StabProj (X : ℝ × ℝ) (hX : X ≠ 0) : Set ℝ :=
  {θ | proj (boostV θ X) ((boostV_zero_iff θ X).not.2 hX) = proj X hX}

theorem StabVec_subset_StabRay (X : ℝ × ℝ) : StabVec X ⊆ StabRay X := by
  intro θ hθ
  simp only [StabRay, Set.mem_setOf_eq]
  rw [show boostV θ X = X from hθ]

theorem StabRay_subset_StabProj (X : ℝ × ℝ) (hX : X ≠ 0) : StabRay X ⊆ StabProj X hX :=
  fun _ hθ => proj_eq_of_RayPos_eq _ _ hθ

/-! ## 1. Carrier A — the future unit timelike vector -/

/-- **A. Orbit**: the whole future unit hyperbola (Task 01 simple
transitivity). -/
theorem orbVec_fourVelocity (c : ℝ) (hc : 0 < c) (η : ℝ) :
    OrbVec (fourVelocity c η) = futureUnit c := by
  ext V
  constructor
  · rintro ⟨θ, rfl⟩
    rw [boostV_fourVelocity]
    exact fourVelocity_mem c hc _
  · intro hV
    obtain ⟨ζ, hζ, -⟩ := fourVelocity_unique c hc V hV
    exact ⟨ζ - η, by rw [boostV_fourVelocity, show η + (ζ - η) = ζ by ring, hζ]⟩

/-- **A. Stabilizer**: trivial (Task 01 `stabilizer_trivial`). -/
theorem stabVec_fourVelocity (c : ℝ) (hc : 0 < c) (η : ℝ) :
    StabVec (fourVelocity c η) = {0} := by
  ext θ
  constructor
  · exact fun hθ => stabilizer_trivial c hc η θ hθ
  · rintro rfl
    simp [StabVec, boostV_zero]

/-! ## 2. Carrier B — the timelike positive ray -/

theorem fourVelocity_fst_pos (c : ℝ) (hc : 0 < c) (η : ℝ) : 0 < (fourVelocity c η).1 :=
  mul_pos hc (Real.cosh_pos η)

/-- **B. Stabilizer**: still trivial.  Quotienting a *timelike* vector by scale
does **not** enlarge the stabilizer, because the ray meets the unit hyperbola in
exactly one point. -/
theorem stabRay_fourVelocity (c : ℝ) (hc : 0 < c) (η : ℝ) :
    StabRay (fourVelocity c η) = {0} := by
  ext θ
  constructor
  · intro hθ
    simp only [StabRay, Set.mem_setOf_eq] at hθ
    rw [boostV_fourVelocity] at hθ
    have hb := (RayPos_eq_iff_betaOf_eq (fourVelocity_fst_pos c hc (η + θ))
      (fourVelocity_fst_pos c hc η)).1 hθ
    rw [betaOf_fourVelocity c hc, betaOf_fourVelocity c hc] at hb
    have := Real.tanh_injective hb
    simpa using this
  · rintro rfl
    simp [StabRay, boostV_zero]

/-- **B. Stabilizer, projective version**: also trivial. -/
theorem stabProj_fourVelocity (c : ℝ) (hc : 0 < c) (η : ℝ) :
    StabProj (fourVelocity c η)
      (FutureCausal_ne_zero (FutureTimelike_subset
        ⟨fourVelocity_fst_pos c hc η, by rw [minkNorm_fourVelocity]; positivity⟩)) = {0} := by
  ext θ
  constructor
  · intro hθ
    simp only [StabProj, Set.mem_setOf_eq] at hθ
    have h1 : 0 < (boostV θ (fourVelocity c η)).1 := by
      rw [boostV_fourVelocity]; exact fourVelocity_fst_pos c hc _
    have hray := (proj_eq_iff_RayPos_eq h1 (fourVelocity_fst_pos c hc η)).1 hθ
    have : θ ∈ StabRay (fourVelocity c η) := hray
    rw [stabRay_fourVelocity c hc η] at this
    exact this
  · rintro rfl
    simp only [StabProj, Set.mem_setOf_eq, boostV_zero]

/-- **B. Orbit**: exactly the future timelike rays, i.e. the open interval
`(-1,1)` of direction coordinates. -/
theorem orbRay_fourVelocity (c : ℝ) (hc : 0 < c) (η : ℝ) :
    OrbRay (fourVelocity c η) = {S | ∃ β : ℝ, |β| < 1 ∧ S = RayPos (causalRep β)} := by
  ext S
  constructor
  · rintro ⟨θ, rfl⟩
    refine ⟨Real.tanh (η + θ), Real.abs_tanh_lt_one _, ?_⟩
    rw [boostV_fourVelocity, causalRep_betaOf_fourVelocity c hc]
  · rintro ⟨β, hβ, rfl⟩
    obtain ⟨ζ, hζ⟩ : ∃ ζ, Real.tanh ζ = β :=
      ⟨Real.artanh β, Real.tanh_artanh (Set.mem_Ioo.2 (abs_lt.1 hβ))⟩
    refine ⟨ζ - η, ?_⟩
    rw [boostV_fourVelocity, show η + (ζ - η) = ζ by ring,
      causalRep_betaOf_fourVelocity c hc, hζ]

/-! ## 3. Carrier C — the nonzero future null vector with fixed scale -/

/-- `K_σ(E) = (E/c) · (1, σ)`. -/
theorem nullMomentum_eq_smul (E c σ : ℝ) :
    nullMomentum E c σ = (E / c) • causalRep σ := by
  refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;>
    simp only [nullMomentum, causalRep, Prod.smul_fst, Prod.smul_snd, smul_eq_mul, mul_one]
  ring

theorem nullMomentum_fst_pos {E c : ℝ} (hE : 0 < E) (hc : 0 < c) (σ : ℝ) :
    0 < (nullMomentum E c σ).1 := div_pos hE hc

theorem nullMomentum_mem_FutureNull {E c : ℝ} (hE : 0 < E) (hc : 0 < c) {σ : ℝ}
    (hσ : σ = 1 ∨ σ = -1) : nullMomentum E c σ ∈ FutureNull :=
  ⟨nullMomentum_fst_pos hE hc σ, minkNorm_nullMomentum E c σ hσ⟩

theorem nullMomentum_ne_zero {E c : ℝ} (hE : 0 < E) (hc : 0 < c) (σ : ℝ) :
    nullMomentum E c σ ≠ 0 := by
  intro h
  have := nullMomentum_fst_pos hE hc σ
  rw [h] at this
  simp at this

/-- The boost acts on the normalized null direction `(1, σ)` by the scale
`e^{σθ}`. -/
theorem boostV_causalRep_null (θ : ℝ) {σ : ℝ} (hσ : σ = 1 ∨ σ = -1) :
    boostV θ (causalRep σ) = Real.exp (σ * θ) • causalRep σ := by
  have h1 : Real.cosh θ + Real.sinh θ = Real.exp θ := Real.cosh_add_sinh θ
  have h2 : Real.cosh θ - Real.sinh θ = Real.exp (-θ) := Real.cosh_sub_sinh θ
  rcases hσ with h | h <;> rw [h] <;>
    refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;>
    simp only [boostV, causalRep, Prod.smul_fst, Prod.smul_snd, smul_eq_mul, one_mul,
      neg_one_mul, mul_one, mul_neg]
  · linear_combination h1
  · linear_combination h1
  · linear_combination h2
  · linear_combination -h2

/-- **The Task 01 boost law for both oriented null sectors**:
`B_θ K_σ(E) = K_σ(e^{σθ} E)`. -/
theorem nullMomentum_boost_sector (E c θ : ℝ) {σ : ℝ} (hσ : σ = 1 ∨ σ = -1) :
    boostV θ (nullMomentum E c σ) = nullMomentum (Real.exp (σ * θ) * E) c σ := by
  rw [nullMomentum_eq_smul, nullMomentum_eq_smul, boostV_smul, boostV_causalRep_null θ hσ,
    smul_smul]
  congr 1
  ring

/-- **C. Stabilizer**: trivial, for either sector (Task 01's theorem, extended
to `σ = -1`). -/
theorem stabVec_nullMomentum {E c : ℝ} (hE : 0 < E) (hc : 0 < c) {σ : ℝ}
    (hσ : σ = 1 ∨ σ = -1) : StabVec (nullMomentum E c σ) = {0} := by
  ext θ
  constructor
  · intro hθ
    simp only [StabVec, Set.mem_setOf_eq, nullMomentum_boost_sector E c θ hσ] at hθ
    have h1 : Real.exp (σ * θ) * E / c = E / c := congrArg Prod.fst hθ
    have hexp : Real.exp (σ * θ) = 1 := by
      have hEc : E / c ≠ 0 := (div_pos hE hc).ne'
      have h2 : Real.exp (σ * θ) * (E / c) = 1 * (E / c) := by
        rw [one_mul, ← mul_div_assoc]; exact h1
      exact mul_right_cancel₀ hEc h2
    have hz : σ * θ = 0 := (Real.exp_eq_one_iff _).1 hexp
    have hσ0 : σ ≠ 0 := by rcases hσ with h | h <;> rw [h] <;> norm_num
    rcases mul_eq_zero.1 hz with h | h
    · exact absurd h hσ0
    · simpa using h
  · rintro rfl
    simp [StabVec, boostV_zero]

/-- **C. Orbit = the whole positive null ray.**  Both inclusions, with the
explicit rapidity `θ = σ log l` producing the prescribed positive rescaling
`l`. -/
theorem orbVec_nullMomentum (E c : ℝ) {σ : ℝ}
    (hσ : σ = 1 ∨ σ = -1) : OrbVec (nullMomentum E c σ) = RayPos (nullMomentum E c σ) := by
  ext Y
  constructor
  · rintro ⟨θ, rfl⟩
    refine ⟨Real.exp (σ * θ), Real.exp_pos _, ?_⟩
    rw [nullMomentum_boost_sector E c θ hσ]
    refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> simp [nullMomentum] <;> ring
  · rintro ⟨l, hl, rfl⟩
    refine ⟨σ * Real.log l, ?_⟩
    have hσσ : σ * (σ * Real.log l) = Real.log l := by
      rcases hσ with h | h <;> rw [h] <;> ring
    rw [nullMomentum_boost_sector E c _ hσ, hσσ, Real.exp_log hl]
    refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> simp [nullMomentum] <;> ring

/-- The positive null ray does not depend on the scale `E`: it is the ray of the
normalized null direction `(1, σ)`. -/
theorem RayPos_nullMomentum {E c : ℝ} (hE : 0 < E) (hc : 0 < c) (σ : ℝ) :
    RayPos (nullMomentum E c σ) = RayPos (causalRep σ) := by
  rw [nullMomentum_eq_smul]
  exact RayPos_smul (div_pos hE hc) _

/-! ## 4. Carriers D and E — the null ray and the projective null direction -/

/-- **D. Stabilizer of the positive null ray = the whole boost group.**  The
quotient by scale collapses the entire (nontrivial) orbit of the null vector to
a single point, so the isotropy jumps from `{0}` to `ℝ`. -/
theorem stabRay_nullMomentum {E c : ℝ} (hE : 0 < E) (hc : 0 < c) {σ : ℝ}
    (hσ : σ = 1 ∨ σ = -1) : StabRay (nullMomentum E c σ) = Set.univ := by
  ext θ
  simp only [StabRay, Set.mem_setOf_eq, Set.mem_univ, iff_true]
  rw [nullMomentum_boost_sector E c θ hσ,
    RayPos_nullMomentum (mul_pos (Real.exp_pos _) hE) hc σ,
    RayPos_nullMomentum hE hc σ]

/-- **E. Stabilizer of the projective null direction = the whole boost
group.** -/
theorem stabProj_nullMomentum {E c : ℝ} (hE : 0 < E) (hc : 0 < c) {σ : ℝ}
    (hσ : σ = 1 ∨ σ = -1) :
    StabProj (nullMomentum E c σ) (nullMomentum_ne_zero hE hc σ) = Set.univ := by
  ext θ
  simp only [Set.mem_univ, iff_true]
  refine StabRay_subset_StabProj _ _ ?_
  rw [stabRay_nullMomentum hE hc hσ]
  trivial

/-- **D. Orbit of the positive null ray = a single point.** -/
theorem orbRay_nullMomentum {E c : ℝ} (hE : 0 < E) (hc : 0 < c) {σ : ℝ}
    (hσ : σ = 1 ∨ σ = -1) :
    OrbRay (nullMomentum E c σ) = {RayPos (nullMomentum E c σ)} := by
  ext S
  constructor
  · rintro ⟨θ, rfl⟩
    have hθ : θ ∈ StabRay (nullMomentum E c σ) := by
      rw [stabRay_nullMomentum hE hc hσ]; trivial
    simpa only [Set.mem_singleton_iff] using hθ
  · rintro rfl
    exact ⟨0, by rw [boostV_zero]⟩

/-- **The collapse, stated directly**: the boost orbit of the null *vector* is a
nontrivial set (it contains vectors of every positive scale), yet its image in
the ray quotient is a single point. -/
theorem null_orbit_collapses {E c : ℝ} (hE : 0 < E) (hc : 0 < c) {σ : ℝ}
    (hσ : σ = 1 ∨ σ = -1) :
    (∃ X ∈ OrbVec (nullMomentum E c σ), X ≠ nullMomentum E c σ) ∧
      (∀ X ∈ OrbVec (nullMomentum E c σ), RayPos X = RayPos (nullMomentum E c σ)) := by
  constructor
  · refine ⟨boostV (σ * Real.log 2) (nullMomentum E c σ), ⟨_, rfl⟩, ?_⟩
    have hσσ : σ * (σ * Real.log 2) = Real.log 2 := by
      rcases hσ with h | h <;> rw [h] <;> ring
    rw [nullMomentum_boost_sector E c _ hσ, hσσ, Real.exp_log (by norm_num : (0:ℝ) < 2)]
    intro h
    have h1 : 2 * E / c = E / c := congrArg Prod.fst h
    have hEc : 0 < E / c := div_pos hE hc
    rw [mul_div_assoc] at h1
    linarith
  · rintro X ⟨θ, rfl⟩
    have hθ : θ ∈ StabRay (nullMomentum E c σ) := by
      rw [stabRay_nullMomentum hE hc hσ]; trivial
    exact hθ

/-! ## 5. Connected group versus the parity extension -/

/-- Spatial parity on four-vector components. -/
def parityV (V : ℝ × ℝ) : ℝ × ℝ := (V.1, -V.2)

@[simp] theorem minkNorm_parityV (V : ℝ × ℝ) : minkNorm (parityV V) = minkNorm V := by
  simp [minkNorm, parityV]

theorem betaOf_parityV {V : ℝ × ℝ} : betaOf (parityV V) = -betaOf V := by
  simp [betaOf, parityV, neg_div]

/-- **Parity exchanges the two oriented null sectors.** -/
theorem parityV_nullMomentum (E c : ℝ) : parityV (nullMomentum E c 1) = nullMomentum E c (-1) := by
  refine Prod.ext_iff.mpr ⟨rfl, ?_⟩
  simp [parityV, nullMomentum]

theorem parityV_causalRep (β : ℝ) : parityV (causalRep β) = causalRep (-β) := by
  refine Prod.ext_iff.mpr ⟨rfl, ?_⟩
  simp [parityV, causalRep]

/-- **The connected boost group leaves each projective null direction
invariant** (`F_θ(±1) = ±1`), whereas **parity exchanges them**.  No further
discrete structure is produced. -/
theorem null_directions_invariant_under_boosts (θ : ℝ) :
    Fmap θ 1 = 1 ∧ Fmap θ (-1) = -1 := ⟨Fmap_one θ, Fmap_neg_one θ⟩

theorem null_directions_exchanged_by_parity :
    parityV (causalRep 1) = causalRep (-1) ∧ parityV (causalRep (-1)) = causalRep 1 := by
  refine ⟨parityV_causalRep 1, ?_⟩
  rw [parityV_causalRep]
  norm_num

/-- **Timelike and null projective directions are never on the same orbit**:
`F_θ` preserves the open interval, so no boost sends a timelike direction to a
null one.  This is an orbit-type (not isotropy) distinction. -/
theorem timelike_dir_not_null_dir {β : ℝ} (hβ : |β| < 1) (θ : ℝ) :
    Fmap θ β ≠ 1 ∧ Fmap θ β ≠ -1 := by
  have h := abs_lt.1 (Fmap_mem_Ioo hβ θ)
  exact ⟨by linarith [h.2], by linarith [h.1]⟩

/-- Parity preserves the future causal cone (it does not change `V⁰`), so the
parity extension still acts on the same carrier; it is the *spatial*
orientation, not the time orientation, that it reverses. -/
theorem parityV_mem_FutureCausal {V : ℝ × ℝ} (hV : V ∈ FutureCausal) :
    parityV V ∈ FutureCausal := ⟨hV.1, by rw [minkNorm_parityV]; exact hV.2⟩

/-- Time reversal leaves the cone: it is *not* a symmetry of the future causal
cone.  Every statement above therefore depends on the fixed Task 01 time
orientation. -/
theorem timeReversal_not_mem_FutureCausal {V : ℝ × ℝ} (hV : V ∈ FutureCausal) :
    ((-V.1, V.2) : ℝ × ℝ) ∉ FutureCausal := by
  intro h
  have h1 : 0 < -V.1 := h.1
  linarith [hV.1]

/-! ## 6. Carrier-specific boundary-symmetry summary -/

/-- **Deliverable: the carrier-specific answer to "does any additional boundary
symmetry follow?"**

* timelike vector: stabilizer `{0}`;
* timelike ray: stabilizer `{0}` (no change under the scale quotient);
* null vector: stabilizer `{0}`;
* null ray: stabilizer `ℝ` (the scale quotient *does* change it);
* projective null direction: stabilizer `ℝ`.

So the Task 01 sentence "no additional boundary symmetry follows" is correct for
the *vector* carrier and false for the *ray/projective* carrier. -/
theorem boundary_symmetry_carrier_specific {E c : ℝ} (hE : 0 < E) (hc : 0 < c) (η : ℝ)
    {σ : ℝ} (hσ : σ = 1 ∨ σ = -1) :
    StabVec (fourVelocity c η) = {0} ∧
      StabRay (fourVelocity c η) = {0} ∧
      StabVec (nullMomentum E c σ) = {0} ∧
      StabRay (nullMomentum E c σ) = Set.univ ∧
      StabProj (nullMomentum E c σ) (nullMomentum_ne_zero hE hc σ) = Set.univ :=
  ⟨stabVec_fourVelocity c hc η, stabRay_fourVelocity c hc η,
   stabVec_nullMomentum hE hc hσ, stabRay_nullMomentum hE hc hσ,
   stabProj_nullMomentum hE hc hσ⟩

end Task02
