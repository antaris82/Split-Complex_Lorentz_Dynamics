/-
# Task 02 — The projectivized future causal cone

We define the future causal, future timelike and nonzero future null cones with
respect to the Task 01 time orientation (`V⁰ > 0`), and prove:

* every future causal vector has a unique normalized representative `(1, β)`
  with `|β| ≤ 1` (`β = V¹/V⁰`, i.e. `v/c` after the Task 01 `c`-normalization);
* timelike ⟺ `|β| < 1`, null ⟺ `|β| = 1`;
* on the future cone the positive-ray quotient and the projective quotient
  *agree* (a nonzero scalar relating two future vectors is automatically
  positive), so the future projective causal cone is in explicit bijection with
  the closed interval `[-1,1]`;
* the induced boost action on `β` is the fractional-linear map
  `F_θ(β) = (β + tanh θ)/(1 + β tanh θ)`, with `F_{θ₁} ∘ F_{θ₂} = F_{θ₁+θ₂}`;
* the two boundary points `β = ±1` are *individually fixed* by every boost,
  while the interior `(-1,1)` is a single orbit;
* `[U(η)] → ` the two null projective directions as `η → ±∞`, although `U(η)`
  itself has no limit in the unit hyperbola.
-/
import RequestProject.Task02.Carriers

namespace Task02

open Task01 Task01.Boundary Filter Topology

/-! ## 1. The cones -/

/-- Future causal cone: `V⁰ > 0` and `minkNorm V ≥ 0`.  (The zero vector is
excluded by `V⁰ > 0`.) -/
def FutureCausal : Set (ℝ × ℝ) := {V | 0 < V.1 ∧ 0 ≤ minkNorm V}

/-- Future timelike cone. -/
def FutureTimelike : Set (ℝ × ℝ) := {V | 0 < V.1 ∧ 0 < minkNorm V}

/-- Nonzero future null cone. -/
def FutureNull : Set (ℝ × ℝ) := {V | 0 < V.1 ∧ minkNorm V = 0}

theorem FutureTimelike_subset : FutureTimelike ⊆ FutureCausal := fun _ h => ⟨h.1, h.2.le⟩

theorem FutureNull_subset : FutureNull ⊆ FutureCausal := fun _ h => ⟨h.1, h.2.ge⟩

theorem FutureCausal_ne_zero {V : ℝ × ℝ} (hV : V ∈ FutureCausal) : V ≠ 0 := by
  intro h
  have := hV.1
  rw [h] at this
  simp at this

/-! ## 2. The normalized causal-direction coordinate `β` -/

/-- The scale-independent direction coordinate `β = V¹/V⁰`. -/
noncomputable def betaOf (V : ℝ × ℝ) : ℝ := V.2 / V.1

/-- The normalized representative of a causal direction. -/
def causalRep (β : ℝ) : ℝ × ℝ := (1, β)

@[simp] theorem betaOf_causalRep (β : ℝ) : betaOf (causalRep β) = β := by
  simp [betaOf, causalRep]

@[simp] theorem minkNorm_causalRep (β : ℝ) : minkNorm (causalRep β) = 1 - β ^ 2 := by
  simp [minkNorm, causalRep]

/-- A future causal vector is its own time component times its normalized
representative. -/
theorem eq_smul_causalRep {V : ℝ × ℝ} (hV : 0 < V.1) : V = V.1 • causalRep (betaOf V) := by
  refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;>
    simp [causalRep, betaOf, mul_div_cancel₀, hV.ne']

theorem RayPos_eq_RayPos_causalRep {V : ℝ × ℝ} (hV : 0 < V.1) :
    RayPos V = RayPos (causalRep (betaOf V)) := by
  conv_lhs => rw [eq_smul_causalRep hV]
  exact RayPos_smul hV _

/-- **Causal ⟺ `|β| ≤ 1`.** -/
theorem mem_FutureCausal_iff {V : ℝ × ℝ} (hV : 0 < V.1) :
    V ∈ FutureCausal ↔ |betaOf V| ≤ 1 := by
  constructor
  · rintro ⟨-, h⟩
    simp only [minkNorm] at h
    rw [betaOf, abs_div, abs_of_pos hV, div_le_one hV]
    nlinarith [abs_nonneg V.2, sq_abs V.2, abs_nonneg V.1]
  · intro h
    refine ⟨hV, ?_⟩
    rw [betaOf, abs_div, abs_of_pos hV, div_le_one hV] at h
    simp only [minkNorm]
    nlinarith [abs_nonneg V.2, sq_abs V.2]

/-- **Timelike ⟺ `|β| < 1`.** -/
theorem mem_FutureTimelike_iff {V : ℝ × ℝ} (hV : 0 < V.1) :
    V ∈ FutureTimelike ↔ |betaOf V| < 1 := by
  constructor
  · rintro ⟨-, h⟩
    simp only [minkNorm] at h
    rw [betaOf, abs_div, abs_of_pos hV, div_lt_one hV]
    nlinarith [abs_nonneg V.2, sq_abs V.2, abs_nonneg V.1]
  · intro h
    refine ⟨hV, ?_⟩
    rw [betaOf, abs_div, abs_of_pos hV, div_lt_one hV] at h
    simp only [minkNorm]
    nlinarith [abs_nonneg V.2, sq_abs V.2]

/-- **Null ⟺ `|β| = 1`.** -/
theorem mem_FutureNull_iff {V : ℝ × ℝ} (hV : 0 < V.1) :
    V ∈ FutureNull ↔ |betaOf V| = 1 := by
  constructor
  · rintro ⟨-, h⟩
    simp only [minkNorm] at h
    rw [betaOf, abs_div, abs_of_pos hV, div_eq_one_iff_eq hV.ne']
    nlinarith [abs_nonneg V.2, sq_abs V.2, abs_nonneg V.1]
  · intro h
    refine ⟨hV, ?_⟩
    rw [betaOf, abs_div, abs_of_pos hV, div_eq_one_iff_eq hV.ne'] at h
    simp only [minkNorm]
    nlinarith [sq_abs V.2, h]

theorem causalRep_mem_FutureCausal {β : ℝ} (h : |β| ≤ 1) : causalRep β ∈ FutureCausal :=
  (mem_FutureCausal_iff (by simp [causalRep])).2 (by simpa using h)

theorem causalRep_mem_FutureTimelike {β : ℝ} (h : |β| < 1) : causalRep β ∈ FutureTimelike :=
  (mem_FutureTimelike_iff (by simp [causalRep])).2 (by simpa using h)

theorem causalRep_mem_FutureNull {β : ℝ} (h : |β| = 1) : causalRep β ∈ FutureNull :=
  (mem_FutureNull_iff (by simp [causalRep])).2 (by simpa using h)

/-! ## 3. Rays, projective classes and the interval `[-1,1]` -/

/-- On the future cone, equality of positive rays is equality of `β`. -/
theorem RayPos_eq_iff_betaOf_eq {V W : ℝ × ℝ} (hV : 0 < V.1) (hW : 0 < W.1) :
    RayPos V = RayPos W ↔ betaOf V = betaOf W := by
  constructor
  · intro h
    obtain ⟨l, hl, hVW⟩ := (RayPos_eq_RayPos_iff (by
      intro h0; rw [h0] at hV; simp at hV)).1 h
    have h1 : V.1 = l * W.1 := congrArg Prod.fst hVW
    have h2 : V.2 = l * W.2 := congrArg Prod.snd hVW
    rw [betaOf, betaOf, h1, h2, mul_div_mul_left _ _ hl.ne']
  · intro h
    rw [RayPos_eq_RayPos_causalRep hV, RayPos_eq_RayPos_causalRep hW, h]

/-- **On the future cone, ray and projective quotients agree**: a nonzero scalar
relating two future-pointing vectors is automatically positive.  Hence no
further information is lost by passing from positive rays to projective classes
*within the future cone*. -/
theorem proj_eq_iff_RayPos_eq {V W : ℝ × ℝ} (hV : 0 < V.1) (hW : 0 < W.1) :
    proj V (by intro h0; rw [h0] at hV; simp at hV)
        = proj W (by intro h0; rw [h0] at hW; simp at hW)
      ↔ RayPos V = RayPos W := by
  constructor
  · intro h
    obtain ⟨l, hl, hVW⟩ := (proj_eq_proj_iff _ _).1 h
    have h1 : V.1 = l * W.1 := congrArg Prod.fst hVW
    have hlpos : 0 < l := by
      rcases lt_trichotomy l 0 with hneg | hzero | hpos
      · nlinarith
      · exact absurd hzero hl
      · exact hpos
    exact (RayPos_eq_RayPos_iff (by intro h0; rw [h0] at hV; simp at hV)).2 ⟨l, hlpos, hVW⟩
  · exact fun h => proj_eq_of_RayPos_eq _ _ h

/-- The set of future causal positive rays. -/
def FutureCausalRays : Set (Set (ℝ × ℝ)) := {S | ∃ V ∈ FutureCausal, S = RayPos V}

/-- **Deliverable C: the projectivized future causal cone is the interval
`[-1,1]`.**  `β ↦ RayPos (1, β)` is a bijection from `[-1,1]` onto the set of
future causal rays; its interior `(-1,1)` is exactly the timelike part and its
two endpoints are exactly the two null directions. -/
theorem bijOn_causalRays :
    Set.BijOn (fun β : ℝ => RayPos (causalRep β)) (Set.Icc (-1) 1) FutureCausalRays := by
  refine ⟨?_, ?_, ?_⟩
  · intro β hβ
    exact ⟨causalRep β, causalRep_mem_FutureCausal (abs_le.2 ⟨hβ.1, hβ.2⟩), rfl⟩
  · intro β hβ β' hβ' h
    have := (RayPos_eq_iff_betaOf_eq (V := causalRep β) (W := causalRep β')
      (by simp [causalRep]) (by simp [causalRep])).1 h
    simpa using this
  · rintro S ⟨V, hV, rfl⟩
    refine ⟨betaOf V, ?_, (RayPos_eq_RayPos_causalRep hV.1).symm⟩
    have := (mem_FutureCausal_iff hV.1).1 hV
    exact Set.mem_Icc.2 (abs_le.1 this)

/-! ## 4. The boost action on the projective carrier -/

/-- The induced action of the boost on the direction coordinate `β`. -/
noncomputable def Fmap (θ β : ℝ) : ℝ := (β + Real.tanh θ) / (1 + β * Real.tanh θ)

theorem one_add_mul_tanh_pos {β : ℝ} (hβ : |β| ≤ 1) (θ : ℝ) : 0 < 1 + β * Real.tanh θ := by
  have h1 : |Real.tanh θ| < 1 := Real.abs_tanh_lt_one θ
  have : |β * Real.tanh θ| < 1 := by
    rw [abs_mul]
    calc |β| * |Real.tanh θ| ≤ 1 * |Real.tanh θ| := by
          exact mul_le_mul_of_nonneg_right hβ (abs_nonneg _)
      _ < 1 := by rw [one_mul]; exact h1
  have := abs_lt.1 this
  linarith [this.1]

theorem boostV_fst_eq {V : ℝ × ℝ} (hV1 : V.1 ≠ 0) (θ : ℝ) :
    (boostV θ V).1 = V.1 * Real.cosh θ * (1 + betaOf V * Real.tanh θ) := by
  have hc := (Real.cosh_pos θ).ne'
  simp only [boostV, betaOf, Real.tanh_eq_sinh_div_cosh]
  field_simp

theorem boostV_snd_eq {V : ℝ × ℝ} (hV1 : V.1 ≠ 0) (θ : ℝ) :
    (boostV θ V).2 = V.1 * Real.cosh θ * (betaOf V + Real.tanh θ) := by
  have hc := (Real.cosh_pos θ).ne'
  simp only [boostV, betaOf, Real.tanh_eq_sinh_div_cosh]
  field_simp
  ring

theorem boostV_fst_pos {V : ℝ × ℝ} (hV : V ∈ FutureCausal) (θ : ℝ) : 0 < (boostV θ V).1 := by
  have hβ := (mem_FutureCausal_iff hV.1).1 hV
  rw [boostV_fst_eq hV.1.ne' θ]
  exact mul_pos (mul_pos hV.1 (Real.cosh_pos θ)) (one_add_mul_tanh_pos hβ θ)

/-- **The boost acts on `β` by the fractional-linear map `F_θ`.**  Derived from
the Task 01 boost, not assumed. -/
theorem betaOf_boostV {V : ℝ × ℝ} (hV : V ∈ FutureCausal) (θ : ℝ) :
    betaOf (boostV θ V) = Fmap θ (betaOf V) := by
  have hne : V.1 * Real.cosh θ ≠ 0 := mul_ne_zero hV.1.ne' (Real.cosh_pos θ).ne'
  rw [betaOf, boostV_fst_eq hV.1.ne' θ, boostV_snd_eq hV.1.ne' θ, Fmap,
    mul_div_mul_left _ _ hne]

/-- The boost preserves the future causal cone, the timelike cone and the null
cone. -/
theorem boostV_mem_FutureCausal {V : ℝ × ℝ} (hV : V ∈ FutureCausal) (θ : ℝ) :
    boostV θ V ∈ FutureCausal :=
  ⟨boostV_fst_pos hV θ, by rw [minkNorm_boostV]; exact hV.2⟩

theorem boostV_mem_FutureTimelike {V : ℝ × ℝ} (hV : V ∈ FutureTimelike) (θ : ℝ) :
    boostV θ V ∈ FutureTimelike :=
  ⟨boostV_fst_pos (FutureTimelike_subset hV) θ, by rw [minkNorm_boostV]; exact hV.2⟩

theorem boostV_mem_FutureNull {V : ℝ × ℝ} (hV : V ∈ FutureNull) (θ : ℝ) :
    boostV θ V ∈ FutureNull :=
  ⟨boostV_fst_pos (FutureNull_subset hV) θ, by rw [minkNorm_boostV]; exact hV.2⟩

/-- `F_θ` preserves `[-1,1]`. -/
theorem Fmap_mem_Icc {β : ℝ} (hβ : |β| ≤ 1) (θ : ℝ) : |Fmap θ β| ≤ 1 := by
  have hden := one_add_mul_tanh_pos hβ θ
  have ht := abs_lt.1 (Real.abs_tanh_lt_one θ)
  have hb := abs_le.1 hβ
  rw [Fmap, abs_div, abs_of_pos hden, div_le_one hden]
  rcases abs_cases (β + Real.tanh θ) with ⟨h, -⟩ | ⟨h, -⟩ <;> rw [h] <;> nlinarith
      [mul_nonneg (sub_nonneg.2 hb.2) (sub_nonneg.2 ht.2.le),
       mul_nonneg (sub_nonneg.2 hb.1) (sub_nonneg.2 ht.1.le)]

/-- `F_θ` preserves the open interval, i.e. timelike directions. -/
theorem Fmap_mem_Ioo {β : ℝ} (hβ : |β| < 1) (θ : ℝ) : |Fmap θ β| < 1 := by
  have hden := one_add_mul_tanh_pos hβ.le θ
  have ht := abs_lt.1 (Real.abs_tanh_lt_one θ)
  have hb := abs_lt.1 hβ
  rw [Fmap, abs_div, abs_of_pos hden, div_lt_one hden]
  rcases abs_cases (β + Real.tanh θ) with ⟨h, -⟩ | ⟨h, -⟩ <;> rw [h] <;> nlinarith
      [mul_pos (sub_pos.2 hb.2) (sub_pos.2 ht.2),
       mul_pos (sub_pos.2 hb.1) (sub_pos.2 ht.1)]

/-- The hyperbolic tangent addition formula (not present in Mathlib). -/
theorem tanh_add (a b : ℝ) :
    Real.tanh (a + b) = (Real.tanh a + Real.tanh b) / (1 + Real.tanh a * Real.tanh b) := by
  have ha := (Real.cosh_pos a).ne'
  have hb := (Real.cosh_pos b).ne'
  have hab := (Real.cosh_pos (a + b)).ne'
  have hden : 1 + Real.tanh a * Real.tanh b
      = Real.cosh (a + b) / (Real.cosh a * Real.cosh b) := by
    rw [Real.cosh_add, Real.tanh_eq_sinh_div_cosh, Real.tanh_eq_sinh_div_cosh]
    field_simp
  rw [hden, Real.tanh_eq_sinh_div_cosh, Real.sinh_add]
  field_simp
  simp only [Real.tanh_eq_sinh_div_cosh]
  field_simp

@[simp] theorem Fmap_zero (β : ℝ) : Fmap 0 β = β := by simp [Fmap]

/-- **The two null boundary points are individually fixed by every boost.** -/
@[simp] theorem Fmap_one (θ : ℝ) : Fmap θ 1 = 1 := by
  have ht := abs_lt.1 (Real.abs_tanh_lt_one θ)
  have h : (0:ℝ) < 1 + Real.tanh θ := by linarith [ht.1]
  rw [Fmap, one_mul]
  exact div_self h.ne'

@[simp] theorem Fmap_neg_one (θ : ℝ) : Fmap θ (-1) = -1 := by
  have ht := abs_lt.1 (Real.abs_tanh_lt_one θ)
  have h : (1:ℝ) + (-1) * Real.tanh θ ≠ 0 := by intro hc; nlinarith [ht.2]
  rw [Fmap, div_eq_iff h]
  ring

/-- On the interior, `F_θ` is rapidity translation. -/
theorem Fmap_tanh (θ η : ℝ) : Fmap θ (Real.tanh η) = Real.tanh (η + θ) := by
  rw [tanh_add η θ, Fmap, mul_comm]

/-- **The group law on the projective carrier.** -/
theorem Fmap_Fmap {β : ℝ} (hβ : |β| ≤ 1) (θ₁ θ₂ : ℝ) :
    Fmap θ₁ (Fmap θ₂ β) = Fmap (θ₁ + θ₂) β := by
  rcases lt_or_eq_of_le hβ with h | h
  · obtain ⟨η, rfl⟩ : ∃ η, Real.tanh η = β :=
      ⟨Real.artanh β, Real.tanh_artanh (Set.mem_Ioo.2 (abs_lt.1 h))⟩
    rw [Fmap_tanh, Fmap_tanh, Fmap_tanh]
    congr 1
    ring
  · rcases (abs_eq (by norm_num : (0:ℝ) ≤ 1)).1 h with rfl | rfl
    · rw [Fmap_one, Fmap_one, Fmap_one]
    · rw [Fmap_neg_one, Fmap_neg_one, Fmap_neg_one]

/-- **The timelike interior is a single boost orbit**, acted on simply
transitively. -/
theorem Fmap_transitive_Ioo {β β' : ℝ} (hβ : |β| < 1) (hβ' : |β'| < 1) :
    ∃! θ : ℝ, Fmap θ β = β' := by
  obtain ⟨η, rfl⟩ : ∃ η, Real.tanh η = β :=
    ⟨Real.artanh β, Real.tanh_artanh (Set.mem_Ioo.2 (abs_lt.1 hβ))⟩
  obtain ⟨η', rfl⟩ : ∃ η', Real.tanh η' = β' :=
    ⟨Real.artanh β', Real.tanh_artanh (Set.mem_Ioo.2 (abs_lt.1 hβ'))⟩
  refine ⟨η' - η, ?_, ?_⟩
  · show Fmap (η' - η) (Real.tanh η) = Real.tanh η'
    rw [Fmap_tanh, show η + (η' - η) = η' by ring]
  · intro θ hθ
    rw [Fmap_tanh] at hθ
    have := Real.tanh_injective hθ
    linarith

/-! ## 5. The timelike-to-null projective boundary -/

/-- The normalized direction of the future unit timelike vector `U(η)`. -/
theorem betaOf_fourVelocity (c : ℝ) (hc : 0 < c) (η : ℝ) :
    betaOf (fourVelocity c η) = Real.tanh η := by
  simp only [betaOf, fourVelocity, Real.tanh_eq_sinh_div_cosh]
  rw [mul_div_mul_left _ _ hc.ne']

theorem causalRep_betaOf_fourVelocity (c : ℝ) (hc : 0 < c) (η : ℝ) :
    RayPos (fourVelocity c η) = RayPos (causalRep (Real.tanh η)) := by
  rw [RayPos_eq_RayPos_causalRep (by
    simp only [fourVelocity]
    exact mul_pos hc (Real.cosh_pos η)), betaOf_fourVelocity c hc]

/-- **The projective limit exists at `η → +∞`**: the direction coordinate tends
to the null value `+1`. -/
theorem tendsto_betaOf_fourVelocity_atTop (c : ℝ) (hc : 0 < c) :
    Tendsto (fun η => betaOf (fourVelocity c η)) atTop (𝓝 1) := by
  simp only [betaOf_fourVelocity c hc]
  exact tendsto_tanh_atTop

theorem tendsto_betaOf_fourVelocity_atBot (c : ℝ) (hc : 0 < c) :
    Tendsto (fun η => betaOf (fourVelocity c η)) atBot (𝓝 (-1)) := by
  simp only [betaOf_fourVelocity c hc]
  have h1 : Tendsto (fun η : ℝ => -η) atBot atTop := tendsto_neg_atBot_atTop
  have h2 : Tendsto (fun η : ℝ => Real.tanh (-η)) atBot (𝓝 1) := tendsto_tanh_atTop.comp h1
  have h3 : Tendsto (fun η : ℝ => -Real.tanh (-η)) atBot (𝓝 (-1)) := h2.neg
  simpa [Real.tanh_neg] using h3

/-- **But the vector itself has no limit**: `U(η)` leaves every bounded set,
so there is no limit inside the unit hyperbola.  The projective limit is a
statement about a *different carrier*. -/
theorem tendsto_fourVelocity_fst_atTop (c : ℝ) (hc : 0 < c) :
    Tendsto (fun η => (fourVelocity c η).1) atTop atTop := by
  simp only [fourVelocity]
  exact tendsto_cosh_atTop.const_mul_atTop hc

/-- The limiting directions are exactly the two future null directions. -/
theorem causalRep_one_mem_FutureNull : causalRep 1 ∈ FutureNull :=
  causalRep_mem_FutureNull (by norm_num)

theorem causalRep_neg_one_mem_FutureNull : causalRep (-1) ∈ FutureNull :=
  causalRep_mem_FutureNull (by norm_num)

/-- No finite rapidity reaches the boundary: `|tanh η| < 1` always, so
`[U(η)]` is a timelike direction for every `η`. -/
theorem fourVelocity_dir_ne_null (c : ℝ) (hc : 0 < c) (η : ℝ) :
    betaOf (fourVelocity c η) ≠ 1 ∧ betaOf (fourVelocity c η) ≠ -1 := by
  have h := abs_lt.1 (Real.abs_tanh_lt_one η)
  rw [betaOf_fourVelocity c hc]
  exact ⟨by linarith [h.2], by linarith [h.1]⟩

theorem fourVelocity_mem_FutureTimelike (c : ℝ) (hc : 0 < c) (η : ℝ) :
    fourVelocity c η ∈ FutureTimelike :=
  ⟨mul_pos hc (Real.cosh_pos η), by rw [minkNorm_fourVelocity]; positivity⟩

/-- **Deliverable C (boundary form).**  For every finite rapidity the normalized
timelike direction is interior (`|β| < 1`); as `η → ±∞` the direction coordinate
converges to the two boundary values `±1`, which are exactly the two future null
directions.  The convergence happens in the projective carrier `[-1,1]`, not in
the unit hyperbola, where `U(η)` diverges. -/
theorem projective_boundary_limits (c : ℝ) (hc : 0 < c) :
    (∀ η : ℝ, |betaOf (fourVelocity c η)| < 1) ∧
      Tendsto (fun η => betaOf (fourVelocity c η)) atTop (𝓝 1) ∧
      Tendsto (fun η => betaOf (fourVelocity c η)) atBot (𝓝 (-1)) ∧
      causalRep 1 ∈ FutureNull ∧ causalRep (-1) ∈ FutureNull ∧
      Tendsto (fun η => (fourVelocity c η).1) atTop atTop := by
  refine ⟨fun η => ?_, tendsto_betaOf_fourVelocity_atTop c hc,
    tendsto_betaOf_fourVelocity_atBot c hc, causalRep_one_mem_FutureNull,
    causalRep_neg_one_mem_FutureNull, tendsto_fourVelocity_fst_atTop c hc⟩
  rw [betaOf_fourVelocity c hc]
  exact Real.abs_tanh_lt_one η

end Task02
