/-
# Task 02 — An independent scalar phase along a timelike curve

We introduce a real phase lift `Θ(τ) = Θ₀ + Ω τ` along a timelike worldline of
constant rapidity, with `Ω ∈ ℝ` a *new* scalar parameter carrying **no** assumed
relation to any Task 01 wave parameter.  We then:

* derive `dΘ/dτ = Ω` and `dΘ/dt = Ω sech η` (the second only through the
  standard coordinate conversion `dτ/dt = sech η`);
* record the exact transformation laws of `Ω`, `Ω sech η`, `k_σ`, `ω_σ` and the
  null-coordinate factors `e^{±η}`;
* prove an **independence theorem**: independent positive rescalings
  `Ω ↦ aΩ`, `(k_σ, ω_σ) ↦ b(k_σ, ω_σ)` preserve every standard structure
  introduced so far, so no relation between `Ω` and the null-wave scale is
  derivable from those structures;
* sharpen the `sech η` versus `e^{±η}` comparison.
-/
import RequestProject.Task02.Orbits

namespace Task02

open Task01 Task01.Lorentz Task01.Kinematics Task01.Phase Task01.Boundary Filter Topology

/-! ## 1. The scalar phase and its two rates -/

/-- The real phase lift along the worldline, as a function of proper time. -/
def scalarPhase (Θ₀ Ω τ : ℝ) : ℝ := Θ₀ + Ω * τ

/-- The straight timelike worldline of constant rapidity `η` through the origin. -/
noncomputable def constRapWorldline (c η : ℝ) : ℝ → ℝ := fun t => vel c η * t

theorem deriv_constRapWorldline (c η : ℝ) :
    deriv (constRapWorldline c η) = fun _ => vel c η := by
  funext s
  have h : HasDerivAt (constRapWorldline c η) (vel c η) s := by
    simpa [constRapWorldline] using (hasDerivAt_id s).const_mul (vel c η)
  exact h.deriv

/-- Proper time along the constant-rapidity worldline: `τ(t) = t sech η`. -/
theorem properTime_constRap (c : ℝ) (hc : c ≠ 0) (η t : ℝ) :
    properTime c (constRapWorldline c η) t = sech η * t := by
  simp only [properTime, deriv_constRapWorldline, properTimeRate_vel c hc]
  simp [mul_comm]

/-- **`dΘ/dτ = Ω`** — the intrinsic rate. -/
theorem hasDerivAt_scalarPhase_properTime (Θ₀ Ω τ : ℝ) :
    HasDerivAt (fun s => scalarPhase Θ₀ Ω s) Ω τ := by
  simpa [scalarPhase] using ((hasDerivAt_id τ).const_mul Ω).const_add Θ₀

/-- **`dΘ/dt = Ω sech η`** — the coordinate rate, obtained *only* through the
standard conversion `dτ/dt = sech η`. -/
theorem hasDerivAt_scalarPhase_coordTime (c : ℝ) (hc : c ≠ 0) (Θ₀ Ω η t : ℝ) :
    HasDerivAt (fun s => scalarPhase Θ₀ Ω (properTime c (constRapWorldline c η) s))
      (Ω * sech η) t := by
  have hrw : (fun s => scalarPhase Θ₀ Ω (properTime c (constRapWorldline c η) s))
      = fun s => Θ₀ + Ω * (sech η * s) := by
    funext s
    rw [properTime_constRap c hc, scalarPhase]
  rw [hrw]
  have h : HasDerivAt (fun s : ℝ => Ω * (sech η * s)) (Ω * sech η) t := by
    have := ((hasDerivAt_id t).const_mul (sech η)).const_mul Ω
    simpa [mul_assoc] using this
  simpa using h.const_add Θ₀

/-- The intrinsic rate. -/
def rhoIntrinsic (Ω : ℝ) : ℝ := Ω

/-- The coordinate rate. -/
noncomputable def rhoCoord (Ω η : ℝ) : ℝ := Ω * sech η

/-- **The coordinate rate is the intrinsic rate times the standard conversion
factor `dτ/dt`, and nothing else.** -/
theorem rhoCoord_eq_mul_properTimeRate (c : ℝ) (hc : c ≠ 0) (Ω η : ℝ) :
    rhoCoord Ω η = rhoIntrinsic Ω * properTimeRate c (vel c η) := by
  rw [rhoCoord, rhoIntrinsic, properTimeRate_vel c hc]

@[simp] theorem rhoCoord_zero_rapidity (Ω : ℝ) : rhoCoord Ω 0 = Ω := by
  simp [rhoCoord, sech]

theorem rhoIntrinsic_const (Ω : ℝ) : rhoIntrinsic Ω = Ω := rfl

/-! ## 2. Limits of the two rates -/

theorem sech_eq_inv_cosh : sech = fun η : ℝ => (Real.cosh η)⁻¹ := by
  funext η; rw [sech, one_div]

theorem tendsto_sech_atTop : Tendsto sech atTop (𝓝 0) := by
  have h : Tendsto (fun η : ℝ => (Real.cosh η)⁻¹) atTop (𝓝 0) :=
    tendsto_cosh_atTop.inv_tendsto_atTop
  rw [sech_eq_inv_cosh]
  exact h

theorem tendsto_sech_atBot : Tendsto sech atBot (𝓝 0) := by
  have h1 : Tendsto (fun η : ℝ => -η) atBot atTop := tendsto_neg_atBot_atTop
  have h2 : Tendsto (fun η : ℝ => sech (-η)) atBot (𝓝 0) := tendsto_sech_atTop.comp h1
  have he : (fun η : ℝ => sech (-η)) = sech := by
    funext η; rw [sech, sech, Real.cosh_neg]
  rwa [he] at h2

/-- `ρ_coord → 0` as `|η| → ∞`, while `ρ_intrinsic ≡ Ω` is constant. -/
theorem tendsto_rhoCoord_atTop (Ω : ℝ) : Tendsto (rhoCoord Ω) atTop (𝓝 0) := by
  have := tendsto_sech_atTop.const_mul Ω
  simpa [rhoCoord] using this

theorem tendsto_rhoCoord_atBot (Ω : ℝ) : Tendsto (rhoCoord Ω) atBot (𝓝 0) := by
  have := tendsto_sech_atBot.const_mul Ω
  simpa [rhoCoord] using this

/-- The intrinsic rate does not vanish in the limit: it is constant. -/
theorem tendsto_rhoIntrinsic (Ω : ℝ) :
    Tendsto (fun _ : ℝ => rhoIntrinsic Ω) atTop (𝓝 Ω) := tendsto_const_nhds

/-! ## 3. The null wave sector after imposing null dispersion -/

/-- A null wave covector of sector `σ = ±1` and scale `k`: `(ω, k) = (σ c k, k)`. -/
def nullCovector (c σ k : ℝ) : ℝ × ℝ := (σ * c * k, k)

theorem nullDispersion_nullCovector (c σ k : ℝ) (hσ : σ = 1 ∨ σ = -1) :
    NullDispersion c (nullCovector c σ k).1 (nullCovector c σ k).2 := by
  rcases hσ with rfl | rfl <;> simp only [NullDispersion, nullCovector] <;> ring

/-- **The remaining continuous freedom of a null sector is exactly one scale.**
After imposing null dispersion, a covector of the oriented sector `σ` is
`(ω, k) = (σ c k, k)` up to the overall sign, so `k` is the single remaining
continuous parameter. -/
theorem nullSector_one_parameter (c σ ω k : ℝ) (hσ : σ = 1 ∨ σ = -1) :
    NullDispersion c ω k ↔ (ω = σ * c * k ∨ ω = -(σ * c * k)) := by
  rw [nullDispersion_iff]
  rcases hσ with rfl | rfl
  · constructor
    · rintro (h | h)
      · left; rw [h]; ring
      · right; rw [h]; ring
    · rintro (h | h)
      · left; rw [h]; ring
      · right; rw [h]; ring
  · constructor
    · rintro (h | h)
      · right; rw [h]; ring
      · left; rw [h]; ring
    · rintro (h | h)
      · right; rw [h]; ring
      · left; rw [h]; ring

/-- **The boost law of the null wave scale**: `k_σ ↦ e^{σθ} k_σ`, hence also
`ω_σ ↦ e^{σθ} ω_σ`.  Derived from the Task 01 `waveBoost`. -/
theorem waveBoost_nullCovector (c : ℝ) (hc : c ≠ 0) (θ k : ℝ) {σ : ℝ}
    (hσ : σ = 1 ∨ σ = -1) :
    waveBoost c θ (nullCovector c σ k) = nullCovector c σ (Real.exp (σ * θ) * k) := by
  have h1 : Real.cosh θ + Real.sinh θ = Real.exp θ := Real.cosh_add_sinh θ
  have h2 : Real.cosh θ - Real.sinh θ = Real.exp (-θ) := Real.cosh_sub_sinh θ
  rcases hσ with rfl | rfl <;>
    refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;>
    simp only [waveBoost, nullCovector, one_mul, neg_mul] <;>
    field_simp
  · linear_combination k * h1
  · linear_combination k * h1
  · linear_combination (-k) * h2
  · linear_combination k * h2

/-! ## 4. Transformation table (Deliverable E) -/

/-- `Ω` is a scalar invariant: it is the derivative of a scalar with respect to
proper time, and neither depends on the frame nor on the rapidity. -/
theorem Omega_invariant (Θ₀ Ω : ℝ) (τ θ : ℝ) :
    HasDerivAt (fun s => scalarPhase Θ₀ Ω s) Ω τ ∧
      HasDerivAt (fun s => scalarPhase Θ₀ Ω s) Ω (τ + θ) :=
  ⟨hasDerivAt_scalarPhase_properTime Θ₀ Ω τ, hasDerivAt_scalarPhase_properTime Θ₀ Ω (τ + θ)⟩

/-- `Ω sech η` is **not** a boost invariant: boosting the worldline by `θ`
replaces it by `Ω sech (η + θ)`, and these agree only in the two degenerate
cases `θ = 0` and `θ = -2η` (the reflection `η ↦ -η`, for which `sech` — an even
function — cannot see the difference; the signed coordinate `tanh` does). -/
theorem rhoCoord_eq_iff {Ω : ℝ} (hΩ : Ω ≠ 0) (η θ : ℝ) :
    rhoCoord Ω (η + θ) = rhoCoord Ω η ↔ (θ = 0 ∨ θ = -2 * η) := by
  have hc1 := (Real.cosh_pos (η + θ)).ne'
  have hc2 := (Real.cosh_pos η).ne'
  constructor
  · intro h
    have hstep : Ω * (Real.cosh (η + θ))⁻¹ = Ω * (Real.cosh η)⁻¹ := by
      simpa [rhoCoord, sech, one_div] using h
    have hcosh : Real.cosh (η + θ) = Real.cosh η :=
      inv_injective (mul_left_cancel₀ hΩ hstep)
    have habs : |η + θ| = |η| :=
      le_antisymm (Real.cosh_le_cosh.1 hcosh.le) (Real.cosh_le_cosh.1 hcosh.ge)
    rcases abs_eq_abs.1 habs with h1 | h1
    · left; linarith
    · right; linarith
  · rintro (rfl | rfl)
    · rw [add_zero]
    · simp only [rhoCoord, sech]
      rw [show η + -2 * η = -η by ring, Real.cosh_neg]

/-- In particular there **exists** a boost changing the coordinate rate, so it is
not invariant. -/
theorem rhoCoord_not_invariant {Ω : ℝ} (hΩ : Ω ≠ 0) (η : ℝ) :
    ∃ θ : ℝ, rhoCoord Ω (η + θ) ≠ rhoCoord Ω η := by
  refine ⟨1 + |2 * η|, ?_⟩
  rw [Ne, rhoCoord_eq_iff hΩ]
  push_neg
  constructor
  · positivity
  · intro h
    have := abs_nonneg (2 * η)
    have h2 : |2 * η| ≥ 2 * η := le_abs_self _
    have h3 : -(2 * η) ≤ |2 * η| := neg_le_abs _
    linarith [h]

/-- The null-coordinate scale factors and the wave scale transform with the
*same* multiplicative weight `e^{σθ}`; `Ω` has weight `0`. -/
theorem weight_table (c : ℝ) (hc : c ≠ 0) (θ k E : ℝ) {σ : ℝ} (hσ : σ = 1 ∨ σ = -1) :
    waveBoost c θ (nullCovector c σ k) = nullCovector c σ (Real.exp (σ * θ) * k) ∧
      boostV θ (nullMomentum E c σ) = nullMomentum (Real.exp (σ * θ) * E) c σ :=
  ⟨waveBoost_nullCovector c hc θ k hσ, nullMomentum_boost_sector E c θ hσ⟩

/-! ## 5. The independence theorem (Deliverable F) -/

/-- Rescaling the null covector by `b > 0` preserves null dispersion. -/
theorem nullDispersion_smul (c ω k b : ℝ) (hb : b ≠ 0) :
    NullDispersion c (b * ω) (b * k) ↔ NullDispersion c ω k := by
  simp only [NullDispersion]
  constructor
  · intro h
    have hb2 : b ^ 2 ≠ 0 := pow_ne_zero 2 hb
    have : b ^ 2 * ω ^ 2 = b ^ 2 * (c ^ 2 * k ^ 2) := by ring_nf; ring_nf at h; linarith
    exact mul_left_cancel₀ hb2 this
  · intro h; rw [mul_pow, mul_pow, h]; ring

/-- Rescaling the null covector by `b` commutes with the boost law. -/
theorem waveBoost_smul (c θ b ω k : ℝ) :
    waveBoost c θ (b * ω, b * k) = (b * (waveBoost c θ (ω, k)).1, b * (waveBoost c θ (ω, k)).2) := by
  refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;> simp only [waveBoost] <;> ring

/-- Rescaling `Ω` by `a` preserves the scalar-phase structure: the intrinsic
rate is `aΩ` and the coordinate rate is `aΩ sech η`. -/
theorem scalarPhase_smul (Θ₀ Ω a τ : ℝ) :
    HasDerivAt (fun s => scalarPhase Θ₀ (a * Ω) s) (a * Ω) τ :=
  hasDerivAt_scalarPhase_properTime Θ₀ (a * Ω) τ

/-- **Underdetermination.**  Any property of the pair `(Ω, k)` that is preserved
by the independent positive rescalings `Ω ↦ aΩ`, `k ↦ bk` — and every structure
introduced so far is so preserved — is either empty on the positive quadrant or
all of it.  Hence no such structure can single out a relation between `Ω` and
the null-wave scale. -/
theorem no_canonical_cross_sector_relation (P : ℝ → ℝ → Prop)
    (hP : ∀ a b : ℝ, 0 < a → 0 < b → ∀ Ω k : ℝ, P Ω k → P (a * Ω) (b * k))
    {Ω₀ k₀ : ℝ} (hΩ₀ : 0 < Ω₀) (hk₀ : 0 < k₀) (h : P Ω₀ k₀) :
    ∀ Ω k : ℝ, 0 < Ω → 0 < k → P Ω k := by
  intro Ω k hΩ hk
  have h2 := hP (Ω / Ω₀) (k / k₀) (div_pos hΩ hΩ₀) (div_pos hk hk₀) Ω₀ k₀ h
  rwa [div_mul_cancel₀ _ hΩ₀.ne', div_mul_cancel₀ _ hk₀.ne'] at h2

/-- **A purported cross-sector equality is not rescaling invariant**, hence it is
not implied by the standard structures: it would have to be *imposed*. -/
theorem cross_sector_equality_not_invariant (c : ℝ) (hc : 0 < c) :
    ¬ (∀ a b : ℝ, 0 < a → 0 < b → ∀ Ω k : ℝ, Ω = c * k → a * Ω = c * (b * k)) := by
  intro h
  have := h 1 2 one_pos (by norm_num) c 1 (by ring)
  simp at this
  linarith

/-- The consistent pairs `(Ω, k)` form the **whole** positive quadrant: for every
`Ω > 0` and every null scale `k > 0` there is a standard configuration (a
timelike worldline with a scalar phase of rate `Ω`, together with a null
covector of scale `k` satisfying null dispersion). -/
theorem configurations_fill_quadrant (c : ℝ) (hc : 0 < c) {σ : ℝ} (hσ : σ = 1 ∨ σ = -1)
    (Ω k η Θ₀ : ℝ) :
    (∀ τ : ℝ, HasDerivAt (fun s => scalarPhase Θ₀ Ω s) Ω τ) ∧
      NullDispersion c (nullCovector c σ k).1 (nullCovector c σ k).2 ∧
      (∀ t : ℝ, HasDerivAt
        (fun s => scalarPhase Θ₀ Ω (properTime c (constRapWorldline c η) s))
        (Ω * sech η) t) :=
  ⟨fun τ => hasDerivAt_scalarPhase_properTime Θ₀ Ω τ,
   nullDispersion_nullCovector c σ k hσ,
   fun t => hasDerivAt_scalarPhase_coordTime c hc.ne' Θ₀ Ω η t⟩

/-! ## 6. `sech η` versus the null-sector boost factors -/

/-- **`sech η = e^{+η}` has the unique solution `η = 0`.** -/
theorem sech_eq_exp_iff (η : ℝ) : sech η = Real.exp η ↔ η = 0 := by
  constructor
  · intro h
    have hcosh := (Real.cosh_pos η).ne'
    have h1 : Real.exp η * Real.cosh η = 1 := by
      rw [sech] at h
      field_simp at h
      linarith [h]
    have h2 : Real.exp η * Real.exp η = 1 := by
      rw [Real.cosh_eq] at h1
      have hexp : Real.exp η * Real.exp (-η) = 1 := by
        rw [← Real.exp_add]; simp
      nlinarith [h1, hexp]
    have h3 : Real.exp (η + η) = 1 := by rw [Real.exp_add]; exact h2
    have := (Real.exp_eq_one_iff _).1 h3
    linarith
  · rintro rfl
    simp [sech]

/-- **`sech η = e^{-η}` has the unique solution `η = 0`.** -/
theorem sech_eq_exp_neg_iff (η : ℝ) : sech η = Real.exp (-η) ↔ η = 0 := by
  constructor
  · intro h
    have hcosh := (Real.cosh_pos η).ne'
    have h1 : Real.exp (-η) * Real.cosh η = 1 := by
      rw [sech] at h
      field_simp at h
      linarith [h]
    have hexp : Real.exp η * Real.exp (-η) = 1 := by rw [← Real.exp_add]; simp
    have h2 : Real.exp (-η) * Real.exp (-η) = 1 := by
      rw [Real.cosh_eq] at h1
      nlinarith [h1, hexp]
    have h3 : Real.exp (-η + -η) = 1 := by rw [Real.exp_add]; exact h2
    have := (Real.exp_eq_one_iff _).1 h3
    linarith
  · rintro rfl
    simp [sech]

/-- `e^{+η}/sech η = (e^{2η} + 1)/2`. -/
theorem exp_div_sech (η : ℝ) :
    Real.exp η / sech η = (Real.exp (2 * η) + 1) / 2 := by
  have hmul : Real.exp η * Real.exp (-η) = 1 := exp_mul_exp_neg η
  have h2 : Real.exp (2 * η) = Real.exp η * Real.exp η := by rw [← Real.exp_add]; ring_nf
  rw [sech, Real.cosh_eq, h2]
  field_simp
  linear_combination hmul

/-- `e^{+η}/sech η = 1/(1 - tanh η) = 1/(1 - β)`. -/
theorem exp_div_sech_beta (η : ℝ) :
    Real.exp η / sech η = 1 / (1 - Real.tanh η) := by
  have hs := sech_pos η
  have ht : 1 - Real.tanh η ≠ 0 := by
    have h := abs_lt.1 (Real.abs_tanh_lt_one η); intro hc; linarith [h.2]
  rw [div_eq_div_iff hs.ne' ht, one_mul, ← exp_neg_mul_sech η, ← mul_assoc,
    exp_mul_exp_neg, one_mul]

/-- `e^{-η}/sech η = (e^{-2η} + 1)/2`. -/
theorem exp_neg_div_sech (η : ℝ) :
    Real.exp (-η) / sech η = (Real.exp (-(2 * η)) + 1) / 2 := by
  have hmul : Real.exp η * Real.exp (-η) = 1 := exp_mul_exp_neg η
  have h2 : Real.exp (-(2 * η)) = Real.exp (-η) * Real.exp (-η) := by
    rw [← Real.exp_add]; ring_nf
  rw [sech, Real.cosh_eq, h2]
  field_simp
  linear_combination hmul

/-- `e^{-η}/sech η = 1/(1 + tanh η) = 1/(1 + β)`. -/
theorem exp_neg_div_sech_beta (η : ℝ) :
    Real.exp (-η) / sech η = 1 / (1 + Real.tanh η) := by
  have hs := sech_pos η
  have ht : 1 + Real.tanh η ≠ 0 := by
    have h := abs_lt.1 (Real.abs_tanh_lt_one η); intro hc; linarith [h.1]
  rw [div_eq_div_iff hs.ne' ht, one_mul, ← exp_mul_sech η, ← mul_assoc,
    show Real.exp (-η) * Real.exp η = 1 by rw [← Real.exp_add]; simp, one_mul]

/-- Asymptotics: `e^{+η}/sech η → ∞` as `η → +∞`. -/
theorem tendsto_exp_div_sech_atTop :
    Tendsto (fun η => Real.exp η / sech η) atTop atTop := by
  have hrw : (fun η => Real.exp η / sech η) = fun η => (Real.exp (2 * η) + 1) / 2 := by
    funext η; exact exp_div_sech η
  rw [hrw]
  have hlin : Tendsto (fun η : ℝ => 2 * η) atTop atTop :=
    Filter.tendsto_id.const_mul_atTop (by norm_num)
  exact ((Real.tendsto_exp_atTop.comp hlin).atTop_add tendsto_const_nhds).atTop_div_const
    (by norm_num)

/-- Asymptotics: `e^{+η}/sech η → 1/2` as `η → -∞`. -/
theorem tendsto_exp_div_sech_atBot :
    Tendsto (fun η => Real.exp η / sech η) atBot (𝓝 (1 / 2)) := by
  have hrw : (fun η => Real.exp η / sech η) = fun η => (Real.exp (2 * η) + 1) / 2 := by
    funext η; exact exp_div_sech η
  rw [hrw]
  have hlin : Tendsto (fun η : ℝ => 2 * η) atBot atBot :=
    Filter.tendsto_id.const_mul_atBot (by norm_num)
  have h := (Real.tendsto_exp_atBot.comp hlin).add_const 1
  simpa using h.div_const 2

end Task02
