/-
# Task 02 — Precision audit of three Task 01 prose claims

Nothing in Task 01 is weakened: every Task 01 theorem is reused as stated.  What
is corrected here is the *prose* that accompanied three of them.

1. **Vanishing rate.**  Task 01 proved that `R_τ` is a bijection of `[0,c)` onto
   `(0,c]`, hence that *every* function of speed factors through it.  That is a
   statement about a coordinate change, not a uniqueness statement: we exhibit
   three *distinct* natural standard rates (`R_τ`, the closing speed, the
   Doppler rate) with the same endpoint data `R(0) = c`, `R(v) → 0`.
2. **Model C cardinality.**  The Task 01 theorem `modelC_null_two_solutions`
   lists two algebraic branches.  For `r = 0` the branches *coincide*, so the
   solution set has exactly one element; for `r ≠ 0` it has exactly two.
3. **Proper time at the null boundary.**  The Lorentz arclength functional *is*
   defined on a null line; its value is `0`; it therefore fails to be a
   nondegenerate parameter (it is not injective); and affine parameters exist
   but carry no canonical scale.  "Ceases to exist" is not the right phrase.
-/
import RequestProject.Task02.ScalarPhase

namespace Task02

open Task01 Task01.Lorentz Task01.Kinematics Task01.Phase Task01.Boundary Filter Topology

/-! ## 1. Factorization through a bijection is not equality -/

theorem Rtau_half (c : ℝ) (hc : 0 < c) : Rtau c (c / 2) = c * Real.sqrt (3 / 4) := by
  rw [Rtau, properTimeRate]
  congr 2
  field_simp
  norm_num

theorem closingSpeed_half (c : ℝ) (hc : 0 < c) : closingSpeed c (c / 2) = c * (1 / 2) := by
  rw [closingSpeed, abs_of_pos (by positivity : (0:ℝ) < c / 2)]
  ring

theorem dopplerRate_half (c : ℝ) (hc : 0 < c) :
    dopplerRate c (c / 2) = c * Real.sqrt (1 / 3) := by
  rw [dopplerRate]
  congr 2
  field_simp
  ring

theorem sqrt_three_quarters_ne_half : Real.sqrt (3 / 4) ≠ 1 / 2 := by
  intro h
  have h2 : (3 : ℝ) / 4 = (1 / 2) ^ 2 := by
    rw [← h, Real.sq_sqrt (by norm_num : (0:ℝ) ≤ 3 / 4)]
  norm_num at h2

theorem sqrt_one_third_ne_half : Real.sqrt (1 / 3) ≠ 1 / 2 := by
  intro h
  have h2 : (1 : ℝ) / 3 = (1 / 2) ^ 2 := by
    rw [← h, Real.sq_sqrt (by norm_num : (0:ℝ) ≤ 1 / 3)]
  norm_num at h2

theorem sqrt_three_quarters_ne_sqrt_one_third : Real.sqrt (3 / 4) ≠ Real.sqrt (1 / 3) := by
  intro h
  have h2 : (3 : ℝ) / 4 = 1 / 3 := by
    have e1 := Real.sq_sqrt (by norm_num : (0:ℝ) ≤ 3 / 4)
    have e2 := Real.sq_sqrt (by norm_num : (0:ℝ) ≤ 1 / 3)
    rw [← e1, ← e2, h]
  norm_num at h2

/-- **The three natural vanishing rates are pairwise distinct** on `0 < v < c`
(witnessed at `v = c/2`). -/
theorem vanishing_rates_pairwise_distinct (c : ℝ) (hc : 0 < c) :
    ∃ v ∈ Set.Ioo (0:ℝ) c,
      Rtau c v ≠ closingSpeed c v ∧ Rtau c v ≠ dopplerRate c v ∧
        closingSpeed c v ≠ dopplerRate c v := by
  refine ⟨c / 2, ⟨by positivity, by linarith⟩, ?_, ?_, ?_⟩
  · rw [Rtau_half c hc, closingSpeed_half c hc]
    exact fun h => sqrt_three_quarters_ne_half (mul_left_cancel₀ hc.ne' h)
  · rw [Rtau_half c hc, dopplerRate_half c hc]
    exact fun h => sqrt_three_quarters_ne_sqrt_one_third (mul_left_cancel₀ hc.ne' h)
  · rw [closingSpeed_half c hc, dopplerRate_half c hc]
    exact fun h => sqrt_one_third_ne_half (mul_left_cancel₀ hc.ne' h).symm

/-- **The endpoint data do not select a unique standard rate.**  All three
functions satisfy `R(0) = c` and `R(v) → 0` as `v → c⁻`, yet they differ. -/
theorem endpoint_data_do_not_select (c : ℝ) (hc : 0 < c) :
    (Rtau c 0 = c ∧ Tendsto (Rtau c) (𝓝[<] c) (𝓝 0)) ∧
      (closingSpeed c 0 = c ∧ Tendsto (closingSpeed c) (𝓝[<] c) (𝓝 0)) ∧
      (dopplerRate c 0 = c ∧ Tendsto (dopplerRate c) (𝓝[<] c) (𝓝 0)) ∧
      ∃ v ∈ Set.Ioo (0:ℝ) c, Rtau c v ≠ closingSpeed c v ∧ Rtau c v ≠ dopplerRate c v := by
  refine ⟨⟨?_, tendsto_Rtau c hc⟩, ⟨closingSpeed_zero c, tendsto_closingSpeed c hc⟩,
    ⟨dopplerRate_zero c hc, tendsto_dopplerRate c hc⟩, ?_⟩
  · simp [Rtau, properTimeRate]
  · obtain ⟨v, hv, h1, h2, -⟩ := vanishing_rates_pairwise_distinct c hc
    exact ⟨v, hv, h1, h2⟩

/-- **Factorization through a bijection carries no information.**  Task 01's
`exists_factor_through_Rtau` applies to *every* function of speed; in particular
the closing speed factors through `R_τ` and is nevertheless different from it.
So "F factors through `R_τ`" never implies "F = `R_τ`". -/
theorem factorization_is_not_equality (c : ℝ) (hc : 0 < c) :
    (∃ f : ℝ → ℝ, ∀ v ∈ Set.Ico (0:ℝ) c, closingSpeed c v = f (Rtau c v)) ∧
      ∃ v ∈ Set.Ioo (0:ℝ) c, closingSpeed c v ≠ Rtau c v := by
  refine ⟨exists_factor_through_Rtau c hc (closingSpeed c), ?_⟩
  obtain ⟨v, hv, h1, -, -⟩ := vanishing_rates_pairwise_distinct c hc
  exact ⟨v, hv, fun h => h1 h.symm⟩

/-! ## 2. The exact Model C cardinality -/

/-- The set of `(k, ω)` pairs compatible with null dispersion and with the
trajectory-local observable `r` at velocity `v`. -/
def modelCNullSolutions (c v r : ℝ) : Set (ℝ × ℝ) :=
  {p : ℝ × ℝ | NullDispersion c p.2 p.1 ∧ obs v p.1 p.2 = r}

theorem modelCNullSolutions_eq (c v r : ℝ) (hv : |v| < c) :
    modelCNullSolutions c v r =
      {(r / (v - c), c * (r / (v - c))), (r / (v + c), -(c * (r / (v + c))))} := by
  ext p
  obtain ⟨k, ω⟩ := p
  simpa [modelCNullSolutions] using modelC_null_two_solutions c v r hv k ω

/-- **`r = 0`: the two algebraic branches coincide** — there is exactly one
solution, the trivial covector `(k, ω) = (0,0)`. -/
theorem modelCNullSolutions_zero (c v : ℝ) (hv : |v| < c) :
    modelCNullSolutions c v 0 = {((0:ℝ), (0:ℝ))} := by
  rw [modelCNullSolutions_eq c v 0 hv]
  norm_num

theorem modelCNullSolutions_zero_ncard (c v : ℝ) (hv : |v| < c) :
    (modelCNullSolutions c v 0).ncard = 1 := by
  rw [modelCNullSolutions_zero c v hv, Set.ncard_singleton]

/-- **`r ≠ 0`: exactly two distinct solutions.** -/
theorem modelCNullSolutions_ncard (c v r : ℝ) (hc : 0 < c) (hv : |v| < c) (hr : r ≠ 0) :
    (modelCNullSolutions c v r).ncard = 2 := by
  obtain ⟨hv1, hv2⟩ := abs_lt.mp hv
  have hne1 : v - c ≠ 0 := by intro h; linarith
  have hne2 : v + c ≠ 0 := by intro h; linarith
  have hkne : r / (v - c) ≠ r / (v + c) := by
    intro h
    rw [div_eq_div_iff hne1 hne2] at h
    have : r * (v + c) - r * (v - c) = 0 := by linarith
    have h2 : r * (2 * c) = 0 := by linarith [this]
    rcases mul_eq_zero.1 h2 with h3 | h3
    · exact hr h3
    · linarith
  rw [modelCNullSolutions_eq c v r hv]
  refine Set.ncard_pair ?_
  intro h
  exact hkne (congrArg Prod.fst h)

/-! ## 3. Proper time at the null boundary: what is degenerate, what is undefined -/

/-- **(i) The Lorentz arclength functional is defined on a null line** (it is a
total function of the endpoint), and **(ii) its value is `0`** — this is the
Task 01 theorem. -/
theorem null_arclength_defined_and_zero (c x₀ : ℝ) (hc : 0 < c) :
    ∀ t : ℝ, properTime c (fun s => x₀ + c * s) t = 0 :=
  fun t => properTime_null_eq_zero c x₀ t hc

/-- **(iii) It is not a nondegenerate parameter**: as a function of coordinate
time it is constant, hence not injective. -/
theorem null_arclength_not_injective (c x₀ : ℝ) (hc : 0 < c) :
    ¬ Function.Injective (properTime c (fun s => x₀ + c * s)) := by
  intro hinj
  have h01 : properTime c (fun s => x₀ + c * s) 0 = properTime c (fun s => x₀ + c * s) 1 := by
    rw [properTime_null_eq_zero c x₀ 0 hc, properTime_null_eq_zero c x₀ 1 hc]
  have := hinj h01
  norm_num at this

/-- **(iv) Affine parameters exist but carry no canonical scale.**  Every
rescaling of the tangent `(1, c)` of the null line is again null, and no
rescaling has unit Lorentz norm, so the metric singles out no affine
normalization. -/
theorem null_affine_no_canonical_scale (c : ℝ) (hc : 0 < c) :
    (∀ a : ℝ, Q c (a • ((1:ℝ), c)) = 0) ∧ ¬ ∃ a : ℝ, Q c (a • ((1:ℝ), c)) = c ^ 2 := by
  have hQ : ∀ a : ℝ, Q c (a • ((1:ℝ), c)) = 0 := by
    intro a
    simp only [Q, Prod.smul_fst, Prod.smul_snd, smul_eq_mul, mul_one]
    ring
  refine ⟨hQ, ?_⟩
  rintro ⟨a, ha⟩
  rw [hQ a] at ha
  nlinarith [ha, hc]

/-- A null line does admit affine reparametrizations, and they act on the
tangent by an arbitrary scale `a` — the freedom that the metric cannot fix
(the statement holds for *every* `a`, which is exactly the point). -/
theorem null_affine_reparam (c a b : ℝ) (lam : ℝ) :
    HasDerivAt (fun s : ℝ => ((a * s + b), c * (a * s + b))) (a • ((1:ℝ), c)) lam := by
  have h1 : HasDerivAt (fun s : ℝ => a * s + b) a lam := by
    simpa using ((hasDerivAt_id lam).const_mul a).add_const b
  have h2 : HasDerivAt (fun s : ℝ => c * (a * s + b)) (c * a) lam := h1.const_mul c
  have := h1.prodMk h2
  convert this using 1
  refine Prod.ext_iff.mpr ⟨?_, ?_⟩ <;>
    simp only [Prod.smul_fst, Prod.smul_snd, smul_eq_mul, mul_one]
  ring

end Task02
