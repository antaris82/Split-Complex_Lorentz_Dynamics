# Task 01 — Foundation, Identifiability, and Null-Boundary Audit in 1+1 Lorentz Kinematics

All statements below are machine-checked in Lean 4 (Mathlib). Every named theorem
is a `theorem` in `RequestProject/Task01/`, and the whole project builds with no
`sorry`, no `axiom`, and no non-standard axioms.

## 0. Conventions fixed once and used throughout

| Item | Convention | Lean |
|---|---|---|
| Signature | `(+,-)`: `Q c (t,x) = c²t² − x²` | `Task01.Lorentz.Q` |
| Null coordinates | `u = ct + x`, `w = ct − x` (the task's `v`; renamed `w` to avoid collision with velocity) | `nullU`, `nullW` |
| Factorisation | `Q = u·w` | `Q_eq_nullU_mul_nullW` |
| Split-complex | `SC.mk a b = a + j b`, `j² = 1` | `Task01.SC` |
| Idempotents | `e± = (1 ± j)/2` | `SC.ePlus`, `SC.eMinus` |
| Algebra ↔ null coords | `toNull : a + jb ↦ (a+b, a−b)`, a ring isomorphism `SC ≃+* ℝ × ℝ` | `SC.toNull` |
| Phase | `φ = k x − ω t` | `Task01.Phase.phase` |
| Sector sign | `σ = ±1`; null condition `ω = σ c k`, sign-free `ω² = c²k²` | `NullDispersion` |
| Rapidity | `v = c tanh η`, `γ = cosh η` | `vel`, `gammaOfVel_vel` |

Notation discipline: `u`, `w` are *coordinates*; `v` is a *coordinate velocity*;
`η` is rapidity; `σ` is a sector sign. These names never collide in the Lean sources.

---

## A. Dependency graph

Arrows point from prerequisite to dependent. Layers are separated as requested.

### A.1 Algebraic layer (`SplitComplex.lean`)
```
CommRing SC ──► j (j²=1) ──► ePlus, eMinus (e±²=e±, e₊e₋=0, e₊+e₋=1)
     │                              │
     ├──► N (split norm) ───────────┼──► N_mul, N_eq_zero_iff, isUnit_iff
     │                              │
     └──► toNull : SC ≃+* ℝ×ℝ ◄─────┘
                │
                ├──► idempotent_iff   (exactly four idempotents: 0, 1, e₊, e₋)
                ├──► conj  (e₊ ↔ e₋)
                └──► prod_ringAut_eq_refl ──► ringAut_eq  (Aut(SC) = {id, conj} ≅ ℤ/2)
```
No Lorentz-geometric input is used in this layer.

### A.2 Lorentz-geometric layer (`Boost.lean`)
```
Q, bil ──► nullU, nullW ──► Q_eq_nullU_mul_nullW
   │            │
   │            └──► toSC ──► N_toSC (N ∘ toSC = Q), toNull_toSC
   │                    ▲
   │            (A.1) ──┘
   │
   ├──► nullDet ──► quad_dichotomy ──► null_isometry_dichotomy
   │                                          │
   │                                          └──► boost_classification
   │                                               (form-preserving + det=1 + orthochronous
   │                                                ⟺ (u,w) ↦ (e^{η}u, e^{−η}w))
   │
   └──► boost ──► Q_boost, boost_boost (one-parameter group), boost_det
             ├──► nullU_boost, nullW_boost   (reciprocal scaling e^{±η})
             └──► boost_toSC  ──► sexp, sexp_mul_ePlus, sexp_mul_eMinus
                                   (e^{±η} are the eigenvalues on the e± sectors)

sech, tanh_sq_add_sech_sq ──► vel, gammaOfVel_vel, rap (⟺ artanh), vel_rap/rap_vel, vel_add
tanh_eq_exp, sech_eq_exp, exp_pair_hyperbola, tanh_sech_pair_circle
                              └──► exp_pair_ne_tanh_sech_pair
```

### A.3 Trajectory layer (`ProperTime.lean`)
```
(A.2) vel, sech
   │
   ├──► properTimeRate (c v) = √(1 − v²/c²)
   ├──► properTime = ∫ Lorentz arclength ──► hasDerivAt_properTime (FTC: dτ/dt = √(1−v²/c²))
   ├──► properTimeRate_vel  (dτ/dt = sech η)
   └──► Rtau = c·dτ/dt ──► Rtau_eq_sqrt, Rtau_zero, tendsto_Rtau, vel_sq_add_Rtau_sq, Rtau_vel
                      └──► Rtau_strictAntiOn ──► Rtau_bijOn ──► exists_factor_through_Rtau
                                                             └──► factor_through_Rtau_unique
   closingSpeed, dopplerRate ──► closingSpeed_eq_of_Rtau, dopplerRate_eq_of_Rtau, dopplerRate_vel
```

### A.4 Phase layer (`Phase.lean`)
```
(A.2) boost, nullU/nullW
   │
   ├──► phase (k,ω) ──► waveBoost ──► phase_boost_invariant ──► waveCovector_unique
   │        (the covector law is *derived* from invariance of φ, not assumed)
   ├──► nullCompU, nullCompW ──► nullCompU_boost (×e^{−η}), nullCompW_boost (×e^{+η})
   └──► hasDerivAt_phaseAlong  (dφ/dt = k v − ω)  ──► obs
              │                        │
   (A.3) ─────┘ phaseRate_properTime   ├──► obs_fibre, obs_not_injective, obs_fibre_eq_line
              (dφ/dτ = γ (k v − ω))    ├──► properRate_no_extra_info
                                       └──► two_velocities_identify
```

### A.5 Dispersion layer (`Phase.lean`)
```
NullDispersion ω² = c²k² ──► nullDispersion_iff (ω = ±ck)
        ├──► null_phase_speed (|ω/k| = c for k ≠ 0)
        ├──► null_group_velocity (dω/dk = σc)
        ├──► + obs ──► modelA_unique
        ├──► + fixed k₀ ──► modelB_null_const, modelB_no_variable_speed
        └──► + obs ──► modelC_null_two_solutions
(without dispersion) ──► modelB_matches_modelA, modelC_fibre
```

### A.6 Massive layer (`Boundary.lean`)
```
minkNorm, boostV ──► fourVelocity u^μ = c(cosh η, sinh η) ──► minkNorm_fourVelocity = c²
        │                       └──► boostV_fourVelocity (η ↦ η+θ)
        ├──► fourMomentum, energy, momentum ──► energy_sq_sub (E² − c²p² = m²c⁴)
        ├──► Limit I: limitI_energy / limitI_momentum / limitI_fourMomentum → 0
        └──► Limit II: massOfRapidity, tendsto_cosh_atTop, tendsto_tanh_atTop
                     ──► limitII_mass/energy/gamma/vel/momentum/fourMomentum
```

### A.7 Null layer (`Boundary.lean`)
```
nullMomentum (E,c,σ) ──► minkNorm_nullMomentum = 0
        ├──► zero_not_nullMomentum        (Limit-I object ≠ null object)
        ├──► no_null_unit_normalisation   (no four-velocity, no rapidity for null)
        ├──► fourVelocity_ne_null
        ├──► properTime_null_eq_zero      (Lorentz arclength ≡ 0 on a null line)
        ├──► nullMomentum_boost (E ↦ e^{η}E), nullMomentum_no_rest_frame
        └──► stabilizer_null_trivial
Orbits: futureUnit ──► fourVelocity_mem, fourVelocity_unique (simple transitivity),
        stabilizer_trivial, futureUnit_disjoint_null, vel_ne_c, vel_range = (−c, c)
Sign:   parity ──► Q_parity, nullU_parity/nullW_parity ──► boost_neg_eq_parity_conj
        sexp_neg_eq_conj, vel_neg, exp_neg_swap ──► discrete_structure_is_Z2 (via SC.ringAut_eq)
```

Cross-layer dependencies are exactly: A.1 → A.2 (algebra used for null coordinates
and boost eigenvalues), A.2 → A.3, A.4, A.6; A.3 → A.4 (proper-time phase rate);
A.4 → A.5; A.6 ↔ A.7 (comparison only — the null layer is constructed independently).

---

## B. Equivalence / reparameterization map

| Description 1 | Description 2 | Explicit map | Status | Lean |
|---|---|---|---|---|
| Split-complex algebra `𝔻` | `ℝ × ℝ` with componentwise product (null-coordinate algebra) | `a + jb ↦ (a+b, a−b)`, inverse `(u,w) ↦ ((u+w)/2, (u−w)/2)` | ring isomorphism — REPARAMETERIZATION | `SC.toNull` |
| Event `(t,x)` with `Q = c²t²−x²` | `z = ct + jx` with split norm `N` | `toSC c (t,x) = ct + j x`, `N ∘ toSC = Q` | REPARAMETERIZATION | `toSC`, `N_toSC` |
| Boost matrix `(cosh η, sinh η)` acting on `(ct, x)` | multiplication by `sexp η = cosh η + j sinh η` | `boost_toSC`; on null coordinates `(u,w) ↦ (e^{η}u, e^{−η}w)` | REPARAMETERIZATION (same group) | `boost_toSC`, `nullU_boost`, `nullW_boost` |
| Reciprocal factors `(e^{+η}, e^{−η})` | eigenvalues of `sexp η` on the idempotent sectors `e₊`, `e₋` | `sexp η · e₊ = e^{η} e₊`, `sexp η · e₋ = e^{−η} e₋` | DERIVED, CANONICAL (given the labelling of `e±`) | `sexp_mul_ePlus`, `sexp_mul_eMinus` |
| Velocity `v ∈ (−c, c)` | rapidity `η ∈ ℝ` | `v = c tanh η`, `η = artanh(v/c)`; mutually inverse; additive: `η₁+η₂` ↔ velocity-addition formula | REPARAMETERIZATION (diffeomorphism, group-theoretically preferred on the `η` side) | `vel_rap`, `rap_vel`, `vel_add` |
| `(e^{+η}, e^{−η})` | `(tanh η, sech η)` | **Not** to be identified. The exact relation is `tanh η = (e^{η}−e^{−η})/(e^{η}+e^{−η})` and `sech η = 2/(e^{η}+e^{−η})`; conversely `e^{±η} = (1 ± tanh η)/sech η`. Moreover the two pairs are never equal for *any* arguments η, θ. The first pair lies on `XY = 1`, the second on `X²+Y² = 1`, and these curves are disjoint. | GENUINELY DIFFERENT functions of the *same* parameter `η`; each pair determines `η` and hence the other. | `tanh_eq_exp`, `sech_eq_exp`, `exp_pair_hyperbola`, `tanh_sech_pair_circle`, `exp_pair_ne_tanh_sech_pair` |
| Wave covector `(ω, k)` with `φ = kx − ωt` | null components `k_u = (k − ω/c)/2`, `k_w = −(k + ω/c)/2` with `φ = k_u u + k_w w` | `nullCompU`, `nullCompW`; they scale by `e^{−η}` and `e^{+η}` respectively — reciprocally to `u`, `w` | DERIVED from phase invariance; the transformation law is unique | `phase_eq_null`, `phase_boost_invariant`, `waveCovector_unique`, `nullCompU_boost`, `nullCompW_boost` |
| `R_τ(v)` | `c·sech η`, `√(c²−v²)`, `c·dτ/dt` | all equal | REPARAMETERIZATION, no new content | `Rtau_vel`, `Rtau_eq_sqrt`, `properTimeRate_vel` |
| `η ↦ −η` on boosts | parity conjugation `P ∘ B(η) ∘ P` | `boost_neg_eq_parity_conj` | DERIVED | `boost_neg_eq_parity_conj` |
| `η ↦ −η` on `SC` | split conjugation `conj`, which swaps `e₊ ↔ e₋` | `sexp (−η) = conj (sexp η)` | DERIVED | `sexp_neg_eq_conj`, `conj_ePlus`, `conj_eMinus` |

---

## C. Identifiability table

Observable class: trajectory-local phase rate(s) on a single specified timelike
trajectory with known velocity `v` (equivalently known `η`), for each sector.
The parameter-to-observable map is
`obs : (k, ω) ↦ k v − ω` (`Task01.Phase.obs`).

| Quantity | Identifiable from a single trajectory-local phase rate? | Reason (Lean) |
|---|---|---|
| `v` | Yes, if the trajectory itself is given (it is part of the specification, not inferred from phase). Not inferable from `dφ/dt` alone. | `obs` depends on `(k,ω,v)` only through `kv−ω`; `obs_fibre` |
| `η` | Yes iff `v` is, via `η = artanh(v/c)` | `rap_vel`, `vel_rap` |
| `dτ/dt` | Yes iff `v` is; it is a function of `v` alone | `properTimeRate`, `Rtau_eq_sqrt` |
| `k±` alone | **NOT_IDENTIFIABLE** | `obs_not_injective`: for every `k'` there is `ω' = ω + v(k'−k)` with the same rate |
| `ω±` alone | **NOT_IDENTIFIABLE** | same |
| combination `k± v − ω±` | Yes — it *is* the observable | `hasDerivAt_phaseAlong` |
| combination `γ (k± v − ω±) = dφ±/dτ` | Yes, but adds nothing new | `phaseRate_properTime`, `properRate_no_extra_info` |
| fibre structure | The fibre over a rate `r` is the affine line `{(s, s v − r) : s ∈ ℝ}` in the `(k,ω)` plane — one-dimensional, hence exactly one undetermined real parameter per sector | `obs_fibre_eq_line` |
| `k±, ω±` given *two* trajectories with `v₁ ≠ v₂` | Yes, uniquely | `two_velocities_identify` |
| `k±, ω±` given the rate **and** null dispersion with fixed sector sign `σ` | Yes, uniquely: `k = r/(v − σc)`, `ω = σ c k` | `modelA_unique` |
| `k±, ω±` given the rate **and** sign-free null dispersion `ω² = c²k²` | Exactly two solutions (one per sector sign) | `modelC_null_two_solutions` |

**Minimal additional inputs that remove the degeneracy** (each labelled
NEW_INPUT_REQUIRED — none is adopted as part of the theory):

1. a second timelike trajectory with a different velocity (`two_velocities_identify`);
2. imposition of the null dispersion relation together with a sector-sign choice (`modelA_unique`);
3. any direct measurement of `k` (spatial periodicity) or of `ω` (temporal periodicity) in a *specified* frame.

---

## D. Model A / B / C comparison

| | Model A: `ω± = σ c k±`, `k± = k±(v)` | Model B: `k± = k₀` fixed, `ω± = ω±(v)` | Model C: both vary |
|---|---|---|---|
| Standard-null compatible | **Yes by construction** (dispersion imposed) | **Only if `ω±` is constant.** If `k₀ ≠ 0` and `ω(·)` is continuous with `ω(v)² = c²k₀²` for all `v`, then `ω` is constant (`modelB_null_const`, by the intermediate value theorem: a continuous function valued in `{±ck₀}` cannot jump without vanishing, and `0` is excluded). So a *genuinely variable* `ω` at fixed `k₀` is **incompatible** with standard null dispersion. | Yes, but then the free function collapses: at each `v`, exactly two `(k,ω)` pairs match a given rate (`modelC_null_two_solutions`) |
| Observationally equivalent under trajectory-local phase rates | — | **Yes**: `ω(v) = k₀ v − r(v)` reproduces any target rate function `r` (`modelB_matches_modelA`) | **Yes**: for *any* prescribed `k(·)` there is a unique `ω(·)` reproducing `r` (`modelC_fibre`) |
| Mere reparameterization? | — | **No.** Trajectory-local equivalence is not equivalence of null Lorentz structures: B's phase speed is `|ω/k₀|`, which under dispersion is forced to `c` (`modelB_no_variable_speed`), so B cannot be a variable-speed null structure; and if B is *not* required to be null, it is a different (non-null) covector family. | **No** |
| Genuinely different | A is **rigid**: `σ` and `r` determine `k` and `ω` uniquely (`modelA_unique`) | B differs from A as a null structure whenever `ω` genuinely varies | C strictly contains A and B |
| Underdetermined | No (given `σ`, `r`) | No (given `k₀`, `r`) | **Yes**: residual freedom = exactly one arbitrary function `k : ℝ → ℝ` (`modelC_fibre` — for each choice of `k(·)`, `ω(·)` is unique). Dimension of residual freedom: one free real-valued function of `v` per sector; zero once null dispersion is imposed, apart from the discrete `σ = ±1`. |
| Requires new input | To *select* A over B: NEW_INPUT_REQUIRED (null dispersion is an extra constraint, not a consequence of the trajectory-local observables) | Same | Same |

**Verdict:** *MODELS A AND B ARE TRAJECTORY-LOCALLY INDISTINGUISHABLE BUT NOT
EQUIVALENT AS NULL STRUCTURES.*

### Null-dispersion discriminator (§7)

`ω² = c²k²` with `k ≠ 0` implies `|ω/k| = c` exactly (`null_phase_speed`), and
`ω = σck` gives group velocity `dω/dk = σc` (`null_group_velocity`). Therefore:

*STANDARD NULL DISPERSION EXCLUDES VARIABLE NULL PROPAGATION SPEED.*
Model B cannot represent a genuinely variable propagation speed while remaining
the same standard Lorentz-null structure (`modelB_null_const`,
`modelB_no_variable_speed`). This is strictly stronger than, and must not be
confused with, the true but weaker statement that Model B can reproduce selected
trajectory-local phase rates (`modelB_matches_modelA`).

Distinctions kept separate throughout: phase velocity `ω/k`; group velocity
`dω/dk`; coordinate velocity `v = dx/dt`; proper-time rate `dτ/dt` (dimensionless)
and `R_τ = c dτ/dt` (velocity units); Doppler rate `c e^{−η}`; trajectory-local
phase rate `kv − ω`; null propagation speed `c`.

---

## E. Limit table

Structures across the five cases. "Degenerate" = still defined but loses the
property that made it useful; "replaced" = a mathematically different object.

| Structure | `v = 0` | `0 < v < c` | `v → c⁻` (fixed `m>0`) | `m → 0⁺`, Limit I (fixed `v<c`) | `m → 0⁺`, Limit II (fixed `E>0`) | genuine `m = 0` |
|---|---|---|---|---|---|---|
| `η` | `0` | finite | divergent `|η| → ∞` | finite (unchanged, `η` fixed) | divergent | **undefined** (`no_null_unit_normalisation`, `fourVelocity_ne_null`) |
| `γ = cosh η` | `1` | finite `>1` | divergent | finite | divergent (`limitII_gamma`) | undefined |
| `v` | `0` | finite | `→ c` (never attained: `vel_ne_c`, `vel_range = (−c,c)`) | unchanged | `→ c⁻` (`limitII_vel`) | replaced by a sector sign `σ = ±1` |
| `dτ/dt`, `R_τ` | `1`, `c` (`Rtau_zero`) | `∈ (0,c)` | `→ 0` (`tendsto_Rtau`) | unchanged (independent of `m`) | `→ 0` | Lorentz arclength `≡ 0` (`properTime_null_eq_zero`) — **not** a clock |
| `τ` (elapsed) | `= t` | finite `< t` | `→ 0` | unchanged | `→ 0` | **zero / replaced** by an affine parameter (no canonical normalisation; `no_null_unit_normalisation`) |
| `u^μ = c(cosh η, sinh η)` | `(c, 0)` | finite | divergent componentwise | unchanged | divergent | **undefined / replaced** — no unit-normalised null vector exists |
| `E = mc² cosh η` | `mc²` | finite | divergent | `→ 0` (`limitI_energy`) | **constant `= E`** (`limitII_energy`) | free positive parameter `E` |
| `p = mc sinh η` | `0` | finite | divergent | `→ 0` (`limitI_momentum`) | `→ E/c` (`limitII_momentum`) | `σE/c` |
| `p^μ` | `(mc, 0)` | finite | divergent | `→ (0,0)` (`limitI_fourMomentum`) — the **zero vector**, which is not a null momentum (`zero_not_nullMomentum`) | `→ (E/c, E/c)` = `nullMomentum E c 1` (`limitII_fourMomentum`) | `nullMomentum E c σ`, `minkNorm = 0` |
| `m` | `m` | `m` | `m` | `→ 0` | `→ 0` (`limitII_mass`) | `0` |
| mass shell | `minkNorm = m²c⁴ > 0` | same | same | degenerates to the point `0` | degenerates to the null cone | `minkNorm = 0`, cone minus origin |
| affine parametrization | proper time `τ` is canonical (up to shift) | same | same | same | same | **replaced**: only an affine class, with no canonical normalisation |
| `k±`, `ω±`, `φ±` | defined; `dφ/dt = −ω` | `dφ/dt = kv − ω` | `dφ/dt → kc − ω` (finite), `dφ/dτ = γ(kv−ω)` divergent unless `kv−ω → 0` | unchanged (`k, ω` carry no `m`) | `dφ/dτ` divergent | `k, ω` still defined on the *wave* side; a trajectory-local rate along a null line has no `dτ` version |

**Conclusion (§9):** `lim_{m→0⁺}` of the massive structure depends on the
prescription. Limit I gives the zero vector, which is *not* the `m = 0` null
structure (`zero_not_nullMomentum`). Limit II gives exactly the directly-defined
null momentum (`limitII_fourMomentum`), but `η`, `u^μ`, and `τ` do not survive:
they diverge or degenerate to `0`, and no rescaling repairs them
(`no_null_unit_normalisation`). *The absence of ordinary proper time and of an
ordinary four-velocity on a null worldline is not repaired by definition.*

---

## E′. Classification of vanishing standard rates (§8)

Quantities `R` with `R(0) = c` and `R(v) → 0` as `v → c⁻`, arising naturally
from established Lorentz structures. No functions were manufactured to fit the
two boundary conditions.

| # | `R(v)` | Definition | Covariance | Invariant / coordinate / trajectory dep. | Independent of `dτ/dt`? | Transport-velocity reading? |
|---|---|---|---|---|---|---|
| 1 | `R_τ(v) = c dτ/dt = c sech η = √(c²−v²)` | `Rtau` | frame-dependent (ratio of an invariant `dτ` to a frame time `dt`) | trajectory dependent, coordinate dependent through `dt` | — (it *is* the proper-time rate) | No: `v² + R_τ² = c²` (`vel_sq_add_Rtau_sq`) is an identity between a coordinate velocity and a proper-time rate in velocity units. Reading `R_τ` as a spatial velocity requires extra structure — **NEW_INPUT_REQUIRED** |
| 2 | `c − |v|` (closing speed to the light cone) | `closingSpeed` | frame-dependent | coordinate dependent | **No** — algebraically determined by `R_τ`: `c − √(c² − R_τ²)` (`closingSpeed_eq_of_Rtau`) | No |
| 3 | `c√((c−v)/(c+v)) = c e^{−η}` (Doppler rate / `−`-sector null scale factor) | `dopplerRate` | covariant as the `e₋`-sector eigenvalue of the boost | frame/relative-velocity dependent | **No** — `= c(c−v)/R_τ(v)` (`dopplerRate_eq_of_Rtau`, `dopplerRate_vel`) | No — it is a frequency ratio |

**General theorem (no new degree of freedom):** every function of the speed
alone on `[0,c)` factors through `R_τ`, uniquely on the rate range `(0,c]`
(`exists_factor_through_Rtau`, `factor_through_Rtau_unique`), because `R_τ` is a
strictly decreasing bijection `[0,c) → (0,c]` (`Rtau_bijOn`). Hence:

*THE APPARENT VANISHING RATE IS EXACTLY THE STANDARD PROPER-TIME RATE AND
INTRODUCES NO NEW DEGREE OF FREEDOM.* Any candidate satisfying the two boundary
conditions and depending on `v` alone is an algebraic function of `R_τ`, not an
independent structure.

---

## E″. Boundary symmetry audit (§10)

| Test | `v = 0` | `0 < v < c` | `v → c⁻` |
|---|---|---|---|
| Lorentz orbit of `u^μ` | same orbit | same orbit | limit point not in the orbit |
| Simple transitivity | the proper orthochronous boost group acts simply transitively on the future unit hyperbola (`fourVelocity_unique`) | | |
| Stabiliser / isotropy | trivial (`stabilizer_trivial`) | trivial (`stabilizer_trivial`) | — (no vector) |
| Null sector | disjoint from the mass shell (`futureUnit_disjoint_null`) | disjoint | the null orbit is a *different* orbit, with trivial stabiliser too (`stabilizer_null_trivial`) |
| Velocity range | `vel` has range exactly `(−c,c)`; `c` is never attained (`vel_ne_c`, `vel_range`) | | |

*NO ADDITIONAL BOUNDARY SYMMETRY FOLLOWS FROM THE STANDARD STRUCTURE.* In
particular `v = 0` is **not** distinguished from `0 < |v| < c` by any orbit,
stabiliser, or isotropy datum: they lie on the same orbit with the same (trivial)
stabiliser, so the intermediate regime does **not** have lower symmetry. The only
invariant distinction is the timelike/null dichotomy (different orbits, and the
null orbit is not in the closure-as-orbit of the mass shell in the sense that no
boost maps one to the other). No geometric "parallel → tilted → parallel"
narrative is supported.

## E‴. Direction and rapidity sign (§11)

| Object | Action of `η ↦ −η` | Lean |
|---|---|---|
| `v = c tanh η` | `v ↦ −v` | `vel_neg` |
| `u` coordinate / `w` coordinate | exchanged under the accompanying parity conjugation | `nullU_parity`, `nullW_parity` |
| null scale factors `(e^{+η}, e^{−η})` | swapped | `exp_neg_swap` |
| `e₊`, `e₋` | swapped by `conj`, and `sexp(−η) = conj(sexp η)` | `conj_ePlus`, `conj_eMinus`, `sexp_neg_eq_conj` |
| boost operator | conjugation by spatial parity: `B(−η) = P B(η) P` | `boost_neg_eq_parity_conj` |
| null propagation direction `σ` | `σ` is a separate discrete label; `η ↦ −η` acts on the *frame*, and exchanges the two oriented null sectors | `nullMomentum_boost` |

Reversing the sign of rapidity is exactly the exchange of the two oriented null
sectors, implemented by the unique nontrivial ring automorphism of `SC`. **Nothing
further follows**: `Aut(SC) = {id, conj} ≅ ℤ/2` (`SC.ringAut_eq`,
`discrete_structure_is_Z2`). No complex structure `J`, no additional paracomplex
structure, no Hodge sector and no handedness follows from the stated inputs; any
such structure is **NEW_INPUT_REQUIRED**.

---

## F. Unresolved-obligation register

| # | Statement | Classification | Note |
|---|---|---|---|
| F1 | `k±` and `ω±` separately, from a single trajectory-local phase rate | **NOT_IDENTIFIABLE** | Proved: fibres are affine lines (`obs_fibre_eq_line`) |
| F2 | Selection between Models A, B, C from trajectory-local observables | **NOT_IDENTIFIABLE** / **NEW_INPUT_REQUIRED** | Removed by a second trajectory velocity, or by imposing null dispersion + sector sign |
| F3 | Null dispersion `ω² = c²k²` | **NEW_INPUT_REQUIRED** (as a modelling constraint) | It is an *added* constraint; it is not derivable from the trajectory-local observables. Its consequences are fully derived once imposed |
| F4 | Sector sign `σ = ±1` after imposing sign-free dispersion | **NEW_INPUT_REQUIRED** (discrete) | `modelC_null_two_solutions`: exactly two solutions remain |
| F5 | Signature `(+,−)` vs `(−,+)`; `u = ct+x` vs `u = ct−x`; `φ = kx−ωt` vs `ωt−kx` | **CONVENTION_DEPENDENT** | Fixed once here; all results are stated relative to these choices |
| F6 | Labelling of `e₊` vs `e₋` (which sector carries `e^{+η}`) | **CONVENTION_DEPENDENT** | The *pairing* of `(e^{+η},e^{−η})` with the two idempotents is canonical once `j` is oriented; the orientation of `j` is a convention (the two choices are exchanged by `conj`) |
| F7 | Interpreting `R_τ` as a spatial/transport velocity | **NEW_INPUT_REQUIRED** | Explicitly labelled; `v² + R_τ² = c²` is an identity between a coordinate velocity and a proper-time rate in velocity units, not a velocity decomposition |
| F8 | A canonical affine parameter (a "clock") on a null worldline | **NOT_YET_DERIVED** / **NEW_INPUT_REQUIRED** | Lorentz arclength is identically zero (`properTime_null_eq_zero`); no unit normalisation exists (`no_null_unit_normalisation`). Not repaired by definition here |
| F9 | Any invariant distinction between `v = 0` and `0 < v < c` | **Resolved negatively** | Same orbit, trivial stabiliser in both cases |
| F10 | Additional discrete structure (`J`, handedness, Hodge sector) from `η ↦ −η` | **NEW_INPUT_REQUIRED** | Only ℤ/2 follows (`discrete_structure_is_Z2`) |
| F11 | Which prescription defines `lim_{m→0⁺}` | **CONVENTION_DEPENDENT** (prescription-dependent) | Limits I and II are inequivalent; only Limit II reaches the genuine null momentum |
| F12 | Physical/ontological content of `k`, `ω`, `R_τ`, `e±` | Out of scope by construction | No interpretation is asserted anywhere |

### Conservation-of-difficulty checks performed

* Reproducing a phase rate (`modelB_matches_modelA`) is explicitly **not** used to
  claim uniqueness of the `(k, ω)` decomposition; the fibre theorem states the
  opposite (`obs_fibre_eq_line`).
* Null dispersion is tracked as an explicit added hypothesis in every statement
  that uses it (`NullDispersion` appears as a hypothesis, never as a definition
  built into `phase` or `obs`).
* No inertia law, coupling, background, or backreaction is introduced; nothing in
  the sources depends on `dη/dt`.
* No difficulty is hidden in notation: `u`/`w` (coordinates) and `v` (velocity)
  are kept lexically distinct, and `σ` (sector sign) is never conflated with a
  velocity direction.

---

## G. Source ledger

### G.1 Imported standard results (used, not re-derived here)

| Result imported | Source | What exactly is imported |
|---|---|---|
| Real hyperbolic functions and their identities (`cosh² − sinh² = 1`, addition formulas, `tanh`, `artanh`, `arsinh`, monotonicity, `tanh → 1` machinery) | Mathlib (`Mathlib.Analysis.SpecialFunctions.Trigonometric.…`, `…Log`, `Real.artanh`, `Real.arsinh`) | Existence and the standard algebraic/analytic identities of `cosh`, `sinh`, `tanh`, `exp`, `log`, and their inverses |
| Fundamental theorem of calculus (`intervalIntegral.integral_hasDerivAt_right`) | Mathlib | Differentiation of the Lorentz arclength integral defining proper time |
| Intermediate value theorem on `uIcc` (`intermediate_value_uIcc`) | Mathlib | Used to show a continuous `{±ck₀}`-valued frequency function is constant |
| Filters/limits API (`Tendsto`, `𝓝[>]`, `atTop`) | Mathlib | Formulation of Limits I and II and of `v → c⁻` |
| Basic linear algebra of `ℝ × ℝ` and ring/field structure | Mathlib | Ambient algebra |
| Structure of the ring `ℝ × ℝ` and rigidity of `ℝ` (`Real.RingHom.unique`) | Mathlib | Ingredient of the automorphism classification |

Standard mathematics assumed as background (textbook level, not imported as Lean
lemmas but reproved here in the form used): Lorentz geometry of `ℝ^{1,1}`, the
split-complex (hyperbolic) number system, and relativistic kinematics.

### G.2 Results derived in this task (proved from scratch in Lean)

* **Algebra.** `SC` as a commutative ring; `e±` idempotents; classification of all
  idempotents (`idempotent_iff`); zero divisors = null cone (`N_eq_zero_iff`);
  units (`isUnit_iff`); `SC ≃+* ℝ × ℝ` (`toNull`); **classification of ring
  automorphisms of `SC`: exactly `{id, conj}`** (`prod_ringAut_eq_refl`, `ringAut_eq`).
* **Lorentz geometry.** `Q = u w`; the boost as split-complex multiplication
  (`boost_toSC`); invariance, group law, determinant; reciprocal null scaling
  (`nullU_boost`, `nullW_boost`); sector eigenvalues (`sexp_mul_ePlus/eMinus`);
  **derivation of the proper orthochronous boost from form-preservation + `det = 1`
  + orthochronicity** (`quad_dichotomy`, `null_isometry_dichotomy`,
  `boost_classification`); `(e^{±η})` vs `(tanh, sech)` disjointness
  (`exp_pair_ne_tanh_sech_pair`).
* **Proper time.** `dτ/dt = √(1−β²) = sech η` via FTC (`hasDerivAt_properTime`,
  `properTimeRate_vel`); `R_τ` with `R_τ(0)=c`, `R_τ → 0`, `v² + R_τ² = c²`;
  strict antitonicity and bijectivity; **factorisation theorem**
  (`exists_factor_through_Rtau`, `factor_through_Rtau_unique`); closing speed and
  Doppler rate as algebraic functions of `R_τ`.
* **Phases.** Derivation (not assumption) of the wave-covector transformation from
  phase invariance, with uniqueness (`waveCovector_unique`); null-sector components
  scaling by `e^{∓η}`; `dφ/dt = kv − ω` (`hasDerivAt_phaseAlong`); `dφ/dτ = γ(kv−ω)`.
* **Identifiability.** Fibres of `obs` are affine lines; non-injectivity; proper-time
  rate adds nothing; two distinct velocities identify `(k,ω)`.
* **Models.** `modelA_unique`, `modelB_matches_modelA`, `modelB_null_const`,
  `modelB_no_variable_speed`, `modelC_fibre`, `modelC_null_two_solutions`;
  `null_phase_speed`, `null_group_velocity`.
* **Massive/null boundary.** Limit I and Limit II theorems; genuine null momentum;
  `zero_not_nullMomentum`; `no_null_unit_normalisation`; `properTime_null_eq_zero`;
  `nullMomentum_boost`, `nullMomentum_no_rest_frame`.
* **Symmetry.** Simple transitivity on the mass shell (`fourVelocity_unique`);
  trivial stabilisers (timelike and null); orbit disjointness; `vel_range = (−c,c)`.
* **Rapidity sign.** `boost_neg_eq_parity_conj`, `sexp_neg_eq_conj`, `vel_neg`,
  `discrete_structure_is_Z2`.

---

## Summary verdicts (acceptance criterion, §15)

1. Dependency relations: section A.
2. Genuinely different vs equivalent: section B and D — *MODELS A AND B ARE
   TRAJECTORY-LOCALLY INDISTINGUISHABLE BUT NOT EQUIVALENT AS NULL STRUCTURES.*
3. Non-identifiability: *THE OBSERVABLE DOES NOT IDENTIFY `k` AND `ω` SEPARATELY*;
   the fibres are one-dimensional affine lines.
4. Effect of null dispersion: it removes the entire continuous fibre, leaving only
   the discrete sector sign — and *STANDARD NULL DISPERSION EXCLUDES VARIABLE NULL
   PROPAGATION SPEED.*
5. Vanishing standard quantities: `R_τ` and (algebraic functions of it) the closing
   speed and the Doppler rate — *THE APPARENT VANISHING RATE IS EXACTLY THE STANDARD
   PROPER-TIME RATE AND INTRODUCES NO NEW DEGREE OF FREEDOM.*
6. Massive/null boundary: `η`, `u^μ`, `τ` cease to exist at `m = 0`; the two
   `m → 0⁺` prescriptions are inequivalent; only Limit II reaches the null momentum.
7. Remaining questions requiring new input: register F — *NEW INPUT IS REQUIRED* for
   F3, F4, F7, F8, F10.
8. Symmetry: *NO ADDITIONAL BOUNDARY SYMMETRY FOLLOWS FROM THE STANDARD STRUCTURE.*
