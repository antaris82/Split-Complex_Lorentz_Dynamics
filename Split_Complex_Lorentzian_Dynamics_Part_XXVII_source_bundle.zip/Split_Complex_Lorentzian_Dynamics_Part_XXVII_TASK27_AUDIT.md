# TASK XXVII AUDIT — Topological coherence of the varying frame family

**Status: Priority 1 complete, Priority 2 complete, Priority 3 complete.
Focused build green, whole-project build green, no `sorry`, no custom axiom.**

---

## 0. Toolchain and provenance

| Item | Value |
| --- | --- |
| Lean | `leanprover/lean4:v4.28.0` (`lean-toolchain`, unchanged) |
| Mathlib | `v4.28.0` tag, as pinned in `lakefile.toml` / `lake-manifest.json` (unchanged) |
| New modules | `RequestProject/NullSectorTask27/` — 10 files, 2594 lines |
| Inherited source | Tasks I–XXVI: **not modified** (`git diff` touches no earlier file) |
| Imports of the layer | `RequestProject.NullSectorTask26.Task26` only (which transitively imports `Mathlib`) |

Module chain (strictly linear):

```
ModelTopology → AtlasTopology → AtlasExtension → FiberTopology → FrameTopology
              → ContinuousTransitions → FrameRightAction → ReverseReconstruction
              → TopologicalFrameFamily → Task27
```

(`FiberTopology` imports `AtlasTopology`; `FrameTopology` imports both `AtlasExtension` and
`FiberTopology`. Every other arrow is a single import.)

Scope firewall check: the layer contains **no** lifted/double-cover frame family, **no**
lifted transition system, **no** spin structure, **no** principal-bundle axiom, **no**
imported vector-bundle or frame-bundle object, **no** characteristic class, **no** cohomology,
**no** connection, **no** smooth structure, and **no** Čech language. Grep-checkable: the
strings `SpinStructure`, `FiberBundle`, `VectorBundle`, `Cech` do not occur in
`RequestProject/NullSectorTask27/` (the only occurrence of "Čech" is the prose sentence
recording that Čech language is *not* used).

Base assumptions: `B` is an arbitrary topological space. It is **not** assumed to be a
manifold, connected, Hausdorff, paracompact, second countable, or locally compact. No proof
in the layer forced any such assumption (item 17–18: no isolated extra assumption was
needed).

---

## 1. Exact definitions

### 1.1 Package B — the total fibre carrier and admissible topologies

```lean
def Total (C : B → Type v) : Type max u v := Σ b : B, C b
def totalBase (C : B → Type v) : Total C → B := fun x => x.1
```

`Total` is a **plain definition**, not an abbreviation: this deliberately blocks instance
search from finding the automatic `Sigma` topology, so a topology on the total carrier can
only ever enter as an explicit datum (items 26–28).

```lean
structure ChartAtlas (C : B → Type v) (M : Type w) [TopologicalSpace M] (ι : Type t) where
  U                    : ι → Set B
  isOpen_U             : ∀ i, IsOpen (U i)
  cover                : ∀ b : B, ∃ i, b ∈ U i
  chart                : ∀ (i : ι) (b : U i), C (b : B) ≃ M
  continuousOn_overlap : ∀ i j : ι,
    ContinuousOn (ovMap U chart i j) {p : (U i) × M | (p.1 : B) ∈ U j}

structure ChartAtlas.IsAdmissible [TopologicalSpace (Total C)] : Prop where
  continuous_base      : Continuous (totalBase C)
  continuous_chart     : ∀ i, Continuous (A.chartFun i)
  continuous_chartSymm : ∀ i, Continuous (A.chartSymm i)

def ChartAtlas.top : TopologicalSpace (Total C) :=
  ⨆ i : ι, TopologicalSpace.coinduced (A.psi i) inferInstance
```

`A.psi i : (U i) × M → Total C` is the inverse chart followed by the inclusion, so `A.top` is
exactly "open iff open in every local product chart" (item 46), stated in the equivalent
supremum-of-coinduced form; `ChartAtlas.isOpen_top_iff` proves the two descriptions agree.

### 1.2 Package C — topological metric-oriented fibre trivializations

```lean
structure TopologicalFibreTriv [τtot : TopologicalSpace (Total E)]
    (F : MetricOrientedRankThreeFamily B E) (U : Set B) where
  alg                  : F.LocalFibreTriv U          -- inherited Task-XXVI algebraic datum
  isOpen_dom           : IsOpen U
  continuous_chart     : Continuous (fibreChartFun alg)
  continuous_chartSymm : Continuous (fibreChartSymm alg)
```

The inherited `F.LocalFibreTriv U` carries the fibrewise `E b ≃ₗᵢ[ℝ] Model` together with the
orientation-preservation proof, so the three fibrewise requirements of item 37 are part of
the object and are re-exposed as `fibrewise_linear`, `fibrewise_isometry`,
`fibrewise_orientation`.

Both formulations of items 39–40 are present and proved equivalent:

* pointwise family + total-space continuity — the structure above;
* total-space homeomorphism — `TopologicalFibreTriv.homeo : fibrePart E U ≃ₜ ↥U × Model` and
  the converse `topologicalFibreTriv_of_homeo`.

It is **not** called a vector-bundle trivialization (item 42).

### 1.3 Package D — the metric-oriented atlas

```lean
structure MetricOrientedFibreAtlas (F : MetricOrientedRankThreeFamily B E) (ι : Type t) where
  U, isOpen_U, cover, triv, continuousOn_overlap
```

with `triv i : F.LocalFibreTriv (U i)` the inherited algebraic trivializations. Its
topologies:

```lean
noncomputable def MetricOrientedFibreAtlas.top      : TopologicalSpace (Total E)
noncomputable def MetricOrientedFibreAtlas.frameTop : TopologicalSpace (Total F.FramePlusAt)
```

### 1.4 Package I — compatible (equivariant) frame trivializations

```lean
def frameRAct (v : FramePlusOf o) (k : GvisModel) : FramePlusOf o :=
  frameEquivOfIsom (k.2.trans (frameIsom_orientation v)) modelFrame

structure TopologicalFrameTriv (F) [τfrm : TopologicalSpace (Total F.FramePlusAt)] (U) where
  frameEquiv : ∀ b : U, F.FramePlusAt (b : B) ≃ FramePlusModel
  isOpen_dom, continuous_chart, continuous_chartSymm

structure CompatibleFrameTriv (F) [τfrm] (U) extends TopologicalFrameTriv F U where
  equivariant : ∀ (b : U) (v : F.FramePlusAt (b : B)) (k : GvisModel),
    frameEquiv b (frameRAct v k) = frameRAct (frameEquiv b v) k
```

### 1.5 Packages K and N — output interfaces

```lean
structure TopologicalFrameFamily (B) [TopologicalSpace B] (E) [...] (ι) where
  family : MetricOrientedRankThreeFamily B E
  atlas  : MetricOrientedFibreAtlas family ι

structure OrdinaryTransitionSystem (B) [TopologicalSpace B] (ι) where
  U, isOpen_U, cover, g, continuous_g, g_self, g_symm, g_trans
```

`TopologicalFrameFamily` is **not** called a principal bundle (item 96); no principal-bundle
axiom is formulated anywhere in the project, so the comparison is recorded as a note only
(item 97): the derived data — a fibrewise free and transitive `GvisModel` action, local
product charts, continuous transition cocycle — is what a principal-bundle formulation would
have to reproduce, but that category is not formalized here.

### 1.6 Model topology (stop-on-hard-frontier rule)

The fixed model group `GvisModel` (Task XXVI) is topologized minimally and directly, without
importing any Lie-group development: `modelIsomTopology` is the topology of pointwise
convergence on `Model ≃ₗᵢ[ℝ] Model`, induced from `Model → Model`. Proved:
`ContinuousMul`, `ContinuousInv`, `IsTopologicalGroup GvisModel`; and
`FramePlusModel = FramePlusOf modelOrient` carries the analogous pointwise topology with
`continuous_framePlus_iff`.

---

## 2. Theorem inventory

Legend: **D** = derived in Task XXVII, **N** = negative control, **I** = interface.

### Package B — carrier and admissibility

| Name | Content |
| --- | --- |
| `fiberTotal_def` (D) | the Task-XXVII carrier *is* the dependent sum |
| `fiberBase_preimage_singleton` (D) | the fibre over `b` is exactly `{x | x.1 = b}` (item 31) |
| `ChartAtlas.isOpen_top_iff` (D) | open ⇔ open in every chart |
| `ChartAtlas.continuous_top_base` (D) | base projection continuous (item 30) |
| `MetricOrientedFibreAtlas.continuous_top_fiberBase` (D) | ditto, fibre atlas |
| `MetricOrientedFibreAtlas.continuous_top_fibreInclusion` (D) | each fibre embeds continuously |

### Package C — local product charts

| Name | Content |
| --- | --- |
| `TopologicalFibreTriv.homeo` (D) | chart is a homeomorphism onto `↥U × Model` (item 35) |
| `TopologicalFibreTriv.homeo_fst` (D) | projection compatibility (item 36) |
| `TopologicalFibreTriv.fibrewise_linear/_isometry/_orientation` (D) | item 37 |
| `topologicalFibreTriv_of_homeo` (D) | converse: the two formulations agree (items 39–40) |

### Package D — atlas-induced topology

| Name | Content |
| --- | --- |
| `MetricOrientedFibreAtlas.topTriv` (D) | every atlas chart is a genuine topological trivialization for `A.top` |
| `ChartAtlas.top_isAdmissible`, `MetricOrientedFibreAtlas.top_isAdmissible` (D) | **existence** (item 47) |
| `ChartAtlas.IsAdmissible.eq_top`, `MetricOrientedFibreAtlas.eq_top_of_isAdmissible` (D) | **uniqueness** (item 48) |
| `ChartAtlas.admissible_unique` (D) | any two admissible topologies coincide |
| `ChartAtlas.continuous_addChart(_symm)` (D) | a chart compatible with the atlas is automatically continuous for `A.top` |

### Package E — negative control on the automatic topology

| Name | Content |
| --- | --- |
| `isOpen_sigmaTop_fibre` (N, reuses Task XXVI `isOpen_sigmaFiber`) | in the automatic topology every fibre is open |
| `Example27.not_isOpen_fibre_in_atlasTop` (N) | in the atlas topology of the constant family over `ℝ` no fibre is open (items 32–33) |
| `Example27.atlasTop_ne_sigmaTop` (N) | hence the automatic topology is **not** forced by the local-product axioms (item 53) |

The example is minimal (item 55): base `ℝ`, constant fibre `Model`, a single global chart.

### Package F — frame total space

| Name | Content |
| --- | --- |
| `frameTotal_def`, `frameBase_def` (D) | the inherited Task-XXVI carrier and projection are reused unchanged (item 56) |
| `MetricOrientedFibreAtlas.ovMap_frame_vec` (D) | the frame overlap map is the fibre overlap map applied to each frame vector |
| `MetricOrientedFibreAtlas.toFrameAtlas` (D) | the induced frame atlas, with continuous overlaps |
| `MetricOrientedFibreAtlas.frameTop` (D) | the frame topology (item 57–58) |
| `frameTop_isAdmissible`, `frame_eq_top_of_isAdmissible` (D) | existence and uniqueness |
| `topologicalFibreTriv_induces_topologicalFrameTriv` (D) | **item 63**, over *any* open `U`, not only atlas domains |
| `TopologicalFrameTriv.homeo`, `homeo_fst` (D) | items 60–61 |
| `topologicalFibreTriv_induces_frameEquiv` (D) | item 62: the fibrewise part is exactly the inherited algebraic frame equivalence |

### Package G/H — continuous transition data

| Name | Content |
| --- | --- |
| `continuousOn_fibre_transition` (D) | the fibre transition map is continuous on the overlap; the proof uses the two total-space charts (items 68–69) |
| `continuousOn_frame_transition` (D) | same for the frame transition map |
| `transitionOn`, `continuous_transitionOn` (D) | `b ↦ g_ij(b) : U ∩ W → GvisModel` continuous (item 67) |
| `transitionOn_self/_symm/_trans` (D) | `g_ii = 1`, `g_ji = g_ij⁻¹`, `g_ik = g_jk * g_ij` (item 70) |
| `frameTrivAt_transitionOn` (D) | frame charts transform by the same `g_ij` (items 74–75) |
| `continuous_frame_transition` (D) | joint continuity of the action `(b, w) ↦ g_ij(b) • w` (items 76–78) |
| `MetricOrientedFibreAtlas.transitionFun` + `continuous_transitionFun`, `transitionFun_self/_symm/_trans`, `frameTrivAt_transitionFun`, `continuous_frameTransitionFun` (D) | the same package at atlas level (item 71) |

### Package I/J — reverse reconstruction and the equivalence

| Name | Content |
| --- | --- |
| `frameRAct`, `frameRAct_one/_mul`, `frameIsom_frameRAct` (D) | the right `GvisModel` action on frames |
| `existsUnique_frameRAct` (D) | the action is free and transitive |
| `frameEquivOfIsom_frameRAct` (D) | induced frame equivalences are equivariant |
| `eq_of_equivariant`, `existsUnique_isom_of_equivariant` (D) | every equivariant map of frame spaces comes from a unique orientation-preserving isometry |
| `exists_nonequivariant_frame_bijection` (N) | equivariance cannot be dropped (item 80, negative control 118) |
| `reconIso`, `reconIso_orientation` (D) | the reconstructed fibre identification (items 82–85: linear + isometric by type, orientation-preserving by theorem) |
| `frameEquivOfIsom_reconIso` (D) | it induces exactly the given frame identification |
| `reconIso_unique` (D) | **item 87**, uniqueness |
| `fibreTrivOfCompatibleFrameTriv` (D) | **item 86**, continuity of the reconstruction on the total space |
| `compatibleFrameTrivOfFibreTriv` (D) | the forward construction is equivariant (item 91) |
| `fibreTriv_roundtrip`, `frameTriv_roundtrip` (D) | the two round trips |
| `fibreTrivEquivCompatibleFrameTriv` (D) | **item 88**: `TopologicalFibreTriv U ≃ CompatibleFrameTriv U` |
| `compatibleFrameTrivOfFibreTriv_atlas` (D) | atlas level: a fibre atlas induces an equivariant frame atlas (item 91) |

### Package L — sections

| Name | Content |
| --- | --- |
| `MetricOrientedFibreAtlas.frameSection`, `continuous_frameSection` (D) | each chart gives a **continuous local** frame section (item 98) |
| `exists_continuous_global_frameSection` (D) | **conditional only** (item 100): a global topological trivialization yields a continuous global frame section |

No unconditional global frame is asserted (item 99). The converse (continuous global frame
section ⟹ global topological trivialization) did **not** follow cheaply from the established
material — it needs joint continuity of the frame transporter on the total frame space — and
is therefore listed in §8 as an unresolved obligation rather than claimed (item 101/93).

### Packages K/N — interfaces

| Name | Content |
| --- | --- |
| `TopologicalFrameFamily` (I) | base topology + fibre family + atlas, with derived topologies, charts, transition data, sections |
| `TopologicalFrameFamily.continuous_fibreBase/_frameBase` (D) | both projections continuous |
| `TopologicalFrameFamily.frameAction_free_transitive` (D) | fibrewise free and transitive frame action |
| `OrdinaryTransitionSystem` (I) | the frozen continuous cocycle (item 107) |
| `TopologicalFrameFamily.toOrdinaryTransitionSystem` (D) | every family produces one |

---

## 3. Dependency graph (Package M)

```
                    Topological base B                 varying metric-oriented rank-3 fibres
                            │                                        │
                            └──────────────────┬─────────────────────┘
                                               │
                 ┌─────────────────────────────┴──────────────────────────────┐
                 │ ALGEBRAIC BRANCH (inherited, Task XXVI, unchanged)          │
                 │   fibre structure  →  FramePlusAt  →  FrameTotal            │
                 │   LocalFibreTriv   →  frameTrivAt  →  transition (algebraic)│
                 └─────────────────────────────┬──────────────────────────────┘
                                               │
                            ✗  algebraic family  ⟹̸  topological local triviality   (item 103)
                            ✗  pointwise algebraic trivialization ⟹̸ continuous one (item 104)
                            ✗  automatic sigma topology ⟹̸ intended coherence       (item 105)
                                               │
                 ┌─────────────────────────────┴──────────────────────────────┐
                 │ TOPOLOGICAL BRANCH (extra datum, Task XXVII)                │
                 │                                                             │
                 │  MetricOrientedFibreAtlas      [EXTRA DATUM]                │
                 │        │                                                    │
                 │        ├── A.top   (fibre topology)   [DEFINITION]          │
                 │        │      ├── top_isAdmissible          [THEOREM]       │
                 │        │      └── eq_top_of_isAdmissible    [THEOREM: uniq] │
                 │        │                                                    │
                 │        ├── TopologicalFibreTriv       [DEFINITION]          │
                 │        │      └── topTriv / homeo           [THEOREM]       │
                 │        │                                                    │
                 │        ├── A.frameTop (frame topology) [DEFINITION]         │
                 │        │      └── frameTop_isAdmissible, uniqueness         │
                 │        │                                                    │
                 │        ├── topologicalFibreTriv_induces_topologicalFrameTriv│
                 │        │                                     [THEOREM]      │
                 │        ├── continuous_transitionFun          [THEOREM]      │
                 │        │      + self / symm / trans laws     [THEOREM]      │
                 │        ├── continuous_frameTransitionFun     [THEOREM]      │
                 │        │                                                    │
                 │        └── fibreTrivEquivCompatibleFrameTriv [EQUIVALENCE]  │
                 │                                                             │
                 │  Example27.atlasTop_ne_sigmaTop        [NEGATIVE RESULT]    │
                 │  exists_nonequivariant_frame_bijection [NEGATIVE RESULT]    │
                 └─────────────────────────────────────────────────────────────┘
                                               │
                                    OrdinaryTransitionSystem  [FROZEN OUTPUT]
```

Classification demanded by item 106:

* **definitions** — `Total`, `ChartAtlas`, `IsAdmissible`, `top`, `frameTop`,
  `TopologicalFibreTriv`, `TopologicalFrameTriv`, `CompatibleFrameTriv`, `frameRAct`,
  `TopologicalFrameFamily`, `OrdinaryTransitionSystem`;
* **extra data** — `TopologicalSpace B`; the atlas `MetricOrientedFibreAtlas F ι` (this is the
  ingredient Task XXVI proved to be missing);
* **theorems** — admissibility, uniqueness, continuity of the projections, the induced frame
  charts, continuity of the transition system, the overlap laws, local sections;
* **equivalences** — `topologicalFibreTriv_of_homeo` (two formulations of a chart) and
  `fibreTrivEquivCompatibleFrameTriv` (fibre ↔ equivariant frame trivializations);
* **negative results** — `atlasTop_ne_sigmaTop`, `not_isOpen_fibre_in_atlasTop`,
  `exists_nonequivariant_frame_bijection`, together with the inherited Task-XXVI controls.

### Negative controls 113–124

| # | Statement | Where |
| --- | --- | --- |
| 113 | a base topology does not determine a total-space topology | `Total` is a plain def with no instance; the atlas is a separate datum |
| 114 | the dependent sum does not carry the intended topology | `Example27.atlasTop_ne_sigmaTop` |
| 115 | fibrewise continuity is not total-space continuity | `TopologicalFibreTriv` requires total-space continuity; Task-XXVI `sigmaTopology_makes_every_algebraic_triv_continuous` shows the fibrewise notion is vacuous |
| 116 | pointwise algebraic triviality ⇏ topological triviality | inherited Task-XXVI `exists_localFibreTriv` (over *every* subset) vs. the atlas datum |
| 117 | local algebraic frames ⇏ continuous local frames | `frameSection` is continuous only because the chart is (`continuous_frameSection` uses `A.frameTop`) |
| 118 | frame charts without equivariance need not encode linear geometry | `exists_nonequivariant_frame_bijection` |
| 119 | continuous transitions are stronger than the algebraic identities | `continuous_transitionFun` is proved from chart continuity, not from `transition_trans` |
| 120 | triple-overlap identities alone do not imply local triviality | the identities hold in Task XXVI, where no topology exists |
| 121–124 | no lifted family, no double cover, no spin structure, no physical statement | absent from the layer (grep-checkable) |

---

## 4. Required decision table

| Question | Verdict |
| --- | --- |
| Base topology included explicitly? | **PROVED** (`TopologicalSpace B` explicit throughout) |
| Correct total fibre topology formalized? | **PROVED** (`MetricOrientedFibreAtlas.top`, `isOpen_top_iff`) |
| Automatic sigma topology rejected as sufficient? | **PROVED** (`isOpen_sigmaTop_fibre`, `not_isOpen_fibre_in_atlasTop`, `atlasTop_ne_sigmaTop`) |
| Base projection continuous? | **PROVED** (`continuous_top_fiberBase`, `TopologicalFrameFamily.continuous_frameBase`) |
| Genuine local product trivialization defined? | **PROVED** (`TopologicalFibreTriv`, `homeo`, `topologicalFibreTriv_of_homeo`) |
| Atlas induces total-space topology? | **PROVED** (`top_isAdmissible`, `topTriv`) |
| Atlas-induced topology unique? | **PROVED** (`eq_top_of_isAdmissible`, `admissible_unique`, `frame_eq_top_of_isAdmissible`) |
| Frame-total topology constructed? | **PROVED** (`frameTop`, `frameTop_isAdmissible`) |
| Fibre trivialization induces frame homeomorphism? | **PROVED** (`topologicalFibreTriv_induces_topologicalFrameTriv`, `TopologicalFrameTriv.homeo`) |
| Ordinary transition maps continuous? | **PROVED** (`continuous_transitionOn`, `continuous_transitionFun`) |
| Identity/inverse/triple laws preserved? | **PROVED** (`transitionFun_self`, `transitionFun_symm`, `transitionFun_trans`) |
| Compatible frame trivialization defined equivariantly? | **PROVED** (`CompatibleFrameTriv`) |
| Frame→fibre reconstruction? | **PROVED** (`fibreTrivOfCompatibleFrameTriv`, `reconIso_unique`) |
| Fibre/frame topological trivializations equivalent? | **PROVED** (`fibreTrivEquivCompatibleFrameTriv`) |
| Continuous local frame sections obtained? | **PROVED** (`continuous_frameSection`) |
| Continuous global frame guaranteed? | **NO** (only `exists_continuous_global_frameSection`, conditional) |
| Principal bundle formalized? | **NO** |
| Internal lifted family constructed? | **NO** |
| Spin structure constructed? | **NO** |

---

## 5. Transformation tables

### 5.1 Chart / transition table

| Object | Domain | Codomain | Statement |
| --- | --- | --- | --- |
| fibre chart | `fibrePart E U` | `↥U × Model` | homeomorphism (`TopologicalFibreTriv.homeo`) |
| frame chart | `framePart F U` | `↥U × FramePlusModel` | homeomorphism (`TopologicalFrameTriv.homeo`) |
| fibre transition | `↥(U_i ∩ U_j)` | `GvisModel` | continuous (`continuous_transitionFun`) |
| frame transition | `↥(U_i ∩ U_j) × FramePlusModel` | `FramePlusModel` | continuous (`continuous_frameTransitionFun`) |

### 5.2 Overlap laws (convention `g_ik = g_jk * g_ij`)

| Law | Statement |
| --- | --- |
| identity | `transitionFun i i b = 1` |
| inverse | `transitionFun j i b = (transitionFun i j b)⁻¹` |
| triple overlap | `transitionFun i k b = transitionFun j k b * transitionFun i j b` |
| frame action | `frameTrivAt (triv j) b v = transitionFun i j b • frameTrivAt (triv i) b v` |

---

## 6. Unresolved mathematical obligations

1. **Converse of the global-section diagnostic.** A continuous global frame section is not
   proved to produce a global topological trivialization. What is missing is exactly joint
   continuity of the frame transporter `(v, w) ↦ frameTransporter v w` on the total frame
   space; the pointwise statement (`existsUnique_frameRAct`) is proved. This branch was left
   open deliberately (item 102: no obstruction theory).
2. **Atlas-level converse in Package J.** `compatibleFrameTrivOfFibreTriv_atlas` gives
   fibre atlas ⟹ equivariant frame atlas; the reverse *atlas* statement is available
   pointwise-per-chart through `fibreTrivEquivCompatibleFrameTriv`, but no packaged
   `frame atlas ⟹ fibre atlas` structure map is defined, since a frame atlas would have to be
   given relative to a topology that is itself defined from a fibre atlas. Making this
   circularity-free requires an independent notion of "frame atlas topology", which is beyond
   the stated scope.
3. **No separation or covering axioms are used**, so nothing is claimed about the topological
   quality (Hausdorffness, local compactness, …) of `A.top` or `A.frameTop`.

Nothing above is required by the central success criterion, which is met in full.

---

## 7. Source ledger

### IMPORTED STANDARD RESULT (Mathlib `v4.28.0`)

| Declaration | Module | Use |
| --- | --- | --- |
| `TopologicalSpace.coinduced`, `isOpen_iSup_iff` | `Mathlib.Topology.Order`, `Mathlib.Topology.Constructions` | the atlas topology and its open-set description |
| `continuousOn_iff_continuous_restrict`, `ContinuousOn.comp_continuous` | `Mathlib.Topology.ContinuousOn` | overlap-map continuity bookkeeping |
| `Continuous.subtype_mk`, `continuous_subtype_val`, `IsOpen.isOpenMap_subtype_val`, `Subtype.image_preimage_coe` | `Mathlib.Topology.Constructions`, `Mathlib.Topology.Order` | subtype/total-space transfers |
| `Homeomorph`, `Homeomorph.apply_symm_apply` | `Mathlib.Topology.Homeomorph.Defs` | chart homeomorphisms |
| `dense_compl_singleton` | `Mathlib.Topology.Separation` | the minimal example over `ℝ` |
| `LinearIsometryEquiv` and its API (`symm_apply_apply`, `inner_map_map`, …) | `Mathlib.Analysis.InnerProductSpace.LinearMap` | fibrewise identifications |
| `Orientation`, `Orientation.map` | `Mathlib.LinearAlgebra.Orientation` | orientation datum (via Task XXVI) |
| `EuclideanSpace ℝ (Fin 3)`, `EuclideanSpace.basisFun` | `Mathlib.Analysis.InnerProductSpace.EuclideanDist` | the fixed model (via Task XXVI) |
| `IsTopologicalGroup`, `ContinuousMul`, `ContinuousInv` | `Mathlib.Topology.Algebra.Group.Basic` | the model group topology |

### INHERITED FROM TASK XXVI (unchanged)

`MetricOrientedRankThreeFamily`, `FramePlusOf`, `FramePlusAt`, `FrameTotal`, `frameBase`,
`Model`, `modelOrient`, `modelFrame`, `modelBasis`, `GvisModel`, `LocalFibreTriv`,
`frameEquivOfIsom`, `frameTrivAt`, `frameIsom`, `frameChart`, `isom_ext_of_frame`,
`isOpen_sigmaFiber`, `sigmaTopology_makes_every_algebraic_triv_continuous`,
`gvisAt_free`, `gvisAt_transitive`, `transition` and the algebraic overlap laws.

### DERIVED IN TASK XXVII

Everything listed in §2, i.e. all declarations in `RequestProject/NullSectorTask27/`.

For the standard mathematics behind the construction (an atlas of local product charts with
continuous transition functions determines a unique topology making the charts
homeomorphisms) the classical reference is N. Steenrod, *The Topology of Fibre Bundles*,
Princeton University Press, 1951, §§2–3. The Lean development does **not** import any such
machinery; the construction and both directions of the characterization are proved directly.

---

## 8. Build and axiom report

| Item | Value |
| --- | --- |
| Focused build | `lake build RequestProject.NullSectorTask27.Task27` → **green**, 8237 jobs |
| Whole-project build | `lake build` → **green**, **8308 jobs**, 0 errors |
| Task-XXVII warnings | **0** |
| Whole-project warnings | **114**, all pre-existing in earlier layers (`NullSectorTask14`, …); none in a Task-XXVII module |
| `sorry` / `admit` | none (`rg -n "sorry|admit" RequestProject/NullSectorTask27/` → no match) |
| custom axiom / `implemented_by` / `native_decide` / `bv_decide` / `unsafe` / `partial` | none |
| `#print axioms` | run on **67** principal endpoints in `Task27.lean`; each depends only on `propext`, `Classical.choice`, `Quot.sound` (a few purely definitional ones depend on no axiom at all) |

Choice is used where Task XXVI already used it (picking a frame in a fibre, `Classical.arbitrary`
in `reconIso`, `dif_pos`-style case splits on overlap membership); no further axiom occurs.

---

## 9. Failed-build ledger

Every failure encountered while building this layer is recorded. **No mathematical statement
was changed as a result of any of them**; all repairs were elaboration/plumbing fixes.

| # | Command | Error | Diagnosis | Repair | Statement changed? |
| --- | --- | --- | --- | --- | --- |
| 1 | `lake build …AtlasTopology` | `unknown identifier 'IsOpen[t]'` | `IsOpen[τ] s` / `Continuous[τ₁,τ₂] f` notation lives in the `Topology` scope | added `open Topology` | no |
| 2 | `lake build …AtlasTopology` | `failed to synthesize TopologicalSpace (Total C)` in a statement using `letI := A.top` | a `letI` in a statement does not make the instance available to later elaboration of the same statement | used explicit `@Continuous _ _ A.top _ f` / named instance binders | no |
| 3 | `lake build …FiberTopology` | `type expected` for `(U : Set B) × Model` | subtype-product must be written `↥U × Model` | rewrote the type | no |
| 4 | `lake build …FiberTopology` | `unexpected token 'in'` after a docstring | `open Classical in` / `omit … in` must *precede* the docstring | reordered | no |
| 5 | `lake build …FrameTopology` | `motive is not type correct` / `rw` pattern not found in `ovMap_apply` | the membership hypothesis `hp : p ∈ {p | …}` is not syntactically the required `(p.1 : B) ∈ U` | inserted `have hp' : (p.1 : B) ∈ … := hp`, supplied `(chart := …) (i := …) (j := …)` explicitly, and beta-reduced with `simp only [Set.mem_preimage, Set.restrict_apply]` before `rw [dif_pos hp']` | no |
| 6 | `lake build …ReverseReconstruction` | `failed to synthesize TopologicalSpace (Total F.FramePlusAt)` at a structure-instance `where` block | the structure has a named instance binder `[τfrm : …]`; `where`-notation cannot infer it | wrapped the body in `letI := A.frameTop; { … }` | no |
| 7 | `lake build …ReverseReconstruction` | `don't know how to synthesize placeholder for argument hf` | the orientation-preservation argument of `frameEquivOfIsom_frameRAct` is not determined by the expected type | supplied `((TopologicalFibreTriv.alg (τtot := A.top) Φ).orientation_preserving b)` explicitly | no |
| 8 | `lake build …ReverseReconstruction` | `Type mismatch: rfl has type ?m = ?m` in the round-trip proofs | the projections of a `letI`-built term are not reducible at `exact`-transparency | factored out `compatibleFrameTrivOfFibreTriv_frameEquiv` (proved `by rfl`) and rewrote with it | no |
| 9 | `lake build …Task27` | `failed to synthesize TopologicalSpace (Total F.FramePlusAt)` in two `abbrev`s | the instance binder referred to `F` before `F` was bound | reordered the binders (`(G : …) [TopologicalSpace (Total G.FramePlusAt)]`) | no |
| 10 | `lake build …Task27` | `compiler IR check failed … has no executable code` for `alias task27_frameRAct := frameRAct` | `alias` produces a computable `def` of a noncomputable declaration | dropped the alias; `frameRAct` is exposed directly and appears in the axiom report | no |

No proposed theorem turned out to be false, so item 139 does not apply; the only statements
deliberately *not* strengthened are recorded in §6.

---

## 10. Exact frontier after Task XXVII (Package N)

Frozen outputs, all proved:

* topological base `B` (arbitrary `TopologicalSpace`);
* total fibre topology `MetricOrientedFibreAtlas.top`;
* ordinary frame total topology `MetricOrientedFibreAtlas.frameTop`;
* open trivializing cover `A.U` with `isOpen_U`, `cover`;
* continuous ordinary transition maps `A.transitionFun i j : ↥(U i ∩ U j) → GvisModel`;
* identity, inverse and triple-overlap laws;
* the fixed model visible group `GvisModel` with its group topology;
* the fibrewise free and transitive frame action `frameRAct`.

Packaged as `OrdinaryTransitionSystem B ι`, produced by
`TopologicalFrameFamily.toOrdinaryTransitionSystem`.

Nothing above this system is constructed. The single question left for a future task, stated
here and **not** answered:

> Given a continuous ordinary transition system valued in the reconstructed visible group,
> what additional compatibility data would be required to reconstruct a coherent two-valued
> internal system over the same base?
