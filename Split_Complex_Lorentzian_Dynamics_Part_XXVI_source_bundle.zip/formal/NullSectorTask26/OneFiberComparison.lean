import RequestProject.NullSectorTask26.TransitionData
import RequestProject.NullSectorTask25.Task25

/-!
# Task 26, Packages J and K: comparison with the frozen one-fibre interface, and the frontier

Package J (items 84–89).  The completed Task-XXV endpoint is imported **unchanged**; nothing
of it is modified or redefined.  Here we show that the frozen one-fibre frame carrier
`NullSectorTask24.FramePlus` is exactly the *local model* of each fibre frame carrier of a
varying family:

* an explicit linear equivalence `coordEquiv` between the inherited three-dimensional
  carrier and the model carrier, carrying the inherited form `h3` to the model inner product;
* an equivalence `task24FrameEquiv` between the model frame carrier and the frozen one-fibre
  frame carrier;
* for every base point `b` and every orientation-preserving identification of the fibre with
  the model, an equivalence `FramePlusAt b ≃ NullSectorTask24.FramePlus` (item 86);
* the exact dependence on that identification: two identifications give equivalences
  differing by the corresponding element of the model group (item 87), so no canonical
  identification is claimed (item 88).

Package K (items 90–97) is a firewall: **no lifted frame family, no lifted transition data,
no principal bundle and no spin structure are constructed here.**  Only the interface record
`LiftedFamilyFrontier` is frozen, naming the Task-XXVI outputs that a future lifted-family
task would consume.
-/

set_option synthInstance.maxHeartbeats 400000
set_option maxHeartbeats 1000000

namespace NullSectorTask26

open Module

universe u v

open NullSectorTask04 NullSectorTask14 NullSectorTask21 NullSectorTask24

noncomputable section Bridge

/-- **NEWLY DEFINED.**  The coordinate linear equivalence between the inherited
three-dimensional carrier `Vec3` and the model carrier. -/
def coordEquiv : Vec3 ≃ₗ[ℝ] Model where
  toFun p := (WithLp.toLp 2 (vc p) : Model)
  map_add' p q := by ext i; fin_cases i <;> simp [vc]
  map_smul' c p := by ext i; fin_cases i <;> simp [vc]
  invFun x := (x 0, x 1, x 2)
  left_inv p := by simp [vc]
  right_inv x := by ext i; fin_cases i <;> simp [vc]

theorem coordEquiv_apply (p : Vec3) (i : Fin 3) : coordEquiv p i = vc p i := rfl

/-- **DERIVED.**  The coordinate equivalence carries the inherited positive-definite form to
the inner product of the model carrier. -/
theorem coordEquiv_inner (p q : Vec3) : inner ℝ (coordEquiv p) (coordEquiv q) = h3 p q := by
  simp [PiLp.inner_apply, Fin.sum_univ_three, coordEquiv_apply, vc, h3, dot3]
  ring

theorem model_orientation_iff (bas : Basis (Fin 3) ℝ Model) :
    bas.orientation = modelOrient ↔
      0 < (EuclideanSpace.basisFun (Fin 3) ℝ).toBasis.det ⇑bas := by
  rw [modelOrient, eq_comm]
  exact Basis.orientation_eq_iff_det_pos _ _

theorem det_coordEquiv (f : Fin 3 → Vec3) :
    (EuclideanSpace.basisFun (Fin 3) ℝ).toBasis.det (fun i => coordEquiv (f i))
      = (mat3 f).det := by
  rw [Basis.det_apply]
  congr 1

/-! ### From a frozen one-fibre frame to a model frame -/

theorem coordFamily_orthonormal (F : NullSectorTask24.FramePlus) :
    Orthonormal ℝ (fun i => coordEquiv (F.vec i)) := by
  rw [orthonormal_iff_ite]
  intro i j
  rw [coordEquiv_inner]
  exact F.orthonormal i j

/-- The basis of the model carrier obtained from a frozen one-fibre frame. -/
def coordBasis (F : NullSectorTask24.FramePlus) : Basis (Fin 3) ℝ Model :=
  basisOfLinearIndependentOfCardEqFinrank (coordFamily_orthonormal F).linearIndependent
    (by simp)

theorem coordBasis_coe (F : NullSectorTask24.FramePlus) :
    ⇑(coordBasis F) = fun i => coordEquiv (F.vec i) :=
  coe_basisOfLinearIndependentOfCardEqFinrank _ _

/-- The orthonormal basis of the model carrier obtained from a frozen one-fibre frame. -/
def coordONB (F : NullSectorTask24.FramePlus) : OrthonormalBasis (Fin 3) ℝ Model :=
  (coordBasis F).toOrthonormalBasis (by
    rw [coordBasis_coe]; exact coordFamily_orthonormal F)

@[simp] theorem coordONB_apply (F : NullSectorTask24.FramePlus) (i : Fin 3) :
    coordONB F i = coordEquiv (F.vec i) := by
  rw [coordONB, Basis.coe_toOrthonormalBasis, coordBasis_coe]

theorem coordONB_orientation (F : NullSectorTask24.FramePlus) :
    (coordONB F).toBasis.orientation = modelOrient := by
  have hb : (coordONB F).toBasis = coordBasis F := Basis.toBasis_toOrthonormalBasis _ _
  rw [hb, model_orientation_iff, coordBasis_coe, det_coordEquiv, det_mat3]
  exact F.oriented

/-- **NEWLY DEFINED (item 86).**  The model frame attached to a frozen one-fibre frame. -/
def ofTask24Frame (F : NullSectorTask24.FramePlus) : FramePlusOf modelOrient :=
  ⟨coordONB F, coordONB_orientation F⟩

@[simp] theorem ofTask24Frame_vec (F : NullSectorTask24.FramePlus) (i : Fin 3) :
    (ofTask24Frame F).vec i = coordEquiv (F.vec i) := coordONB_apply F i

/-! ### From a model frame to a frozen one-fibre frame -/

theorem backFamily_orthonormal (v : FramePlusOf modelOrient) :
    IsOrthonormalTriple fun i => coordEquiv.symm (v.vec i) := by
  intro i j
  have h := coordEquiv_inner (coordEquiv.symm (v.vec i)) (coordEquiv.symm (v.vec j))
  simp only [LinearEquiv.apply_symm_apply] at h
  rw [← h]
  exact v.inner_eq i j

theorem backFamily_oriented (v : FramePlusOf modelOrient) :
    IsPositivelyOriented fun i => coordEquiv.symm (v.vec i) := by
  have hbas : ⇑v.basis = v.vec := funext (FramePlusOf.basis_apply v)
  have hpos : 0 < (EuclideanSpace.basisFun (Fin 3) ℝ).toBasis.det v.vec := by
    have := (model_orientation_iff v.basis).1 (FramePlusOf.basis_orientation v)
    rwa [hbas] at this
  have hdet := det_coordEquiv fun i => coordEquiv.symm (v.vec i)
  simp only [LinearEquiv.apply_symm_apply] at hdet
  have : 0 < (mat3 fun i => coordEquiv.symm (v.vec i)).det := by rw [← hdet]; exact hpos
  rwa [det_mat3] at this

/-- **NEWLY DEFINED (item 86).**  The frozen one-fibre frame attached to a model frame. -/
def toTask24Frame (v : FramePlusOf modelOrient) : NullSectorTask24.FramePlus :=
  ⟨fun i => coordEquiv.symm (v.vec i), backFamily_orthonormal v, backFamily_oriented v⟩

@[simp] theorem toTask24Frame_vec (v : FramePlusOf modelOrient) (i : Fin 3) :
    (toTask24Frame v).vec i = coordEquiv.symm (v.vec i) := rfl

/-- **DERIVED (items 85–86), principal.**  The model frame carrier and the frozen one-fibre
frame carrier are equivalent: the previously reconstructed one-fibre object has exactly the
structural form of the fibre frame carriers of a varying family. -/
def task24FrameEquiv : FramePlusOf modelOrient ≃ NullSectorTask24.FramePlus where
  toFun := toTask24Frame
  invFun := ofTask24Frame
  left_inv v := by
    refine FramePlusOf.ext fun i => ?_
    simp
  right_inv F := by
    refine NullSectorTask24.FramePlus.ext fun i => ?_
    simp

end Bridge

/-! ## The fibrewise comparison (items 86–89) -/

namespace MetricOrientedRankThreeFamily

variable {B : Type u} {E : B → Type v} [∀ b, NormedAddCommGroup (E b)]
  [∀ b, InnerProductSpace ℝ (E b)] {F : MetricOrientedRankThreeFamily B E}

/-- **DERIVED (item 86), principal.**  Under an orientation-preserving metric identification
of the fibre over `b` with the model carrier, the fibre frame carrier is equivalent to the
frozen one-fibre frame carrier. -/
noncomputable def framePlusAtEquivTask24 {b : B} {φ : E b ≃ₗᵢ[ℝ] Model}
    (hφ : IsOrientationPreserving (F.orient b) modelOrient φ) :
    F.FramePlusAt b ≃ NullSectorTask24.FramePlus :=
  (frameEquivOfIsom hφ).trans task24FrameEquiv

/-- **DERIVED (items 87–88), principal.**  Changing the identification of the fibre with the
model changes the induced frame equivalence exactly by the corresponding element of the model
group: the comparison is canonical only up to that visible transformation, so no canonical
identification is claimed. -/
theorem frameEquivOfIsom_change {b : B} {φ ψ : E b ≃ₗᵢ[ℝ] Model}
    (hφ : IsOrientationPreserving (F.orient b) modelOrient φ)
    (hψ : IsOrientationPreserving (F.orient b) modelOrient ψ) (v : F.FramePlusAt b) :
    frameEquivOfIsom hψ v = gvisTransition hφ hψ • frameEquivOfIsom hφ v := by
  refine FramePlusOf.ext fun i => ?_
  show ψ (FramePlusOf.vec v i)
      = (gvisTransition hφ hψ : Model ≃ₗᵢ[ℝ] Model) (φ (FramePlusOf.vec v i))
  simp

end MetricOrientedRankThreeFamily

/-! ## Package K: the frontier interface (items 90–97)

**No lifted object is constructed.**  The record below only *names* the Task-XXVI outputs a
future lifted-family task would have to start from; every field is data or a theorem already
established above. -/

/-- **NEWLY DEFINED (items 96–97).**  The frozen output interface of Task XXVI: the base, the
ordinary frame total carrier with its projection, a family of Level-1 local fibre
trivializations with their induced frame trivializations, the visible transition
transformations, and their identity/inverse/triple-overlap laws.  It contains **no** lifted
frame carrier, **no** lifted transition data and **no** spin structure. -/
structure LiftedFamilyFrontier (B : Type u) (E : B → Type v)
    [∀ b, NormedAddCommGroup (E b)] [∀ b, InnerProductSpace ℝ (E b)] where
  /-- The varying metric-oriented rank-three family. -/
  family : MetricOrientedRankThreeFamily B E
  /-- An index set of trivialization domains. -/
  Index : Type u
  /-- The trivialization domains. -/
  dom : Index → Set B
  /-- The domains cover the base. -/
  covers : ∀ b : B, ∃ i, b ∈ dom i
  /-- A Level-1 local fibre trivialization over each domain. -/
  triv : ∀ i, family.LocalFibreTriv (dom i)

namespace LiftedFamilyFrontier

variable {B : Type u} {E : B → Type v} [∀ b, NormedAddCommGroup (E b)]
  [∀ b, InnerProductSpace ℝ (E b)]

/-- The visible transition transformation of the frontier interface. -/
noncomputable def trans26 (D : LiftedFamilyFrontier B E) {i j : D.Index} {b : B}
    (hi : b ∈ D.dom i) (hj : b ∈ D.dom j) : GvisModel :=
  MetricOrientedRankThreeFamily.transition (D.triv i) (D.triv j) hi hj

theorem trans26_self (D : LiftedFamilyFrontier B E) {i : D.Index} {b : B}
    (hi hi' : b ∈ D.dom i) : D.trans26 hi hi' = 1 :=
  MetricOrientedRankThreeFamily.transition_self _ _ _

theorem trans26_symm (D : LiftedFamilyFrontier B E) {i j : D.Index} {b : B}
    (hi : b ∈ D.dom i) (hj : b ∈ D.dom j) : D.trans26 hj hi = (D.trans26 hi hj)⁻¹ :=
  MetricOrientedRankThreeFamily.transition_symm _ _ _ _

theorem trans26_triple (D : LiftedFamilyFrontier B E) {i j k : D.Index} {b : B}
    (hi : b ∈ D.dom i) (hj : b ∈ D.dom j) (hk : b ∈ D.dom k) :
    D.trans26 hi hk = D.trans26 hj hk * D.trans26 hi hj :=
  MetricOrientedRankThreeFamily.transition_trans _ _ _ _ _ _

end LiftedFamilyFrontier

end NullSectorTask26
