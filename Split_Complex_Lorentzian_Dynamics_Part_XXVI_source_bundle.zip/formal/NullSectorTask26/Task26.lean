import RequestProject.NullSectorTask26.OneFiberComparison

/-!
# Task 26 — principal endpoints

This module imports the complete Task-26 development and exposes its principal endpoints
under stable names, followed by an axiom report (`#print axioms`) on each of them.

The Task-XXV endpoint is imported unchanged; no declaration of Tasks XXIII–XXV was modified,
and no `SpinStructure`, principal bundle, vector bundle, lifted frame family, tangent bundle,
characteristic class, Čech cohomology, connection or curvature occurs anywhere in the layer.

## Required decision table

| Question | Verdict |
| --- | --- |
| Nontrivial base allowed without manifold assumptions? | `PROVED` (`MetricOrientedRankThreeFamily`: `B` is an arbitrary type) |
| Varying real rank-3 fibres formalized? | `PROVED` (`task26_family`) |
| Fibrewise metric formalized? | `PROVED` (ambient `InnerProductSpace ℝ (E b)`) |
| Fibrewise orientation formalized? | `PROVED` (`MetricOrientedRankThreeFamily.orient`) |
| `FramePlusAt b` intrinsic? | `PROVED` (`task26_FramePlusAt`) |
| Frames exist in every fibre? | `PROVED` (`task26_frame_exists`) |
| Total frame carrier constructed? | `PROVED` (`task26_FrameTotal`) |
| Fibre of total carrier exactly `FramePlusAt b`? | `PROVED` (`task26_fiber_exact`) |
| Fixed `Gvis` canonical in every fibre? | `REQUIRES CHOICE` (`task26_gvis_compare`, `task26_gvis_compare_change`) |
| Intrinsic fibrewise visible group constructed? | `PROVED` (`task26_GvisAt`) |
| Fibrewise group acts freely? | `PROVED` (`task26_gvisAt_free`) |
| Fibrewise group acts transitively? | `PROVED` (`task26_gvisAt_transitive`) |
| Algebraic local fibre trivialization defined? | `PROVED` (`task26_LocalFibreTriv`) |
| Induced local frame trivialization? | `PROVED` (`task26_frameTrivTotal`) |
| Reverse reconstruction frame→fibre? | `PROVED` (`task26_isom_unique_of_frame_image`, `task26_existsUnique_isom_of_frames`) |
| Fibre and frame trivializations equivalent? | `PROVED` (`task26_fibreTriv_equiv_frameSection`) |
| Transition transformations constructed? | `PROVED` (`task26_transition`) |
| Triple-overlap law? | `PROVED` (`task26_transition_trans`) |
| Correct bundle topology constructed? | `NOT YET` (`task26_sigma_topology_negative_control`, `task26_sigma_fiber_open`) |
| Principal bundle constructed? | `NO` |
| Lifted frame family constructed? | `NO` |
| Spin structure constructed? | `NO` |
-/

set_option maxHeartbeats 1000000

namespace NullSectorTask26

open Module

universe u v

section Endpoints

variable {B : Type u} {E : B → Type v} [∀ b, NormedAddCommGroup (E b)]
  [∀ b, InnerProductSpace ℝ (E b)]

/-! ## Package A — the varying metric-oriented rank-three family -/

/-- Principal endpoint 1: the varying-fibre input structure. -/
abbrev task26_family (B : Type u) (E : B → Type v) [∀ b, NormedAddCommGroup (E b)]
    [∀ b, InnerProductSpace ℝ (E b)] : Type _ :=
  MetricOrientedRankThreeFamily B E

alias task26_family_finiteDimensional := MetricOrientedRankThreeFamily.finiteDimensional
alias task26_orientation_invariance := IsOrientationPreserving.trans

/-! ## Package B — negative controls of the dependency audit -/

alias task26_dimension_does_not_orient := exists_two_orientations
alias task26_metric_does_not_orient := exists_two_families
alias task26_orientation_does_not_frame := exists_two_oriented_orthonormal_bases
alias task26_pointwise_data_not_global := pointwise_data_not_global

/-! ## Package C — intrinsic fibrewise frames -/

/-- Principal endpoint 2: the intrinsic fibrewise oriented orthonormal frame carrier. -/
abbrev task26_FramePlusAt (F : MetricOrientedRankThreeFamily B E) (b : B) : Type _ :=
  F.FramePlusAt b

alias task26_frame_exists := MetricOrientedRankThreeFamily.framePlusAt_nonempty
alias task26_frame_is_basis := MetricOrientedRankThreeFamily.framePlusAt_basis
alias task26_frame_ext := MetricOrientedRankThreeFamily.framePlusAt_ext

/-! ## Package D — the total ordinary frame carrier -/

/-- Principal endpoint 3: the total ordinary frame carrier. -/
abbrev task26_FrameTotal (F : MetricOrientedRankThreeFamily B E) : Type _ := F.FrameTotal

alias task26_frameBase := MetricOrientedRankThreeFamily.frameBase
alias task26_fiber_exact := MetricOrientedRankThreeFamily.frameFiberEquiv
alias task26_frameBase_surjective := MetricOrientedRankThreeFamily.frameBase_surjective
alias task26_sigma_fiber_open := isOpen_sigmaFiber

/-! ## Package E — the intrinsic fibrewise visible group -/

/-- Principal endpoint 4: the intrinsic orientation-preserving isometry group of a fibre. -/
noncomputable abbrev task26_GvisAt (F : MetricOrientedRankThreeFamily B E) (b : B) :
    Subgroup (E b ≃ₗᵢ[ℝ] E b) :=
  F.GvisAt b

alias task26_gvisAt_free := MetricOrientedRankThreeFamily.gvisAt_free
alias task26_gvisAt_transitive := MetricOrientedRankThreeFamily.gvisAt_transitive
alias task26_gvisAt_existsUnique := MetricOrientedRankThreeFamily.gvisAt_existsUnique
alias task26_gvis_det_characterization := mem_SOOf_iff_det_pos
alias task26_gvis_compare := gvisCompare
alias task26_gvis_compare_change := gvisCompare_change
alias task26_gvis_compare_eq_iff_commute := gvisCompare_eq_iff_commute

/-! ## Packages F and G — local fibre and frame trivializations -/

/-- Principal endpoint 5: the Level-1 (algebraic) local fibre trivialization. -/
abbrev task26_LocalFibreTriv (F : MetricOrientedRankThreeFamily B E) (U : Set B) : Type _ :=
  F.LocalFibreTriv U

alias task26_localTriv_exists := MetricOrientedRankThreeFamily.exists_localFibreTriv
alias task26_frameTrivAt := MetricOrientedRankThreeFamily.frameTrivAt
alias task26_frameTrivTotal := MetricOrientedRankThreeFamily.frameTrivTotal
alias task26_sigma_topology_negative_control :=
  sigmaTopology_makes_every_algebraic_triv_continuous

/-! ## Package H — reverse reconstruction -/

alias task26_isom_unique_of_frame_image := isom_unique_of_frame_image
alias task26_existsUnique_isom_of_frames := existsUnique_isom_of_frames
/-- Principal endpoint: identifications with the model ≃ oriented frames, at one space. -/
noncomputable def task26_isom_equiv_frame {V : Type*} [NormedAddCommGroup V]
    [InnerProductSpace ℝ V] (o : Orientation ℝ V (Fin 3)) :
    {f : V ≃ₗᵢ[ℝ] Model // IsOrientationPreserving o modelOrient f} ≃ FramePlusOf o :=
  isomEquivFrame o
alias task26_fibreTriv_equiv_frameSection :=
  MetricOrientedRankThreeFamily.fibreTrivEquivFrameSection

/-! ## Package I — transition transformations -/

/-- Principal endpoint 6: the visible transition transformation over an overlap. -/
alias task26_transition := MetricOrientedRankThreeFamily.transition

alias task26_transition_metric := gvisTransition_inner
alias task26_transition_orientation := gvisTransition_orientation
alias task26_transition_self := MetricOrientedRankThreeFamily.transition_self
alias task26_transition_symm := MetricOrientedRankThreeFamily.transition_symm
alias task26_transition_trans := MetricOrientedRankThreeFamily.transition_trans
alias task26_frameTriv_transition := MetricOrientedRankThreeFamily.frameTrivAt_transition

/-! ## Package J — comparison with the frozen one-fibre model -/

/-- Principal endpoint: the model frame carrier is the frozen one-fibre frame carrier. -/
noncomputable def task26_task24_frame_equiv :
    FramePlusOf modelOrient ≃ NullSectorTask24.FramePlus := task24FrameEquiv
alias task26_framePlusAt_equiv_task24 :=
  MetricOrientedRankThreeFamily.framePlusAtEquivTask24
alias task26_frame_equiv_change := MetricOrientedRankThreeFamily.frameEquivOfIsom_change

/-! ## Package K — the frontier interface for a future lifted-family task -/

alias task26_frontier_triple := LiftedFamilyFrontier.trans26_triple

end Endpoints

/-! ## Axiom report -/

#print axioms NullSectorTask26.MetricOrientedRankThreeFamily
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.finiteDimensional
#print axioms NullSectorTask26.IsOrientationPreserving
#print axioms NullSectorTask26.IsOrientationPreserving.trans
#print axioms NullSectorTask26.exists_two_orientations
#print axioms NullSectorTask26.exists_two_families
#print axioms NullSectorTask26.exists_two_oriented_orthonormal_bases
#print axioms NullSectorTask26.pointwise_data_not_global
#print axioms NullSectorTask26.FramePlusOf
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.FramePlusAt
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.framePlusAt_nonempty
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.framePlusAt_basis
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.FrameTotal
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.frameBase
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.frameFiberEquiv
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.frameBase_surjective
#print axioms NullSectorTask26.isOpen_sigmaFiber
#print axioms NullSectorTask26.SOOf
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.GvisAt
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.gvisAt_free
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.gvisAt_transitive
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.gvisAt_existsUnique
#print axioms NullSectorTask26.mem_SOOf_iff_det_pos
#print axioms NullSectorTask26.gvisCompare
#print axioms NullSectorTask26.gvisCompare_change
#print axioms NullSectorTask26.gvisCompare_eq_iff_commute
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.LocalFibreTriv
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.exists_localFibreTriv
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.frameTrivAt
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.frameTrivTotal
#print axioms NullSectorTask26.sigmaTopology_makes_every_algebraic_triv_continuous
#print axioms NullSectorTask26.isom_unique_of_frame_image
#print axioms NullSectorTask26.existsUnique_isom_of_frames
#print axioms NullSectorTask26.isomEquivFrame
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.fibreTrivEquivFrameSection
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.transition
#print axioms NullSectorTask26.gvisTransition_inner
#print axioms NullSectorTask26.gvisTransition_orientation
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.transition_self
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.transition_symm
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.transition_trans
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.frameTrivAt_transition
#print axioms NullSectorTask26.task24FrameEquiv
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.framePlusAtEquivTask24
#print axioms NullSectorTask26.MetricOrientedRankThreeFamily.frameEquivOfIsom_change
#print axioms NullSectorTask26.LiftedFamilyFrontier.trans26_triple

end NullSectorTask26
