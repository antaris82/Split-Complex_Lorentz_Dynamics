# TASK XXVI AUDIT — Varying metric-oriented fibres and frame-family reconstruction

**Status: Priority 1 complete, Priority 2 complete, Priority 3 complete.
Focused build green, whole-project build green, no `sorry`, no custom axiom.**

---

## 0. Toolchain and provenance

| Item | Value |
| --- | --- |
| Lean | `leanprover/lean4:v4.28.0` (`lean-toolchain`, unchanged) |
| Mathlib | `v4.28.0` tag, as pinned in `lakefile.toml` / `lake-manifest.json` (unchanged) |
| New modules | `RequestProject/NullSectorTask26/` — 9 files, 1615 lines |
| Inherited source | Tasks I–XXV: **not modified** (`git diff` touches no earlier file) |
| Imports of the layer | `Mathlib` (base module) and `RequestProject.NullSectorTask25.Task25` (comparison module only) |

Module chain (strictly linear):

```
FamilyBase → FiberFrames → FrameTotal → FiberIsometryGroup
           → LocalTrivialization → FrameTrivialization → TransitionData
           → OneFiberComparison → Task26
```

---

## 1. Exact definitions

### 1.1 Package A — the varying-fibre input

```lean
structure MetricOrientedRankThreeFamily (B : Type u) (E : B → Type v)
    [∀ b, NormedAddCommGroup (E b)] [∀ b, InnerProductSpace ℝ (E b)] where
  rank_three : ∀ b : B, finrank ℝ (E b) = 3
  orient     : ∀ b : B, Orientation ℝ (E b) (Fin 3)
```

* The base `B` is an arbitrary type: **no** manifold structure, **no** topology, **no**
  connectivity, **no** separation or countability assumptions (items 13, 14, 22).
* The fibrewise real vector-space structure and the fibrewise symmetric positive-definite
  form are carried by the ambient instance hypotheses `NormedAddCommGroup (E b)` and
  `InnerProductSpace ℝ (E b)` — the standard Lean packaging (item 26).  No fibre is assumed
  equal to any fixed carrier (item 8).
* The orientation datum is Mathlib's `Orientation ℝ (E b) (Fin 3)` (a ray in the space of
  alternating three-forms), i.e. **not** represented by a chosen frame (item 29).
* The record contains no trivialization, frame, transition function, group action or lifted
  fibre (item 33).

Auxiliary single-space notions:

```lean
def IsOrientationPreserving (oV : Orientation ℝ V (Fin 3)) (oW : Orientation ℝ W (Fin 3))
    (f : V ≃ₗᵢ[ℝ] W) : Prop := Orientation.map (Fin 3) f.toLinearEquiv oV = oW

abbrev Model : Type := EuclideanSpace ℝ (Fin 3)
noncomputable def modelOrient : Orientation ℝ Model (Fin 3) :=
  (EuclideanSpace.basisFun (Fin 3) ℝ).toBasis.orientation
```

### 1.2 Package C/D — frames and the total carrier

```lean
def FramePlusOf (o : Orientation ℝ V (Fin 3)) : Type _ :=
  {v : OrthonormalBasis (Fin 3) ℝ V // v.toBasis.orientation = o}

def MetricOrientedRankThreeFamily.FramePlusAt (F) (b : B) : Type _ := FramePlusOf (F.orient b)
def MetricOrientedRankThreeFamily.FrameTotal (F) : Type _ := Σ b : B, F.FramePlusAt b
def MetricOrientedRankThreeFamily.frameBase (F) : F.FrameTotal → B := Sigma.fst
```

### 1.3 Package E — the intrinsic fibrewise group

```lean
def SOOf (o : Orientation ℝ V (Fin 3)) : Subgroup (V ≃ₗᵢ[ℝ] V) :=
  { carrier := {f | IsOrientationPreserving o o f}, … }

noncomputable def MetricOrientedRankThreeFamily.GvisAt (F) (b : B) : Subgroup (E b ≃ₗᵢ[ℝ] E b)
  := SOOf (F.orient b)

noncomputable def GvisModel : Subgroup (Model ≃ₗᵢ[ℝ] Model) := SOOf modelOrient
```

The action on frames is `frameSMul g v = v.onb.map g`, registered as a `MulAction`.

### 1.4 Packages F–I

```lean
structure LocalFibreTriv (F) (U : Set B) where
  iso : ∀ b : U, E (b : B) ≃ₗᵢ[ℝ] Model
  orientation_preserving : ∀ b : U, IsOrientationPreserving (F.orient b) modelOrient (iso b)

noncomputable def frameChart (v : FramePlusOf o) : V ≃ₗᵢ[ℝ] Model := v.onb.repr
def frameEquivOfIsom (hf : IsOrientationPreserving oV oW f) : FramePlusOf oV ≃ FramePlusOf oW
noncomputable def gvisTransition (hφ hψ) : GvisModel := ⟨φ.symm.trans ψ, _⟩
noncomputable def MetricOrientedRankThreeFamily.transition (Φ Ψ) (hU hW) : GvisModel
```

### 1.5 Package K — the frontier interface (no lifting)

```lean
structure LiftedFamilyFrontier (B) (E) … where
  family : MetricOrientedRankThreeFamily B E
  Index  : Type u
  dom    : Index → Set B
  covers : ∀ b : B, ∃ i, b ∈ dom i
  triv   : ∀ i, family.LocalFibreTriv (dom i)
```

with the three transition laws re-exported.  It contains **no** lifted frame carrier, **no**
lifted transition datum and **no** spin structure.

---

## 2. Theorem inventory (principal endpoints, 46 audited)

| # | Name | Content |
| --- | --- | --- |
| 1 | `MetricOrientedRankThreeFamily` | the varying rank-3 metric-oriented family |
| 2 | `MetricOrientedRankThreeFamily.finiteDimensional` | rank 3 ⇒ finite dimensional fibre |
| 3 | `IsOrientationPreserving.trans` / `.symm` / `isOrientationPreserving_refl` | the minimal orientation notion is invariant under composition, inverse, identity (item 31) |
| 4 | `mem_SOOf_iff_det_pos` | orientation preservation ⇔ positive determinant |
| 5 | `exists_two_orientations` | rank 3 + metric does not choose an orientation |
| 6 | `exists_two_families` | two families with the same fibres and metric, different orientations |
| 7 | `exists_two_oriented_orthonormal_bases` | orientation does not choose a frame |
| 8 | `pointwise_data_not_global` | data at one point do not determine data elsewhere |
| 9 | `FramePlusOf` / `FramePlusAt` | intrinsic fibrewise oriented orthonormal frames |
| 10 | `FramePlusOf.basis`, `…linearIndependent`, `…span_eq_top` | every frame is a basis |
| 11 | `FramePlusOf.ext`, `framePlusAt_ext` | frame equality is componentwise |
| 12 | `framePlusOf_nonempty`, `framePlusAt_nonempty` | frames exist in every fibre |
| 13 | `FrameTotal`, `frameBase` | total ordinary-frame carrier and projection |
| 14 | `frameFiberEquiv` | the fibre over `b` is exactly `FramePlusAt b` |
| 15 | `frameBase_surjective` | projection surjective |
| 16 | `isOpen_sigmaFiber` | the automatic sigma topology makes every fibre open |
| 17 | `SOOf`, `GvisAt` | intrinsic fibrewise orientation-preserving isometry group |
| 18 | `frameAction_free`, `gvisAt_free` | the fibrewise action is free |
| 19 | `frameAction_transitive`, `gvisAt_transitive` | the fibrewise action is transitive |
| 20 | `existsUnique_frameAction`, `gvisAt_existsUnique` | unique transporter between two frames |
| 21 | `gvisCompare` | comparison with the model group, given an identification |
| 22 | `gvisCompare_change` | two identifications differ by conjugation |
| 23 | `gvisCompare_eq_iff_commute` | they agree exactly when the transition element commutes |
| 24 | `LocalFibreTriv` | Level-1 local fibre trivialization |
| 25 | `localFibreTrivOfFrames`, `exists_localFibreTriv` | existence from fibrewise frames |
| 26 | `sigmaTopology_makes_every_algebraic_triv_continuous` | the automatic topology imposes no condition |
| 27 | `frameChart`, `frameChart_orientation` | a frame *is* an orientation-preserving chart |
| 28 | `frameEquivOfIsom` | induced equivalence of frame carriers (items 65–66) |
| 29 | `frameTrivAt`, `frameTrivTotal` | induced local frame trivialization `frameBase⁻¹ U ≃ U × FramePlus(Model)` |
| 30 | `isom_unique_of_frame_image` | reverse reconstruction: uniqueness |
| 31 | `existsUnique_isom_of_frames` | reverse reconstruction: existence and uniqueness |
| 32 | `isomEquivFrame` | identifications with the model ≃ oriented frames (one space) |
| 33 | `fibreTrivEquivFrameSection` | local fibre trivializations ≃ local frame sections |
| 34 | `transition` | transition transformation over an overlap |
| 35 | `gvisTransition_inner` | transitions preserve the metric |
| 36 | `gvisTransition_orientation` | transitions preserve orientation, i.e. lie in `GvisModel` |
| 37 | `transition_self` | identity law `g_ii = 1` |
| 38 | `transition_symm` | inverse law `g_ji = g_ij⁻¹` |
| 39 | `transition_trans` | triple-overlap law `g_ik = g_jk * g_ij` |
| 40 | `frameTrivAt_transition` | the two induced frame trivializations differ by the transition action |
| 41 | `coordEquiv`, `coordEquiv_inner` | coordinate bridge to the inherited three-dimensional carrier |
| 42 | `task24FrameEquiv` | model frame carrier ≃ frozen one-fibre frame carrier |
| 43 | `framePlusAtEquivTask24` | fibre frames ≃ frozen one-fibre frames, given an identification |
| 44 | `frameEquivOfIsom_change` | dependence on the identification is exactly a visible-group element |
| 45 | `LiftedFamilyFrontier` | the frozen output interface |
| 46 | `LiftedFamilyFrontier.trans26_self/symm/triple` | its transition laws |

---

## 3. Dependency DAG (Package L)

Arrow types: **[D]** definition, **[A]** additional assumption/structure, **[C]** construction,
**[T]** theorem, **[E]** equivalence, **[O]** obstruction.

```
                     Base B  +  varying real rank-3 fibres E b
                                     |
        +----------------------------+----------------------------+
        |              |              |                |
   vector space      metric      orientation         rank 3
   (ambient inst.)  (ambient)   (orient field)     (rank_three)
        |              |              |                |
        +--------------+------+-------+----------------+
                              | [D]
                        FramePlusAt b
                              | [T] framePlusAt_nonempty  (classical existence of an
                              |     orthonormal basis + adjustment to the orientation)
                              | [C]
                    FrameTotal --frameBase--> B
                              | [T] frameFiberEquiv (fibre exact), frameBase_surjective
                              |
                              | [D] SOOf / GvisAt        [T] free, transitive, unique
                              |
   local fibre trivialization (Level 1)   <-- [A] ADDITIONAL STRUCTURE, not implied
                              | [C]
                  local frame trivialization
                              | [E] fibreTrivEquivFrameSection
                              | [D]
                  transition transformations in GvisModel
                              | [T] identity / inverse / triple-overlap
                              |
                       [O] topology on Σ b, E b : MISSING
                              |
                       (future lifted-family task)
```

Explicitly **not** drawn (items 99–100):

* `metric-oriented fibres → local triviality` — local triviality is additional
  structure/theorem-level input in the topological sense.  What *is* proved is only the
  Level-1 (set-theoretic) statement `exists_localFibreTriv`, whose proof chooses a frame in
  each fibre and therefore carries no regularity in `b`.
* `FrameTotal → spin structure` — no such arrow exists anywhere in this layer.

---

## 4. Required decision table

| Question | Verdict |
| --- | --- |
| Nontrivial base allowed without manifold assumptions? | **PROVED** (`B` arbitrary type) |
| Varying real rank-3 fibres formalized? | **PROVED** (`MetricOrientedRankThreeFamily`) |
| Fibrewise metric formalized? | **PROVED** (ambient `InnerProductSpace ℝ (E b)`) |
| Fibrewise orientation formalized? | **PROVED** (`orient`, Mathlib `Orientation`) |
| `FramePlusAt b` intrinsic? | **PROVED** |
| Frames exist in every fibre? | **PROVED** (`framePlusAt_nonempty`) |
| Total frame carrier constructed? | **PROVED** (`FrameTotal`) |
| Fibre of total carrier exactly `FramePlusAt b`? | **PROVED** (`frameFiberEquiv`) |
| Fixed `Gvis` canonical in every fibre? | **REQUIRES CHOICE** (`gvisCompare`, `gvisCompare_change`) |
| Intrinsic fibrewise visible group constructed? | **PROVED** (`GvisAt`, Outcome E1 fibrewise) |
| Fibrewise group acts freely? | **PROVED** |
| Fibrewise group acts transitively? | **PROVED** |
| Algebraic local fibre trivialization defined? | **PROVED** (`LocalFibreTriv`) |
| Induced local frame trivialization? | **PROVED** (`frameTrivAt`, `frameTrivTotal`) |
| Reverse reconstruction frame→fibre? | **PROVED** (`isom_unique_of_frame_image`, `existsUnique_isom_of_frames`) |
| Fibre and frame trivializations equivalent? | **PROVED** at Level 1 (`fibreTrivEquivFrameSection`) |
| Transition transformations constructed? | **PROVED** |
| Triple-overlap law? | **PROVED** (`transition_trans`) |
| Correct bundle topology constructed? | **NOT YET** (see §6) |
| Principal bundle constructed? | **NO** |
| Lifted frame family constructed? | **NO** |
| Spin structure constructed? | **NO** |

---

## 5. Package E: the exact role of a fixed visible group

Outcome **E2**.  Each fibre carries its own intrinsic group `GvisAt b`, and the action on
`FramePlusAt b` is free and transitive.  A comparison with one fixed group exists only after
choosing an orientation-preserving identification `φ : E b ≃ₗᵢ[ℝ] Model`:

* `gvisCompare hφ : SOOf (F.orient b) ≃* GvisModel` — *takes `φ` as an input*;
* `gvisCompare_change`: for two choices `φ, ψ`,
  `gvisCompare hψ g = c * gvisCompare hφ g * c⁻¹` with `c = gvisTransition hφ hψ`;
* `gvisCompare_eq_iff_commute`: the two comparisons agree on `g` exactly when `c` commutes
  with the image of `g`.

**Recorded verdict:** identifying all fibrewise visible groups with one fixed `Gvis` is
additional trivialization data; no constant structural group is assumed anywhere.

---

## 6. Level 1 versus Level 2 (topology)

* **Level 1 (closed).**  Local fibre trivializations and local frame trivializations are
  defined, related and proved equivalent purely set-theoretically.
* **Level 2 (open, dependency identified).**  A topological local trivialization needs a
  topology on the total fibre carrier `Σ b, E b`.  The only topology automatically available
  is the disjoint union of the fibres, and it is provably useless here:
  * `isOpen_sigmaFiber` — every fibre is open, so for a connected base this is not a bundle
    topology;
  * `sigmaTopology_makes_every_algebraic_triv_continuous` — *every* algebraic fibrewise
    trivialization is continuous for it, so it imposes no condition at all.

  No topology was invented to force Level 2 (item 64).  `FrameTotal` carries **no**
  `TopologicalSpace` instance at all in this development, and none is inherited
  definitionally, since `OrthonormalBasis`-subtypes carry none (item 50).

---

## 7. Negative controls

| Control | Formal statement |
| --- | --- |
| rank 3 does not choose an orientation | `exists_two_orientations` |
| the metric does not choose an orientation | `exists_two_families` |
| an orientation does not choose a frame | `exists_two_oriented_orthonormal_bases` |
| data at one point do not determine data elsewhere | `pointwise_data_not_global` |
| the sigma type does not carry the intended bundle topology | `isOpen_sigmaFiber` |
| the automatic topology cannot express local triviality | `sigmaTopology_makes_every_algebraic_triv_continuous` |
| no canonical constant structural group | `gvisCompare_change`, `gvisCompare_eq_iff_commute` |
| pointwise comparison with the frozen model is choice-dependent | `frameEquivOfIsom_change` |

Controls 101–106 that are *scope statements* rather than theorems (a family of vector spaces
is not a vector bundle; frames in every fibre do not give a continuous global frame; the
fibrewise frame carriers do not make the projection a principal bundle) are honestly recorded
as such: nothing in this layer asserts them as Lean theorems, and nothing in this layer
assumes their converses.  A continuous global frame cannot even be *stated* before Level 2.

---

## 8. Unresolved mathematical obligations

1. **Topology on the total fibre carrier** and on `FrameTotal` — the next missing dependency.
   Until it exists, "continuity of `b ↦ φ_b`", "continuous transition maps" and "continuous
   global frame" are not statable.
2. **Level-2 local triviality** and its comparison with Level 1.
3. **Continuity/regularity of the transition transformations** (item 83: the results here are
   purely algebraic).
4. **Bare set-level total-space equivalences.**  The proved reverse reconstruction is
   `fibre trivialization ↔ local frame section`.  It is *not* claimed that an arbitrary set
   equivalence `frameBase⁻¹ U ≃ U × FramePlus(Model)` comes from a fibre trivialization; that
   would require an equivariance hypothesis and is left open.
5. **Comparison of the minimal orientation formalism with further Mathlib orientation API**
   beyond what is used (`Orientation.map`, `Basis.orientation`, `adjustToOrientation`).
6. No principal bundle, no lifted family, no spin structure — deliberately out of scope.

---

## 9. Source ledger

### IMPORTED STANDARD RESULT (Mathlib, `v4.28.0`)

| Declaration | Module |
| --- | --- |
| `Orientation`, `Orientation.map`, `Orientation.map_apply`, `Orientation.map_refl`, `Orientation.map_eq_iff_det_pos` | `Mathlib/LinearAlgebra/Orientation.lean` |
| `Module.Ray`, `Module.Ray.ind`, `Module.Ray.ne_neg_self` | `Mathlib/LinearAlgebra/Ray.lean` |
| `Basis.orientation`, `Basis.orientation_map`, `Basis.orientation_eq_iff_det_pos` | `Mathlib/LinearAlgebra/Orientation.lean` |
| `Basis.det_apply`, `Basis.det_reindex`, `Basis.toMatrix_apply` | `Mathlib/LinearAlgebra/Determinant.lean`, `Mathlib/LinearAlgebra/Matrix/Basis.lean` |
| `OrthonormalBasis`, `.toBasis`, `.map`, `.reindex`, `.repr`, `.repr_self`, `.repr_symm_single`, `.toBasis_map` | `Mathlib/Analysis/InnerProductSpace/PiL2.lean` |
| `stdOrthonormalBasis` | `Mathlib/Analysis/InnerProductSpace/PiL2.lean` |
| `OrthonormalBasis.adjustToOrientation`, `orientation_adjustToOrientation` | `Mathlib/Analysis/InnerProductSpace/Orientation.lean` |
| `Basis.toOrthonormalBasis`, `basisOfLinearIndependentOfCardEqFinrank` | `Mathlib/Analysis/InnerProductSpace/PiL2.lean`, `Mathlib/LinearAlgebra/FiniteDimensional.lean` |
| `Module.finite_of_finrank_pos`, `finrank_euclideanSpace_fin` | `Mathlib/LinearAlgebra/Dimension/*`, `Mathlib/Analysis/InnerProductSpace/EuclideanDist.lean` |
| `LinearIsometryEquiv` group structure, `inner_map_map` | `Mathlib/Analysis/Normed/Operator/LinearIsometry.lean` |
| `continuous_sigma_iff`, `isOpen_sigma_iff` | `Mathlib/Topology/Constructions.lean` |

### DERIVED IN TASK XXVI

Everything listed in §2 that is not in the table above: the family record, the intrinsic
fibrewise frame carriers and their properties, the total carrier and its exact fibre, the
intrinsic fibrewise group with free/transitive action, the comparison with a fixed model
group and its choice-dependence, Level-1 local fibre and frame trivializations, the reverse
reconstruction and the equivalence of the two trivialization notions, the transition
transformations and their three laws, the coordinate bridge to the inherited carrier, the
comparison with the frozen one-fibre frame carrier, and the frontier interface.

### INHERITED, UNCHANGED

`NullSectorTask24.FramePlus`, `NullSectorTask24.IsOrthonormalTriple`,
`NullSectorTask24.IsPositivelyOriented`, `NullSectorTask24.mat3`, `det_mat3`,
`NullSectorTask21.vc`, `NullSectorTask14.h3`, `NullSectorTask04.dot3`, and the whole
Task-XXV endpoint (imported, not modified).

---

## 10. Build and axiom report

| Command | Result |
| --- | --- |
| `lake build RequestProject.NullSectorTask26.Task26` | **PASS** |
| `lake build` (whole project) | **PASS**, 8298 jobs, 0 errors |
| Warnings | 114 project-wide, **all pre-existing** in Tasks 11/14/21; **0** in any Task-26 module |
| `#print axioms` on all 46 principal endpoints | every one reports exactly `[propext, Classical.choice, Quot.sound]` |
| Prohibited-token scan of `RequestProject/NullSectorTask26/` | `sorry` 0, `admit` 0, `axiom` 0, `native_decide` 0, `bv_decide` 0, `implemented_by` 0, `unsafe` 0, `partial` 0 |

`Classical.choice` enters through the classical existence of an orthonormal basis
(`stdOrthonormalBasis`), through `Classical.arbitrary` in `exists_localFibreTriv`, and through
ordinary Mathlib noncomputability; it is audited and expected.

### Failed-build ledger (all repaired; no mathematical statement changed)

| # | Command | Error | Diagnosis | Repair | Statement changed? |
| --- | --- | --- | --- | --- | --- |
| 1 | build `FamilyBase` | `No goals to be solved` after `congr 1` | `congr 1` already closed the orientation-transport goal | dropped the trailing `ext` | no |
| 2 | build `FamilyBase` | type mismatch in `isOrientationPreserving_refl` | `(LinearIsometryEquiv.refl).toLinearEquiv` is not syntactically `LinearEquiv.refl` | inserted the `rfl` bridging step | no |
| 3 | build `FamilyBase` | det orientation mismatch | `Basis.orientation_eq_iff_det_pos` produces the *reindexed* determinant | restated `det_cyc3_pos` with `∘ cyc3` and used `Basis.det_reindex` | no |
| 4 | build `FiberFrames` | "consider marking noncomputable" | `OrthonormalBasis` projections are noncomputable | `noncomputable section` | no |
| 5 | build `FiberFrames` | `ext_iff` already declared | clash with the `@[ext]`-generated lemma | renamed to `eq_iff_vec` | no |
| 6 | build `FiberFrames` | orthonormality/`span` shape mismatches | `simp` normalized `⟪v i, v i⟫` and `⇑basis` differently | used `orthonormal_iff_ite` and the explicit `⇑basis = vec` rewrite | no |
| 7 | build `FiberIsometryGroup` | `rewrite` failed in the uniqueness proof | wrong intermediate group identity | reorganized via `g⁻¹ • w = v` | no |
| 8 | build `FiberIsometryGroup` | `HSMul` instance not found for `GvisAt`/`FramePlusAt` | the fibrewise names are `def`s, not reducible | added the fibrewise `MulAction` instances | no |
| 9 | build `FrameTrivialization` | unsolved `single i 1` goals | `simp` rewrites `modelFrame.vec i` to `EuclideanSpace.single i 1` | added the simp lemma `frameChart_symm_single` | no |
| 10 | build `TransitionData` | `HSMul` for `GvisModel` | same cause as #8 | added `modelGvisMulAction` | no |
| 11 | build `Task26` | compiler IR failures on three aliases | aliases of noncomputable definitions | replaced by `noncomputable` definitions | no |

---

## 11. Frontier for a future lifted-family task (Package K)

A future task would consume exactly:

1. the base `B` and the family `MetricOrientedRankThreeFamily B E`;
2. the ordinary frame total carrier `FrameTotal` with `frameBase`;
3. Level-1 local fibre trivializations `LocalFibreTriv F U` and the induced local frame
   trivializations `frameTrivTotal`;
4. the visible transition transformations `transition Φ Ψ hU hW ∈ GvisModel`;
5. their identity, inverse and triple-overlap laws;
6. the comparison of the fibrewise groups with the fixed model group, together with its
   proved choice-dependence.

Still absent, and required before any lifting statement: a topology on the total fibre
carrier, continuity of the trivializations and of the transition transformations, and
therefore any notion of a *continuous* lift.  **Nothing was lifted in Task XXVI.**
