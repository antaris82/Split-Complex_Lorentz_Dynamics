This project was edited by [Aristotle](https://aristotle.harmonic.fun).

To cite Aristotle:
- Tag @Aristotle-Harmonic on GitHub PRs/issues
- Add as co-author to commits:
```
Co-authored-by: Aristotle (Harmonic) <aristotle-harmonic@harmonic.fun>
```

# Null-Sector Task 01 — Longitudinal causal decomposition inside 3+1 Minkowski space

A self-contained, machine-checked Lean 4 development of the split-complex /
null-coordinate decomposition of a fixed 1+1 plane inside 3+1 Minkowski space,
together with the classification of the future-causal coefficient quadrant, the
action of longitudinal boosts, the invariant product of complementary
coefficients, and two elementary limiting regimes.

This is a carrier-and-transformation audit. No physical ontology is attached to
any coefficient or invariant: all objects are real vector spaces, quadratic
forms, real coefficients and derived algebraic quantities.

## Environment

| Item | Value |
| --- | --- |
| Lean toolchain | `leanprover/lean4:v4.28.0` (see `lean-toolchain`) |
| Mathlib | `v4.28.0`, commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (see `lake-manifest.json`) |
| Build target | `RequestProject` library (`lakefile.toml`) |

## Layout

```
RequestProject/NullSectorTask01/Basic.lean        -- 3+1 carrier, Q₄, longitudinal 1+1 carrier, Q₂, ι
RequestProject/NullSectorTask01/SplitComplex.lean -- split-complex product, e₊/e₋, null coordinates, Q₂(P a b) = a b
RequestProject/NullSectorTask01/Strata.lean       -- future-causal quadrant and its four strata
RequestProject/NullSectorTask01/Boost.lean        -- longitudinal boosts, reciprocal scaling, invariant product
RequestProject/NullSectorTask01/Limits.lean       -- boundary families and the two limiting regimes
RequestProject/NullSectorTask01/Task01.lean       -- imports everything, states the principal final theorems
```

Every file imports `Mathlib` (transitively, through `Basic.lean`).

## Build

```
lake build RequestProject.NullSectorTask01.Task01
```

The development contains no `sorry`, no `admit`, and no custom `axiom`.
The principal theorems depend only on `propext`, `Classical.choice`, `Quot.sound`.

## Documentation

The full audit — definitions, theorem inventory, dependency graph, stratum and
boost tables, invariant-product result, Regime A / Regime B comparison,
unresolved obligations, source ledger and build/axiom report — is in
[`TASK01_AUDIT.md`](TASK01_AUDIT.md).
