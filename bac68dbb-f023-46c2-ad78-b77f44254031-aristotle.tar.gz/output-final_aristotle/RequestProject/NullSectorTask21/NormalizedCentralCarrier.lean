import RequestProject.NullSectorTask21.CentralProduct

/-!
# Task 21, Packages K and L: modulus/phase splitting and the normalized carrier

**IDENTIFICATION / COMPARISON MODULE.**

Package K splits the identified centre into its positive-modulus factor and its phase
factor, and asks whether the positive-modulus factor splits off the full internal carrier as
a direct central factor.

Package L then compares the resulting *normalized* carrier — the full internal carrier with
unit central modulus — with standard named objects.  The verdicts are recorded in
`TASK21_AUDIT.md`; only what is proved here is claimed.

`IMPORTED STANDARD RESULT`: `Circle`, `Matrix.unitaryGroup`, `Matrix.specialUnitaryGroup`.

Concerning `Spin(3)` and `Spinᶜ(3)`: the installed library provides `spinGroup` for a general
Clifford algebra but no three-dimensional model and no equivalence with unit quaternions, and
no `Spinᶜ` object at all.  Those two verdicts are therefore `NOT FORMALIZED`, and the
quotient expression proved below is kept as the formally proved object (item 108).
-/

set_option synthInstance.maxHeartbeats 400000
set_option maxHeartbeats 1000000

namespace NullSectorTask21

open NullSectorTask01 NullSectorTask04 NullSectorTask06 NullSectorTask07 NullSectorTask08
open NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12 NullSectorTask13
open NullSectorTask14 NullSectorTask15 NullSectorTask16 NullSectorTask17 NullSectorTask18
open NullSectorTask19 NullSectorTask20

open Quaternion Matrix

/-! ## Package K — modulus and phase -/

/-- The positive real numbers as a multiplicative group. -/
abbrev Rpos : Type := {x : ℝ // 0 < x}

/-- **PACKAGE K (item 99).**  The polar decomposition of the nonzero complex numbers as a
group equivalence, with zero excluded constructively. -/
noncomputable def polarEquiv : ℂˣ ≃* Rpos × Circle := by
  sorry

theorem polarEquiv_fst (z : ℂˣ) : ((polarEquiv z).1 : ℝ) = ‖(z : ℂ)‖ := by
  sorry

theorem polarEquiv_snd (z : ℂˣ) :
    (((polarEquiv z).2 : Circle) : ℂ) = (z : ℂ) / (‖(z : ℂ)‖ : ℂ) := by
  sorry

/-! ## The normalized central plane and the normalized carrier -/

/-- **NEUTRAL DEFINITION.**  The unit-modulus part of the exact central plane. -/
def CUnit1 : Set W := {z : W | ∃ a b : ℝ, a ^ 2 + b ^ 2 = 1 ∧ z = zc a b}

theorem CUnit1_subset_CUnit : CUnit1 ⊆ CUnit := by
  sorry

/-- **PACKAGED.**  The unit-modulus central subgroup. -/
def CUnit1G : Subgroup WG where
  carrier := {u : WG | u.val ∈ CUnit1}
  one_mem' := by sorry
  mul_mem' := by sorry
  inv_mem' := by sorry

/-- **NEUTRAL DEFINITION (item 104).**  The normalized full carrier: unit central
modulus. -/
def LiftZ1 : Set W := {u : W | ∃ z ∈ CUnit1, ∃ g ∈ Lift, u = z ⋆ g}

/-- **PACKAGED.**  The normalized full carrier as a group. -/
def LiftZ1G : Subgroup WG where
  carrier := {u : WG | u.val ∈ LiftZ1}
  one_mem' := by sorry
  mul_mem' := by sorry
  inv_mem' := by sorry

/-- The positive central scalars inside the full internal carrier. -/
noncomputable def posCentral : Rpos →* LiftZG where
  toFun r := ⟨⟨zc (r : ℝ) 0, zc (r : ℝ)⁻¹ 0, by sorry, by sorry⟩, by sorry⟩
  map_one' := by sorry
  map_mul' := by sorry

/-- **PACKAGE K (items 103, 112), principal.**  The positive-modulus factor splits off as a
direct central factor: the full internal carrier is the direct product of the positive
scalars and the normalized carrier. -/
noncomputable def liftZSplit : LiftZG ≃* Rpos × LiftZ1G := by
  sorry

/-! ## Package L — the normalized carrier as a central extension -/

/-- **PACKAGE L.**  The standard-side multiplication map into the normalized carrier. -/
noncomputable def muNorm : Circle × UQ →* LiftZ1G := by
  sorry

theorem muNorm_surjective : Function.Surjective muNorm := by
  sorry

/-- The sign element of the phase circle. -/
def circleNegOne : Circle := ⟨-1, by simp [Submonoid.unitSphere, Metric.sphere]⟩

theorem ker_muNorm :
    (muNorm.ker : Set (Circle × UQ)) = {(1, 1), (circleNegOne, uqNegOne)} := by
  sorry

/-- **PACKAGE L (item 105), principal.**  The exact quotient description of the normalized
carrier: it is the central product of the phase circle with the unit-quaternion core, modulo
the diagonal sign. -/
noncomputable def normalizedQuotientEquiv : ((Circle × UQ) ⧸ muNorm.ker) ≃* LiftZ1G :=
  QuotientGroup.quotientKerEquivOfSurjective muNorm muNorm_surjective

/-! ## Comparison with the standard unitary model -/

/-- **PACKAGE L (item 109).**  The standard-side map into the two-dimensional unitary
group. -/
noncomputable def nuU2 : Circle × UQ →* Matrix.unitaryGroup (Fin 2) ℂ where
  toFun wq := ⟨((wq.1 : ℂ) • quatMat (wq.2 : ℍ)), by sorry⟩
  map_one' := by sorry
  map_mul' := by sorry

theorem nuU2_surjective : Function.Surjective nuU2 := by
  sorry

theorem ker_nuU2 : nuU2.ker = muNorm.ker := by
  sorry

/-- **PACKAGE L (item 111), verdict for the unitary model.**  The normalized carrier is
group-equivalent to the standard two-dimensional unitary group. -/
noncomputable def normalizedU2Equiv : LiftZ1G ≃* Matrix.unitaryGroup (Fin 2) ℂ :=
  normalizedQuotientEquiv.symm.trans
    ((QuotientGroup.quotientMulEquivOfEq ker_nuU2.symm).trans
      (QuotientGroup.quotientKerEquivOfSurjective nuU2 nuU2_surjective))

end NullSectorTask21
