import RequestProject.NullSectorTask07.Uniqueness

/-!
# Task 07, Layer 11: generator-order and sign diagnostic

A narrow structural check: how the new product direction responds to

```
A ↔ B,   A ↦ -A,   B ↦ -B.
```

No geometric or physical interpretation is attached to the outcome.
-/

namespace NullSectorTask07

open NullSectorTask01 NullSectorTask04

variable {E : Type*} [AddCommGroup E] [Module ℝ E]

namespace AmbientExt

variable (S : AmbientExt E)

/-- **DERIVED.**  Exchanging the two generators reverses the sign of the mixed
product. -/
theorem swap_generators : S.mul S.genB S.genA = - S.genP := S.mul_genB_genA

/-- **DERIVED.**  Flipping the sign of the first generator reverses the sign of
the mixed product. -/
theorem neg_genA_mixed : S.mul (- S.genA) S.genB = - S.genP := by
  simp [S.mul_genA_genB]

/-- **DERIVED.**  Flipping the sign of the second generator reverses the sign of
the mixed product. -/
theorem neg_genB_mixed : S.mul S.genA (- S.genB) = - S.genP := by
  simp [S.mul_genA_genB]

/-- **DERIVED.**  Flipping both signs leaves the mixed product unchanged. -/
theorem neg_both_mixed : S.mul (- S.genA) (- S.genB) = S.genP := by
  simp [S.mul_genA_genB]

/-- The sign-flipped generators still satisfy the derived generator
relations. -/
theorem neg_generators_relations :
    S.mul (- S.genA) (- S.genA) = S.oneE ∧ S.mul (- S.genB) (- S.genB) = S.oneE ∧
      S.mul (- S.genA) (- S.genB) + S.mul (- S.genB) (- S.genA) = 0 := by
  refine ⟨by simp [S.genA_sq], by simp [S.genB_sq], ?_⟩
  rw [S.neg_both_mixed]
  simp [S.mul_genB_genA]

/-- **SIGN AND ORDER DIAGNOSTIC (summary).**  The new product direction is
sensitive to the order of the generating pair and to the sign of either
generator separately, and insensitive to a simultaneous sign flip of both. -/
theorem sign_audit :
    S.mul S.genB S.genA = - S.genP ∧
    S.mul (- S.genA) S.genB = - S.genP ∧
    S.mul S.genA (- S.genB) = - S.genP ∧
    S.mul (- S.genA) (- S.genB) = S.genP :=
  ⟨S.swap_generators, S.neg_genA_mixed, S.neg_genB_mixed, S.neg_both_mixed⟩

end AmbientExt

/-! ## The same diagnostic in the concrete witness -/

theorem wit_sign_audit :
    witMul witB witA = - witP ∧
    witMul (- witA) witB = - witP ∧
    witMul witA (- witB) = - witP ∧
    witMul (- witA) (- witB) = witP := by
  refine ⟨witB_mul_witA, ?_, ?_, ?_⟩ <;>
    (funext i; fin_cases i <;> simp [witA, witB, witP])

end NullSectorTask07
