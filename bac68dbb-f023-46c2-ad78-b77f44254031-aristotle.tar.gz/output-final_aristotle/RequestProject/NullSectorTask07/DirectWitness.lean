import RequestProject.NullSectorTask07.Minimality

/-!
# Task 07, Layer 9: a direct finite-dimensional existence witness

**Source order.**  This module imports the derivation modules; no derivation
module imports it.  The multiplication rule used below is *not* an oracle: it is
literally the coefficient formula proved in
`GeneratedClosure.mul_gcomb`, which was derived from the inherited square law,
polarization and associativity alone.

A fresh real vector space of the *derived* dimension four is used, namely
`Wit = Fin 4 → ℝ` (a different carrier from `Vec4`), and the product is defined
by the derived coefficient formula.  Bilinearity, the two-sided unit,
associativity, the generator squares, the anticommutation relation and the
value of the mixed product are all proved directly, without importing any known
algebra.
-/

namespace NullSectorTask07

/-- A fresh four-dimensional real carrier for the existence witness. -/
abbrev Wit : Type := Fin 4 → ℝ

/-- The product given by the **derived** coefficient formula. -/
def witMulFun (x y : Wit) : Wit :=
  ![x 0 * y 0 + x 1 * y 1 + x 2 * y 2 - x 3 * y 3,
    x 0 * y 1 + x 1 * y 0 - x 2 * y 3 + x 3 * y 2,
    x 0 * y 2 + x 1 * y 3 + x 2 * y 0 - x 3 * y 1,
    x 0 * y 3 + x 1 * y 2 - x 2 * y 1 + x 3 * y 0]

/-- **EXISTENCE WITNESS: bilinearity.** -/
def witMul : Wit →ₗ[ℝ] Wit →ₗ[ℝ] Wit :=
  LinearMap.mk₂ ℝ witMulFun
    (by intro x₁ x₂ y; funext i; fin_cases i <;> simp [witMulFun] <;> ring)
    (by intro c x y; funext i; fin_cases i <;> simp [witMulFun] <;> ring)
    (by intro x y₁ y₂; funext i; fin_cases i <;> simp [witMulFun] <;> ring)
    (by intro c x y; funext i; fin_cases i <;> simp [witMulFun] <;> ring)

@[simp] theorem witMul_apply (x y : Wit) : witMul x y = witMulFun x y := rfl

@[simp] theorem witMul_coord_zero (x y : Wit) :
    witMul x y 0 = x 0 * y 0 + x 1 * y 1 + x 2 * y 2 - x 3 * y 3 := by simp [witMulFun]

@[simp] theorem witMul_coord_one (x y : Wit) :
    witMul x y 1 = x 0 * y 1 + x 1 * y 0 - x 2 * y 3 + x 3 * y 2 := by simp [witMulFun]

@[simp] theorem witMul_coord_two (x y : Wit) :
    witMul x y 2 = x 0 * y 2 + x 1 * y 3 + x 2 * y 0 - x 3 * y 1 := by simp [witMulFun]

@[simp] theorem witMul_coord_three (x y : Wit) :
    witMul x y 3 = x 0 * y 3 + x 1 * y 2 - x 2 * y 1 + x 3 * y 0 := by simp [witMulFun]

/-- The witness unit. -/
def witOne : Wit := ![1, 0, 0, 0]
/-- The first witness generator. -/
def witA : Wit := ![0, 1, 0, 0]
/-- The second witness generator. -/
def witB : Wit := ![0, 0, 1, 0]
/-- The witness mixed direction. -/
def witP : Wit := ![0, 0, 0, 1]

/-- **EXISTENCE WITNESS: two-sided unit.** -/
theorem witMul_one_left (x : Wit) : witMul witOne x = x := by
  funext i; fin_cases i <;> simp [witOne]

theorem witMul_one_right (x : Wit) : witMul x witOne = x := by
  funext i; fin_cases i <;> simp [witOne]

theorem witTwoSidedUnit : TwoSidedUnitE witMul witOne :=
  ⟨witMul_one_left, witMul_one_right⟩

/-- **EXISTENCE WITNESS: associativity**, proved directly from the derived
coefficient formula. -/
theorem witMul_assoc (x y z : Wit) : witMul (witMul x y) z = witMul x (witMul y z) := by
  funext i; fin_cases i <;> simp [witMulFun] <;> ring

theorem witAssociative : AssociativeE witMul := witMul_assoc

/-- **EXISTENCE WITNESS: first generator square.** -/
theorem witA_sq : witMul witA witA = witOne := by
  funext i; fin_cases i <;> simp [witA, witOne]

/-- **EXISTENCE WITNESS: second generator square.** -/
theorem witB_sq : witMul witB witB = witOne := by
  funext i; fin_cases i <;> simp [witB, witOne]

/-- **EXISTENCE WITNESS: the mixed product.** -/
theorem witA_mul_witB : witMul witA witB = witP := by
  funext i; fin_cases i <;> simp [witA, witB, witP]

theorem witB_mul_witA : witMul witB witA = - witP := by
  funext i; fin_cases i <;> simp [witA, witB, witP]

/-- **EXISTENCE WITNESS: anticommutation.** -/
theorem witAnticomm : witMul witA witB + witMul witB witA = 0 := by
  rw [witA_mul_witB, witB_mul_witA]; abel

/-- **EXISTENCE WITNESS: the square of the mixed direction.** -/
theorem witP_sq : witMul witP witP = - witOne := by
  funext i; fin_cases i <;> simp [witP, witOne]

/-- The four witness elements are linearly independent (hence the witness has
exactly the derived dimension four). -/
theorem wit_indep_coeffs {α β γ δ : ℝ}
    (h : α • witOne + β • witA + γ • witB + δ • witP = 0) :
    α = 0 ∧ β = 0 ∧ γ = 0 ∧ δ = 0 := by
  have h0 := congrFun h 0
  have h1 := congrFun h 1
  have h2 := congrFun h 2
  have h3 := congrFun h 3
  simp [witOne, witA, witB, witP] at h0 h1 h2 h3
  exact ⟨h0, h1, h2, h3⟩

/-- **EXISTENCE WITNESS (summary).**  A real vector space of the derived
dimension four carries a bilinear, unital, associative product realizing
exactly the derived relations. -/
theorem witness_summary :
    AssociativeE witMul ∧ TwoSidedUnitE witMul witOne ∧
    witMul witA witA = witOne ∧ witMul witB witB = witOne ∧
    witMul witA witB + witMul witB witA = 0 ∧
    witMul witA witB = witP ∧ witMul witP witP = - witOne :=
  ⟨witAssociative, witTwoSidedUnit, witA_sq, witB_sq, witAnticomm, witA_mul_witB, witP_sq⟩

end NullSectorTask07
