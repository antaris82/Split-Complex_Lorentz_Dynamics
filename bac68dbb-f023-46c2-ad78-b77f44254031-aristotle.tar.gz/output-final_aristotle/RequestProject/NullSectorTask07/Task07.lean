import RequestProject.NullSectorTask07.Identification

/-!
# Task 07 — principal theorems

This module imports the complete Task-07 development and exposes the principal
results.  The late conventional identification layer is imported here only so
that the axiom report covers it; it is labelled COMPARISON ONLY and no earlier
module depends on it.

Answers to the Conservation-of-Difficulty questions (§32 of the task):

1. relaxing old-carrier closure removes the two-direction associativity
   contradiction — YES (`task07_witness`, `task07_closure`);
2. associativity forces `P = A ⋆ B` outside the embedded old carrier — YES
   (`task07_new_direction`);
3. `P` is linearly independent of the inherited carrier — YES
   (`task07_linear_independence`);
4. the forced identities involving `P` — `task07_forced_relations`;
5. the span of `1, A, B, P` is multiplicatively closed — YES
   (`task07_closure`);
6. its exact dimension is `4` (`task07_dimension`);
7. the closure is minimal (`task07_minimality`);
8. a direct real associative witness exists (`task07_witness`);
9. the minimal closure is unique up to a generator-preserving isomorphism
   (`task07_uniqueness`);
10. the order and the individual signs of the two generators act by `P ↦ -P`
    (`task07_sign_audit`).

Outcome (§33): **Outcome C**.
-/

namespace NullSectorTask07

open NullSectorTask01 NullSectorTask04

variable {E : Type*} [AddCommGroup E] [Module ℝ E]
variable {E' : Type*} [AddCommGroup E'] [Module ℝ E']

/-! ## Inherited data -/

/-- **INHERITED.**  Every sector-compatible bilinear product on the original
carrier has the same diagonal `oldSq`, and `oldSq` is the diagonal of the
forced symmetric product `μsym`. -/
theorem task07_inherited_square_law :
    (∀ M : BiProd4, SectorCompatible M → ∀ X : Vec4, M X X = oldSq X) ∧
    (∀ X : Vec4, oldSq X = musym X X) ∧
    (∀ X : Vec4, (oldSq X).1 = X.1 * X.1 + dot3 X.2 X.2) :=
  ⟨fun _ hM X => sectorCompatible_sq hM X, oldSq_eq_musym, oldSq_time⟩

/-- **INHERITED (INPUT MOTIVATION).**  The Task-06 no-go: no associative
sector-compatible bilinear product exists on the original carrier. -/
theorem task07_inherited_no_go :
    ¬ ∃ M : BiProd4, SectorCompatible M ∧ Associative4 M :=
  inherited_no_associative_closure

/-! ## The ambient extension -/

/-- **DERIVED.**  Polarization recovers the entire inherited symmetric product
after embedding; it is not assumed separately. -/
theorem task07_polarization (S : AmbientExt E) (X Y : Vec4) :
    S.mul (S.iota X) (S.iota Y) + S.mul (S.iota Y) (S.iota X)
      = (2 : ℝ) • S.iota (musym X Y) :=
  S.polarization X Y

/-- **DERIVED.**  The two selected orthogonal spatial directions square to the
unit and anticommute. -/
theorem task07_generator_relations (S : AmbientExt E) :
    S.mul S.genA S.genA = S.oneE ∧ S.mul S.genB S.genB = S.oneE ∧
      S.mul S.genA S.genB + S.mul S.genB S.genA = 0 :=
  ⟨S.genA_sq, S.genB_sq, S.gen_anticomm_sum⟩

/-- **FORCED RELATIONS.**  All products involving the mixed product
`P = A ⋆ B`, derived from associativity. -/
theorem task07_forced_relations (S : AmbientExt E) :
    S.mul S.genA S.genA = S.oneE ∧
    S.mul S.genB S.genB = S.oneE ∧
    S.mul S.genA S.genB = S.genP ∧
    S.mul S.genB S.genA = - S.genP ∧
    S.mul S.genA S.genP = S.genB ∧
    S.mul S.genP S.genA = - S.genB ∧
    S.mul S.genB S.genP = - S.genA ∧
    S.mul S.genP S.genB = S.genA ∧
    S.mul S.genP S.genP = - S.oneE :=
  S.forced_relations

/-- **NEW PRODUCT DIRECTION FORCED / OUTSIDE OLD CARRIER.**  The mixed product
is nonzero and is not the image of any vector of the original carrier; the
local reason is the explicit old-carrier square obstruction. -/
theorem task07_new_direction (S : AmbientExt E) :
    (∀ X : Vec4, oldSq X ≠ - e₀) ∧
    S.genP ≠ 0 ∧
    (¬ ∃ X : Vec4, S.iota X = S.genP) ∧
    S.genP ∉ LinearMap.range S.iota :=
  ⟨oldSq_ne_neg_e₀, S.genP_ne_zero, S.genP_not_image, S.genP_not_mem_range⟩

/-- **DERIVED.**  `1, A, B, P` are linearly independent over `ℝ`. -/
theorem task07_linear_independence (S : AmbientExt E) :
    LinearIndependent ℝ S.genFamily ∧
    (∀ α β γ δ : ℝ, α • S.oneE + β • S.genA + γ • S.genB + δ • S.genP = 0 →
      α = 0 ∧ β = 0 ∧ γ = 0 ∧ δ = 0) :=
  ⟨S.genFamily_linearIndependent, fun _ _ _ _ h => S.gen_indep_coeffs h⟩

/-- **NORMAL FORM.**  Existence and uniqueness of the four coefficients. -/
theorem task07_normal_form (S : AmbientExt E) :
    (∀ x : E, x ∈ S.Gsub ↔ ∃ α β γ δ : ℝ, x = S.gcomb α β γ δ) ∧
    (∀ α β γ δ α' β' γ' δ' : ℝ, S.gcomb α β γ δ = S.gcomb α' β' γ' δ' →
      α = α' ∧ β = β' ∧ γ = γ' ∧ δ = δ') :=
  ⟨S.mem_Gsub_iff, fun _ _ _ _ _ _ _ _ h => S.gcomb_injective h⟩

/-- **CLOSED.**  The generated span is closed under the ambient product, and
products of normal forms reduce to normal forms with the derived
coefficients. -/
theorem task07_closure (S : AmbientExt E) :
    (∀ x ∈ S.Gsub, ∀ y ∈ S.Gsub, S.mul x y ∈ S.Gsub) ∧
    (∀ α β γ δ α' β' γ' δ' : ℝ,
      S.mul (S.gcomb α β γ δ) (S.gcomb α' β' γ' δ') =
        S.gcomb (α * α' + β * β' + γ * γ' - δ * δ')
                (α * β' + β * α' - γ * δ' + δ * γ')
                (α * γ' + β * δ' + γ * α' - δ * β')
                (α * δ' + β * γ' - γ * β' + δ * α')) :=
  ⟨fun _ hx _ hy => S.Gsub_mul_closed hx hy, fun _ _ _ _ _ _ _ _ => S.mul_gcomb _ _ _ _ _ _ _ _⟩

/-- **DERIVED MULTIPLICATION TABLE.** -/
theorem task07_multiplication_table (S : AmbientExt E) :
    (S.mul S.oneE S.oneE = S.oneE ∧ S.mul S.oneE S.genA = S.genA ∧
     S.mul S.oneE S.genB = S.genB ∧ S.mul S.oneE S.genP = S.genP) ∧
    (S.mul S.genA S.oneE = S.genA ∧ S.mul S.genA S.genA = S.oneE ∧
     S.mul S.genA S.genB = S.genP ∧ S.mul S.genA S.genP = S.genB) ∧
    (S.mul S.genB S.oneE = S.genB ∧ S.mul S.genB S.genA = - S.genP ∧
     S.mul S.genB S.genB = S.oneE ∧ S.mul S.genB S.genP = - S.genA) ∧
    (S.mul S.genP S.oneE = S.genP ∧ S.mul S.genP S.genA = - S.genB ∧
     S.mul S.genP S.genB = S.genA ∧ S.mul S.genP S.genP = - S.oneE) :=
  S.multiplication_table

/-- **EXACT DIMENSION (DERIVED).**  The ambient carrier keeps an unspecified
dimension; the generated closure has dimension exactly four. -/
theorem task07_dimension (S : AmbientExt E) : Module.finrank ℝ S.Gsub = 4 :=
  S.finrank_Gsub

/-- **MINIMAL.**  Every product-closed subspace containing the unit and the two
inherited spatial generators contains the mixed product, hence the whole
generated closure. -/
theorem task07_minimality (S : AmbientExt E) :
    S.IsGenClosed S.Gsub ∧
    (∀ H : Submodule ℝ E, S.IsGenClosed H → S.genP ∈ H ∧ S.Gsub ≤ H) :=
  ⟨S.isGenClosed_Gsub, fun _ hH => ⟨S.genP_mem_of_isGenClosed hH, S.Gsub_le_of_isGenClosed hH⟩⟩

/-- **EXISTENCE WITNESS.**  A fresh real vector space of the derived dimension
four carries a bilinear, unital, associative product satisfying exactly the
derived relations. -/
theorem task07_witness :
    AssociativeE witMul ∧ TwoSidedUnitE witMul witOne ∧
    witMul witA witA = witOne ∧ witMul witB witB = witOne ∧
    witMul witA witB + witMul witB witA = 0 ∧
    witMul witA witB = witP ∧ witMul witP witP = - witOne :=
  witness_summary

/-- **UNIQUE UP TO ISOMORPHISM.**  The derived table determines the product
uniquely on the four-dimensional basis, and the generated closures of any two
ambient extensions are isomorphic by the generator-preserving multiplicative
linear equivalence. -/
theorem task07_uniqueness (S : AmbientExt E) (S' : AmbientExt E') :
    (∀ m m' : Wit →ₗ[ℝ] Wit →ₗ[ℝ] Wit,
        (∀ i j : Fin 4, m (witFamily i) (witFamily j) = m' (witFamily i) (witFamily j)) →
        m = m') ∧
    ((S.closureEquiv S' ⟨S.oneE, S.oneE_mem_Gsub⟩ : S'.Gsub) : E') = S'.oneE ∧
    ((S.closureEquiv S' ⟨S.genA, S.genA_mem_Gsub⟩ : S'.Gsub) : E') = S'.genA ∧
    ((S.closureEquiv S' ⟨S.genB, S.genB_mem_Gsub⟩ : S'.Gsub) : E') = S'.genB ∧
    ((S.closureEquiv S' ⟨S.genP, S.genP_mem_Gsub⟩ : S'.Gsub) : E') = S'.genP ∧
    (∀ x y : S.Gsub,
      ((S.closureEquiv S' ⟨S.mul (x : E) (y : E), S.Gsub_mul_closed x.2 y.2⟩ : S'.Gsub) : E')
        = S'.mul (S.closureEquiv S' x) (S.closureEquiv S' y)) :=
  ⟨bilinear_product_unique, S.closureEquiv_oneE S', S.closureEquiv_genA S',
    S.closureEquiv_genB S', S.closureEquiv_genP S', S.closureEquiv_mul S'⟩

/-- **SIGN AND ORDER DIAGNOSTIC.** -/
theorem task07_sign_audit (S : AmbientExt E) :
    S.mul S.genB S.genA = - S.genP ∧
    S.mul (- S.genA) S.genB = - S.genP ∧
    S.mul S.genA (- S.genB) = - S.genP ∧
    S.mul (- S.genA) (- S.genB) = S.genP :=
  S.sign_audit

/-- **COMPARISON ONLY.**  Late conventional identification of the derived
minimal closure. -/
theorem task07_identification :
    Function.Bijective witToMat ∧
    (∀ x y : Wit, witToMat (x + y) = witToMat x + witToMat y) ∧
    (∀ (c : ℝ) (x : Wit), witToMat (c • x) = c • witToMat x) ∧
    (∀ x y : Wit, witToMat (witMul x y) = witToMat x * witToMat y) ∧
    witToMat witOne = 1 :=
  identification_summary

/-! ## Axiom report -/

#print axioms task07_inherited_square_law
#print axioms task07_inherited_no_go
#print axioms task07_polarization
#print axioms task07_generator_relations
#print axioms task07_forced_relations
#print axioms task07_new_direction
#print axioms task07_linear_independence
#print axioms task07_normal_form
#print axioms task07_closure
#print axioms task07_multiplication_table
#print axioms task07_dimension
#print axioms task07_minimality
#print axioms task07_witness
#print axioms task07_uniqueness
#print axioms task07_sign_audit
#print axioms task07_identification

end NullSectorTask07
