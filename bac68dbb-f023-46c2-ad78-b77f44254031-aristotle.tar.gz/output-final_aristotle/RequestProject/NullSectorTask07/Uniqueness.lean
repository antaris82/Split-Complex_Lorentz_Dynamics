import RequestProject.NullSectorTask07.DirectWitness

/-!
# Task 07, Layer 10: uniqueness up to generator-preserving isomorphism

Two results:

1. the derived multiplication table determines a **unique** bilinear product on
   the derived four-dimensional basis;
2. for every ambient extension, the witness carrier maps isomorphically and
   multiplicatively onto the generated closure by the generator-preserving map
   `1 ↦ 1, A ↦ A, B ↦ B, P ↦ P`; consequently the closures of any two ambient
   extensions are isomorphic by a generator-preserving isomorphism.

No standard algebra classification theorem is used.
-/

namespace NullSectorTask07

open NullSectorTask01 NullSectorTask04

/-! ## The derived table determines the product -/

/-- The four witness elements, as a family. -/
def witFamily : Fin 4 → Wit := ![witOne, witA, witB, witP]

theorem witFamily_eq_basisFun (i : Fin 4) : witFamily i = Pi.basisFun ℝ (Fin 4) i := by
  fin_cases i <;> (funext j; fin_cases j <;>
    simp [witFamily, witOne, witA, witB, witP, Pi.basisFun_apply])

/-- **UNIQUENESS OF THE PRODUCT.**  Two bilinear products on the derived
four-dimensional carrier that agree on all sixteen basis pairs are equal:
the derived multiplication table determines the product completely. -/
theorem bilinear_product_unique (m m' : Wit →ₗ[ℝ] Wit →ₗ[ℝ] Wit)
    (h : ∀ i j : Fin 4, m (witFamily i) (witFamily j) = m' (witFamily i) (witFamily j)) :
    m = m' := by
  refine LinearMap.ext_basis (Pi.basisFun ℝ (Fin 4)) (Pi.basisFun ℝ (Fin 4)) ?_
  intro i j
  rw [← witFamily_eq_basisFun, ← witFamily_eq_basisFun]
  exact h i j

variable {E : Type*} [AddCommGroup E] [Module ℝ E]

namespace AmbientExt

variable (S : AmbientExt E)

/-! ## The comparison map -/

/-- The generator-preserving linear map from the witness carrier into the
ambient extension. -/
def witToE : Wit →ₗ[ℝ] E where
  toFun x := S.gcomb (x 0) (x 1) (x 2) (x 3)
  map_add' := by intro x y; simp only [Pi.add_apply, gcomb]; module
  map_smul' := by
    intro c x; simp only [Pi.smul_apply, smul_eq_mul, gcomb, RingHom.id_apply]; module

theorem witToE_apply (x : Wit) : S.witToE x = S.gcomb (x 0) (x 1) (x 2) (x 3) := rfl

@[simp] theorem witToE_witOne : S.witToE witOne = S.oneE := by
  simp [witToE, witOne, gcomb]

@[simp] theorem witToE_witA : S.witToE witA = S.genA := by
  simp [witToE, witA, gcomb]

@[simp] theorem witToE_witB : S.witToE witB = S.genB := by
  simp [witToE, witB, gcomb]

@[simp] theorem witToE_witP : S.witToE witP = S.genP := by
  simp [witToE, witP, gcomb]

/-- **MULTIPLICATIVITY.**  The comparison map intertwines the witness product
with the ambient product. -/
theorem witToE_mul (x y : Wit) :
    S.witToE (witMul x y) = S.mul (S.witToE x) (S.witToE y) := by
  rw [witToE_apply, witToE_apply, witToE_apply, S.mul_gcomb]
  simp only [witMul_coord_zero, witMul_coord_one, witMul_coord_two, witMul_coord_three,
    gcomb]

theorem witToE_injective : Function.Injective S.witToE := by
  rw [injective_iff_map_eq_zero]
  intro x hx
  rw [witToE_apply, gcomb] at hx
  obtain ⟨h0, h1, h2, h3⟩ := S.gen_indep_coeffs hx
  funext i
  fin_cases i <;> simpa using ‹_›

theorem witToE_mem_Gsub (x : Wit) : S.witToE x ∈ S.Gsub := S.gcomb_mem _ _ _ _

theorem witToE_range : LinearMap.range S.witToE = S.Gsub := by
  apply le_antisymm
  · rintro x ⟨w, rfl⟩; exact S.witToE_mem_Gsub w
  · intro x hx
    obtain ⟨α, β, γ, δ, rfl⟩ := (S.mem_Gsub_iff x).1 hx
    exact ⟨![α, β, γ, δ], by simp [witToE, gcomb]⟩

/-- The comparison map, corestricted to the generated closure. -/
def witToG : Wit →ₗ[ℝ] S.Gsub :=
  LinearMap.codRestrict S.Gsub S.witToE S.witToE_mem_Gsub

@[simp] theorem witToG_coe (x : Wit) : (S.witToG x : E) = S.witToE x := rfl

theorem witToG_bijective : Function.Bijective S.witToG := by
  constructor
  · intro x y hxy
    exact S.witToE_injective (congrArg Subtype.val hxy)
  · intro y
    obtain ⟨α, β, γ, δ, hy⟩ := (S.mem_Gsub_iff (y : E)).1 y.2
    exact ⟨![α, β, γ, δ], Subtype.ext (by simp [witToG, witToE, gcomb, hy])⟩

/-- **EXISTENCE WITNESS ≅ GENERATED CLOSURE.**  The derived four-dimensional
witness is linearly isomorphic to the generated closure of any ambient
extension, by the generator-preserving map. -/
noncomputable def witEquivGsub : Wit ≃ₗ[ℝ] S.Gsub :=
  LinearEquiv.ofBijective S.witToG S.witToG_bijective

@[simp] theorem witEquivGsub_coe (x : Wit) : (S.witEquivGsub x : E) = S.witToE x := rfl

end AmbientExt

/-! ## Uniqueness of the minimal closure -/

variable {E' : Type*} [AddCommGroup E'] [Module ℝ E']

namespace AmbientExt

/-- **UNIQUE UP TO ISOMORPHISM.**  The generated closures of any two ambient
extensions are linearly isomorphic by the generator-preserving map
`1 ↦ 1, A ↦ A', B ↦ B', P ↦ P'`, and the isomorphism is multiplicative. -/
noncomputable def closureEquiv (S : AmbientExt E) (S' : AmbientExt E') :
    S.Gsub ≃ₗ[ℝ] S'.Gsub :=
  (S.witEquivGsub).symm.trans S'.witEquivGsub

theorem closureEquiv_apply (S : AmbientExt E) (S' : AmbientExt E') (x : S.Gsub) :
    ((S.closureEquiv S' x : E') ) = S'.witToE (S.witEquivGsub.symm x) := rfl

theorem closureEquiv_oneE (S : AmbientExt E) (S' : AmbientExt E') :
    ((S.closureEquiv S' ⟨S.oneE, S.oneE_mem_Gsub⟩ : S'.Gsub) : E') = S'.oneE := by
  have h : S.witEquivGsub witOne = ⟨S.oneE, S.oneE_mem_Gsub⟩ := by
    apply Subtype.ext; exact S.witToE_witOne
  rw [closureEquiv_apply, ← h, LinearEquiv.symm_apply_apply, S'.witToE_witOne]

theorem closureEquiv_genA (S : AmbientExt E) (S' : AmbientExt E') :
    ((S.closureEquiv S' ⟨S.genA, S.genA_mem_Gsub⟩ : S'.Gsub) : E') = S'.genA := by
  have h : S.witEquivGsub witA = ⟨S.genA, S.genA_mem_Gsub⟩ := by
    apply Subtype.ext; exact S.witToE_witA
  rw [closureEquiv_apply, ← h, LinearEquiv.symm_apply_apply, S'.witToE_witA]

theorem closureEquiv_genB (S : AmbientExt E) (S' : AmbientExt E') :
    ((S.closureEquiv S' ⟨S.genB, S.genB_mem_Gsub⟩ : S'.Gsub) : E') = S'.genB := by
  have h : S.witEquivGsub witB = ⟨S.genB, S.genB_mem_Gsub⟩ := by
    apply Subtype.ext; exact S.witToE_witB
  rw [closureEquiv_apply, ← h, LinearEquiv.symm_apply_apply, S'.witToE_witB]

theorem closureEquiv_genP (S : AmbientExt E) (S' : AmbientExt E') :
    ((S.closureEquiv S' ⟨S.genP, S.genP_mem_Gsub⟩ : S'.Gsub) : E') = S'.genP := by
  have h : S.witEquivGsub witP = ⟨S.genP, S.genP_mem_Gsub⟩ := by
    apply Subtype.ext; exact S.witToE_witP
  rw [closureEquiv_apply, ← h, LinearEquiv.symm_apply_apply, S'.witToE_witP]

/-- **MULTIPLICATIVE COMPATIBILITY** of the closure isomorphism. -/
theorem closureEquiv_mul (S : AmbientExt E) (S' : AmbientExt E') (x y : S.Gsub) :
    ((S.closureEquiv S' ⟨S.mul (x : E) (y : E), S.Gsub_mul_closed x.2 y.2⟩ : S'.Gsub) : E')
      = S'.mul (S.closureEquiv S' x) (S.closureEquiv S' y) := by
  set u := S.witEquivGsub.symm x with hu
  set v := S.witEquivGsub.symm y with hv
  have hx : (x : E) = S.witToE u := by
    rw [hu, ← AmbientExt.witEquivGsub_coe, LinearEquiv.apply_symm_apply]
  have hy : (y : E) = S.witToE v := by
    rw [hv, ← AmbientExt.witEquivGsub_coe, LinearEquiv.apply_symm_apply]
  have hxy : S.witEquivGsub (witMul u v)
      = ⟨S.mul (x : E) (y : E), S.Gsub_mul_closed x.2 y.2⟩ := by
    apply Subtype.ext
    rw [AmbientExt.witEquivGsub_coe, S.witToE_mul, ← hx, ← hy]
  rw [closureEquiv_apply, ← hxy, LinearEquiv.symm_apply_apply, S'.witToE_mul]
  rfl

end AmbientExt

end NullSectorTask07
