import RequestProject.NullSectorTask13.Identification

/-!
# Task 13 — principal theorems and axiom report

This module imports the complete Task-13 development and exposes the principal results.
The twenty-five questions of the Conservation-of-Difficulty audit (§49) are answered
below, in order, with the status vocabulary of §58.

**Firewalls.**  Experiment 1 is not used anywhere.  No spinor, `ℂ²`, Pauli, `SU(2)`,
`Spin`, projective- or spin-representation input enters the reconstruction core; the only
conventional identification is the comparison layer, imported by this module and by
nothing else.  No inner product, no norm, no projective quotient, no probability
interpretation, no physical time reading, no full rotation group, no boost and no field
equation occurs.

**NOT PHYSICAL SPIN.**  The reduced carrier action classified here is an intrinsic
algebraic transformation structure; no physical state interpretation is claimed.
-/

namespace NullSectorTask13

open NullSectorTask08 NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12

/-! ## 1. Is the missing `H₋` stabilizer exactly the counterpart of the `H₊` one? -/

/-- **1 (§1).  DERIVED, AXIS-RELATIVE: `minus_sector_stabilizer_exact`.**  The exact left
stabilizer of the minus sector is the kernel of the opposite compression, has real
dimension six, is a subalgebra containing the unit, the centre and the axis but not the
transverse generator, and is carried onto the plus stabilizer by the inherited inner
automorphism that reverses the axis. -/
theorem task13_minus_sector_stabilizer_exact :
    StabL Hminus = LinearMap.ker crossMP ∧
    Module.finrank ℝ (StabL Hminus) = 6 ∧
    (∀ x : W, x ∈ StabL Hminus ↔ x 2 + x 4 = 0 ∧ x 3 + x 5 = 0) ∧
    (∀ x : W, x ∈ StabL Hplus ↔ x 2 - x 4 = 0 ∧ x 3 - x 5 = 0) ∧
    (w1 ∈ StabL Hminus ∧ wS ∈ StabL Hminus ∧ wA ∈ StabL Hminus ∧ wB ∉ StabL Hminus ∧
      ∀ x ∈ StabL Hminus, ∀ y ∈ StabL Hminus, x ⋆ y ∈ StabL Hminus) ∧
    (∀ x : W, x ∈ StabL Hminus ↔ conjB x ∈ StabL Hplus) :=
  ⟨StabL_Hminus_eq_ker, finrank_StabL_Hminus, mem_StabL_Hminus_iff_coords,
    mem_StabL_Hplus_iff_coords, StabL_Hminus_algebra, conjB_StabL_iff⟩

/-! ## 2. Is `H₋` reducible under its exact stabilizer? -/

/-- **2 (§1).  DERIVED: `minus_sector_reducible`, `REDUCIBLE`. -/
theorem task13_minus_sector_reducible :
    Zspan eminus ≤ Hminus ∧ Zspan eminus ≠ ⊥ ∧ Zspan eminus ≠ Hminus ∧
      ∀ x ∈ StabL Hminus, ∀ ψ ∈ Zspan eminus, x ⋆ ψ ∈ Zspan eminus :=
  Hminus_reducible

/-! ## 3, 4. Are the slices stable under the exact center? -/

/-- **3, 4 (§9).  DERIVED, CENTRAL, CARRIER-INDEPENDENT.**  Both axis-relative slices of
every left carrier are stable under the exact center. -/
theorem task13_slices_central_stable {L : Submodule ℝ W} (hL : IsLeftCarrier L) {z : W}
    (hz : z ∈ Z) :
    (∀ ψ ∈ Kplus L, z ⋆ ψ ∈ Kplus L) ∧ (∀ ψ ∈ Kminus L, z ⋆ ψ ∈ Kminus L) :=
  ⟨fun _ hψ => Kplus_central_stable hL hz hψ, fun _ hψ => Kminus_central_stable hL hz hψ⟩

/-! ## 5. The exact central rank of each slice -/

/-- **5 (§8, §9).  DERIVED: `slice_plus_dim`, `slice_minus_dim`,
`slice_plus_central_rank`, `slice_minus_central_rank`.**  Each slice has real dimension
two and central rank one: it is the plane of central multiples of any one of its nonzero
elements, with unique coefficients.  A generator is never canonically selected. -/
theorem task13_slice_central_rank {L : Submodule ℝ W} (hL : IsMinimalLeftCarrier L) :
    Module.finrank ℝ (Kplus L) = 2 ∧ Module.finrank ℝ (Kminus L) = 2 ∧
    Kplus L ⊔ Kminus L = L ∧ Kplus L ⊓ Kminus L = ⊥ ∧
    (∀ ψ ∈ Kplus L, ψ ≠ 0 → Kplus L = Zspan ψ) ∧
    (∀ ψ ∈ Kminus L, ψ ≠ 0 → Kminus L = Zspan ψ) ∧
    (∀ ψ ∈ Kplus L, ψ ≠ 0 → ∀ φ ∈ Kplus L, ∃! p : ℝ × ℝ, φ = zz p.1 p.2 ⋆ ψ) ∧
    (∀ ψ ∈ Kminus L, ψ ≠ 0 → ∀ φ ∈ Kminus L, ∃! p : ℝ × ℝ, φ = zz p.1 p.2 ⋆ ψ) :=
  ⟨finrank_Kplus hL, finrank_Kminus hL, (carrier_slice_direct_sum hL).1,
    (carrier_slice_direct_sum hL).2,
    fun _ hψ hne => Kplus_eq_Zspan hL hψ hne, fun _ hψ hne => Kminus_eq_Zspan hL hψ hne,
    fun _ hψ hne _ hφ => Kplus_central_representation hL hψ hne hφ,
    fun _ hψ hne _ hφ => Kminus_central_representation hL hψ hne hφ⟩

/-! ## 6. Does the reference lift preserve both slices, for every minimal carrier? -/

/-- **6 (§14).  DERIVED, CARRIER-INDEPENDENT: `reference_preserves_plus_slice`,
`reference_preserves_minus_slice`. -/
theorem task13_reference_preserves_slices {L : Submodule ℝ W} (hL : IsMinimalLeftCarrier L)
    (θ : ℝ) :
    Submodule.map (Lmul (Uref θ)) (Kplus L) = Kplus L ∧
    Submodule.map (Lmul (Uref θ)) (Kminus L) = Kminus L :=
  ⟨reference_preserves_plus_slice hL.1.1 θ, reference_preserves_minus_slice hL.1.1 θ⟩

/-! ## 7, 8. The exact reference action on each slice -/

/-- **7, 8 (§15, §16).  DERIVED, REFERENCE LIFT: `reference_action_plus_exact`,
`reference_action_minus_exact`. -/
theorem task13_reference_sector_actions {L : Submodule ℝ W} (_hL : IsMinimalLeftCarrier L)
    (θ : ℝ) :
    (∀ ψ ∈ Kplus L, Uref θ ⋆ ψ = zz (Real.cos (θ / 2)) (-Real.sin (θ / 2)) ⋆ ψ) ∧
    (∀ ψ ∈ Kminus L, Uref θ ⋆ ψ = zz (Real.cos (θ / 2)) (Real.sin (θ / 2)) ⋆ ψ) :=
  ⟨fun _ hψ => reference_action_plus_exact hψ.2 θ,
    fun _ hψ => reference_action_minus_exact hψ.2 θ⟩

/-! ## 9. Is the opposite-sector relation universal? -/

/-- **9 (§17).  DERIVED: `reference_relative_action_exact`.**  The two sector factors are
mutually inverse central units and differ by the fixed full-angle relative factor. -/
theorem task13_reference_relative_action (θ : ℝ) :
    cPlusRef θ ⋆ cMinusRef θ = w1 ∧
    cPlusRef θ = RelRef θ ⋆ cMinusRef θ ∧
    RelRef θ = cPlusRef θ ⋆ cPlusRef θ ∧
    cMinusRef θ ⋆ cPlusRef θ = w1 :=
  reference_relative_action_exact θ

/-! ## 10. Does the reference action depend on the literal carrier? -/

/-- **10 (§18).  DERIVED, `CARRIER-INDEPENDENT`. -/
theorem task13_reference_action_carrier_independent {L L' : Submodule ℝ W}
    (hL : IsMinimalLeftCarrier L) (hL' : IsMinimalLeftCarrier L') (θ : ℝ) :
    (∀ ψ ∈ Kplus L, Uref θ ⋆ ψ = cPlusRef θ ⋆ ψ) ∧
    (∀ ψ ∈ Kplus L', Uref θ ⋆ ψ = cPlusRef θ ⋆ ψ) ∧
    (∀ ψ ∈ Kminus L, Uref θ ⋆ ψ = cMinusRef θ ⋆ ψ) ∧
    (∀ ψ ∈ Kminus L', Uref θ ⋆ ψ = cMinusRef θ ⋆ ψ) :=
  reference_action_carrier_independent hL hL' θ

/-! ## 11. How does the arbitrary `(α, β)` freedom modify each slice? -/

/-- **11 (§20, §21).  DERIVED, FULL LIFT: `full_lift_action_plus_exact`,
`full_lift_action_minus_exact`.**  Both slices are preserved by every full lift, and the
exact central factors of the continuous family are the closed-form ones. -/
theorem task13_full_lift_sector_actions {L : Submodule ℝ W} (hL : IsMinimalLeftCarrier L)
    (α β θ : ℝ) :
    Submodule.map (Lmul ((fun t => zexp α β t ⋆ Uref t) θ)) (Kplus L) = Kplus L ∧
    Submodule.map (Lmul ((fun t => zexp α β t ⋆ Uref t) θ)) (Kminus L) = Kminus L ∧
    (∀ ψ ∈ Kplus L, (fun t => zexp α β t ⋆ Uref t) θ ⋆ ψ = cPlusFull α β θ ⋆ ψ) ∧
    (∀ ψ ∈ Kminus L, (fun t => zexp α β t ⋆ Uref t) θ ⋆ ψ = cMinusFull α β θ ⋆ ψ) := by
  have hU : IsFullLift (fun t => zexp α β t ⋆ Uref t) :=
    ((continuousFullLift_classification _).2 ⟨α, β, fun _ => rfl⟩).toIsFullLift
  refine ⟨(fullLift_preserves_slices hL.1.1 hU θ).1,
    (fullLift_preserves_slices hL.1.1 hU θ).2, ?_, ?_⟩
  · intro ψ hψ
    exact (continuous_full_lift_sector_factors (fun _ => rfl) θ).1 ψ hψ.2
  · intro ψ hψ
    exact (continuous_full_lift_sector_factors (fun _ => rfl) θ).2 ψ hψ.2

/-! ## 12, 13, 14. Common factor, relative factor, lift-independence -/

/-- **12, 13, 14 (§22, §23).  DERIVED: `full_lift_relative_action_independent`,
`COMMON FACTOR` versus `RELATIVE FACTOR`.**  For every full lift the two slice factors
share the arbitrary central residual, their relative factor is the fixed central element
`Rel(θ)`, and it is the unique solution of the division-free relation.  The relative
sector transformation is therefore `LIFT-INDEPENDENT` and `CARRIER-INDEPENDENT`. -/
theorem task13_common_versus_relative {L : Submodule ℝ W} (hL : IsMinimalLeftCarrier L)
    {U : ℝ → W} (hU : IsFullLift U) :
    ∃ z : ℝ → W, IsCentralHom z ∧
      (∀ (θ : ℝ), ∀ ψ ∈ Kplus L, U θ ⋆ ψ = (z θ ⋆ cPlusRef θ) ⋆ ψ) ∧
      (∀ (θ : ℝ), ∀ ψ ∈ Kminus L, U θ ⋆ ψ = (z θ ⋆ cMinusRef θ) ⋆ ψ) ∧
      (∀ θ : ℝ, z θ ⋆ cPlusRef θ = RelRef θ ⋆ (z θ ⋆ cMinusRef θ)) ∧
      (∀ (θ : ℝ) (r : W), z θ ⋆ cPlusRef θ = r ⋆ (z θ ⋆ cMinusRef θ) → r = RelRef θ) :=
  common_versus_relative_classification hL hU

/-! ## 15, 16. The exact restricted infinitesimal generators -/

/-- **15, 16 (§24, §25).  DERIVED: `infinitesimal_plus_exact`,
`infinitesimal_minus_exact`, `infinitesimal_relative_exact`.**  The restricted generators
are the central elements `α • 1 + (β ∓ 1/2) • S`; the common part is `α • 1 + β • S` and
the relative part is the fixed `-S`, for every `(α, β)`. -/
theorem task13_infinitesimal_restriction {L : Submodule ℝ W} (_hL : IsMinimalLeftCarrier L)
    (α β : ℝ) :
    (∀ ψ ∈ Kplus L, Ggen α β ⋆ ψ = zz α (β - 2⁻¹) ⋆ ψ) ∧
    (∀ ψ ∈ Kminus L, Ggen α β ⋆ ψ = zz α (β + 2⁻¹) ⋆ ψ) ∧
    zz α (β - 2⁻¹) - zz α (β + 2⁻¹) = -wS ∧
    (∀ α' β' : ℝ, zz α' (β' - 2⁻¹) - zz α' (β' + 2⁻¹)
      = zz α (β - 2⁻¹) - zz α (β + 2⁻¹)) :=
  ⟨fun _ hψ => infinitesimal_plus_exact hψ.2 α β,
    fun _ hψ => infinitesimal_minus_exact hψ.2 α β,
    infinitesimal_relative_exact α β,
    (infinitesimal_common_relative_split α β).2.2.2⟩

/-- **16 bis (§26).  DERIVED.**  The Task-10 rate `λ` is not a combination of `(α, β)`:
the induced derivation is `Dgen` for every `(α, β)`, forcing `λ = 1`, while `(α, β)`
remain free and visible on the carrier. -/
theorem task13_rate_versus_residual (α β : ℝ) :
    inducedDer (Ggen α β) = Dgen ∧
    (∀ α' β' : ℝ, inducedDer (Ggen α' β') = inducedDer (Ggen α β)) ∧
    (∀ l : ℝ, (∀ x : W, inducedDer (Ggen α β) x = l • Dgen x) ↔ l = 1) :=
  rate_versus_residual_separation α β

/-! ## 17, 18, 19. Carrier equivalences against slices and lifts -/

/-- **17, 18, 19 (§30, §31, §32).  DERIVED, `INTERTWINED`:
`carrier_equiv_preserves_plus_slice`, `carrier_equiv_preserves_minus_slice`,
`carrier_equiv_intertwines_reference`, `carrier_equiv_intertwines_full_lift`. -/
theorem task13_carrier_equivalence_compatibility {L L' : Submodule ℝ W}
    (hL : IsMinimalLeftCarrier L) (hL' : IsMinimalLeftCarrier L') :
    ∃ r : W,
      (∀ ψ ∈ Kplus L, ψ ⋆ r ∈ Kplus L') ∧
      (∀ ψ ∈ Kminus L, ψ ⋆ r ∈ Kminus L') ∧
      (∀ φ ∈ Kplus L', ∃ ψ ∈ Kplus L, ψ ⋆ r = φ) ∧
      (∀ φ ∈ Kminus L', ∃ ψ ∈ Kminus L, ψ ⋆ r = φ) ∧
      (∀ (θ : ℝ) (ψ : W), (Uref θ ⋆ ψ) ⋆ r = Uref θ ⋆ (ψ ⋆ r)) ∧
      (∀ (U : ℝ → W), IsFullLift U → ∀ (θ : ℝ) (ψ : W),
        (U θ ⋆ ψ) ⋆ r = U θ ⋆ (ψ ⋆ r)) ∧
      (∀ (θ : ℝ), (∀ ψ ∈ Kplus L, Uref θ ⋆ ψ = cPlusRef θ ⋆ ψ) ∧
        (∀ ψ ∈ Kplus L', Uref θ ⋆ ψ = cPlusRef θ ⋆ ψ) ∧
        (∀ ψ ∈ Kminus L, Uref θ ⋆ ψ = cMinusRef θ ⋆ ψ) ∧
        (∀ ψ ∈ Kminus L', Uref θ ⋆ ψ = cMinusRef θ ⋆ ψ)) :=
  universal_axial_carrier_type hL hL'

/-! ## 20. One axial transformation type across all minimal carriers? -/

/-- **20 (§33).  VERDICT: `UNIVERSAL AXIAL CARRIER TYPE`.**  Same statement as question
17–19, read as the universality criterion: every pair of minimal carriers is related by an
equivalence matching the slices and intertwining every lift, with identical central sector
factors. -/
theorem task13_universal_axial_carrier_type {L L' : Submodule ℝ W}
    (hL : IsMinimalLeftCarrier L) (hL' : IsMinimalLeftCarrier L') :
    ∃ r : W,
      (∀ ψ ∈ Kplus L, ψ ⋆ r ∈ Kplus L') ∧
      (∀ ψ ∈ Kminus L, ψ ⋆ r ∈ Kminus L') ∧
      (∀ φ ∈ Kplus L', ∃ ψ ∈ Kplus L, ψ ⋆ r = φ) ∧
      (∀ φ ∈ Kminus L', ∃ ψ ∈ Kminus L, ψ ⋆ r = φ) ∧
      (∀ (θ : ℝ) (ψ : W), (Uref θ ⋆ ψ) ⋆ r = Uref θ ⋆ (ψ ⋆ r)) ∧
      (∀ (U : ℝ → W), IsFullLift U → ∀ (θ : ℝ) (ψ : W),
        (U θ ⋆ ψ) ⋆ r = U θ ⋆ (ψ ⋆ r)) ∧
      (∀ (θ : ℝ), (∀ ψ ∈ Kplus L, Uref θ ⋆ ψ = cPlusRef θ ⋆ ψ) ∧
        (∀ ψ ∈ Kplus L', Uref θ ⋆ ψ = cPlusRef θ ⋆ ψ) ∧
        (∀ ψ ∈ Kminus L, Uref θ ⋆ ψ = cMinusRef θ ⋆ ψ) ∧
        (∀ ψ ∈ Kminus L', Uref θ ⋆ ψ = cMinusRef θ ⋆ ψ)) :=
  universal_axial_carrier_type hL hL'

/-! ## 21. How does the automorphism family act on the family of carriers? -/

/-- **21 (§34).  DERIVED: `phi_maps_minimal_carriers`.**  The carrier-family action is a
one-parameter group action on the minimal carriers, is right multiplication by the inverse
lift, and is *not* the internal left action, which preserves every minimal carrier. -/
theorem task13_phi_carrier_family_action :
    (∀ (L : Submodule ℝ W), IsMinimalLeftCarrier L → ∀ θ : ℝ,
      IsMinimalLeftCarrier (phiCarrier θ L)) ∧
    (∀ (U : ℝ → W), IsFullLift U → ∀ (L : Submodule ℝ W), IsMinimalLeftCarrier L →
      ∀ θ : ℝ, Submodule.map (Lmul (U θ)) L = L) ∧
    (∀ (U : ℝ → W), IsFullLift U → ∀ (L : Submodule ℝ W), IsLeftCarrier L → ∀ θ : ℝ,
      phiCarrier θ L = Submodule.map (Rmul (U (-θ))) L) ∧
    phiCarrier (Real.pi / 2) (Lgen (esph 0 1 0)) ≠ Lgen (esph 0 1 0) :=
  ⟨fun _ hL θ => phi_maps_minimal_carriers hL θ,
    internal_action_versus_carrier_action.1,
    internal_action_versus_carrier_action.2.1,
    internal_action_versus_carrier_action.2.2⟩

/-! ## 22. The exact global fixed locus -/

/-- **22 (§35, §36).  DERIVED: `phi_fixed_carrier_iff`, `FIXED CARRIER`.**  Every minimal
carrier is generated by a unique point of the explicit unit two-sphere; the carriers fixed
by the whole automorphism family are exactly the two axial ones; and the exact criterion
for fixity at a single parameter value is also given. -/
theorem task13_phi_fixed_locus :
    (∀ L : Submodule ℝ W, IsMinimalLeftCarrier L →
      ∃ n₁ n₂ n₃ : ℝ, n₁ ^ 2 + n₂ ^ 2 + n₃ ^ 2 = 1 ∧ L = Lgen (esph n₁ n₂ n₃)) ∧
    (∀ L : Submodule ℝ W, IsMinimalLeftCarrier L →
      ((∀ θ : ℝ, phiCarrier θ L = L) ↔ L = Lgen eplus ∨ L = Lgen eminus)) ∧
    {L : Submodule ℝ W | IsMinimalLeftCarrier L ∧ ∀ θ : ℝ, phiCarrier θ L = L}
      = {Lgen eplus, Lgen eminus} ∧
    (∀ (n₁ n₂ n₃ : ℝ), n₁ ^ 2 + n₂ ^ 2 + n₃ ^ 2 = 1 → ∀ θ : ℝ,
      (phiCarrier θ (Lgen (esph n₁ n₂ n₃)) = Lgen (esph n₁ n₂ n₃) ↔
        (Real.cos θ = 1 ∧ Real.sin θ = 0) ∨ (n₂ = 0 ∧ n₃ = 0))) :=
  ⟨fun _ hL => minimal_eq_Lgen_esph hL, fun _ hL => phi_fixed_carrier_iff hL,
    phi_fixed_locus_exact.1, fun _ _ _ hn θ => phi_fixed_single_angle hn θ⟩

/-! ## 23. Does the axial structure select one carrier? -/

/-- **23 (§37).  VERDICT: `AXIAL DATA SELECT A FINITE FAMILY` (exactly two), together with
the §38 separation of selection from transformation. -/
theorem task13_axial_selection_verdict :
    {L : Submodule ℝ W | IsMinimalLeftCarrier L}.Infinite ∧
    {L : Submodule ℝ W | IsMinimalLeftCarrier L ∧ ∀ θ : ℝ, phiCarrier θ L = L}
      = {Lgen eplus, Lgen eminus} ∧
    Lgen eplus ≠ Lgen eminus ∧
    (∀ L : Submodule ℝ W, IsMinimalLeftCarrier L → ∀ θ : ℝ,
      (∀ ψ ∈ Kplus L, Uref θ ⋆ ψ = cPlusRef θ ⋆ ψ) ∧
      (∀ ψ ∈ Kminus L, Uref θ ⋆ ψ = cMinusRef θ ⋆ ψ)) :=
  ⟨axial_selection_verdict.1, axial_selection_verdict.2.1, axial_selection_verdict.2.2,
    selection_versus_transformation.1⟩

/-! ## 24, 25. Does any carrier-intrinsic requirement force `α = β = 0`? -/

/-- **24, 25 (§50).  VERDICT: `NO NORMALIZATION DERIVED`.**  Every inherited
carrier-structural requirement is satisfied for arbitrary `(α, β)`, distinct parameters
give distinct lifts, and the unresolved freedom therefore remains exactly the Task-11
two-parameter residual family. -/
theorem task13_no_normalization_derived (α β : ℝ) :
    IsContinuousFullLift (fun θ => zexp α β θ ⋆ Uref θ) ∧
    (∀ L : Submodule ℝ W, IsMinimalLeftCarrier L → ∀ θ : ℝ,
      Submodule.map (Lmul ((fun θ => zexp α β θ ⋆ Uref θ) θ)) L = L) ∧
    (∀ L : Submodule ℝ W, IsMinimalLeftCarrier L → ∀ θ : ℝ,
      Submodule.map (Lmul ((fun θ => zexp α β θ ⋆ Uref θ) θ)) (Kplus L) = Kplus L ∧
      Submodule.map (Lmul ((fun θ => zexp α β θ ⋆ Uref θ) θ)) (Kminus L) = Kminus L) ∧
    (∀ θ : ℝ, (∀ ψ ∈ Hplus, (fun θ => zexp α β θ ⋆ Uref θ) θ ⋆ ψ = cPlusFull α β θ ⋆ ψ) ∧
      (∀ ψ ∈ Hminus, (fun θ => zexp α β θ ⋆ Uref θ) θ ⋆ ψ = cMinusFull α β θ ⋆ ψ)) ∧
    (∀ (r ψ : W) (θ : ℝ), ((fun θ => zexp α β θ ⋆ Uref θ) θ ⋆ ψ) ⋆ r
      = (fun θ => zexp α β θ ⋆ Uref θ) θ ⋆ (ψ ⋆ r)) :=
  no_normalization_derived α β

/-! ## Further principal results: `2π`/`4π` audit, central compatibility, commutants -/

/-- **§28.  DERIVED.**  The exact `2π` and `4π` behaviour of a generic full lift on the
reduced carrier, and the strict distinction from the algebra automorphism, which is
already the identity at `2π`. -/
theorem task13_two_pi_four_pi {U z : ℝ → W} (hz : ∀ θ, U θ = z θ ⋆ Uref θ) :
    Phi (2 * Real.pi) = LinearMap.id ∧
    (∀ ψ ∈ Hplus, U (2 * Real.pi) ⋆ ψ = -(z (2 * Real.pi) ⋆ ψ)) ∧
    (∀ ψ ∈ Hminus, U (2 * Real.pi) ⋆ ψ = -(z (2 * Real.pi) ⋆ ψ)) ∧
    (∀ ψ ∈ Hplus, U (4 * Real.pi) ⋆ ψ = z (4 * Real.pi) ⋆ ψ) ∧
    (∀ ψ ∈ Hminus, U (4 * Real.pi) ⋆ ψ = z (4 * Real.pi) ⋆ ψ) :=
  ⟨Phi_two_pi, (full_lift_two_pi_four_pi hz).1, (full_lift_two_pi_four_pi hz).2.1,
    (full_lift_two_pi_four_pi hz).2.2.1, (full_lift_two_pi_four_pi hz).2.2.2⟩

/-- **§40.  DERIVED.**  The restricted axial action commutes with the internal central
endomorphism algebra of the carrier. -/
theorem task13_central_compatibility {U : ℝ → W} (hU : IsFullLift U) {z : W} (hz : z ∈ Z)
    (θ : ℝ) (ψ : W) : U θ ⋆ (z ⋆ ψ) = z ⋆ (U θ ⋆ ψ) :=
  fullLift_central_compatibility hU hz θ ψ

/-- **§41.  DERIVED.**  The two commutants on a slice: the endomorphisms commuting with
the restricted central action, and those commuting with the whole restricted reference
family, are the same — exactly the central multiplications. -/
theorem task13_slice_commutants {L : Submodule ℝ W} (hL : IsMinimalLeftCarrier L)
    {ψ : W} (hψ : ψ ∈ Kplus L) (hne : ψ ≠ 0) (T : Kplus L →ₗ[ℝ] Kplus L) :
    ((∀ φ : Kplus L, (T (SopP hL.1.1 φ) : W) = wS ⋆ ((T φ : Kplus L) : W)) ↔
      ∃ a b : ℝ, ∀ φ : Kplus L, ((T φ : Kplus L) : W) = zz a b ⋆ (φ : W)) ∧
    ((∀ θ : ℝ, T.comp (rhoRefP hL.1.1 θ) = (rhoRefP hL.1.1 θ).comp T) ↔
      ∃ a b : ℝ, ∀ φ : Kplus L, ((T φ : Kplus L) : W) = zz a b ⋆ (φ : W)) :=
  ⟨slice_plus_central_commutant hL hψ hne T, slice_plus_axial_commutant hL hψ hne T⟩

/-! ## §51 — the optional additional compatibility test -/

/-- **§51.  `ADDITIONAL COMPATIBILITY`, secondary.**  Only the explicitly added Task-11
conditional quadratic test collapses the residual parameters. -/
theorem task13_additional_compatibility {α β : ℝ}
    (hpres : PreservesLeftQuadratic Nplus (fun θ => zexp α β θ ⋆ Uref θ)) :
    α = 0 ∧ β = 0 ∧ PreservesLeftQuadratic Nminus (fun θ => zexp α β θ ⋆ Uref θ) :=
  additional_compatibility_collapses_parameters hpres

/-! ## Axiom report (§56) -/

#print axioms task13_minus_sector_stabilizer_exact
#print axioms task13_minus_sector_reducible
#print axioms task13_slices_central_stable
#print axioms task13_slice_central_rank
#print axioms task13_reference_preserves_slices
#print axioms task13_reference_sector_actions
#print axioms task13_reference_relative_action
#print axioms task13_reference_action_carrier_independent
#print axioms task13_full_lift_sector_actions
#print axioms task13_common_versus_relative
#print axioms task13_infinitesimal_restriction
#print axioms task13_rate_versus_residual
#print axioms task13_carrier_equivalence_compatibility
#print axioms task13_universal_axial_carrier_type
#print axioms task13_phi_carrier_family_action
#print axioms task13_phi_fixed_locus
#print axioms task13_axial_selection_verdict
#print axioms task13_no_normalization_derived
#print axioms task13_two_pi_four_pi
#print axioms task13_central_compatibility
#print axioms task13_slice_commutants
#print axioms task13_additional_compatibility
#print axioms comparison_summary

end NullSectorTask13
