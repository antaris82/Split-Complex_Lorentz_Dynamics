import RequestProject.NullSectorTask13.SelectionAudit
import RequestProject.NullSectorTask12.Identification

/-!
# Task 13, Layer 13: late conventional identification — **COMPARISON ONLY**

Every statement in this module is labelled **COMPARISON ONLY**.  Nothing here is used in
the reconstruction core: the module is imported by the top-level `Task13.Task13` and by
nothing else, and each theorem only *re-reads*, in conventional language, a result already
established intrinsically in Layers 0–12 (§52).

The comparison isomorphism is the Task-08 one, `toMat`, with the algebra of `2 × 2`
complex matrices.

**Strict limit of the comparison (§53).**  The permitted conclusion is only:

*the independently reconstructed one-axis carrier action is algebraically equivalent to
the standard axial spinorial action.*

No fermion, no physical spin-1/2, no electron, no quantum mechanics and no physical state
interpretation follows.  Labels: `COMPARISON ONLY`, `NOT PHYSICAL SPIN`.
-/

namespace NullSectorTask13

open NullSectorTask08 NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12

/-! ## COMPARISON ONLY — 1. the two central sector factors are conjugate phases -/

/-- **COMPARISON ONLY.**  Under the comparison isomorphism the reconstructed plus factor
is the complex scalar `cos(θ/2) − i sin(θ/2)`, and the minus factor is its conjugate
`cos(θ/2) + i sin(θ/2)`.  These are exactly the two half-angle phases of the standard
axial spinorial action about one fixed axis. -/
theorem comparison_sector_factors (θ : ℝ) :
    toMat (cPlusRef θ)
      = ((Real.cos (θ / 2) : ℂ) - (Real.sin (θ / 2) : ℂ) * Complex.I) • (1 : Matrix (Fin 2) (Fin 2) ℂ) ∧
    toMat (cMinusRef θ)
      = ((Real.cos (θ / 2) : ℂ) + (Real.sin (θ / 2) : ℂ) * Complex.I) • (1 : Matrix (Fin 2) (Fin 2) ℂ) := by
  constructor
  · have h : cPlusRef θ = zc (Real.cos (θ / 2)) (-Real.sin (θ / 2)) := by
      rw [cPlusRef, zz, zc]
    rw [h, comparison_toMat_zc]
    congr 1
    push_cast
    ring
  · have h : cMinusRef θ = zc (Real.cos (θ / 2)) (Real.sin (θ / 2)) := by
      rw [cMinusRef, zz, zc]
    rw [h, comparison_toMat_zc]

/-- **COMPARISON ONLY.**  The restricted reference action on the two slices of an
arbitrary minimal carrier, read through the comparison isomorphism: multiplication by the
two conjugate half-angle phases. -/
theorem comparison_restricted_action {L : Submodule ℝ W} (_hL : IsMinimalLeftCarrier L)
    (θ : ℝ) :
    (∀ ψ ∈ Kplus L, toMat (Uref θ ⋆ ψ)
      = ((Real.cos (θ / 2) : ℂ) - (Real.sin (θ / 2) : ℂ) * Complex.I) • toMat ψ) ∧
    (∀ ψ ∈ Kminus L, toMat (Uref θ ⋆ ψ)
      = ((Real.cos (θ / 2) : ℂ) + (Real.sin (θ / 2) : ℂ) * Complex.I) • toMat ψ) := by
  obtain ⟨hP, hM⟩ := comparison_sector_factors θ
  constructor
  · intro ψ hψ
    rw [reference_action_plus_exact hψ.2, toMat_mul, hP, smul_mul_assoc, one_mul]
  · intro ψ hψ
    rw [reference_action_minus_exact hψ.2, toMat_mul, hM, smul_mul_assoc, one_mul]

/-! ## COMPARISON ONLY — 2. the reconstructed carriers are matrix left ideals -/

/-- **COMPARISON ONLY.**  The reconstructed minimal carriers are exactly the minimal left
ideals of the comparison matrix algebra, and the reconstructed global parametrization is
the conventional two-sphere of rank-one projections. -/
theorem comparison_minimal_carrier {L : Submodule ℝ W} (hL : IsMinimalLeftCarrier L) :
    Module.finrank ℝ L = 4 ∧
    ∃ n₁ n₂ n₃ : ℝ, n₁ ^ 2 + n₂ ^ 2 + n₃ ^ 2 = 1 ∧
      (∀ y : W, y ∈ L ↔ ∃ X : Matrix (Fin 2) (Fin 2) ℂ,
        X * toMat (esph n₁ n₂ n₃) = toMat y) := by
  obtain ⟨n₁, n₂, n₃, hn, rfl⟩ := minimal_eq_Lgen_esph hL
  exact ⟨finrank_of_isMinimal hL, n₁, n₂, n₃, hn, comparison_Lgen_eq_left_ideal _⟩

/-! ## COMPARISON ONLY — 3. the permitted conclusion -/

/-- **COMPARISON ONLY, NOT PHYSICAL SPIN (§52, §53).**  The exact correspondence: on every
minimal carrier the independently reconstructed one-parameter axial action decomposes into
the two axis eigen-slices, on which it acts by the mutually conjugate half-angle complex
phases of the comparison algebra; the carrier itself is a minimal left ideal of that
algebra.  This is an *algebraic* equivalence with the standard axial spinorial action
about one fixed axis, and nothing more: no physical spin, no particle, no state space and
no dynamics is claimed or derived. -/
theorem comparison_summary {L : Submodule ℝ W} (hL : IsMinimalLeftCarrier L) (θ : ℝ) :
    Module.finrank ℝ L = 4 ∧
    Module.finrank ℝ (Kplus L) = 2 ∧ Module.finrank ℝ (Kminus L) = 2 ∧
    (∀ ψ ∈ Kplus L, toMat (Uref θ ⋆ ψ)
      = ((Real.cos (θ / 2) : ℂ) - (Real.sin (θ / 2) : ℂ) * Complex.I) • toMat ψ) ∧
    (∀ ψ ∈ Kminus L, toMat (Uref θ ⋆ ψ)
      = ((Real.cos (θ / 2) : ℂ) + (Real.sin (θ / 2) : ℂ) * Complex.I) • toMat ψ) :=
  ⟨finrank_of_isMinimal hL, finrank_Kplus hL, finrank_Kminus hL,
    (comparison_restricted_action hL θ).1, (comparison_restricted_action hL θ).2⟩

end NullSectorTask13
