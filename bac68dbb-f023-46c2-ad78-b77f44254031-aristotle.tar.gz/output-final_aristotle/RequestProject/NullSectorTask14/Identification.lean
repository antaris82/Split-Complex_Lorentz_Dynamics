import RequestProject.NullSectorTask14.SelectionAudit

/-!
# Task 14, Layer 21 (§75–§76): late conventional comparison — **COMPARISON ONLY**

Everything in this module is *comparison*, performed only after the intrinsic
reconstruction, classification and defect theorems are complete.  Nothing here is used
anywhere in the reconstruction modules, and nothing here is a definition on which an
earlier result depends.

The comparison records:

1. the exact multiplication relations of the minimal product-closed implementer algebra
   derived in §26 — a four-dimensional real associative algebra with three
   square-minus-one generators pairwise anticommuting, which is the conventional
   unit-quaternion algebra (in the left-handed sign convention `PQ = -R`);
2. the derived infinitesimal bracket relations, which are those of the conventional
   three-dimensional rotation Lie algebra;
3. the derived internal residual of the full-parameter closed path, `-1`, and the
   double-parameter return `U(4π) = 1`, which is the conventional double-cover behaviour;
4. exactly which parts do **not** correspond: no inner product, no unitarity, no
   projective identification, and a residual central freedom strictly larger than `±1`
   once arbitrary lifts are admitted.

**NOT PHYSICAL SPIN.**  No particle, observable, measurement or probability is derived.
-/

namespace NullSectorTask14

open NullSectorTask01 NullSectorTask04 NullSectorTask06 NullSectorTask07 NullSectorTask08
open NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12 NullSectorTask13

/-! ## COMPARISON ONLY — 1. the implementer algebra -/

/-- **COMPARISON ONLY.**  The exact relations of the three derived noncentral generators of
the minimal product-closed implementer algebra.  These are the conventional
unit-quaternion relations in the sign convention `PQ = -R`. -/
theorem comparison_implementer_relations :
    wP ⋆ wP = -w1 ∧ wQ ⋆ wQ = -w1 ∧ wR ⋆ wR = -w1 ∧
      wP ⋆ wQ = -wR ∧ wQ ⋆ wP = wR ∧
      wQ ⋆ wR = -wP ∧ wR ⋆ wQ = wP ∧
      wR ⋆ wP = -wQ ∧ wP ⋆ wR = wQ := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩ <;>
    (funext i; fin_cases i <;> simp [w1, wP, wQ, wR, wit8MulFun])

/-- **COMPARISON ONLY.**  The derived implementer algebra is four-dimensional, closed under
the product, has one-dimensional centre inside itself, and contains every reference axis
implementation. -/
theorem comparison_implementer_algebra :
    Module.finrank ℝ (ImplAlg : Submodule ℝ W) = 4 ∧
      IsProductClosed ImplAlg ∧
      (∀ (n : Vec3) (θ : ℝ), Un n θ ∈ ImplAlg) :=
  ⟨finrank_ImplAlg, ImplAlg_productClosed, fun n θ => Un_mem_ImplAlg n θ⟩

/-! ## COMPARISON ONLY — 2. the infinitesimal bracket -/

/-- **COMPARISON ONLY.**  The derived infinitesimal generators close under the commutator
with the cyclic relations of the conventional three-dimensional rotation Lie algebra. -/
theorem comparison_bracket_relations :
    GA ⋆ GB - GB ⋆ GA = GC ∧ GB ⋆ GC - GC ⋆ GB = GA ∧ GC ⋆ GA - GA ⋆ GC = GB :=
  ⟨infinitesimal_closure.1, infinitesimal_closure.2.1, infinitesimal_closure.2.2⟩

/-! ## COMPARISON ONLY — 3. the double-parameter behaviour -/

/-- **COMPARISON ONLY.**  The full-parameter reference implementation is `-1` and the
double-parameter one is `1`, while both induce the identity algebra automorphism: this is
the conventional double-cover behaviour, here obtained purely from finite compositions
inside the reconstructed algebra. -/
theorem comparison_double_cover (n : Vec3) :
    Un n (2 * Real.pi) = -w1 ∧ Un n (4 * Real.pi) = w1 ∧
      PhiGen n (2 * Real.pi) = LinearMap.id := by
  refine ⟨full_turn_val, ?_, full_turn_aut n⟩
  rw [Un, show 4 * Real.pi / 2 = 2 * Real.pi by ring, Real.cos_two_pi, Real.sin_two_pi]
  module

/-- **COMPARISON ONLY.**  The closed mixed path of two orthogonal half-parameter
transformations returns to the identity automorphism with internal residual `-1`. -/
theorem comparison_closed_path :
    wordAut closedPath = LinearMap.id ∧ wordVal closedPath = -w1 :=
  closed_path_internal_residual

/-! ## COMPARISON ONLY — 4. what does *not* correspond -/

/-- **COMPARISON ONLY, negative part.**  Two features of the intrinsic result are *not*
captured by the conventional picture as usually presented:

* the residual central freedom of arbitrary (non-reference) implementations is the whole
  group of invertible central elements, not merely `±1`;
* nothing here identifies implementations differing by a central factor, so the central
  defect remains an explicit part of the object. -/
theorem comparison_residual_larger_than_sign {n : Vec3} (hn : IsUnitAxis n) (θ : ℝ) :
    (∀ a b : ℝ, a ^ 2 + b ^ 2 ≠ 0 →
        ∃ u v ui vi : W, Implements u ui (PhiGen n θ) ∧ Implements v vi (PhiGen n θ) ∧
          u ⋆ vi = zz a b) ∧
      (∃ u v ui vi : W, Implements u ui (PhiGen n θ) ∧ Implements v vi (PhiGen n θ) ∧
        u ⋆ vi ≠ w1 ∧ u ⋆ vi ≠ -w1) :=
  ⟨(full_lift_defect_exact hn θ).2, full_lift_defect_not_pm_one hn θ⟩

/-- **COMPARISON ONLY, permitted conclusion (§76).**  The independently reconstructed
minimal-carrier action closes algebraically across spatial axes, and in this late
comparison it is equivalent to the standard full spatial spinorial rotation structure:
the implementer algebra is the conventional four-dimensional one, the generators satisfy
the conventional bracket relations, and finite reference words carry the conventional
two-valued central defect.

**NOT PHYSICAL SPIN.**  No fermion, observable, measurement outcome or angular momentum is
derived; those require additional structure which Task 14 does not introduce. -/
theorem comparison_summary :
    (wP ⋆ wP = -w1 ∧ wQ ⋆ wQ = -w1 ∧ wR ⋆ wR = -w1) ∧
      Module.finrank ℝ (ImplAlg : Submodule ℝ W) = 4 ∧
      (GA ⋆ GB - GB ⋆ GA = GC) ∧
      (∀ n : Vec3, Un n (2 * Real.pi) = -w1) ∧
      wordVal closedPath = -w1 :=
  ⟨⟨comparison_implementer_relations.1, comparison_implementer_relations.2.1,
      comparison_implementer_relations.2.2.1⟩,
    finrank_ImplAlg, comparison_bracket_relations.1,
    fun _ => full_turn_val, closed_path_internal_residual.2⟩

end NullSectorTask14
