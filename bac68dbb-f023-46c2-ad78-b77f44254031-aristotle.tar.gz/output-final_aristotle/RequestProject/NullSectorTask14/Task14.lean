import RequestProject.NullSectorTask14.Identification

/-!
# Task 14 — top module: principal theorem set and axiom report

This module imports the complete Task-14 development and exposes the principal results
under the names requested in §70 of the task.  Each exposed name is an alias of the
theorem proved in the corresponding layer; no new mathematics happens here.

Layer order (source-order firewall of §68):

```
Task14.SafeBase
  → SecondAxisOldStructure → SecondAxisAutomorphism → SecondAxisImplementation
  → SecondAxisCarrierSlices → SecondAxisSectorAction
  → TwoAxisSliceComparison → MixedProjectors
  → MixedFiniteComposition → MixedInfinitesimalComposition → ImplementerClosure
  → AxisGeneratorMap → GenericAxis → GenericTwoAxisComposition
  → ReferenceWordDefect → FullLiftDefect → CoherenceAudit
  → CarrierIntertwiners → CarrierFamilyAction → CommonFixedLocus → SelectionAudit
  → Identification (COMPARISON ONLY)
```

The `#print axioms` block at the end is the §78 axiom report.
-/

namespace NullSectorTask14

/-! ## §8–§9 — independent second-axis old-space reconstruction -/

alias task14_second_axis_decomposition := second_axis_decomposition
alias task14_second_axis_transverse_dimension := finrank_TransB
alias task14_second_axis_longitudinal_dimension := finrank_LongB

/-! ## §10–§11 — independent second-axis transformation and algebra extension -/

alias task14_second_axis_old_family := rotB_isSecondAxisOldFamily
alias task14_second_axis_orientation_branches := second_axis_orientation_branches
alias task14_second_axis_automorphism_exists := second_axis_extension_exists_unique
alias task14_second_axis_automorphism_unique := secondAxisExtension_unique
alias task14_second_axis_basis_table := second_axis_basis_table

/-! ## §12–§14 — independent second-axis internal implementation -/

alias task14_second_axis_forced_plane := second_axis_forced_plane
alias task14_second_axis_half_angle_forced := second_axis_half_angle_forced
alias task14_second_axis_reference_implementation := UBref_isBLift
alias task14_second_axis_lift_relative_central := bLift_relative_central

/-! ## §15–§18 — second-axis carrier slices and sector action -/

alias task14_second_axis_sector_split := second_axis_carrier_split
alias task14_second_axis_slice_dimensions := second_axis_slice_dimensions
alias task14_second_axis_slices_central_lines := second_axis_slices_central_lines
alias task14_second_axis_sector_action_plus := second_axis_action_plus_exact
alias task14_second_axis_sector_action_minus := second_axis_action_minus_exact
alias task14_second_axis_relative_action_exact := second_axis_relative_action_exact
alias task14_second_axis_relative_action_independent :=
  second_axis_relative_action_independent
alias task14_second_axis_matches_first_axis := second_axis_matches_first_axis

/-! ## §19–§23 — two-axis comparison and mixed projector algebra -/

alias task14_two_axis_slice_intersections := two_axis_slice_intersections
alias task14_two_axis_decompositions_transverse := two_axis_decompositions_transverse
alias task14_mixed_projector_classification := mixed_projector_data
alias task14_mixed_composition_nonzero := mixed_composition_nonzero

/-! ## §24–§25 — mixed finite compositions -/

alias task14_mixed_automorphisms_order_dependence := mixed_automorphisms_commute_iff
alias task14_mixed_reference_products_exact := mixed_reference_product_difference

/-! ## §26–§29 — implementer algebra, infinitesimal closure, third axis -/

alias task14_minimal_implementer_subalgebra := ImplAlg_productClosed
alias task14_minimal_implementer_dimension := finrank_ImplAlg
alias task14_minimal_implementer_minimality := ImplAlg_minimal
alias task14_minimal_implementer_center := ImplAlg_center
alias task14_minimal_implementer_table := qelt_mul
alias task14_mixed_infinitesimal_commutator := mixed_commutator
alias task14_infinitesimal_closure := infinitesimal_closure
alias task14_third_axis_relation := third_axis_relation
alias task14_generator_sign_classification := generator_sign_classification

/-! ## §31–§34 — the intrinsic axis-generator map -/

alias task14_axis_generator_map_exists := Jmap_basis_cases
alias task14_axis_generator_map_linearity := Jmap_linear
alias task14_axis_generator_square := Jmap_sq
alias task14_axis_generator_symmetric_product := Jmap_symmetric_product
alias task14_axis_generator_antisymmetric_product := Jmap_antisymmetric_product
alias task14_axis_generator_late_identification := Jmap_eq_central_mul

/-! ## §35–§43 — arbitrary unit axes -/

alias task14_generic_axis_group_law := Un_group
alias task14_generic_axis_carrier_split := generic_carrier_split
alias task14_generic_axis_slices_central_lines := generic_slices_central_lines
alias task14_generic_axis_reference_action := generic_action_exact
alias task14_generic_axis_relative_action := generic_relative_action_universal
alias task14_generic_mixed_intersection := generic_mixed_intersection_zero
alias task14_generic_reference_product_shape := generic_reference_product_shape
alias task14_generic_reference_composition_closes := generic_reference_composition_closes

/-! ## §44–§48 — word defects and residual freedom -/

alias task14_word_implements := word_implements
alias task14_reference_word_relative_central := implements_defect_mem_Z
alias task14_reference_word_defect_classification := reference_word_defect_set_exact
alias task14_full_lift_word_relative_central := full_lift_defect_exact
alias task14_full_lift_defect_not_pm_one := full_lift_defect_not_pm_one
alias task14_multi_axis_residual_freedom_verdict := multi_axis_residual_freedom_verdict

/-! ## §49–§54 — coherence, closed paths, path dependence, three closures -/

alias task14_coherent_lift_obstructed := coherent_lift_obstructed
alias task14_closed_path_internal_residual := closed_path_internal_residual
alias task14_path_dependence_explicit := path_dependence_explicit
alias task14_three_closure_notions := three_closure_notions

/-! ## §55–§60 — carriers, carrier family, fixed locus, selection -/

alias task14_multi_axis_carrier_intertwining := word_action_intertwined
alias task14_multi_axis_carrier_type := multi_axis_carrier_type
alias task14_generic_carrier_family_action := generic_carrier_family_action
alias task14_second_axis_carrier_family_action := secondAxis_carrier_family_action
alias task14_mixed_carrier_family_action := mixed_carrier_family_action
alias task14_generic_fixed_carrier_iff := generic_fixed_carrier_iff
alias task14_common_fixed_locus := no_common_fixed_carrier
alias task14_one_axis_fixed_locus_moved := one_axis_fixed_locus_moved
alias task14_two_axis_selection_verdict := two_axis_selection_verdict

/-! ## §30, §65–§67 — rate, isotropy and orientation audits -/

alias task14_rate_freedom_axis_local := rate_freedom_axis_local
alias task14_isotropy_forces_common_rate := isotropy_forces_common_rate
alias task14_orientation_global_sign := orientation_global_sign
alias task14_rate_orientation_audit := rate_orientation_audit

/-! ## §75–§76 — late conventional comparison, COMPARISON ONLY -/

alias task14_comparison_summary := comparison_summary
alias task14_comparison_double_cover := comparison_double_cover
alias task14_comparison_residual_larger_than_sign := comparison_residual_larger_than_sign

/-! ## §78 — axiom report -/

#print axioms task14_second_axis_decomposition
#print axioms task14_second_axis_automorphism_exists
#print axioms task14_second_axis_reference_implementation
#print axioms task14_second_axis_sector_split
#print axioms task14_second_axis_relative_action_exact
#print axioms task14_two_axis_slice_intersections
#print axioms task14_mixed_projector_classification
#print axioms task14_mixed_automorphisms_order_dependence
#print axioms task14_mixed_reference_products_exact
#print axioms task14_mixed_infinitesimal_commutator
#print axioms task14_infinitesimal_closure
#print axioms task14_third_axis_relation
#print axioms task14_minimal_implementer_subalgebra
#print axioms task14_minimal_implementer_dimension
#print axioms task14_minimal_implementer_minimality
#print axioms task14_axis_generator_map_linearity
#print axioms task14_axis_generator_square
#print axioms task14_generic_axis_carrier_split
#print axioms task14_generic_axis_relative_action
#print axioms task14_generic_reference_composition_closes
#print axioms task14_reference_word_relative_central
#print axioms task14_reference_word_defect_classification
#print axioms task14_full_lift_word_relative_central
#print axioms task14_multi_axis_residual_freedom_verdict
#print axioms task14_coherent_lift_obstructed
#print axioms task14_closed_path_internal_residual
#print axioms task14_path_dependence_explicit
#print axioms task14_multi_axis_carrier_type
#print axioms task14_generic_carrier_family_action
#print axioms task14_common_fixed_locus
#print axioms task14_two_axis_selection_verdict
#print axioms task14_isotropy_forces_common_rate
#print axioms task14_comparison_summary

end NullSectorTask14
