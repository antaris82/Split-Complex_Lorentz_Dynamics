import RequestProject.NullSectorTask11.Identification

/-!
# Task 11 — principal theorems and axiom report

This module imports the complete Task-11 development and exposes the principal
final theorems, one for each of the seventeen Conservation-of-Difficulty
questions of §34, followed by the late comparison statements (§40) and the
`#print axioms` report demanded by §39.

Layer order actually realized in the source (§35):

```
SafeBase → CenterRigidity → FullLift → RelativeLiftRigidity →
ReferenceExistence → ExactLiftClassification → ContinuousClassification →
PeriodicityAudit → QuadraticCompatibility → InfinitesimalLift →
GeneratorSeparation → Identification
```

The explicit reference lift first enters in `ReferenceExistence`, strictly after
the exact center theorem and the complete relative-lift rigidity theorem.
-/

namespace NullSectorTask11

open NullSectorTask08 NullSectorTask09 NullSectorTask10

/-! ## 1. Is the known central two-plane the full center? -/

/-- **1.  YES — the exact center (§9).**  The independently derived central
two-plane `Z = spanℝ{1, S}` is the *entire* center of the reconstructed
carrier. -/
theorem task11_center : CenterW = (Z : Set W) := center_eq_Z

/-! ## 2. What is the centralizer of the generating triple? -/

/-- **2.  The centralizer of `{A,B,C}` is already the full center; two
generators suffice; one does not (negative control, §10).** -/
theorem task11_centralizer :
    CentralizerOf {wA, wB, wC} = CenterW ∧
      CentralizerOf {wA, wB} = (Z : Set W) ∧
      CentralizerOf {wA} ≠ CenterW :=
  ⟨centralizer_triple_eq_center, centralizer_pair_eq_Z, centralizer_single_ne_center⟩

/-! ## 3. How can two full internal lifts of the same action differ? -/

/-- **3.  Exactly by a central multiplicative factor (§11–§14).**  The relative
element of two arbitrary full-carrier lifts lies in the exact center, is
multiplicative, and reconstructs one lift from the other.  Nothing is assumed
about it beforehand, and no reference formula is used. -/
theorem task11_relative_lift {U V : ℝ → W} (hU : IsFullLift U) (hV : IsFullLift V) :
    IsCentralHom (rel U V) ∧ (∀ θ, U θ = rel U V θ ⋆ V θ) ∧
      (∀ θ, rel U V θ ∈ CenterW) :=
  ⟨rel_isCentralHom hU hV,
    fun θ => by rw [rel, mul_assoc_W, hV.neg_mul, mul_one_W],
    rel_mem_center hU hV⟩

/-- **3'.  UPPER CLASSIFICATION (§14), before any explicit witness.** -/
theorem task11_relative_classification {V : ℝ → W} (hV : IsFullLift V) (U : ℝ → W) :
    IsFullLift U ↔ ∃ z : ℝ → W, IsCentralHom z ∧ ∀ θ, U θ = z θ ⋆ V θ :=
  fullLift_relative_classification hV U

/-! ## 4. Was the Task-10 real factor the complete freedom? -/

/-- **4.  NO — it was only the `K`-slice (§16).**  A full lift lies in the
Task-10 two-plane `K` exactly when its residual `S`-coefficient vanishes
identically, and full lifts leaving `K` exist. -/
theorem task11_K_slice :
    (∀ (U : ℝ → W) (f g : ℝ → ℝ), (∀ θ, U θ = zc (f θ) (g θ) ⋆ Uref θ) →
        (∀ θ, U θ ∈ K) → ∀ θ, g θ = 0) ∧
      (∃ U : ℝ → W, IsContinuousFullLift U ∧ ¬ (∀ θ, U θ ∈ K)) :=
  ⟨fun _ _ _ hU hK θ => residual_S_coeff_eq_zero_of_mem_K hU hK θ,
    exists_fullLift_not_mem_K⟩

/-! ## 5. The complete algebraic residual freedom -/

/-- **5.  EXACT ALGEBRAIC LIFT CLASSIFICATION (§15).**  Every full-carrier lift
is a central multiplicative map times the reference lift, and conversely. -/
theorem task11_algebraic_classification (U : ℝ → W) :
    IsFullLift U ↔ ∃ z : ℝ → W, IsCentralHom z ∧ ∀ θ, U θ = z θ ⋆ Uref θ :=
  fullLift_classification U

/-! ## 6–7. The complete continuous residual freedom and its parameter count -/

/-- **6.  EXACT CONTINUOUS LIFT CLASSIFICATION (§18).** -/
theorem task11_continuous_classification (U : ℝ → W) :
    IsContinuousFullLift U ↔ ∃ α β : ℝ, ∀ θ, U θ = zexp α β θ ⋆ Uref θ :=
  continuousFullLift_classification U

/-- **7.  EXACTLY TWO REAL CONTINUOUS PARAMETERS.**  The parameters of the
continuous family are unique, so the continuous residual freedom has exactly two
real degrees of freedom — and it is strictly smaller than the algebraic freedom,
which also contains discontinuous residual maps (§20). -/
theorem task11_parameter_count :
    (∀ {α β α' β' : ℝ}, (∀ θ, zexp α β θ ⋆ Uref θ = zexp α' β' θ ⋆ Uref θ) →
        α = α' ∧ β = β') ∧
      (∃ z : ℝ → W, IsCentralHom z ∧ ¬ ∃ α β : ℝ, ∀ θ, z θ = zexp α β θ) :=
  ⟨fun h => continuousFullLift_parameters_unique h, exists_centralHom_not_continuous⟩

/-! ## 8–9. General `2π` and `4π` behaviour -/

/-- **8.  THE EXACT GENERAL `2π` AND `4π` VALUES (§21).** -/
theorem task11_periodicity {U : ℝ → W} {α β : ℝ} (hU : ∀ θ, U θ = zexp α β θ ⋆ Uref θ) :
    U (2 * Real.pi)
        = zc (-(Real.exp (α * (2 * Real.pi)) * Real.cos (β * (2 * Real.pi))))
            (-(Real.exp (α * (2 * Real.pi)) * Real.sin (β * (2 * Real.pi)))) ∧
      U (4 * Real.pi)
        = zc (Real.exp (α * (4 * Real.pi)) * Real.cos (β * (4 * Real.pi)))
            (Real.exp (α * (4 * Real.pi)) * Real.sin (β * (4 * Real.pi))) :=
  ⟨continuousFullLift_two_pi hU, continuousFullLift_four_pi hU⟩

/-- **9.  THE SHARP VALUES BELONG TO THE REFERENCE LIFT ONLY.**  The values
`-1` and `1` are the special case `α = β = 0`; other continuous full lifts take
other values at `2π`.  Algebra periodicity does not determine implementer
periodicity (§22). -/
theorem task11_reference_periodicity :
    (Uref (2 * Real.pi) = -w1 ∧ Uref (4 * Real.pi) = w1) ∧
      (∃ U V : ℝ → W, IsContinuousFullLift U ∧ IsContinuousFullLift V ∧
        U (2 * Real.pi) ≠ V (2 * Real.pi)) ∧
      (Phi (2 * Real.pi) = LinearMap.id ∧ Uref (2 * Real.pi) ≠ w1) :=
  ⟨reference_two_pi_four_pi, two_pi_value_depends_on_parameters,
    algebra_periodicity_does_not_fix_lift⟩

/-! ## 10–12. Conditional quadratic compatibility -/

/-- **10.  `N₊` CONDITIONAL COMPATIBILITY (§24).**  *This is a conditional
structural test, not an inherited requirement.*  Among the continuous full lifts
it removes both continuous parameters and leaves exactly the reference lift. -/
theorem task11_Nplus_compatibility {U : ℝ → W} (hU : IsContinuousFullLift U) :
    PreservesLeftQuadratic Nplus U ↔ U = Uref :=
  Nplus_compatibility_classification hU

/-- **11.  `N₋` CONDITIONAL COMPATIBILITY (§25).**  Proved through the
branch-parameterized criterion, whose only branch input is the proved relation
`ζ * ζ = 1`; the two conditional classes coincide. -/
theorem task11_Nminus_compatibility {U : ℝ → W} (hU : IsContinuousFullLift U) :
    (PreservesLeftQuadratic Nminus U ↔ U = Uref) ∧
      (PreservesLeftQuadratic Nplus U ↔ PreservesLeftQuadratic Nminus U) :=
  ⟨Nminus_compatibility_classification hU, Nplus_Nminus_compatibility_equiv U⟩

/-- **12.  SIMULTANEOUS COMPATIBILITY IS NOT STRONGER (§26).** -/
theorem task11_simultaneous_compatibility {U : ℝ → W} (hU : IsContinuousFullLift U) :
    (PreservesLeftQuadratic Nplus U ∧ PreservesLeftQuadratic Nminus U) ↔ U = Uref :=
  simultaneous_compatibility_classification hU

/-! ## 13. Does a normalization emerge as a theorem? -/

/-- **13.  NORMALIZATION DERIVED CONDITIONALLY (§27).**  No unit-norm condition
was assumed anywhere in the classification layers.  Under the *explicit*
conditional test of §23 a unit-like relation is derived. -/
theorem task11_normalization {U : ℝ → W} {α β : ℝ} (hU : ∀ θ, U θ = zexp α β θ ⋆ Uref θ)
    (hcont : IsContinuousFullLift U) (hpres : PreservesLeftQuadratic Nplus U) :
    (∀ θ, nRe (U θ) = 1 ∧ nSc (U θ) = 0) ∧
      (∀ θ, (Real.exp (α * θ) * Real.cos (β * θ)) ^ 2
        + (Real.exp (α * θ) * Real.sin (β * θ)) ^ 2 = 1) :=
  normalization_derived hU hcont hpres

/-! ## 14. The exact infinitesimal generator of an arbitrary differentiable lift -/

/-- **14.  EXACT GENERATOR (§28).**  Continuity and differentiability coincide
for full lifts, and the left generator of a differentiable full lift is exactly
an arbitrary central element plus the fixed term `-(1/2)·R`; every such value
occurs. -/
theorem task11_infinitesimal_generator :
    (∀ U : ℝ → W, IsContinuousFullLift U ↔ IsDifferentiableFullLift U) ∧
      (∀ {U : ℝ → W}, IsDifferentiableFullLift U →
        ∃ α β : ℝ, (∀ θ, U θ = zexp α β θ ⋆ Uref θ) ∧
          leftGen U = zc α β - (2⁻¹ : ℝ) • wR) ∧
      (∀ G : W, (∃ U : ℝ → W, IsDifferentiableFullLift U ∧ leftGen U = G) ↔
        G + (2⁻¹ : ℝ) • wR ∈ Z) :=
  ⟨continuousFullLift_iff_differentiableFullLift,
    fun hU => differentiableFullLift_generator hU, generator_classification⟩

/-! ## 15–17. Visible, invisible, and rate freedom -/

/-- **15–16.  GENERATOR SEPARATION (§29, §30).**  The commutator of the left
generator is exactly the inherited infinitesimal algebra generator (visible
part); two generators induce the same derivation exactly when they differ by an
element of the exact center (invisible part); left multiplication by the
generator is itself *not* a derivation. -/
theorem task11_generator_separation {U : ℝ → W} (hU : IsDifferentiableFullLift U) :
    inducedDer (leftGen U) = Dgen ∧
      (∀ G G' : W, inducedDer G = inducedDer G' ↔ G - G' ∈ CenterW) ∧
      ¬ (∀ x y : W, leftGen U ⋆ (x ⋆ y)
          = (leftGen U ⋆ x) ⋆ y + x ⋆ (leftGen U ⋆ y)) :=
  ⟨(differentiableFullLift_inducedDer hU).1, inducedDer_eq_iff_sub_mem_center,
    leftMul_generator_not_derivation hU⟩

/-- **17.  THIS IS NOT THE TASK-10 RATE FREEDOM (§31).**  Task 10 left the whole
real line `λ • Dgen` of admissible axial derivations; an internal lift of the
*fixed* automorphism family always induces `λ = 1`.  The residual lift freedom is
invisible to the algebra action, whereas the rate freedom is precisely visible in
it: the two freedoms are logically independent. -/
theorem task11_rate_vs_lift_freedom {U V : ℝ → W}
    (hU : IsDifferentiableFullLift U) (hV : IsDifferentiableFullLift V) :
    (∀ l : ℝ, (∀ x : W, inducedDer (leftGen U) x = l • Dgen x) ↔ l = 1) ∧
      inducedDer (leftGen U) = inducedDer (leftGen V) ∧
      leftGen U - leftGen V ∈ CenterW :=
  ⟨fun l => rate_freedom_collapses hU l, (residual_freedom_invisible hU hV).1,
    (residual_freedom_invisible hU hV).2⟩

/-! ## Late conventional comparison (§40) — **COMPARISON ONLY** -/

/-- **COMPARISON ONLY.**  The intrinsic center, the intrinsic continuous residual
family, the quotient of two implementers and the invisible infinitesimal
component, re-read through the Task-08 comparison isomorphism.  No conventional
theorem supports any earlier result, and no physical conclusion is drawn (§41). -/
theorem task11_identification :
    (∀ z : W, z ∈ CenterW ↔ ∃ c : ℂ, toMat z = c • (1 : Matrix (Fin 2) (Fin 2) ℂ)) ∧
      (∀ α β θ : ℝ, toMat (zexp α β θ)
        = Complex.exp (((α : ℂ) + (β : ℂ) * Complex.I) * (θ : ℂ))
          • (1 : Matrix (Fin 2) (Fin 2) ℂ)) ∧
      (∀ θ : ℝ, (toMat (Uref θ)).det = 1) ∧
      (∀ G G' : W, inducedDer G = inducedDer G' ↔
        ∃ c : ℂ, toMat (G - G') = c • (1 : Matrix (Fin 2) (Fin 2) ℂ)) :=
  ⟨comparison_center_eq_scalars, comparison_residual_freedom, comparison_det_Uref,
    comparison_invisible_component⟩

/-! ## Axiom report (§39) -/

#print axioms task11_center
#print axioms task11_centralizer
#print axioms task11_relative_lift
#print axioms task11_relative_classification
#print axioms task11_K_slice
#print axioms task11_algebraic_classification
#print axioms task11_continuous_classification
#print axioms task11_parameter_count
#print axioms task11_periodicity
#print axioms task11_reference_periodicity
#print axioms task11_Nplus_compatibility
#print axioms task11_Nminus_compatibility
#print axioms task11_simultaneous_compatibility
#print axioms task11_normalization
#print axioms task11_infinitesimal_generator
#print axioms task11_generator_separation
#print axioms task11_rate_vs_lift_freedom
#print axioms task11_identification

end NullSectorTask11
