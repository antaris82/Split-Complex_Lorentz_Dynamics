import RequestProject.NullSectorTask06.Task04Comparison
import RequestProject.NullSectorTask06.UniversalObstructionSummary

/-!
# Task 06: principal theorems and axiom report

This module imports the complete Task-06 development and states its principal
results under stable names.  It is the last module compiled and nothing depends
on it.

* Phase A (clean-room gluing classification) — `task06_generic_extension` …
  `task06_task04_replication`.
* Phase B (universal obstruction probe) — `task06_minimal_configuration` …
  `task06_joint_obstruction`.  The Phase-B theorems depend only on
  `Task06.SafeBase` and `Task06.GenericExtension`; they are stated here purely
  for convenience.

The axiom report is produced by the `#print axioms` commands at the end.
-/

namespace NullSectorTask06

open NullSectorTask01 NullSectorTask04

/-! ## Phase A -/

/-- **RE-DERIVED.**  The clean generic extension theorem, with uniqueness of the
defect and the identification of the symmetric and alternating parts. -/
theorem task06_generic_extension :
    (∀ M : BiProd4, SectorCompatible M ↔
      ∃ A : RestDefect, Alternating A ∧ M = extensionFromDefect A) ∧
    (∀ A B : RestDefect, extensionFromDefect A = extensionFromDefect B → A = B) ∧
    (∀ M : BiProd4, SectorCompatible M → ∀ X Y : Vec4,
      SymPart M X Y = symForced X Y ∧ AltPart M X Y = defectOfProd M X.2 Y.2) :=
  ⟨sectorCompatible_iff_defect, fun _ _ h => defect_unique h,
   fun _ hM X Y => ⟨symPart_eq hM X Y, altPart_eq hM X Y⟩⟩

/-- **DERIVED.**  The proper isotropy is defined intrinsically from the Lorentz
stabilizer of `e₀`, and preservation of `L4`, of the time (future) component, of
the rest space and of the induced positive form are consequences. -/
theorem task06_proper_isotropy :
    (∀ R : Vec4 ≃ₗ[ℝ] Vec4, Stab R → (∀ X Y, L4 (R X) (R Y) = L4 X Y) ∧
      (∀ X, (R X).1 = X.1) ∧ (∀ X ∈ Rest, R X ∈ Rest) ∧
      (∀ X Y, h (R X) (R Y) = h X Y)) ∧
    (∀ R : Vec4 ≃ₗ[ℝ] Vec4, ProperStab R ↔ (Stab R ∧ detRest R = 1)) ∧
    ProperStab (liftRest hz) ∧ ¬ ProperStab (liftRest refz) :=
  ⟨fun _ hR => ⟨stab_L4 hR, stab_time hR, fun _ hX => stab_rest hR hX, stab_h hR⟩,
   fun _ => Iff.rfl, properStab_hz, not_properStab_refz⟩

/-- **RIGIDITY RESULT.**  For an arbitrary (unknown) alternating defect, proper
equivariance forces: the temporal output component vanishes identically, and the
three basis-pair values are governed by a single real number. -/
theorem task06_rigidity {A : RestDefect} (hA : Alternating A) (hE : ProperEquivariant A) :
    (∀ v w : Vec3, tempPart A v w = 0) ∧
      (∃ c : ℝ, A r₂ r₃ = c • sp r₁ ∧ A r₃ r₁ = c • sp r₂ ∧ A r₁ r₂ = c • sp r₃) :=
  ⟨rigidity_temporal_zero hA hE, rigidity_basis_pairs hA hE⟩

/-- **RIGIDITY RESULT (upper bound, proved before any witness).**  Two
alternating proper-equivariant defects with the same parameter coincide, and
parameter zero forces the zero defect. -/
theorem task06_rigidity_upper_bound :
    (∀ A B : RestDefect, Alternating A → ProperEquivariant A → Alternating B →
      ProperEquivariant B → (A r₂ r₃).2.1 = (B r₂ r₃).2.1 → A = B) ∧
    (∀ A : RestDefect, Alternating A → ProperEquivariant A → (A r₂ r₃).2.1 = 0 → A = 0) :=
  ⟨fun _ _ hA hEA hB hEB hc => rigidity_unique hA hEA hB hEB hc,
   fun _ hA hE hc => rigidity_eq_zero_of_param_zero hA hE hc⟩

/-- **EXISTENCE WITNESS (constructed only after the rigidity bound).** -/
theorem task06_existence :
    Alternating witDefect ∧ ProperEquivariant witDefect ∧ witDefect ≠ 0 :=
  ⟨witDefect_alternating, witDefect_properEquivariant, witDefect_ne_zero⟩

/-- **EXACT SOLUTION SPACE.**  The proper-equivariant alternating defects are
exactly the real multiples of the witness; the solution space is the line it
spans, the parameterization is injective, and it is linearly isomorphic to `ℝ`
(hence `FINITE-DIMENSIONAL` of dimension one, with `CONTINUOUS FREEDOM`). -/
theorem task06_exact_classification :
    (∀ A : RestDefect, (Alternating A ∧ ProperEquivariant A) ↔ ∃ c : ℝ, A = c • witDefect) ∧
      ProperSolutions = (ℝ ∙ witDefect) ∧
      Function.Injective (fun c : ℝ => c • witDefect) ∧
      Nonempty (ℝ ≃ₗ[ℝ] ProperSolutions) :=
  ⟨properEquivariant_iff, properSolutions_eq_span, smul_witDefect_injective,
   ⟨properSolutionsEquiv⟩⟩

/-- **DERIVED COORDINATE FORMULA (after the classification).** -/
theorem task06_coordinate_formula {A : RestDefect} (hA : Alternating A)
    (hE : ProperEquivariant A) (v w : Vec3) :
    A v w = ((A r₂ r₃).2.1) • ((0 : ℝ), v.2.1 * w.2.2 - v.2.2 * w.2.1,
      v.2.2 * w.1 - v.1 * w.2.2, v.1 * w.2.1 - v.2.1 * w.1) :=
  properEquivariant_coordinate_formula hA hE v w

/-- **EXACT CLASSIFICATION AT THE LEVEL OF PRODUCTS.** -/
theorem task06_product_classification (M : BiProd4) :
    (SectorCompatible M ∧ ProperEquivariantProd M) ↔ ∃ c : ℝ, M = glueFam c :=
  sectorCompatible_properEquivariant_iff M

/-- **ORIENTATION-REVERSAL THEOREM.**  The orientation-reversing reflection
negates the parameter; its only fixed point is the zero defect. -/
theorem task06_orientation_reversal :
    (∀ c : ℝ, reverseDefect (c • witDefect) = (-c) • witDefect) ∧
      (∀ c : ℝ, reverseDefect (c • witDefect) = c • witDefect ↔ c = 0) ∧
      detRest (liftRest refz) = -1 :=
  ⟨reverseDefect_smul_witDefect, reverseDefect_fixed_iff, detRest_refz⟩

/-- **FULL-ISOTROPY CLASSIFICATION.**  Under the full isotropy group only the
zero defect survives, so the global product is unique. -/
theorem task06_full_isotropy :
    (∀ A : RestDefect, (Alternating A ∧ FullEquivariant A) ↔ A = 0) ∧
      (∀ M : BiProd4, (SectorCompatible M ∧ IsotropyEquivariantProd M) ↔ M = symForced) :=
  ⟨fullEquivariant_iff, sectorCompatible_fullEquivariant_iff⟩

/-- **COMPARISON ONLY.**  Late conventional identification of the reconstructed
alternating operation. -/
theorem task06_identification (v w : Vec3) :
    toFin3 (wit3 v w) = crossProduct (toFin3 v) (toFin3 w) :=
  wit3_eq_crossProduct v w

/-- **REPLICATED.**  Late comparison with Task 04. -/
theorem task06_task04_replication (M : BiProd4) :
    ((SectorCompatible M ∧ ProperEquivariantProd M) ↔ ∃ c : ℝ, M = glueFam c) ∧
      ((SectorCompatible M ∧ NullSectorTask04.ProperIsotropyEquivariant M) ↔
        ∃ c : ℝ, M = NullSectorTask04.muFam c) ∧
      (∀ c : ℝ, glueFam c = NullSectorTask04.muFam c) ∧
      (ProperEquivariantProd M ↔ NullSectorTask04.ProperIsotropyEquivariant M) :=
  task06_replicates_task04 M

/-! ## Phase B -/

/-- The minimal configuration in which both universal obstructions appear. -/
theorem task06_minimal_configuration (M : BiProd4) (hM : SectorCompatible M) :
    M (sp r₁) (sp r₁) = e₀ ∧ M (sp r₂) (sp r₂) = e₀ ∧
      M (sp r₁) (sp r₂) + M (sp r₂) (sp r₁) = 0 ∧
      (∀ Z : Vec4, (M Z Z).1 = Z.1 * Z.1 + dot3 Z.2 Z.2) :=
  minimal_obstruction_configuration M hM

/-- **UNIVERSAL OBSTRUCTION.**  `ASSOCIATIVITY: impossible`, over the entire
generic defect space and with no isotropy assumption. -/
theorem task06_associativity_universal :
    (∀ M : BiProd4, SectorCompatible M → ¬ Associative4 M) ∧
      ¬ ∃ M : BiProd4, SectorCompatible M ∧ Associative4 M :=
  ⟨associativity_universally_impossible, not_exists_associative_sectorCompatible⟩

/-- The exact incompatible equation behind the associativity obstruction. -/
theorem task06_associativity_minimal_equations {M : BiProd4} (hM : SectorCompatible M)
    (hassoc : Associative4 M) :
    (M (sp r₁) (sp r₂)).1 ^ 2 + dot3 (M (sp r₁) (sp r₂)).2 (M (sp r₁) (sp r₂)).2 = -1 :=
  associativity_incompatible_equations hM hassoc

/-- **UNIVERSAL OBSTRUCTION.**  `GLOBAL Q4 MULTIPLICATIVITY: impossible`, over
the entire generic defect space and with no isotropy assumption. -/
theorem task06_norm_universal :
    (∀ M : BiProd4, SectorCompatible M → ¬ Q4Multiplicative M) ∧
      ¬ ∃ M : BiProd4, SectorCompatible M ∧ Q4Multiplicative M :=
  ⟨globalNorm_universally_impossible, not_exists_Q4Multiplicative_sectorCompatible⟩

/-- The exact incompatible equations behind the global-norm obstruction. -/
theorem task06_norm_minimal_equations {M : BiProd4} (hM : SectorCompatible M)
    (hmul : Q4Multiplicative M) :
    (M (sp r₁) (sp r₂)).1 = 0 ∧
      dot3 (M (sp r₁) (sp r₂)).2 (M (sp r₁) (sp r₂)).2 = -1 :=
  norm_incompatible_equations hM hmul

/-- Both obstructions survive the addition of any further hypothesis, in
particular of any isotropy or orientation requirement. -/
theorem task06_obstructions_isotropy_independent (P : BiProd4 → Prop) :
    (∀ M : BiProd4, SectorCompatible M → P M → ¬ Associative4 M) ∧
      (∀ M : BiProd4, SectorCompatible M → P M → ¬ Q4Multiplicative M) :=
  obstructions_independent_of_extra_hypotheses P

/-- **Joint theorem (summary only).** -/
theorem task06_joint_obstruction :
    ¬ ∃ M : BiProd4, SectorCompatible M ∧ Associative4 M ∧ Q4Multiplicative M :=
  no_associative_and_Q4Multiplicative

/-! ## Axiom report -/

#print axioms task06_generic_extension
#print axioms task06_proper_isotropy
#print axioms task06_rigidity
#print axioms task06_rigidity_upper_bound
#print axioms task06_existence
#print axioms task06_exact_classification
#print axioms task06_coordinate_formula
#print axioms task06_product_classification
#print axioms task06_orientation_reversal
#print axioms task06_full_isotropy
#print axioms task06_identification
#print axioms task06_task04_replication
#print axioms task06_minimal_configuration
#print axioms task06_associativity_universal
#print axioms task06_associativity_minimal_equations
#print axioms task06_norm_universal
#print axioms task06_norm_minimal_equations
#print axioms task06_obstructions_isotropy_independent
#print axioms task06_joint_obstruction

end NullSectorTask06
