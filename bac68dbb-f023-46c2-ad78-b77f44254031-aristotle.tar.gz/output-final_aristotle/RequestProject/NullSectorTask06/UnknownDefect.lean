import RequestProject.NullSectorTask06.ProperAction

/-!
# Task 06, Layer 3: the unknown alternating defect

From here on `A : RestDefect = Vec3 →ₗ[ℝ] Vec3 →ₗ[ℝ] Vec4` is an entirely
**abstract variable**.  No explicit nonzero alternating map is defined in this
file, and no multiplication table on `r₁, r₂, r₃` is assumed.  The only concrete
defect mentioned anywhere before the rigidity theorem is `0`.

This file only

* defines equivariance of an unknown defect under the proper isotropy (and
  under the full isotropy);
* relates it to equivariance of the corresponding global product;
* splits the unknown output `A v w` into its `e₀`-component and its rest-space
  component, and records how proper isotropy acts on each.
-/

namespace NullSectorTask06

open NullSectorTask01 NullSectorTask04

/-! ## Equivariance -/

/-- Equivariance of an unknown defect under the orientation-preserving isotropy
of `e₀`.  The action on the codomain is the ambient action of `R`. -/
def ProperEquivariant (A : RestDefect) : Prop :=
  ∀ R : Vec4 ≃ₗ[ℝ] Vec4, ProperStab R → ∀ v w : Vec3,
    R (A v w) = A (restOf R v) (restOf R w)

/-- Equivariance of an unknown defect under the **full** isotropy of `e₀`. -/
def FullEquivariant (A : RestDefect) : Prop :=
  ∀ R : Vec4 ≃ₗ[ℝ] Vec4, Stab R → ∀ v w : Vec3,
    R (A v w) = A (restOf R v) (restOf R w)

theorem FullEquivariant.toProper {A : RestDefect} (hA : FullEquivariant A) :
    ProperEquivariant A := fun R hR => hA R hR.1

/-- Equivariance of a global product under the proper isotropy. -/
def ProperEquivariantProd (M : BiProd4) : Prop :=
  ∀ R : Vec4 ≃ₗ[ℝ] Vec4, ProperStab R → ∀ X Y, R (M X Y) = M (R X) (R Y)

/-- Equivariance of a global product under the full isotropy. -/
def IsotropyEquivariantProd (M : BiProd4) : Prop :=
  ∀ R : Vec4 ≃ₗ[ℝ] Vec4, Stab R → ∀ X Y, R (M X Y) = M (R X) (R Y)

theorem IsotropyEquivariantProd.toProper {M : BiProd4} (hM : IsotropyEquivariantProd M) :
    ProperEquivariantProd M := fun R hR => hM R hR.1

/-- The zero defect is (trivially) equivariant: the trivial control. -/
theorem properEquivariant_zero : ProperEquivariant (0 : RestDefect) := by
  intro R _ v w; simp

/-! ## The forced symmetric branch is equivariant -/

theorem symForced_isotropyEquivariant : IsotropyEquivariantProd symForced := by
  intro R hR X Y
  rw [symForced_coordfree, map_sub, map_add, map_smul, map_smul, map_smul, hR.1,
    symForced_coordfree, stab_L4_e₀ hR, stab_L4_e₀ hR, stab_L4 hR]

/-! ## Translating equivariance between products and defects -/

/-- Equivariance of a sector-compatible product gives equivariance of its
defect. -/
theorem properEquivariant_defectOfProd {M : BiProd4} (hE : ProperEquivariantProd M)
    {R : Vec4 ≃ₗ[ℝ] Vec4} (hR : ProperStab R) (v w : Vec3) :
    R (defectOfProd M v w) = defectOfProd M (restOf R v) (restOf R w) := by
  rw [defectOfProd_apply, defectOfProd_apply, map_sub, map_smul, hR.1.1]
  rw [← stab_sp hR.1, ← stab_sp hR.1, hE R hR, restOf_dot3 hR.1]

theorem properEquivariant_of_prod {M : BiProd4} (hE : ProperEquivariantProd M) :
    ProperEquivariant (defectOfProd M) :=
  fun _ hR v w => properEquivariant_defectOfProd hE hR v w

theorem fullEquivariant_of_prod {M : BiProd4} (hE : IsotropyEquivariantProd M) :
    FullEquivariant (defectOfProd M) := by
  intro R hR v w
  rw [defectOfProd_apply, defectOfProd_apply, map_sub, map_smul, hR.1]
  rw [← stab_sp hR, ← stab_sp hR, hE R hR, restOf_dot3 hR]

/-- Conversely, an equivariant defect gives an equivariant product. -/
theorem properEquivariantProd_extensionFromDefect {A : RestDefect}
    (hA : ProperEquivariant A) : ProperEquivariantProd (extensionFromDefect A) := by
  intro R hR X Y
  rw [extensionFromDefect_apply, extensionFromDefect_apply, map_add,
    symForced_isotropyEquivariant R hR.1 X Y, hA R hR, stab_snd hR.1 X, stab_snd hR.1 Y]

theorem isotropyEquivariantProd_extensionFromDefect {A : RestDefect}
    (hA : FullEquivariant A) : IsotropyEquivariantProd (extensionFromDefect A) := by
  intro R hR X Y
  rw [extensionFromDefect_apply, extensionFromDefect_apply, map_add,
    symForced_isotropyEquivariant R hR X Y, hA R hR, stab_snd hR X, stab_snd hR Y]

/-! ## Temporal and spatial output components of the unknown defect -/

/-- The `e₀`-component of the unknown output. -/
def tempPart (A : RestDefect) (v w : Vec3) : ℝ := (A v w).1

/-- The rest-space component of the unknown output. -/
def spatPart (A : RestDefect) (v w : Vec3) : Vec3 := (A v w).2

/-- Decomposition of the unknown output relative to `e₀`. -/
theorem defect_decomp (A : RestDefect) (v w : Vec3) :
    A v w = (tempPart A v w) • e₀ + sp (spatPart A v w) := vec4_decomp (A v w)

/-- **Proper isotropy acts trivially on the temporal output component.** -/
theorem tempPart_invariant {A : RestDefect} (hA : ProperEquivariant A)
    {R : Vec4 ≃ₗ[ℝ] Vec4} (hR : ProperStab R) (v w : Vec3) :
    tempPart A (restOf R v) (restOf R w) = tempPart A v w := by
  have h := hA R hR v w
  have := congrArg (fun Z : Vec4 => Z.1) h
  simp only at this
  rw [stab_time hR.1] at this
  exact this.symm

/-- **Proper isotropy acts on the spatial output component through the induced
rest-space map.** -/
theorem spatPart_equivariant {A : RestDefect} (hA : ProperEquivariant A)
    {R : Vec4 ≃ₗ[ℝ] Vec4} (hR : ProperStab R) (v w : Vec3) :
    spatPart A (restOf R v) (restOf R w) = restOf R (spatPart A v w) := by
  have h := hA R hR v w
  have h2 := congrArg (fun Z : Vec4 => Z.2) h
  simp only at h2
  rw [stab_snd hR.1] at h2
  exact h2.symm

end NullSectorTask06
