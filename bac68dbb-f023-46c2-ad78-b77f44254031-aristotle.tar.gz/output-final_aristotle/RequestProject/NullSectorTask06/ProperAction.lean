import RequestProject.NullSectorTask06.GenericExtension

/-!
# Task 06, Layer 2: the proper rest-space isotropy (RE-DERIVED)

The stabilizer of the chosen future unit is defined intrinsically by two
conditions only:

```
R e₀ = e₀   and   ∀ X, Q4 (R X) = Q4 X.
```

Preservation of the polarized form `L4`, of the time component (hence of the
future direction), of the rest space and of the induced positive form are all
**derived**.

The orientation criterion is the ordinary determinant of the induced rest-space
map, written out by hand in the coordinate basis as a *scalar* trilinear
expression (Leibniz/Sarrus formula).  It is **not** built from any bilinear
alternating map on the rest space: no map of type `Vec3 → Vec3 → Vec3` or
`Vec3 → Vec3 → Vec4` occurs anywhere in this file.

No conventional group-theoretic name is used as a proof shortcut; all proper
transformations occurring later are constructed by explicit coordinate
formulas, and their orientation determinant is computed.
-/

namespace NullSectorTask06

open NullSectorTask01 NullSectorTask04

/-! ## The stabilizer of the chosen unit -/

/-- Linear equivalences of the ambient carrier fixing `e₀` and preserving `Q4`. -/
def Stab (R : Vec4 ≃ₗ[ℝ] Vec4) : Prop := R e₀ = e₀ ∧ ∀ X, Q4 (R X) = Q4 X

variable {R : Vec4 ≃ₗ[ℝ] Vec4}

/-- **DERIVED.**  A stabilizer preserves the polarized form. -/
theorem stab_L4 (hR : Stab R) (X Y : Vec4) : L4 (R X) (R Y) = L4 X Y := by
  simp only [L4, ← map_add]
  rw [hR.2 (X + Y), hR.2 X, hR.2 Y]

theorem stab_L4_e₀ (hR : Stab R) (X : Vec4) : L4 (R X) e₀ = L4 X e₀ := by
  calc L4 (R X) e₀ = L4 (R X) (R e₀) := by rw [hR.1]
    _ = L4 X e₀ := stab_L4 hR X e₀

/-- **DERIVED.**  A stabilizer preserves the time component; in particular it
preserves the future component of every vector. -/
theorem stab_time (hR : Stab R) (X : Vec4) : (R X).1 = X.1 := by
  have h1 := stab_L4_e₀ hR X
  rwa [L4_e₀_right, L4_e₀_right] at h1

/-- **DERIVED.**  Future vectors are sent to future vectors. -/
theorem stab_future (hR : Stab R) {X : Vec4} (hX : 0 < X.1) : 0 < (R X).1 := by
  rwa [stab_time hR]

/-- **DERIVED.**  A stabilizer preserves the rest space. -/
theorem stab_rest (hR : Stab R) {X : Vec4} (hX : X ∈ Rest) : R X ∈ Rest := by
  rw [mem_Rest, stab_time hR]
  exact (mem_Rest X).1 hX

/-- **DERIVED.**  A stabilizer preserves the induced positive rest-space form. -/
theorem stab_h (hR : Stab R) (X Y : Vec4) : h (R X) (R Y) = h X Y := by
  simp only [h, stab_L4 hR]

/-- The induced map of rest-space coordinates. -/
def restOf (R : Vec4 ≃ₗ[ℝ] Vec4) (v : Vec3) : Vec3 := (R (sp v)).2

theorem stab_sp (hR : Stab R) (v : Vec3) : R (sp v) = sp (restOf R v) :=
  rest_eq_sp (stab_rest hR (sp_mem_Rest v))

theorem stab_snd (hR : Stab R) (X : Vec4) : (R X).2 = restOf R X.2 := by
  conv_lhs => rw [vec4_decomp X]
  rw [map_add, map_smul, hR.1, stab_sp hR]
  simp [e₀]

theorem restOf_dot3 (hR : Stab R) (v w : Vec3) :
    dot3 (restOf R v) (restOf R w) = dot3 v w := by
  have h1 := stab_h hR (sp v) (sp w)
  rwa [stab_sp hR v, stab_sp hR w, h_sp, h_sp] at h1

theorem restOf_add (hR : Stab R) (v w : Vec3) :
    restOf R (v + w) = restOf R v + restOf R w := by
  apply sp_injective
  rw [← stab_sp hR (v + w), sp_add, map_add, stab_sp hR v, stab_sp hR w, ← sp_add]

theorem restOf_smul (hR : Stab R) (c : ℝ) (v : Vec3) :
    restOf R (c • v) = c • restOf R v := by
  apply sp_injective
  rw [← stab_sp hR (c • v), sp_smul, map_smul, stab_sp hR v, ← sp_smul]

/-! ## The orientation criterion -/

/-- The determinant of a triple of spatial coordinate vectors, written out by
hand (Leibniz formula).  This is a *scalar* trilinear expression, not a
bilinear map on the rest space. -/
def det3 (a b c : Vec3) : ℝ :=
  a.1 * (b.2.1 * c.2.2 - b.2.2 * c.2.1)
    - a.2.1 * (b.1 * c.2.2 - b.2.2 * c.1)
    + a.2.2 * (b.1 * c.2.1 - b.2.1 * c.1)

@[simp] theorem det3_apply (a b c : Vec3) :
    det3 a b c = a.1 * (b.2.1 * c.2.2 - b.2.2 * c.2.1)
      - a.2.1 * (b.1 * c.2.2 - b.2.2 * c.1)
      + a.2.2 * (b.1 * c.2.1 - b.2.1 * c.1) := rfl

@[simp] theorem det3_basis : det3 r₁ r₂ r₃ = 1 := by norm_num [s₁, s₂, s₃]

/-- Orientation determinant of a stabilizer: the determinant of the images of
the rest basis. -/
def detRest (R : Vec4 ≃ₗ[ℝ] Vec4) : ℝ := det3 (restOf R r₁) (restOf R r₂) (restOf R r₃)

/-- **Proper (orientation-preserving) isotropy.**  A transformation fixing `e₀`,
preserving `Q4` (hence `L4`, the rest space, the induced positive form, and the
future component), whose induced rest-space map has determinant `+1`. -/
def ProperStab (R : Vec4 ≃ₗ[ℝ] Vec4) : Prop := Stab R ∧ detRest R = 1

theorem ProperStab.toStab {R : Vec4 ≃ₗ[ℝ] Vec4} (hR : ProperStab R) : Stab R := hR.1

/-! ## Coordinate description of the induced rest-space map -/

/-- Expansion of a spatial vector along a triple. -/
def rho (c1 c2 c3 : Vec3) (v : Vec3) : Vec3 := v.1 • c1 + v.2.1 • c2 + v.2.2 • c3

@[simp] theorem rho_apply (c1 c2 c3 v : Vec3) :
    rho c1 c2 c3 v = v.1 • c1 + v.2.1 • c2 + v.2.2 • c3 := rfl

/-- A stabilizer acts on rest coordinates through the images of the basis. -/
theorem restOf_eq_rho (hR : Stab R) (v : Vec3) :
    restOf R v = rho (restOf R r₁) (restOf R r₂) (restOf R r₃) v := by
  conv_lhs => rw [rest_basis_expansion v]
  rw [restOf_add hR, restOf_add hR, restOf_smul hR, restOf_smul hR, restOf_smul hR]
  rfl

/-- The images of the rest basis under a stabilizer are orthonormal. -/
theorem stab_columns (hR : Stab R) :
    dot3 (restOf R r₁) (restOf R r₁) = 1 ∧ dot3 (restOf R r₂) (restOf R r₂) = 1 ∧
      dot3 (restOf R r₃) (restOf R r₃) = 1 ∧ dot3 (restOf R r₁) (restOf R r₂) = 0 ∧
      dot3 (restOf R r₁) (restOf R r₃) = 0 ∧ dot3 (restOf R r₂) (restOf R r₃) = 0 := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩ <;> rw [restOf_dot3 hR] <;> simp [s₁, s₂, s₃]

/-! ## Explicit transformations -/

/-- Builder for a linear equivalence of the spatial coordinates. -/
def mkEquiv3 (f g : Vec3 → Vec3)
    (hadd : ∀ v w, f (v + w) = f v + f w) (hsmul : ∀ (c : ℝ) v, f (c • v) = c • f v)
    (h1 : ∀ v, g (f v) = v) (h2 : ∀ v, f (g v) = v) : Vec3 ≃ₗ[ℝ] Vec3 where
  toFun := f
  map_add' := hadd
  map_smul' := hsmul
  invFun := g
  left_inv := h1
  right_inv := h2

/-- Lift a spatial equivalence to the ambient carrier, fixing the time
coordinate. -/
def liftRest (f : Vec3 ≃ₗ[ℝ] Vec3) : Vec4 ≃ₗ[ℝ] Vec4 :=
  LinearEquiv.prodCongr (LinearEquiv.refl ℝ ℝ) f

@[simp] theorem liftRest_apply (f : Vec3 ≃ₗ[ℝ] Vec3) (X : Vec4) :
    liftRest f X = (X.1, f X.2) := rfl

theorem liftRest_stab {f : Vec3 ≃ₗ[ℝ] Vec3} (hf : ∀ v, dot3 (f v) (f v) = dot3 v v) :
    Stab (liftRest f) := by
  constructor
  · rw [liftRest_apply, e₀_snd, map_zero]
    rfl
  · intro X
    have h1 := hf X.2
    simp only [dot3_apply] at h1
    simp only [liftRest_apply, Q4]
    nlinarith [h1]

@[simp] theorem restOf_liftRest (f : Vec3 ≃ₗ[ℝ] Vec3) (v : Vec3) :
    restOf (liftRest f) v = f v := rfl

/-- Half-turn about the first rest direction. -/
def hx : Vec3 ≃ₗ[ℝ] Vec3 :=
  mkEquiv3 (fun v => (v.1, -v.2.1, -v.2.2)) (fun v => (v.1, -v.2.1, -v.2.2))
    (by intro v w; apply vec3_ext <;> simp <;> ring)
    (by intro c v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)

/-- Half-turn about the second rest direction. -/
def hy : Vec3 ≃ₗ[ℝ] Vec3 :=
  mkEquiv3 (fun v => (-v.1, v.2.1, -v.2.2)) (fun v => (-v.1, v.2.1, -v.2.2))
    (by intro v w; apply vec3_ext <;> simp <;> ring)
    (by intro c v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)

/-- Half-turn about the third rest direction. -/
def hz : Vec3 ≃ₗ[ℝ] Vec3 :=
  mkEquiv3 (fun v => (-v.1, -v.2.1, v.2.2)) (fun v => (-v.1, -v.2.1, v.2.2))
    (by intro v w; apply vec3_ext <;> simp <;> ring)
    (by intro c v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)

/-- Quarter-turn about the third rest direction. -/
def qz : Vec3 ≃ₗ[ℝ] Vec3 :=
  mkEquiv3 (fun v => (-v.2.1, v.1, v.2.2)) (fun v => (v.2.1, -v.1, v.2.2))
    (by intro v w; apply vec3_ext <;> simp; ring)
    (by intro c v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)

/-- Quarter-turn about the first rest direction. -/
def qx : Vec3 ≃ₗ[ℝ] Vec3 :=
  mkEquiv3 (fun v => (v.1, -v.2.2, v.2.1)) (fun v => (v.1, v.2.2, -v.2.1))
    (by intro v w; apply vec3_ext <;> simp; ring)
    (by intro c v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)

/-- Reflection of the third rest coordinate (orientation reversing). -/
def refz : Vec3 ≃ₗ[ℝ] Vec3 :=
  mkEquiv3 (fun v => (v.1, v.2.1, -v.2.2)) (fun v => (v.1, v.2.1, -v.2.2))
    (by intro v w; apply vec3_ext <;> simp; ring)
    (by intro c v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)

@[simp] theorem hx_apply (v : Vec3) : hx v = (v.1, -v.2.1, -v.2.2) := rfl
@[simp] theorem hy_apply (v : Vec3) : hy v = (-v.1, v.2.1, -v.2.2) := rfl
@[simp] theorem hz_apply (v : Vec3) : hz v = (-v.1, -v.2.1, v.2.2) := rfl
@[simp] theorem qz_apply (v : Vec3) : qz v = (-v.2.1, v.1, v.2.2) := rfl
@[simp] theorem qx_apply (v : Vec3) : qx v = (v.1, -v.2.2, v.2.1) := rfl
@[simp] theorem refz_apply (v : Vec3) : refz v = (v.1, v.2.1, -v.2.2) := rfl

theorem properStab_hx : ProperStab (liftRest hx) := by
  refine ⟨liftRest_stab (by intro v; simp only [hx_apply, dot3_apply]; ring), ?_⟩
  simp only [detRest, restOf_liftRest, det3_apply, hx_apply]
  norm_num [s₁, s₂, s₃]

theorem properStab_hy : ProperStab (liftRest hy) := by
  refine ⟨liftRest_stab (by intro v; simp only [hy_apply, dot3_apply]; ring), ?_⟩
  simp only [detRest, restOf_liftRest, det3_apply, hy_apply]
  norm_num [s₁, s₂, s₃]

theorem properStab_hz : ProperStab (liftRest hz) := by
  refine ⟨liftRest_stab (by intro v; simp only [hz_apply, dot3_apply]; ring), ?_⟩
  simp only [detRest, restOf_liftRest, det3_apply, hz_apply]
  norm_num [s₁, s₂, s₃]

theorem properStab_qz : ProperStab (liftRest qz) := by
  refine ⟨liftRest_stab (by intro v; simp only [qz_apply, dot3_apply]; ring), ?_⟩
  simp only [detRest, restOf_liftRest, det3_apply, qz_apply]
  norm_num [s₁, s₂, s₃]

theorem properStab_qx : ProperStab (liftRest qx) := by
  refine ⟨liftRest_stab (by intro v; simp only [qx_apply, dot3_apply]; ring), ?_⟩
  simp only [detRest, restOf_liftRest, det3_apply, qx_apply]
  norm_num [s₁, s₂, s₃]

/-- The third-coordinate reflection is a stabilizer. -/
theorem stab_refz : Stab (liftRest refz) :=
  liftRest_stab (by intro v; simp only [refz_apply, dot3_apply]; ring)

/-- Its orientation determinant is `-1`: it is **not** proper. -/
theorem detRest_refz : detRest (liftRest refz) = -1 := by
  simp only [detRest, restOf_liftRest, det3_apply, refz_apply]
  norm_num [s₁, s₂, s₃]

theorem not_properStab_refz : ¬ ProperStab (liftRest refz) := by
  intro hcon
  have := hcon.2
  rw [detRest_refz] at this
  norm_num at this

/-! ## Action of the explicit transformations on the rest basis -/

theorem hx_r₁ : hx r₁ = r₁ := by apply vec3_ext <;> simp [s₁]
theorem hx_r₂ : hx r₂ = -r₂ := by apply vec3_ext <;> simp [s₂]
theorem hx_r₃ : hx r₃ = -r₃ := by apply vec3_ext <;> simp [s₃]
theorem hy_r₁ : hy r₁ = -r₁ := by apply vec3_ext <;> simp [s₁]
theorem hy_r₂ : hy r₂ = r₂ := by apply vec3_ext <;> simp [s₂]
theorem hy_r₃ : hy r₃ = -r₃ := by apply vec3_ext <;> simp [s₃]
theorem hz_r₁ : hz r₁ = -r₁ := by apply vec3_ext <;> simp [s₁]
theorem hz_r₂ : hz r₂ = -r₂ := by apply vec3_ext <;> simp [s₂]
theorem hz_r₃ : hz r₃ = r₃ := by apply vec3_ext <;> simp [s₃]
theorem qz_r₂ : qz r₂ = -r₁ := by apply vec3_ext <;> simp [s₁, s₂]
theorem qz_r₃ : qz r₃ = r₃ := by apply vec3_ext <;> simp [s₃]
theorem qx_r₁ : qx r₁ = r₁ := by apply vec3_ext <;> simp [s₁]
theorem qx_r₃ : qx r₃ = -r₂ := by apply vec3_ext <;> simp [s₂, s₃]
theorem refz_r₁ : refz r₁ = r₁ := by apply vec3_ext <;> simp [s₁]
theorem refz_r₂ : refz r₂ = r₂ := by apply vec3_ext <;> simp [s₂]
theorem refz_r₃ : refz r₃ = -r₃ := by apply vec3_ext <;> simp [s₃]

end NullSectorTask06
