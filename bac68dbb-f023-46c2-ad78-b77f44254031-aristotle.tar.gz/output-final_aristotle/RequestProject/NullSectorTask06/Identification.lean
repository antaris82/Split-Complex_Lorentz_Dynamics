import RequestProject.NullSectorTask06.OrientationReversal
import Mathlib.LinearAlgebra.CrossProduct

/-!
# Task 06, Layer 8: late conventional identification — **COMPARISON ONLY**

Everything in this module is `COMPARISON ONLY`.  It is the first module of the
Task-06 development in which a conventional name for the reconstructed
alternating operation may appear.  Nothing proved here is used by any earlier
module, and no earlier module imports it.

Two comparisons are made:

* the spatial part `wit3` of the reconstructed alternating defect coincides,
  under the coordinate identification `ℝ × ℝ × ℝ ≃ (Fin 3 → ℝ)`, with the
  library operation `crossProduct` of `Mathlib.LinearAlgebra.CrossProduct`
  (`COMPARISON ONLY`);
* the forced symmetric branch `symForced` has the coordinate-free shape
  `L4 X e₀ • Y + L4 Y e₀ • X - L4 X Y • e₀`, already recorded in
  `Task06.GenericExtension`.

The reconstruction itself did not use, import or mention these objects.
-/

namespace NullSectorTask06

open NullSectorTask01 NullSectorTask04

/-- Coordinate identification of the rest space with `Fin 3 → ℝ`. -/
def toFin3 (v : Vec3) : Fin 3 → ℝ := ![v.1, v.2.1, v.2.2]

@[simp] theorem toFin3_zero (v : Vec3) : toFin3 v 0 = v.1 := rfl
@[simp] theorem toFin3_one (v : Vec3) : toFin3 v 1 = v.2.1 := rfl
@[simp] theorem toFin3_two (v : Vec3) : toFin3 v 2 = v.2.2 := rfl

/-- **COMPARISON ONLY.**  The independently reconstructed alternating operation
is, in coordinates, the conventional three-dimensional vector product of the
Mathlib library. -/
theorem wit3_eq_crossProduct (v w : Vec3) :
    toFin3 (wit3 v w) = crossProduct (toFin3 v) (toFin3 w) := by
  funext i
  fin_cases i <;> simp [crossProduct, toFin3]

/-- **COMPARISON ONLY.**  Consequently the whole proper-equivariant solution
space consists of the real multiples of that conventional operation, embedded
into the rest space of the ambient carrier. -/
theorem properSolutions_eq_crossProduct_multiples {A : RestDefect}
    (hA : Alternating A) (hE : ProperEquivariant A) :
    ∃ c : ℝ, ∀ v w : Vec3,
      toFin3 (A v w).2 = c • crossProduct (toFin3 v) (toFin3 w) := by
  obtain ⟨c, hc⟩ := (properEquivariant_iff A).1 ⟨hA, hE⟩
  refine ⟨c, fun v w => ?_⟩
  rw [hc]
  have hval : ((c • witDefect) v w).2 = c • wit3 v w := by
    simp only [LinearMap.smul_apply, witDefect_apply]
    rfl
  rw [hval, ← wit3_eq_crossProduct]
  funext i
  fin_cases i <;> simp [toFin3]

end NullSectorTask06
