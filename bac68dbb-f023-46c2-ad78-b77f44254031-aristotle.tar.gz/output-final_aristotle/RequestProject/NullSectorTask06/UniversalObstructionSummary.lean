import RequestProject.NullSectorTask06.AssociativityObstruction
import RequestProject.NullSectorTask06.NormObstruction

/-!
# Task 06, Phase B, Layer 3: summary of the universal obstructions

The two Phase-B questions were settled **separately** (in
`Task06.AssociativityObstruction` and `Task06.NormObstruction`, neither of which
imports the other, and neither of which imports any Phase-A module beyond the
clean generic layer).  This module only collects the results, records the
minimal configuration in which both obstructions already appear, and states the
joint theorem as a summary.

No repair is attempted: the carrier, the scalar field and the longitudinal
sector laws are untouched.
-/

namespace NullSectorTask06

open NullSectorTask01 NullSectorTask04

/-! ## The minimal configuration -/

/-- **MINIMAL CONFIGURATION.**  Everything the two obstruction proofs use is
contained in this list: two orthonormal rest directions whose squares are the
inherited unit, whose symmetrized product vanishes, and the fact that the
`e₀`-component of any square is a sum of squares. -/
theorem minimal_obstruction_configuration (M : BiProd4) (hM : SectorCompatible M) :
    M (sp r₁) (sp r₁) = e₀ ∧ M (sp r₂) (sp r₂) = e₀ ∧
      M (sp r₁) (sp r₂) + M (sp r₂) (sp r₁) = 0 ∧
      (∀ Z : Vec4, (M Z Z).1 = Z.1 * Z.1 + dot3 Z.2 Z.2) := by
  refine ⟨?_, ?_, ?_, fun Z => sq_time_component hM Z⟩
  · rw [M_rest_sq hM r₁]; norm_num [s₁]
  · rw [M_rest_sq hM r₂]; norm_num [s₂]
  · rw [M_rest_symm hM r₁ r₂]; norm_num [s₁, s₂]

/-! ## The two separate verdicts -/

/-- `ASSOCIATIVITY: impossible` — `UNIVERSAL OBSTRUCTION`. -/
theorem associativity_universally_impossible :
    ∀ M : BiProd4, SectorCompatible M → ¬ Associative4 M :=
  fun M hM => no_associative_sectorCompatible M hM

/-- `GLOBAL Q4 MULTIPLICATIVITY: impossible` — `UNIVERSAL OBSTRUCTION`. -/
theorem globalNorm_universally_impossible :
    ∀ M : BiProd4, SectorCompatible M → ¬ Q4Multiplicative M :=
  fun M hM => no_Q4Multiplicative_sectorCompatible M hM

/-- Both obstructions are independent of any further hypothesis one might wish
to add — in particular of any isotropy or orientation assumption `P`. -/
theorem obstructions_independent_of_extra_hypotheses (P : BiProd4 → Prop) :
    (∀ M : BiProd4, SectorCompatible M → P M → ¬ Associative4 M) ∧
      (∀ M : BiProd4, SectorCompatible M → P M → ¬ Q4Multiplicative M) :=
  ⟨fun M hM _ => no_associative_sectorCompatible M hM,
   fun M hM _ => no_Q4Multiplicative_sectorCompatible M hM⟩

/-! ## Joint theorem (summary only) -/

/-- **Joint statement.**  Recorded only after the two separate results: no
sector-compatible product is both associative and globally
`Q4`-multiplicative — indeed neither property is attainable on its own. -/
theorem no_associative_and_Q4Multiplicative :
    ¬ ∃ M : BiProd4, SectorCompatible M ∧ Associative4 M ∧ Q4Multiplicative M := by
  rintro ⟨M, hM, hassoc, _⟩
  exact no_associative_sectorCompatible M hM hassoc

/-- **Diagnostic handoff (neutral statement).**  Inside the fixed real `3+1`
carrier, two mutually orthogonal rest directions cannot both satisfy the
inherited sector square relations together with global associativity, and
cannot both satisfy them together with global `Q4`-multiplicativity: in each
case the temporal component of the resulting square is forced to be
simultaneously nonnegative and equal to `-1`. -/
theorem diagnostic_handoff (M : BiProd4) (hM : SectorCompatible M) :
    (Associative4 M → False) ∧ (Q4Multiplicative M → False) :=
  ⟨no_associative_sectorCompatible M hM, no_Q4Multiplicative_sectorCompatible M hM⟩

end NullSectorTask06
