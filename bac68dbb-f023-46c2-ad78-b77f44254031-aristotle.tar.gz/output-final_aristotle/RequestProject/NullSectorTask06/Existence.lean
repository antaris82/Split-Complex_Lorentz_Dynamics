import RequestProject.NullSectorTask06.Rigidity

/-!
# Task 06, Layer 5: existence, **after** rigidity

The rigidity theorems of `Task06.Rigidity` bound the solution space from above:
an alternating proper-equivariant defect is determined by a single real number,
and its temporal output component vanishes.  Nothing so far shows that a nonzero
solution exists.

This file is the **first** place in the Task-06 development where an explicit
nonzero alternating bilinear map on the rest space is written down.  Its shape is
not imported from anywhere and not taken from a conventional operation: it is
read off from the rigidity conclusion

```
A r₂ r₃ = c • sp r₁,  A r₃ r₁ = c • sp r₂,  A r₁ r₂ = c • sp r₃
```

together with the general bilinear expansion `alternating_expand`, taking
`c = 1`.  The verification that it really is alternating and really is proper
equivariant is then a computation.
-/

namespace NullSectorTask06

open NullSectorTask01 NullSectorTask04

/-! ## The candidate produced by the rigidity conclusion -/

/-- The spatial map obtained by inserting the rigidity values
`A r₁ r₂ = r₃`, `A r₂ r₃ = r₁`, `A r₃ r₁ = r₂` (`c = 1`) into the general
bilinear expansion of an alternating defect. -/
def wit3 (v w : Vec3) : Vec3 :=
  (v.2.1 * w.2.2 - v.2.2 * w.2.1, v.2.2 * w.1 - v.1 * w.2.2, v.1 * w.2.1 - v.2.1 * w.1)

@[simp] theorem wit3_apply (v w : Vec3) :
    wit3 v w = (v.2.1 * w.2.2 - v.2.2 * w.2.1, v.2.2 * w.1 - v.1 * w.2.2,
      v.1 * w.2.1 - v.2.1 * w.1) := rfl

theorem wit3_self (v : Vec3) : wit3 v v = 0 := by
  apply vec3_ext <;> simp <;> ring

theorem wit3_add_left (u v w : Vec3) : wit3 (u + v) w = wit3 u w + wit3 v w := by
  apply vec3_ext <;> simp <;> ring

theorem wit3_add_right (u v w : Vec3) : wit3 u (v + w) = wit3 u v + wit3 u w := by
  apply vec3_ext <;> simp <;> ring

theorem wit3_smul_left (c : ℝ) (v w : Vec3) : wit3 (c • v) w = c • wit3 v w := by
  apply vec3_ext <;> simp <;> ring

theorem wit3_smul_right (c : ℝ) (v w : Vec3) : wit3 v (c • w) = c • wit3 v w := by
  apply vec3_ext <;> simp <;> ring

/-- **EXISTENCE WITNESS.**  The candidate packaged as a defect datum, with values
in the rest space of the ambient carrier. -/
def witDefect : RestDefect :=
  LinearMap.mk₂ ℝ (fun v w => sp (wit3 v w))
    (by intro u v w; dsimp only; rw [wit3_add_left, sp_add])
    (by intro c v w; dsimp only; rw [wit3_smul_left, sp_smul])
    (by intro u v w; dsimp only; rw [wit3_add_right, sp_add])
    (by intro c v w; dsimp only; rw [wit3_smul_right, sp_smul])

@[simp] theorem witDefect_apply (v w : Vec3) : witDefect v w = sp (wit3 v w) := rfl

/-- The witness is alternating. -/
theorem witDefect_alternating : Alternating witDefect := by
  intro v; rw [witDefect_apply, wit3_self]; rfl

/-! ## Values on the basis pairs -/

@[simp] theorem wit3_r₁_r₂ : wit3 r₁ r₂ = r₃ := by apply vec3_ext <;> simp [s₁, s₂, s₃]
@[simp] theorem wit3_r₂_r₃ : wit3 r₂ r₃ = r₁ := by apply vec3_ext <;> simp [s₁, s₂, s₃]
@[simp] theorem wit3_r₃_r₁ : wit3 r₃ r₁ = r₂ := by apply vec3_ext <;> simp [s₁, s₂, s₃]

theorem witDefect_r₁_r₂ : witDefect r₁ r₂ = sp r₃ := by rw [witDefect_apply, wit3_r₁_r₂]
theorem witDefect_r₂_r₃ : witDefect r₂ r₃ = sp r₁ := by rw [witDefect_apply, wit3_r₂_r₃]
theorem witDefect_r₃_r₁ : witDefect r₃ r₁ = sp r₂ := by rw [witDefect_apply, wit3_r₃_r₁]

/-- The parameter of the witness is `1`. -/
@[simp] theorem witDefect_param : (witDefect r₂ r₃).2.1 = 1 := by
  rw [witDefect_r₂_r₃]; rfl

/-- **NONTRIVIALITY.** -/
theorem witDefect_ne_zero : witDefect ≠ 0 := by
  intro hcon
  have := congrArg (fun A : RestDefect => (A r₂ r₃).2.1) hcon
  simp only [witDefect_param, LinearMap.zero_apply] at this
  exact one_ne_zero this

/-! ## Determinant identities (pure polynomial identities) -/

theorem dot3_wit3 (a b c : Vec3) : dot3 (wit3 a b) c = det3 a b c := by
  simp [dot3, det3]; ring

theorem dot3_wit3_left (v w : Vec3) : dot3 (wit3 v w) v = 0 := by
  simp [dot3]; ring

theorem dot3_wit3_right (v w : Vec3) : dot3 (wit3 v w) w = 0 := by
  simp [dot3]; ring

theorem det3_rot1 (c1 c2 c3 : Vec3) : dot3 (wit3 c2 c3) c1 = det3 c1 c2 c3 := by
  simp [dot3, det3]; ring

theorem det3_rot2 (c1 c2 c3 : Vec3) : dot3 (wit3 c3 c1) c2 = det3 c1 c2 c3 := by
  simp [dot3, det3]; ring

/-- **Reciprocal expansion.**  A pure polynomial identity. -/
theorem recip_expansion (c1 c2 c3 u : Vec3) :
    (det3 c1 c2 c3) • u =
      (dot3 u c1) • (wit3 c2 c3) + (dot3 u c2) • (wit3 c3 c1) + (dot3 u c3) • (wit3 c1 c2) := by
  apply vec3_ext <;> simp [det3, dot3] <;> ring

/-- **Cofactor identity.**  A pure polynomial identity. -/
theorem wit3_of_rho (c1 c2 c3 v w : Vec3) :
    wit3 (rho c1 c2 c3 v) (rho c1 c2 c3 w)
      = rho (wit3 c2 c3) (wit3 c3 c1) (wit3 c1 c2) (wit3 v w) := by
  apply vec3_ext <;> simp <;> ring

/-- The three defining relations of an orthonormal positively oriented triple. -/
theorem wit3_triple {c1 c2 c3 : Vec3}
    (o11 : dot3 c1 c1 = 1) (o22 : dot3 c2 c2 = 1) (o33 : dot3 c3 c3 = 1)
    (o12 : dot3 c1 c2 = 0) (o13 : dot3 c1 c3 = 0) (o23 : dot3 c2 c3 = 0)
    (hdet : det3 c1 c2 c3 = 1) :
    wit3 c2 c3 = c1 ∧ wit3 c3 c1 = c2 ∧ wit3 c1 c2 = c3 := by
  have o21 : dot3 c2 c1 = 0 := by rw [dot3_symm]; exact o12
  have o31 : dot3 c3 c1 = 0 := by rw [dot3_symm]; exact o13
  have o32 : dot3 c3 c2 = 0 := by rw [dot3_symm]; exact o23
  refine ⟨?_, ?_, ?_⟩
  · have hq : (det3 c1 c2 c3) • (wit3 c2 c3 - c1) = 0 := by
      rw [recip_expansion]
      have d1 : dot3 (wit3 c2 c3 - c1) c1 = 0 := by
        rw [dot3_sub_left, det3_rot1, hdet, o11]; ring
      have d2 : dot3 (wit3 c2 c3 - c1) c2 = 0 := by
        rw [dot3_sub_left, dot3_wit3_left, o12]; ring
      have d3 : dot3 (wit3 c2 c3 - c1) c3 = 0 := by
        rw [dot3_sub_left, dot3_wit3_right, o13]; ring
      rw [d1, d2, d3]
      simp
    rw [hdet, one_smul] at hq
    exact sub_eq_zero.1 hq
  · have hq : (det3 c1 c2 c3) • (wit3 c3 c1 - c2) = 0 := by
      rw [recip_expansion]
      have d1 : dot3 (wit3 c3 c1 - c2) c1 = 0 := by
        rw [dot3_sub_left, dot3_wit3_right, o21]; ring
      have d2 : dot3 (wit3 c3 c1 - c2) c2 = 0 := by
        rw [dot3_sub_left, det3_rot2, hdet, o22]; ring
      have d3 : dot3 (wit3 c3 c1 - c2) c3 = 0 := by
        rw [dot3_sub_left, dot3_wit3_left, o23]; ring
      rw [d1, d2, d3]
      simp
    rw [hdet, one_smul] at hq
    exact sub_eq_zero.1 hq
  · have hq : (det3 c1 c2 c3) • (wit3 c1 c2 - c3) = 0 := by
      rw [recip_expansion]
      have d1 : dot3 (wit3 c1 c2 - c3) c1 = 0 := by
        rw [dot3_sub_left, dot3_wit3_left, o31]; ring
      have d2 : dot3 (wit3 c1 c2 - c3) c2 = 0 := by
        rw [dot3_sub_left, dot3_wit3_right, o32]; ring
      have d3 : dot3 (wit3 c1 c2 - c3) c3 = 0 := by
        rw [dot3_sub_left, dot3_wit3, hdet, o33]; ring
      rw [d1, d2, d3]
      simp
    rw [hdet, one_smul] at hq
    exact sub_eq_zero.1 hq

/-! ## Proper equivariance of the witness -/

/-- Transport of the candidate under a proper isotropy transformation. -/
theorem wit3_proper {R : Vec4 ≃ₗ[ℝ] Vec4} (hR : ProperStab R) (v w : Vec3) :
    restOf R (wit3 v w) = wit3 (restOf R v) (restOf R w) := by
  obtain ⟨o11, o22, o33, o12, o13, o23⟩ := stab_columns hR.1
  obtain ⟨K1, K2, K3⟩ := wit3_triple o11 o22 o33 o12 o13 o23 hR.2
  rw [restOf_eq_rho hR.1 v, restOf_eq_rho hR.1 w, restOf_eq_rho hR.1 (wit3 v w),
    wit3_of_rho, K1, K2, K3]

/-- **EXISTENCE WITNESS: proper equivariance.** -/
theorem witDefect_properEquivariant : ProperEquivariant witDefect := by
  intro R hR v w
  rw [witDefect_apply, witDefect_apply, stab_sp hR.1, wit3_proper hR]

/-- **EXISTENCE THEOREM.**  A nonzero alternating proper-equivariant defect
exists.  (Stated only after the rigidity bound has been proved.) -/
theorem exists_nonzero_properEquivariant :
    ∃ A : RestDefect, Alternating A ∧ ProperEquivariant A ∧ A ≠ 0 :=
  ⟨witDefect, witDefect_alternating, witDefect_properEquivariant, witDefect_ne_zero⟩

/-! ## Scalar multiples -/

theorem smul_witDefect_alternating (c : ℝ) : Alternating (c • witDefect) := by
  intro v; simp [witDefect_alternating v]

theorem smul_witDefect_properEquivariant (c : ℝ) : ProperEquivariant (c • witDefect) := by
  intro R hR v w
  simp only [LinearMap.smul_apply, map_smul]
  rw [witDefect_properEquivariant R hR]

@[simp] theorem smul_witDefect_param (c : ℝ) : ((c • witDefect) r₂ r₃).2.1 = c := by
  simp only [LinearMap.smul_apply, witDefect_r₂_r₃]
  simp [sp, s₁]

end NullSectorTask06
