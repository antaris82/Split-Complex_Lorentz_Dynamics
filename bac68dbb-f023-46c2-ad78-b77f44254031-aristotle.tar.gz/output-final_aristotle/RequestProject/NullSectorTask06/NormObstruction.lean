import RequestProject.NullSectorTask06.GenericExtension

/-!
# Task 06, Phase B, Layer 2: the universal global-norm question

This module is **logically independent** of the associativity module: it does
not import it, and associativity is never assumed or used.  As in the
associativity module, the only hypothesis on `M` is `SectorCompatible M`.

The question settled here is existential:

```
does there exist M with SectorCompatible M ∧ Q4Multiplicative M ?
```

The answer is **no**.  The obstruction again involves only two orthonormal rest
directions, and it uses no associativity, no commutativity, no isotropy and no
alternating witness.
-/

namespace NullSectorTask06

open NullSectorTask01 NullSectorTask04

/-! ## Elementary expansion of the quadratic form -/

theorem Q4_add (X Y : Vec4) : Q4 (X + Y) = Q4 X + 2 * L4 X Y + Q4 Y := by
  simp only [L4]; ring

@[simp] theorem Q4_sp_r₁ : Q4 (sp r₁) = -1 := by norm_num [Q4, sp, s₁]

@[simp] theorem Q4_sp_r₂ : Q4 (sp r₂) = -1 := by norm_num [Q4, sp, s₂]

theorem Q4_sp_r₁_add_r₂ : Q4 (sp r₁ + sp r₂) = -2 := by
  norm_num [Q4, sp, s₁, s₂, Prod.ext_iff]

/-! ## The universal no-go theorem -/

/-- **UNIVERSAL OBSTRUCTION.**  No sector-compatible real bilinear product on
the `3+1` carrier satisfies `Q4 (M X Y) = Q4 X * Q4 Y` for all `X, Y`.  The
proof uses only the two inherited sector identities for `sp r₁`, bilinearity,
the quadratic form, and two evaluations of the multiplicativity requirement. -/
theorem no_Q4Multiplicative_sectorCompatible (M : BiProd4) (hM : SectorCompatible M) :
    ¬ Q4Multiplicative M := by
  intro hmul
  set p : Vec4 := M (sp r₁) (sp r₂) with hp
  -- the square of the first direction is the unit
  have haa : M (sp r₁) (sp r₁) = e₀ := by rw [M_rest_sq hM r₁]; norm_num [s₁]
  -- first evaluation: the mixed product has Lorentz square one
  have h1 : Q4 p = 1 := by
    rw [hp, hmul, Q4_sp_r₁, Q4_sp_r₂]; norm_num
  -- second evaluation, on the pair `(sp r₁, sp r₁ + sp r₂)`
  have hbil : M (sp r₁) (sp r₁ + sp r₂) = e₀ + p := by
    rw [M_add_right, haa, hp]
  have h2 : Q4 (e₀ + p) = 2 := by
    rw [← hbil, hmul, Q4_sp_r₁, Q4_sp_r₁_add_r₂]; norm_num
  -- the temporal component of the mixed product is forced to vanish
  have hexp : Q4 (e₀ + p) = Q4 e₀ + 2 * L4 e₀ p + Q4 p := Q4_add e₀ p
  have hp1 : p.1 = 0 := by
    rw [hexp, Q4_e₀, h1, L4_e₀_left] at h2
    linarith
  -- hence its Lorentz square is minus a sum of squares, contradicting `Q4 p = 1`
  have hq : Q4 p = - dot3 p.2 p.2 := by
    obtain ⟨t, u⟩ := p
    simp only at hp1
    subst hp1
    simp [Q4, dot3]
    ring
  rw [hq] at h1
  nlinarith [dot3_self_nonneg p.2]

/-- **UNIVERSAL OBSTRUCTION (existential form).** -/
theorem not_exists_Q4Multiplicative_sectorCompatible :
    ¬ ∃ M : BiProd4, SectorCompatible M ∧ Q4Multiplicative M := by
  rintro ⟨M, hM, hmul⟩
  exact no_Q4Multiplicative_sectorCompatible M hM hmul

/-- **The exact incompatible equations.**  With `p = M (sp r₁) (sp r₂)` and
`p = τ • e₀ + sp u`, global `Q4`-multiplicativity forces simultaneously

```
τ ^ 2 - dot3 u u = 1        (from  Q4 p = Q4 (sp r₁) * Q4 (sp r₂))
(1 + τ) ^ 2 - dot3 u u = 2  (from  Q4 (e₀ + p) = Q4 (sp r₁) * Q4 (sp r₁ + sp r₂))
```

whose difference gives `τ = 0` and therefore `dot3 u u = -1`, impossible for the
positive rest-space form. -/
theorem norm_incompatible_equations {M : BiProd4} (hM : SectorCompatible M)
    (hmul : Q4Multiplicative M) :
    (M (sp r₁) (sp r₂)).1 = 0 ∧
      dot3 (M (sp r₁) (sp r₂)).2 (M (sp r₁) (sp r₂)).2 = -1 := by
  set p : Vec4 := M (sp r₁) (sp r₂) with hp
  have haa : M (sp r₁) (sp r₁) = e₀ := by rw [M_rest_sq hM r₁]; norm_num [s₁]
  have h1 : Q4 p = 1 := by rw [hp, hmul, Q4_sp_r₁, Q4_sp_r₂]; norm_num
  have hbil : M (sp r₁) (sp r₁ + sp r₂) = e₀ + p := by rw [M_add_right, haa, hp]
  have h2 : Q4 (e₀ + p) = 2 := by
    rw [← hbil, hmul, Q4_sp_r₁, Q4_sp_r₁_add_r₂]; norm_num
  have hexp : Q4 (e₀ + p) = Q4 e₀ + 2 * L4 e₀ p + Q4 p := Q4_add e₀ p
  have hp1 : p.1 = 0 := by
    rw [hexp, Q4_e₀, h1, L4_e₀_left] at h2
    linarith
  refine ⟨hp1, ?_⟩
  have hq : Q4 p = - dot3 p.2 p.2 := by
    obtain ⟨t, u⟩ := p
    simp only at hp1
    subst hp1
    simp [Q4, dot3]
    ring
  rw [hq] at h1
  linarith

end NullSectorTask06
