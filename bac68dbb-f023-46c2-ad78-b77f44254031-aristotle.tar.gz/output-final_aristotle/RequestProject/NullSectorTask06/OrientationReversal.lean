import RequestProject.NullSectorTask06.ExactClassification

/-!
# Task 06, Layer 7: orientation reversal and the full isotropy

An explicit orientation-reversing rest-space isometry is available from
`Task06.ProperAction`: the reflection `refz` of the third rest coordinate, whose
orientation determinant was computed to be `-1`.

Two questions are settled here, neither of them assumed in advance:

1. how the reflection acts on the classified solution space (it turns out to
   **negate** the parameter, so the action is nontrivial but of order two);
2. what survives equivariance under the **full** isotropy group (only the zero
   defect, hence a unique global product).
-/

namespace NullSectorTask06

open NullSectorTask01 NullSectorTask04

/-! ## The reflection acting on defects -/

/-- Conjugation of a defect by the orientation-reversing reflection. -/
noncomputable def reverseDefect (A : RestDefect) : RestDefect :=
  LinearMap.mk₂ ℝ (fun v w => liftRest refz (A (refz v) (refz w)))
    (by intro u v w; dsimp only; simp only [map_add, LinearMap.add_apply])
    (by intro c v w; dsimp only; simp only [map_smul, LinearMap.smul_apply])
    (by intro u v w; dsimp only; simp only [map_add])
    (by intro c v w; dsimp only; simp only [map_smul])

@[simp] theorem reverseDefect_apply (A : RestDefect) (v w : Vec3) :
    reverseDefect A v w = liftRest refz (A (refz v) (refz w)) := rfl

/-- The reflection is an involution on defects. -/
theorem reverseDefect_involutive (A : RestDefect) : reverseDefect (reverseDefect A) = A := by
  apply LinearMap.ext; intro v; apply LinearMap.ext; intro w
  simp only [reverseDefect_apply]
  have hv : refz (refz v) = v := by apply vec3_ext <;> simp
  have hw : refz (refz w) = w := by apply vec3_ext <;> simp
  rw [hv, hw]
  apply vec4_ext <;> simp

/-! ## The exact action on the classified solution space -/

/-- **ORIENTATION-REVERSAL THEOREM.**  The reflection negates the parameter of
the classified solution space: it neither fixes the surviving defect nor
permutes it with anything else. -/
theorem reverseDefect_smul_witDefect (c : ℝ) :
    reverseDefect (c • witDefect) = (-c) • witDefect := by
  apply LinearMap.ext; intro v; apply LinearMap.ext; intro w
  simp only [reverseDefect_apply, LinearMap.smul_apply, witDefect_apply, map_smul]
  apply vec4_ext <;> simp [sp] <;> ring

/-- In particular the witness itself is sent to its negative. -/
theorem reverseDefect_witDefect : reverseDefect witDefect = (-1 : ℝ) • witDefect := by
  have := reverseDefect_smul_witDefect 1
  rwa [one_smul] at this

/-- The reflection preserves the solution space and acts on it by `c ↦ -c`;
the only fixed point is the zero defect. -/
theorem reverseDefect_fixed_iff (c : ℝ) :
    reverseDefect (c • witDefect) = c • witDefect ↔ c = 0 := by
  rw [reverseDefect_smul_witDefect]
  constructor
  · intro hcon
    have := smul_witDefect_injective hcon
    linarith
  · rintro rfl; simp

/-! ## The full isotropy -/

/-- **FULL-ISOTROPY CLASSIFICATION.**  Adding the orientation-reversing isometry
to the symmetry requirement destroys the whole surviving freedom. -/
theorem fullEquivariant_iff (A : RestDefect) :
    (Alternating A ∧ FullEquivariant A) ↔ A = 0 := by
  constructor
  · rintro ⟨hA, hE⟩
    obtain ⟨c, hc⟩ := (properEquivariant_iff A).1 ⟨hA, hE.toProper⟩
    -- the reflection fixes `r₁` and `r₂` but reverses `sp r₃`
    have hrefl := hE (liftRest refz) stab_refz r₁ r₂
    simp only [restOf_liftRest, refz_r₁, refz_r₂] at hrefl
    rw [hc] at hrefl
    have hval : (c • witDefect) r₁ r₂ = c • sp r₃ := by
      simp only [LinearMap.smul_apply, witDefect_r₁_r₂]
    rw [hval, map_smul] at hrefl
    have himg : liftRest refz (sp r₃) = - sp r₃ := by
      apply vec4_ext <;> simp [sp, s₃]
    rw [himg] at hrefl
    have hc0 : c = 0 := by
      have h3 := congrArg (fun Z : Vec4 => Z.2.2.2) hrefl
      simp [sp, s₃] at h3
      linarith
    rw [hc, hc0, zero_smul]
  · rintro rfl
    exact ⟨alternating_zero, fun R _ v w => by simp⟩

/-- **FULL-ISOTROPY CLASSIFICATION AT THE LEVEL OF PRODUCTS.**  Sector
compatibility together with equivariance under the full isotropy of `e₀`
determines the product uniquely. -/
theorem sectorCompatible_fullEquivariant_iff (M : BiProd4) :
    (SectorCompatible M ∧ IsotropyEquivariantProd M) ↔ M = symForced := by
  constructor
  · rintro ⟨hM, hE⟩
    have h0 : defectOfProd M = 0 :=
      (fullEquivariant_iff _).1 ⟨defectOfProd_alternating hM, fullEquivariant_of_prod hE⟩
    rw [eq_extensionFromDefect hM, h0, extensionFromDefect_zero]
  · rintro rfl
    refine ⟨symForced_sectorCompatible, symForced_isotropyEquivariant⟩

end NullSectorTask06
