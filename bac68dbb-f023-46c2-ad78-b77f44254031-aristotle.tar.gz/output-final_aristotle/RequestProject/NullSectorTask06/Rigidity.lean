import RequestProject.NullSectorTask06.UnknownDefect

/-!
# Task 06, Layer 4: clean-room rigidity

Here the unknown alternating defect `A` is constrained, using **only**

* bilinearity of `A` (part of its carrier type),
* alternation,
* orthonormality of the rest basis,
* the explicitly constructed proper isotropy transformations of
  `Task06.ProperAction` (two half-turns and two quarter-turns).

No explicit nonzero alternating map has been defined at any point up to and
including this file, and none is used in any proof below.  The direction of the
argument is

```
unknown A  +  symmetry  →  constraints on A.
```

Results:

* the temporal (`e₀`) output component of `A` vanishes identically;
* on the three basis pairs `A` is determined by the **single** real number
  `c = (A r₂ r₃).2.1`, with the values forced to be
  `A r₂ r₃ = c • sp r₁`, `A r₃ r₁ = c • sp r₂`, `A r₁ r₂ = c • sp r₃`;
* consequently two alternating proper-equivariant defects with the same `c`
  coincide, so the solution space injects into `ℝ` (**upper bound**).

Whether the value `c` can be nonzero is *not* decided here; that existence
question is answered only afterwards, in `Task06.Existence`.
-/

namespace NullSectorTask06

open NullSectorTask01 NullSectorTask04

section
variable {A : RestDefect} (hA : Alternating A) (hE : ProperEquivariant A)
include hA hE

/-! ## Step 1: the value on `(r₂, r₃)` -/

omit hA in
/-- **RIGIDITY RESULT.**  The half-turns about the third and the first rest
directions force the value on `(r₂, r₃)` to be a multiple of `sp r₁`; in
particular its temporal component vanishes.  (Alternation is not needed for this
first step: linearity of `A` and the two half-turns already suffice.) -/
theorem rigidity_r₂r₃ : A r₂ r₃ = ((A r₂ r₃).2.1) • sp r₁ := by
  -- half-turn about `r₃`: `r₂ ↦ -r₂`, `r₃ ↦ r₃`
  have ez : liftRest hz (A r₂ r₃) = - A r₂ r₃ := by
    rw [hE _ properStab_hz r₂ r₃]
    simp only [restOf_liftRest, hz_r₂, hz_r₃, map_neg, LinearMap.neg_apply]
  -- half-turn about `r₁`: `r₂ ↦ -r₂`, `r₃ ↦ -r₃`
  have ex : liftRest hx (A r₂ r₃) = A r₂ r₃ := by
    rw [hE _ properStab_hx r₂ r₃]
    simp only [restOf_liftRest, hx_r₂, hx_r₃, map_neg, LinearMap.neg_apply, neg_neg]
  have c0 : (A r₂ r₃).1 = -(A r₂ r₃).1 := congrArg (fun Z : Vec4 => Z.1) ez
  have c3 : (A r₂ r₃).2.2.2 = -(A r₂ r₃).2.2.2 := congrArg (fun Z : Vec4 => Z.2.2.2) ez
  have c2 : -(A r₂ r₃).2.2.1 = (A r₂ r₃).2.2.1 := congrArg (fun Z : Vec4 => Z.2.2.1) ex
  apply vec4_ext <;> simp only [sp, s₁, Prod.smul_fst, Prod.smul_snd, smul_eq_mul,
    mul_zero, mul_one] <;> linarith

/-! ## Step 2: the value on `(r₃, r₁)` -/

/-- **RIGIDITY RESULT.**  The quarter-turn about the third rest direction
transports the previous value: the value on `(r₃, r₁)` is the **same** multiple
of `sp r₂`. -/
theorem rigidity_r₃r₁ : A r₃ r₁ = ((A r₂ r₃).2.1) • sp r₂ := by
  have hq := hE _ properStab_qz r₂ r₃
  simp only [restOf_liftRest, qz_r₂, qz_r₃, map_neg, LinearMap.neg_apply] at hq
  rw [rigidity_r₂r₃ hE, map_smul] at hq
  have himg : liftRest qz (sp r₁) = sp r₂ := by
    apply vec4_ext <;> simp [sp, s₁, s₂]
  rw [himg, alternating_antisymm hA r₁ r₃, neg_neg] at hq
  exact hq.symm

/-! ## Step 3: the value on `(r₁, r₂)` -/

/-- **RIGIDITY RESULT.**  The quarter-turn about the first rest direction gives
the third value, again with the same coefficient. -/
theorem rigidity_r₁r₂ : A r₁ r₂ = ((A r₂ r₃).2.1) • sp r₃ := by
  have hq := hE _ properStab_qx r₃ r₁
  simp only [restOf_liftRest, qx_r₃, qx_r₁, map_neg, LinearMap.neg_apply] at hq
  rw [rigidity_r₃r₁ hA hE, map_smul] at hq
  have himg : liftRest qx (sp r₂) = sp r₃ := by
    apply vec4_ext <;> simp [sp, s₂, s₃]
  rw [himg, alternating_antisymm hA r₂ r₁, neg_neg] at hq
  exact hq.symm

/-! ## The basis-pair determination theorem -/

/-- **BASIS-PAIR RIGIDITY (the exact upper bound).**  For an arbitrary
alternating, proper-equivariant defect there is exactly one free real number
`c`; every basis-pair value is forced by it, no temporal component survives, and
no further independent value remains. -/
theorem rigidity_basis_pairs :
    ∃ c : ℝ, A r₂ r₃ = c • sp r₁ ∧ A r₃ r₁ = c • sp r₂ ∧ A r₁ r₂ = c • sp r₃ :=
  ⟨(A r₂ r₃).2.1, rigidity_r₂r₃ hE, rigidity_r₃r₁ hA hE, rigidity_r₁r₂ hA hE⟩

/-- **DERIVED, not assumed.**  The temporal output component of a
proper-equivariant alternating defect vanishes identically. -/
theorem rigidity_temporal_zero (v w : Vec3) : tempPart A v w = 0 := by
  have h := alternating_expand hA v w
  rw [rigidity_r₁r₂ hA hE, rigidity_r₂r₃ hE, rigidity_r₃r₁ hA hE] at h
  have := congrArg (fun Z : Vec4 => Z.1) h
  simpa [tempPart, sp, s₁, s₂, s₃] using this

/-- Equivalently: the defect takes its values in the rest space. -/
theorem rigidity_values_in_rest (v w : Vec3) : A v w ∈ Rest := by
  rw [mem_Rest]
  exact rigidity_temporal_zero hA hE v w

end

/-! ## Uniqueness given the parameter -/

/-- **RIGIDITY RESULT (uniqueness).**  Two alternating proper-equivariant
defects whose parameters agree are equal.  Hence the solution space injects into
`ℝ`; this bound is proved *before* any nonzero solution is known to exist. -/
theorem rigidity_unique {A B : RestDefect} (hA : Alternating A) (hEA : ProperEquivariant A)
    (hB : Alternating B) (hEB : ProperEquivariant B)
    (hc : (A r₂ r₃).2.1 = (B r₂ r₃).2.1) : A = B := by
  refine alternating_ext hA hB ?_ ?_ ?_
  · rw [rigidity_r₁r₂ hA hEA, rigidity_r₁r₂ hB hEB, hc]
  · rw [rigidity_r₂r₃ hEA, rigidity_r₂r₃ hEB, hc]
  · rw [rigidity_r₃r₁ hA hEA, rigidity_r₃r₁ hB hEB, hc]

/-- **RIGIDITY RESULT (zero parameter forces the zero defect).** -/
theorem rigidity_eq_zero_of_param_zero {A : RestDefect} (hA : Alternating A)
    (hE : ProperEquivariant A) (hc : (A r₂ r₃).2.1 = 0) : A = 0 := by
  refine alternating_eq_zero_of_basis hA ?_ ?_ ?_
  · rw [rigidity_r₁r₂ hA hE, hc, zero_smul]
  · rw [rigidity_r₂r₃ hE, hc, zero_smul]
  · rw [rigidity_r₃r₁ hA hE, hc, zero_smul]

end NullSectorTask06
