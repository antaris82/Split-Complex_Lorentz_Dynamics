import RequestProject.NullSectorTask06.Identification
import RequestProject.NullSectorTask04.ProperIsotropy

/-!
# Task 06, Layer 9: late comparison with Task 04 — **COMPARISON ONLY**

This is the **only** Task-06 module that imports the formerly contaminated
Task-04 proper-isotropy/identification layer.  No earlier Task-06 module imports
it, and nothing proved here is used anywhere else.  Task 04 is treated as a
comparison target, not as an oracle: the Task-06 classification was completed
and compiled before this file was written, and it is not adjusted here.

The comparison is exact:

* the two orientation criteria agree (`det3` of Task 06 equals `det3` of
  Task 04, hence the two proper-isotropy groups are literally the same set of
  transformations, and the two equivariance predicates coincide);
* the two forced symmetric branches agree;
* the independently reconstructed alternating witness equals the Task-04
  witness;
* the two one-parameter families of products agree parameter by parameter;
* consequently the two reported solution spaces are the same.
-/

namespace NullSectorTask06

open NullSectorTask01 NullSectorTask04

/-! ## The orientation criteria agree -/

theorem det3_eq_task04 (a b c : Vec3) :
    NullSectorTask06.det3 a b c = NullSectorTask04.det3 a b c := by
  simp [NullSectorTask06.det3, NullSectorTask04.det3, dot3]; ring

theorem detRest_eq_task04 (R : Vec4 ≃ₗ[ℝ] Vec4) :
    NullSectorTask06.detRest R = NullSectorTask04.detRest R := by
  rw [NullSectorTask06.detRest, NullSectorTask04.detRest, det3_eq_task04]
  rfl

theorem stab_iff_task04 (R : Vec4 ≃ₗ[ℝ] Vec4) :
    NullSectorTask06.Stab R ↔ NullSectorTask04.Stabilizer R := Iff.rfl

theorem properStab_iff_task04 (R : Vec4 ≃ₗ[ℝ] Vec4) :
    NullSectorTask06.ProperStab R ↔ NullSectorTask04.ProperStabilizer R := by
  rw [NullSectorTask06.ProperStab, NullSectorTask04.ProperStabilizer, detRest_eq_task04]
  exact Iff.rfl

theorem properEquivariantProd_iff_task04 (M : BiProd4) :
    ProperEquivariantProd M ↔ NullSectorTask04.ProperIsotropyEquivariant M := by
  constructor
  · intro hE R hR
    exact hE R ((properStab_iff_task04 R).2 hR)
  · intro hE R hR
    exact hE R ((properStab_iff_task04 R).1 hR)

/-! ## The forced symmetric branches agree -/

theorem symForced_eq_task04 : symForced = NullSectorTask04.mu4sym := by
  apply LinearMap.ext; intro X; apply LinearMap.ext; intro Y
  rfl

/-! ## The witnesses agree -/

/-- **COMPARISON ONLY.**  The independently reconstructed witness is exactly the
Task-04 alternating witness. -/
theorem witDefect_eq_task04 : witDefect = NullSectorTask04.altBasis := by
  apply LinearMap.ext; intro v; apply LinearMap.ext; intro w
  rw [witDefect_apply, NullSectorTask04.altBasis_apply]
  apply vec4_ext <;> simp [sp]

/-! ## The families of products agree -/

theorem glueFam_eq_task04 (c : ℝ) : glueFam c = NullSectorTask04.muFam c := by
  rw [glueFam, NullSectorTask04.muFam, witDefect_eq_task04]
  apply LinearMap.ext; intro X; apply LinearMap.ext; intro Y
  rw [extensionFromDefect_apply, NullSectorTask04.muOf_apply, symForced_eq_task04]

/-! ## The replication verdict -/

/-- **REPLICATED.**  The clean-room Task-06 classification of
proper-isotropy-equivariant sector-compatible products and the Task-04 result
are the same theorem: the two symmetry groups coincide, the two solution spaces
coincide, and the two one-parameter families coincide term by term. -/
theorem task06_replicates_task04 (M : BiProd4) :
    ((SectorCompatible M ∧ ProperEquivariantProd M) ↔ ∃ c : ℝ, M = glueFam c) ∧
      ((SectorCompatible M ∧ NullSectorTask04.ProperIsotropyEquivariant M) ↔
        ∃ c : ℝ, M = NullSectorTask04.muFam c) ∧
      (∀ c : ℝ, glueFam c = NullSectorTask04.muFam c) ∧
      (ProperEquivariantProd M ↔ NullSectorTask04.ProperIsotropyEquivariant M) := by
  refine ⟨sectorCompatible_properEquivariant_iff M,
    NullSectorTask04.sectorCompatible_properIsotropy_classification M,
    glueFam_eq_task04, properEquivariantProd_iff_task04 M⟩

/-- **REPLICATED.**  Orientation reversal acts by `c ↦ -c` in both developments:
the Task-06 statement is about the defect, the Task-04 statement about the
product, and the underlying families are identified above. -/
theorem orientation_reversal_agrees (c : ℝ) :
    reverseDefect (c • witDefect) = (-c) • witDefect ∧
      (∀ X Y : Vec4, NullSectorTask04.liftRest NullSectorTask04.fz
        (NullSectorTask04.muFam c X Y) =
          NullSectorTask04.muFam (-c) (NullSectorTask04.liftRest NullSectorTask04.fz X)
            (NullSectorTask04.liftRest NullSectorTask04.fz Y)) :=
  ⟨reverseDefect_smul_witDefect c, NullSectorTask04.muFam_orientation_reversal c⟩

/-- **REPLICATED.**  The full-isotropy verdicts agree: in both developments only
the forced symmetric branch survives. -/
theorem full_isotropy_agrees (M : BiProd4) :
    ((SectorCompatible M ∧ IsotropyEquivariantProd M) ↔ M = symForced) ∧
      ((SectorCompatible M ∧ NullSectorTask04.IsotropyEquivariant M) ↔
        M = NullSectorTask04.mu4sym) ∧
      symForced = NullSectorTask04.mu4sym :=
  ⟨sectorCompatible_fullEquivariant_iff M,
   NullSectorTask04.sectorCompatible_isotropy_unique M, symForced_eq_task04⟩

end NullSectorTask06
