import RequestProject.NullSectorTask06.Existence

/-!
# Task 06, Layer 6: the exact solution space and its coordinate formula

Combining

* the **upper bound** of `Task06.Rigidity` (an alternating proper-equivariant
  defect is determined by one real number, and its temporal component vanishes),
  and
* the **existence witness** of `Task06.Existence`,

gives the exact structure of

```
{ A | Alternating A ∧ ProperEquivariant A }.
```

It is a one-dimensional real vector space: `FINITE-DIMENSIONAL`, of dimension
exactly `1`, with `CONTINUOUS FREEDOM` given by a single real scalar.  The
coordinate formula for its elements is derived here — after the classification —
from the basis-pair values plus bilinearity and alternation.
-/

namespace NullSectorTask06

open NullSectorTask01 NullSectorTask04

/-! ## The exact classification of defects -/

/-- **EXACT SOLUTION-SPACE THEOREM.**  An alternating defect is proper
equivariant if and only if it is a real multiple of the witness. -/
theorem properEquivariant_iff (A : RestDefect) :
    (Alternating A ∧ ProperEquivariant A) ↔ ∃ c : ℝ, A = c • witDefect := by
  constructor
  · rintro ⟨hA, hE⟩
    refine ⟨(A r₂ r₃).2.1, ?_⟩
    refine rigidity_unique hA hE (smul_witDefect_alternating _)
      (smul_witDefect_properEquivariant _) ?_
    rw [smul_witDefect_param]
  · rintro ⟨c, rfl⟩
    exact ⟨smul_witDefect_alternating c, smul_witDefect_properEquivariant c⟩

/-- The parameterization by the scalar is injective: the freedom is exactly one
real parameter, and it is `NON-UNIQUE` in the sense that distinct scalars give
distinct defects. -/
theorem smul_witDefect_injective : Function.Injective (fun c : ℝ => c • witDefect) := by
  intro a b hab
  have h := congrArg (fun A : RestDefect => (A r₂ r₃).2.1) hab
  simpa only [smul_witDefect_param] using h

/-! ## The solution space as a submodule -/

/-- The solution space of the clean-room classification problem. -/
def ProperSolutions : Submodule ℝ RestDefect where
  carrier := {A | Alternating A ∧ ProperEquivariant A}
  add_mem' := by
    rintro A B ⟨hA, hEA⟩ ⟨hB, hEB⟩
    refine ⟨fun v => by simp [hA v, hB v], fun R hR v w => ?_⟩
    simp only [LinearMap.add_apply, map_add, hEA R hR v w, hEB R hR v w]
  zero_mem' := ⟨alternating_zero, properEquivariant_zero⟩
  smul_mem' := by
    rintro c A ⟨hA, hEA⟩
    refine ⟨fun v => by simp [hA v], fun R hR v w => ?_⟩
    simp only [LinearMap.smul_apply, map_smul, hEA R hR v w]

@[simp] theorem mem_properSolutions (A : RestDefect) :
    A ∈ ProperSolutions ↔ Alternating A ∧ ProperEquivariant A := Iff.rfl

/-- **EXACT SOLUTION SPACE.**  The solution space is the line spanned by the
witness. -/
theorem properSolutions_eq_span : ProperSolutions = (ℝ ∙ witDefect) := by
  apply le_antisymm
  · rintro A ⟨hA, hE⟩
    obtain ⟨c, hc⟩ := (properEquivariant_iff A).1 ⟨hA, hE⟩
    exact Submodule.mem_span_singleton.2 ⟨c, hc.symm⟩
  · rw [Submodule.span_le, Set.singleton_subset_iff]
    exact ⟨witDefect_alternating, witDefect_properEquivariant⟩

/-- **FINITE-DIMENSIONAL, of dimension exactly one.**  An explicit linear
isomorphism between the real line and the solution space: the scalar `c` is the
only datum, and it is recovered from a solution as `(A r₂ r₃).2.1`. -/
noncomputable def properSolutionsEquiv : ℝ ≃ₗ[ℝ] ProperSolutions where
  toFun c := ⟨c • witDefect, smul_witDefect_alternating c, smul_witDefect_properEquivariant c⟩
  invFun A := ((A : RestDefect) r₂ r₃).2.1
  map_add' a b := by
    apply Subtype.ext
    simp only [Submodule.coe_add, add_smul]
  map_smul' a b := by
    apply Subtype.ext
    simp only [Submodule.coe_smul, smul_smul, RingHom.id_apply, smul_eq_mul]
  left_inv c := by simp only [smul_witDefect_param]
  right_inv A := by
    apply Subtype.ext
    obtain ⟨hA, hE⟩ := A.2
    obtain ⟨c, hc⟩ := (properEquivariant_iff (A : RestDefect)).1 ⟨hA, hE⟩
    show (((A : RestDefect) r₂ r₃).2.1) • witDefect = (A : RestDefect)
    have hpar : ((A : RestDefect) r₂ r₃).2.1 = c := by rw [hc]; simp [s₂, s₃]
    rw [hpar, hc]

/-- The solution space is not the zero space. -/
theorem properSolutions_ne_bot : ProperSolutions ≠ ⊥ := by
  intro hcon
  have hmem : witDefect ∈ ProperSolutions :=
    ⟨witDefect_alternating, witDefect_properEquivariant⟩
  rw [hcon, Submodule.mem_bot] at hmem
  exact witDefect_ne_zero hmem

/-! ## The coordinate formula, derived after the classification -/

/-- **DERIVED COORDINATE FORMULA.**  Consequence of the basis-pair
classification, bilinearity and alternation: exactly one scalar coefficient
survives, and the coordinate expression of every proper-equivariant alternating
defect is the following. -/
theorem properEquivariant_coordinate_formula {A : RestDefect} (hA : Alternating A)
    (hE : ProperEquivariant A) (v w : Vec3) :
    A v w = ((A r₂ r₃).2.1) • ((0 : ℝ), v.2.1 * w.2.2 - v.2.2 * w.2.1,
      v.2.2 * w.1 - v.1 * w.2.2, v.1 * w.2.1 - v.2.1 * w.1) := by
  obtain ⟨c, hc⟩ := (properEquivariant_iff A).1 ⟨hA, hE⟩
  have hpar : (A r₂ r₃).2.1 = c := by rw [hc]; simp [s₂, s₃]
  rw [hpar, hc]
  simp only [LinearMap.smul_apply, witDefect_apply, wit3_apply, sp]

/-! ## The corresponding family of global products -/

/-- The one-parameter family of sector-compatible, proper-equivariant products. -/
noncomputable def glueFam (c : ℝ) : BiProd4 := extensionFromDefect (c • witDefect)

@[simp] theorem glueFam_apply (c : ℝ) (X Y : Vec4) :
    glueFam c X Y = symForced X Y + c • sp (wit3 X.2 Y.2) := rfl

theorem glueFam_zero : glueFam 0 = symForced := by
  rw [glueFam, zero_smul, extensionFromDefect_zero]

theorem glueFam_injective : Function.Injective glueFam := by
  intro a b hab
  have := defect_unique (A := a • witDefect) (B := b • witDefect) hab
  exact smul_witDefect_injective this

/-- **EXACT CLASSIFICATION AT THE LEVEL OF PRODUCTS.**  A bilinear product is
sector compatible and equivariant under the orientation-preserving isotropy of
`e₀` if and only if it belongs to the one-real-parameter family `glueFam`. -/
theorem sectorCompatible_properEquivariant_iff (M : BiProd4) :
    (SectorCompatible M ∧ ProperEquivariantProd M) ↔ ∃ c : ℝ, M = glueFam c := by
  constructor
  · rintro ⟨hM, hE⟩
    obtain ⟨c, hc⟩ := (properEquivariant_iff (defectOfProd M)).1
      ⟨defectOfProd_alternating hM, properEquivariant_of_prod hE⟩
    refine ⟨c, ?_⟩
    rw [glueFam]
    conv_lhs => rw [eq_extensionFromDefect hM, hc]
  · rintro ⟨c, rfl⟩
    exact ⟨extensionFromDefect_sectorCompatible (smul_witDefect_alternating c),
      properEquivariantProd_extensionFromDefect (smul_witDefect_properEquivariant c)⟩

end NullSectorTask06
