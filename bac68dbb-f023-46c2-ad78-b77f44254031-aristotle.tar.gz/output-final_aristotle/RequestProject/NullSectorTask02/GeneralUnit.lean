import RequestProject.NullSectorTask02.FixedUnit

/-!
# Task 02, Layer 5: arbitrary unit vectors

For a *generic* `e : Long` we resolve

* the exact relation between `Q2 e = 1` and `∃ μ, AdmissibleAt e μ`;
* uniqueness of the admissible product at a fixed `e`;
* the coordinate-free expression of that product in terms of the polarization
  `L2` and `e` — obtained as the **output** of the existence/uniqueness analysis;
* the non-uniqueness of "future normalized" vectors.
-/

namespace NullSectorTask02

open NullSectorTask01

/-- The `Q2`-orthogonal companion of `e`, `f e := (e.2, e.1)`. -/
def compl (e : Long) : Long := (e.2, e.1)

@[simp] theorem compl_fst (e : Long) : (compl e).1 = e.2 := rfl
@[simp] theorem compl_snd (e : Long) : (compl e).2 = e.1 := rfl

theorem Q2_compl (e : Long) : Q2 (compl e) = - Q2 e := by simp [Q2, compl]

theorem L2_compl (e : Long) : L2 e (compl e) = 0 := by simp [compl]; ring

/-- Decomposition of an arbitrary vector in the basis `(e, compl e)`, valid whenever
`Q2 e = 1`. -/
theorem ec_decomp {e : Long} (hQ : Q2 e = 1) (X : Long) :
    X = (L2 X e) • e - (L2 X (compl e)) • compl e := by
  simp [Q2] at hQ
  apply Prod.ext
  · simp [compl]; linear_combination (-X.1) * hQ
  · simp [compl]; linear_combination (-X.2) * hQ

/-!
### Existence
-/

/-- Candidate product attached to a vector `e`; its coordinate-free description is
`recAt e X Y = L2 X e • Y + L2 Y e • X - L2 X Y • e` (see `recAt_eq`). -/
noncomputable def recAt (e : Long) : BiProd :=
  LinearMap.mk₂ ℝ
    (fun X Y => (((X.1 * e.1 - X.2 * e.2) * Y.1 + (Y.1 * e.1 - Y.2 * e.2) * X.1
        - (X.1 * Y.1 - X.2 * Y.2) * e.1 : ℝ),
      ((X.1 * e.1 - X.2 * e.2) * Y.2 + (Y.1 * e.1 - Y.2 * e.2) * X.2
        - (X.1 * Y.1 - X.2 * Y.2) * e.2 : ℝ)))
    (by intro X₁ X₂ Y; apply Prod.ext <;> simp <;> ring)
    (by intro c X Y; apply Prod.ext <;> simp <;> ring)
    (by intro X Y₁ Y₂; apply Prod.ext <;> simp <;> ring)
    (by intro c X Y; apply Prod.ext <;> simp <;> ring)

@[simp] theorem recAt_apply (e X Y : Long) :
    recAt e X Y = ((X.1 * e.1 - X.2 * e.2) * Y.1 + (Y.1 * e.1 - Y.2 * e.2) * X.1
        - (X.1 * Y.1 - X.2 * Y.2) * e.1,
      (X.1 * e.1 - X.2 * e.2) * Y.2 + (Y.1 * e.1 - Y.2 * e.2) * X.2
        - (X.1 * Y.1 - X.2 * Y.2) * e.2) := rfl

/-- Coordinate-free form of the candidate product. -/
theorem recAt_eq (e X Y : Long) :
    recAt e X Y = (L2 X e) • Y + (L2 Y e) • X - (L2 X Y) • e := by
  apply Prod.ext <;> simp

/-- **Existence.**  `Q2 e = 1` suffices for an admissible product with unit `e`. -/
theorem recAt_admissible {e : Long} (hQ : Q2 e = 1) : AdmissibleAt e (recAt e) := by
  simp [Q2] at hQ
  refine ⟨⟨?_, ?_⟩, ?_⟩
  · intro X
    apply Prod.ext
    · simp; linear_combination X.1 * hQ
    · simp; linear_combination X.2 * hQ
  · intro X
    apply Prod.ext
    · simp; linear_combination X.1 * hQ
    · simp; linear_combination X.2 * hQ
  · intro X Y
    simp [Q2]
    linear_combination (X.1 ^ 2 * Y.1 ^ 2 - X.1 ^ 2 * Y.2 ^ 2 - X.2 ^ 2 * Y.1 ^ 2
      + X.2 ^ 2 * Y.2 ^ 2) * hQ

/-!
### Uniqueness at a fixed `e`
-/

section FixedGeneralUnit

variable {μ : BiProd} {e : Long} (h : AdmissibleAt e μ)

include h

/-- Expansion of an admissible product in the basis `(e, compl e)`. -/
theorem ec_expand (X Y : Long) :
    μ X Y = (L2 X e * L2 Y e) • e - (L2 X e * L2 Y (compl e)) • compl e
      - (L2 X (compl e) * L2 Y e) • compl e
      + (L2 X (compl e) * L2 Y (compl e)) • μ (compl e) (compl e) := by
  have hQ : Q2 e = 1 := Q2_unit_eq_one h
  have hl : ∀ Z, μ e Z = Z := h.1.1
  have hr : ∀ Z, μ Z e = Z := h.1.2
  conv_lhs => rw [ec_decomp hQ X, ec_decomp hQ Y]
  simp only [map_sub, map_smul, LinearMap.sub_apply, LinearMap.smul_apply, hl, hr,
    smul_sub, smul_smul]
  module

/-- **Derived square relation for a general unit.** -/
theorem mu_compl_sq : μ (compl e) (compl e) = e := by
  have hQ : Q2 e = 1 := Q2_unit_eq_one h
  have hl : ∀ Z, μ e Z = Z := h.1.1
  have hr : ∀ Z, μ Z e = Z := h.1.2
  have hA : Q2 (μ (compl e) (compl e)) = Q2 (compl e) * Q2 (compl e) := h.2 _ _
  have hC : Q2 (μ (e + compl e) (e - compl e))
      = Q2 (e + compl e) * Q2 (e - compl e) := h.2 _ _
  have hprod : μ (e + compl e) (e - compl e) = e - μ (compl e) (compl e) := by
    simp only [map_add, map_sub, LinearMap.add_apply, hl, hr]
    abel
  rw [hprod] at hC
  rw [Q2_compl, hQ] at hA
  rcases hw : μ (compl e) (compl e) with ⟨w1, w2⟩
  rw [hw] at hA hC
  obtain ⟨c, s⟩ := e
  simp [Q2, compl] at hQ hA hC ⊢
  have hp : w1 * c - w2 * s = 1 := by nlinarith [hQ, hA, hC]
  have h0 : (w2 * c - w1 * s) ^ 2 = 0 := by nlinarith [hQ, hA, hp]
  have hq : w2 * c - w1 * s = 0 := sq_eq_zero_iff.mp h0
  constructor
  · linear_combination c * hp + s * hq - w1 * hQ
  · linear_combination s * hp + c * hq - w2 * hQ

/-- **Uniqueness at a fixed unit, in coordinate-free form.**  Any admissible product
with unit `e` is given by the polarization formula. -/
theorem generalUnit_formula (X Y : Long) :
    μ X Y = (L2 X e) • Y + (L2 Y e) • X - (L2 X Y) • e := by
  have hQ : Q2 e = 1 := Q2_unit_eq_one h
  rw [ec_expand h, mu_compl_sq h]
  obtain ⟨c, s⟩ := e
  simp [Q2] at hQ
  apply Prod.ext
  · simp [compl]
    linear_combination (X.1 * Y.1 * c - X.1 * Y.2 * s - X.2 * Y.1 * s + X.2 * Y.2 * c) * hQ
  · simp [compl]
    linear_combination (-(X.1 * Y.1 * s) + X.1 * Y.2 * c + X.2 * Y.1 * c - X.2 * Y.2 * s) * hQ

theorem eq_recAt : μ = recAt e := by
  apply LinearMap.ext; intro X; apply LinearMap.ext; intro Y
  rw [generalUnit_formula h, recAt_eq]

end FixedGeneralUnit

/-- **Existence ↔ normalization.**  An admissible product with unit `e` exists exactly
when `Q2 e = 1`. -/
theorem exists_admissible_iff (e : Long) : (∃ μ : BiProd, AdmissibleAt e μ) ↔ Q2 e = 1 :=
  ⟨fun ⟨_, h⟩ => Q2_unit_eq_one h, fun hQ => ⟨recAt e, recAt_admissible hQ⟩⟩

/-- **Existence and uniqueness for a normalized unit.** -/
theorem generalUnit_existsUnique {e : Long} (hQ : Q2 e = 1) : ∃! μ : BiProd, AdmissibleAt e μ :=
  ⟨recAt e, recAt_admissible hQ, fun _ h => eq_recAt h⟩

/-- Two products admissible at *different* units are different. -/
theorem admissible_units_determine {μ ν : BiProd} {e e' : Long}
    (h : AdmissibleAt e μ) (h' : AdmissibleAt e' ν) (hne : e ≠ e') : μ ≠ ν := by
  intro hcon
  subst hcon
  exact hne (twoSidedUnit_unique h.1 h'.1)

/-!
### Future normalized vectors
-/

/-- Neutral definition: a vector with positive first coordinate and `Q2 = 1`. -/
def FutureUnit (e : Long) : Prop := e.1 > 0 ∧ Q2 e = 1

theorem futureUnit_u₀ : FutureUnit u₀ := ⟨by norm_num [u₀], Q2_u₀⟩

theorem futureUnit_other : FutureUnit ((5 / 4 : ℝ), (3 / 4 : ℝ)) := by
  constructor
  · norm_num
  · norm_num [Q2]

/-- **PROVED NON-UNIQUE.**  `Q2` together with the sign of the first coordinate does
*not* single out a normalized vector. -/
theorem futureUnit_not_unique :
    ∃ e e' : Long, FutureUnit e ∧ FutureUnit e' ∧ e ≠ e' := by
  refine ⟨u₀, ((5 / 4 : ℝ), (3 / 4 : ℝ)), futureUnit_u₀, futureUnit_other, ?_⟩
  intro hcon
  have : (u₀.1 : ℝ) = 5 / 4 := by rw [hcon]
  norm_num [u₀] at this

/-- **No intrinsic selection.**  There are at least two admissible products whose units
are future normalized vectors; so `Q2` plus the future component does not determine a
product. -/
theorem admissible_product_not_intrinsic :
    ∃ (e e' : Long) (μ ν : BiProd),
      FutureUnit e ∧ FutureUnit e' ∧ AdmissibleAt e μ ∧ AdmissibleAt e' ν ∧ μ ≠ ν := by
  obtain ⟨e, e', he, he', hne⟩ := futureUnit_not_unique
  exact ⟨e, e', recAt e, recAt e', he, he', recAt_admissible he.2, recAt_admissible he'.2,
    admissible_units_determine (recAt_admissible he.2) (recAt_admissible he'.2) hne⟩

end NullSectorTask02
