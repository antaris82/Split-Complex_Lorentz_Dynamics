import RequestProject.NullSectorTask02.GeneralUnit

/-!
# Task 02, Layer 6: canonicality made testable

A concrete *rational* `Q2`-preserving linear equivalence `Tsym` is constructed from
`Long` and `Q2` alone (no analytic structure, no Task-01 boost).  It preserves the
closed future cone and the set of future normalized vectors, and it has no nonzero
fixed vector.

Consequences:

* no future normalized vector is invariant, so `Q2` plus the future component does
  not intrinsically determine the unit `u₀`;
* **no admissible product is equivariant** under `Tsym`: a concrete obstruction.
-/

namespace NullSectorTask02

open NullSectorTask01

/-- The underlying linear map of the rational symmetry. -/
noncomputable def TsymMap : Long →ₗ[ℝ] Long where
  toFun X := ((5 / 4 : ℝ) * X.1 + (3 / 4 : ℝ) * X.2, (3 / 4 : ℝ) * X.1 + (5 / 4 : ℝ) * X.2)
  map_add' := by intro X Y; apply Prod.ext <;> simp <;> ring
  map_smul' := by intro c X; apply Prod.ext <;> simp <;> ring

/-- The inverse linear map. -/
noncomputable def TsymInv : Long →ₗ[ℝ] Long where
  toFun X := ((5 / 4 : ℝ) * X.1 - (3 / 4 : ℝ) * X.2, -(3 / 4 : ℝ) * X.1 + (5 / 4 : ℝ) * X.2)
  map_add' := by intro X Y; apply Prod.ext <;> simp <;> ring
  map_smul' := by intro c X; apply Prod.ext <;> simp <;> ring

@[simp] theorem TsymMap_apply (X : Long) :
    TsymMap X = ((5 / 4 : ℝ) * X.1 + (3 / 4 : ℝ) * X.2,
      (3 / 4 : ℝ) * X.1 + (5 / 4 : ℝ) * X.2) := rfl

@[simp] theorem TsymInv_apply (X : Long) :
    TsymInv X = ((5 / 4 : ℝ) * X.1 - (3 / 4 : ℝ) * X.2,
      -(3 / 4 : ℝ) * X.1 + (5 / 4 : ℝ) * X.2) := rfl

/-- An explicit non-identity real-linear equivalence of `Long`. -/
noncomputable def Tsym : Long ≃ₗ[ℝ] Long :=
  LinearEquiv.ofLinear TsymMap TsymInv
    (by apply LinearMap.ext; intro X; apply Prod.ext <;> simp <;> ring)
    (by apply LinearMap.ext; intro X; apply Prod.ext <;> simp <;> ring)

@[simp] theorem Tsym_apply (X : Long) :
    Tsym X = ((5 / 4 : ℝ) * X.1 + (3 / 4 : ℝ) * X.2,
      (3 / 4 : ℝ) * X.1 + (5 / 4 : ℝ) * X.2) := rfl

/-- `Tsym` preserves the quadratic form. -/
theorem Tsym_Q2 (X : Long) : Q2 (Tsym X) = Q2 X := by simp [Q2]; ring

/-- `Tsym` preserves the closed future cone `{X | 0 ≤ X.1 ∧ 0 ≤ Q2 X}`. -/
theorem Tsym_future_cone {X : Long} (h1 : 0 ≤ X.1) (h2 : 0 ≤ Q2 X) :
    0 ≤ (Tsym X).1 ∧ 0 ≤ Q2 (Tsym X) := by
  refine ⟨?_, by rw [Tsym_Q2]; exact h2⟩
  simp only [Tsym_apply]
  simp [Q2] at h2
  nlinarith [h2, h1, sq_nonneg (X.1 - X.2), sq_nonneg (X.1 + X.2)]

/-- `Tsym` preserves the set of future normalized vectors. -/
theorem Tsym_futureUnit {e : Long} (h : FutureUnit e) : FutureUnit (Tsym e) := by
  obtain ⟨h1, h2⟩ := h
  refine ⟨?_, by rw [Tsym_Q2]; exact h2⟩
  have := (Tsym_future_cone (le_of_lt h1) (by rw [h2]; norm_num)).1
  simp only [Tsym_apply] at this ⊢
  simp [Q2] at h2
  nlinarith [h1, h2]

/-- `Tsym` is not the identity. -/
theorem Tsym_ne_id : Tsym u₀ ≠ u₀ := by
  intro hcon
  have : (Tsym u₀).1 = (u₀ : Long).1 := by rw [hcon]
  norm_num [u₀] at this

/-- `Tsym` has no nonzero fixed vector. -/
theorem Tsym_no_fixed_point {X : Long} (h : Tsym X = X) : X = 0 := by
  have h1 : (Tsym X).1 = X.1 := by rw [h]
  have h2 : (Tsym X).2 = X.2 := by rw [h]
  simp only [Tsym_apply] at h1 h2
  apply Prod.ext <;> simp <;> linarith

/-- Equivariance of a bilinear product under a linear equivalence. -/
def Equivariant (T : Long ≃ₗ[ℝ] Long) (μ : BiProd) : Prop :=
  ∀ X Y, T (μ X Y) = μ (T X) (T Y)

/-- If a product is equivariant under `T`, then `T` maps a two-sided unit to a
two-sided unit. -/
theorem unit_map_of_equivariant {T : Long ≃ₗ[ℝ] Long} {μ : BiProd} {e : Long}
    (heq : Equivariant T μ) (hu : TwoSidedUnit μ e) : TwoSidedUnit μ (T e) := by
  constructor
  · intro Z
    obtain ⟨W, hW⟩ : ∃ W, T W = Z := ⟨T.symm Z, by simp⟩
    rw [← hW, ← heq e W, hu.1 W]
  · intro Z
    obtain ⟨W, hW⟩ : ∃ W, T W = Z := ⟨T.symm Z, by simp⟩
    rw [← hW, ← heq W e, hu.2 W]

/-- **Concrete obstruction.**  No admissible unital product is equivariant under the
explicit symmetry `Tsym`: the Lorentz data alone cannot select the product. -/
theorem no_equivariant_admissible :
    ¬ ∃ (e : Long) (μ : BiProd), AdmissibleAt e μ ∧ Equivariant Tsym μ := by
  rintro ⟨e, μ, hadm, heq⟩
  have hu : TwoSidedUnit μ (Tsym e) := unit_map_of_equivariant heq hadm.1
  have hfix : Tsym e = e := twoSidedUnit_unique hu hadm.1
  have he0 : e = 0 := Tsym_no_fixed_point hfix
  have := Q2_unit_eq_one hadm
  rw [he0] at this
  simp [Q2] at this

/-- Equivalently: for every `e`, the unique candidate product at `e` fails to be
equivariant under `Tsym`. -/
theorem recAt_not_equivariant {e : Long} (hQ : Q2 e = 1) : ¬ Equivariant Tsym (recAt e) :=
  fun heq => no_equivariant_admissible ⟨e, recAt e, recAt_admissible hQ, heq⟩

/-!
### Coordinate availability versus intrinsic determination
-/

/-- **Coordinate-level availability.**  In the chosen coordinate representation the
vector `u₀ = (1,0)` can simply be written down, and it is future normalized. -/
theorem u₀_available : FutureUnit u₀ := futureUnit_u₀

/-- **Intrinsic determination fails.**  No future normalized vector is fixed by the
`Q2`-preserving, future-preserving symmetry `Tsym`; hence `Q2` together with the
future component does not determine a unit. -/
theorem no_invariant_futureUnit :
    ∀ e : Long, FutureUnit e → FutureUnit (Tsym e) ∧ Tsym e ≠ e := by
  intro e he
  refine ⟨Tsym_futureUnit he, ?_⟩
  intro hcon
  have he0 : e = 0 := Tsym_no_fixed_point hcon
  have := he.2
  rw [he0] at this
  simp [Q2] at this

/-- Selecting `u₀` is data over and above `(Long, Q2, future component)`: the chosen
vector is moved by a symmetry of exactly that data. -/
theorem u₀_is_extra_data : FutureUnit u₀ ∧ FutureUnit (Tsym u₀) ∧ Tsym u₀ ≠ u₀ :=
  ⟨futureUnit_u₀, (no_invariant_futureUnit u₀ futureUnit_u₀).1,
    (no_invariant_futureUnit u₀ futureUnit_u₀).2⟩

end NullSectorTask02
