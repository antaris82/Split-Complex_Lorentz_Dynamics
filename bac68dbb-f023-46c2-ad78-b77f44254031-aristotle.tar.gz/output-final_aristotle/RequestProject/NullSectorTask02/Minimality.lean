import RequestProject.NullSectorTask02.FixedUnit

/-!
# Task 02, Layer 4: minimality audit — weakening the unit assumptions

Here the right-unit law is dropped.  A generic bilinear product with

* `LeftUnit μ u₀`,
* `QMultiplicative μ`

is classified completely: there are **exactly two** such products, and they are
distinct.  Re-imposing separately the right-unit law, commutativity, or
associativity kills the second branch in each case, so each of these three
conditions suffices (and none of them is needed twice).
-/

namespace NullSectorTask02

open NullSectorTask01

section LeftOnly

variable {μ : BiProd} (h : LeftAdmissibleAt u₀ μ)

include h

/-- Generic shape of a left-admissible product at `u₀`: two unknown vectors remain. -/
theorem left_shape (X Y : Long) :
    μ X Y = (X.1 * Y.1 + X.2 * Y.1 * (μ s₀ u₀).1 + X.2 * Y.2 * (μ s₀ s₀).1,
             X.1 * Y.2 + X.2 * Y.1 * (μ s₀ u₀).2 + X.2 * Y.2 * (μ s₀ s₀).2) := by
  rw [bilin_expand μ X Y, h.1 u₀, h.1 s₀]
  apply Prod.ext <;> simp [u₀, s₀]

/-- **Complete left-unit classification.**  Exactly two coordinate formulas are
possible; both branches actually occur (see `recU_left_admissible` and
`twistU_left_admissible`). -/
theorem leftAdmissible_dichotomy :
    (∀ X Y : Long, μ X Y = (X.1 * Y.1 + X.2 * Y.2, X.1 * Y.2 + X.2 * Y.1)) ∨
    (∀ X Y : Long, μ X Y = (X.1 * Y.1 - X.2 * Y.2, X.1 * Y.2 - X.2 * Y.1)) := by
  have e1 : Q2 (μ s₀ s₀) = Q2 s₀ * Q2 s₀ := h.2 s₀ s₀
  have e2 : Q2 (μ s₀ u₀) = Q2 s₀ * Q2 u₀ := h.2 s₀ u₀
  have e3 : Q2 (μ (1, 1) u₀) = Q2 ((1, 1) : Long) * Q2 u₀ := h.2 (1, 1) u₀
  have e4 : Q2 (μ (1, 1) s₀) = Q2 ((1, 1) : Long) * Q2 s₀ := h.2 (1, 1) s₀
  have e5 : Q2 (μ (1, 1) (1, 1)) = Q2 ((1, 1) : Long) * Q2 ((1, 1) : Long) := h.2 (1, 1) (1, 1)
  rw [left_shape h] at e3 e4 e5
  rcases hv : μ s₀ u₀ with ⟨v1, v2⟩
  rcases hw : μ s₀ s₀ with ⟨w1, w2⟩
  rw [hv, hw] at e3 e4 e5
  rw [hw] at e1
  rw [hv] at e2
  simp [Q2, s₀, u₀] at e1 e2 e3 e4 e5
  have hw2 : w2 = 0 := by nlinarith [e1, e4]
  have hv1 : v1 = 0 := by nlinarith [e2, e3]
  have hw1 : w1 = 1 ∨ w1 = -1 := by
    have : w1 ^ 2 = 1 := by nlinarith [e1, hw2]
    rcases mul_self_eq_one_iff.1 (by nlinarith : w1 * w1 = 1) with h' | h'
    · exact Or.inl h'
    · exact Or.inr h'
  have hv2 : v2 = w1 := by
    rcases hw1 with h1 | h1 <;> nlinarith [e2, e5, hv1, hw2, h1]
  rcases hw1 with h1 | h1
  · left
    intro X Y
    rw [left_shape h, hv, hw]
    simp [h1, hv1, hv2, hw2]
  · right
    intro X Y
    rw [left_shape h, hv, hw]
    simp [h1, hv1, hv2, hw2]
    constructor <;> ring

end LeftOnly

/-- Second branch of the left-unit classification, as a bilinear map. -/
noncomputable def twistU : BiProd :=
  LinearMap.mk₂ ℝ (fun X Y => ((X.1 * Y.1 - X.2 * Y.2 : ℝ), (X.1 * Y.2 - X.2 * Y.1 : ℝ)))
    (by intro X₁ X₂ Y; apply Prod.ext <;> simp <;> ring)
    (by intro c X Y; apply Prod.ext <;> simp <;> ring)
    (by intro X Y₁ Y₂; apply Prod.ext <;> simp <;> ring)
    (by intro c X Y; apply Prod.ext <;> simp <;> ring)

@[simp] theorem twistU_apply (X Y : Long) :
    twistU X Y = (X.1 * Y.1 - X.2 * Y.2, X.1 * Y.2 - X.2 * Y.1) := rfl

theorem recU_left_admissible : LeftAdmissibleAt u₀ recU := recU_admissible.toLeft

theorem twistU_left_admissible : LeftAdmissibleAt u₀ twistU := by
  refine ⟨?_, ?_⟩
  · intro X; apply Prod.ext <;> simp [u₀]
  · intro X Y; simp [Q2]; ring

/-- The two branches are genuinely distinct products. -/
theorem recU_ne_twistU : recU ≠ twistU := by
  intro hcon
  have : recU s₀ u₀ = twistU s₀ u₀ := by rw [hcon]
  norm_num [s₀, u₀] at this

/-- **PROVED NON-UNIQUE.**  Bilinear + left unit `u₀` + `Q2`-multiplicative admits
exactly two products, and they are different. -/
theorem leftAdmissible_not_unique :
    ∃ μ ν : BiProd, LeftAdmissibleAt u₀ μ ∧ LeftAdmissibleAt u₀ ν ∧ μ ≠ ν :=
  ⟨recU, twistU, recU_left_admissible, twistU_left_admissible, recU_ne_twistU⟩

/-- The second branch has **no** right unit at `u₀`. -/
theorem twistU_not_rightUnit : ¬ RightUnit twistU u₀ := by
  intro hcon
  have := hcon s₀
  norm_num [s₀, u₀] at this

/-- The second branch is **not** commutative. -/
theorem twistU_not_commutative : ¬ Commutative twistU := by
  intro hcon
  have := hcon s₀ u₀
  norm_num [s₀, u₀] at this

/-- The second branch is **not** associative. -/
theorem twistU_not_associative : ¬ Associative twistU := by
  intro hcon
  have := hcon s₀ s₀ s₀
  norm_num [s₀] at this

/-- **Test A.**  Left unit + `Q2`-multiplicative + right unit ⇒ unique. -/
theorem testA_unique {μ : BiProd} (h : LeftAdmissibleAt u₀ μ) (hr : RightUnit μ u₀) :
    μ = recU := by
  apply LinearMap.ext; intro X; apply LinearMap.ext; intro Y
  rcases leftAdmissible_dichotomy h with hb | hb
  · rw [hb, recU_apply]
  · exfalso
    have := hr s₀
    rw [hb] at this
    norm_num [s₀, u₀] at this

/-- **Test B.**  Left unit + `Q2`-multiplicative + commutativity ⇒ unique. -/
theorem testB_unique {μ : BiProd} (h : LeftAdmissibleAt u₀ μ) (hc : Commutative μ) :
    μ = recU := by
  apply LinearMap.ext; intro X; apply LinearMap.ext; intro Y
  rcases leftAdmissible_dichotomy h with hb | hb
  · rw [hb, recU_apply]
  · exfalso
    have := hc s₀ u₀
    rw [hb, hb] at this
    norm_num [s₀, u₀] at this

/-- **Test C.**  Left unit + `Q2`-multiplicative + associativity ⇒ unique. -/
theorem testC_unique {μ : BiProd} (h : LeftAdmissibleAt u₀ μ) (ha : Associative μ) :
    μ = recU := by
  apply LinearMap.ext; intro X; apply LinearMap.ext; intro Y
  rcases leftAdmissible_dichotomy h with hb | hb
  · rw [hb, recU_apply]
  · exfalso
    have h1 := ha s₀ s₀ s₀
    simp only [hb] at h1
    norm_num [s₀] at h1

end NullSectorTask02
