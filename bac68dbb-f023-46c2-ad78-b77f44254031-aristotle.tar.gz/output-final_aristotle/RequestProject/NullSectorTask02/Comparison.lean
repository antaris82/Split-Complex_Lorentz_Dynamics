import RequestProject.NullSectorTask02.Canonicality
import RequestProject.NullSectorTask01.SplitComplex

/-!
# Task 02, Layer 7: late comparison with Task 01

This is the **only** file of the Task-02 development that imports the Task-01
split-complex layer.  Every reconstruction, minimality, and canonicality result
above was proved before this file exists and does not depend on it.

Content:

* the Task-01 product `mulL` is packaged as a bilinear map and shown to satisfy the
  Task-02 admissibility conditions at the Task-01 unit `oneL = u₀`;
* equality with the independently reconstructed product is obtained **from the
  uniqueness theorem**, not by coordinate rewriting;
* the independently defined `pplus`, `pminus` are compared with `ep`, `em`;
* several Task-01 split-complex identities are re-derived as consequences of the
  Task-02 assumptions.
-/

namespace NullSectorTask02

open NullSectorTask01

/-- The Task-01 split-complex product packaged as a bilinear map. -/
noncomputable def mulLBil : BiProd :=
  LinearMap.mk₂ ℝ mulL
    (by intro X₁ X₂ Y; apply Prod.ext <;> simp [mulL] <;> ring)
    (by intro c X Y; apply Prod.ext <;> simp [mulL] <;> ring)
    (by intro X Y₁ Y₂; apply Prod.ext <;> simp [mulL] <;> ring)
    (by intro c X Y; apply Prod.ext <;> simp [mulL] <;> ring)

@[simp] theorem mulLBil_apply (X Y : Long) : mulLBil X Y = mulL X Y := rfl

/-- The Task-01 unit is the Task-02 reference vector. -/
theorem oneL_eq_u₀ : oneL = u₀ := rfl

/-- **Comparison step 1.**  The Task-01 product satisfies the Task-02 admissibility
conditions at the Task-01 unit. -/
theorem mulLBil_admissible : AdmissibleAt u₀ mulLBil := by
  refine ⟨⟨?_, ?_⟩, ?_⟩
  · intro X; simpa [← oneL_eq_u₀] using oneL_mulL X
  · intro X; apply Prod.ext <;> simp [mulL, u₀]
  · intro X Y; simp [Q2, mulL]; ring

/-- **Comparison step 2/3.**  Equality with the independently reconstructed product,
obtained from the Task-02 fixed-unit uniqueness theorem. -/
theorem mulLBil_eq_recU : mulLBil = recU :=
  fixedUnit_unique mulLBil_admissible recU_admissible

/-- Pointwise form of the same statement. -/
theorem mulL_eq_recU (X Y : Long) : mulL X Y = recU X Y := by
  have := congrArg (fun ν : BiProd => ν X Y) mulLBil_eq_recU
  simpa using this

/-- The Task-01 product also coincides with the general-unit reconstruction at `u₀`. -/
theorem mulLBil_eq_recAt_u₀ : mulLBil = recAt u₀ := eq_recAt mulLBil_admissible

/-- **Comparison step 4.**  The independently defined candidate idempotents agree with
the Task-01 idempotents. -/
theorem pplus_eq_ep : pplus = ep := by rw [pplus_coord, ep_eq]

theorem pminus_eq_em : pminus = NullSectorTask01.em := by rw [pminus_coord, em_eq]

/-!
### Comparison step 5: Task-01 identities as consequences of Task-02 assumptions

Each statement below is proved for an *arbitrary* product `μ` admissible in the
Task-02 sense at `u₀`; specializing to `mulLBil` recovers the Task-01 identity.
-/

section Consequences

variable {μ : BiProd} (h : AdmissibleAt u₀ μ)

include h

/-- Task-01 `jL ⋆ jL = oneL` becomes a consequence: `μ s₀ s₀ = u₀`. -/
theorem jL_square_derived : μ jL jL = oneL := mu_s₀_s₀ h

/-- Task-01 `ep ⋆ ep = ep` becomes a consequence. -/
theorem ep_idem_derived : μ ep ep = ep := by
  rw [← pplus_eq_ep]; exact mu_pplus_pplus h

/-- Task-01 `em ⋆ em = em` becomes a consequence. -/
theorem em_idem_derived : μ NullSectorTask01.em NullSectorTask01.em = NullSectorTask01.em := by
  rw [← pminus_eq_em]; exact mu_pminus_pminus h

/-- Task-01 `ep ⋆ em = 0` becomes a consequence. -/
theorem ep_em_orthogonal_derived : μ ep NullSectorTask01.em = 0 := by
  rw [← pplus_eq_ep, ← pminus_eq_em]
  exact mu_pplus_pminus h

/-- Task-01 commutativity becomes a consequence. -/
theorem mulL_comm_derived : Commutative μ := fixedUnit_commutative h

/-- Task-01 associativity becomes a consequence. -/
theorem mulL_assoc_derived : Associative μ := fixedUnit_associative h

end Consequences

/-- Task-01 `ep + em = oneL`, re-derived from the Task-02 definitions of `pplus`,
`pminus` (no product needed). -/
theorem ep_add_em_derived : ep + NullSectorTask01.em = oneL := by
  rw [← pplus_eq_ep, ← pminus_eq_em]; exact pplus_add_pminus

/-- Task-01 `ep - em = jL`, re-derived from the Task-02 definitions. -/
theorem ep_sub_em_derived : ep - NullSectorTask01.em = jL := by
  rw [← pplus_eq_ep, ← pminus_eq_em]; exact pplus_sub_pminus

/-- Task-01 nullity of the idempotents, re-derived. -/
theorem Q2_ep_derived : Q2 ep = 0 := by rw [← pplus_eq_ep]; exact Q2_pplus

theorem Q2_em_derived : Q2 NullSectorTask01.em = 0 := by rw [← pminus_eq_em]; exact Q2_pminus

end NullSectorTask02
