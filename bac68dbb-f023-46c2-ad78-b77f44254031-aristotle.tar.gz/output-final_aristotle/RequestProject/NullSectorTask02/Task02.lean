import RequestProject.NullSectorTask02.Minimality
import RequestProject.NullSectorTask02.Comparison

/-!
# Task 02: principal classification and obstruction theorems

This file imports the complete Task-02 development (including the late comparison
layer) and states the principal final results, one group per acceptance criterion.
Every statement below is proved elsewhere in the development; nothing new is assumed.
-/

namespace NullSectorTask02

open NullSectorTask01

/-! ## 1. The Lorentz bilinear form by polarization -/

theorem task02_polarization :
    (∀ t x s y : ℝ, L2 (t, x) (s, y) = t * s - x * y) ∧
    (∀ X : Long, L2 X X = Q2 X) ∧
    (∀ X Y : Long, L2 X Y = L2 Y X) ∧
    (∀ X : Long, (∀ Y, L2 X Y = 0) → X = 0) :=
  ⟨L2_apply, L2_self, L2_symm, fun _ h => L2_nondegenerate h⟩

/-! ## 2. Necessary condition on a unit (derived, not assumed) -/

theorem task02_unit_normalized {e : Long} {μ : BiProd} (h : AdmissibleAt e μ) : Q2 e = 1 :=
  Q2_unit_eq_one h

theorem task02_unit_normalized_left {e : Long} {μ : BiProd} (h : LeftAdmissibleAt e μ) :
    Q2 e = 1 :=
  Q2_leftUnit_eq_one h

theorem task02_unit_unique {μ : BiProd} {e e' : Long}
    (h : TwoSidedUnit μ e) (h' : TwoSidedUnit μ e') : e = e' :=
  twoSidedUnit_unique h h'

/-! ## 3. Complete classification at the chosen reference unit `u₀ = (1,0)` -/

theorem task02_fixedUnit_formula {μ : BiProd} (h : AdmissibleAt u₀ μ) (X Y : Long) :
    μ X Y = (X.1 * Y.1 + X.2 * Y.2, X.1 * Y.2 + X.2 * Y.1) :=
  fixedUnit_formula h X Y

/-- **PROVED UNIQUE**: bilinear + two-sided unit `u₀` + `Q2`-multiplicative. -/
theorem task02_fixedUnit_existsUnique : ∃! μ : BiProd, AdmissibleAt u₀ μ :=
  fixedUnit_existsUnique

/-- Commutativity and associativity are consequences of admissibility at `u₀`. -/
theorem task02_comm_assoc_derived {μ : BiProd} (h : AdmissibleAt u₀ μ) :
    Commutative μ ∧ Associative μ :=
  ⟨fixedUnit_commutative h, fixedUnit_associative h⟩

/-- The square relation is a corollary of the classification. -/
theorem task02_square_relation {μ : BiProd} (h : AdmissibleAt u₀ μ) : μ s₀ s₀ = u₀ :=
  mu_s₀_s₀ h

/-- The complementary null idempotent structure is downstream of the classification. -/
theorem task02_idempotents {μ : BiProd} (h : AdmissibleAt u₀ μ) :
    μ pplus pplus = pplus ∧ μ pminus pminus = pminus ∧ μ pplus pminus = 0 ∧
      pplus + pminus = u₀ ∧ pplus - pminus = s₀ ∧ Q2 pplus = 0 ∧ Q2 pminus = 0 :=
  ⟨mu_pplus_pplus h, mu_pminus_pminus h, mu_pplus_pminus h, pplus_add_pminus,
    pplus_sub_pminus, Q2_pplus, Q2_pminus⟩

/-! ## 4. Minimality: the left-unit-only problem -/

/-- **PROVED NON-UNIQUE**: bilinear + left unit `u₀` + `Q2`-multiplicative admits
exactly two products. -/
theorem task02_leftUnit_dichotomy {μ : BiProd} (h : LeftAdmissibleAt u₀ μ) :
    (∀ X Y : Long, μ X Y = (X.1 * Y.1 + X.2 * Y.2, X.1 * Y.2 + X.2 * Y.1)) ∨
    (∀ X Y : Long, μ X Y = (X.1 * Y.1 - X.2 * Y.2, X.1 * Y.2 - X.2 * Y.1)) :=
  leftAdmissible_dichotomy h

theorem task02_leftUnit_not_unique :
    ∃ μ ν : BiProd, LeftAdmissibleAt u₀ μ ∧ LeftAdmissibleAt u₀ ν ∧ μ ≠ ν :=
  leftAdmissible_not_unique

/-- Each of right unit, commutativity, associativity restores uniqueness. -/
theorem task02_minimality_tests :
    (∀ μ : BiProd, LeftAdmissibleAt u₀ μ → RightUnit μ u₀ → μ = recU) ∧
    (∀ μ : BiProd, LeftAdmissibleAt u₀ μ → Commutative μ → μ = recU) ∧
    (∀ μ : BiProd, LeftAdmissibleAt u₀ μ → Associative μ → μ = recU) :=
  ⟨fun _ h hr => testA_unique h hr, fun _ h hc => testB_unique h hc,
    fun _ h ha => testC_unique h ha⟩

/-! ## 5. Arbitrary unit vectors -/

/-- **Existence ↔ normalization** for an arbitrary vector `e`. -/
theorem task02_exists_admissible_iff (e : Long) :
    (∃ μ : BiProd, AdmissibleAt e μ) ↔ Q2 e = 1 :=
  exists_admissible_iff e

/-- **PROVED UNIQUE** for each normalized `e`, with a coordinate-free formula. -/
theorem task02_generalUnit_existsUnique {e : Long} (hQ : Q2 e = 1) :
    ∃! μ : BiProd, AdmissibleAt e μ :=
  generalUnit_existsUnique hQ

theorem task02_generalUnit_formula {μ : BiProd} {e : Long} (h : AdmissibleAt e μ) (X Y : Long) :
    μ X Y = (L2 X e) • Y + (L2 Y e) • X - (L2 X Y) • e :=
  generalUnit_formula h X Y

/-! ## 6. Future normalized vectors and canonicality -/

/-- **PROVED NON-UNIQUE**: `Q2` plus the future component does not select a unit. -/
theorem task02_futureUnit_not_unique :
    ∃ e e' : Long, FutureUnit e ∧ FutureUnit e' ∧ e ≠ e' :=
  futureUnit_not_unique

/-- **PROVED NON-UNIQUE**: `Q2` plus the future component does not select a product. -/
theorem task02_product_not_intrinsic :
    ∃ (e e' : Long) (μ ν : BiProd),
      FutureUnit e ∧ FutureUnit e' ∧ AdmissibleAt e μ ∧ AdmissibleAt e' ν ∧ μ ≠ ν :=
  admissible_product_not_intrinsic

/-- An explicit rational nontrivial `Q2`-preserving, future-preserving symmetry. -/
theorem task02_symmetry :
    (∀ X : Long, Q2 (Tsym X) = Q2 X) ∧
    (∀ e : Long, FutureUnit e → FutureUnit (Tsym e)) ∧
    Tsym u₀ ≠ u₀ :=
  ⟨Tsym_Q2, fun _ he => Tsym_futureUnit he, Tsym_ne_id⟩

/-- **PROVED IMPOSSIBLE**: no admissible unital product is equivariant under `Tsym`. -/
theorem task02_no_equivariant_admissible :
    ¬ ∃ (e : Long) (μ : BiProd), AdmissibleAt e μ ∧ Equivariant Tsym μ :=
  no_equivariant_admissible

/-- Coordinate availability of `u₀` versus intrinsic determination. -/
theorem task02_u₀_extra_data : FutureUnit u₀ ∧ FutureUnit (Tsym u₀) ∧ Tsym u₀ ≠ u₀ :=
  u₀_is_extra_data

/-! ## 7. Late comparison with Task 01 -/

theorem task02_comparison_admissible : AdmissibleAt u₀ mulLBil := mulLBil_admissible

theorem task02_comparison_eq : mulLBil = recU := mulLBil_eq_recU

theorem task02_comparison_idempotents :
    pplus = ep ∧ pminus = NullSectorTask01.em :=
  ⟨pplus_eq_ep, pminus_eq_em⟩

/-! ## Axiom report -/

#print axioms task02_polarization
#print axioms task02_unit_normalized
#print axioms task02_unit_unique
#print axioms task02_fixedUnit_formula
#print axioms task02_fixedUnit_existsUnique
#print axioms task02_comm_assoc_derived
#print axioms task02_square_relation
#print axioms task02_idempotents
#print axioms task02_leftUnit_dichotomy
#print axioms task02_leftUnit_not_unique
#print axioms task02_minimality_tests
#print axioms task02_exists_admissible_iff
#print axioms task02_generalUnit_existsUnique
#print axioms task02_generalUnit_formula
#print axioms task02_futureUnit_not_unique
#print axioms task02_product_not_intrinsic
#print axioms task02_symmetry
#print axioms task02_no_equivariant_admissible
#print axioms task02_u₀_extra_data
#print axioms task02_comparison_admissible
#print axioms task02_comparison_eq
#print axioms task02_comparison_idempotents

end NullSectorTask02
