import RequestProject.NullSectorTask09.Existence

/-!
# Task 09, Layer 6: the exact classification

Rigidity (Layer 4) and existence (Layer 5) are combined into the exact
description of

```
{ N : W → W | CentralQuadraticExtension N }.
```

**Result.**  The solution space is *nonempty*, has *exactly two* elements, and
the residual freedom is a **sign**, i.e. **DISCRETE FREEDOM** — there is no
continuous family.  Moreover no admissible map can have its image inside the
real line `ℝ • 1`, so the additional central direction is genuinely required.
-/

namespace NullSectorTask09

open NullSectorTask01 NullSectorTask08

/-! ## The exact solution space -/

/-- **EXACT CLASSIFICATION THEOREM.**  A map is an admissible central-valued
quadratic multiplicative extension of the inherited Lorentz form **iff** it is
one of the two explicit maps of Layer 5. -/
theorem exact_classification (N : W → W) :
    CentralQuadraticExtension N ↔ (N = Ncand 1 ∨ N = Ncand (-1)) := by
  constructor
  · intro h
    obtain ⟨y, hy, hd⟩ := h.residual_normal
    rcases hy with rfl | rfl
    · exact Or.inl (rigidity h Ncand_admissible_one
        (by rw [hd, Ncand_residual]))
    · exact Or.inr (rigidity h Ncand_admissible_neg_one
        (by rw [hd, Ncand_residual]))
  · rintro (rfl | rfl)
    · exact Ncand_admissible_one
    · exact Ncand_admissible_neg_one

/-- **EXISTENCE.**  The solution space is nonempty. -/
theorem exists_central_extension :
    ∃ N : W → W, CentralQuadraticExtension N :=
  ⟨Ncand 1, Ncand_admissible_one⟩

/-- The solution space as a set. -/
theorem solution_set_eq :
    {N : W → W | CentralQuadraticExtension N} = {Ncand 1, Ncand (-1)} := by
  ext N
  simpa using exact_classification N

/-- **NON-UNIQUE, DISCRETE FREEDOM.**  The solution space has exactly two
elements. -/
theorem solution_set_ncard :
    {N : W → W | CentralQuadraticExtension N}.ncard = 2 := by
  rw [solution_set_eq]
  exact Set.ncard_pair Ncand_one_ne_neg_one

/-- **THE FREEDOM IS DISCRETE, NOT CONTINUOUS.**  Inside the one-real-parameter
family of explicit coefficient maps, exactly the two values `z = ±1` are
admissible. -/
theorem admissible_parameter (z : ℝ) :
    CentralQuadraticExtension (Ncand z) ↔ (z = 1 ∨ z = -1) := by
  constructor
  · intro h
    obtain ⟨y, hy, hd⟩ := h.residual_normal
    rw [Ncand_residual] at hd
    have hzy : (0 : ℝ) • w1 + (2 * z) • wS = (0 : ℝ) • w1 + (2 * y) • wS := by
      rw [zero_smul, zero_add, zero_add, hd]
    have := (Z_coeff_unique hzy).2
    rcases hy with rfl | rfl
    · left; linarith
    · right; linarith
  · rintro (rfl | rfl)
    · exact Ncand_admissible_one
    · exact Ncand_admissible_neg_one

/-! ## §26 — the real-line image negative control -/

theorem smul_wS_not_mem_line {c : ℝ} (hc : c ≠ 0) :
    (c • wS) ∉ Submodule.span ℝ ({w1} : Set W) := by
  rw [Submodule.mem_span_singleton]
  rintro ⟨a, ha⟩
  have h7 := congrFun ha 7
  simp [w1, wS] at h7
  exact hc h7.symm

/-- **REAL-LINE IMAGE IMPOSSIBLE.**  No admissible map has all of its values in
the real line `ℝ • 1 ⊆ Z`: the enlargement of the product carrier alone was
insufficient, and multiplicative quadratic extension also forces the codomain to
use the additional central direction. -/
theorem real_line_image_impossible {N : W → W} (h : CentralQuadraticExtension N) :
    ¬ (∀ x : W, N x ∈ Submodule.span ℝ ({w1} : Set W)) := by
  intro hline
  obtain ⟨y, hy, hd⟩ := h.residual_normal
  have hval : N (w1 + wS) = (2 * y) • wS := by rw [h.val_sum_w1_wS, hd]
  have hne : (2 * y) ≠ 0 := by rcases hy with rfl | rfl <;> norm_num
  exact smul_wS_not_mem_line hne (hval ▸ hline (w1 + wS))

/-! ## §27 — the `S` component is actually attained -/

/-- **CENTRAL COMPONENT REQUIRED.**  For *every* admissible map there is an
element whose value has a nonzero `S` component; no branch of the classification
avoids the additional central direction. -/
theorem S_component_attained {N : W → W} (h : CentralQuadraticExtension N) :
    ∃ x : W, (N x) 7 ≠ 0 := by
  obtain ⟨y, hy, hd⟩ := h.residual_normal
  refine ⟨w1 + wS, ?_⟩
  have hval : N (w1 + wS) = (2 * y) • wS := by rw [h.val_sum_w1_wS, hd]
  rw [hval]
  have : ((2 * y) • wS) 7 = 2 * y := by simp [wS]
  rw [this]
  rcases hy with rfl | rfl <;> norm_num

/-! ## The literal `W → Z` form of the classification -/

/-- The two explicit candidates, as maps into the central plane. -/
def NcandZ (z : ℝ) (x : W) : (Z : Submodule ℝ W) := ⟨Ncand z x, Ncand_mem z x⟩

/-- **EXISTENCE, LITERAL `W → Z` FORM.** -/
theorem exists_central_extension_Z :
    ∃ N : W → (Z : Submodule ℝ W), CentralQuadraticExtensionZ N := by
  refine ⟨NcandZ 1, ?_⟩
  rw [cqeZ_iff]
  exact Ncand_admissible_one

/-- **VERDICT ON THE SECOND PART-VI OBSTRUCTION.**
`PART-VI Q4 MULTIPLICATIVITY OBSTRUCTION RESOLVED AFTER CODOMAIN ENLARGEMENT.`

The product carrier is unchanged (it is the Task-08 associative closure);
only the codomain of the quadratic map was enlarged, from `ℝ` to the internally
derived central plane `Z`.  With codomain `ℝ` no extension exists; with codomain
`Z` exactly two exist. -/
theorem part_vi_verdict :
    (¬ ∃ NR : W → ℝ, AdmissibleR NR) ∧
    (∃ N : W → W, CentralQuadraticExtension N) ∧
    {N : W → W | CentralQuadraticExtension N}.ncard = 2 :=
  ⟨no_real_valued_extension, exists_central_extension, solution_set_ncard⟩

end NullSectorTask09
