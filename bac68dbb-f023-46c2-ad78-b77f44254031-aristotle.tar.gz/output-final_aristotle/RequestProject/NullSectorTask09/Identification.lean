import RequestProject.NullSectorTask09.CentralSignAudit
import RequestProject.NullSectorTask08.Identification

/-!
# Task 09, Layer 8: late conventional identification — COMPARISON ONLY

Everything asked of Task 09 has already been established without this module:
the scalar no-go, the construction of the central plane with its closure,
commutativity, centrality and dimension, the unknown-map analysis, the rigidity
theorem, the explicit existence witnesses, global multiplicativity, the full
old-`Q4` restriction, the exact classification, the real-line negative control
and the central-sign audit.  **No earlier Task-09 result depends on this file**,
and no Task-09 reconstruction module imports it.

Only now is the Task-08 conventional identification imported, and only now may
the words *determinant* and *complex* appear.  The single question asked here
is whether the independently reconstructed quadratic multiplicative map
corresponds to a standard known operation under the Task-08 isomorphism.  It
does.

All statements in this module are **COMPARISON ONLY**.
-/

namespace NullSectorTask09

open NullSectorTask08

/-! ## Coordinates of the reconstructed map -/

@[simp] theorem Ncand_coord_0 (z : ℝ) (x : W) : Ncand z x 0 = nRe x := by
  simp [Ncand, w1, wS]

@[simp] theorem Ncand_coord_7 (z : ℝ) (x : W) : Ncand z x 7 = z * nSc x := by
  simp [Ncand, w1, wS]

@[simp] theorem Ncand_coord_1 (z : ℝ) (x : W) : Ncand z x 1 = 0 := by
  simp [Ncand, w1, wS]

@[simp] theorem Ncand_coord_2 (z : ℝ) (x : W) : Ncand z x 2 = 0 := by
  simp [Ncand, w1, wS]

@[simp] theorem Ncand_coord_3 (z : ℝ) (x : W) : Ncand z x 3 = 0 := by
  simp [Ncand, w1, wS]

@[simp] theorem Ncand_coord_4 (z : ℝ) (x : W) : Ncand z x 4 = 0 := by
  simp [Ncand, w1, wS]

@[simp] theorem Ncand_coord_5 (z : ℝ) (x : W) : Ncand z x 5 = 0 := by
  simp [Ncand, w1, wS]

@[simp] theorem Ncand_coord_6 (z : ℝ) (x : W) : Ncand z x 6 = 0 := by
  simp [Ncand, w1, wS]

/-- **COMPARISON ONLY.**  Under the Task-08 isomorphism the independently
reconstructed central-valued quadratic multiplicative extension `Ncand 1` is
exactly the determinant of the corresponding `2 × 2` complex matrix, viewed as a
scalar matrix, i.e. as an element of the centre.  The other admissible map is
its complex conjugate. -/
theorem toMat_Ncand_one (x : W) :
    toMat (Ncand 1 x) = (toMat x).det • (1 : Matrix (Fin 2) (Fin 2) ℂ) := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [toMat, Matrix.det_fin_two, nRe, nSc, Complex.ext_iff,
      - Complex.ofReal_pow] <;>
    constructor <;> ring

/-- **COMPARISON ONLY.**  The second admissible map is the complex conjugate of
the determinant. -/
theorem toMat_Ncand_neg_one (x : W) :
    toMat (Ncand (-1) x)
      = (starRingEnd ℂ) ((toMat x).det) • (1 : Matrix (Fin 2) (Fin 2) ℂ) := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [toMat, Matrix.det_fin_two, nRe, nSc, Complex.ext_iff,
      - Complex.ofReal_pow] <;>
    constructor <;> ring

/-- **COMPARISON ONLY (summary).**  The exact Task-09 classification consists of
the determinant and its complex conjugate, transported through the Task-08
isomorphism; the derived central plane `Z = spanℝ {1, S}` is the centre of the
matrix algebra, i.e. the scalar matrices. -/
theorem identification_comparison :
    (∀ x : W, toMat (Ncand 1 x) = (toMat x).det • (1 : Matrix (Fin 2) (Fin 2) ℂ)) ∧
    (∀ x : W, toMat (Ncand (-1) x)
      = (starRingEnd ℂ) ((toMat x).det) • (1 : Matrix (Fin 2) (Fin 2) ℂ)) ∧
    toMat wS = !![Complex.I, 0; 0, Complex.I] :=
  ⟨toMat_Ncand_one, toMat_Ncand_neg_one, toMat_wS⟩

end NullSectorTask09
