import RequestProject.NullSectorTask09.ExactClassification

/-!
# Task 09, Layer 7: the central-sign audit

Two independent diagnostics.

**§28.**  The real-linear map of the central plane determined by `1 ↦ 1`,
`S ↦ -S` is defined intrinsically (no conventional name is attached to it), it
is proved to preserve the induced multiplication of `Z`, and its action on the
classified solution space is determined exactly: it **exchanges** the two
admissible maps, fixing neither.

**§29.**  The residual Task-09 ambiguity is compared with the Task-08 ordered
generator freedom.  Transposing two of the three derived spatial generators is
an algebra automorphism of the fixed carrier which sends the derived central
element `S` to `-S` (the sign recorded by the Task-08 permutation audit), and
composing an admissible map with it produces exactly the other admissible map.
So the Task-09 freedom tracks the already existing Task-08 sign freedom; it is
not a new ambiguity.
-/

namespace NullSectorTask09

open NullSectorTask01 NullSectorTask08

/-! ## §28 — the central sign map -/

/-- **DERIVED.**  The real-linear map of the carrier which acts on the central
plane by `1 ↦ 1`, `S ↦ -S`. -/
def zFlip (x : W) : W := (x 0) • w1 - (x 7) • wS

theorem zFlip_add (x y : W) : zFlip (x + y) = zFlip x + zFlip y := by
  simp only [zFlip, Pi.add_apply, add_smul]
  abel

theorem zFlip_smul (r : ℝ) (x : W) : zFlip (r • x) = r • zFlip x := by
  simp only [zFlip, Pi.smul_apply, smul_eq_mul, mul_smul]
  module

theorem zFlip_normal (a b : ℝ) : zFlip (a • w1 + b • wS) = a • w1 - b • wS := by
  have h0 : (a • w1 + b • wS) 0 = a := by simp [w1, wS]
  have h7 : (a • w1 + b • wS) 7 = b := by simp [w1, wS]
  rw [zFlip, h0, h7]

@[simp] theorem zFlip_w1 : zFlip w1 = w1 := by
  have h : w1 = (1 : ℝ) • w1 + (0 : ℝ) • wS := by module
  rw [h, zFlip_normal]; module

@[simp] theorem zFlip_wS : zFlip wS = - wS := by
  have h : wS = (0 : ℝ) • w1 + (1 : ℝ) • wS := by module
  rw [h, zFlip_normal]; module

theorem zFlip_mem {x : W} (hx : x ∈ Z) : zFlip x ∈ Z := by
  obtain ⟨a, b, rfl⟩ := (mem_Z_iff x).1 hx
  rw [zFlip_normal]
  have h : a • w1 - b • wS = a • w1 + (-b) • wS := by module
  rw [h]
  exact smul_add_smul_mem_Z _ _

/-- **DERIVED.**  The central sign map preserves the induced multiplication of
the central plane. -/
theorem zFlip_mul {x y : W} (hx : x ∈ Z) (hy : y ∈ Z) :
    zFlip (x ⋆ y) = zFlip x ⋆ zFlip y := by
  obtain ⟨a, b, rfl⟩ := (mem_Z_iff x).1 hx
  obtain ⟨c, d, rfl⟩ := (mem_Z_iff y).1 hy
  rw [central_mul_rule, zFlip_normal, zFlip_normal, zFlip_normal]
  have e1 : a • w1 - b • wS = a • w1 + (-b) • wS := by module
  have e2 : c • w1 - d • wS = c • w1 + (-d) • wS := by module
  rw [e1, e2, central_mul_rule]
  module

/-! ### Its action on the classified solution space -/

theorem zFlip_Ncand (z : ℝ) (x : W) : zFlip (Ncand z x) = Ncand (-z) x := by
  rw [Ncand, zFlip_normal, Ncand]
  module

/-- **CENTRAL-SIGN ACTION.**  Composition with the central sign map exchanges
the two admissible maps; it fixes neither. -/
theorem zFlip_exchanges :
    zFlip ∘ (Ncand 1) = Ncand (-1) ∧ zFlip ∘ (Ncand (-1)) = Ncand 1 := by
  constructor
  · funext x; simpa using zFlip_Ncand 1 x
  · funext x
    have := zFlip_Ncand (-1) x
    simpa using this

/-- **CENTRAL-SIGN ACTION, intrinsic form.**  For every admissible `N` the
composite `zFlip ∘ N` is again admissible, and it is the *other* solution. -/
theorem zFlip_admissible {N : W → W} (h : CentralQuadraticExtension N) :
    CentralQuadraticExtension (zFlip ∘ N) ∧ zFlip ∘ N ≠ N := by
  rcases (exact_classification N).1 h with rfl | rfl
  · refine ⟨?_, ?_⟩
    · rw [zFlip_exchanges.1]; exact Ncand_admissible_neg_one
    · rw [zFlip_exchanges.1]; exact fun hcon => Ncand_one_ne_neg_one hcon.symm
  · refine ⟨?_, ?_⟩
    · rw [zFlip_exchanges.2]; exact Ncand_admissible_one
    · rw [zFlip_exchanges.2]; exact Ncand_one_ne_neg_one

/-! ## §29 — comparison with the Task-08 ordered generator freedom -/

/-- **DERIVED.**  The relabelling of the two first derived spatial generators,
written in the derived Task-08 coordinates.  It is *not* a new structure: it is
the coordinate form of the transposition already audited in Task 08. -/
def swapAB (x : W) : W :=
  ![x 0, x 2, x 1, x 3, -(x 4), x 6, x 5, -(x 7)]

theorem swapAB_add (x y : W) : swapAB (x + y) = swapAB x + swapAB y := by
  funext i; fin_cases i <;> simp [swapAB] <;> ring

theorem swapAB_smul (r : ℝ) (x : W) : swapAB (r • x) = r • swapAB x := by
  funext i; fin_cases i <;> simp [swapAB]

/-- **DERIVED.**  The relabelling is multiplicative for the fixed inherited
product: it is an algebra automorphism of the Task-08 carrier. -/
theorem swapAB_mul (x y : W) : swapAB (x ⋆ y) = swapAB x ⋆ swapAB y := by
  funext i; fin_cases i <;> simp [swapAB] <;> ring

@[simp] theorem swapAB_w1 : swapAB w1 = w1 := by
  funext i; fin_cases i <;> simp [swapAB, w1]

@[simp] theorem swapAB_wA : swapAB wA = wB := by
  funext i; fin_cases i <;> simp [swapAB, wA, wB]

@[simp] theorem swapAB_wB : swapAB wB = wA := by
  funext i; fin_cases i <;> simp [swapAB, wA, wB]

@[simp] theorem swapAB_wC : swapAB wC = wC := by
  funext i; fin_cases i <;> simp [swapAB, wC]

/-- **THE TASK-08 SIGN.**  The relabelling sends the derived central element to
its negative — exactly the sign recorded by the Task-08 permutation audit. -/
@[simp] theorem swapAB_wS : swapAB wS = - wS := by
  funext i; fin_cases i <;> simp [swapAB, wS]

@[simp] theorem swapAB_coord_0 (x : W) : swapAB x 0 = x 0 := rfl
@[simp] theorem swapAB_coord_1 (x : W) : swapAB x 1 = x 2 := rfl
@[simp] theorem swapAB_coord_2 (x : W) : swapAB x 2 = x 1 := rfl
@[simp] theorem swapAB_coord_3 (x : W) : swapAB x 3 = x 3 := rfl
@[simp] theorem swapAB_coord_4 (x : W) : swapAB x 4 = -(x 4) := rfl
@[simp] theorem swapAB_coord_5 (x : W) : swapAB x 5 = x 6 := rfl
@[simp] theorem swapAB_coord_6 (x : W) : swapAB x 6 = x 5 := rfl
@[simp] theorem swapAB_coord_7 (x : W) : swapAB x 7 = -(x 7) := rfl

theorem nRe_swapAB (x : W) : nRe (swapAB x) = nRe x := by
  simp only [nRe, swapAB_coord_0, swapAB_coord_1, swapAB_coord_2,
    swapAB_coord_3, swapAB_coord_4, swapAB_coord_5, swapAB_coord_6,
    swapAB_coord_7]
  ring

theorem nSc_swapAB (x : W) : nSc (swapAB x) = - nSc x := by
  simp only [nSc, swapAB_coord_0, swapAB_coord_1, swapAB_coord_2,
    swapAB_coord_3, swapAB_coord_4, swapAB_coord_5, swapAB_coord_6,
    swapAB_coord_7]
  ring

/-- **THE TASK-09 FREEDOM TRACKS THE TASK-08 SIGN FREEDOM.**  Precomposing an
admissible map with the generator transposition produces the other admissible
map — the same exchange as the central sign map of §28. -/
theorem Ncand_comp_swapAB (z : ℝ) (x : W) : Ncand z (swapAB x) = Ncand (-z) x := by
  rw [Ncand, nRe_swapAB, nSc_swapAB, Ncand]
  module

theorem generator_relabelling_exchanges :
    (Ncand 1) ∘ swapAB = Ncand (-1) ∧ (Ncand (-1)) ∘ swapAB = Ncand 1 := by
  constructor
  · funext x; simpa using Ncand_comp_swapAB 1 x
  · funext x
    have := Ncand_comp_swapAB (-1) x
    simpa using this

/-- **CENTRAL-SIGN AUDIT (summary).** -/
theorem central_sign_audit :
    (∀ x y : W, x ∈ Z → y ∈ Z → zFlip (x ⋆ y) = zFlip x ⋆ zFlip y) ∧
    zFlip w1 = w1 ∧ zFlip wS = - wS ∧
    zFlip ∘ (Ncand 1) = Ncand (-1) ∧ zFlip ∘ (Ncand (-1)) = Ncand 1 ∧
    swapAB wS = - wS ∧
    (Ncand 1) ∘ swapAB = Ncand (-1) :=
  ⟨fun _ _ hx hy => zFlip_mul hx hy, zFlip_w1, zFlip_wS, zFlip_exchanges.1,
    zFlip_exchanges.2, swapAB_wS, generator_relabelling_exchanges.1⟩

end NullSectorTask09
