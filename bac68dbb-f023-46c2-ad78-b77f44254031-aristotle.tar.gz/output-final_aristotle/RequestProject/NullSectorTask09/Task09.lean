import RequestProject.NullSectorTask09.Identification

/-!
# Task 09: principal theorems

This module imports the complete Task-09 development and states the principal
final theorems, one per acceptance criterion, followed by the axiom report.

The import of the late comparison layer happens **here and in
`Identification.lean` only**; the whole reconstruction core
(`SafeBase → RealScalarNoGo → CentralPlane → UnknownQuadraticMap → Rigidity →
Existence → ExactClassification → CentralSignAudit`) is independent of it.
-/

namespace NullSectorTask09

open NullSectorTask01 NullSectorTask04 NullSectorTask07 NullSectorTask08

/-! ## Phase A — the real-valued negative control -/

/-- **1. SCALAR CODOMAIN OBSTRUCTION.**  Even after the associative product
carrier has been enlarged successfully, no real-valued quadratic multiplicative
extension of the inherited Lorentz form exists. -/
theorem task09_scalar_no_go :
    ¬ ∃ NR : W → ℝ,
        IsRealQuadratic NR ∧ MultiplicativeR NR ∧ ExtendsQ4R NR :=
  no_real_valued_extension_explicit

/-- **2. THE MINIMAL SCALAR OBSTRUCTION.**  The smallest transparent
configuration: degree-two homogeneity, multiplicativity, and the three inherited
values `-1` on the embedded old spatial directions, tested on the single element
`1 + S`. -/
theorem task09_minimal_scalar_obstruction (NR : W → ℝ)
    (hhom : ∀ (r : ℝ) (x : W), NR (r • x) = r ^ 2 * NR x)
    (hmul : MultiplicativeR NR)
    (hA : NR wA = -1) (hB : NR wB = -1) (hC : NR wC = -1) : False :=
  scalar_obstruction_minimal NR hhom hmul hA hB hC

/-! ## The internal central two-plane -/

/-- **3. CENTRAL PLANE.**  `Z = spanℝ {1, S}` is closed under the inherited
product, its induced multiplication is commutative, every element of `Z`
commutes with every element of the eight-dimensional carrier, and
`dimℝ Z = 2`. -/
theorem task09_central_plane :
    (∀ x y : W, x ∈ Z → y ∈ Z → x ⋆ y ∈ Z) ∧
    (∀ x y : W, x ∈ Z → y ∈ Z → x ⋆ y = y ⋆ x) ∧
    (∀ z : W, z ∈ Z → ∀ x : W, z ⋆ x = x ⋆ z) ∧
    Module.finrank ℝ (Z : Submodule ℝ W) = 2 :=
  centralPlane_summary

/-- **4. NORMAL FORM IN THE CENTRAL PLANE.**  Every element of `Z` is uniquely
`a • 1 + b • S`. -/
theorem task09_central_normal_form :
    (∀ x : W, x ∈ Z ↔ ∃ a b : ℝ, x = a • w1 + b • wS) ∧
    (∀ a b a' b' : ℝ, a • w1 + b • wS = a' • w1 + b' • wS → a = a' ∧ b = b') ∧
    (∀ a b c d : ℝ, (a • w1 + b • wS) ⋆ (c • w1 + d • wS)
      = (a * c - b * d) • w1 + (a * d + b * c) • wS) :=
  ⟨mem_Z_iff, fun _ _ _ _ h => Z_coeff_unique h, central_mul_rule⟩

/-! ## Phase B — the unknown map, forced values and rigidity -/

/-- **5. INHERITED BASIS VALUES.**  For an arbitrary admissible central-valued
map every value on the eight derived Task-08 basis elements is forced, and every
one of them lies in the real line `ℝ • 1` inside `Z`. -/
theorem task09_forced_basis_values {N : W → W} (h : CentralQuadraticExtension N) :
    N w1 = w1 ∧ N wA = - w1 ∧ N wB = - w1 ∧ N wC = - w1 ∧
      N wP = w1 ∧ N wQ = w1 ∧ N wR = w1 ∧ N wS = - w1 :=
  h.forced_basis_values

/-- **6. OLD-`Q4` POLARIZATION CONSTRAINTS.**  All six polarization values on
the embedded old carrier, derived from the inherited Lorentz form. -/
theorem task09_old_polarization_constraints {N : W → W}
    (h : CentralQuadraticExtension N) :
    polar N w1 wA = 0 ∧ polar N w1 wB = 0 ∧ polar N w1 wC = 0 ∧
    polar N wA wB = 0 ∧ polar N wA wC = 0 ∧ polar N wB wC = 0 :=
  h.old_polarization_constraints

/-- **7. EXACT RESIDUAL FREEDOM.**  The only datum not forced to a number is the
polarization of the unit against the derived central element, and it satisfies
`d ⋆ d = -4 • 1`, hence `d = (2ζ) • S` with `ζ = ±1`. -/
theorem task09_residual_datum {N : W → W} (h : CentralQuadraticExtension N) :
    (polar N w1 wS) ⋆ (polar N w1 wS) = (-4 : ℝ) • w1 ∧
      ∃ y : ℝ, (y = 1 ∨ y = -1) ∧ polar N w1 wS = (2 * y) • wS :=
  ⟨h.residual_sq, h.residual_normal⟩

/-- **8. RIGIDITY RESULT.**  An admissible map is completely determined by that
single residual datum. -/
theorem task09_rigidity {N₁ N₂ : W → W} (h1 : CentralQuadraticExtension N₁)
    (h2 : CentralQuadraticExtension N₂)
    (hd : polar N₁ w1 wS = polar N₂ w1 wS) : N₁ = N₂ :=
  rigidity h1 h2 hd

/-! ## Phase C — existence -/

/-- **9. EXISTENCE WITNESS, QUADRATICITY.** -/
theorem task09_quadraticity (z : ℝ) : IsRealQuadratic (Ncand z) :=
  Ncand_quadratic z

/-- **10. GLOBAL MULTIPLICATIVITY.**  For arbitrary `x y : W`, not merely for
basis elements. -/
theorem task09_global_multiplicativity (z : ℝ) (hz : z * z = 1) (x y : W) :
    Ncand z (x ⋆ y) = (Ncand z x) ⋆ (Ncand z y) :=
  Ncand_mul z hz x y

/-- **11. FULL OLD-`Q4` RESTRICTION.**  For arbitrary old vectors `X : Vec4`. -/
theorem task09_old_Q4_restriction (z : ℝ) (X : Vec4) :
    Ncand z (iota3 X) = Q4 X • w1 :=
  Ncand_ext z X

/-- **12. EXISTENCE.** -/
theorem task09_existence : ∃ N : W → W, CentralQuadraticExtension N :=
  exists_central_extension

/-- **13. EXISTENCE, LITERAL `W → Z` FORM.** -/
theorem task09_existence_Z :
    ∃ N : W → (Z : Submodule ℝ W), CentralQuadraticExtensionZ N :=
  exists_central_extension_Z

/-! ## The exact classification -/

/-- **14. EXACT CLASSIFICATION.** -/
theorem task09_exact_classification (N : W → W) :
    CentralQuadraticExtension N ↔ (N = Ncand 1 ∨ N = Ncand (-1)) :=
  exact_classification N

/-- **15. NON-UNIQUE, DISCRETE FREEDOM.**  The solution space has exactly two
elements, and inside the one-real-parameter family of coefficient maps exactly
the two values `z = ±1` are admissible: the residual freedom is a sign, not a
continuum. -/
theorem task09_solution_space :
    {N : W → W | CentralQuadraticExtension N} = {Ncand 1, Ncand (-1)} ∧
    {N : W → W | CentralQuadraticExtension N}.ncard = 2 ∧
    Ncand 1 ≠ Ncand (-1) ∧
    (∀ z : ℝ, CentralQuadraticExtension (Ncand z) ↔ (z = 1 ∨ z = -1)) :=
  ⟨solution_set_eq, solution_set_ncard, Ncand_one_ne_neg_one, admissible_parameter⟩

/-- **16. REAL-LINE IMAGE IMPOSSIBLE.**  Enlarging the product carrier alone was
insufficient; multiplicative quadratic extension also forces the codomain to use
the additional central direction. -/
theorem task09_real_line_image_impossible {N : W → W}
    (h : CentralQuadraticExtension N) :
    ¬ (∀ x : W, N x ∈ Submodule.span ℝ ({w1} : Set W)) :=
  real_line_image_impossible h

/-- **17. CENTRAL COMPONENT REQUIRED.**  For every admissible map the `S`
component of the image is actually attained. -/
theorem task09_S_component_attained {N : W → W}
    (h : CentralQuadraticExtension N) : ∃ x : W, (N x) 7 ≠ 0 :=
  S_component_attained h

/-! ## The central-sign audit -/

/-- **18. CENTRAL-SIGN ACTION.**  The real-linear map of the central plane with
`1 ↦ 1`, `S ↦ -S` preserves the induced multiplication and **exchanges** the two
admissible maps, fixing neither. -/
theorem task09_central_sign_action :
    (∀ x y : W, x ∈ Z → y ∈ Z → zFlip (x ⋆ y) = zFlip x ⋆ zFlip y) ∧
    zFlip w1 = w1 ∧ zFlip wS = - wS ∧
    zFlip ∘ (Ncand 1) = Ncand (-1) ∧ zFlip ∘ (Ncand (-1)) = Ncand 1 ∧
    swapAB wS = - wS ∧
    (Ncand 1) ∘ swapAB = Ncand (-1) :=
  central_sign_audit

/-- **19. THE RESIDUAL FREEDOM TRACKS THE TASK-08 SIGN FREEDOM.**  The
transposition of two derived spatial generators is an algebra automorphism of
the *fixed* carrier which sends `S` to `-S`, and precomposition with it
exchanges the two admissible maps. -/
theorem task09_generator_sign_tracking :
    (∀ x y : W, swapAB (x ⋆ y) = swapAB x ⋆ swapAB y) ∧
    swapAB wA = wB ∧ swapAB wB = wA ∧ swapAB wC = wC ∧ swapAB wS = - wS ∧
    (Ncand 1) ∘ swapAB = Ncand (-1) ∧ (Ncand (-1)) ∘ swapAB = Ncand 1 :=
  ⟨swapAB_mul, swapAB_wA, swapAB_wB, swapAB_wC, swapAB_wS,
    generator_relabelling_exchanges.1, generator_relabelling_exchanges.2⟩

/-! ## The Part-VI verdict -/

/-- **20. PART-VI Q4 MULTIPLICATIVITY OBSTRUCTION RESOLVED AFTER CODOMAIN
ENLARGEMENT.**  The product carrier is unchanged; only the codomain of the
quadratic map was enlarged, from `ℝ` to the internally derived central plane
`Z = spanℝ {1, S}`. -/
theorem task09_part_vi_verdict :
    (¬ ∃ NR : W → ℝ, AdmissibleR NR) ∧
    (∃ N : W → W, CentralQuadraticExtension N) ∧
    {N : W → W | CentralQuadraticExtension N}.ncard = 2 :=
  part_vi_verdict

/-! ## Late conventional identification — COMPARISON ONLY -/

/-- **21. COMPARISON ONLY.** -/
theorem task09_identification :
    (∀ x : W, toMat (Ncand 1 x) = (toMat x).det • (1 : Matrix (Fin 2) (Fin 2) ℂ)) ∧
    (∀ x : W, toMat (Ncand (-1) x)
      = (starRingEnd ℂ) ((toMat x).det) • (1 : Matrix (Fin 2) (Fin 2) ℂ)) ∧
    toMat wS = !![Complex.I, 0; 0, Complex.I] :=
  identification_comparison

/-! ## Axiom report -/

#print axioms task09_scalar_no_go
#print axioms task09_minimal_scalar_obstruction
#print axioms task09_central_plane
#print axioms task09_central_normal_form
#print axioms task09_forced_basis_values
#print axioms task09_old_polarization_constraints
#print axioms task09_residual_datum
#print axioms task09_rigidity
#print axioms task09_quadraticity
#print axioms task09_global_multiplicativity
#print axioms task09_old_Q4_restriction
#print axioms task09_existence
#print axioms task09_existence_Z
#print axioms task09_exact_classification
#print axioms task09_solution_space
#print axioms task09_real_line_image_impossible
#print axioms task09_S_component_attained
#print axioms task09_central_sign_action
#print axioms task09_generator_sign_tracking
#print axioms task09_part_vi_verdict
#print axioms task09_identification

end NullSectorTask09
