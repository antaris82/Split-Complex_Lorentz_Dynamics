import RequestProject.NullSectorTask08.FullVec4Embedding

/-!
# Task 08, Layer 12: uniqueness up to generator-preserving isomorphism

Two results:

1. the derived multiplication table determines a **unique** bilinear product on
   the derived eight-dimensional basis;
2. for every ambient extension the witness carrier maps isomorphically and
   multiplicatively onto the generated closure by the generator-preserving map
   `1 ↦ 1, A ↦ A, B ↦ B, C ↦ C`; consequently the minimal three-generator
   closures of any two ambient extensions are isomorphic by a
   generator-preserving, unit-preserving, multiplicative linear equivalence.
   The images of all mixed products then follow as theorems.

No conventional classification theorem is invoked.
-/

namespace NullSectorTask08

open NullSectorTask01 NullSectorTask04 NullSectorTask07

/-! ## The derived table determines the product -/

/-- The eight witness elements, as a family. -/
def witFamily8 : Fin 8 → Wit8 := ![w1, wA, wB, wC, wP, wQ, wR, wS]

theorem witFamily8_eq_basisFun (i : Fin 8) : witFamily8 i = Pi.basisFun ℝ (Fin 8) i := by
  fin_cases i <;> (funext j; fin_cases j <;>
    simp [witFamily8, w1, wA, wB, wC, wP, wQ, wR, wS, Pi.basisFun_apply])

/-- **UNIQUENESS OF THE PRODUCT.**  Two bilinear products on the derived
eight-dimensional carrier that agree on all sixty-four basis pairs are equal:
the derived multiplication table determines the product completely. -/
theorem bilinear_product_unique (m m' : Wit8 →ₗ[ℝ] Wit8 →ₗ[ℝ] Wit8)
    (h : ∀ i j : Fin 8, m (witFamily8 i) (witFamily8 j) = m' (witFamily8 i) (witFamily8 j)) :
    m = m' := by
  refine LinearMap.ext_basis (Pi.basisFun ℝ (Fin 8)) (Pi.basisFun ℝ (Fin 8)) ?_
  intro i j
  rw [← witFamily8_eq_basisFun, ← witFamily8_eq_basisFun]
  exact h i j

variable {E : Type*} [AddCommGroup E] [Module ℝ E] (S : AmbientExt E)

/-! ## The comparison map -/

/-- The generator-preserving linear map from the witness carrier into an
arbitrary ambient extension. -/
def wit8ToE : Wit8 →ₗ[ℝ] E where
  toFun x := comb8 S (x 0) (x 1) (x 2) (x 3) (x 4) (x 5) (x 6) (x 7)
  map_add' := by intro x y; simp only [Pi.add_apply, comb8]; module
  map_smul' := by
    intro c x; simp only [Pi.smul_apply, smul_eq_mul, comb8, RingHom.id_apply]; module

theorem wit8ToE_apply (x : Wit8) :
    wit8ToE S x = comb8 S (x 0) (x 1) (x 2) (x 3) (x 4) (x 5) (x 6) (x 7) := rfl

@[simp] theorem wit8ToE_w1 : wit8ToE S w1 = S.oneE := by simp [wit8ToE, w1, comb8]
@[simp] theorem wit8ToE_wA : wit8ToE S wA = S.genA := by simp [wit8ToE, wA, comb8]
@[simp] theorem wit8ToE_wB : wit8ToE S wB = S.genB := by simp [wit8ToE, wB, comb8]
@[simp] theorem wit8ToE_wC : wit8ToE S wC = genC S := by simp [wit8ToE, wC, comb8]
@[simp] theorem wit8ToE_wP : wit8ToE S wP = S.genP := by simp [wit8ToE, wP, comb8]
@[simp] theorem wit8ToE_wQ : wit8ToE S wQ = genQ S := by simp [wit8ToE, wQ, comb8]
@[simp] theorem wit8ToE_wR : wit8ToE S wR = genR S := by simp [wit8ToE, wR, comb8]
@[simp] theorem wit8ToE_wS : wit8ToE S wS = genS S := by simp [wit8ToE, wS, comb8]

/-- **MULTIPLICATIVITY.**  The comparison map intertwines the witness product
with the ambient product. -/
theorem wit8ToE_mul (x y : Wit8) :
    wit8ToE S (wit8Mul x y) = S.mul (wit8ToE S x) (wit8ToE S y) := by
  rw [wit8ToE_apply, wit8ToE_apply, wit8ToE_apply, mul_comb8]
  simp only [wit8Mul_coord_0, wit8Mul_coord_1, wit8Mul_coord_2, wit8Mul_coord_3,
    wit8Mul_coord_4, wit8Mul_coord_5, wit8Mul_coord_6, wit8Mul_coord_7]

theorem wit8ToE_injective : Function.Injective (wit8ToE S) := by
  rw [injective_iff_map_eq_zero]
  intro x hx
  rw [wit8ToE_apply] at hx
  obtain ⟨h0, h1, h2, h3, h4, h5, h6, h7⟩ := comb8_eq_zero_iff S hx
  funext i
  fin_cases i <;> simpa using ‹_›

theorem wit8ToE_mem_G3 (x : Wit8) : wit8ToE S x ∈ G3 S := comb8_mem S _ _ _ _ _ _ _ _

theorem wit8ToE_range : LinearMap.range (wit8ToE S) = G3 S := by
  apply le_antisymm
  · rintro x ⟨w, rfl⟩; exact wit8ToE_mem_G3 S w
  · intro x hx
    obtain ⟨a0, a1, a2, a3, a4, a5, a6, a7, rfl⟩ := (mem_G3_iff S x).1 hx
    exact ⟨![a0, a1, a2, a3, a4, a5, a6, a7], by simp [wit8ToE, comb8]⟩

/-- The comparison map, corestricted to the generated closure. -/
def wit8ToG3 : Wit8 →ₗ[ℝ] G3 S :=
  LinearMap.codRestrict (G3 S) (wit8ToE S) (wit8ToE_mem_G3 S)

@[simp] theorem wit8ToG3_coe (x : Wit8) : (wit8ToG3 S x : E) = wit8ToE S x := rfl

theorem wit8ToG3_bijective : Function.Bijective (wit8ToG3 S) := by
  constructor
  · intro x y hxy
    exact wit8ToE_injective S (congrArg Subtype.val hxy)
  · intro y
    obtain ⟨a0, a1, a2, a3, a4, a5, a6, a7, hy⟩ := (mem_G3_iff S (y : E)).1 y.2
    exact ⟨![a0, a1, a2, a3, a4, a5, a6, a7],
      Subtype.ext (by simp [wit8ToG3, wit8ToE, comb8, hy])⟩

/-- **EXISTENCE WITNESS ≅ GENERATED CLOSURE.**  The derived eight-dimensional
witness is linearly isomorphic to the generated closure of any ambient
extension, by the generator-preserving map. -/
noncomputable def wit8EquivG3 : Wit8 ≃ₗ[ℝ] G3 S :=
  LinearEquiv.ofBijective (wit8ToG3 S) (wit8ToG3_bijective S)

@[simp] theorem wit8EquivG3_coe (x : Wit8) : (wit8EquivG3 S x : E) = wit8ToE S x := rfl

/-! ## Uniqueness of the minimal three-generator closure -/

variable {E' : Type*} [AddCommGroup E'] [Module ℝ E']

/-- **UNIQUE UP TO ISOMORPHISM.**  The generated closures of any two ambient
extensions are linearly isomorphic by the generator-preserving map
`1 ↦ 1', A ↦ A', B ↦ B', C ↦ C'`. -/
noncomputable def closureEquiv3 (S : AmbientExt E) (S' : AmbientExt E') :
    G3 S ≃ₗ[ℝ] G3 S' :=
  (wit8EquivG3 S).symm.trans (wit8EquivG3 S')

theorem closureEquiv3_apply (S : AmbientExt E) (S' : AmbientExt E') (x : G3 S) :
    ((closureEquiv3 S S' x : E')) = wit8ToE S' ((wit8EquivG3 S).symm x) := rfl

/-- Generic transport lemma for the generator-preserving isomorphism. -/
theorem closureEquiv3_gen (S : AmbientExt E) (S' : AmbientExt E') {w : Wit8}
    {x : E} {x' : E'} (hx : wit8ToE S w = x) (hx' : wit8ToE S' w = x')
    (hmem : x ∈ G3 S) :
    ((closureEquiv3 S S' ⟨x, hmem⟩ : G3 S') : E') = x' := by
  have h : wit8EquivG3 S w = ⟨x, hmem⟩ := Subtype.ext (by simpa using hx)
  rw [closureEquiv3_apply, ← h, LinearEquiv.symm_apply_apply, hx']

/-- **UNIT COMPATIBILITY.** -/
theorem closureEquiv3_oneE (S : AmbientExt E) (S' : AmbientExt E') :
    ((closureEquiv3 S S' ⟨S.oneE, oneE_mem_G3 S⟩ : G3 S') : E') = S'.oneE :=
  closureEquiv3_gen S S' (wit8ToE_w1 S) (wit8ToE_w1 S') _

/-- **GENERATOR COMPATIBILITY (first generator).** -/
theorem closureEquiv3_genA (S : AmbientExt E) (S' : AmbientExt E') :
    ((closureEquiv3 S S' ⟨S.genA, genA_mem_G3 S⟩ : G3 S') : E') = S'.genA :=
  closureEquiv3_gen S S' (wit8ToE_wA S) (wit8ToE_wA S') _

/-- **GENERATOR COMPATIBILITY (second generator).** -/
theorem closureEquiv3_genB (S : AmbientExt E) (S' : AmbientExt E') :
    ((closureEquiv3 S S' ⟨S.genB, genB_mem_G3 S⟩ : G3 S') : E') = S'.genB :=
  closureEquiv3_gen S S' (wit8ToE_wB S) (wit8ToE_wB S') _

/-- **GENERATOR COMPATIBILITY (third generator).** -/
theorem closureEquiv3_genC (S : AmbientExt E) (S' : AmbientExt E') :
    ((closureEquiv3 S S' ⟨genC S, genC_mem_G3 S⟩ : G3 S') : E') = genC S' :=
  closureEquiv3_gen S S' (wit8ToE_wC S) (wit8ToE_wC S') _

/-- **THEOREM, NOT INPUT: the images of the mixed channels.** -/
theorem closureEquiv3_mixed (S : AmbientExt E) (S' : AmbientExt E') :
    ((closureEquiv3 S S' ⟨S.genP, genP_mem_G3 S⟩ : G3 S') : E') = S'.genP ∧
    ((closureEquiv3 S S' ⟨genQ S, genQ_mem_G3 S⟩ : G3 S') : E') = genQ S' ∧
    ((closureEquiv3 S S' ⟨genR S, genR_mem_G3 S⟩ : G3 S') : E') = genR S' ∧
    ((closureEquiv3 S S' ⟨genS S, genS_mem_G3 S⟩ : G3 S') : E') = genS S' :=
  ⟨closureEquiv3_gen S S' (wit8ToE_wP S) (wit8ToE_wP S') _,
   closureEquiv3_gen S S' (wit8ToE_wQ S) (wit8ToE_wQ S') _,
   closureEquiv3_gen S S' (wit8ToE_wR S) (wit8ToE_wR S') _,
   closureEquiv3_gen S S' (wit8ToE_wS S) (wit8ToE_wS S') _⟩

/-- **MULTIPLICATIVE COMPATIBILITY** of the closure isomorphism. -/
theorem closureEquiv3_mul (S : AmbientExt E) (S' : AmbientExt E') (x y : G3 S) :
    ((closureEquiv3 S S' ⟨S.mul (x : E) (y : E), G3_mul_closed S x.2 y.2⟩ : G3 S') : E')
      = S'.mul (closureEquiv3 S S' x) (closureEquiv3 S S' y) := by
  set u := (wit8EquivG3 S).symm x with hu
  set v := (wit8EquivG3 S).symm y with hv
  have hx : (x : E) = wit8ToE S u := by
    rw [hu, ← wit8EquivG3_coe, LinearEquiv.apply_symm_apply]
  have hy : (y : E) = wit8ToE S v := by
    rw [hv, ← wit8EquivG3_coe, LinearEquiv.apply_symm_apply]
  have hxy : wit8EquivG3 S (wit8Mul u v)
      = ⟨S.mul (x : E) (y : E), G3_mul_closed S x.2 y.2⟩ := by
    apply Subtype.ext
    rw [wit8EquivG3_coe, wit8ToE_mul, ← hx, ← hy]
  rw [closureEquiv3_apply, ← hxy, LinearEquiv.symm_apply_apply, wit8ToE_mul]
  rfl

end NullSectorTask08
