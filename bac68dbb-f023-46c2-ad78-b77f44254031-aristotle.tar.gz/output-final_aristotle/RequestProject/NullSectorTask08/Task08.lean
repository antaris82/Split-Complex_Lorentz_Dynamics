import RequestProject.NullSectorTask08.Identification

/-!
# Task 08: principal theorems

This top-level module imports the complete Task-08 development and states the
principal results under stable names, followed by the axiom report.

The reconstruction chain (source order, each module importing only its
predecessor) is

```
SafeBase → ThirdDirection → InheritedRelations → NewMixedProducts →
ForcedRelations → Membership → Independence → GeneratedClosure → Minimality →
StructuralDiagnostic → DirectWitness → FullVec4Embedding → Uniqueness →
SignPermutationAudit → Identification (COMPARISON ONLY)
```

`Identification.lean` is imported only here and by nothing else.

## Outcome

**Outcome C.**  Three new independent product directions are forced (`Q = A⋆C`,
`R = B⋆C`, `S₃ = (A⋆B)⋆C`); none of them lies in the old carrier or in the
Task-07 two-generator closure; the eight derived elements are independent, the
span closes multiplicatively, its dimension is exactly `8`, it is the minimal
associative closure containing the three inherited spatial generators, and a
direct eight-dimensional witness carries an injective copy of the *complete*
old carrier on which the inherited square law and the whole inherited
symmetric product are reproduced.

**TASK07 FULL-AMBIENT EXISTENCE OBLIGATION RESOLVED POSITIVELY**
(`task08_ambient_existence`, witnessed by `wit8Ambient`).
-/

namespace NullSectorTask08

open NullSectorTask01 NullSectorTask04 NullSectorTask07

variable {E : Type*} [AddCommGroup E] [Module ℝ E]

/-! ## 1. Inherited old-carrier data -/

/-- **INHERITED.**  Orthogonality and normalization of the four selected old
vectors. -/
theorem task08_old_carrier_data :
    L4 e₀ dirA = 0 ∧ L4 e₀ dirB = 0 ∧ L4 e₀ dirC = 0 ∧
    Q4 dirA = -1 ∧ Q4 dirB = -1 ∧ Q4 dirC = -1 ∧
    L4 dirA dirB = 0 ∧ L4 dirA dirC = 0 ∧ L4 dirB dirC = 0 :=
  old_carrier_data

/-! ## 2. The third generator, its square, and inherited anticommutation -/

/-- **DERIVED.**  `C ⋆ C = 1`, forced by the inherited old square law. -/
theorem task08_third_generator_square (S : AmbientExt E) :
    S.mul (genC S) (genC S) = S.oneE := genC_sq S

/-- **DERIVED.**  Pairwise anticommutation of the three inherited spatial
generators, forced by polarization of the old square law and orthogonality. -/
theorem task08_pairwise_anticommutation (S : AmbientExt E) :
    S.mul S.genA S.genB + S.mul S.genB S.genA = 0 ∧
    S.mul S.genA (genC S) + S.mul (genC S) S.genA = 0 ∧
    S.mul S.genB (genC S) + S.mul (genC S) S.genB = 0 :=
  pairwise_anticommutation S

/-! ## 3. The new mixed products and the forced relation ledger -/

/-- **DERIVED.**  Associativity identifies all parenthesizations of the triple
product; `(A⋆C)⋆B` is its negative. -/
theorem task08_parenthesizations (S : AmbientExt E) :
    genS S = S.mul (S.mul S.genA S.genB) (genC S) ∧
    genS S = S.mul S.genA (S.mul S.genB (genC S)) ∧
    S.mul (S.mul S.genA (genC S)) S.genB = - genS S :=
  genS_parenthesizations S

/-- **FORCED RELATIONS.**  The complete ledger of products of the old
generators with the new channels, of the channels with `P`, and of the channels
among themselves, including their squares. -/
theorem task08_forced_relations (S : AmbientExt E) :
    (S.mul S.genA (genQ S) = genC S ∧ S.mul (genQ S) S.genA = - genC S ∧
      S.mul S.genB (genQ S) = - genS S ∧ S.mul (genQ S) S.genB = - genS S ∧
      S.mul (genC S) (genQ S) = - S.genA ∧ S.mul (genQ S) (genC S) = S.genA ∧
      S.mul S.genA (genR S) = genS S ∧ S.mul (genR S) S.genA = genS S ∧
      S.mul S.genB (genR S) = genC S ∧ S.mul (genR S) S.genB = - genC S ∧
      S.mul (genC S) (genR S) = - S.genB ∧ S.mul (genR S) (genC S) = S.genB) ∧
    (S.mul S.genA (genS S) = genR S ∧ S.mul (genS S) S.genA = genR S ∧
      S.mul S.genB (genS S) = - genQ S ∧ S.mul (genS S) S.genB = - genQ S ∧
      S.mul (genC S) (genS S) = S.genP ∧ S.mul (genS S) (genC S) = S.genP) ∧
    (S.mul S.genP (genQ S) = - genR S ∧ S.mul (genQ S) S.genP = genR S ∧
      S.mul S.genP (genR S) = genQ S ∧ S.mul (genR S) S.genP = - genQ S ∧
      S.mul S.genP (genS S) = - genC S ∧ S.mul (genS S) S.genP = - genC S) ∧
    (S.mul (genQ S) (genQ S) = - S.oneE ∧ S.mul (genR S) (genR S) = - S.oneE ∧
      S.mul (genS S) (genS S) = - S.oneE ∧
      S.mul (genQ S) (genR S) = - S.genP ∧ S.mul (genR S) (genQ S) = S.genP ∧
      S.mul (genQ S) (genS S) = S.genB ∧ S.mul (genS S) (genQ S) = S.genB ∧
      S.mul (genR S) (genS S) = - S.genA ∧ S.mul (genS S) (genR S) = - S.genA) :=
  ⟨forced_relations_old_generators S, forced_relations_genS S,
    forced_relations_genP S, forced_relations_new_channels S⟩

/-! ## 4. Membership classification -/

/-- **OUTSIDE OLD CARRIER.**  `C` is an embedded old vector; `P`, `Q`, `R`, `S₃`
are not. -/
theorem task08_old_carrier_membership (S : AmbientExt E) :
    genC S ∈ LinearMap.range S.iota ∧
    S.genP ∉ LinearMap.range S.iota ∧
    genQ S ∉ LinearMap.range S.iota ∧
    genR S ∉ LinearMap.range S.iota ∧
    genS S ∉ LinearMap.range S.iota :=
  old_carrier_classification S

/-- **OUTSIDE TWO-GENERATOR CLOSURE.**  None of `C, Q, R, S₃` lies in the
Task-07 closure `G₂ = span {1, A, B, P}`. -/
theorem task08_two_generator_closure_membership (S : AmbientExt E) :
    genC S ∉ S.Gsub ∧ genQ S ∉ S.Gsub ∧ genR S ∉ S.Gsub ∧ genS S ∉ S.Gsub :=
  Gsub_membership_classification S

/-! ## 5. Independence, closure, dimension, minimality -/

/-- **INDEPENDENT.**  The eight derived elements are linearly independent; no
dependency occurs. -/
theorem task08_linear_independence (S : AmbientExt E) :
    LinearIndependent ℝ (genFamily8 S) := genFamily8_linearIndependent S

/-- **NORMAL FORM.**  Existence and uniqueness of the eight-coefficient normal
form on the generated span. -/
theorem task08_normal_form (S : AmbientExt E) :
    (∀ x ∈ G3 S, ∃ a0 a1 a2 a3 a4 a5 a6 a7 : ℝ, x = comb8 S a0 a1 a2 a3 a4 a5 a6 a7) ∧
    (∀ a0 a1 a2 a3 a4 a5 a6 a7 b0 b1 b2 b3 b4 b5 b6 b7 : ℝ,
      comb8 S a0 a1 a2 a3 a4 a5 a6 a7 = comb8 S b0 b1 b2 b3 b4 b5 b6 b7 →
        a0 = b0 ∧ a1 = b1 ∧ a2 = b2 ∧ a3 = b3 ∧ a4 = b4 ∧ a5 = b5 ∧ a6 = b6 ∧ a7 = b7) :=
  ⟨fun x hx => (mem_G3_iff S x).1 hx, fun _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ h =>
    comb8_injective S h⟩

/-- **CLOSED — THREE-GENERATOR ASSOCIATIVE CLOSURE ACHIEVED.** -/
theorem task08_closure (S : AmbientExt E) :
    S.oneE ∈ G3 S ∧ S.genA ∈ G3 S ∧ S.genB ∈ G3 S ∧ genC S ∈ G3 S ∧
      ∀ x ∈ G3 S, ∀ y ∈ G3 S, S.mul x y ∈ G3 S :=
  G3_is_closed_subspace S

/-- **EXACT DIMENSION.**  `finrank_ℝ G₃ = 8`, an output of the reconstruction. -/
theorem task08_dimension (S : AmbientExt E) : Module.finrank ℝ (G3 S) = 8 :=
  finrank_G3 S

/-- **MINIMAL.**  `G₃` is contained in every product-closed subspace containing
the unit and the three inherited spatial generators, and is itself one. -/
theorem task08_minimality (S : AmbientExt E) :
    IsGenClosed3 S (G3 S) ∧ ∀ H : Submodule ℝ E, IsGenClosed3 S H → G3 S ≤ H :=
  G3_least S

/-- **WORD REDUCTION.**  Every associative word in `A, B, C` reduces to the
derived normal-form basis. -/
theorem task08_word_reduction (S : AmbientExt E) (H : Submodule ℝ E)
    (hH : IsGenClosed3 S H) :
    G3 S ≤ H ∧ ∀ x ∈ G3 S, ∃ a0 a1 a2 a3 a4 a5 a6 a7 : ℝ,
      x = comb8 S a0 a1 a2 a3 a4 a5 a6 a7 :=
  word_reduction S H hH

/-! ## 6. The complete derived multiplication table -/

/-- **DERIVED MULTIPLICATION TABLE.**  All sixty-four products of the derived
basis, collected only after closure was proved. -/
theorem task08_multiplication_table (S : AmbientExt E) :
    (S.mul S.oneE S.oneE = S.oneE ∧ S.mul S.oneE S.genA = S.genA ∧
      S.mul S.oneE S.genB = S.genB ∧ S.mul S.oneE (genC S) = genC S ∧
      S.mul S.oneE S.genP = S.genP ∧ S.mul S.oneE (genQ S) = genQ S ∧
      S.mul S.oneE (genR S) = genR S ∧ S.mul S.oneE (genS S) = genS S) ∧
    (S.mul S.genA S.oneE = S.genA ∧ S.mul S.genA S.genA = S.oneE ∧
      S.mul S.genA S.genB = S.genP ∧ S.mul S.genA (genC S) = genQ S ∧
      S.mul S.genA S.genP = S.genB ∧ S.mul S.genA (genQ S) = genC S ∧
      S.mul S.genA (genR S) = genS S ∧ S.mul S.genA (genS S) = genR S) ∧
    (S.mul S.genB S.oneE = S.genB ∧ S.mul S.genB S.genA = - S.genP ∧
      S.mul S.genB S.genB = S.oneE ∧ S.mul S.genB (genC S) = genR S ∧
      S.mul S.genB S.genP = - S.genA ∧ S.mul S.genB (genQ S) = - genS S ∧
      S.mul S.genB (genR S) = genC S ∧ S.mul S.genB (genS S) = - genQ S) ∧
    (S.mul (genC S) S.oneE = genC S ∧ S.mul (genC S) S.genA = - genQ S ∧
      S.mul (genC S) S.genB = - genR S ∧ S.mul (genC S) (genC S) = S.oneE ∧
      S.mul (genC S) S.genP = genS S ∧ S.mul (genC S) (genQ S) = - S.genA ∧
      S.mul (genC S) (genR S) = - S.genB ∧ S.mul (genC S) (genS S) = S.genP) ∧
    (S.mul S.genP S.oneE = S.genP ∧ S.mul S.genP S.genA = - S.genB ∧
      S.mul S.genP S.genB = S.genA ∧ S.mul S.genP (genC S) = genS S ∧
      S.mul S.genP S.genP = - S.oneE ∧ S.mul S.genP (genQ S) = - genR S ∧
      S.mul S.genP (genR S) = genQ S ∧ S.mul S.genP (genS S) = - genC S) ∧
    (S.mul (genQ S) S.oneE = genQ S ∧ S.mul (genQ S) S.genA = - genC S ∧
      S.mul (genQ S) S.genB = - genS S ∧ S.mul (genQ S) (genC S) = S.genA ∧
      S.mul (genQ S) S.genP = genR S ∧ S.mul (genQ S) (genQ S) = - S.oneE ∧
      S.mul (genQ S) (genR S) = - S.genP ∧ S.mul (genQ S) (genS S) = S.genB) ∧
    (S.mul (genR S) S.oneE = genR S ∧ S.mul (genR S) S.genA = genS S ∧
      S.mul (genR S) S.genB = - genC S ∧ S.mul (genR S) (genC S) = S.genB ∧
      S.mul (genR S) S.genP = - genQ S ∧ S.mul (genR S) (genQ S) = S.genP ∧
      S.mul (genR S) (genR S) = - S.oneE ∧ S.mul (genR S) (genS S) = - S.genA) ∧
    (S.mul (genS S) S.oneE = genS S ∧ S.mul (genS S) S.genA = genR S ∧
      S.mul (genS S) S.genB = - genQ S ∧ S.mul (genS S) (genC S) = S.genP ∧
      S.mul (genS S) S.genP = - genC S ∧ S.mul (genS S) (genQ S) = S.genB ∧
      S.mul (genS S) (genR S) = - S.genA ∧ S.mul (genS S) (genS S) = - S.oneE) :=
  ⟨table_one S, table_genA S, table_genB S, table_genC S, table_genP S,
    table_genQ S, table_genR S, table_genS S⟩

/-! ## 7. Structural diagnostic for the highest channel -/

/-- **DIAGNOSTIC.**  `S₃` commutes with every derived generator (no
anticommuting case occurs) and `S₃ ⋆ S₃ = -1`. -/
theorem task08_structural_diagnostic (S : AmbientExt E) :
    S.mul S.genA (genS S) = S.mul (genS S) S.genA ∧
    S.mul S.genB (genS S) = S.mul (genS S) S.genB ∧
    S.mul (genC S) (genS S) = S.mul (genS S) (genC S) ∧
    S.mul S.genP (genS S) = S.mul (genS S) S.genP ∧
    S.mul (genQ S) (genS S) = S.mul (genS S) (genQ S) ∧
    S.mul (genR S) (genS S) = S.mul (genS S) (genR S) ∧
    S.mul (genS S) (genS S) = - S.oneE :=
  genS_diagnostic S

/-! ## 8. The direct finite-dimensional witness -/

/-- **EXISTENCE WITNESS.**  An eight-dimensional real carrier with a bilinear,
unital, associative product satisfying exactly the derived relations. -/
theorem task08_witness :
    AssociativeE wit8Mul ∧ TwoSidedUnitE wit8Mul w1 ∧
    (wit8Mul wA wA = w1 ∧ wit8Mul wB wB = w1 ∧ wit8Mul wC wC = w1) ∧
    (wit8Mul wA wB + wit8Mul wB wA = 0 ∧ wit8Mul wA wC + wit8Mul wC wA = 0 ∧
      wit8Mul wB wC + wit8Mul wC wB = 0) ∧
    (wit8Mul wA wB = wP ∧ wit8Mul wA wC = wQ ∧ wit8Mul wB wC = wR ∧
      wit8Mul wP wC = wS) :=
  wit8_summary

/-! ## 9. The full old-carrier embedding — critical theorem -/

/-- **FULL OLD-CARRIER EMBEDDING.**  The complete original carrier embeds
linearly and injectively into the witness, the inherited old square law holds
for every embedded old vector, and polarization recovers the complete inherited
symmetric product. -/
theorem task08_full_vec4_embedding :
    Function.Injective iota3 ∧
    (∀ X : Vec4, iota3 (oldSq X) = wit8Mul (iota3 X) (iota3 X)) ∧
    (∀ X Y : Vec4, wit8Mul (iota3 X) (iota3 Y) + wit8Mul (iota3 Y) (iota3 X)
      = (2 : ℝ) • iota3 (musym X Y)) :=
  iota3_full_old_structure

/-- **THERE EXISTS A REAL ASSOCIATIVE AMBIENT EXTENSION OF THE COMPLETE OLD
`Vec4` CARRIER PRESERVING THE INHERITED OLD SQUARE LAW.**  This resolves the
Task-07 full-ambient existence obligation positively. -/
theorem task08_ambient_existence : Nonempty (AmbientExt Wit8) := ambient_existence

/-- The same, spelled out in terms of the abstract interface data. -/
theorem task08_ambient_existence_explicit :
    ∃ (m : Wit8 →ₗ[ℝ] Wit8 →ₗ[ℝ] Wit8) (u : Wit8) (j : Vec4 →ₗ[ℝ] Wit8),
      AssociativeE m ∧ TwoSidedUnitE m u ∧ Function.Injective j ∧ j e₀ = u ∧
        ∀ X : Vec4, m (j X) (j X) = j (oldSq X) :=
  ambient_existence_explicit

/-! ## 10. Uniqueness -/

/-- **UNIQUE UP TO ISOMORPHISM.**  The minimal three-generator closures of any
two ambient extensions are linearly isomorphic by the generator-preserving map,
which preserves the unit, the three generators, all four derived mixed channels
and the product. -/
theorem task08_uniqueness {E' : Type*} [AddCommGroup E'] [Module ℝ E']
    (S : AmbientExt E) (S' : AmbientExt E') :
    ((closureEquiv3 S S' ⟨S.oneE, oneE_mem_G3 S⟩ : G3 S') : E') = S'.oneE ∧
    ((closureEquiv3 S S' ⟨S.genA, genA_mem_G3 S⟩ : G3 S') : E') = S'.genA ∧
    ((closureEquiv3 S S' ⟨S.genB, genB_mem_G3 S⟩ : G3 S') : E') = S'.genB ∧
    ((closureEquiv3 S S' ⟨genC S, genC_mem_G3 S⟩ : G3 S') : E') = genC S' ∧
    ((closureEquiv3 S S' ⟨S.genP, genP_mem_G3 S⟩ : G3 S') : E') = S'.genP ∧
    ((closureEquiv3 S S' ⟨genQ S, genQ_mem_G3 S⟩ : G3 S') : E') = genQ S' ∧
    ((closureEquiv3 S S' ⟨genR S, genR_mem_G3 S⟩ : G3 S') : E') = genR S' ∧
    ((closureEquiv3 S S' ⟨genS S, genS_mem_G3 S⟩ : G3 S') : E') = genS S' ∧
    (∀ x y : G3 S,
      ((closureEquiv3 S S' ⟨S.mul (x : E) (y : E), G3_mul_closed S x.2 y.2⟩ : G3 S') : E')
        = S'.mul (closureEquiv3 S S' x) (closureEquiv3 S S' y)) :=
  ⟨closureEquiv3_oneE S S', closureEquiv3_genA S S', closureEquiv3_genB S S',
    closureEquiv3_genC S S', (closureEquiv3_mixed S S').1,
    (closureEquiv3_mixed S S').2.1, (closureEquiv3_mixed S S').2.2.1,
    (closureEquiv3_mixed S S').2.2.2, closureEquiv3_mul S S'⟩

/-- **UNIQUENESS OF THE PRODUCT.**  The derived table determines the bilinear
product on the eight-dimensional carrier completely. -/
theorem task08_product_uniqueness (m m' : Wit8 →ₗ[ℝ] Wit8 →ₗ[ℝ] Wit8)
    (h : ∀ i j : Fin 8, m (witFamily8 i) (witFamily8 j) = m' (witFamily8 i) (witFamily8 j)) :
    m = m' := bilinear_product_unique m m' h

/-! ## 11. Sign and permutation audit -/

/-- **DIAGNOSTIC.**  The highest channel changes sign under each transposition
of two generators and under each single sign flip, and is invariant under the
tested cyclic permutation. -/
theorem task08_sign_permutation_audit (S : AmbientExt E) :
    S.mul (S.mul S.genB S.genA) (genC S) = - genS S ∧
    S.mul (S.mul (genC S) S.genB) S.genA = - genS S ∧
    S.mul (S.mul S.genA (genC S)) S.genB = - genS S ∧
    S.mul (S.mul S.genB (genC S)) S.genA = genS S :=
  genS_permutation_summary S

/-! ## 12. Task-07 versus Task-08 structural comparison -/

/-- **STRUCTURAL INCLUSION.**  The Task-07 two-generator closure is a *proper*
subspace of the Task-08 three-generator closure; the Task-08 closure contains
it together with the four new directions `C, Q, R, S₃`. -/
theorem task08_task07_comparison (S : AmbientExt E) :
    S.Gsub < G3 S ∧ genC S ∈ G3 S ∧ genQ S ∈ G3 S ∧ genR S ∈ G3 S ∧ genS S ∈ G3 S ∧
      Module.finrank ℝ S.Gsub = 4 ∧ Module.finrank ℝ (G3 S) = 8 :=
  ⟨Gsub_lt_G3 S, genC_mem_G3 S, genQ_mem_G3 S, genR_mem_G3 S, genS_mem_G3 S,
    S.finrank_Gsub, finrank_G3 S⟩

/-! ## 13. Late conventional identification (COMPARISON ONLY) -/

/-- **COMPARISON ONLY.**  The reconstructed algebra is isomorphic, as a real
algebra, to the algebra of `2 × 2` complex matrices, via an explicit
real-linear, unital, multiplicative bijection.  No earlier result depends on
this. -/
theorem task08_identification :
    (∀ x y : Wit8, toMat (x + y) = toMat x + toMat y) ∧
    (∀ (c : ℝ) (x : Wit8), toMat (c • x) = c • toMat x) ∧
    (∀ x y : Wit8, toMat (wit8Mul x y) = toMat x * toMat y) ∧
    toMat w1 = 1 ∧ Function.Bijective toMat :=
  identification

/-! ## Axiom report -/

#print axioms task08_old_carrier_data
#print axioms task08_third_generator_square
#print axioms task08_pairwise_anticommutation
#print axioms task08_parenthesizations
#print axioms task08_forced_relations
#print axioms task08_old_carrier_membership
#print axioms task08_two_generator_closure_membership
#print axioms task08_linear_independence
#print axioms task08_normal_form
#print axioms task08_closure
#print axioms task08_dimension
#print axioms task08_minimality
#print axioms task08_word_reduction
#print axioms task08_multiplication_table
#print axioms task08_structural_diagnostic
#print axioms task08_witness
#print axioms task08_full_vec4_embedding
#print axioms task08_ambient_existence
#print axioms task08_ambient_existence_explicit
#print axioms task08_uniqueness
#print axioms task08_product_uniqueness
#print axioms task08_sign_permutation_audit
#print axioms task08_task07_comparison
#print axioms task08_identification

end NullSectorTask08
