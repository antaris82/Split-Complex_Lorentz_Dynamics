import RequestProject.NullSectorTask08.Uniqueness

/-!
# Task 08, Layer 13: generator permutation and sign audit

A narrow structural diagnostic.  For each permutation or sign flip of the three
inherited spatial generators the four derived mixed channels are recomputed
*from their definitions* (a product of generators in the permuted order) and
compared with the original ones.  No sign is assumed; each is a consequence of
the derived pairwise anticommutation relations and associativity.

Notation: for a generator triple `(g₁, g₂, g₃)` the corresponding channels are

```
P' := g₁ ⋆ g₂,  Q' := g₁ ⋆ g₃,  R' := g₂ ⋆ g₃,  S' := (g₁ ⋆ g₂) ⋆ g₃.
```

No geometric interpretation is attached to the outcome.
-/

namespace NullSectorTask08

open NullSectorTask01 NullSectorTask04 NullSectorTask07

variable {E : Type*} [AddCommGroup E] [Module ℝ E] (S : AmbientExt E)

/-! ## Exchange `A ↔ B`, i.e. the triple `(B, A, C)` -/

theorem swapAB_channels :
    S.mul S.genB S.genA = - S.genP ∧
    S.mul S.genB (genC S) = genR S ∧
    S.mul S.genA (genC S) = genQ S ∧
    S.mul (S.mul S.genB S.genA) (genC S) = - genS S := by
  refine ⟨S.mul_genB_genA, mul_genB_genC S, mul_genA_genC S, ?_⟩
  rw [S.mul_genB_genA, mul_neg_left, mul_genP_genC]

/-! ## Exchange `A ↔ C`, i.e. the triple `(C, B, A)` -/

theorem swapAC_channels :
    S.mul (genC S) S.genB = - genR S ∧
    S.mul (genC S) S.genA = - genQ S ∧
    S.mul S.genB S.genA = - S.genP ∧
    S.mul (S.mul (genC S) S.genB) S.genA = - genS S := by
  refine ⟨mul_genC_genB S, mul_genC_genA S, S.mul_genB_genA, ?_⟩
  rw [mul_genC_genB, mul_neg_left, mul_genR_genA]

/-! ## Exchange `B ↔ C`, i.e. the triple `(A, C, B)` -/

theorem swapBC_channels :
    S.mul S.genA (genC S) = genQ S ∧
    S.mul S.genA S.genB = S.genP ∧
    S.mul (genC S) S.genB = - genR S ∧
    S.mul (S.mul S.genA (genC S)) S.genB = - genS S :=
  ⟨mul_genA_genC S, S.mul_genA_genB, mul_genC_genB S, genQ_mul_genB S⟩

/-! ## The cyclic permutation `A → B → C → A`, i.e. the triple `(B, C, A)` -/

theorem cyclic_channels :
    S.mul S.genB (genC S) = genR S ∧
    S.mul S.genB S.genA = - S.genP ∧
    S.mul (genC S) S.genA = - genQ S ∧
    S.mul (S.mul S.genB (genC S)) S.genA = genS S :=
  ⟨mul_genB_genC S, S.mul_genB_genA, mul_genC_genA S, mul_genR_genA S⟩

/-! ## Sign flips, one generator at a time -/

/-- `A ↦ -A`: `P ↦ -P`, `Q ↦ -Q`, `R ↦ R`, `S₃ ↦ -S₃`. -/
theorem negA_channels :
    S.mul (- S.genA) S.genB = - S.genP ∧
    S.mul (- S.genA) (genC S) = - genQ S ∧
    S.mul S.genB (genC S) = genR S ∧
    S.mul (S.mul (- S.genA) S.genB) (genC S) = - genS S := by
  refine ⟨by rw [mul_neg_left, S.mul_genA_genB], by rw [mul_neg_left, mul_genA_genC],
    mul_genB_genC S, ?_⟩
  rw [mul_neg_left, S.mul_genA_genB, mul_neg_left, mul_genP_genC]

/-- `B ↦ -B`: `P ↦ -P`, `Q ↦ Q`, `R ↦ -R`, `S₃ ↦ -S₃`. -/
theorem negB_channels :
    S.mul S.genA (- S.genB) = - S.genP ∧
    S.mul S.genA (genC S) = genQ S ∧
    S.mul (- S.genB) (genC S) = - genR S ∧
    S.mul (S.mul S.genA (- S.genB)) (genC S) = - genS S := by
  refine ⟨by rw [mul_neg_right, S.mul_genA_genB], mul_genA_genC S,
    by rw [mul_neg_left, mul_genB_genC], ?_⟩
  rw [mul_neg_right, S.mul_genA_genB, mul_neg_left, mul_genP_genC]

/-- `C ↦ -C`: `P ↦ P`, `Q ↦ -Q`, `R ↦ -R`, `S₃ ↦ -S₃`. -/
theorem negC_channels :
    S.mul S.genA S.genB = S.genP ∧
    S.mul S.genA (- genC S) = - genQ S ∧
    S.mul S.genB (- genC S) = - genR S ∧
    S.mul (S.mul S.genA S.genB) (- genC S) = - genS S := by
  refine ⟨S.mul_genA_genB, by rw [mul_neg_right, mul_genA_genC],
    by rw [mul_neg_right, mul_genB_genC], ?_⟩
  rw [S.mul_genA_genB, mul_neg_right, mul_genP_genC]

/-- **SIGN AND PERMUTATION AUDIT (summary).**  The highest channel `S₃` changes
sign under every transposition of two generators and under every single sign
flip, and is invariant under the tested cyclic permutation. -/
theorem genS_permutation_summary :
    S.mul (S.mul S.genB S.genA) (genC S) = - genS S ∧
    S.mul (S.mul (genC S) S.genB) S.genA = - genS S ∧
    S.mul (S.mul S.genA (genC S)) S.genB = - genS S ∧
    S.mul (S.mul S.genB (genC S)) S.genA = genS S :=
  ⟨(swapAB_channels S).2.2.2, (swapAC_channels S).2.2.2,
    (swapBC_channels S).2.2.2, (cyclic_channels S).2.2.2⟩

end NullSectorTask08
