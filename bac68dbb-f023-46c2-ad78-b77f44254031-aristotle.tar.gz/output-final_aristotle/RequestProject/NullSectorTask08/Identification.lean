import RequestProject.NullSectorTask08.SignPermutationAudit

/-!
# Task 08, Layer 14: late conventional identification — COMPARISON ONLY

Everything asked of Task 08 has already been established without this module:
the forced relations, the membership classification, linear independence,
closure, the exact dimension, minimality, the direct finite-dimensional
witness, the full old-carrier embedding, square preservation, recovery of the
symmetric product and uniqueness.  **No earlier Task-08 result depends on this
file**, and no reconstruction module imports it.

Only now may the question be asked: is the independently reconstructed
eight-dimensional real algebra conventionally known?  The answer is yes: the
explicit real-linear map below is bijective, unital and multiplicative onto the
algebra of `2 × 2` complex matrices regarded as a real algebra.  The
identification is a *comparison* and is used nowhere else.
-/

namespace NullSectorTask08

/-- The comparison map into `2 × 2` complex matrices. -/
noncomputable def toMat (x : Wit8) : Matrix (Fin 2) (Fin 2) ℂ :=
  !![((x 0 + x 3 : ℝ) : ℂ) + ((x 4 + x 7 : ℝ) : ℂ) * Complex.I,
     ((x 1 - x 5 : ℝ) : ℂ) + ((-x 2 + x 6 : ℝ) : ℂ) * Complex.I;
     ((x 1 + x 5 : ℝ) : ℂ) + ((x 2 + x 6 : ℝ) : ℂ) * Complex.I,
     ((x 0 - x 3 : ℝ) : ℂ) + ((-x 4 + x 7 : ℝ) : ℂ) * Complex.I]

/-- The inverse comparison map. -/
noncomputable def fromMat (M : Matrix (Fin 2) (Fin 2) ℂ) : Wit8 :=
  ![((M 0 0).re + (M 1 1).re) / 2, ((M 0 1).re + (M 1 0).re) / 2,
    ((M 1 0).im - (M 0 1).im) / 2, ((M 0 0).re - (M 1 1).re) / 2,
    ((M 0 0).im - (M 1 1).im) / 2, ((M 1 0).re - (M 0 1).re) / 2,
    ((M 0 1).im + (M 1 0).im) / 2, ((M 0 0).im + (M 1 1).im) / 2]

/-- **COMPARISON ONLY: multiplicativity.** -/
theorem toMat_mul (x y : Wit8) : toMat (wit8Mul x y) = toMat x * toMat y := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [toMat, Matrix.mul_apply, Fin.sum_univ_two, Complex.ext_iff] <;>
    constructor <;> ring

/-- **COMPARISON ONLY: the unit is preserved.** -/
theorem toMat_one : toMat w1 = 1 := by
  ext i j
  fin_cases i <;> fin_cases j <;> simp [toMat, w1]

/-- **COMPARISON ONLY: additivity.** -/
theorem toMat_add (x y : Wit8) : toMat (x + y) = toMat x + toMat y := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [toMat, Complex.ext_iff] <;> constructor <;> ring

/-- **COMPARISON ONLY: real homogeneity.** -/
theorem toMat_smul (c : ℝ) (x : Wit8) : toMat (c • x) = c • toMat x := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [toMat, Complex.ext_iff, Complex.real_smul] <;> (try constructor) <;> ring

theorem fromMat_toMat (x : Wit8) : fromMat (toMat x) = x := by
  funext i
  fin_cases i <;> simp [toMat, fromMat] <;> ring

theorem toMat_fromMat (M : Matrix (Fin 2) (Fin 2) ℂ) : toMat (fromMat M) = M := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [toMat, fromMat, Complex.ext_iff] <;> constructor <;> ring

/-- **COMPARISON ONLY: bijectivity.** -/
theorem toMat_bijective : Function.Bijective toMat :=
  Function.bijective_iff_has_inverse.2 ⟨fromMat, fromMat_toMat, toMat_fromMat⟩

/-! ## Images of the derived basis -/

theorem toMat_wA : toMat wA = !![0, 1; 1, 0] := by
  ext i j; fin_cases i <;> fin_cases j <;> simp [toMat, wA]

theorem toMat_wB : toMat wB = !![0, -Complex.I; Complex.I, 0] := by
  ext i j; fin_cases i <;> fin_cases j <;> simp [toMat, wB]

theorem toMat_wC : toMat wC = !![1, 0; 0, -1] := by
  ext i j; fin_cases i <;> fin_cases j <;> simp [toMat, wC]

theorem toMat_wS : toMat wS = !![Complex.I, 0; 0, Complex.I] := by
  ext i j; fin_cases i <;> fin_cases j <;> simp [toMat, wS]

/-- **CONVENTIONAL IDENTIFICATION (COMPARISON ONLY).**  The independently
reconstructed minimal three-generator closure is isomorphic, as a real algebra,
to the algebra of `2 × 2` complex matrices: the explicit map `toMat` is
real-linear, bijective, unital and multiplicative.  This is a comparison
statement only; no Task-08 reconstruction result depends on it. -/
theorem identification :
    (∀ x y : Wit8, toMat (x + y) = toMat x + toMat y) ∧
    (∀ (c : ℝ) (x : Wit8), toMat (c • x) = c • toMat x) ∧
    (∀ x y : Wit8, toMat (wit8Mul x y) = toMat x * toMat y) ∧
    toMat w1 = 1 ∧ Function.Bijective toMat :=
  ⟨toMat_add, toMat_smul, toMat_mul, toMat_one, toMat_bijective⟩

end NullSectorTask08
