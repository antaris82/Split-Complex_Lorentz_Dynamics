import RequestProject.NullSectorTask20.Identification

/-!
# Task 20 — Intrinsic Equivalence and Structure Audit: principal endpoints

This module imports the complete Task-20 development and exposes the principal final
theorems.  It is the only module that imports the Task-20 comparison-only module
`Identification`.

## Source order

`SafeBase → LiftCarrier → InternalProjection → VisibleQuotient → BridgeTorsor
→ ReversalQuotient → GlobalObstruction → SectionObstruction → NegativeControls
→ Identification (COMPARISON ONLY) → Task20`

## Status table

| endpoint | Lean name | status |
| --- | --- | --- |
| visible equality is an equivalence, quotient built | `task20_visible_quotient` | `PROVED` |
| unique factorization and bijection onto the visible image | `task20_visible_quotient` | `PROVED` |
| quotient topology = subspace topology on the visible image | `task20_quotient_topology` | `PROVED` |
| the visible image is closed under composition and inversion | `task20_visible_group_law` | `PROVED` (full closure; no weaker structure needed) |
| internal core carrier = reference implementers, closed under product and inverse | `task20_internal_core` | `PROVED` |
| kernel over the core = `{1, -1}`; kernel over the full carrier = its centre | `task20_kernel_and_centre` | `PROVED` |
| a distinguished subcarrier with discrete kernel inside a continuous centre | `task20_kernel_and_centre` | `PROVED` |
| inherited central sign under a full turn | `task20_full_turn_sign` | `PROVED` |
| primitive bridge = unique relative factor between internal lifts | `task20_relative_factor` | `PROVED` |
| local exact rate set is a free transitive `ℤ`-object with no origin | `task20_rate_torsor` | `PROVED` |
| differences of allowed rates are exactly `ℤ` | `task20_rate_torsor` | `PROVED` |
| reduction of the integer data loses information | `task20_reduction_loses_information` | `PROVED` (explicit witness) |
| reversal quotient: antipodal-free / complete as fibre statements | `task20_reversal_quotient` | `PROVED` |
| maximal admissible = dense selector for the reversal quotient | `task20_reversal_quotient` | `PROVED` |
| maximal selectors are not unique; distinguishing datum exhibited | `task20_selector_nonuniqueness` | `PROVED` |
| minimal intrinsic obstruction (no discreteness used) | `task20_minimal_obstruction` | `PROVED` |
| the three-condition obstruction as a corollary; countermodels | `task20_obstruction_levels` | `PROVED` |
| a quotient-compatible internal choice exists | `task20_internal_choice` | `PROVED` |
| no quotient-compatible internal choice is continuous | `task20_internal_choice` | `PROVED` |
| relation completeness ↔ primitive global bridge (inherited) | `task20_relation_completeness` | `PROVED` (re-export) |
| anti-overclaim controls | `task20_controls` | `PROVED` |
| external identification of the internal core carrier | `task20_comparison` | `EXACT EQUIVALENCE` (comparison-only module) |
| external identification of the visible object | — | `NOT CLAIMED`; see `TASK20_AUDIT.md` |
| disconnected label extension criterion (frozen) | `task20_label_extension` | `PROVED` (re-export); independence from the rate torsor `OPEN` |
| regularity collapse `C⁰ = Cᵏ = C∞` (frozen) | `task20_regularity` | `PROVED` (re-export); arbitrary-domain analytic admissibility `OPEN` |

Formal Lean endpoints are exactly the `task20_*` theorems below.  Everything else in the
`TASK20_AUDIT.md` narrative is a paper-level reading.
-/

namespace NullSectorTask20

open scoped ContDiff

open NullSectorTask01 NullSectorTask04 NullSectorTask06 NullSectorTask07 NullSectorTask08
open NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12 NullSectorTask13
open NullSectorTask14 NullSectorTask15 NullSectorTask16 NullSectorTask17 NullSectorTask18
open NullSectorTask19

/-! ## Package B -/

/-- **TASK-20 ENDPOINT.**  Visible equality is reflexive, symmetric and transitive; the
visible map factors through the quotient uniquely; the induced map onto the visible image is
a bijection. -/
theorem task20_visible_quotient :
    (∀ p : VisParam, visRel p p) ∧
      (∀ p q : VisParam, visRel p q → visRel q p) ∧
      (∀ p q r : VisParam, visRel p q → visRel q r → visRel p r) ∧
      (∀ p : VisParam, visLift (visClass p) = visMap p) ∧
      (∀ F : VisQuot → (W →ₗ[ℝ] W), (∀ p, F (visClass p) = visMap p) → F = visLift) ∧
      Function.Bijective visToImage :=
  ⟨visRel_refl, fun _ _ h => visRel_symm h, fun _ _ _ h h' => visRel_trans h h',
    visLift_visClass, visLift_unique, visToImage_bijective⟩

/-- **TASK-20 ENDPOINT.**  The quotient topology agrees with the subspace topology on the
visible image: the canonical bijection is a homeomorphism. -/
theorem task20_quotient_topology :
    ∃ e : VisQuot ≃ₜ visImageFun, ∀ p : VisParam, (e (visClass p) : W → W) = ⇑(visMap p) :=
  ⟨visHomeo, fun _ => rfl⟩

/-- **TASK-20 ENDPOINT.**  The visible image carries the inherited composition law and is
closed under it, contains the identity, and is closed under inversion. -/
theorem task20_visible_group_law :
    LinearMap.id ∈ visImage ∧
      (∀ F ∈ visImage, ∀ G ∈ visImage, F.comp G ∈ visImage) ∧
      (∀ F ∈ visImage, ∃ G ∈ visImage, F.comp G = LinearMap.id ∧ G.comp F = LinearMap.id) :=
  visImage_closed_law

/-! ## Package C -/

/-- **TASK-20 ENDPOINT.**  The internal core carrier is exactly the set of reference
implementers, and it is closed under the inherited product and inversion; so is the full
internal carrier obtained by adjoining the invertible central elements. -/
theorem task20_internal_core :
    (∀ u : W, u ∈ Lift ↔ ∃ (n : Vec3) (θ : ℝ), IsUnitAxis n ∧ u = Un n θ) ∧
      (∀ u ∈ Lift, ∀ v ∈ Lift, u ⋆ v ∈ Lift) ∧
      (∀ u ∈ Lift, ∃ v ∈ Lift, u ⋆ v = w1 ∧ v ⋆ u = w1) ∧
      (∀ u ∈ LiftZ, ∀ v ∈ LiftZ, u ⋆ v ∈ LiftZ) ∧
      (∀ u ∈ LiftZ, ∃ v ∈ LiftZ, u ⋆ v = w1 ∧ v ⋆ u = w1) :=
  ⟨mem_Lift_iff_exists_Un, fun _ hu _ hv => Lift_mul_mem hu hv, fun _ hu => Lift_inv_mem hu,
    fun _ hu _ hv => LiftZ_mul_mem hu hv, fun _ hu => LiftZ_inv_mem hu⟩

/-- **TASK-20 ENDPOINT.**  The kernel of the projection on the full internal carrier equals
its centre; the kernel on the internal core carrier is exactly `{1, -1}` and is a *proper*
subset of that centre; and the larger kernel contains a continuous injective one-parameter
family.  The answer to "kernel = centre?" therefore depends on the chosen subcarrier, and
both cases are recorded. -/
theorem task20_kernel_and_centre :
    {u : W | u ∈ LiftZ ∧ proj u = LinearMap.id} = CentreOf LiftZ ∧
      {u : W | u ∈ Lift ∧ proj u = LinearMap.id} = ({w1, -w1} : Set W) ∧
      ({w1, -w1} : Set W) ⊂ CentreOf LiftZ ∧
      (Continuous (fun t : ℝ => zexp 1 0 t) ∧ Function.Injective (fun t : ℝ => zexp 1 0 t) ∧
        ∀ t : ℝ, zexp 1 0 t ∈ CUnit ∧ proj (zexp 1 0 t) = LinearMap.id) :=
  ⟨kernel_vs_centre.1, kernel_vs_centre.2.2, kernel_vs_centre.2.1, kernel_full_continuum⟩

/-- **TASK-20 ENDPOINT.**  A full turn of the parameter is invisible below but changes the
internal element by the inherited central sign; a double full turn returns it. -/
theorem task20_full_turn_sign (n : Vec3) :
    Un n (2 * Real.pi) = -w1 ∧ Un n (4 * Real.pi) = w1 ∧
      proj (Un n (2 * Real.pi)) = LinearMap.id ∧ Un n (2 * Real.pi) ≠ Un n 0 :=
  full_turn_sign n

/-! ## Package D -/

/-- **TASK-20 ENDPOINT.**  Two internal lifts of the same visible datum differ by exactly one
invertible central factor; in the core carrier the relative factor is exactly a sign.  No
continuity and no exactness is used. -/
theorem task20_relative_factor :
    (∀ u ∈ LiftZ, ∀ u' ∈ LiftZ, proj u = proj u' → ∃! z : W, z ∈ CUnit ∧ u = z ⋆ u') ∧
      (∀ u ∈ Lift, ∀ u' ∈ Lift, proj u = proj u' → u = u' ∨ u = -u') :=
  ⟨fun _ hu _ hu' h => relative_factor_existsUnique hu hu' h,
    fun _ hu _ hu' h => relative_factor_core hu hu' h⟩

/-! ## Package E -/

/-- **TASK-20 ENDPOINT.**  The local exact rate set is nonempty, avoids zero, carries a free
and transitive action of the integers, has no distinguished element, and its set of
differences is exactly the integers. -/
theorem task20_rate_torsor :
    (∃ x : ℝ, x ∈ HalfOddSet) ∧
      (0 : ℝ) ∉ HalfOddSet ∧
      (∀ x ∈ HalfOddSet, ∀ k : ℤ, x + (k : ℝ) ∈ HalfOddSet) ∧
      (∀ x ∈ HalfOddSet, ∀ k : ℤ, x + (k : ℝ) = x → k = 0) ∧
      (∀ x ∈ HalfOddSet, ∀ y ∈ HalfOddSet, ∃! k : ℤ, x + (k : ℝ) = y) ∧
      {d : ℝ | ∃ x ∈ HalfOddSet, ∃ y ∈ HalfOddSet, d = y - x}
        = {d : ℝ | ∃ k : ℤ, d = (k : ℝ)} :=
  ⟨halfOddSet_torsor.1, halfOddSet_torsor.2.1, halfOddSet_torsor.2.2.1,
    halfOddSet_torsor.2.2.2.1, halfOddSet_torsor.2.2.2.2, halfOddSet_differences⟩

/-- **TASK-20 ENDPOINT.**  Reduction of the integer relative data modulo a proper subgroup
loses information: two allowed labels differing by an even integer have different central
factors although the value after a full turn is the same for both. -/
theorem task20_reduction_loses_information :
    ∃ b b' : ℝ, b ∈ HalfOddSet ∧ b' ∈ HalfOddSet ∧ (∃ k : ℤ, b' = b + 2 * (k : ℝ)) ∧
      (∃ θ : ℝ, labelBridge b θ ≠ labelBridge b' θ) ∧
      labelBridge b (2 * Real.pi) = labelBridge b' (2 * Real.pi) :=
  reduction_loses_information

/-! ## Package F -/

/-- **TASK-20 ENDPOINT.**  The Task-XIX domain properties as fibre statements for the orbit
quotient of the reversal involution, and the resulting reading of inclusion-maximal
admissibility as "dense selector". -/
theorem task20_reversal_quotient :
    (∀ D : Set Vec3, UnitSet D → (AntipodalFree D ↔
        ∀ s t : Sph, (s : Vec3) ∈ D → (t : Vec3) ∈ D → revClass s = revClass t → s = t)) ∧
      (∀ D : Set Vec3, AntipodalComplete D ↔
        ∀ c : RevQuot, ∃ s : Sph, (s : Vec3) ∈ D ∧ revClass s = c) ∧
      (∀ D : Set Vec3, UnitSet D → ((AntipodalFree D ∧ AntipodalComplete D) ↔
        ∀ c : RevQuot, ∃! s : Sph, (s : Vec3) ∈ D ∧ revClass s = c)) ∧
      (∀ D : Set Vec3, UnitSet D → (IsMaximalIn AdmClass D ↔
        ((∀ c : RevQuot, ∃! s : Sph, (s : Vec3) ∈ D ∧ revClass s = c) ∧ DenseDom D))) :=
  ⟨fun _ h => antipodalFree_iff_fibre_subsingleton h,
    fun _ => antipodalComplete_iff_fibre_nonempty,
    fun _ h => selector_iff h, fun _ h => maximal_iff_dense_selector h⟩

/-- **TASK-20 ENDPOINT.**  Maximal selectors are not unique, and the datum distinguishing two
of them is the fibre at which they choose the other representative. -/
theorem task20_selector_nonuniqueness :
    ∃ D E : Set Vec3, IsMaximalIn AdmClass D ∧ IsMaximalIn AdmClass E ∧ D ≠ E ∧
      E = negSet D ∧ ∃ n : Vec3, IsUnitAxis n ∧ (n ∈ D ↔ n ∉ E) :=
  maximal_selectors_not_unique

/-! ## Package G -/

/-- **TASK-20 ENDPOINT.**  The minimal intrinsic obstruction: a continuous reversal-odd rate
has a zero, hence cannot take values in any set avoiding zero.  Discreteness plays no role;
the non-discrete instance of strictly positive rates is included. -/
theorem task20_minimal_obstruction :
    (∀ f : Sph → ℝ, Continuous f → (∀ s : Sph, f (negSph s) = -f s) → ∃ s : Sph, f s = 0) ∧
      (∀ S : Set ℝ, (0 : ℝ) ∉ S →
        ¬ ∃ b : Vec3 → ℝ, RateCont b ∧ RateRev b ∧ ∀ n : Vec3, IsUnitAxis n → b n ∈ S) ∧
      ¬ ∃ b : Vec3 → ℝ, RateCont b ∧ RateRev b ∧ ∀ n : Vec3, IsUnitAxis n → 0 < b n :=
  ⟨fun _ hf hodd => exists_zero_of_odd hf hodd,
    fun _ h0 => no_continuous_odd_rate_avoiding_zero h0, no_positive_odd_rate⟩

/-- **TASK-20 ENDPOINT.**  The inherited obstruction at all three levels, obtained as a
corollary of the minimal statement, with the three inherited countermodels preserved. -/
theorem task20_obstruction_levels :
    (¬ ∃ b : Vec3 → ℝ, RateCont b ∧ RateHalfOdd b ∧ RateRev b) ∧
      (¬ ∃ c : Vec3 → ℝ → W, IsPrimitiveBridge c ∧ IsTransformationValued (recon c)) ∧
      (¬ ∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧ IsTransformationValued U) ∧
      (RateHalfOdd signRate ∧ RateRev signRate ∧ ¬ RateCont signRate) ∧
      (RateCont rateZero ∧ RateRev rateZero ∧ ¬ RateHalfOdd rateZero) ∧
      (RateCont rateHalf ∧ RateHalfOdd rateHalf ∧ ¬ RateRev rateHalf) :=
  ⟨obstruction_all_levels.1, obstruction_all_levels.2.1, obstruction_all_levels.2.2.1,
    obstruction_countermodels.1, obstruction_countermodels.2.1,
    obstruction_countermodels.2.2.1⟩

/-! ## Packages G, H — internal choices over the visible quotient -/

/-- **TASK-20 ENDPOINT, principal.**  A quotient-compatible internal choice exists, and no
quotient-compatible internal choice is continuous.  The whole global phenomenon is therefore
located in continuity of an internal choice over the visible quotient. -/
theorem task20_internal_choice :
    (∃ σ : VisParam → W, (∀ p : VisParam, σ p ∈ Lift) ∧
        (∀ p : VisParam, proj (σ p) = visMap p) ∧
        (∀ p q : VisParam, visRel p q → σ p = σ q)) ∧
      ¬ ∃ σ : VisParam → W, Continuous σ ∧ (∀ p : VisParam, σ p ∈ Lift) ∧
        (∀ p : VisParam, proj (σ p) = visMap p) ∧
        (∀ p q : VisParam, visRel p q → σ p = σ q) :=
  ⟨exists_quotient_compatible_lift, no_continuous_quotient_compatible_lift⟩

/-- **TASK-20 ENDPOINT.**  The inherited relation-completeness equivalences, re-exported in
the Task-20 packaging. -/
theorem task20_relation_completeness :
    ((∃ (ι : Type) (D : ι → Set Vec3) (U : ι → Vec3 → ℝ → W),
          IsLocalSystem D U ∧ SystemRelationComplete D U) ↔
        ∃ c : Vec3 → ℝ → W, IsPrimitiveBridge c ∧ IsTransformationValued (recon c)) ∧
      (¬ ∃ (ι : Type) (D : ι → Set Vec3) (U : ι → Vec3 → ℝ → W),
        IsLocalSystem D U ∧ SystemRelationComplete D U) ∧
      (∀ U : Vec3 → ℝ → W, IsJointlyRegularFamily U → RateZeroHalfOdd U →
        (IsRelationComplete U ↔ AntipodalRelated U)) :=
  relation_completeness_package

/-! ## Package L -/

/-- **TASK-20 ENDPOINT.**  The six anti-overclaim controls. -/
theorem task20_controls :
    (({w1, -w1} : Set W) ⊂ CentreOf LiftZ) ∧
      (Continuous (fun t : ℝ => zexp 1 0 t) ∧ Function.Injective (fun t : ℝ => zexp 1 0 t) ∧
        ∀ t : ℝ, zexp 1 0 t ∈ CUnit ∧ proj (zexp 1 0 t) = LinearMap.id) ∧
      (∃ b b' : ℝ, b ∈ HalfOddSet ∧ b' ∈ HalfOddSet ∧ (∃ k : ℤ, b' = b + 2 * (k : ℝ)) ∧
        (∃ θ : ℝ, labelBridge b θ ≠ labelBridge b' θ) ∧
        labelBridge b (2 * Real.pi) = labelBridge b' (2 * Real.pi)) ∧
      (CoversDirections Dom ∧ ¬ SystemRelationComplete Dom inhSystem) ∧
      (∃ σ : VisParam → W, (∀ p : VisParam, σ p ∈ Lift) ∧
        (∀ p : VisParam, proj (σ p) = visMap p) ∧
        (∀ p q : VisParam, visRel p q → σ p = σ q)) ∧
      ¬ ∃ b : Vec3 → ℝ, RateCont b ∧ RateRev b ∧ ∀ n : Vec3, IsUnitAxis n → 0 < b n :=
  anti_overclaim_controls

/-! ## Phase B, comparison only -/

/-- **TASK-20 ENDPOINT (comparison only).**  The single formal external identification: the
internal core carrier is exactly the image of the unit quaternions under an explicit
injective unital multiplicative map. -/
theorem task20_comparison :
    fromQuat 1 = w1 ∧
      (∀ q p : Quaternion ℝ, fromQuat (q * p) = fromQuat q ⋆ fromQuat p) ∧
      Function.Injective fromQuat ∧
      Lift = fromQuat '' {q : Quaternion ℝ | Quaternion.normSq q = 1} :=
  ⟨fromQuat_one, fromQuat_mul, fromQuat_injective, lift_eq_image_unit_quaternions⟩

/-! ## Packages I and J — frozen inherited statements -/

/-- **TASK-20 ENDPOINT (item 73), frozen re-export.**  The inherited closure-extension
criterion for prescribed labels on a disconnected domain, together with the necessity of
separation of differently labelled closures and the refutation of its sufficiency.  Task 20
adds no theorem here; whether the criterion can be replaced by a purely geometric condition
with no existential ambient function is recorded as `OPEN` in `TASK20_AUDIT.md`. -/
theorem task20_label_extension :
    (∀ (D : Set Vec3) (hunit : UnitSet D) (l : Vec3 → ℤ),
        LabelRealized D l ↔
          ∃ g : C(closure (sphSet D), ℝ),
            (∀ (n : Vec3) (h : n ∈ D),
              g ⟨⟨n, hunit n h⟩, subset_closure h⟩ = (l n : ℝ) + 1 / 2) ∧
            (∀ (n : Vec3) (h : n ∈ D) (h' : -n ∈ D),
              g ⟨⟨-n, hunit _ h'⟩, subset_closure h'⟩ =
                -g ⟨⟨n, hunit n h⟩, subset_closure h⟩)) ∧
      ((∀ j k : ℤ, j ≠ k →
          closure (sphSet (LabelLevel accDom accLabel j)) ∩
            closure (sphSet (LabelLevel accDom accLabel k)) = ∅) ∧
        ¬ LabelRealized accDom accLabel) :=
  ⟨fun _ hunit l => label_closure_extension_criterion hunit l, separation_not_sufficient⟩

/-- **TASK-20 ENDPOINT (item 79), frozen re-export.**  The inherited regularity collapse —
continuous, every finite `Cᵏ` and smooth admissibility define the same arbitrary-domain
class — together with the separate analytic audit.  Arbitrary-domain analytic admissibility
remains `OPEN`. -/
theorem task20_regularity :
    (∀ (k : ℕ) (D : Set Vec3), IsAdmissibleDomain D ↔ IsCkAdmissibleDomain (k : WithTop ℕ∞) D) ∧
      (∀ D : Set Vec3, IsAdmissibleDomain D ↔ IsCkAdmissibleDomain ∞ D) ∧
      (∀ f : ℝ → ℝ, AnalyticOnNhd ℝ f Set.univ → ∀ p q c : ℝ, p < q →
        (∀ x ∈ Set.Ioo p q, f x = c) → ∀ x : ℝ, f x = c) ∧
      (∀ D : Set Vec3, (∀ n ∈ D, IsUnitAxis n) → AntipodalFree D → IsCkAdmissibleDomain ω D) :=
  ⟨fun k _ => admissible_iff_ckAdmissible k, fun _ => admissible_iff_smoothAdmissible,
    control_c1_needs_construction.2,
    fun _ hunit hfree => antipodalFree_analyticAdmissible hunit hfree⟩

/-! ## Axiom report -/

#print axioms task20_visible_quotient
#print axioms task20_quotient_topology
#print axioms task20_visible_group_law
#print axioms task20_internal_core
#print axioms task20_kernel_and_centre
#print axioms task20_full_turn_sign
#print axioms task20_relative_factor
#print axioms task20_rate_torsor
#print axioms task20_reduction_loses_information
#print axioms task20_reversal_quotient
#print axioms task20_selector_nonuniqueness
#print axioms task20_minimal_obstruction
#print axioms task20_obstruction_levels
#print axioms task20_internal_choice
#print axioms task20_relation_completeness
#print axioms task20_controls
#print axioms task20_label_extension
#print axioms task20_regularity
#print axioms task20_comparison

end NullSectorTask20
