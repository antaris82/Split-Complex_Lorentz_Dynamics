import RequestProject.NullSectorTask16.RateAudit

/-!
# Task 16, Layer 8: the late comparison module

**COMPARISON ONLY, AND LAST.**  This module is imported by nothing but
`RequestProject.NullSectorTask16.Task16`.  No reconstruction module of Task 16 (or of any
earlier task) imports it, and no reconstruction theorem depends on it.  Conventional
terminology is admitted here and only here, and it is used only to *name* structures that
have already been derived; nothing below is used as an input anywhere.

## What the reconstruction produced

1. Two axis–parameter pairs represent the same inherited visible automorphism exactly when
   their reference implementations agree **up to a sign** (`coincidence_iff`).  The two
   exceptional identifications are the parameter period `2π` and the reversal
   `(n, θ) ↦ (-n, -θ)`.
2. Jointly regular families are exactly the exponential–rotation multiples of the
   reference implementations with continuous rate functions
   (`jointRegularity_classification`).
3. No jointly regular family is an exact function of the visible transformation
   (`no_global_jointly_regular_transformationValued`); the residual is exactly a central
   sign, and the unique family realizing that weaker requirement is the inherited
   reference family itself (`signValued_eq_reference`).
4. Exact closure is restored on any proper domain of directions, the admissible local
   choices being indexed by the integers, and two local choices differ by a central,
   direction-independent, uniquely determined factor (`locFam_transformationValuedOn`,
   `local_rates`, `locFam_overlap`, `locFam_overlap_unique`).

## The conventional reading

The pattern in 1–4 is the one conventionally described by saying that the internal
representatives form a *two-fold* refinement of the visible transformations: the parameter
must be run through twice before the internal representative returns to itself, so an exact
global assignment of internal representatives to visible transformations does not exist,
while such an assignment does exist over any region of directions that omits antipodal
pairs, with a two-valued comparison between overlapping regions.

This paragraph is a *reading* of the derived statements and is used nowhere.  In
particular, no group, cover, cocycle or bundle notion was constructed, imported, or needed;
the obstruction was produced from the inherited carrier, the inherited automorphism family,
and the joint regularity requirement alone.

## Restatements

The two theorems below are literal restatements of already proved reconstruction results,
recorded here so that the comparison paragraph is anchored to formal content.
-/

namespace NullSectorTask16

open NullSectorTask01 NullSectorTask04 NullSectorTask06 NullSectorTask07 NullSectorTask08
open NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12 NullSectorTask13
open NullSectorTask14 NullSectorTask15

/-- **COMPARISON ONLY.**  The parameter period of the visible automorphism family is `2π`,
while the internal reference representative returns to itself only after `4π`; at `2π` it
returns to its own negative. -/
theorem comparison_two_fold_parameter (n : Vec3) (θ : ℝ) :
    PhiGen n (θ + 2 * Real.pi) = PhiGen n θ ∧
      Un n (θ + 2 * Real.pi) = -(Un n θ) ∧
      Un n (θ + 2 * Real.pi + 2 * Real.pi) = Un n θ :=
  ⟨coincidence_add_two_pi n θ, Un_add_two_pi n θ, by
    rw [Un_add_two_pi, Un_add_two_pi]; module⟩

/-- **COMPARISON ONLY.**  The exact global situation: no exact assignment exists, the
sign-relaxed one exists and is unique, and exact assignments exist on proper domains. -/
theorem comparison_global_versus_local (v : Vec3) :
    (¬ ∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧ IsTransformationValued U) ∧
      IsSignTransformationValued refFam ∧
      IsTransformationValuedOn (Dom v) (locFam 0) :=
  ⟨no_global_jointly_regular_transformationValued, reference_signTransformationValued,
    locFam_transformationValuedOn 0 v⟩

end NullSectorTask16
