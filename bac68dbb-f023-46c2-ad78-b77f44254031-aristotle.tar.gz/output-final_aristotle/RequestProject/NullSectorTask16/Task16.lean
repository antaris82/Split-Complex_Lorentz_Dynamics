import RequestProject.NullSectorTask16.OptionCAudit
import RequestProject.NullSectorTask16.Identification

/-!
# Task 16: the principal theorems

This module imports the complete Task-16 development and exposes the principal final
theorems, one group per work package, together with the axiom report.

Source order of the development:

```
SafeBase
  → ExactCoincidences        (Work Package 1)
  → JointRegularity          (Work Package 2)
  → TransformationValuedClosure (Work Package 3)
  → RegularDefect            (Work Package 4)
  → LocalRepair              (Work Package 5)
  → RateAudit                (Work Package 6, first half; negative controls)
  → OptionCAudit             (COMPARISON ONLY)
  → Identification           (COMPARISON ONLY, last)
  → Task16
```

`OptionCAudit` and `Identification` are imported by this module only; no reconstruction
module depends on either.

## Verdict table

| question | answer |
|---|---|
| 1. exact axis–angle coincidence relation | **CLOSED** (`task16_coincidence_iff`) |
| 2. joint continuity in `(n, θ)` | **CLASSIFIED** (`task16_joint_regularity_classification`) |
| 3. recovered `α, β` regularity | both are forced to be **continuous**, and every continuous pair occurs |
| 4. global jointly regular transformation-valued family | **DOES NOT EXIST** |
| 5. central composition defect under joint regularity | exactly `{1, -1}` on closed visible relations, and *not* discrete without the normalization |
| 6. minimal repair | exact closure on proper domains covering all directions, with central, direction-independent, unique transition data, composing along finite chains |
| 7. spatial rate versus central rates | logically separate; `lam = 1` is derived, not conventional |
| 8. Task-1 Option-C pattern | **REPLACED BY A DISCRETE GLOBAL OBSTRUCTION**, repaired by domainwise data |

**Task-16 status: GLOBAL REGULAR REPRESENTATIVE OBSTRUCTED; MINIMAL LOCAL REPAIR
CLASSIFIED.**
-/

namespace NullSectorTask16

open NullSectorTask01 NullSectorTask04 NullSectorTask06 NullSectorTask07 NullSectorTask08
open NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12 NullSectorTask13
open NullSectorTask14 NullSectorTask15

/-! ## Work Package 1 -/

theorem task16_coincidence_iff {n m : Vec3} (hn : IsUnitAxis n) (hm : IsUnitAxis m)
    (θ φ : ℝ) : PhiGen n θ = PhiGen m φ ↔ SignRelated n m θ φ :=
  coincidence_iff hn hm θ φ

theorem task16_coincidence_coords {n m : Vec3} (hn : IsUnitAxis n) (hm : IsUnitAxis m)
    (θ φ : ℝ) :
    PhiGen n θ = PhiGen m φ ↔
      (Real.cos (θ / 2) = Real.cos (φ / 2) ∧ Real.sin (θ / 2) • n = Real.sin (φ / 2) • m) ∨
      (Real.cos (θ / 2) = -Real.cos (φ / 2) ∧
        Real.sin (θ / 2) • n = -(Real.sin (φ / 2) • m)) :=
  coincidence_iff_coords hn hm θ φ

theorem task16_coincidence_periodicity (n : Vec3) (θ : ℝ) :
    PhiGen n (θ + 2 * Real.pi) = PhiGen n θ :=
  coincidence_add_two_pi n θ

theorem task16_coincidence_reversal (n : Vec3) (θ : ℝ) : PhiGen (-n) θ = PhiGen n (-θ) :=
  coincidence_neg_axis n θ

theorem task16_coincidence_identity {n : Vec3} (hn : IsUnitAxis n) (θ : ℝ) :
    PhiGen n θ = LinearMap.id ↔ ∃ k : ℤ, θ = 2 * Real.pi * k :=
  coincidence_id_iff hn θ

theorem task16_coincidence_same_axis {n : Vec3} (hn : IsUnitAxis n) (θ φ : ℝ) :
    PhiGen n θ = PhiGen n φ ↔ ∃ k : ℤ, θ - φ = 2 * Real.pi * k :=
  coincidence_same_axis_iff hn θ φ

theorem task16_coincidence_axis_determined {n m : Vec3} (hn : IsUnitAxis n)
    (hm : IsUnitAxis m) {θ φ : ℝ} (hθ : Real.sin (θ / 2) ≠ 0)
    (h : PhiGen n θ = PhiGen m φ) : n = m ∨ n = -m :=
  coincidence_axis_determined hn hm hθ h

theorem task16_coincidence_degenerate {n m : Vec3} (hn : IsUnitAxis n) (hm : IsUnitAxis m)
    (k l : ℤ) : PhiGen n (2 * Real.pi * k) = PhiGen m (2 * Real.pi * l) :=
  coincidence_axis_undetermined_at_zero_angle hn hm k l

/-! ## Work Package 2 -/

theorem task16_joint_regularity_classification (U : Vec3 → ℝ → W) :
    IsJointlyRegularFamily U ↔
      ∃ a b : Vec3 → ℝ, (Continuous fun s : Sph => a (s : Vec3)) ∧
        (Continuous fun s : Sph => b (s : Vec3)) ∧
        ∀ n : Vec3, IsUnitAxis n → ∀ θ : ℝ, U n θ = zexp (a n) (b n) θ ⋆ Un n θ :=
  jointRegularity_classification U

theorem task16_alpha_continuous {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U) :
    Continuous fun s : Sph => rateAlpha U (s : Vec3) :=
  jointlyRegular_alpha_continuous hU

theorem task16_beta_continuous {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U) :
    Continuous fun s : Sph => rateBeta U (s : Vec3) :=
  jointlyRegular_beta_continuous hU

theorem task16_joint_regularity_sufficient {a b : Vec3 → ℝ}
    (ha : Continuous fun s : Sph => a (s : Vec3))
    (hb : Continuous fun s : Sph => b (s : Vec3)) :
    IsJointlyRegularFamily (famOf a b) :=
  jointlyRegular_famOf ha hb

/-! ## Work Package 3 -/

theorem task16_no_global_transformation_valued :
    ¬ ∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧ IsTransformationValued U :=
  no_global_jointly_regular_transformationValued

theorem task16_explicit_failure {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U) :
    ∃ (n m : Vec3) (θ φ : ℝ), IsUnitAxis n ∧ IsUnitAxis m ∧
      PhiGen n θ = PhiGen m φ ∧ U n θ ≠ U m φ :=
  jointlyRegular_transformation_valuedness_fails hU

/-! ## Work Package 4 -/

theorem task16_reference_sign_valued : IsSignTransformationValued refFam :=
  reference_signTransformationValued

theorem task16_sign_valued_unique {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    (hV : IsSignTransformationValued U) {n : Vec3} (hn : IsUnitAxis n) (θ : ℝ) :
    U n θ = refFam n θ :=
  signValued_eq_reference hU hV hn θ

theorem task16_defect_pm_one {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    (hV : IsSignTransformationValued U) {n m : Vec3} (hn : IsUnitAxis n) (hm : IsUnitAxis m)
    {θ φ : ℝ} (hP : PhiGen n θ = PhiGen m φ) :
    ∃ c : W, (c = w1 ∨ c = -w1) ∧ c ∈ Z ∧ U n θ = c ⋆ U m φ :=
  signValued_defect_pm_one hU hV hn hm hP

theorem task16_defect_nontrivial :
    ∃ (n : Vec3) (θ φ : ℝ), IsUnitAxis n ∧ PhiGen n θ = PhiGen n φ ∧
      refFam n θ = -(refFam n φ) ∧ refFam n θ ≠ refFam n φ :=
  reference_sign_defect_nontrivial

theorem task16_defect_not_discrete_without_normalization :
    ∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧
      ∃ (n : Vec3) (θ φ : ℝ), IsUnitAxis n ∧ PhiGen n θ = PhiGen n φ ∧
        U n θ = (-(Real.exp (2 * Real.pi))) • U n φ ∧
        (-(Real.exp (2 * Real.pi))) ≠ 1 ∧ (-(Real.exp (2 * Real.pi))) ≠ -1 :=
  defect_not_discrete_without_normalization

/-! ## Work Package 5 -/

theorem task16_local_existence (k : ℤ) (v : Vec3) :
    IsJointlyRegularFamily (locFam k) ∧ IsTransformationValuedOn (Dom v) (locFam k) :=
  ⟨locFam_jointlyRegular k, locFam_transformationValuedOn k v⟩

theorem task16_local_covering {n : Vec3} (hn : IsUnitAxis n) : n ∈ Dom n := Dom_covers hn

theorem task16_local_rates {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U) {v : Vec3}
    (hV : IsTransformationValuedOn (Dom v) U) {n : Vec3} (hn : n ∈ Dom v) :
    rateAlpha U n = 0 ∧ ∃ k : ℤ, rateBeta U n = (k : ℝ) + 1 / 2 :=
  local_rates hU hV hn

theorem task16_overlap (k l : ℤ) (n : Vec3) (θ : ℝ) :
    locFam k n θ = zexp 0 ((k : ℝ) - l) θ ⋆ locFam l n θ ∧
      zexp 0 ((k : ℝ) - l) θ ∈ Z ∧ IsCentralUnit (zexp 0 ((k : ℝ) - l) θ) :=
  locFam_overlap k l n θ

theorem task16_overlap_unique {k l : ℤ} {n : Vec3} (hn : IsUnitAxis n) {θ : ℝ} {c : W}
    (h : locFam k n θ = c ⋆ locFam l n θ) : c = zexp 0 ((k : ℝ) - l) θ :=
  locFam_overlap_unique hn h

theorem task16_overlap_chain (k l m : ℤ) (θ : ℝ) :
    zexp 0 ((k : ℝ) - l) θ ⋆ zexp 0 ((l : ℝ) - m) θ = zexp 0 ((k : ℝ) - m) θ :=
  locFam_overlap_chain k l m θ

theorem task16_local_repair_status :
    (¬ ∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧ IsTransformationValued U) ∧
    (∀ v : Vec3, IsJointlyRegularFamily (locFam 0) ∧
      IsTransformationValuedOn (Dom v) (locFam 0)) ∧
    (∀ n : Vec3, IsUnitAxis n → n ∈ Dom n) ∧
    (∀ (k l : ℤ) (n : Vec3) (θ : ℝ), locFam k n θ = zexp 0 ((k : ℝ) - l) θ ⋆ locFam l n θ ∧
      IsCentralUnit (zexp 0 ((k : ℝ) - l) θ)) ∧
    (∀ (k l m : ℤ) (θ : ℝ),
      zexp 0 ((k : ℝ) - l) θ ⋆ zexp 0 ((l : ℝ) - m) θ = zexp 0 ((k : ℝ) - m) θ) :=
  local_repair_status

/-! ## Work Package 6 and the negative controls -/

theorem task16_rate_survival :
    (∀ a b : Vec3 → ℝ, (Continuous fun s : Sph => a (s : Vec3)) →
        (Continuous fun s : Sph => b (s : Vec3)) →
        IsJointlyRegularFamily (famOf a b) ∧ ∀ n : Vec3, IsUnitAxis n →
          rateAlpha (famOf a b) n = a n ∧ rateBeta (famOf a b) n = b n) ∧
    (¬ ∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧ IsTransformationValued U) ∧
    (∀ U : Vec3 → ℝ → W, IsJointlyRegularFamily U → IsSignTransformationValued U →
      ∀ n : Vec3, IsUnitAxis n → rateAlpha U n = 0 ∧ rateBeta U n = 0) ∧
    (∀ (U : Vec3 → ℝ → W), IsJointlyRegularFamily U → ∀ v : Vec3,
      IsTransformationValuedOn (Dom v) U → ∀ n ∈ Dom v,
        rateAlpha U n = 0 ∧ ∃ k : ℤ, rateBeta U n = (k : ℝ) + 1 / 2) ∧
    (∀ k : ℤ, ∀ n : Vec3, IsUnitAxis n →
      rateAlpha (locFam k) n = 0 ∧ rateBeta (locFam k) n = (k : ℝ) + 1 / 2) :=
  rate_survival

theorem task16_spatial_rate_forced {lam : ℝ} {a b : Vec3 → ℝ} {n : Vec3}
    (hn : IsUnitAxis n)
    (h : ∀ (θ : ℝ) (x : W),
      (rateFam lam a b n θ ⋆ x) ⋆ rateFam lam a b n (-θ) = PhiGen n θ x) : lam = 1 :=
  spatial_rate_forced hn h

theorem task16_control_no_basis_axis {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    (hV : IsTransformationValued U) : ∀ n : Vec3, IsUnitAxis n → rateBeta U n = 0 :=
  control_no_basis_axis hU hV

theorem task16_control_rates_not_preset (a b : Vec3 → ℝ)
    (ha : Continuous fun s : Sph => a (s : Vec3))
    (hb : Continuous fun s : Sph => b (s : Vec3)) :
    IsJointlyRegularFamily (famOf a b) ∧
      ∀ n : Vec3, IsUnitAxis n →
        rateAlpha (famOf a b) n = a n ∧ rateBeta (famOf a b) n = b n :=
  control_rates_not_preset a b ha hb

theorem task16_control_reference_not_selected :
    ∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧ U ≠ refFam :=
  control_reference_not_selected

theorem task16_control_antipodal_is_the_obstruction (v : Vec3) :
    (∀ n : Vec3, PhiGen (-n) 0 = PhiGen n (-0)) ∧
    (∀ (n : Vec3) (θ : ℝ), PhiGen n (θ + 2 * Real.pi) = PhiGen n θ) ∧
    (∀ n ∈ Dom v, -n ∉ Dom v) ∧
    IsTransformationValuedOn (Dom v) (locFam 0) :=
  control_antipodal_is_the_obstruction v

theorem task16_control_rate_separation_persists {n : Vec3} (hn : IsUnitAxis n)
    {lam α β lam' α' β' : ℝ}
    (h : zc α β - (lam * 2⁻¹ : ℝ) • Jmap n = zc α' β' - (lam' * 2⁻¹ : ℝ) • Jmap n) :
    lam = lam' ∧ α = α' ∧ β = β' :=
  control_rate_separation_persists hn h

/-! ## Comparison layers (imported by this module only) -/

theorem task16_optionC_comparison :
    (∀ a b : Vec3 → ℝ, (Continuous fun s : Sph => a (s : Vec3)) →
        (Continuous fun s : Sph => b (s : Vec3)) →
        ∀ n : Vec3, IsUnitAxis n →
          rateAlpha (famOf a b) n = a n ∧ rateBeta (famOf a b) n = b n) ∧
    (¬ ∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧ IsTransformationValued U) ∧
    (∀ U : Vec3 → ℝ → W, IsJointlyRegularFamily U → IsSignTransformationValued U →
      ∀ n : Vec3, IsUnitAxis n → rateAlpha U n = 0 ∧ rateBeta U n = 0) ∧
    (∀ (v : Vec3) (k : ℤ), IsTransformationValuedOn (Dom v) (locFam k) ∧
      ∀ n : Vec3, IsUnitAxis n →
        rateAlpha (locFam k) n = 0 ∧ rateBeta (locFam k) n = (k : ℝ) + 1 / 2) :=
  optionC_comparison

theorem task16_comparison_two_fold (n : Vec3) (θ : ℝ) :
    PhiGen n (θ + 2 * Real.pi) = PhiGen n θ ∧
      Un n (θ + 2 * Real.pi) = -(Un n θ) ∧
      Un n (θ + 2 * Real.pi + 2 * Real.pi) = Un n θ :=
  comparison_two_fold_parameter n θ

/-! ## Axiom report -/

#print axioms task16_coincidence_iff
#print axioms task16_coincidence_coords
#print axioms task16_coincidence_periodicity
#print axioms task16_coincidence_reversal
#print axioms task16_coincidence_identity
#print axioms task16_coincidence_same_axis
#print axioms task16_coincidence_axis_determined
#print axioms task16_coincidence_degenerate
#print axioms task16_joint_regularity_classification
#print axioms task16_alpha_continuous
#print axioms task16_beta_continuous
#print axioms task16_joint_regularity_sufficient
#print axioms task16_no_global_transformation_valued
#print axioms task16_explicit_failure
#print axioms task16_reference_sign_valued
#print axioms task16_sign_valued_unique
#print axioms task16_defect_pm_one
#print axioms task16_defect_nontrivial
#print axioms task16_defect_not_discrete_without_normalization
#print axioms task16_local_existence
#print axioms task16_local_covering
#print axioms task16_local_rates
#print axioms task16_overlap
#print axioms task16_overlap_unique
#print axioms task16_overlap_chain
#print axioms task16_local_repair_status
#print axioms task16_rate_survival
#print axioms task16_spatial_rate_forced
#print axioms task16_control_no_basis_axis
#print axioms task16_control_rates_not_preset
#print axioms task16_control_reference_not_selected
#print axioms task16_control_antipodal_is_the_obstruction
#print axioms task16_control_rate_separation_persists
#print axioms task16_optionC_comparison
#print axioms task16_comparison_two_fold

end NullSectorTask16
