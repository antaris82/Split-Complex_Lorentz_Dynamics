import RequestProject.NullSectorTask16.LocalRepair
import RequestProject.NullSectorTask15.RateSeparation

/-!
# Task 16, Layer 6 (Work Package 6, first half): the final rate audit and the negative
controls

Only now, with Packages 1–5 complete, is the rate problem revisited.

## The separation

The inherited spatial rate `lam` and the two central rates `α, β` remain logically
separate: the generator of a rate-`lam` family is `α • 1 + β • S − (lam/2) • J n`, and the
triple is recovered injectively (inherited: `generator_components_independent`).  Task 16
adds one new fact that Task 15 could not see: the value `lam = 1` is **not** a convention —
it is forced by the requirement that the family implement the inherited automorphism family
with its own parameter (`spatial_rate_forced`).

## What survives

| requirement | `α` | `β` |
|---|---|---|
| joint regularity only | arbitrary continuous function | arbitrary continuous function |
| + exact global transformation-valuedness | *no such family exists* | *no such family exists* |
| + sign-relaxed global closure | `≡ 0` | `≡ 0` |
| + exact closure on a proper domain | `≡ 0` | discrete remnant `ℤ + 1/2` |

## Negative controls (§VIII)

The theorems below show that the obstruction is not an artefact of a basis axis, of the
spatial-rate convention, of setting a rate to zero in advance, of the reference
implementation, of omitting the antipodal and periodic identifications, or of quotienting
the central discrepancy.
-/

namespace NullSectorTask16

open NullSectorTask01 NullSectorTask04 NullSectorTask06 NullSectorTask07 NullSectorTask08
open NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12 NullSectorTask13
open NullSectorTask14 NullSectorTask15

/-! ## The rate audit -/

/-- **PRINCIPAL THEOREM (Work Package 6), what survives.**  The four regimes, with the
exact surviving rate data in each. -/
theorem rate_survival :
    (∀ a b : Vec3 → ℝ, (Continuous fun s : Sph => a (s : Vec3)) →
        (Continuous fun s : Sph => b (s : Vec3)) →
        IsJointlyRegularFamily (famOf a b) ∧ ∀ n : Vec3, IsUnitAxis n →
          rateAlpha (famOf a b) n = a n ∧ rateBeta (famOf a b) n = b n) ∧
    (¬ ∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧ IsTransformationValued U) ∧
    (∀ U : Vec3 → ℝ → W, IsJointlyRegularFamily U → IsSignTransformationValued U →
      ∀ n : Vec3, IsUnitAxis n → rateAlpha U n = 0 ∧ rateBeta U n = 0) ∧
    (∀ (U : Vec3 → ℝ → W), IsJointlyRegularFamily U → ∀ v : Vec3,
      IsTransformationValuedOn (Dom v) U → ∀ n ∈ Dom v,
        rateAlpha U n = 0 ∧ ∃ k : ℤ, rateBeta U n = (k : ℝ) + 1 / 2) ∧
    (∀ k : ℤ, ∀ n : Vec3, IsUnitAxis n →
      rateAlpha (locFam k) n = 0 ∧ rateBeta (locFam k) n = (k : ℝ) + 1 / 2) := by
  refine ⟨fun a b ha hb => ⟨jointlyRegular_famOf ha hb, fun n hn => ?_⟩,
    no_global_jointly_regular_transformationValued, ?_, ?_, fun k n hn => locFam_rates k hn⟩
  · obtain ⟨h1, h2⟩ := regular_family_arbitrary_parameters a b
    exact h2 n hn
  · intro U hU hV n hn
    have href := signValued_eq_reference hU hV hn
    have hfac : ∀ θ : ℝ, U n θ = zexp 0 0 θ ⋆ Un n θ := by
      intro θ; rw [href θ, refFam, zexp_zero_eq, one_mul_W]
    obtain ⟨h1, h2⟩ := regularFamily_param_unique hU.toRegularFamily hn hfac
    exact ⟨h1.symm, h2.symm⟩
  · intro U hU v hV n hn
    exact local_rates hU hV hn

/-- **PRINCIPAL THEOREM (Work Package 6), the spatial rate is not a convention.**  A
rate-reparametrized family implements the inherited automorphism family with *its own*
parameter only if the spatial rate equals one.  Hence the Task-14 normalization is derived
here, not assumed. -/
theorem spatial_rate_forced {lam : ℝ} {a b : Vec3 → ℝ} {n : Vec3} (hn : IsUnitAxis n)
    (h : ∀ (θ : ℝ) (x : W),
      (rateFam lam a b n θ ⋆ x) ⋆ rateFam lam a b n (-θ) = PhiGen n θ x) : lam = 1 := by
  have hall : ∀ θ : ℝ, PhiGen n (lam * θ) = PhiGen n θ := by
    intro θ
    refine LinearMap.ext (fun x => ?_)
    rw [← rateFam_conj n lam a b θ x, h θ x]
  by_contra hne
  have hd : lam - 1 ≠ 0 := fun h0 => hne (by linarith)
  set θ : ℝ := Real.pi / (lam - 1) with hθ
  obtain ⟨k, hk⟩ := (coincidence_same_axis_iff hn (lam * θ) θ).1 (hall θ)
  have hval : lam * θ - θ = Real.pi := by
    rw [hθ]; field_simp
  rw [hval] at hk
  have h2 : (2 * k : ℤ) = 1 := by
    have hpi := Real.pi_pos
    have : (2 : ℝ) * (k : ℝ) = 1 := by
      have hk' : Real.pi = 2 * Real.pi * (k : ℝ) := hk
      nlinarith [hk', hpi]
    exact_mod_cast this
  omega

/-! ## Negative controls (§VIII) -/

/-- **NEGATIVE CONTROL 1.**  The obstruction is not an artefact of a distinguished basis
axis: the second central rate is forced to vanish at *every* unit direction. -/
theorem control_no_basis_axis {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    (hV : IsTransformationValued U) : ∀ n : Vec3, IsUnitAxis n → rateBeta U n = 0 :=
  fun _ hn => jointlyRegular_transformationValued_beta_zero hU hV hn

/-- **NEGATIVE CONTROL 2.**  The obstruction is not an artefact of setting a central rate
to zero in advance: before the closure requirement is imposed, both central rates are
completely free continuous functions of the direction, and *every* admissible pair is
realized. -/
theorem control_rates_not_preset (a b : Vec3 → ℝ)
    (ha : Continuous fun s : Sph => a (s : Vec3)) (hb : Continuous fun s : Sph => b (s : Vec3)) :
    IsJointlyRegularFamily (famOf a b) ∧
      ∀ n : Vec3, IsUnitAxis n →
        rateAlpha (famOf a b) n = a n ∧ rateBeta (famOf a b) n = b n :=
  ⟨jointlyRegular_famOf ha hb, fun n hn => (regular_family_arbitrary_parameters a b).2 n hn⟩

/-- **NEGATIVE CONTROL 3.**  The obstruction is not an artefact of selecting the normalized
reference implementation: the jointly regular class is strictly larger than the reference
family. -/
theorem control_reference_not_selected :
    ∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧ U ≠ refFam := by
  refine ⟨locFam 0, locFam_jointlyRegular 0, ?_⟩
  intro hcon
  have h := congrFun (congrFun hcon ((1, 0, 0) : Vec3)) Real.pi
  rw [locFam, refFam] at h
  have hz : zexp 0 ((0 : ℤ) + 1 / 2 : ℝ) Real.pi = zc (Real.cos (Real.pi / 2))
      (Real.sin (Real.pi / 2)) := by
    rw [zexp_zero_val]
    congr 1 <;> [skip; skip] <;> · congr 1; push_cast; ring
  rw [hz, Real.cos_pi_div_two, Real.sin_pi_div_two] at h
  have h7 := congrFun h 7
  rw [Un_coord_7] at h7
  have hzc : (zc 0 1 ⋆ Un ((1, 0, 0) : Vec3) Real.pi) 7 = 1 * Real.cos (Real.pi / 2) :=
    zc_mul_Un_coord_7 _ 0 1 _
  rw [hzc, Real.cos_pi_div_two] at h7
  -- the two families already differ at the transverse coordinate
  have h6 := congrFun h 6
  rw [Un_coord_6] at h6
  have hzc6 : (zc 0 1 ⋆ Un ((1, 0, 0) : Vec3) Real.pi) 6
      = -(0 * Real.sin (Real.pi / 2)) * ((1, 0, 0) : Vec3).1 := zc_mul_Un_coord_6 _ 0 1 _
  rw [hzc6, Real.sin_pi_div_two] at h6
  norm_num at h6

/-- **NEGATIVE CONTROL 4.**  The obstruction is not an artefact of *omitting* the antipodal
and periodic identifications: both are part of the classified coincidence relation, and it
is exactly the antipodal identification that fails locally — a proper domain contains no
antipodal pair, and on it exact closure is restored. -/
theorem control_antipodal_is_the_obstruction (v : Vec3) :
    (∀ n : Vec3, PhiGen (-n) 0 = PhiGen n (-0)) ∧
    (∀ (n : Vec3) (θ : ℝ), PhiGen n (θ + 2 * Real.pi) = PhiGen n θ) ∧
    (∀ n ∈ Dom v, -n ∉ Dom v) ∧
    IsTransformationValuedOn (Dom v) (locFam 0) :=
  ⟨fun n => coincidence_neg_axis n 0, coincidence_add_two_pi,
    fun _ hn => Dom_no_antipodal hn, locFam_transformationValuedOn 0 v⟩

/-- **NEGATIVE CONTROL 5.**  The central discrepancy is never quotiented: it is exhibited
as an explicit element of the carrier, and its surviving values are the two explicit
central units. -/
theorem control_defect_not_quotiented {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    (hV : IsSignTransformationValued U) {n m : Vec3} (hn : IsUnitAxis n) (hm : IsUnitAxis m)
    {θ φ : ℝ} (hP : PhiGen n θ = PhiGen m φ) :
    ∃ c : W, (c = w1 ∨ c = -w1) ∧ c ∈ Z ∧ U n θ = c ⋆ U m φ :=
  signValued_defect_pm_one hU hV hn hm hP

/-- **NEGATIVE CONTROL 6.**  The two rate notions remain separate: the spatial rate and the
two central rates are recovered injectively from the generator, so the new coherence
conditions create no relation between them. -/
theorem control_rate_separation_persists {n : Vec3} (hn : IsUnitAxis n)
    {lam α β lam' α' β' : ℝ}
    (h : zc α β - (lam * 2⁻¹ : ℝ) • Jmap n = zc α' β' - (lam' * 2⁻¹ : ℝ) • Jmap n) :
    lam = lam' ∧ α = α' ∧ β = β' :=
  generator_components_independent hn h

end NullSectorTask16
