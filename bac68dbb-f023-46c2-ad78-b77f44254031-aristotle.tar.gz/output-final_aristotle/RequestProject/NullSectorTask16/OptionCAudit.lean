import RequestProject.NullSectorTask16.RateAudit

/-!
# Task 16, Layer 7 (Work Package 6, second half): the Option-C dependency comparison

**COMPARISON ONLY.**  This module is imported by nothing but the Task-16 top module.  No
reconstruction result depends on it.  It compares *dependency structures* only; no
heuristic reading of any quantity is used in any proof, and no dictionary between the rates
and any informal notion enters any statement.

The Task-1 Option-C shape was

```
two independently variable quantities
  + insufficient compatibility information
  → residual underdetermination.
```

The Task-16 dependency structure is different, and the difference is exactly measurable:

* **before** any closure requirement, the two continuous freedoms are present in full: every
  continuous pair of rate functions occurs (`control_rates_not_preset`);
* imposing *exact* transformation-valuedness does **not** supply "one more compatibility
  relation": it makes the class **empty**
  (`no_global_jointly_regular_transformationValued`), and the reason is a *discrete*
  incompatibility — a discrete invariant is forced to be simultaneously half-odd and odd
  under reversal;
* imposing the sign-relaxed closure removes **both** continuous freedoms at once, leaving
  exactly one family (`signValued_eq_reference`);
* restricting to a proper domain of directions restores exact closure and leaves a purely
  **discrete** remnant, indexed by the integers (`local_rates`, `locFam_rates`).

Hence, among the alternatives A–E of the task:

* **A** (exactly one additional compatibility relation reducing two continuous freedoms) —
  **does not hold**;
* **B** (complete elimination of the two-rate freedom) — holds only for the *sign-relaxed*
  requirement;
* **C** (a discrete obstruction instead of a continuous relation) — **holds** for the exact
  requirement, and is the principal answer;
* **D** (local or path-independent-but-domainwise data replacing globally defined rates) —
  **holds** for the repair;
* **E** (no meaningful structural correspondence) — does not apply.

Only after this structural comparison may the heuristic dictionary of the task be
mentioned; it is recorded in the audit document, is explicitly heuristic, and appears in no
Lean statement.
-/

namespace NullSectorTask16

open NullSectorTask01 NullSectorTask04 NullSectorTask06 NullSectorTask07 NullSectorTask08
open NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12 NullSectorTask13
open NullSectorTask14 NullSectorTask15

/-- **COMPARISON ONLY.**  The exact dependency pattern of Task 16, assembled from the
reconstruction results.  Reading, in order: the two continuous freedoms are unconstrained
before closure; exact global closure is impossible; sign-relaxed global closure removes
both freedoms completely; exact closure on a proper domain leaves a discrete remnant which
is fully realized. -/
theorem optionC_comparison :
    (∀ a b : Vec3 → ℝ, (Continuous fun s : Sph => a (s : Vec3)) →
        (Continuous fun s : Sph => b (s : Vec3)) →
        ∀ n : Vec3, IsUnitAxis n →
          rateAlpha (famOf a b) n = a n ∧ rateBeta (famOf a b) n = b n) ∧
    (¬ ∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧ IsTransformationValued U) ∧
    (∀ U : Vec3 → ℝ → W, IsJointlyRegularFamily U → IsSignTransformationValued U →
      ∀ n : Vec3, IsUnitAxis n → rateAlpha U n = 0 ∧ rateBeta U n = 0) ∧
    (∀ (v : Vec3) (k : ℤ), IsTransformationValuedOn (Dom v) (locFam k) ∧
      ∀ n : Vec3, IsUnitAxis n →
        rateAlpha (locFam k) n = 0 ∧ rateBeta (locFam k) n = (k : ℝ) + 1 / 2) :=
  ⟨fun a b ha hb n hn => (control_rates_not_preset a b ha hb).2 n hn,
    no_global_jointly_regular_transformationValued,
    fun U hU hV n hn => rate_survival.2.2.1 U hU hV n hn,
    fun v k => ⟨locFam_transformationValuedOn k v, fun _ hn => locFam_rates k hn⟩⟩

end NullSectorTask16
