import RequestProject.NullSectorTask18.NegativeControls

/-!
# Task 18, final layer: the comparison-only module

**COMPARISON ONLY, AND LAST.**  This module is imported by nothing but
`RequestProject.NullSectorTask18.Task18`.  No reconstruction module of Task 18 — or of any
earlier task — imports it, and no reconstruction theorem depends on it.  It contains a
single reading of results that have already been derived; nothing here is used as an input
anywhere, and no new mathematics is introduced.

## What the Task-18 reconstruction produced

1. For a **preconnected** set of unit directions, admissibility and antipodal-freeness are
   the same condition; the empty domain satisfies both, and no nonemptiness hypothesis is
   needed (Package A).
2. Maximality depends on the class: the inherited domains are maximal among *open
   preconnected* admissible sets, not among open admissible sets, and not among admissible
   sets; an explicit lexicographic half-space is a *constructed* maximal preconnected
   admissible set; two different such maximal sets contain one and the same inherited
   domain and carry the same algebraic data, so nothing selects one of them (Package B).
3. The unrestricted literal extension problem and the sign-relaxed reconstruction problem
   are different: the Task-17 system solves the first and fails the second (Package C).
4. Every jointly regular family factors, at every unit direction, through the unique global
   sign-relaxed reference by a **central** factor which is unique, whose rate is the already
   reconstructed one, which is half-odd as soon as the family is exact at one point of a
   domain, which is direction-independent on preconnected exact domains, and whose
   differences reproduce the previously classified integer overlap factors (Package D).
5. Removing that factor — while retaining it as data — turns *every* local exact
   representative into one and the same global sign-relaxed reference; the bridge-normalized
   reconstruction exists and is unique (Package E).
6. The residual obstruction is located exactly: a globally exact jointly regular
   representative exists **iff** one global bridge exists, and no global bridge exists
   because no rate function is at once continuous, half-odd everywhere and reversal-odd —
   while each pair of these three conditions is realizable (Package F).
7. Ordinary overlaps do not exhaust the visible coincidence relations: no family of
   antipodal-free domains covers them, and besides the antipodal relation there is exactly
   one further cross-domain class, the degenerate identity-parameter class, which is
   harmless (Package G).
8. Labels are constant on preconnected components, arbitrary component assignments are
   admissible exactly when they extend to one continuous reversal-compatible rate, and
   distinct labels can never accumulate (Package H).
9. Continuous and `C¹` admissibility agree for **every** set of unit directions, with the
   `C¹` rate constructed (Package I).

## The conventional reading

The pattern 1–9 is the one conventionally described by saying that the local internal
representatives all differ from one fixed global reference by a discrete central factor, so
that the local-to-global mismatch of the previous stage is a matter of normalization only,
while a genuinely global obstruction survives in the comparison across direction reversal.

This paragraph is a *reading* of already-derived statements.  No group, covering, cocycle,
bundle, cohomology, connection or classification theorem was constructed, imported, or
needed anywhere in the reconstruction; the discrete labels are integers attached to
explicit families and are given no interpretation beyond that.
-/

namespace NullSectorTask18

open NullSectorTask01 NullSectorTask04 NullSectorTask06 NullSectorTask07 NullSectorTask08
open NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12 NullSectorTask13
open NullSectorTask14 NullSectorTask15 NullSectorTask16 NullSectorTask17

/-- **COMPARISON ONLY.**  The two facts that the informal reading above compresses: every
local exact representative is the reference multiplied by its own central conversion
factor, and a global such factor does not exist. -/
theorem comparison_bridge_pattern {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    {n : Vec3} (hn : IsUnitAxis n) (θ : ℝ) :
    U n θ = Bridge U n θ ⋆ refFam n θ ∧ ¬ ∃ c : Vec3 → ℝ → W, IsGlobalBridge c :=
  ⟨bridge_factorization hU hn θ, no_global_bridge⟩

end NullSectorTask18
