import RequestProject.NullSectorTask18.Identification

/-!
# Task 18: the principal theorems

This module imports the complete Task-18 development and exposes the principal final
theorems, one group per package, together with the axiom report.

Source order of the development:

```
SafeBase
  → ConnectedAdmissibility   (Package A)
  → MaximalDomains           (Package B)
  → ReconstructionPredicates (Package C)
  → BridgeFactors            (Package D)
  → BridgeReconstruction     (Package E)
  → GlobalBridgeObstruction  (Package F)
  → RelationCoverage         (Package G)
  → DisconnectedDomains      (Package H)
  → RegularityAudit          (Package I)
  → NegativeControls
  → Identification           (COMPARISON ONLY, last)
  → Task18
```

`Identification` is imported by this module only; no reconstruction module depends on it,
and no Task-17 or Task-16 comparison module is reachable from any Task-18 reconstruction
module.

## Status table (Package J, §56)

| entry | status |
|---|---|
| preconnected admissibility `Admissible ↔ AntipodalFree` | **PROVED** (`task18_preconnected_admissibility`) |
| the same, empty domain, nonemptiness not required | **PROVED** (`task18_admissibility_empty`) |
| the five point-set notions are not interchangeable | **PROVED** (`task18_notions_separated`) |
| maximal connected admissible domains exist (constructed) | **PROVED** (`task18_lexA_maximal`) |
| inherited domains maximal among open preconnected admissible sets | **PROVED** (`task18_Dom_maximal_open_connected`) |
| inherited domains maximal among open admissible sets | **REFUTED** (`task18_Dom_not_maximal_open`) |
| inherited domains maximal among admissible sets | **REFUTED** (`task18_Dom_not_maximal_admissible`) |
| structural obstruction to enlargement = antipodal completeness | **PROVED** (`task18_maximal_iff_antipodalComplete`) |
| more than one connected admissible extension of every `Dom v` | **PROVED** (`task18_two_connected_extensions`) |
| canonical choice of a maximal connected admissible extension | **REFUTED** (`task18_maximal_extension_not_canonical`) |
| unrestricted literal global extension of the Task-17 system | **PROVED** (`task18_literal_extension_exists`) |
| literal sign-relaxed reconstruction of the Task-17 system | **REFUTED** (`task18_no_signRelaxed_reconstruction`) |
| existence and uniqueness of local bridges | **PROVED** (`task18_bridge_factorization`, `task18_bridge_unique`, `task18_bridge_central`) |
| bridge-rate classification (half-odd, one label on preconnected domains) | **PROVED** (`task18_bridge_rate_halfOdd`, `task18_bridge_one_label`) |
| bridge factorization `U = Bridge ⋆ refFam` | **PROVED** (`task18_bridge_factorization`) |
| overlap-as-bridge-difference; integer transition recovered | **PROVED** (`task18_overlap_is_bridge_difference`, `task18_integer_transition_recovered`) |
| bridge-normalized reconstruction (existence and uniqueness) | **PROVED** (`task18_bridge_normalized_reconstruction`) |
| sign-relaxed reconstruction **with explicit conversion factors** | **PROVED** (`task18_signRelaxed_with_factors`) |
| the three failure modes are distinct | **PROVED** (`task18_three_failure_modes`) |
| global bridge existence | **REFUTED** (`task18_no_global_bridge`) |
| equivalence: global exactness ↔ one global bridge | **PROVED** (`task18_globalExact_iff_globalBridge`) |
| where continuity / half-oddness / reversal enter | **PROVED** (`task18_globalBridge_rate_conditions`, `task18_three_conditions_pairwise_realizable`) |
| relation coverage by the inherited family | **REFUTED** (`task18_relation_coverage_refuted`); no antipodal-free family covers the relations (`task18_no_antipodalFree_family_covers`) |
| classification of cross-domain relations | **PROVED** (`task18_coincidence_cross_classification`); the second, degenerate class is harmless (`task18_degenerate_class_harmless`) |
| disconnected-component classification | **PROVED** (`task18_label_const_on_component`, `task18_component_label_criterion`, `task18_multi_label_domain`, `task18_labels_locally_constant`) |
| arbitrary-domain continuous versus `C¹` admissibility | **PROVED** (`task18_admissible_iff_c1`) |
| arbitrary spatial word problem | **OPEN** — untouched in Task 18 |
| maximal members of the plain admissible class | **OPEN** — not investigated; see the audit |

## Verdict (§ required Task-XVIII verdict)

**Yes**, with a precise residue.  Introducing the explicit central conversion factor from
each local exact representative to the unique global sign-relaxed reference *does* resolve
the local-to-global reconstruction mismatch discovered in Task 17:
`task18_signRelaxed_with_factors` and `task18_bridge_normalized_reconstruction` produce the
global object, uniquely, for an arbitrary covering system of admissible local exact
representatives, with all conversion data retained and nothing quotiented.  The original
global **exact** obstruction remains exactly where `task18_globalExact_iff_globalBridge`
places it: it is *equivalent* to the nonexistence of one global bridge, and by
`task18_globalBridge_rate_conditions` together with
`task18_three_conditions_pairwise_realizable` that nonexistence is the incompatibility of
the three conditions — continuity, half-oddness, reversal-oddness — no two of which already
conflict.
-/

namespace NullSectorTask18

open NullSectorTask01 NullSectorTask04 NullSectorTask06 NullSectorTask07 NullSectorTask08
open NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12 NullSectorTask13
open NullSectorTask14 NullSectorTask15 NullSectorTask16 NullSectorTask17

/-! ## Package A — connected admissibility -/

theorem task18_preconnected_admissibility {D : Set Vec3} (hunit : UnitSet D)
    (hpre : PreconnDomain D) : IsAdmissibleDomain D ↔ AntipodalFree D :=
  admissible_iff_antipodalFree_of_preconn hunit hpre

theorem task18_admissibility_empty :
    IsAdmissibleDomain (∅ : Set Vec3) ∧ AntipodalFree (∅ : Set Vec3) ∧
      (IsAdmissibleDomain (∅ : Set Vec3) ↔ AntipodalFree (∅ : Set Vec3)) :=
  admissible_iff_antipodalFree_empty

theorem task18_connected_admissibility {D : Set Vec3} (hunit : UnitSet D)
    (hconn : ConnDomain D) : IsAdmissibleDomain D ↔ AntipodalFree D :=
  admissible_iff_antipodalFree_of_conn hunit hconn

theorem task18_pathConnected_admissibility {D : Set Vec3} (hunit : UnitSet D)
    (hpath : PathConnDomain D) : IsAdmissibleDomain D ↔ AntipodalFree D :=
  admissible_iff_antipodalFree_of_pathConn hunit hpath

theorem task18_notions_separated {n : Vec3} (hn : IsUnitAxis n) :
    (PreconnDomain (∅ : Set Vec3) ∧ ¬ ConnDomain (∅ : Set Vec3)) ∧
      (IsAdmissibleDomain ({n, -n} : Set Vec3) ∧ ¬ PreconnDomain ({n, -n} : Set Vec3)) :=
  ⟨empty_preconn_not_conn, antipodal_pair_not_preconn hn⟩

/-! ## Package B — maximal connected admissible domains -/

theorem task18_maximal_iff_antipodalComplete {D : Set Vec3} (hunit : UnitSet D)
    (hfree : AntipodalFree D) :
    (∀ E : Set Vec3, UnitSet E → AntipodalFree E → D ⊆ E → E = D) ↔ AntipodalComplete D :=
  maximal_antipodalFree_iff_complete hunit hfree

theorem task18_lexA_maximal :
    PathConnDomain lexA ∧ IsAdmissibleDomain lexA ∧ IsMaximalIn PreconnAdmClass lexA :=
  ⟨lexA_pathConn, lexA_admissible, lexA_maximal⟩

theorem task18_Dom_maximal_open_connected {v : Vec3} (hv : v ≠ 0) :
    IsMaximalIn OpenConnAdmClass (Dom v) := Dom_maximal_openConnAdm hv

theorem task18_Dom_not_maximal_open : ¬ IsMaximalIn OpenAdmClass (Dom e1) :=
  Dom_not_maximal_openAdm.2.2.2

theorem task18_Dom_not_maximal_admissible {v : Vec3} (hv : v ≠ 0) :
    ¬ IsMaximalIn AdmClass (Dom v) := Dom_not_maximal_adm hv

theorem task18_two_connected_extensions {v : Vec3} (hv : v ≠ 0) :
    ∃ E₁ E₂ : Set Vec3,
      (UnitSet E₁ ∧ PathConnDomain E₁ ∧ IsAdmissibleDomain E₁) ∧
      (UnitSet E₂ ∧ PathConnDomain E₂ ∧ IsAdmissibleDomain E₂) ∧
      Dom v ⊆ E₁ ∧ Dom v ⊆ E₂ ∧ ¬ E₁ ⊆ E₂ ∧ ¬ E₂ ⊆ E₁ :=
  Dom_two_connected_extensions hv

theorem task18_maximal_extension_not_canonical :
    lexA ≠ lexB ∧ Dom e1 ⊆ lexA ∧ Dom e1 ⊆ lexB ∧
      IsMaximalIn PreconnAdmClass lexA ∧ IsMaximalIn PreconnAdmClass lexB ∧
      (∀ k : ℤ, IsTransformationValuedOn lexA (locFam k)) ∧
      (∀ k : ℤ, IsTransformationValuedOn lexB (locFam k)) :=
  maximal_extension_not_canonical

/-! ## Package C — the two reconstruction problems -/

theorem task18_literal_extension_exists :
    HasLiteralGlobalExtension Dom task17System :=
  task17System_hasLiteralGlobalExtension

theorem task18_no_signRelaxed_reconstruction :
    ¬ HasSignRelaxedReconstruction Dom task17System :=
  task17System_no_signRelaxedReconstruction

theorem task18_two_problems_differ :
    HasLiteralGlobalExtension Dom task17System ∧
      ¬ HasSignRelaxedReconstruction Dom task17System :=
  literal_and_signRelaxed_differ

/-! ## Package D — the local-to-reference bridge -/

theorem task18_bridge_central {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U) {n : Vec3}
    (hn : IsUnitAxis n) (θ : ℝ) : Bridge U n θ ∈ Z := bridge_central hU hn θ

theorem task18_bridge_factorization {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    {n : Vec3} (hn : IsUnitAxis n) (θ : ℝ) : U n θ = Bridge U n θ ⋆ refFam n θ :=
  bridge_factorization hU hn θ

theorem task18_bridge_unique {U : Vec3 → ℝ → W} {n : Vec3} (hn : IsUnitAxis n) {θ : ℝ}
    {c : W} (h : U n θ = c ⋆ refFam n θ) : c = Bridge U n θ := bridge_unique hn h

theorem task18_bridge_rate {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U) {n : Vec3}
    (hn : IsUnitAxis n) (hα : rateAlpha U n = 0) (θ : ℝ) :
    Bridge U n θ = zexp 0 (rateBeta U n) θ := bridge_eq_zexp hU hn hα θ

theorem task18_bridge_rate_halfOdd {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    {D : Set Vec3} (hexact : IsTransformationValuedOn D U) {n : Vec3} (hnD : n ∈ D)
    (hn : IsUnitAxis n) :
    IsHalfOdd (rateBeta U n) ∧
      ∃ k : ℤ, ∀ θ : ℝ, Bridge U n θ = zexp 0 ((k : ℝ) + 1 / 2) θ :=
  bridge_rate_halfOdd hU hexact hnD hn

theorem task18_bridge_one_label {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    {D : Set Vec3} (hunit : UnitSet D) (hpre : PreconnDomain D)
    (hexact : IsTransformationValuedOn D U) {n₀ : Vec3} (hn₀ : n₀ ∈ D) :
    ∃! k : ℤ, ∀ n ∈ D, ∀ θ : ℝ, Bridge U n θ = zexp 0 ((k : ℝ) + 1 / 2) θ :=
  bridge_unique_label hU hunit hpre hexact hn₀

theorem task18_overlap_is_bridge_difference {U V : Vec3 → ℝ → W}
    (hV : IsJointlyRegularFamily V) {n : Vec3} (hn : IsUnitAxis n) (θ : ℝ) :
    ovl U V n θ ⋆ Bridge V n θ = Bridge U n θ := overlap_eq_bridge_difference hV hn θ

theorem task18_integer_transition_recovered {U V : Vec3 → ℝ → W}
    (hU : IsJointlyRegularFamily U) (hV : IsJointlyRegularFamily V) {DU DV : Set Vec3}
    (hexU : IsTransformationValuedOn DU U) (hexV : IsTransformationValuedOn DV V)
    {n : Vec3} (hnU : n ∈ DU) (hnV : n ∈ DV) (hn : IsUnitAxis n) :
    ∃ j : ℤ, ∀ θ : ℝ, ovl U V n θ = zexp 0 (j : ℝ) θ :=
  integer_transition_from_bridges hU hV hexU hexV hnU hnV hn

/-! ## Package E — bridge-normalized reconstruction -/

theorem task18_bridge_normalized_reconstruction {ι : Type*} {D : ι → Set Vec3}
    {F : ι → Vec3 → ℝ → W} (hS : IsCoveringLocalSystem D F) :
    (∀ i : ι, ∀ n ∈ D i, ∀ θ : ℝ, bridgeNormalize (F i) n θ = refFam n θ) ∧
      IsJointlyRegularFamily refFam ∧ IsSignTransformationValued refFam ∧
      (∀ G : Vec3 → ℝ → W, (∀ i : ι, ∀ n ∈ D i, ∀ θ : ℝ, bridgeNormalize (F i) n θ = G n θ) →
        ∀ n : Vec3, IsUnitAxis n → ∀ θ : ℝ, G n θ = refFam n θ) ∧
      (∀ i : ι, ∀ n ∈ D i, ∀ θ : ℝ,
        F i n θ = Bridge (F i) n θ ⋆ refFam n θ ∧ Bridge (F i) n θ ∈ Z) :=
  bridge_normalized_reconstruction hS

theorem task18_signRelaxed_with_factors :
    HasSignRelaxedReconstructionWithFactors Dom task17System :=
  task17System_hasSignRelaxedReconstructionWithFactors

theorem task18_three_failure_modes :
    (¬ HasLiteralGlobalExtension (fun _ : Bool => Dom e1) twoLabelSystem) ∧
      HasLiteralGlobalExtension Dom task17System ∧
      (¬ HasSignRelaxedReconstruction Dom task17System) ∧
      HasSignRelaxedReconstructionWithFactors Dom task17System :=
  three_failure_modes_distinguished

/-! ## Package F — the global bridge -/

theorem task18_globalExact_iff_globalBridge :
    (∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧ IsTransformationValued U) ↔
      ∃ c : Vec3 → ℝ → W, IsGlobalBridge c := globalExact_iff_globalBridge

theorem task18_no_global_bridge : ¬ ∃ c : Vec3 → ℝ → W, IsGlobalBridge c := no_global_bridge

theorem task18_globalBridge_rate_conditions {c : Vec3 → ℝ → W} (hc : IsGlobalBridge c) :
    ∃ b : Vec3 → ℝ, (Continuous fun s : Sph => b (s : Vec3)) ∧
      (∀ n : Vec3, IsUnitAxis n → IsHalfOdd (b n)) ∧
      (∀ n : Vec3, IsUnitAxis n → b (-n) = -b n) ∧
      (∀ n : Vec3, IsUnitAxis n → ∀ θ : ℝ, c n θ = zexp 0 (b n) θ) :=
  globalBridge_rate_conditions hc

theorem task18_three_conditions_pairwise_realizable :
    (∃ b : Vec3 → ℝ, (Continuous fun s : Sph => b (s : Vec3)) ∧
      (∀ n : Vec3, IsUnitAxis n → b (-n) = -b n) ∧
      ¬ (∀ n : Vec3, IsUnitAxis n → IsHalfOdd (b n))) ∧
    (∃ b : Vec3 → ℝ, (Continuous fun s : Sph => b (s : Vec3)) ∧
      (∀ n : Vec3, IsUnitAxis n → IsHalfOdd (b n)) ∧
      ¬ (∀ n : Vec3, IsUnitAxis n → b (-n) = -b n)) ∧
    (∃ b : Vec3 → ℝ, (∀ n : Vec3, IsUnitAxis n → IsHalfOdd (b n)) ∧
      (∀ n : Vec3, IsUnitAxis n → b (-n) = -b n) ∧
      ¬ (Continuous fun s : Sph => b (s : Vec3))) :=
  three_conditions_pairwise_realizable

/-! ## Package G — relation coverage -/

theorem task18_relation_coverage_refuted :
    CoversDirections Dom ∧ ¬ CoversRelations Dom :=
  Dom_coversDirections_not_coversRelations

theorem task18_no_antipodalFree_family_covers {ι : Type*} {D : ι → Set Vec3}
    (hfree : ∀ i : ι, AntipodalFree (D i)) : ¬ CoversRelations D :=
  antipodalFree_family_not_coversRelations hfree

theorem task18_coincidence_cross_classification {n m : Vec3} (hn : IsUnitAxis n)
    (hm : IsUnitAxis m) {θ φ : ℝ} (h : Coincident n θ m φ) :
    m = n ∨ m = -n ∨ ((∃ k : ℤ, θ = 2 * Real.pi * k) ∧ ∃ l : ℤ, φ = 2 * Real.pi * l) :=
  coincidence_cross_classification hn hm h

theorem task18_degenerate_class_harmless (k : ℤ) {n m : Vec3} (hn : IsUnitAxis n)
    (hm : IsUnitAxis m) :
    Coincident n (2 * Real.pi) m 0 ∧ locFam k n (2 * Real.pi) = locFam k m 0 :=
  ⟨degenerate_cross_coincidence hn hm, degenerate_relations_satisfied k n m⟩

/-! ## Package H — disconnected admissible domains -/

theorem task18_label_const_on_component {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    {D : Set Vec3} (hunit : UnitSet D) (hexact : IsTransformationValuedOn D U) (s : Sph) :
    ∀ t ∈ connectedComponentIn (sphSet D) s, ∀ t' ∈ connectedComponentIn (sphSet D) s,
      rateBeta U (t : Vec3) = rateBeta U (t' : Vec3) :=
  label_const_on_component hU hunit hexact s

theorem task18_component_label_criterion {D : Set Vec3} (hunit : UnitSet D) (l : Vec3 → ℤ) :
    (∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧ IsTransformationValuedOn D U ∧
        ∀ n ∈ D, rateBeta U n = (l n : ℝ) + 1 / 2) ↔
      (∃ b : Vec3 → ℝ, (Continuous fun s : Sph => b (s : Vec3)) ∧
        (∀ n ∈ D, b n = (l n : ℝ) + 1 / 2) ∧ (∀ n ∈ D, -n ∈ D → b (-n) = -b n)) :=
  component_label_criterion hunit l

theorem task18_multi_label_domain :
    IsAdmissibleDomain multiD ∧
      e1 ∈ multiD ∧ -e1 ∈ multiD ∧ p35 ∈ multiD ∧ -p35 ∈ multiD ∧
      ∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧ IsTransformationValuedOn multiD U ∧
        rateBeta U e1 = 5 / 2 ∧ rateBeta U (-e1) = -(5 / 2) ∧
        rateBeta U p35 = 3 / 2 ∧ rateBeta U (-p35) = -(3 / 2) :=
  multiD_admissible_four_labels

theorem task18_labels_locally_constant {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    {D : Set Vec3} (hunit : UnitSet D) (hexact : IsTransformationValuedOn D U) (p : Sph) :
    ∃ ε > 0, ∀ s t : Sph, (s : Vec3) ∈ D → (t : Vec3) ∈ D →
      dist s p < ε → dist t p < ε → rateBeta U (s : Vec3) = rateBeta U (t : Vec3) :=
  admissible_labels_locally_constant hU hunit hexact p

/-! ## Package I — arbitrary-domain `C¹` admissibility -/

theorem task18_admissible_iff_c1 {D : Set Vec3} :
    IsAdmissibleDomain D ↔ IsC1AdmissibleDomain D := admissible_iff_c1Admissible

/-! ## Negative controls -/

theorem task18_control_bridge_not_halfOdd :
    ∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧
      (∀ n : Vec3, IsUnitAxis n → ∀ θ : ℝ, Bridge U n θ ∈ Z) ∧
      (∀ n : Vec3, IsUnitAxis n → ∀ θ : ℝ, Bridge U n θ = zexp 0 (1 / 3) θ) ∧
      ¬ IsHalfOdd (1 / 3 : ℝ) :=
  bridge_central_but_not_halfOdd

theorem task18_control_direction_dependent :
    ∃ (U : Vec3 → ℝ → W) (D : Set Vec3), IsJointlyRegularFamily U ∧
      IsTransformationValuedOn D U ∧ e1 ∈ D ∧ p35 ∈ D ∧
      (∀ θ : ℝ, Bridge U e1 θ = zexp 0 (5 / 2) θ) ∧
      (∀ θ : ℝ, Bridge U p35 θ = zexp 0 (3 / 2) θ) :=
  bridge_direction_dependent

theorem task18_control_normalization {v : Vec3} (hv : v ≠ 0) :
    (∀ n ∈ Dom v, ∀ θ : ℝ, bridgeNormalize (locFam 0) n θ = refFam n θ) ∧
      ¬ IsTransformationValuedOn (Dom v) refFam :=
  normalization_does_not_preserve_exactness hv

theorem task18_control_bridge_nontrivial : Bridge (locFam 0) e1 Real.pi ≠ w1 :=
  bridge_locFam_ne_one

theorem task18_control_no_quotient {U V : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    (hV : IsJointlyRegularFamily V) {n : Vec3} (hn : IsUnitAxis n) {θ : ℝ}
    (h : Bridge U n θ = Bridge V n θ) : U n θ = V n θ :=
  bridge_determines_family hU hV hn h

/-! ## Comparison layer (imported by this module only) -/

theorem task18_comparison_bridge_pattern {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    {n : Vec3} (hn : IsUnitAxis n) (θ : ℝ) :
    U n θ = Bridge U n θ ⋆ refFam n θ ∧ ¬ ∃ c : Vec3 → ℝ → W, IsGlobalBridge c :=
  comparison_bridge_pattern hU hn θ

/-! ## Axiom report -/

#print axioms task18_preconnected_admissibility
#print axioms task18_admissibility_empty
#print axioms task18_connected_admissibility
#print axioms task18_pathConnected_admissibility
#print axioms task18_notions_separated
#print axioms task18_maximal_iff_antipodalComplete
#print axioms task18_lexA_maximal
#print axioms task18_Dom_maximal_open_connected
#print axioms task18_Dom_not_maximal_open
#print axioms task18_Dom_not_maximal_admissible
#print axioms task18_two_connected_extensions
#print axioms task18_maximal_extension_not_canonical
#print axioms task18_literal_extension_exists
#print axioms task18_no_signRelaxed_reconstruction
#print axioms task18_two_problems_differ
#print axioms task18_bridge_central
#print axioms task18_bridge_factorization
#print axioms task18_bridge_unique
#print axioms task18_bridge_rate
#print axioms task18_bridge_rate_halfOdd
#print axioms task18_bridge_one_label
#print axioms task18_overlap_is_bridge_difference
#print axioms task18_integer_transition_recovered
#print axioms task18_bridge_normalized_reconstruction
#print axioms task18_signRelaxed_with_factors
#print axioms task18_three_failure_modes
#print axioms task18_globalExact_iff_globalBridge
#print axioms task18_no_global_bridge
#print axioms task18_globalBridge_rate_conditions
#print axioms task18_three_conditions_pairwise_realizable
#print axioms task18_relation_coverage_refuted
#print axioms task18_no_antipodalFree_family_covers
#print axioms task18_coincidence_cross_classification
#print axioms task18_degenerate_class_harmless
#print axioms task18_label_const_on_component
#print axioms task18_component_label_criterion
#print axioms task18_multi_label_domain
#print axioms task18_labels_locally_constant
#print axioms task18_admissible_iff_c1
#print axioms task18_control_bridge_not_halfOdd
#print axioms task18_control_direction_dependent
#print axioms task18_control_normalization
#print axioms task18_control_bridge_nontrivial
#print axioms task18_control_no_quotient
#print axioms task18_comparison_bridge_pattern

end NullSectorTask18
