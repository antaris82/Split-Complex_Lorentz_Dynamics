import RequestProject.NullSectorTask04.Classification

/-!
# Task 04, Layer 6: identity audit for the reconstructed global products

Each identity is tested separately, by a direct theorem statement rather than
by typeclass packaging, and each test returns either a proof or an explicit
counterexample.  No property is inferred from the name of any algebra.
-/

namespace NullSectorTask04

open NullSectorTask01

/-! ## Named test properties -/

/-- Left alternativity. -/
def LeftAlternative (M : BiProd4) : Prop := ∀ X Y, M (M X X) Y = M X (M X Y)

/-- Flexibility. -/
def Flexible (M : BiProd4) : Prop := ∀ X Y, M (M X Y) X = M X (M Y X)

/-- Third-degree power associativity. -/
def PowerAssoc3 (M : BiProd4) : Prop := ∀ X, M (M X X) X = M X (M X X)

/-- Fourth-degree power associativity. -/
def PowerAssoc4 (M : BiProd4) : Prop := ∀ X, M (M X X) (M X X) = M (M (M X X) X) X

/-- The Jordan identity. -/
def JordanIdentity (M : BiProd4) : Prop := ∀ X Y, M (M (M X X) Y) X = M (M X X) (M Y X)

/-! ## Convenient coordinate vectors -/

/-- The three spatial coordinate directions, as ambient vectors. -/
def E1 : Vec4 := (0, 1, 0, 0)
def E2 : Vec4 := (0, 0, 1, 0)
def E3 : Vec4 := (0, 0, 0, 1)

theorem E1_eq_sp : E1 = sp s₁ := rfl
theorem E2_eq_sp : E2 = sp s₂ := rfl
theorem E3_eq_sp : E3 = sp s₃ := rfl

@[simp] theorem E1_snd : E1.2 = s₁ := rfl
@[simp] theorem E2_snd : E2.2 = s₂ := rfl
@[simp] theorem E3_snd : E3.2 = s₃ := rfl

/-! ## Sectorwise properties (positive results) -/

section
variable {M : BiProd4} (hM : SectorCompatible M)
include hM

/-- **SECTORWISE Q-MULTIPLICATIVITY.**  Inside every longitudinal sector the
product is `Q4`-multiplicative. -/
theorem sector_qMultiplicative {s : Vec4} (hs : UnitSpacelike s) (X Y : Long) :
    Q4 (M (iotaS s X) (iotaS s Y)) = Q4 (iotaS s X) * Q4 (iotaS s Y) := by
  rw [hM s hs X Y, Q4_iotaS_Q2 hs, Q4_iotaS_Q2 hs, Q4_iotaS_Q2 hs, muLong_qmul]

/-- **SECTORWISE ASSOCIATIVITY.**  Inside every longitudinal sector the product
is associative, for *every* sector-compatible global product. -/
theorem sector_associative {s : Vec4} (hs : UnitSpacelike s) (X Y Z : Long) :
    M (M (iotaS s X) (iotaS s Y)) (iotaS s Z) = M (iotaS s X) (M (iotaS s Y) (iotaS s Z)) := by
  rw [hM s hs X Y, hM s hs Y Z, hM s hs (muLong X Y) Z, hM s hs X (muLong Y Z), muLong_assoc]

/-- **SECTORWISE COMMUTATIVITY.** -/
theorem sector_commutative {s : Vec4} (hs : UnitSpacelike s) (X Y : Long) :
    M (iotaS s X) (iotaS s Y) = M (iotaS s Y) (iotaS s X) := by
  rw [hM s hs X Y, hM s hs Y X, muLong_comm]

end

/-! ## The symmetric branch: positive identities -/

/-- **PROVED.**  Flexibility of the symmetric branch. -/
theorem mu4sym_flexible : Flexible mu4sym := by
  intro X Y
  rw [mu4sym_comm (mu4sym X Y) X, mu4sym_comm Y X]

/-- **PROVED.**  Third-degree power associativity. -/
theorem mu4sym_powerAssoc3 : PowerAssoc3 mu4sym := by
  intro X
  rw [mu4sym_comm (mu4sym X X) X]

/-- **PROVED.**  Fourth-degree power associativity. -/
theorem mu4sym_powerAssoc4 : PowerAssoc4 mu4sym := by
  intro X
  apply vec4_ext <;> simp [dot3] <;> ring

/-- **PROVED.**  The symmetric branch satisfies the Jordan identity. -/
theorem mu4sym_jordan : JordanIdentity mu4sym := by
  intro X Y
  apply vec4_ext <;> simp [dot3] <;> ring

/-! ## The symmetric branch: refutations -/

@[simp] theorem mu4sym_E1_E2 : mu4sym E1 E2 = 0 := by
  apply vec4_ext <;> simp [dot3, E1, E2]

@[simp] theorem mu4sym_E2_E2 : mu4sym E2 E2 = e₀ := by
  apply vec4_ext <;> simp [dot3, e₀, E2]

@[simp] theorem mu4sym_E1_e₀ : mu4sym E1 e₀ = E1 := by
  apply vec4_ext <;> simp [dot3, e₀, E1]

/-- **REFUTED BY EXPLICIT COUNTEREXAMPLE.**  The symmetric branch is not
associative; the counterexample uses two linearly independent spatial
directions. -/
theorem mu4sym_not_associative : ¬ Associative4 mu4sym := by
  intro hassoc
  have h := hassoc E1 E2 E2
  rw [mu4sym_E1_E2, mu4sym_E2_E2, mu4sym_E1_e₀] at h
  rw [LinearMap.map_zero₂] at h
  simp [E1, Prod.ext_iff] at h

/-- **REFUTED BY EXPLICIT COUNTEREXAMPLE.**  The symmetric branch is not left
alternative. -/
theorem mu4sym_not_leftAlternative : ¬ LeftAlternative mu4sym := by
  intro halt
  have h := halt E1 E2
  have h1 : mu4sym E1 E1 = e₀ := by apply vec4_ext <;> simp [dot3, e₀, E1]
  rw [h1, mu4sym_E1_E2] at h
  have h2 : mu4sym e₀ E2 = E2 := by apply vec4_ext <;> simp [dot3, e₀, E2]
  rw [h2, LinearMap.map_zero] at h
  simp [E2, Prod.ext_iff] at h

/-- **REFUTED BY EXPLICIT COUNTEREXAMPLE.**  Global `Q4`-multiplicativity fails
for the symmetric branch: the two arguments lie in *different* spatial
directions. -/
theorem mu4sym_not_Q4Multiplicative : ¬ Q4Multiplicative mu4sym := by
  intro hq
  have h := hq E1 E2
  rw [mu4sym_E1_E2] at h
  simp [Q4, E1, E2] at h

/-! ## The one-parameter family: refutations for every real parameter -/

@[simp] theorem altBasis_s₁_s₂ : altBasis s₁ s₂ = E3 := by
  apply vec4_ext <;> simp [s₁, s₂, E3]

@[simp] theorem altBasis_s₃_s₂ : altBasis s₃ s₂ = -E1 := by
  apply vec4_ext <;> simp [s₃, s₂, E1]

theorem muFam_E1_E2 (lam : ℝ) : muFam lam E1 E2 = lam • E3 := by
  rw [muFam_apply, mu4sym_E1_E2, E1_snd, E2_snd, altBasis_s₁_s₂, zero_add]

theorem muFam_E3_E2 (lam : ℝ) : muFam lam E3 E2 = -(lam • E1) := by
  have h0 : mu4sym E3 E2 = 0 := by apply vec4_ext <;> simp [dot3, E3, E2]
  rw [muFam_apply, h0, E3_snd, E2_snd, altBasis_s₃_s₂, zero_add, smul_neg]

theorem muFam_E2_E2 (lam : ℝ) : muFam lam E2 E2 = e₀ := by
  have h0 : altBasis s₂ s₂ = 0 := altBasis_isAlt s₂
  rw [muFam_apply, mu4sym_E2_E2, E2_snd, h0, smul_zero, add_zero]

theorem muFam_E1_e₀ (lam : ℝ) : muFam lam E1 e₀ = E1 := by
  have h0 : altBasis s₁ 0 = 0 := by rw [map_zero]
  rw [muFam_apply, mu4sym_E1_e₀, E1_snd, e₀_snd, h0, smul_zero, add_zero]

/-- **PROVED IMPOSSIBLE.**  No member of the one-parameter family is
associative: the obstruction is the equation `-lam^2 = 1`, which has no real
solution. -/
theorem muFam_not_associative (lam : ℝ) : ¬ Associative4 (muFam lam) := by
  intro hassoc
  have h := hassoc E1 E2 E2
  rw [muFam_E1_E2, muFam_E2_E2, muFam_E1_e₀] at h
  rw [M_smul_left, muFam_E3_E2] at h
  have h1 : lam • -(lam • E1) = (-(lam ^ 2)) • E1 := by
    rw [smul_neg, smul_smul, ← neg_smul]
    congr 1
    ring
  rw [h1] at h
  have h3 : -(lam ^ 2) = 1 := by
    have := congrArg (fun Z : Vec4 => Z.2.1) h
    simpa [E1] using this
  nlinarith [sq_nonneg lam]

/-- **PROVED IMPOSSIBLE.**  No member of the one-parameter family is globally
`Q4`-multiplicative: the obstruction is again `-lam^2 = 1`. -/
theorem muFam_not_Q4Multiplicative (lam : ℝ) : ¬ Q4Multiplicative (muFam lam) := by
  intro hq
  have h := hq E1 E2
  rw [muFam_E1_E2] at h
  have h1 : Q4 (lam • E3) = -(lam ^ 2) := by
    simp [Q4, E3]
  have h2 : Q4 E1 * Q4 E2 = 1 := by simp [Q4, E1, E2]
  rw [h1, h2] at h
  nlinarith [sq_nonneg lam]

/-- The same obstruction, stated as an exact equation on the parameter. -/
theorem muFam_associativity_equation (lam : ℝ) :
    (Associative4 (muFam lam) → -(lam ^ 2) = 1) ∧
      (Q4Multiplicative (muFam lam) → -(lam ^ 2) = 1) := by
  constructor
  · intro hassoc; exact absurd hassoc (muFam_not_associative lam)
  · intro hq; exact absurd hq (muFam_not_Q4Multiplicative lam)

end NullSectorTask04
