import RequestProject.NullSectorTask04.Overlap
import RequestProject.NullSectorTask01.SplitComplex
import Mathlib.LinearAlgebra.CrossProduct

/-!
# Task 04, Layer 10: late mathematical identification — COMPARISON ONLY

Everything in this file is a *comparison*.  Nothing proved here is used anywhere
in the Task-04 core: the classification files
`Lorentz4 → RestSpace → Sectors → GlobalExtension → Classification →
IdentityAudit → Isotropy → ProperIsotropy → Overlap`
do not import this module, and none of the objects compared here appears as an
input to any construction.

Three comparisons are recorded.

1. The Task-02 longitudinal product used throughout Task 04 agrees, in
   coordinates, with the Task-01 explicit split-complex multiplication.  Task 04
   never used this fact: `muLong` was taken from the Task-02 reconstruction.
2. The forced symmetric branch `mu4sym`, derived here purely from the family of
   longitudinal sectors, is the product
   `(a,v) ∘ (b,w) = (a b + v·w, a w + b v)` on `ℝ ⊕ ℝ³`.  This is the standard
   commutative (Jordan) *spin factor* product.  The Jordan identity for it was
   *proved* in `IdentityAudit`, not assumed.
3. The basic alternating gluing defect `alt3`, derived here from the
   proper-isotropy classification, coincides with Mathlib's `crossProduct` on
   `Fin 3 → ℝ` under the obvious coordinate identification.  The cross product
   was not used anywhere in the derivation.
-/

namespace NullSectorTask04

open NullSectorTask01 Matrix

/-! ## Comparison 1: the longitudinal product -/

/-- **COMPARISON ONLY.**  The Task-02 reconstructed longitudinal product agrees
with the Task-01 explicit split-complex multiplication. -/
theorem muLong_eq_mulL (X Y : Long) : muLong X Y = NullSectorTask01.mulL X Y := rfl

/-! ## Comparison 2: the forced symmetric branch -/

/-- The conventional spin-factor / Jordan product on `ℝ ⊕ ℝ³`, written out
independently for the comparison. -/
def spinFactorProduct (X Y : Vec4) : Vec4 :=
  (X.1 * Y.1 + dot3 X.2 Y.2, X.1 • Y.2 + Y.1 • X.2)

/-- **COMPARISON ONLY.**  The independently derived symmetric branch is exactly
the conventional spin-factor (Jordan) product. -/
theorem mu4sym_eq_spinFactorProduct (X Y : Vec4) :
    mu4sym X Y = spinFactorProduct X Y := by
  apply vec4_ext <;> simp [spinFactorProduct, dot3]

/-- **COMPARISON ONLY.**  Restated: the two standard Jordan axioms hold, both of
them proved in the core development rather than assumed. -/
theorem mu4sym_is_jordan :
    Commutative4 mu4sym ∧ JordanIdentity mu4sym :=
  ⟨mu4sym_comm, mu4sym_jordan⟩

/-! ## Comparison 3: the basic alternating defect -/

/-- Coordinate identification of the rest-space carrier with `Fin 3 → ℝ`. -/
def toFin3 (v : Vec3) : Fin 3 → ℝ := ![v.1, v.2.1, v.2.2]

/-- **COMPARISON ONLY.**  The alternating operation produced by the
proper-isotropy classification is the conventional three-dimensional vector
product. -/
theorem alt3_eq_crossProduct (v w : Vec3) :
    toFin3 (alt3 v w) = crossProduct (toFin3 v) (toFin3 w) := by
  rw [cross_apply]
  funext i
  fin_cases i <;> simp [toFin3, alt3]

/-- **COMPARISON ONLY.**  Consequently the one-parameter family classified by
proper isotropy is, in conventional language, the spin-factor product plus
`lam` times the vector product on the rest space. -/
theorem muFam_comparison (lam : ℝ) (X Y : Vec4) :
    toFin3 (muFam lam X Y).2 =
      toFin3 (spinFactorProduct X Y).2 + lam • crossProduct (toFin3 X.2) (toFin3 Y.2) := by
  rw [← alt3_eq_crossProduct]
  funext i
  fin_cases i <;> simp [toFin3, alt3, spinFactorProduct, dot3]

end NullSectorTask04
