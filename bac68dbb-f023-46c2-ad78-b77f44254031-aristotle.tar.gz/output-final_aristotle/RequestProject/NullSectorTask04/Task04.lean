import RequestProject.NullSectorTask04.Overlap
import RequestProject.NullSectorTask04.Identification

/-!
# Task 04 — principal theorems

Compatibility and gluing of all longitudinal 1+1 sectors inside the real 3+1
Lorentz carrier.

This module imports the complete Task-04 development and restates its principal
results under stable names.  The *core* classification (everything except the
final comparison layer) lives in

```
Lorentz4 → RestSpace → Sectors → GlobalExtension → Classification
        → IdentityAudit → Isotropy → ProperIsotropy → Overlap
```

and imports, from Tasks 01–03, only `NullSectorTask01.Basic` (carrier and
quadratic forms) and `NullSectorTask02.FixedUnit` (the reconstructed
longitudinal product).  The module `Identification` is a **comparison only**
layer and is not used by any core result.

The `#print axioms` commands at the end of this file constitute the axiom
report.
-/

namespace NullSectorTask04

open NullSectorTask01

/-! ## 1. The polarized form is derived from `Q4` -/

/-- **DERIVED.**  Polarization of `Q4`: the exact coordinate formula, the
diagonal identity, and the uniqueness of the polarization. -/
theorem task04_polarization :
    (∀ t x y z t' x' y' z' : ℝ,
      L4 (t, x, y, z) (t', x', y', z') = t * t' - x * x' - y * y' - z * z') ∧
    (∀ X : Vec4, L4 X X = Q4 X) ∧
    (∀ B : Vec4 → Vec4 → ℝ, (∀ X Y, B X Y = B Y X) →
      (∀ X Y Z, B (X + Y) Z = B X Z + B Y Z) → (∀ X, B X X = Q4 X) →
      ∀ X Y, B X Y = L4 X Y) :=
  ⟨L4_apply, L4_self, L4_unique_of_diagonal⟩

/-! ## 2. The rest space and its positive form -/

/-- **DERIVED.**  The reference unit is normalized, the rest space is exactly the
set of vectors with vanishing time coordinate, and the induced form `h = -L4` is
positive semidefinite on it, definite, and equal to the ordinary spatial dot
product in coordinates. -/
theorem task04_rest_space :
    Q4 e₀ = 1 ∧
    (∀ X : Vec4, X ∈ Rest ↔ L4 e₀ X = 0) ∧
    (∀ v w : Vec3, h (sp v) (sp w) = dot3 v w) ∧
    (∀ X : Vec4, X ∈ Rest → 0 ≤ h X X) ∧
    (∀ X : Vec4, X ∈ Rest → (h X X = 0 ↔ X = 0)) := by
  refine ⟨Q4_e₀, ?_, h_sp, fun X hX => h_nonneg hX, fun X hX => h_eq_zero_iff hX⟩
  intro X
  rw [mem_Rest, L4_e₀_left]

/-! ## 3. Every unit spatial direction gives an exact 1+1 Lorentz sector -/

/-- **DERIVED.**  For every unit spacelike direction the embedding
`(a,b) ↦ a e₀ + b s` is an isometry onto its longitudinal plane, both for the
quadratic form and for its polarization, and it is injective. -/
theorem task04_sector_embedding {s : Vec4} (hs : UnitSpacelike s) :
    (∀ X : Long, Q4 (iotaS s X) = X.1 ^ 2 - X.2 ^ 2) ∧
    (∀ X : Long, Q4 (iotaS s X) = Q2 X) ∧
    (∀ X Y : Long, L4 (iotaS s X) (iotaS s Y) = NullSectorTask02.L2 X Y) ∧
    Function.Injective (iotaS s) :=
  ⟨Q4_iotaS hs, Q4_iotaS_Q2 hs, L4_iotaS hs, iotaS_injective hs⟩

/-- **DERIVED.**  The sector product is the Task-02 reconstruction transported
through the embedding; it inherits every sectorwise property. -/
theorem task04_sector_product {s : Vec4} (hs : UnitSpacelike s) :
    (∀ μ : NullSectorTask02.BiProd,
      NullSectorTask02.AdmissibleAt NullSectorTask02.u₀ μ → μ = muLong) ∧
    (∀ X Y : Long, Q2 (muLong X Y) = Q2 X * Q2 Y) ∧
    (∀ X Y Z : Long, muLong (muLong X Y) Z = muLong X (muLong Y Z)) ∧
    (∀ X Y : Long, sectorProd s X Y = iotaS s (muLong X Y)) ∧
    (∀ X Y : Long, Q4 (sectorProd s X Y) = Q4 (iotaS s X) * Q4 (iotaS s Y)) :=
  ⟨fun _ hμ => muLong_unique hμ, muLong_qmul, muLong_assoc, fun _ _ => rfl, fun X Y => by
    rw [sectorProd_apply, Q4_iotaS_Q2 hs, Q4_iotaS_Q2 hs, Q4_iotaS_Q2 hs, muLong_qmul]⟩

/-! ## 4. The global unit is derived, not assumed -/

/-- **GLOBAL UNIT: DERIVED.**  Sector compatibility alone forces `e₀` to be a
two-sided unit. -/
theorem task04_global_unit {M : BiProd4} (hM : SectorCompatible M) : GlobalUnit M :=
  M_globalUnit hM

/-! ## 5. Spatial squares and the symmetric cross-sector combination -/

/-- **DERIVED.**  Sector compatibility determines every pure spatial square, for
arbitrary (not merely unit) rest vectors, and determines exactly the symmetric
combination of a cross-sector product. -/
theorem task04_spatial_squares_and_symmetrization {M : BiProd4} (hM : SectorCompatible M) :
    (∀ v : Vec3, M (sp v) (sp v) = (dot3 v v) • e₀) ∧
    (∀ X : Vec4, X ∈ Rest → M X X = (h X X) • e₀) ∧
    (∀ v w : Vec3, M (sp v) (sp w) + M (sp w) (sp v) = (2 * dot3 v w) • e₀) :=
  ⟨M_rest_sq hM, fun _ hX => M_rest_sq' hM hX, M_rest_symm hM⟩

/-! ## 6. Exact classification of all sector-compatible products -/

/-- **PROVED NON-UNIQUE, WITH EXACT CLASSIFICATION.**  A bilinear product on the
ambient carrier is sector compatible **iff** it is the forced symmetric branch
`mu4sym` plus an alternating rest-space defect, and the defect is unique. -/
theorem task04_classification (M : BiProd4) :
    (SectorCompatible M ↔ ∃ A : Defect, IsAlt A ∧ M = muOf A) ∧
    (∀ A B : Defect, muOf A = muOf B → A = B) ∧
    (∀ A : Defect, IsAlt A → SectorCompatible (muOf A)) :=
  ⟨sectorCompatible_iff M, fun _ _ hAB => defect_unique hAB,
    fun _ hA => muOf_sectorCompatible hA⟩

/-- **DERIVED.**  The symmetric part of every sector-compatible product is the
same, and it has a coordinate-free description through `L4` and `e₀`; the whole
remaining freedom sits in the antisymmetric part, which is supported on
`Rest × Rest`. -/
theorem task04_symmetric_and_antisymmetric_parts {M : BiProd4} (hM : SectorCompatible M) :
    (∀ X Y : Vec4, SymM M X Y = mu4sym X Y) ∧
    (∀ X Y : Vec4, mu4sym X Y = (L4 X e₀) • Y + (L4 Y e₀) • X - (L4 X Y) • e₀) ∧
    (∀ X Y : Vec4, AltM M X Y = defectOf M X.2 Y.2) ∧
    (∀ X : Vec4, AltM M e₀ X = 0) ∧
    IsAlt (defectOf M) :=
  ⟨symM_eq hM, mu4sym_coordfree, altM_eq hM, altM_e₀ hM, defectOf_isAlt hM⟩

/-- **EXPLICIT NONUNIQUENESS WITNESS.**  Two extensionally different
sector-compatible products. -/
theorem task04_nonuniqueness :
    SectorCompatible mu4sym ∧ SectorCompatible (muFam 1) ∧ mu4sym ≠ muFam 1 :=
  sectorCompatible_not_unique

/-! ## 7. Commutativity -/

/-- **PROVED UNIQUE.**  Sector compatibility together with commutativity singles
out `mu4sym`, whose global unit is proved directly. -/
theorem task04_commutative_classification (M : BiProd4) :
    ((SectorCompatible M ∧ Commutative4 M) ↔ M = mu4sym) ∧
    SectorCompatible mu4sym ∧ Commutative4 mu4sym ∧ GlobalUnit mu4sym :=
  ⟨sectorCompatible_comm_unique M, mu4sym_sectorCompatible, mu4sym_comm, mu4sym_globalUnit⟩

/-! ## 8. Full isotropy -/

/-- **PROVED UNIQUE.**  Equivariance under the *full* stabilizer of `e₀` removes
the whole gluing freedom, with no commutativity assumption. -/
theorem task04_full_isotropy_classification (M : BiProd4) :
    (SectorCompatible M ∧ IsotropyEquivariant M) ↔ M = mu4sym :=
  sectorCompatible_isotropy_unique M

/-- **DERIVED.**  Stabilizers preserve the polarized form, the time component,
the rest space and its positive form. -/
theorem task04_stabilizer_properties {R : Vec4 ≃ₗ[ℝ] Vec4} (hR : Stabilizer R) :
    (∀ X Y : Vec4, L4 (R X) (R Y) = L4 X Y) ∧
    (∀ X : Vec4, (R X).1 = X.1) ∧
    (∀ X : Vec4, X ∈ Rest → R X ∈ Rest) ∧
    (∀ X Y : Vec4, h (R X) (R Y) = h X Y) ∧
    (∀ v w : Vec3, dot3 (restOf R v) (restOf R w) = dot3 v w) :=
  ⟨stab_L4 hR, stab_time hR, fun _ hX => stab_rest hR hX, stab_h hR, restOf_dot3 hR⟩

/-! ## 9. Proper isotropy -/

/-- **PROVED EXACT FAMILY (one continuous parameter).**  Requiring equivariance
only for the orientation-preserving stabilizers leaves exactly the
one-real-parameter family `muFam`, and the parameterization is injective. -/
theorem task04_proper_isotropy_classification (M : BiProd4) :
    ((SectorCompatible M ∧ ProperIsotropyEquivariant M) ↔ ∃ lam : ℝ, M = muFam lam) ∧
    Function.Injective muFam :=
  ⟨sectorCompatible_properIsotropy_classification M, properIsotropy_freedom_one_parameter⟩

/-- **DISCRETE CHOICE.**  Orientation reversal (an improper stabilizer, of
rest-space determinant `-1`) sends the parameter `lam` to `-lam`. -/
theorem task04_orientation_reversal :
    detRest (liftRest fz) = -1 ∧ Stabilizer (liftRest fz) ∧
    ¬ ProperStabilizer (liftRest fz) ∧
    (∀ (lam : ℝ) (X Y : Vec4),
      liftRest fz (muFam lam X Y) = muFam (-lam) (liftRest fz X) (liftRest fz Y)) :=
  ⟨detRest_fz, stabilizer_fz, not_properStabilizer_fz, muFam_orientation_reversal⟩

/-- **Scale question.**  Exactly which of the Task-04 inputs constrain the
surviving parameter. -/
theorem task04_parameter_selectors (lam : ℝ) :
    SectorCompatible (muFam lam) ∧
    ProperIsotropyEquivariant (muFam lam) ∧
    (Commutative4 (muFam lam) ↔ lam = 0) ∧
    (IsotropyEquivariant (muFam lam) ↔ lam = 0) ∧
    ¬ Associative4 (muFam lam) ∧
    ¬ Q4Multiplicative (muFam lam) :=
  lam_selector_audit lam

/-! ## 10. Identity audit -/

/-- **IDENTITY AUDIT for the forced symmetric branch.**  Flexible, power
associative in degrees 3 and 4, and Jordan: PROVED.  Associative, left
alternative, globally `Q4`-multiplicative: REFUTED BY EXPLICIT COUNTEREXAMPLE
(the counterexamples use two linearly independent spatial directions). -/
theorem task04_identity_audit :
    Flexible mu4sym ∧ PowerAssoc3 mu4sym ∧ PowerAssoc4 mu4sym ∧ JordanIdentity mu4sym ∧
    ¬ Associative4 mu4sym ∧ ¬ LeftAlternative mu4sym ∧ ¬ Q4Multiplicative mu4sym :=
  ⟨mu4sym_flexible, mu4sym_powerAssoc3, mu4sym_powerAssoc4, mu4sym_jordan,
    mu4sym_not_associative, mu4sym_not_leftAlternative, mu4sym_not_Q4Multiplicative⟩

/-- **Local versus global.**  Every longitudinal sector of a sector-compatible
product is associative, commutative and `Q`-multiplicative, while the glued
product is none of these; the explicit associativity counterexample uses the two
orthogonal spatial directions `E1`, `E2`. -/
theorem task04_local_versus_global {M : BiProd4} (hM : SectorCompatible M)
    {s : Vec4} (hs : UnitSpacelike s) :
    (∀ X Y Z : Long, M (M (iotaS s X) (iotaS s Y)) (iotaS s Z)
        = M (iotaS s X) (M (iotaS s Y) (iotaS s Z))) ∧
    (∀ X Y : Long, M (iotaS s X) (iotaS s Y) = M (iotaS s Y) (iotaS s X)) ∧
    (∀ X Y : Long, Q4 (M (iotaS s X) (iotaS s Y)) = Q4 (iotaS s X) * Q4 (iotaS s Y)) ∧
    mu4sym (mu4sym E1 E2) E2 ≠ mu4sym E1 (mu4sym E2 E2) := by
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro X Y Z
    rw [hM s hs X Y, hM s hs Y Z, hM s hs (muLong X Y) Z, hM s hs X (muLong Y Z),
      muLong_assoc]
  · intro X Y
    rw [hM s hs X Y, hM s hs Y X, muLong_comm]
  · exact sector_qMultiplicative hM hs
  · intro hcon
    rw [mu4sym_E1_E2, mu4sym_E2_E2, mu4sym_E1_e₀, LinearMap.map_zero₂] at hcon
    simp [E1, Prod.ext_iff] at hcon

/-- **PROVED IMPOSSIBLE, for every real parameter.**  No member of the
proper-isotropy family is associative or globally `Q4`-multiplicative; the exact
obstruction is the real equation `-lam² = 1`. -/
theorem task04_family_obstructions (lam : ℝ) :
    ¬ Associative4 (muFam lam) ∧ ¬ Q4Multiplicative (muFam lam) ∧
    (Associative4 (muFam lam) → -(lam ^ 2) = 1) ∧
    (Q4Multiplicative (muFam lam) → -(lam ^ 2) = 1) :=
  ⟨muFam_not_associative lam, muFam_not_Q4Multiplicative lam,
    (muFam_associativity_equation lam).1, (muFam_associativity_equation lam).2⟩

/-! ## 11. Overlaps versus cross-sector gluing -/

/-- **PROVED, AND DISTINGUISHED.**  Sector products agree on every overlap (and
in particular on the common timelike line), but overlap agreement does not
determine multiplication between different spatial sectors. -/
theorem task04_overlap :
    (∀ (s r : Vec4), UnitSpacelike s → UnitSpacelike r → ∀ X Y X' Y' : Long,
      iotaS s X = iotaS r Y → iotaS s X' = iotaS r Y' →
      sectorProd s X X' = sectorProd r Y Y') ∧
    (∀ (s : Vec4) (a b : ℝ), sectorProd s (a, 0) (b, 0) = (a * b) • e₀) ∧
    (∃ M N : BiProd4, SectorCompatible M ∧ SectorCompatible N ∧
      M (sp s₁) (sp s₂) ≠ N (sp s₁) (sp s₂)) :=
  ⟨fun _ _ hs hr _ _ _ _ h1 h2 => sector_overlap_agreement hs hr h1 h2, sector_overlap_timelike,
    overlap_does_not_determine_cross_sector⟩

/-! ## 12. Late identification — COMPARISON ONLY -/

/-- **COMPARISON ONLY.**  After the classification: the forced symmetric branch
is the conventional spin-factor (Jordan) product, and the basic alternating
gluing defect is the conventional three-dimensional vector product. -/
theorem task04_identification :
    (∀ X Y : Vec4, mu4sym X Y = spinFactorProduct X Y) ∧
    (∀ v w : Vec3, toFin3 (alt3 v w) = crossProduct (toFin3 v) (toFin3 w)) ∧
    (∀ X Y : Long, muLong X Y = NullSectorTask01.mulL X Y) :=
  ⟨mu4sym_eq_spinFactorProduct, alt3_eq_crossProduct, muLong_eq_mulL⟩

/-! ## Axiom report -/

#print axioms task04_polarization
#print axioms task04_rest_space
#print axioms task04_sector_embedding
#print axioms task04_sector_product
#print axioms task04_global_unit
#print axioms task04_spatial_squares_and_symmetrization
#print axioms task04_classification
#print axioms task04_symmetric_and_antisymmetric_parts
#print axioms task04_nonuniqueness
#print axioms task04_commutative_classification
#print axioms task04_full_isotropy_classification
#print axioms task04_stabilizer_properties
#print axioms task04_proper_isotropy_classification
#print axioms task04_orientation_reversal
#print axioms task04_parameter_selectors
#print axioms task04_identity_audit
#print axioms task04_local_versus_global
#print axioms task04_family_obstructions
#print axioms task04_overlap
#print axioms task04_identification

end NullSectorTask04
