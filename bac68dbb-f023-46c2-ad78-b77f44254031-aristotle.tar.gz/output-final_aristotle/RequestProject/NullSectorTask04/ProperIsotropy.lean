import RequestProject.NullSectorTask04.Isotropy

/-!
# Task 04, Layer 8: the proper stabilizer and the surviving gluing freedom

The orientation criterion is the ordinary determinant of the induced map of the
rest space, written out in the spatial coordinate basis (Leibniz formula); no
prepackaged group-theoretic identification is used.

The classification of proper-isotropy-equivariant defects is obtained from
explicit coordinate transformations (half-turns and quarter-turns), and the
converse direction is proved by elementary polynomial algebra.
-/

namespace NullSectorTask04

open NullSectorTask01

/-! ## The basic alternating spatial operation, in spatial coordinates -/

/-- The spatial component of the basic alternating defect.  (No conventional
name is attached to it at this stage.) -/
def alt3 (v w : Vec3) : Vec3 :=
  (v.2.1 * w.2.2 - v.2.2 * w.2.1, v.2.2 * w.1 - v.1 * w.2.2, v.1 * w.2.1 - v.2.1 * w.1)

@[simp] theorem alt3_apply (v w : Vec3) :
    alt3 v w = (v.2.1 * w.2.2 - v.2.2 * w.2.1, v.2.2 * w.1 - v.1 * w.2.2,
      v.1 * w.2.1 - v.2.1 * w.1) := rfl

theorem altBasis_eq_sp (v w : Vec3) : altBasis v w = sp (alt3 v w) := rfl

/-- The determinant of the triple `(c₁,c₂,c₃)` in the spatial coordinate basis. -/
def det3 (c1 c2 c3 : Vec3) : ℝ := dot3 (alt3 c1 c2) c3

/-- Expansion of a spatial vector along a triple. -/
def rho (c1 c2 c3 : Vec3) (v : Vec3) : Vec3 := v.1 • c1 + v.2.1 • c2 + v.2.2 • c3

@[simp] theorem rho_apply (c1 c2 c3 v : Vec3) :
    rho c1 c2 c3 v = v.1 • c1 + v.2.1 • c2 + v.2.2 • c3 := rfl

/-! ## Elementary algebraic identities (pure polynomial identities) -/

theorem alt3_self (v : Vec3) : alt3 v v = 0 := by
  apply vec3_ext <;> simp <;> ring

theorem dot3_alt3_left (v w : Vec3) : dot3 (alt3 v w) v = 0 := by
  simp [dot3]; ring

theorem dot3_alt3_right (v w : Vec3) : dot3 (alt3 v w) w = 0 := by
  simp [dot3]; ring

theorem det3_rot1 (c1 c2 c3 : Vec3) : dot3 (alt3 c2 c3) c1 = det3 c1 c2 c3 := by
  simp [det3]; ring

theorem det3_rot2 (c1 c2 c3 : Vec3) : dot3 (alt3 c3 c1) c2 = det3 c1 c2 c3 := by
  simp [det3, dot3]; ring

/-- **Reciprocal expansion.**  A pure polynomial identity. -/
theorem recip_expansion (c1 c2 c3 u : Vec3) :
    (det3 c1 c2 c3) • u =
      (dot3 u c1) • (alt3 c2 c3) + (dot3 u c2) • (alt3 c3 c1) + (dot3 u c3) • (alt3 c1 c2) := by
  apply vec3_ext <;> simp [det3, dot3] <;> ring

/-- **Cofactor identity.**  A pure polynomial identity: the image of `alt3` under
a linear map expressed in the triple `(c₁,c₂,c₃)`. -/
theorem alt3_of_rho (c1 c2 c3 v w : Vec3) :
    alt3 (rho c1 c2 c3 v) (rho c1 c2 c3 w)
      = rho (alt3 c2 c3) (alt3 c3 c1) (alt3 c1 c2) (alt3 v w) := by
  apply vec3_ext <;> simp <;> ring

/-! ## Orthonormal positively oriented triples -/

/-- The three defining relations of an orthonormal, positively oriented triple. -/
theorem alt3_triple {c1 c2 c3 : Vec3}
    (o11 : dot3 c1 c1 = 1) (o22 : dot3 c2 c2 = 1) (o33 : dot3 c3 c3 = 1)
    (o12 : dot3 c1 c2 = 0) (o13 : dot3 c1 c3 = 0) (o23 : dot3 c2 c3 = 0)
    (hdet : det3 c1 c2 c3 = 1) :
    alt3 c2 c3 = c1 ∧ alt3 c3 c1 = c2 ∧ alt3 c1 c2 = c3 := by
  have o21 : dot3 c2 c1 = 0 := by rw [dot3_symm]; exact o12
  have o31 : dot3 c3 c1 = 0 := by rw [dot3_symm]; exact o13
  have o32 : dot3 c3 c2 = 0 := by rw [dot3_symm]; exact o23
  refine ⟨?_, ?_, ?_⟩
  · have hq : (det3 c1 c2 c3) • (alt3 c2 c3 - c1) = 0 := by
      rw [recip_expansion]
      have d1 : dot3 (alt3 c2 c3 - c1) c1 = 0 := by
        rw [dot3_sub_left, det3_rot1, hdet, o11]; ring
      have d2 : dot3 (alt3 c2 c3 - c1) c2 = 0 := by
        rw [dot3_sub_left, dot3_alt3_left, o12]; ring
      have d3 : dot3 (alt3 c2 c3 - c1) c3 = 0 := by
        rw [dot3_sub_left, dot3_alt3_right, o13]; ring
      rw [d1, d2, d3]
      simp
    rw [hdet, one_smul] at hq
    exact sub_eq_zero.1 hq
  · have hq : (det3 c1 c2 c3) • (alt3 c3 c1 - c2) = 0 := by
      rw [recip_expansion]
      have d1 : dot3 (alt3 c3 c1 - c2) c1 = 0 := by
        rw [dot3_sub_left, dot3_alt3_right, o21]; ring
      have d2 : dot3 (alt3 c3 c1 - c2) c2 = 0 := by
        rw [dot3_sub_left, det3_rot2, hdet, o22]; ring
      have d3 : dot3 (alt3 c3 c1 - c2) c3 = 0 := by
        rw [dot3_sub_left, dot3_alt3_left, o23]; ring
      rw [d1, d2, d3]
      simp
    rw [hdet, one_smul] at hq
    exact sub_eq_zero.1 hq
  · have hq : (det3 c1 c2 c3) • (alt3 c1 c2 - c3) = 0 := by
      rw [recip_expansion]
      have d1 : dot3 (alt3 c1 c2 - c3) c1 = 0 := by
        rw [dot3_sub_left, dot3_alt3_left, o31]; ring
      have d2 : dot3 (alt3 c1 c2 - c3) c2 = 0 := by
        rw [dot3_sub_left, dot3_alt3_right, o32]; ring
      have d3 : dot3 (alt3 c1 c2 - c3) c3 = 0 := by
        rw [dot3_sub_left, ← det3, hdet, o33]; ring
      rw [d1, d2, d3]
      simp
    rw [hdet, one_smul] at hq
    exact sub_eq_zero.1 hq

/-! ## The proper stabilizer -/

/-- Orientation criterion: the determinant of the induced map of the rest space,
in the spatial coordinate basis. -/
def detRest (R : Vec4 ≃ₗ[ℝ] Vec4) : ℝ := det3 (restOf R s₁) (restOf R s₂) (restOf R s₃)

/-- Orientation-preserving stabilizers. -/
def ProperStabilizer (R : Vec4 ≃ₗ[ℝ] Vec4) : Prop := Stabilizer R ∧ detRest R = 1

theorem ProperStabilizer.toStabilizer {R : Vec4 ≃ₗ[ℝ] Vec4} (hR : ProperStabilizer R) :
    Stabilizer R := hR.1

/-- Equivariance under the proper stabilizer only. -/
def ProperIsotropyEquivariant (M : BiProd4) : Prop :=
  ∀ R : Vec4 ≃ₗ[ℝ] Vec4, ProperStabilizer R → ∀ X Y, R (M X Y) = M (R X) (R Y)

theorem IsotropyEquivariant.toProper {M : BiProd4} (hM : IsotropyEquivariant M) :
    ProperIsotropyEquivariant M := fun R hR => hM R hR.1

/-- A stabilizer acts on spatial coordinates through the triple of images of the
coordinate directions. -/
theorem restOf_eq_rho {R : Vec4 ≃ₗ[ℝ] Vec4} (hR : Stabilizer R) (v : Vec3) :
    restOf R v = rho (restOf R s₁) (restOf R s₂) (restOf R s₃) v := by
  obtain ⟨v1, v2, v3⟩ := v
  have hv : ((v1, v2, v3) : Vec3) = v1 • s₁ + v2 • s₂ + v3 • s₃ := by
    apply vec3_ext <;> simp [s₁, s₂, s₃]
  rw [hv, restOf_add hR, restOf_add hR, restOf_smul hR, restOf_smul hR, restOf_smul hR]
  apply vec3_ext <;> simp [s₁, s₂, s₃]

/-- The columns of a stabilizer are orthonormal. -/
theorem stab_columns {R : Vec4 ≃ₗ[ℝ] Vec4} (hR : Stabilizer R) :
    dot3 (restOf R s₁) (restOf R s₁) = 1 ∧ dot3 (restOf R s₂) (restOf R s₂) = 1 ∧
      dot3 (restOf R s₃) (restOf R s₃) = 1 ∧ dot3 (restOf R s₁) (restOf R s₂) = 0 ∧
      dot3 (restOf R s₁) (restOf R s₃) = 0 ∧ dot3 (restOf R s₂) (restOf R s₃) = 0 := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩ <;> rw [restOf_dot3 hR] <;> simp [s₁, s₂, s₃]

/-- **Transport of the basic alternating operation** under a proper stabilizer. -/
theorem alt3_proper {R : Vec4 ≃ₗ[ℝ] Vec4} (hR : ProperStabilizer R) (v w : Vec3) :
    restOf R (alt3 v w) = alt3 (restOf R v) (restOf R w) := by
  obtain ⟨o11, o22, o33, o12, o13, o23⟩ := stab_columns hR.1
  obtain ⟨K1, K2, K3⟩ := alt3_triple o11 o22 o33 o12 o13 o23 hR.2
  rw [restOf_eq_rho hR.1 v, restOf_eq_rho hR.1 w, restOf_eq_rho hR.1 (alt3 v w),
    alt3_of_rho, K1, K2, K3]

/-! ## The family of products with a scaled basic defect is proper-equivariant -/

theorem muFam_properEquivariant (lam : ℝ) : ProperIsotropyEquivariant (muFam lam) := by
  intro R hR X Y
  have hst := hR.1
  rw [muFam_apply, muFam_apply, map_add, mu4sym_isotropyEquivariant R hst X Y]
  congr 1
  rw [map_smul, altBasis_eq_sp, altBasis_eq_sp, stab_snd hst X, stab_snd hst Y,
    stab_sp hst, alt3_proper hR]

/-! ## Explicit proper stabilizer elements

Half-turns and quarter-turns of the spatial coordinates.  Each is built by hand
from an explicit coordinate formula; its membership in the stabilizer and the
value of its orientation determinant are computed directly.
-/

/-- Half-turn about the first spatial axis. -/
def rxHalf : Vec3 ≃ₗ[ℝ] Vec3 :=
  mkEquiv3 (fun v => (v.1, -v.2.1, -v.2.2)) (fun v => (v.1, -v.2.1, -v.2.2))
    (by intro v w; apply vec3_ext <;> simp <;> ring)
    (by intro c v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)

/-- Half-turn about the second spatial axis. -/
def ryHalf : Vec3 ≃ₗ[ℝ] Vec3 :=
  mkEquiv3 (fun v => (-v.1, v.2.1, -v.2.2)) (fun v => (-v.1, v.2.1, -v.2.2))
    (by intro v w; apply vec3_ext <;> simp <;> ring)
    (by intro c v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)

/-- Half-turn about the third spatial axis. -/
def rzHalf : Vec3 ≃ₗ[ℝ] Vec3 :=
  mkEquiv3 (fun v => (-v.1, -v.2.1, v.2.2)) (fun v => (-v.1, -v.2.1, v.2.2))
    (by intro v w; apply vec3_ext <;> simp <;> ring)
    (by intro c v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)

/-- Quarter-turn about the third spatial axis. -/
def rzQuarter : Vec3 ≃ₗ[ℝ] Vec3 :=
  mkEquiv3 (fun v => (-v.2.1, v.1, v.2.2)) (fun v => (v.2.1, -v.1, v.2.2))
    (by intro v w; apply vec3_ext <;> simp; ring)
    (by intro c v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)

/-- Quarter-turn about the first spatial axis. -/
def rxQuarter : Vec3 ≃ₗ[ℝ] Vec3 :=
  mkEquiv3 (fun v => (v.1, -v.2.2, v.2.1)) (fun v => (v.1, v.2.2, -v.2.1))
    (by intro v w; apply vec3_ext <;> simp; ring)
    (by intro c v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)

@[simp] theorem rxHalf_apply (v : Vec3) : rxHalf v = (v.1, -v.2.1, -v.2.2) := rfl
@[simp] theorem ryHalf_apply (v : Vec3) : ryHalf v = (-v.1, v.2.1, -v.2.2) := rfl
@[simp] theorem rzHalf_apply (v : Vec3) : rzHalf v = (-v.1, -v.2.1, v.2.2) := rfl
@[simp] theorem rzQuarter_apply (v : Vec3) : rzQuarter v = (-v.2.1, v.1, v.2.2) := rfl
@[simp] theorem rxQuarter_apply (v : Vec3) : rxQuarter v = (v.1, -v.2.2, v.2.1) := rfl

theorem properStab_rxHalf : ProperStabilizer (liftRest rxHalf) := by
  refine ⟨liftRest_stabilizer (by intro v; simp only [rxHalf_apply, dot3_apply]; ring), ?_⟩
  simp only [detRest, restOf_liftRest, det3, dot3_apply, alt3_apply, rxHalf_apply]
  norm_num [s₁, s₂, s₃]

theorem properStab_ryHalf : ProperStabilizer (liftRest ryHalf) := by
  refine ⟨liftRest_stabilizer (by intro v; simp only [ryHalf_apply, dot3_apply]; ring), ?_⟩
  simp only [detRest, restOf_liftRest, det3, dot3_apply, alt3_apply, ryHalf_apply]
  norm_num [s₁, s₂, s₃]

theorem properStab_rzHalf : ProperStabilizer (liftRest rzHalf) := by
  refine ⟨liftRest_stabilizer (by intro v; simp only [rzHalf_apply, dot3_apply]; ring), ?_⟩
  simp only [detRest, restOf_liftRest, det3, dot3_apply, alt3_apply, rzHalf_apply]
  norm_num [s₁, s₂, s₃]

theorem properStab_rzQuarter : ProperStabilizer (liftRest rzQuarter) := by
  refine ⟨liftRest_stabilizer (by intro v; simp only [rzQuarter_apply, dot3_apply]; ring), ?_⟩
  simp only [detRest, restOf_liftRest, det3, dot3_apply, alt3_apply, rzQuarter_apply]
  norm_num [s₁, s₂, s₃]

theorem properStab_rxQuarter : ProperStabilizer (liftRest rxQuarter) := by
  refine ⟨liftRest_stabilizer (by intro v; simp only [rxQuarter_apply, dot3_apply]; ring), ?_⟩
  simp only [detRest, restOf_liftRest, det3, dot3_apply, alt3_apply, rxQuarter_apply]
  norm_num [s₁, s₂, s₃]

/-- Orientation reversal: the third-coordinate reflection has determinant `-1`. -/
theorem detRest_fz : detRest (liftRest fz) = -1 := by
  simp only [detRest, restOf_liftRest, det3, dot3_apply, alt3_apply, fz_apply]
  norm_num [s₁, s₂, s₃]

theorem not_properStabilizer_fz : ¬ ProperStabilizer (liftRest fz) := by
  intro hcon
  have := hcon.2
  rw [detRest_fz] at this
  norm_num at this

/-! ## Action of the explicit rotations on the coordinate directions -/

theorem rxHalf_s₁ : rxHalf s₁ = s₁ := by apply vec3_ext <;> simp [s₁]
theorem rxHalf_s₂ : rxHalf s₂ = -s₂ := by apply vec3_ext <;> simp [s₂]
theorem rxHalf_s₃ : rxHalf s₃ = -s₃ := by apply vec3_ext <;> simp [s₃]
theorem ryHalf_s₁ : ryHalf s₁ = -s₁ := by apply vec3_ext <;> simp [s₁]
theorem ryHalf_s₂ : ryHalf s₂ = s₂ := by apply vec3_ext <;> simp [s₂]
theorem ryHalf_s₃ : ryHalf s₃ = -s₃ := by apply vec3_ext <;> simp [s₃]
theorem rzHalf_s₁ : rzHalf s₁ = -s₁ := by apply vec3_ext <;> simp [s₁]
theorem rzHalf_s₂ : rzHalf s₂ = -s₂ := by apply vec3_ext <;> simp [s₂]
theorem rzHalf_s₃ : rzHalf s₃ = s₃ := by apply vec3_ext <;> simp [s₃]
theorem rzQuarter_s₂ : rzQuarter s₂ = -s₁ := by apply vec3_ext <;> simp [s₁, s₂]
theorem rzQuarter_s₃ : rzQuarter s₃ = s₃ := by apply vec3_ext <;> simp [s₃]
theorem rxQuarter_s₁ : rxQuarter s₁ = s₁ := by apply vec3_ext <;> simp [s₁]
theorem rxQuarter_s₃ : rxQuarter s₃ = -s₂ := by apply vec3_ext <;> simp [s₂, s₃]

/-! ## Values of the basic alternating defect on the coordinate pairs -/

@[simp] theorem altBasis_s₂_s₃ : altBasis s₂ s₃ = E1 := by
  apply vec4_ext <;> simp [s₂, s₃, E1]

@[simp] theorem altBasis_s₃_s₁ : altBasis s₃ s₁ = E2 := by
  apply vec4_ext <;> simp [s₃, s₁, E2]

/-! ## Equivariance under the proper stabilizer, as a condition on the defect -/

section
variable {M : BiProd4} (hE : ProperIsotropyEquivariant M)
include hE

/-- **Translation of proper equivariance into a condition on the defect.** -/
theorem defect_properEquivariant (hR : ProperStabilizer R) (v w : Vec3) :
    R (defectOf M v w) = defectOf M (restOf R v) (restOf R w) := by
  rw [defectOf_apply, defectOf_apply, map_sub, map_smul, hR.1.1]
  rw [← stab_sp hR.1, ← stab_sp hR.1, hE R hR, restOf_dot3 hR.1]

end

/-! ## Classification of proper-isotropy-equivariant defects -/

section
variable {M : BiProd4} (hM : SectorCompatible M) (hE : ProperIsotropyEquivariant M)
include hM hE

/-- **PROVED EXACT FAMILY.**  Under equivariance for the orientation-preserving
stabilizers only, the alternating gluing defect is a real multiple of the basic
alternating defect. -/
theorem defect_proper_classification :
    defectOf M = ((defectOf M s₂ s₃).2.1) • altBasis := by
  have hA : IsAlt (defectOf M) := defectOf_isAlt hM
  have key : ∀ {R : Vec4 ≃ₗ[ℝ] Vec4}, ProperStabilizer R → ∀ v w : Vec3,
      R (defectOf M v w) = defectOf M (restOf R v) (restOf R w) :=
    fun hR v w => defect_properEquivariant hE hR v w
  -- Step 1: the value on `(s₂, s₃)` is a multiple of `E1`.
  have hW : defectOf M s₂ s₃ = ((defectOf M s₂ s₃).2.1) • E1 := by
    have ez : liftRest rzHalf (defectOf M s₂ s₃) = - defectOf M s₂ s₃ := by
      rw [key properStab_rzHalf s₂ s₃]
      simp only [restOf_liftRest, rzHalf_s₂, rzHalf_s₃, map_neg, LinearMap.neg_apply]
    have ex : liftRest rxHalf (defectOf M s₂ s₃) = defectOf M s₂ s₃ := by
      rw [key properStab_rxHalf s₂ s₃]
      simp only [restOf_liftRest, rxHalf_s₂, rxHalf_s₃, map_neg, LinearMap.neg_apply, neg_neg]
    have c0 : (defectOf M s₂ s₃).1 = -(defectOf M s₂ s₃).1 :=
      congrArg (fun Z : Vec4 => Z.1) ez
    have c3 : (defectOf M s₂ s₃).2.2.2 = -(defectOf M s₂ s₃).2.2.2 :=
      congrArg (fun Z : Vec4 => Z.2.2.2) ez
    have c2 : -(defectOf M s₂ s₃).2.2.1 = (defectOf M s₂ s₃).2.2.1 :=
      congrArg (fun Z : Vec4 => Z.2.2.1) ex
    apply vec4_ext <;> simp only [E1, Prod.smul_fst, Prod.smul_snd, smul_eq_mul,
      mul_zero, mul_one] <;> linarith
  -- Step 2: the value on `(s₃, s₁)` is the same multiple of `E2`.
  have hU : defectOf M s₃ s₁ = ((defectOf M s₂ s₃).2.1) • E2 := by
    have hq := key properStab_rzQuarter s₂ s₃
    simp only [restOf_liftRest, rzQuarter_s₂, rzQuarter_s₃, map_neg,
      LinearMap.neg_apply] at hq
    rw [hW, map_smul] at hq
    have hE12 : liftRest rzQuarter E1 = E2 := by apply vec4_ext <;> simp [E1, E2]
    rw [hE12, isAlt_antisymm hA s₁ s₃, neg_neg] at hq
    exact hq.symm
  -- Step 3: the value on `(s₁, s₂)` is the same multiple of `E3`.
  have hV : defectOf M s₁ s₂ = ((defectOf M s₂ s₃).2.1) • E3 := by
    have hq := key properStab_rxQuarter s₃ s₁
    simp only [restOf_liftRest, rxQuarter_s₃, rxQuarter_s₁, map_neg,
      LinearMap.neg_apply] at hq
    rw [hU, map_smul] at hq
    have hE23 : liftRest rxQuarter E2 = E3 := by apply vec4_ext <;> simp [E2, E3]
    rw [hE23, isAlt_antisymm hA s₂ s₁, neg_neg] at hq
    exact hq.symm
  -- Assemble.
  have hdiff : defectOf M - ((defectOf M s₂ s₃).2.1) • altBasis = 0 := by
    refine defect_eq_zero_of_basis ?_ ?_ ?_ ?_
    · intro v
      simp only [LinearMap.sub_apply, LinearMap.smul_apply, hA v, altBasis_isAlt v,
        smul_zero, sub_zero]
    · simp only [LinearMap.sub_apply, LinearMap.smul_apply, altBasis_s₁_s₂]
      exact sub_eq_zero.2 hV
    · simp only [LinearMap.sub_apply, LinearMap.smul_apply, altBasis_s₂_s₃]
      exact sub_eq_zero.2 hW
    · simp only [LinearMap.sub_apply, LinearMap.smul_apply, altBasis_s₃_s₁]
      exact sub_eq_zero.2 hU
  exact sub_eq_zero.1 hdiff

end

/-! ## The exact proper-isotropy classification -/

theorem muFam_injective {lam mu : ℝ} (h : muFam lam = muFam mu) : lam = mu := by
  have := congrArg (fun N : BiProd4 => N E1 E2) h
  simp only [muFam_E1_E2] at this
  have h3 := congrArg (fun Z : Vec4 => Z.2.2.2) this
  simpa [E3] using h3

/-- **PROVED EXACT FAMILY.**  Sector compatibility together with equivariance
under the orientation-preserving stabilizers of `e₀` is satisfied by exactly a
one-real-parameter family of products. -/
theorem sectorCompatible_properIsotropy_classification (M : BiProd4) :
    (SectorCompatible M ∧ ProperIsotropyEquivariant M) ↔ ∃ lam : ℝ, M = muFam lam := by
  constructor
  · rintro ⟨hM, hE⟩
    obtain ⟨lam, hd⟩ : ∃ lam : ℝ, defectOf M = lam • altBasis :=
      ⟨_, defect_proper_classification hM hE⟩
    refine ⟨lam, ?_⟩
    conv_lhs => rw [eq_muOf_defect hM, hd]
    rfl
  · rintro ⟨lam, rfl⟩
    exact ⟨muFam_sectorCompatible lam, muFam_properEquivariant lam⟩

/-- The surviving freedom is exactly one real parameter: the parameterization is
injective. -/
theorem properIsotropy_freedom_one_parameter :
    Function.Injective muFam := fun _ _ h => muFam_injective h

/-! ## Orientation reversal acts by a sign on the parameter -/

/-- **Orientation reversal sends `lam` to `-lam`.** -/
theorem muFam_orientation_reversal (lam : ℝ) (X Y : Vec4) :
    liftRest fz (muFam lam X Y) = muFam (-lam) (liftRest fz X) (liftRest fz Y) := by
  have hst : Stabilizer (liftRest fz) := stabilizer_fz
  have halt : ∀ v w : Vec3, fz (alt3 v w) = - alt3 (fz v) (fz w) := by
    intro v w; apply vec3_ext <;> simp <;> ring
  rw [muFam_apply, muFam_apply, map_add, mu4sym_isotropyEquivariant _ hst X Y]
  congr 1
  rw [map_smul, altBasis_eq_sp, altBasis_eq_sp]
  have h1 : liftRest fz (sp (alt3 X.2 Y.2)) = sp (fz (alt3 X.2 Y.2)) := rfl
  rw [h1, halt]
  have h2 : (liftRest fz X).2 = fz X.2 := rfl
  have h3 : (liftRest fz Y).2 = fz Y.2 := rfl
  rw [h2, h3]
  apply vec4_ext <;> simp [sp] <;> ring

/-- Sector compatibility and proper isotropy impose **no** equation on the
parameter, whereas commutativity and full isotropy force it to vanish, and
associativity and global `Q4`-multiplicativity are impossible for every value. -/
theorem lam_selector_audit (lam : ℝ) :
    SectorCompatible (muFam lam) ∧
    ProperIsotropyEquivariant (muFam lam) ∧
    (Commutative4 (muFam lam) ↔ lam = 0) ∧
    (IsotropyEquivariant (muFam lam) ↔ lam = 0) ∧
    ¬ Associative4 (muFam lam) ∧
    ¬ Q4Multiplicative (muFam lam) := by
  refine ⟨muFam_sectorCompatible lam, muFam_properEquivariant lam, ?_, ?_,
    muFam_not_associative lam, muFam_not_Q4Multiplicative lam⟩
  · constructor
    · intro hc
      have h0 : (lam • altBasis : Defect) = 0 :=
        (commutative_iff_defect_zero (altBasis_smul_isAlt lam)).1 hc
      have := congrArg (fun A : Defect => A s₁ s₂) h0
      simp only [LinearMap.smul_apply, altBasis_s₁_s₂, LinearMap.zero_apply] at this
      have h3 := congrArg (fun Z : Vec4 => Z.2.2.2) this
      simpa [E3] using h3
    · rintro rfl
      rw [muFam_zero]
      exact mu4sym_comm
  · constructor
    · intro hI
      have : muFam lam = mu4sym :=
        (sectorCompatible_isotropy_unique _).1 ⟨muFam_sectorCompatible lam, hI⟩
      rw [← muFam_zero] at this
      exact muFam_injective this
    · rintro rfl
      rw [muFam_zero]
      exact mu4sym_isotropyEquivariant

end NullSectorTask04
