import RequestProject.NullSectorTask04.GlobalExtension

/-!
# Task 04, Layer 5: exact classification of all sector-compatible products

The symmetric part of a sector-compatible product is completely forced; the
only remaining freedom is an alternating bilinear map on the rest space with
values in the ambient carrier.  Both directions are proved.

The distinguished symmetric branch `mu4sym` is *produced by the classification*,
not posited in advance: `mu4sym` is the product obtained from the zero defect,
and the classification theorem shows that it is exactly the forced part.
-/

namespace NullSectorTask04

open NullSectorTask01

/-! ## The zero-defect branch -/

/-- The product obtained from the forced symmetric data alone (zero defect). -/
noncomputable def mu4sym : BiProd4 :=
  LinearMap.mk₂ ℝ
    (fun X Y => (X.1 * Y.1 + dot3 X.2 Y.2,
      X.1 * Y.2.1 + Y.1 * X.2.1, X.1 * Y.2.2.1 + Y.1 * X.2.2.1,
      X.1 * Y.2.2.2 + Y.1 * X.2.2.2))
    (by intro X₁ X₂ Y; apply vec4_ext <;> simp [dot3] <;> ring)
    (by intro c X Y; apply vec4_ext <;> simp [dot3] <;> ring)
    (by intro X Y₁ Y₂; apply vec4_ext <;> simp [dot3] <;> ring)
    (by intro c X Y; apply vec4_ext <;> simp [dot3] <;> ring)

@[simp] theorem mu4sym_apply (X Y : Vec4) :
    mu4sym X Y = (X.1 * Y.1 + dot3 X.2 Y.2,
      X.1 * Y.2.1 + Y.1 * X.2.1, X.1 * Y.2.2.1 + Y.1 * X.2.2.1,
      X.1 * Y.2.2.2 + Y.1 * X.2.2.2) := rfl

/-- Coordinate-free description of the zero-defect branch. -/
theorem mu4sym_eq (X Y : Vec4) :
    mu4sym X Y = (X.1 * Y.1 + dot3 X.2 Y.2) • e₀ + X.1 • sp Y.2 + Y.1 • sp X.2 := by
  apply vec4_ext <;> simp [e₀, sp]

/-- **Coordinate-free description of the forced symmetric branch.**  It is
expressed purely through `L4` and the chosen unit `e₀`. -/
theorem mu4sym_coordfree (X Y : Vec4) :
    mu4sym X Y = (L4 X e₀) • Y + (L4 Y e₀) • X - (L4 X Y) • e₀ := by
  apply vec4_ext <;> simp [e₀, dot3]; ring

theorem mu4sym_comm : Commutative4 mu4sym := by
  intro X Y; apply vec4_ext <;> simp [dot3] <;> ring

theorem mu4sym_rest (v w : Vec3) : mu4sym (sp v) (sp w) = (dot3 v w) • e₀ := by
  apply vec4_ext <;> simp [e₀, sp, dot3]

/-! ## Alternating rest-space defects -/

/-- A defect datum: a bilinear map on rest-space coordinates with values in the
ambient carrier. -/
abbrev Defect : Type := Vec3 →ₗ[ℝ] Vec3 →ₗ[ℝ] Vec4

/-- The alternating condition on a defect. -/
def IsAlt (A : Defect) : Prop := ∀ v, A v v = 0

theorem isAlt_antisymm {A : Defect} (hA : IsAlt A) (v w : Vec3) : A v w = - A w v := by
  have hvw := hA (v + w)
  simp only [map_add, LinearMap.add_apply] at hvw
  rw [hA v, hA w] at hvw
  have h0 : A v w + A w v = 0 := by rw [← hvw]; abel
  exact eq_neg_of_add_eq_zero_left h0

/-- The product attached to a defect datum. -/
noncomputable def muOf (A : Defect) : BiProd4 :=
  LinearMap.mk₂ ℝ (fun X Y => mu4sym X Y + A X.2 Y.2)
    (by intro X₁ X₂ Y; simp only [Prod.snd_add, map_add, LinearMap.add_apply]; abel)
    (by intro c X Y; simp only [Prod.smul_snd, map_smul, LinearMap.smul_apply, smul_add])
    (by intro X Y₁ Y₂; simp only [Prod.snd_add, map_add]; abel)
    (by intro c X Y; simp only [Prod.smul_snd, map_smul, smul_add])

@[simp] theorem muOf_apply (A : Defect) (X Y : Vec4) :
    muOf A X Y = mu4sym X Y + A X.2 Y.2 := rfl

/-! ## The forward direction: extraction of the defect -/

/-- The defect of a bilinear product: the rest-space block minus the forced
symmetric contribution. -/
noncomputable def defectOf (M : BiProd4) : Defect :=
  LinearMap.mk₂ ℝ (fun v w => M (sp v) (sp w) - (dot3 v w) • e₀)
    (by
      intro v₁ v₂ w
      dsimp only
      rw [sp_add, M_add_left, dot3_add_left, add_smul]; abel)
    (by
      intro c v w
      dsimp only
      rw [sp_smul, M_smul_left, dot3_smul_left, mul_smul, smul_sub])
    (by
      intro v w₁ w₂
      dsimp only
      rw [sp_add, M_add_right, dot3_add_right, add_smul]; abel)
    (by
      intro c v w
      dsimp only
      rw [sp_smul, M_smul_right, dot3_smul_right, mul_smul, smul_sub])

@[simp] theorem defectOf_apply (M : BiProd4) (v w : Vec3) :
    defectOf M v w = M (sp v) (sp w) - (dot3 v w) • e₀ := rfl

section
variable {M : BiProd4} (hM : SectorCompatible M)
include hM

/-- The defect of a sector-compatible product is alternating. -/
theorem defectOf_isAlt : IsAlt (defectOf M) := by
  intro v
  rw [defectOf_apply, M_rest_sq hM v, sub_self]

/-- A sector-compatible product is its forced symmetric part plus its defect. -/
theorem eq_muOf_defect : M = muOf (defectOf M) := by
  apply LinearMap.ext; intro X; apply LinearMap.ext; intro Y
  rw [muOf_apply, defectOf_apply, mu4sym_eq, M_expand hM X Y]
  module

end

/-! ## The converse direction -/

/-- **Converse.**  Every alternating defect reconstructs a sector-compatible
product. -/
theorem muOf_sectorCompatible {A : Defect} (hA : IsAlt A) : SectorCompatible (muOf A) := by
  intro s hs X Y
  obtain ⟨hsp, hd⟩ := unitSpacelike_spatial hs
  have hs1 : s.1 = 0 := by
    have := (unitSpacelike_iff s).1 hs
    exact (mem_Rest s).1 this.1
  have hiota : ∀ Z : Long, iotaS s Z = (Z.1, Z.2 • s.2) := by
    intro Z
    apply vec4_ext <;> simp [iotaS, e₀, hs1]
  have hA' : A (X.2 • s.2) (Y.2 • s.2) = 0 := by
    simp [hA s.2]
  rw [muOf_apply, hiota X, hiota Y, hiota (muLong X Y)]
  rw [show ((X.1, X.2 • s.2) : Vec4).2 = X.2 • s.2 from rfl,
    show ((Y.1, Y.2 • s.2) : Vec4).2 = Y.2 • s.2 from rfl, hA', add_zero]
  apply vec4_ext
  · simp only [mu4sym_apply, muLong_apply]
    rw [dot3_smul_left, dot3_smul_right, hd]
    ring
  · simp [dot3]; ring
  · simp [dot3]; ring
  · simp [dot3]; ring

/-! ## The classification -/

/-- **Exact classification of all sector-compatible products.**  A bilinear
product is sector compatible if and only if it is the forced symmetric branch
plus an alternating rest-space defect. -/
theorem sectorCompatible_iff (M : BiProd4) :
    SectorCompatible M ↔ ∃ A : Defect, IsAlt A ∧ M = muOf A := by
  constructor
  · intro hM
    exact ⟨defectOf M, defectOf_isAlt hM, eq_muOf_defect hM⟩
  · rintro ⟨A, hA, rfl⟩
    exact muOf_sectorCompatible hA

/-- The defect datum is uniquely determined by the product. -/
theorem defect_unique {A B : Defect} (h : muOf A = muOf B) : A = B := by
  apply LinearMap.ext; intro v; apply LinearMap.ext; intro w
  have := congrArg (fun (N : BiProd4) => N (sp v) (sp w)) h
  simp only [muOf_apply, sp_snd] at this
  exact add_left_cancel this

/-- The zero defect reproduces the symmetric branch. -/
theorem muOf_zero : muOf 0 = mu4sym := by
  apply LinearMap.ext; intro X; apply LinearMap.ext; intro Y
  simp

theorem isAlt_zero : IsAlt (0 : Defect) := by intro v; simp

/-- The zero-defect branch is sector compatible. -/
theorem mu4sym_sectorCompatible : SectorCompatible mu4sym := by
  rw [← muOf_zero]
  exact muOf_sectorCompatible isAlt_zero

/-! ## Symmetric and antisymmetric parts -/

/-- Symmetric part of a bilinear product. -/
noncomputable def SymM (M : BiProd4) (X Y : Vec4) : Vec4 := (1/2 : ℝ) • (M X Y + M Y X)

/-- Antisymmetric part of a bilinear product. -/
noncomputable def AltM (M : BiProd4) (X Y : Vec4) : Vec4 := (1/2 : ℝ) • (M X Y - M Y X)

theorem sym_add_alt (M : BiProd4) (X Y : Vec4) : SymM M X Y + AltM M X Y = M X Y := by
  simp only [SymM, AltM, ← smul_add]
  rw [show M X Y + M Y X + (M X Y - M Y X) = (2 : ℝ) • M X Y by
    rw [two_smul]; abel]
  rw [smul_smul, show (1/2 : ℝ) * 2 = 1 by norm_num, one_smul]

section
variable {M : BiProd4} (hM : SectorCompatible M)
include hM

/-- **The symmetric part is completely fixed by sector compatibility.** -/
theorem symM_eq (X Y : Vec4) : SymM M X Y = mu4sym X Y := by
  have hMX := eq_muOf_defect hM
  rw [SymM, hMX]
  simp only [muOf_apply]
  rw [mu4sym_comm Y X, isAlt_antisymm (defectOf_isAlt hM) Y.2 X.2]
  rw [show mu4sym X Y + defectOf M X.2 Y.2 + (mu4sym X Y + -defectOf M X.2 Y.2)
      = (2 : ℝ) • mu4sym X Y by rw [two_smul]; abel]
  rw [smul_smul, show (1/2 : ℝ) * 2 = 1 by norm_num, one_smul]

/-- **The remaining freedom is exactly the alternating part, and it is supported
on the rest space.** -/
theorem altM_eq (X Y : Vec4) : AltM M X Y = defectOf M X.2 Y.2 := by
  have hMX := eq_muOf_defect hM
  have hxy : M X Y = mu4sym X Y + defectOf M X.2 Y.2 :=
    congrArg (fun N : BiProd4 => N X Y) hMX
  have hyx : M Y X = mu4sym Y X + defectOf M Y.2 X.2 :=
    congrArg (fun N : BiProd4 => N Y X) hMX
  rw [AltM, hxy, hyx]
  rw [mu4sym_comm Y X, isAlt_antisymm (defectOf_isAlt hM) Y.2 X.2]
  rw [show mu4sym X Y + defectOf M X.2 Y.2 - (mu4sym X Y + -defectOf M X.2 Y.2)
      = (2 : ℝ) • defectOf M X.2 Y.2 by rw [two_smul]; abel]
  rw [smul_smul, show (1/2 : ℝ) * 2 = 1 by norm_num, one_smul]

/-- The alternating part only sees the rest components: it vanishes whenever one
argument is `e₀`. -/
theorem altM_e₀ (X : Vec4) : AltM M e₀ X = 0 := by
  rw [altM_eq hM, e₀_snd]
  exact LinearMap.map_zero₂ _ _

end

/-! ## Explicit nonuniqueness witness -/

/-- The basic alternating rest-space defect, written in coordinates.  (No
conventional name is attached to it at this stage.) -/
noncomputable def altBasis : Defect :=
  LinearMap.mk₂ ℝ
    (fun v w => (0, v.2.1 * w.2.2 - v.2.2 * w.2.1, v.2.2 * w.1 - v.1 * w.2.2,
      v.1 * w.2.1 - v.2.1 * w.1))
    (by intro v₁ v₂ w; apply vec4_ext <;> simp <;> ring)
    (by intro c v w; apply vec4_ext <;> simp <;> ring)
    (by intro v w₁ w₂; apply vec4_ext <;> simp <;> ring)
    (by intro c v w; apply vec4_ext <;> simp <;> ring)

@[simp] theorem altBasis_apply (v w : Vec3) :
    altBasis v w = (0, v.2.1 * w.2.2 - v.2.2 * w.2.1, v.2.2 * w.1 - v.1 * w.2.2,
      v.1 * w.2.1 - v.2.1 * w.1) := rfl

theorem altBasis_isAlt : IsAlt altBasis := by
  intro v; apply vec4_ext <;> simp <;> ring

theorem altBasis_smul_isAlt (lam : ℝ) : IsAlt (lam • altBasis) := by
  intro v; simp [altBasis_isAlt v]

/-- The one-parameter family of products with a scaled basic defect. -/
noncomputable def muFam (lam : ℝ) : BiProd4 := muOf (lam • altBasis)

theorem muFam_sectorCompatible (lam : ℝ) : SectorCompatible (muFam lam) :=
  muOf_sectorCompatible (altBasis_smul_isAlt lam)

@[simp] theorem muFam_apply (lam : ℝ) (X Y : Vec4) :
    muFam lam X Y = mu4sym X Y + lam • altBasis X.2 Y.2 := rfl

theorem muFam_zero : muFam 0 = mu4sym := by
  apply LinearMap.ext; intro X; apply LinearMap.ext; intro Y
  simp

/-- **PROVED NON-UNIQUE.**  Sector compatibility alone does not determine the
global product: the zero-defect branch and the branch with defect `altBasis`
are both sector compatible and are extensionally different. -/
theorem sectorCompatible_not_unique :
    SectorCompatible mu4sym ∧ SectorCompatible (muFam 1) ∧ mu4sym ≠ muFam 1 := by
  refine ⟨mu4sym_sectorCompatible, muFam_sectorCompatible 1, ?_⟩
  intro hcon
  have := congrArg (fun (N : BiProd4) => N (sp s₁) (sp s₂)) hcon
  simp [s₁, s₂, dot3] at this

/-! ## Commutativity removes all freedom -/

/-- **Commutativity forces the defect to vanish.** -/
theorem commutative_iff_defect_zero {A : Defect} (hA : IsAlt A) :
    Commutative4 (muOf A) ↔ A = 0 := by
  constructor
  · intro hc
    apply LinearMap.ext; intro v; apply LinearMap.ext; intro w
    have hvw := hc (sp v) (sp w)
    simp only [muOf_apply, sp_snd] at hvw
    rw [mu4sym_comm (sp w) (sp v)] at hvw
    have h2 : A v w = A w v := add_left_cancel hvw
    have h3 : A v w = - A w v := isAlt_antisymm hA v w
    rw [← h2] at h3
    have h4 : (2 : ℝ) • A v w = 0 := by
      rw [two_smul]; nth_rewrite 2 [h3]; abel
    simp only [LinearMap.zero_apply]
    rcases smul_eq_zero.1 h4 with h5 | h5
    · norm_num at h5
    · exact h5
  · rintro rfl
    intro X Y
    simp [mu4sym_comm X Y]

/-- **PROVED UNIQUE.**  Sector compatibility together with commutativity
determines the global product completely. -/
theorem sectorCompatible_comm_unique (M : BiProd4) :
    (SectorCompatible M ∧ Commutative4 M) ↔ M = mu4sym := by
  constructor
  · rintro ⟨hM, hc⟩
    obtain ⟨A, hA, rfl⟩ := (sectorCompatible_iff M).1 hM
    have : A = 0 := (commutative_iff_defect_zero hA).1 hc
    subst this
    apply LinearMap.ext; intro X; apply LinearMap.ext; intro Y
    simp
  · rintro rfl
    exact ⟨mu4sym_sectorCompatible, mu4sym_comm⟩

/-- The global unit of the symmetric branch, proved directly. -/
theorem mu4sym_globalUnit : GlobalUnit mu4sym := by
  constructor <;> intro X <;> apply vec4_ext <;> simp [e₀, dot3]

end NullSectorTask04
