import RequestProject.NullSectorTask04.IdentityAudit

/-!
# Task 04, Layer 7: the stabilizer of the chosen unit and full isotropy

The stabilizer is defined by two conditions only: `R e₀ = e₀` and preservation
of `Q4`.  Preservation of `L4`, of the rest space and of the positive form `h`
are all derived, not imported from any prepackaged identification.

The main result of this file: sector compatibility together with equivariance
under the **full** stabilizer determines the global product uniquely.
-/

namespace NullSectorTask04

open NullSectorTask01

/-! ## The stabilizer -/

/-- Linear equivalences of the ambient carrier fixing `e₀` and preserving `Q4`. -/
def Stabilizer (R : Vec4 ≃ₗ[ℝ] Vec4) : Prop := R e₀ = e₀ ∧ ∀ X, Q4 (R X) = Q4 X

variable {R : Vec4 ≃ₗ[ℝ] Vec4}

/-- **Derived.**  A stabilizer preserves the polarized form. -/
theorem stab_L4 (hR : Stabilizer R) (X Y : Vec4) : L4 (R X) (R Y) = L4 X Y := by
  simp only [L4, ← map_add]
  rw [hR.2 (X + Y), hR.2 X, hR.2 Y]

/-- Pairing with `e₀` is preserved. -/
theorem stab_L4_e₀ (hR : Stabilizer R) (X : Vec4) : L4 (R X) e₀ = L4 X e₀ := by
  calc L4 (R X) e₀ = L4 (R X) (R e₀) := by rw [hR.1]
    _ = L4 X e₀ := stab_L4 hR X e₀

/-- **Derived.**  A stabilizer preserves the time component. -/
theorem stab_time (hR : Stabilizer R) (X : Vec4) : (R X).1 = X.1 := by
  have h1 := stab_L4_e₀ hR X
  rwa [L4_e₀_right, L4_e₀_right] at h1

/-- **Derived.**  A stabilizer preserves the rest space. -/
theorem stab_rest (hR : Stabilizer R) {X : Vec4} (hX : X ∈ Rest) : R X ∈ Rest := by
  rw [mem_Rest, stab_time hR]
  exact (mem_Rest X).1 hX

/-- **Derived.**  A stabilizer preserves the positive form of the rest space. -/
theorem stab_h (hR : Stabilizer R) (X Y : Vec4) : h (R X) (R Y) = h X Y := by
  simp only [h, stab_L4 hR]

/-- The spatial part of a stabilizer. -/
def restOf (R : Vec4 ≃ₗ[ℝ] Vec4) (v : Vec3) : Vec3 := (R (sp v)).2

theorem stab_sp (hR : Stabilizer R) (v : Vec3) : R (sp v) = sp (restOf R v) :=
  rest_eq_sp (stab_rest hR (sp_mem_Rest v))

theorem stab_snd (hR : Stabilizer R) (X : Vec4) : (R X).2 = restOf R X.2 := by
  conv_lhs => rw [vec4_decomp X]
  rw [map_add, map_smul, hR.1, stab_sp hR]
  simp [e₀]

theorem restOf_dot3 (hR : Stabilizer R) (v w : Vec3) :
    dot3 (restOf R v) (restOf R w) = dot3 v w := by
  have h1 := stab_h hR (sp v) (sp w)
  rwa [stab_sp hR v, stab_sp hR w, h_sp, h_sp] at h1

theorem restOf_add (hR : Stabilizer R) (v w : Vec3) :
    restOf R (v + w) = restOf R v + restOf R w := by
  apply sp_injective
  rw [← stab_sp hR (v + w), sp_add, map_add, stab_sp hR v, stab_sp hR w, ← sp_add]

theorem restOf_smul (hR : Stabilizer R) (c : ℝ) (v : Vec3) :
    restOf R (c • v) = c • restOf R v := by
  apply sp_injective
  rw [← stab_sp hR (c • v), sp_smul, map_smul, stab_sp hR v, ← sp_smul]

/-- Unit spatial directions are preserved. -/
theorem stab_unitSpacelike (hR : Stabilizer R) {s : Vec4} (hs : UnitSpacelike s) :
    UnitSpacelike (R s) := by
  refine ⟨?_, ?_⟩
  · rw [← hR.1, stab_L4 hR]; exact hs.1
  · rw [hR.2]; exact hs.2

/-! ## Equivariance -/

/-- Equivariance of a product under the full stabilizer. -/
def IsotropyEquivariant (M : BiProd4) : Prop :=
  ∀ R : Vec4 ≃ₗ[ℝ] Vec4, Stabilizer R → ∀ X Y, R (M X Y) = M (R X) (R Y)

/-- **The symmetric branch is equivariant**, directly from its coordinate-free
description. -/
theorem mu4sym_isotropyEquivariant : IsotropyEquivariant mu4sym := by
  intro R hR X Y
  rw [mu4sym_coordfree, map_sub, map_add, map_smul, map_smul, map_smul, hR.1,
    mu4sym_coordfree, stab_L4_e₀ hR, stab_L4_e₀ hR, stab_L4 hR]

/-! ## Explicit stabilizer elements -/

/-- Componentwise extensionality for spatial coordinates. -/
theorem vec3_ext {v w : Vec3} (h1 : v.1 = w.1) (h2 : v.2.1 = w.2.1) (h3 : v.2.2 = w.2.2) :
    v = w := by
  obtain ⟨a, b, c⟩ := v; obtain ⟨a', b', c'⟩ := w; simp_all

/-- Builder for a linear equivalence of the spatial coordinates. -/
def mkEquiv3 (f g : Vec3 → Vec3)
    (hadd : ∀ v w, f (v + w) = f v + f w) (hsmul : ∀ (c : ℝ) v, f (c • v) = c • f v)
    (h1 : ∀ v, g (f v) = v) (h2 : ∀ v, f (g v) = v) : Vec3 ≃ₗ[ℝ] Vec3 where
  toFun := f
  map_add' := hadd
  map_smul' := hsmul
  invFun := g
  left_inv := h1
  right_inv := h2

/-- Lift a spatial equivalence to the ambient carrier, fixing the time
coordinate. -/
def liftRest (f : Vec3 ≃ₗ[ℝ] Vec3) : Vec4 ≃ₗ[ℝ] Vec4 :=
  LinearEquiv.prodCongr (LinearEquiv.refl ℝ ℝ) f

@[simp] theorem liftRest_apply (f : Vec3 ≃ₗ[ℝ] Vec3) (X : Vec4) :
    liftRest f X = (X.1, f X.2) := rfl

theorem liftRest_stabilizer {f : Vec3 ≃ₗ[ℝ] Vec3} (hf : ∀ v, dot3 (f v) (f v) = dot3 v v) :
    Stabilizer (liftRest f) := by
  constructor
  · rw [liftRest_apply, e₀_snd, map_zero]
    rfl
  · intro X
    have h1 := hf X.2
    simp only [dot3_apply] at h1
    simp only [liftRest_apply, Q4]
    nlinarith [h1]

@[simp] theorem restOf_liftRest (f : Vec3 ≃ₗ[ℝ] Vec3) (v : Vec3) :
    restOf (liftRest f) v = f v := rfl

/-- Reflection of the first spatial coordinate. -/
def fx : Vec3 ≃ₗ[ℝ] Vec3 :=
  mkEquiv3 (fun v => (-v.1, v.2.1, v.2.2)) (fun v => (-v.1, v.2.1, v.2.2))
    (by intro v w; apply vec3_ext <;> simp; ring)
    (by intro c v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)

/-- Reflection of the second spatial coordinate. -/
def fy : Vec3 ≃ₗ[ℝ] Vec3 :=
  mkEquiv3 (fun v => (v.1, -v.2.1, v.2.2)) (fun v => (v.1, -v.2.1, v.2.2))
    (by intro v w; apply vec3_ext <;> simp; ring)
    (by intro c v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)

/-- Reflection of the third spatial coordinate. -/
def fz : Vec3 ≃ₗ[ℝ] Vec3 :=
  mkEquiv3 (fun v => (v.1, v.2.1, -v.2.2)) (fun v => (v.1, v.2.1, -v.2.2))
    (by intro v w; apply vec3_ext <;> simp; ring)
    (by intro c v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)
    (by intro v; apply vec3_ext <;> simp)

@[simp] theorem fx_apply (v : Vec3) : fx v = (-v.1, v.2.1, v.2.2) := rfl
@[simp] theorem fy_apply (v : Vec3) : fy v = (v.1, -v.2.1, v.2.2) := rfl
@[simp] theorem fz_apply (v : Vec3) : fz v = (v.1, v.2.1, -v.2.2) := rfl

theorem stabilizer_fx : Stabilizer (liftRest fx) :=
  liftRest_stabilizer (by intro v; simp only [fx_apply, dot3_apply]; ring)

theorem stabilizer_fy : Stabilizer (liftRest fy) :=
  liftRest_stabilizer (by intro v; simp only [fy_apply, dot3_apply]; ring)

theorem stabilizer_fz : Stabilizer (liftRest fz) :=
  liftRest_stabilizer (by intro v; simp only [fz_apply, dot3_apply]; ring)

/-! ## The equivariance condition on the defect -/

section
variable {M : BiProd4} (hE : IsotropyEquivariant M)
include hE

/-- **Translation of equivariance into a condition on the defect.** -/
theorem defect_equivariant (hR : Stabilizer R) (v w : Vec3) :
    R (defectOf M v w) = defectOf M (restOf R v) (restOf R w) := by
  rw [defectOf_apply, defectOf_apply, map_sub, map_smul, hR.1]
  rw [← stab_sp hR, ← stab_sp hR, hE R hR, restOf_dot3 hR]

end

/-! ## A defect is determined by its values on the coordinate basis -/

theorem defect_eq_zero_of_basis {A : Defect} (hA : IsAlt A)
    (h12 : A s₁ s₂ = 0) (h23 : A s₂ s₃ = 0) (h31 : A s₃ s₁ = 0) : A = 0 := by
  have h21 : A s₂ s₁ = 0 := by rw [isAlt_antisymm hA, h12, neg_zero]
  have h32 : A s₃ s₂ = 0 := by rw [isAlt_antisymm hA, h23, neg_zero]
  have h13 : A s₁ s₃ = 0 := by rw [isAlt_antisymm hA, h31, neg_zero]
  apply LinearMap.ext; intro v; apply LinearMap.ext; intro w
  obtain ⟨v1, v2, v3⟩ := v
  obtain ⟨w1, w2, w3⟩ := w
  have hv : ((v1, v2, v3) : Vec3) = v1 • s₁ + v2 • s₂ + v3 • s₃ := by
    apply vec3_ext <;> simp [s₁, s₂, s₃]
  have hw : ((w1, w2, w3) : Vec3) = w1 • s₁ + w2 • s₂ + w3 • s₃ := by
    apply vec3_ext <;> simp [s₁, s₂, s₃]
  rw [hv, hw]
  simp only [map_add, map_smul, LinearMap.add_apply, LinearMap.smul_apply,
    LinearMap.zero_apply, hA s₁, hA s₂, hA s₃, h12, h21, h23, h32, h13, h31,
    smul_zero, add_zero]

/-! ## Full isotropy kills the defect -/

section
variable {M : BiProd4} (hM : SectorCompatible M) (hE : IsotropyEquivariant M)
include hM hE

/-- **Full isotropy forces the defect to vanish.** -/
theorem defect_zero_of_full_isotropy : defectOf M = 0 := by
  have hA : IsAlt (defectOf M) := defectOf_isAlt hM
  have hx : ∀ v w : Vec3, liftRest fx (defectOf M v w) = defectOf M (fx v) (fx w) :=
    fun v w => defect_equivariant hE stabilizer_fx v w
  have hy : ∀ v w : Vec3, liftRest fy (defectOf M v w) = defectOf M (fy v) (fy w) :=
    fun v w => defect_equivariant hE stabilizer_fy v w
  have hz : ∀ v w : Vec3, liftRest fz (defectOf M v w) = defectOf M (fz v) (fz w) :=
    fun v w => defect_equivariant hE stabilizer_fz v w
  have fxs₁ : fx s₁ = -s₁ := by apply vec3_ext <;> simp [s₁]
  have fxs₂ : fx s₂ = s₂ := by apply vec3_ext <;> simp [s₂]
  have fxs₃ : fx s₃ = s₃ := by apply vec3_ext <;> simp [s₃]
  have fys₁ : fy s₁ = s₁ := by apply vec3_ext <;> simp [s₁]
  have fys₂ : fy s₂ = -s₂ := by apply vec3_ext <;> simp [s₂]
  have fys₃ : fy s₃ = s₃ := by apply vec3_ext <;> simp [s₃]
  have fzs₁ : fz s₁ = s₁ := by apply vec3_ext <;> simp [s₁]
  have fzs₂ : fz s₂ = s₂ := by apply vec3_ext <;> simp [s₂]
  have fzs₃ : fz s₃ = -s₃ := by apply vec3_ext <;> simp [s₃]
  -- the value on the pair (s₂, s₃)
  have h23 : defectOf M s₂ s₃ = 0 := by
    have e2 : liftRest fy (defectOf M s₂ s₃) = - defectOf M s₂ s₃ := by
      rw [hy s₂ s₃, fys₂, fys₃, map_neg, LinearMap.neg_apply]
    have e3 : liftRest fz (defectOf M s₂ s₃) = - defectOf M s₂ s₃ := by
      rw [hz s₂ s₃, fzs₂, fzs₃, map_neg]
    have c0 : (defectOf M s₂ s₃).1 = -(defectOf M s₂ s₃).1 :=
      congrArg (fun Z : Vec4 => Z.1) e2
    have c1 : (defectOf M s₂ s₃).2.1 = -(defectOf M s₂ s₃).2.1 :=
      congrArg (fun Z : Vec4 => Z.2.1) e2
    have c2 : (defectOf M s₂ s₃).2.2.1 = -(defectOf M s₂ s₃).2.2.1 :=
      congrArg (fun Z : Vec4 => Z.2.2.1) e3
    have c3 : (defectOf M s₂ s₃).2.2.2 = -(defectOf M s₂ s₃).2.2.2 :=
      congrArg (fun Z : Vec4 => Z.2.2.2) e2
    apply vec4_ext <;> simp only [Prod.fst_zero, Prod.snd_zero] <;> linarith
  -- the value on the pair (s₃, s₁)
  have h31 : defectOf M s₃ s₁ = 0 := by
    have e1 : liftRest fx (defectOf M s₃ s₁) = - defectOf M s₃ s₁ := by
      rw [hx s₃ s₁, fxs₃, fxs₁, map_neg]
    have e3 : liftRest fz (defectOf M s₃ s₁) = - defectOf M s₃ s₁ := by
      rw [hz s₃ s₁, fzs₃, fzs₁, map_neg, LinearMap.neg_apply]
    have c0 : (defectOf M s₃ s₁).1 = -(defectOf M s₃ s₁).1 :=
      congrArg (fun Z : Vec4 => Z.1) e1
    have c1 : (defectOf M s₃ s₁).2.1 = -(defectOf M s₃ s₁).2.1 :=
      congrArg (fun Z : Vec4 => Z.2.1) e3
    have c2 : (defectOf M s₃ s₁).2.2.1 = -(defectOf M s₃ s₁).2.2.1 :=
      congrArg (fun Z : Vec4 => Z.2.2.1) e1
    have c3 : (defectOf M s₃ s₁).2.2.2 = -(defectOf M s₃ s₁).2.2.2 :=
      congrArg (fun Z : Vec4 => Z.2.2.2) e1
    apply vec4_ext <;> simp only [Prod.fst_zero, Prod.snd_zero] <;> linarith
  -- the value on the pair (s₁, s₂)
  have h12 : defectOf M s₁ s₂ = 0 := by
    have e1 : liftRest fx (defectOf M s₁ s₂) = - defectOf M s₁ s₂ := by
      rw [hx s₁ s₂, fxs₁, fxs₂, map_neg, LinearMap.neg_apply]
    have e2 : liftRest fy (defectOf M s₁ s₂) = - defectOf M s₁ s₂ := by
      rw [hy s₁ s₂, fys₁, fys₂, map_neg]
    have c0 : (defectOf M s₁ s₂).1 = -(defectOf M s₁ s₂).1 :=
      congrArg (fun Z : Vec4 => Z.1) e1
    have c1 : (defectOf M s₁ s₂).2.1 = -(defectOf M s₁ s₂).2.1 :=
      congrArg (fun Z : Vec4 => Z.2.1) e2
    have c2 : (defectOf M s₁ s₂).2.2.1 = -(defectOf M s₁ s₂).2.2.1 :=
      congrArg (fun Z : Vec4 => Z.2.2.1) e1
    have c3 : (defectOf M s₁ s₂).2.2.2 = -(defectOf M s₁ s₂).2.2.2 :=
      congrArg (fun Z : Vec4 => Z.2.2.2) e1
    apply vec4_ext <;> simp only [Prod.fst_zero, Prod.snd_zero] <;> linarith
  exact defect_eq_zero_of_basis hA h12 h23 h31

end

/-- **PROVED UNIQUE.**  Sector compatibility together with equivariance under the
full stabilizer of `e₀` determines the global product completely — with no
commutativity assumption. -/
theorem sectorCompatible_isotropy_unique (M : BiProd4) :
    (SectorCompatible M ∧ IsotropyEquivariant M) ↔ M = mu4sym := by
  constructor
  · rintro ⟨hM, hE⟩
    have h0 : defectOf M = 0 := defect_zero_of_full_isotropy hM hE
    rw [eq_muOf_defect hM, h0, muOf_zero]
  · rintro rfl
    exact ⟨mu4sym_sectorCompatible, mu4sym_isotropyEquivariant⟩

end NullSectorTask04
