import RequestProject.NullSectorTask10.DynamicsDiagnostic

/-!
# Task 10, Layer 10: late conventional comparison — **COMPARISON ONLY**

Every statement in this module is labelled **COMPARISON ONLY**.  Nothing here is
used in the reconstruction; every theorem below is a restatement of a result
already proved in the neutral core, together with a remark relating it to
standard terminology.

**Physical-interpretation firewall (§31).**  No physical object has been
derived.  In particular this module does *not* claim that a photon, a fermion, a
physical longitudinal polarization or a physical half-integer state has been
constructed.  Task 10 establishes transformation structure only; physical state
selection is a separate problem, not addressed here.
-/

namespace NullSectorTask10

open NullSectorTask01 NullSectorTask04 NullSectorTask07 NullSectorTask08
open NullSectorTask09

/-! ## COMPARISON ONLY — 1. axial decomposition of the vector channels -/

/-- **COMPARISON ONLY.**  The longitudinal channel transforms with the constant
central factor `zsc 1 0`, i.e. with weight `0`; the two transverse `Z`-channels
transform with the mutually inverse factors `zsc (cos θ) (± sin θ)`, i.e. with
weights `±1`.  This is the pattern of the axial decomposition of a conventional
spin-1 representation.  No claim is made that a spin-1 particle, field or state
space has been constructed. -/
theorem comparison_vector_weights (θ : ℝ) :
    (∀ x ∈ LongW, Phi θ x = zsc 1 0 ⋆ x) ∧
    (∀ x ∈ Zline chPlus, Phi θ x = zsc (Real.cos θ) (Real.sin θ) ⋆ x) ∧
    (∀ x ∈ Zline chMinus, Phi θ x = zsc (Real.cos θ) (-Real.sin θ) ⋆ x) :=
  ⟨fun _ hx => Phi_on_LongW θ hx, fun _ hx => Phi_on_Zline_chPlus θ hx,
    fun _ hx => Phi_on_Zline_chMinus θ hx⟩

/-- **COMPARISON ONLY (§32).**  The weight-`0` longitudinal channel is a
transformation-theoretic fact about the carrier only.  Conventional massive
spin-1 representations may contain a longitudinal mode, whereas a physical
massless spin-1 field carries additional constraints that remove a longitudinal
physical polarization.  Task 10 neither derives nor imposes such constraints,
and the theorem below asserts nothing about them. -/
theorem comparison_longitudinal_channel_is_fixed (θ : ℝ) (x : W) (hx : x ∈ LongW) :
    Phi θ x = x :=
  Phi_fixes_LongW θ hx

/-! ## COMPARISON ONLY — 2. the double-valued lift -/

/-- **COMPARISON ONLY.**  The algebra automorphism returns after `2π` while the
distinguished internal lift returns only after `4π`, changing sign at `2π`.
This is the pattern conventionally described as the double-valued lift of
spatial rotations.  The statement is about the reconstructed carrier only. -/
theorem comparison_double_valued_lift :
    Phi (2 * Real.pi) = LinearMap.id ∧ Ustd (2 * Real.pi) = -w1 ∧
      Ustd (4 * Real.pi) = w1 :=
  ⟨Phi_two_pi, Ustd_two_pi, Ustd_four_pi⟩

/-- **COMPARISON ONLY.**  The lift is *not* unique after the normalization
`U 0 = 1`; the sharp sign statement above is a statement about the distinguished
representative.  Any conventional identification must therefore also fix the
scalar freedom. -/
theorem comparison_lift_scale_freedom : ∃ U : ℝ → W, IsKLift U ∧ U ≠ Ustd :=
  klift_not_unique

/-! ## COMPARISON ONLY — 3. the half-angle sectors -/

/-- **COMPARISON ONLY (§33).**  On the two distinguished-axis sectors the state
factor at angle `θ` equals the transverse vector factor at angle `θ/2`, with
opposite senses on the two sectors.  This is the transformation law
conventionally associated with projections `±1/2` along the distinguished axis.
No claim is made that these sectors are physical fermion states. -/
theorem comparison_half_angle_sectors (θ : ℝ) :
    (∀ ψ ∈ SectorPlus, StateAction θ ψ = vectorFactorMinus (θ / 2) ⋆ ψ) ∧
    (∀ ψ ∈ SectorMinus, StateAction θ ψ = vectorFactorPlus (θ / 2) ⋆ ψ) :=
  ⟨fun _ hψ => halfAngle_SectorPlus hψ θ, fun _ hψ => halfAngle_SectorMinus hψ θ⟩

/-- **COMPARISON ONLY (§33).**  A state orientation transverse to the
distinguished axis is *not* selected by the present data: the analogous sector
condition along a transverse generator fails to be preserved by the state
action.  Conventionally, a transverse spin orientation would require a
superposition or a further state-axis choice; none is introduced here. -/
theorem comparison_transverse_orientation_requires_more_data :
    ∃ (θ : ℝ) (ψ : W), ψ ≠ 0 ∧ wB ⋆ ψ = ψ ∧
      wB ⋆ (StateAction θ ψ) ≠ StateAction θ ψ :=
  no_canonical_transverse_state_orientation

/-! ## COMPARISON ONLY — 4. the infinitesimal generator -/

/-- **COMPARISON ONLY.**  The normalized axial derivation is the derivative at
`θ = 0` of the axial automorphism family, and equals one half of the commutator
with the transverse channel `R`.  This is the pattern of the usual infinitesimal
generator of rotations about a distinguished axis.  No evolution parameter and
no dynamical law are attached to it. -/
theorem comparison_generator (x : W) :
    HasDerivAt (fun θ => Phi θ x) (Dgen x) 0 ∧
      Dgen x = (2⁻¹ : ℝ) • (x ⋆ wR - wR ⋆ x) :=
  ⟨hasDerivAt_Phi_zero x, Dgen_eq_half_commutator x⟩

/-- **COMPARISON ONLY.**  Any conventional identification must supply, in
addition, a rule fixing the generator scale; the reconstruction fixes only the
direction. -/
theorem comparison_no_rate_selected :
    ∀ l : ℝ, IsAxialDerivation (l • Dgen) :=
  scaled_isAxialDerivation

end NullSectorTask10
