import RequestProject.NullSectorTask10.AxialDerivation

/-!
# Task 10, Layer 9: the first dynamics diagnostic (§28)

This is the only permitted dynamics conclusion of Task 10.  The scalar `λ`
below is a real number and nothing else: it is **not** an energy, a mass, a
frequency, or a Hamiltonian, and no evolution parameter is introduced.

The content is the negative control demanded by §28: every real multiple of the
normalized axial derivation satisfies exactly the same structural conditions, and
distinct multiples are distinct maps.  Hence the reconstructed structure fixes
the generator **direction** and leaves its **rate** entirely free.
-/

namespace NullSectorTask10

open NullSectorTask01 NullSectorTask04 NullSectorTask07 NullSectorTask08
open NullSectorTask09

/-- **THE NEGATIVE CONTROL (§28).**  Every real multiple of the normalized
generator is again an axial derivation. -/
theorem scaled_isAxialDerivation (l : ℝ) : IsAxialDerivation (l • Dgen) :=
  (axialDerivation_classification _).2 ⟨l, rfl⟩

/-- **THE DIRECTION IS FIXED.**  Every axial derivation is a real multiple of
the normalized generator. -/
theorem generator_direction_fixed {D : W →ₗ[ℝ] W} (hD : IsAxialDerivation D) :
    ∃ l : ℝ, D = l • Dgen :=
  (axialDerivation_classification D).1 hD

/-- **THE RATE IS NOT FIXED.**  Distinct real scalars give distinct axial
derivations, so the structural conditions do not select one. -/
theorem generator_rate_not_fixed {l l' : ℝ} (h : l ≠ l') : l • Dgen ≠ l' • Dgen :=
  fun heq => h (smul_left_injective ℝ Dgen_ne_zero heq)

/-- **THE COMBINED DIAGNOSTIC.**  The solution set of the structural conditions
is exactly a one-parameter real line of generators, and every point of it is
admissible: the current kinematic/algebraic structure fixes the generator
direction but does not fix an evolution rate. -/
theorem direction_fixed_rate_free :
    (∀ D : W →ₗ[ℝ] W, IsAxialDerivation D ↔ ∃ l : ℝ, D = l • Dgen) ∧
    (∀ l : ℝ, IsAxialDerivation (l • Dgen)) ∧
    (∀ l l' : ℝ, l ≠ l' → l • Dgen ≠ l' • Dgen) :=
  ⟨axialDerivation_classification, scaled_isAxialDerivation,
    fun _ _ h => generator_rate_not_fixed h⟩

/-- The same freedom, at the level of the internal lift: the scalar function of
`klift_classification` is not fixed either.  Task 10 therefore records **two**
independent unfixed scales, and introduces no rule relating any evolution
parameter to either. -/
theorem lift_scale_not_fixed : ∃ U : ℝ → W, IsKLift U ∧ U ≠ Ustd :=
  klift_not_unique

end NullSectorTask10
