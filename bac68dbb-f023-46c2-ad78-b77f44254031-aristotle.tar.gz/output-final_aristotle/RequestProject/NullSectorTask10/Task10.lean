import RequestProject.NullSectorTask10.Identification

/-!
# Task 10 — principal theorems and axiom report

This module imports the complete Task-10 development and exposes the principal
final theorems, one for each of the twelve Conservation-of-Difficulty questions
of §34, followed by the late comparison statements of §30 and the
`#print axioms` report demanded by §39.
-/

namespace NullSectorTask10

open NullSectorTask01 NullSectorTask04 NullSectorTask07 NullSectorTask08
open NullSectorTask09

/-! ## 1. Does the distinguished axis split old space? -/

/-- **1.**  Relative to the distinguished old spatial axis `A`, the old rest
space splits as an internal direct sum of the longitudinal line and the
transverse plane. -/
theorem task10_axis_decomposition :
    Long ⊓ Trans = ⊥ ∧ Long ⊔ Trans = Rest :=
  ⟨Long_inf_Trans, Long_sup_Trans⟩

/-! ## 2. The old axial rotation and its extension -/

/-- **2a.**  The old axial rotation is a one-parameter group of old isometries
fixing the time direction and the distinguished axis. -/
theorem task10_old_axial_rotation :
    rot 0 = LinearMap.id ∧
    (∀ θ φ : ℝ, rot (θ + φ) = (rot θ).comp (rot φ)) ∧
    (∀ (θ : ℝ) (X : Vec4), Q4 (rot θ X) = Q4 X) ∧
    (∀ θ : ℝ, rot θ axis = axis) :=
  ⟨rot_zero, rot_add, Q4_rot, rot_axis⟩

/-- **2b.**  The old axial rotation extends to the full Task-08/09 algebra, and
the extension is unique. -/
theorem task10_algebra_extension (θ : ℝ) :
    ∃! Φ : W →ₗ[ℝ] W, IsAxialExtension θ Φ :=
  axialExtension_existsUnique θ

/-- **2c.**  The complete action on the derived basis, obtained by
multiplication alone. -/
theorem task10_extension_on_basis (θ : ℝ) :
    Phi θ w1 = w1 ∧ Phi θ wA = wA ∧
    Phi θ wB = Real.cos θ • wB + Real.sin θ • wC ∧
    Phi θ wC = (-Real.sin θ) • wB + Real.cos θ • wC ∧
    Phi θ wP = Real.cos θ • wP + Real.sin θ • wQ ∧
    Phi θ wQ = (-Real.sin θ) • wP + Real.cos θ • wQ ∧
    Phi θ wR = wR ∧ Phi θ wS = wS :=
  ⟨Phi_w1 θ, Phi_wA θ, Phi_wB θ, Phi_wC θ, Phi_wP θ, Phi_wQ θ, Phi_wR θ, Phi_wS θ⟩

/-! ## 3. Longitudinal and transverse transformation channels -/

/-- **3a.**  The longitudinal line is fixed pointwise, the transverse plane is
preserved, and the transverse plane contains no proper nonzero invariant
subspace. -/
theorem task10_vector_sectors :
    (∀ (θ : ℝ) (x : W), x ∈ LongW → Phi θ x = x) ∧
    (∀ (θ : ℝ) (x : W), x ∈ TransW → Phi θ x ∈ TransW) :=
  ⟨fun θ _ hx => Phi_fixes_LongW θ hx, fun θ _ hx => Phi_preserves_TransW θ hx⟩

/-- **3b.**  Exactly two transverse `Z`-channels exist, with mutually inverse
central factors, and the longitudinal factor is the central unit. -/
theorem task10_channel_classification :
    (∀ ψ : W, IsZChannel ψ ↔ ψ ≠ 0 ∧ (ψ ∈ Zline chPlus ∨ ψ ∈ Zline chMinus)) ∧
    (∀ (θ : ℝ) (x : W), x ∈ LongW → Phi θ x = zsc 1 0 ⋆ x) ∧
    (∀ (θ : ℝ) (x : W), x ∈ Zline chPlus →
      Phi θ x = zsc (Real.cos θ) (Real.sin θ) ⋆ x) ∧
    (∀ (θ : ℝ) (x : W), x ∈ Zline chMinus →
      Phi θ x = zsc (Real.cos θ) (-Real.sin θ) ⋆ x) :=
  ⟨zChannel_classification, fun θ _ hx => Phi_on_LongW θ hx,
    fun θ _ hx => Phi_on_Zline_chPlus θ hx, fun θ _ hx => Phi_on_Zline_chMinus θ hx⟩

/-- **3c.**  Both Task-09 central norm branches are preserved separately; they
are not exchanged. -/
theorem task10_both_branches_preserved (θ : ℝ) (x : W) :
    Ncand 1 (Phi θ x) = Ncand 1 x ∧ Ncand (-1) (Phi θ x) = Ncand (-1) x :=
  both_branches_preserved θ x

/-! ## 4. Does the algebra automorphism return after `2π`? -/

/-- **4.**  Yes, on the entire algebra. -/
theorem task10_algebra_two_pi : Phi (2 * Real.pi) = LinearMap.id :=
  Phi_two_pi

/-! ## 5–6. Existence and (non-)uniqueness of the internal lift -/

/-- **5.**  An internal continuous lift inside the two-plane `K = spanℝ{1,R}`
exists, and its coordinate functions carry the half angle. -/
theorem task10_internal_lift_exists :
    IsKLift Ustd ∧ ∀ θ : ℝ, Ustd θ = ksc (Real.cos (θ / 2)) (- Real.sin (θ / 2)) :=
  ⟨Ustd_isKLift, fun _ => rfl⟩

/-- **6.**  The lift is **not** unique after the normalization `U 0 = 1`.  The
exact classification keeps a multiplicative scalar function free, and a second
lift is exhibited. -/
theorem task10_internal_lift_classification :
    (∀ U : ℝ → W, IsKLift U ↔ ∃ k : ℝ → ℝ, IsScalarFactor k ∧ ∀ θ, U θ = k θ • Ustd θ) ∧
    (∃ U : ℝ → W, IsKLift U ∧ U ≠ Ustd) :=
  ⟨klift_classification, klift_not_unique⟩

/-- **6b.**  A *derived* sharpening: requiring in addition that the lift
preserve the Task-09 branch `N₊` under left multiplication forces the scalar
factor to be `1`, hence singles out the distinguished representative.  This is
an extra hypothesis, not a convention. -/
theorem task10_internal_lift_normalized {U : ℝ → W} (hU : IsKLift U)
    (hbranch : ∀ (θ : ℝ) (ψ : W), Ncand 1 (U θ ⋆ ψ) = Ncand 1 ψ) :
    U = Ustd :=
  klift_branch_forces_k hU hbranch

/-! ## 7. `2π` and `4π` behaviour of the lift -/

/-- **7a.**  For the distinguished representative. -/
theorem task10_lift_periodicity :
    Ustd (2 * Real.pi) = -w1 ∧ Ustd (4 * Real.pi) = w1 :=
  Ustd_periodicity

/-- **7b.**  For an arbitrary internal lift the scalar freedom survives: only the
sign pattern is forced. -/
theorem task10_lift_periodicity_general {U : ℝ → W} (hU : IsKLift U) :
    ∃ c : ℝ, 0 < c ∧ U (2 * Real.pi) = (-c) • w1 ∧ U (4 * Real.pi) = (c ^ 2) • w1 :=
  klift_periodicity hU

/-! ## 8. Half-angle behaviour of the left state action -/

/-- **8.**  The candidate-state left action of the distinguished lift satisfies
`StateAction (2π) ψ = -ψ` and `StateAction (4π) ψ = ψ`, in explicit contrast
with the algebra action, which is already the identity at `2π`. -/
theorem task10_state_action_periodicity (ψ : W) :
    StateAction (2 * Real.pi) ψ = -ψ ∧ StateAction (4 * Real.pi) ψ = ψ ∧
      Phi (2 * Real.pi) ψ = ψ :=
  ⟨StateAction_two_pi ψ, StateAction_four_pi ψ, (algebra_vs_state_two_pi ψ).1⟩

/-- **8b.**  The two actions genuinely differ at `2π` on every nonzero element. -/
theorem task10_algebra_vs_state {x : W} (hx : x ≠ 0) :
    Phi (2 * Real.pi) x ≠ StateAction (2 * Real.pi) x :=
  algebra_ne_state_two_pi hx

/-! ## 9. The distinguished-axis half-angle sectors -/

/-- **9.**  The solution spaces of `R ψ = ± S ψ` are nonzero, of real dimension
`4` (equivalently `Z`-dimension `2`), intersect trivially, span the whole
carrier, are preserved by the state action, and transform with the transverse
vector factor at **half** the angle. -/
theorem task10_half_angle_sectors :
    Module.finrank ℝ SectorPlus = 4 ∧ Module.finrank ℝ SectorMinus = 4 ∧
    SectorPlus ⊓ SectorMinus = ⊥ ∧ SectorPlus ⊔ SectorMinus = ⊤ ∧
    SectorPlus = Zline (w1 + wA) ⊔ Zline (wB + wP) ∧
    SectorMinus = Zline (w1 - wA) ⊔ Zline (wB - wP) ∧
    (∀ (θ : ℝ) (ψ : W), ψ ∈ SectorPlus →
      StateAction θ ψ = vectorFactorMinus (θ / 2) ⋆ ψ) ∧
    (∀ (θ : ℝ) (ψ : W), ψ ∈ SectorMinus →
      StateAction θ ψ = vectorFactorPlus (θ / 2) ⋆ ψ) :=
  ⟨finrank_SectorPlus, finrank_SectorMinus, SectorPlus_inf_SectorMinus,
    SectorPlus_sup_SectorMinus, SectorPlus_eq_two_Zlines, SectorMinus_eq_two_Zlines,
    fun θ _ hψ => halfAngle_SectorPlus hψ θ, fun θ _ hψ => halfAngle_SectorMinus hψ θ⟩

/-! ## 10. Transverse state orientation -/

/-- **10.**  The present data do **not** select a transverse state orientation:
the analogous sector condition along a transverse generator is not preserved by
the state action.  Further state data would be required, and none is
introduced. -/
theorem task10_no_transverse_orientation :
    ∃ (θ : ℝ) (ψ : W), ψ ≠ 0 ∧ wB ⋆ ψ = ψ ∧
      wB ⋆ (StateAction θ ψ) ≠ StateAction θ ψ :=
  no_canonical_transverse_state_orientation

/-! ## 11–12. The axial derivation and the rate freedom -/

/-- **11.**  The space of structure-preserving axial derivations is exactly the
real line through the normalized generator; it is one-dimensional, uniquely
normalized by the orientation convention `D B = C`, and admits the intrinsic
commutator formula. -/
theorem task10_axial_derivations :
    (∀ D : W →ₗ[ℝ] W, IsAxialDerivation D ↔ ∃ l : ℝ, D = l • Dgen) ∧
    Module.finrank ℝ (Submodule.span ℝ {Dgen}) = 1 ∧
    (∀ {D : W →ₗ[ℝ] W}, IsAxialDerivation D → D wB = wC → D = Dgen) ∧
    (∀ x : W, Dgen x = (2⁻¹ : ℝ) • (x ⋆ wR - wR ⋆ x)) ∧
    (∀ x : W, HasDerivAt (fun θ => Phi θ x) (Dgen x) 0) :=
  ⟨axialDerivation_classification, finrank_axialDerivations,
    fun hD hor => axialDerivation_unique_of_orientation hD hor,
    Dgen_eq_half_commutator, hasDerivAt_Phi_zero⟩

/-- **11b.**  The derived action of the normalized generator on the remaining
derived basis elements. -/
theorem task10_generator_on_basis :
    Dgen w1 = 0 ∧ Dgen wA = 0 ∧ Dgen wB = wC ∧ Dgen wC = -wB ∧
    Dgen wP = wQ ∧ Dgen wQ = -wP ∧ Dgen wR = 0 ∧ Dgen wS = 0 :=
  ⟨Dgen_w1, Dgen_wA, Dgen_wB, Dgen_wC, Dgen_wP, Dgen_wQ, Dgen_wR, Dgen_wS⟩

/-- **12.**  The structure fixes the generator direction but not its rate. -/
theorem task10_rate_freedom :
    (∀ D : W →ₗ[ℝ] W, IsAxialDerivation D ↔ ∃ l : ℝ, D = l • Dgen) ∧
    (∀ l : ℝ, IsAxialDerivation (l • Dgen)) ∧
    (∀ l l' : ℝ, l ≠ l' → l • Dgen ≠ l' • Dgen) :=
  direction_fixed_rate_free

/-! ## Late conventional comparison — COMPARISON ONLY -/

/-- **COMPARISON ONLY.** -/
theorem task10_identification (θ : ℝ) :
    ((∀ x ∈ LongW, Phi θ x = zsc 1 0 ⋆ x) ∧
      (∀ x ∈ Zline chPlus, Phi θ x = zsc (Real.cos θ) (Real.sin θ) ⋆ x) ∧
      (∀ x ∈ Zline chMinus, Phi θ x = zsc (Real.cos θ) (-Real.sin θ) ⋆ x)) ∧
    (Phi (2 * Real.pi) = LinearMap.id ∧ Ustd (2 * Real.pi) = -w1 ∧
      Ustd (4 * Real.pi) = w1) ∧
    ((∀ ψ ∈ SectorPlus, StateAction θ ψ = vectorFactorMinus (θ / 2) ⋆ ψ) ∧
      (∀ ψ ∈ SectorMinus, StateAction θ ψ = vectorFactorPlus (θ / 2) ⋆ ψ)) ∧
    (∀ x : W, HasDerivAt (fun t => Phi t x) (Dgen x) 0 ∧
      Dgen x = (2⁻¹ : ℝ) • (x ⋆ wR - wR ⋆ x)) :=
  ⟨comparison_vector_weights θ, comparison_double_valued_lift,
    comparison_half_angle_sectors θ, comparison_generator⟩

/-! ## Axiom report (§39) -/

#print axioms task10_axis_decomposition
#print axioms task10_old_axial_rotation
#print axioms task10_algebra_extension
#print axioms task10_extension_on_basis
#print axioms task10_vector_sectors
#print axioms task10_channel_classification
#print axioms task10_both_branches_preserved
#print axioms task10_algebra_two_pi
#print axioms task10_internal_lift_exists
#print axioms task10_internal_lift_classification
#print axioms task10_internal_lift_normalized
#print axioms task10_lift_periodicity
#print axioms task10_lift_periodicity_general
#print axioms task10_state_action_periodicity
#print axioms task10_algebra_vs_state
#print axioms task10_half_angle_sectors
#print axioms task10_no_transverse_orientation
#print axioms task10_axial_derivations
#print axioms task10_generator_on_basis
#print axioms task10_rate_freedom
#print axioms task10_identification

end NullSectorTask10
