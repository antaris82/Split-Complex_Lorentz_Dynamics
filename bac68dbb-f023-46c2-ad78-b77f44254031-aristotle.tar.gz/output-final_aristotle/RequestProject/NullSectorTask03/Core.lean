import RequestProject.NullSectorTask02.GeneralUnit

/-!
# Task 03 core: Lorentz maps, unit orbit, product covariance, null pair

Input data (and nothing else):

* the real carrier `Long = ℝ × ℝ` and the quadratic form `Q2`
  (`RequestProject.NullSectorTask01.Basic`);
* the polarization `L2`, the reference coordinate vectors `u₀`, `s₀`, the
  admissibility predicate `AdmissibleAt`, the reconstruction `recAt` with its
  existence/uniqueness theorem, and `FutureUnit`
  (`RequestProject.NullSectorTask02.LorentzData/CandidateProduct/FixedUnit/GeneralUnit`).

**Import firewall.**  No Task-01 split-complex, strata, limits or boost declaration
is used anywhere in this file; the only Task-01 module reachable from here is
`Basic` (carrier and quadratic form), through the Task-02 chain.  The comparison
with Task 01 happens exclusively in `Comparison.lean`, which is imported by
nothing except `Task03.lean`.

The core is kept in a single module because every module of this project imports
the whole of Mathlib, which dominates compilation time; the layering intended by
the task is preserved as the four sections below.

* Layer 1 — Lorentz maps: `IsLorentz`, derived `L2`-preservation, the future
  component, the determinant `detL`, the stricter `IsProper`, and the explicit
  normal form on the two-dimensional carrier.
* Layer 2 — the orbit of normalized future units: explicit transporters, the
  complete transporter classification, and the stabilizer.
* Layer 3 — the reconstructed product family `mu e`, its covariance, multiplicative
  transport, and fixed-product invariance versus family covariance.
* Layer 4 — spacelike companions, the complementary null pair, ordered versus
  unordered structure, and transport of the pair.
-/
namespace NullSectorTask03

open NullSectorTask01 NullSectorTask02

/-! ## Lorentz maps -/

/-- A real-linear equivalence of `Long` is *Lorentz* when it preserves `Q2`. -/
def IsLorentz (T : Long ≃ₗ[ℝ] Long) : Prop := ∀ X, Q2 (T X) = Q2 X

/-- **Derived, not assumed (§4).**  Preservation of the quadratic form already forces
preservation of its polarization: no second axiom is needed. -/
theorem L2_of_isLorentz {T : Long ≃ₗ[ℝ] Long} (h : IsLorentz T) (X Y : Long) :
    L2 (T X) (T Y) = L2 X Y := by
  have hadd : T (X + Y) = T X + T Y := map_add T X Y
  have h1 : Q2 (T X + T Y) = Q2 (X + Y) := by rw [← hadd]; exact h (X + Y)
  simp only [L2, h1, h X, h Y]

/-- The identity is a Lorentz map. -/
theorem isLorentz_refl : IsLorentz (LinearEquiv.refl ℝ Long) := fun _ => rfl

theorem isLorentz_symm {T : Long ≃ₗ[ℝ] Long} (h : IsLorentz T) : IsLorentz T.symm := by
  intro X
  have h0 := h (T.symm X)
  rw [T.apply_symm_apply] at h0
  exact h0.symm

theorem isLorentz_trans {T S : Long ≃ₗ[ℝ] Long} (hT : IsLorentz T) (hS : IsLorentz S) :
    IsLorentz (T.trans S) := fun X => by
  simp only [LinearEquiv.trans_apply]
  rw [hS (T X), hT X]

/-! ## The future component -/

/-- A vector of the open future timelike cone. -/
def FutureTimelike (X : Long) : Prop := 0 < X.1 ∧ 0 < Q2 X

/-- `T` maps the future timelike component into itself.  No orientation condition is
built into this definition. -/
def PreservesFuture (T : Long ≃ₗ[ℝ] Long) : Prop := ∀ X, FutureTimelike X → FutureTimelike (T X)

theorem futureTimelike_u₀ : FutureTimelike u₀ := by
  constructor <;> simp [u₀, Q2]

theorem futureTimelike_of_futureUnit {e : Long} (he : FutureUnit e) : FutureTimelike e :=
  ⟨he.1, by rw [he.2]; norm_num⟩

/-! ## Determinant and the stricter proper condition -/

/-- The determinant of `T` in the coordinate basis `(u₀, s₀)`; a concrete real number,
not an imported classification. -/
def detL (T : Long ≃ₗ[ℝ] Long) : ℝ := (T u₀).1 * (T s₀).2 - (T s₀).1 * (T u₀).2

/-- The *stricter* condition: preservation of the coordinate orientation. -/
def IsProper (T : Long ≃ₗ[ℝ] Long) : Prop := detL T = 1

/-- Future-preserving **and** orientation-preserving. -/
def ProperFutureLorentz (T : Long ≃ₗ[ℝ] Long) : Prop :=
  IsLorentz T ∧ PreservesFuture T ∧ IsProper T

/-! ## Normal form -/

/-- Every linear map of `Long` is determined by its values on `u₀` and `s₀`. -/
theorem linear_expand (T : Long ≃ₗ[ℝ] Long) (X : Long) :
    T X = X.1 • T u₀ + X.2 • T s₀ := by
  conv_lhs => rw [coord_decomp X]
  rw [map_add, map_smul, map_smul]

/-- **Normal form of a Lorentz map.**  With `a = (T u₀).1` and `c = (T u₀).2` one has
`a² - c² = 1` and `T` is either the "proper" matrix `[[a,c],[c,a]]` or the
"orientation-reversing" matrix `[[a,-c],[c,-a]]`.  Proved by explicit coordinate
computation on the two-dimensional carrier. -/
theorem lorentz_normal_form {T : Long ≃ₗ[ℝ] Long} (h : IsLorentz T) :
    ∃ a c : ℝ, a ^ 2 - c ^ 2 = 1 ∧ (T u₀ = (a, c)) ∧
      ((T s₀ = (c, a) ∧ ∀ X : Long, T X = (a * X.1 + c * X.2, c * X.1 + a * X.2)) ∨
       (T s₀ = (-c, -a) ∧ ∀ X : Long, T X = (a * X.1 - c * X.2, c * X.1 - a * X.2))) := by
  set a := (T u₀).1 with ha
  set c := (T u₀).2 with hc
  set b := (T s₀).1 with hb
  set d := (T s₀).2 with hd
  have hu : a ^ 2 - c ^ 2 = 1 := by
    have := h u₀
    rw [Q2_u₀] at this
    simpa [Q2] using this
  have hs : b ^ 2 - d ^ 2 = -1 := by
    have := h s₀
    rw [Q2_s₀] at this
    simpa [Q2] using this
  have hTu : T u₀ = (a, c) := by rw [ha, hc]
  have hTs : T s₀ = (b, d) := by rw [hb, hd]
  have hcross : a * b - c * d = 0 := by
    have h0 := L2_of_isLorentz h u₀ s₀
    rw [L2_u₀_s₀, L2_coord, hTu, hTs] at h0
    simpa using h0
  have hane : a ≠ 0 := by
    intro h0
    rw [h0] at hu
    nlinarith [sq_nonneg c]
  have ha2 : a ^ 2 = 1 + c ^ 2 := by linarith
  have hd2' : d ^ 2 = 1 + b ^ 2 := by linarith
  have hab : a * b = c * d := by linarith
  have hsq : a ^ 2 * b ^ 2 = c ^ 2 * d ^ 2 := by
    linear_combination (a * b + c * d) * hab
  have hb2 : b ^ 2 = c ^ 2 := by
    linear_combination hsq - b ^ 2 * ha2 + c ^ 2 * hd2'
  have hd2 : d ^ 2 = a ^ 2 := by
    linear_combination hd2' + hb2 - ha2
  have hbc : b = c ∨ b = -c := by
    rcases mul_eq_zero.mp (show (b - c) * (b + c) = 0 by nlinarith [hb2]) with h1 | h1
    · left; linarith
    · right; linarith
  have hda : d = a ∨ d = -a := by
    rcases mul_eq_zero.mp (show (d - a) * (d + a) = 0 by nlinarith [hd2]) with h1 | h1
    · left; linarith
    · right; linarith
  refine ⟨a, c, hu, hTu, ?_⟩
  have expand : ∀ X : Long, T X = (a * X.1 + b * X.2, c * X.1 + d * X.2) := by
    intro X
    rw [linear_expand T X, hTu, hTs]
    apply Prod.ext <;> simp <;> ring
  rcases hbc with hbc | hbc <;> rcases hda with hda | hda
  · left
    refine ⟨by rw [hTs, hbc, hda], ?_⟩
    intro X; rw [expand X, hbc, hda]
  · have hc0 : c = 0 := by
      rw [hbc, hda] at hcross
      rcases mul_eq_zero.mp (by linarith : a * c = 0) with h1 | h1
      · exact absurd h1 hane
      · exact h1
    right
    refine ⟨by rw [hTs, hbc, hda, hc0]; simp, ?_⟩
    intro X; rw [expand X, hbc, hda, hc0]; simp
  · have hc0 : c = 0 := by
      rw [hbc, hda] at hcross
      rcases mul_eq_zero.mp (by linarith : a * c = 0) with h1 | h1
      · exact absurd h1 hane
      · exact h1
    left
    refine ⟨by rw [hTs, hbc, hda, hc0]; simp, ?_⟩
    intro X; rw [expand X, hbc, hda, hc0]; simp
  · right
    refine ⟨by rw [hTs, hbc, hda], ?_⟩
    intro X; rw [expand X, hbc, hda]
    apply Prod.ext <;> simp <;> ring

/-- **Exactly two components.**  The determinant of a Lorentz map is `±1`. -/
theorem detL_eq_one_or_neg_one {T : Long ≃ₗ[ℝ] Long} (h : IsLorentz T) :
    detL T = 1 ∨ detL T = -1 := by
  obtain ⟨a, c, hu, hTu, hcase⟩ := lorentz_normal_form h
  rcases hcase with ⟨hTs, _⟩ | ⟨hTs, _⟩
  · left; simp [detL, hTu, hTs]; nlinarith [hu]
  · right; simp [detL, hTu, hTs]; nlinarith [hu]

/-- Elementary positivity fact used for the future component: if `a > 0`, `a² - c² = 1`
and `v² < u²` with `u > 0`, then `a u + c v > 0`. -/
theorem futureCoeff_pos {a c u v : ℝ} (ha : 0 < a) (hac : a ^ 2 - c ^ 2 = 1) (hu : 0 < u)
    (huv : v ^ 2 < u ^ 2) : 0 < a * u + c * v := by
  by_contra hcon
  push_neg at hcon
  have hau : 0 < a * u := mul_pos ha hu
  have h1 : 0 < a * u - c * v := by linarith
  have h2 : 0 ≤ (-(a * u + c * v)) * (a * u - c * v) := mul_nonneg (by linarith) h1.le
  have hexp : (a * u + c * v) * (a * u - c * v) = u ^ 2 + c ^ 2 * (u ^ 2 - v ^ 2) := by
    linear_combination u ^ 2 * hac
  have h3 : 0 ≤ c ^ 2 * (u ^ 2 - v ^ 2) := mul_nonneg (sq_nonneg c) (by linarith)
  have h4 : 0 < u ^ 2 := pow_pos hu 2
  nlinarith [h2, hexp, h3, h4]

/-- Future preservation is equivalent to positivity of the single number `(T u₀).1`. -/
theorem preservesFuture_iff {T : Long ≃ₗ[ℝ] Long} (h : IsLorentz T) :
    PreservesFuture T ↔ 0 < (T u₀).1 := by
  constructor
  · intro hf
    exact (hf u₀ futureTimelike_u₀).1
  · intro hpos X hX
    obtain ⟨a, c, hu, hTu, hcase⟩ := lorentz_normal_form h
    have ha : 0 < a := by rw [hTu] at hpos; exact hpos
    have hQ : 0 < Q2 (T X) := by rw [h X]; exact hX.2
    refine ⟨?_, hQ⟩
    have hX2 : X.2 ^ 2 < X.1 ^ 2 := by
      have := hX.2; simp [Q2] at this; linarith
    rcases hcase with ⟨_, hform⟩ | ⟨_, hform⟩
    · rw [hform X]
      exact futureCoeff_pos ha hu hX.1 hX2
    · rw [hform X]
      have hu' : a ^ 2 - (-c) ^ 2 = 1 := by linear_combination hu
      have := futureCoeff_pos ha hu' hX.1 hX2
      simpa using this

/-- **Normal form of a future-preserving Lorentz map**: the coefficient `a` is
positive, and the two cases are exactly the two determinant values. -/
theorem futureLorentz_normal_form {T : Long ≃ₗ[ℝ] Long} (h : IsLorentz T)
    (hf : PreservesFuture T) :
    ∃ a c : ℝ, a ^ 2 - c ^ 2 = 1 ∧ 0 < a ∧
      ((detL T = 1 ∧ ∀ X : Long, T X = (a * X.1 + c * X.2, c * X.1 + a * X.2)) ∨
       (detL T = -1 ∧ ∀ X : Long, T X = (a * X.1 - c * X.2, c * X.1 - a * X.2))) := by
  obtain ⟨a, c, hu, hTu, hcase⟩ := lorentz_normal_form h
  have ha : 0 < a := by
    have := (preservesFuture_iff h).mp hf
    rw [hTu] at this; exact this
  refine ⟨a, c, hu, ha, ?_⟩
  rcases hcase with ⟨hTs, hform⟩ | ⟨hTs, hform⟩
  · left
    refine ⟨?_, hform⟩
    simp [detL, hTu, hTs]; nlinarith [hu]
  · right
    refine ⟨?_, hform⟩
    simp [detL, hTu, hTs]; nlinarith [hu]


/-! ## Two concrete families of Lorentz equivalences -/

/-- Underlying linear map of the determinant `+1` family. -/
def hypRotMap (A C : ℝ) : Long →ₗ[ℝ] Long where
  toFun X := (A * X.1 + C * X.2, C * X.1 + A * X.2)
  map_add' := by intro X Y; apply Prod.ext <;> simp <;> ring
  map_smul' := by intro r X; apply Prod.ext <;> simp <;> ring

@[simp] theorem hypRotMap_apply (A C : ℝ) (X : Long) :
    hypRotMap A C X = (A * X.1 + C * X.2, C * X.1 + A * X.2) := rfl

/-- Underlying linear map of the determinant `-1` family. -/
def hypFlipMap (A C : ℝ) : Long →ₗ[ℝ] Long where
  toFun X := (A * X.1 - C * X.2, C * X.1 - A * X.2)
  map_add' := by intro X Y; apply Prod.ext <;> simp <;> ring
  map_smul' := by intro r X; apply Prod.ext <;> simp <;> ring

@[simp] theorem hypFlipMap_apply (A C : ℝ) (X : Long) :
    hypFlipMap A C X = (A * X.1 - C * X.2, C * X.1 - A * X.2) := rfl

/-- The determinant `+1` Lorentz equivalence with coefficients `(A, C)`. -/
def hypRot (A C : ℝ) (h : A ^ 2 - C ^ 2 = 1) : Long ≃ₗ[ℝ] Long :=
  LinearEquiv.ofLinear (hypRotMap A C) (hypRotMap A (-C))
    (by
      apply LinearMap.ext; intro X; apply Prod.ext <;> simp <;>
        [linear_combination X.1 * h; linear_combination X.2 * h])
    (by
      apply LinearMap.ext; intro X; apply Prod.ext <;> simp <;>
        [linear_combination X.1 * h; linear_combination X.2 * h])

@[simp] theorem hypRot_apply (A C : ℝ) (h : A ^ 2 - C ^ 2 = 1) (X : Long) :
    hypRot A C h X = (A * X.1 + C * X.2, C * X.1 + A * X.2) := rfl

/-- The determinant `-1` Lorentz equivalence with coefficients `(A, C)`. -/
def hypFlip (A C : ℝ) (h : A ^ 2 - C ^ 2 = 1) : Long ≃ₗ[ℝ] Long :=
  LinearEquiv.ofLinear (hypFlipMap A C) (hypFlipMap A C)
    (by
      apply LinearMap.ext; intro X; apply Prod.ext <;> simp <;>
        [linear_combination X.1 * h; linear_combination X.2 * h])
    (by
      apply LinearMap.ext; intro X; apply Prod.ext <;> simp <;>
        [linear_combination X.1 * h; linear_combination X.2 * h])

@[simp] theorem hypFlip_apply (A C : ℝ) (h : A ^ 2 - C ^ 2 = 1) (X : Long) :
    hypFlip A C h X = (A * X.1 - C * X.2, C * X.1 - A * X.2) := rfl

theorem hypRot_isLorentz (A C : ℝ) (h : A ^ 2 - C ^ 2 = 1) : IsLorentz (hypRot A C h) := by
  intro X
  simp only [hypRot_apply, Q2]
  linear_combination (X.1 ^ 2 - X.2 ^ 2) * h

theorem hypFlip_isLorentz (A C : ℝ) (h : A ^ 2 - C ^ 2 = 1) : IsLorentz (hypFlip A C h) := by
  intro X
  simp only [hypFlip_apply, Q2]
  linear_combination (X.1 ^ 2 - X.2 ^ 2) * h

theorem hypRot_detL (A C : ℝ) (h : A ^ 2 - C ^ 2 = 1) : detL (hypRot A C h) = 1 := by
  simp only [detL, hypRot_apply, u₀, s₀]
  linear_combination h

theorem hypFlip_detL (A C : ℝ) (h : A ^ 2 - C ^ 2 = 1) : detL (hypFlip A C h) = -1 := by
  simp only [detL, hypFlip_apply, u₀, s₀]
  linear_combination -h

theorem hypRot_preservesFuture (A C : ℝ) (h : A ^ 2 - C ^ 2 = 1) (hA : 0 < A) :
    PreservesFuture (hypRot A C h) := by
  rw [preservesFuture_iff (hypRot_isLorentz A C h)]
  simpa [u₀] using hA

theorem hypFlip_preservesFuture (A C : ℝ) (h : A ^ 2 - C ^ 2 = 1) (hA : 0 < A) :
    PreservesFuture (hypFlip A C h) := by
  rw [preservesFuture_iff (hypFlip_isLorentz A C h)]
  simpa [u₀] using hA

/-! ## Action on normalized future units -/

/-- A Lorentz map preserves the normalization condition. -/
theorem isLorentz_Q2_unit {T : Long ≃ₗ[ℝ] Long} (h : IsLorentz T) {e : Long} (he : Q2 e = 1) :
    Q2 (T e) = 1 := by rw [h e, he]

/-- **PROVED (§5).**  A future-preserving Lorentz map sends normalized future units to
normalized future units. -/
theorem futureUnit_map {T : Long ≃ₗ[ℝ] Long} (h : IsLorentz T) (hfut : PreservesFuture T)
    {e : Long} (he : FutureUnit e) : FutureUnit (T e) :=
  ⟨(hfut e (futureTimelike_of_futureUnit he)).1, isLorentz_Q2_unit h he.2⟩

/-- **Negative control.**  Without the future condition the statement fails: `-id` is a
Lorentz map that destroys the future condition. -/
theorem futureUnit_not_preserved_by_all_lorentz :
    ∃ T : Long ≃ₗ[ℝ] Long, IsLorentz T ∧ ∃ e : Long, FutureUnit e ∧ ¬ FutureUnit (T e) := by
  refine ⟨LinearEquiv.neg ℝ, fun X => by simp [Q2], u₀, futureUnit_u₀, ?_⟩
  intro hcon
  have h0 := hcon.1
  simp [u₀] at h0
  linarith

/-! ## Explicit transporters -/

/-- Positivity of the two pairings of two normalized future units. -/
theorem pairing_pos {e f : Long} (he : FutureUnit e) (hf : FutureUnit f) :
    0 < e.1 * f.1 - e.2 * f.2 ∧ 0 < e.1 * f.1 + e.2 * f.2 := by
  obtain ⟨he1, heQ⟩ := he
  obtain ⟨hf1, hfQ⟩ := hf
  simp only [Q2] at heQ hfQ
  have hprod : (e.1 * f.1 - e.2 * f.2) * (e.1 * f.1 + e.2 * f.2) = 1 + e.2 ^ 2 + f.2 ^ 2 := by
    linear_combination (f.1 ^ 2) * heQ + (e.2 ^ 2 + 1) * hfQ
  have hsum : 0 < (e.1 * f.1 - e.2 * f.2) + (e.1 * f.1 + e.2 * f.2) := by
    nlinarith [mul_pos he1 hf1]
  constructor <;> nlinarith [sq_nonneg e.2, sq_nonneg f.2]

theorem transport_coeff {e f : Long} (he : Q2 e = 1) (hf : Q2 f = 1) :
    (e.1 * f.1 - e.2 * f.2) ^ 2 - (e.1 * f.2 - e.2 * f.1) ^ 2 = 1 := by
  simp only [Q2] at he hf
  linear_combination (f.1 ^ 2 - f.2 ^ 2) * he + hf

theorem transportFlip_coeff {e f : Long} (he : Q2 e = 1) (hf : Q2 f = 1) :
    (e.1 * f.1 + e.2 * f.2) ^ 2 - (e.1 * f.2 + e.2 * f.1) ^ 2 = 1 := by
  simp only [Q2] at he hf
  linear_combination (f.1 ^ 2 - f.2 ^ 2) * he + hf

/-- **The transporter**, built from `Q2`, `L2`, `e` and `f` alone.  Its first
coefficient is the pairing `L2 e f`, its second the coordinate determinant of `(e,f)`. -/
def transport {e f : Long} (he : Q2 e = 1) (hf : Q2 f = 1) : Long ≃ₗ[ℝ] Long :=
  hypRot (e.1 * f.1 - e.2 * f.2) (e.1 * f.2 - e.2 * f.1) (transport_coeff he hf)

/-- The orientation-reversing partner of the transporter. -/
def transportFlip {e f : Long} (he : Q2 e = 1) (hf : Q2 f = 1) : Long ≃ₗ[ℝ] Long :=
  hypFlip (e.1 * f.1 + e.2 * f.2) (e.1 * f.2 + e.2 * f.1) (transportFlip_coeff he hf)

@[simp] theorem transport_apply {e f : Long} (he : Q2 e = 1) (hf : Q2 f = 1) (X : Long) :
    transport he hf X =
      ((e.1 * f.1 - e.2 * f.2) * X.1 + (e.1 * f.2 - e.2 * f.1) * X.2,
        (e.1 * f.2 - e.2 * f.1) * X.1 + (e.1 * f.1 - e.2 * f.2) * X.2) := rfl

@[simp] theorem transportFlip_apply {e f : Long} (he : Q2 e = 1) (hf : Q2 f = 1) (X : Long) :
    transportFlip he hf X =
      ((e.1 * f.1 + e.2 * f.2) * X.1 - (e.1 * f.2 + e.2 * f.1) * X.2,
        (e.1 * f.2 + e.2 * f.1) * X.1 - (e.1 * f.1 + e.2 * f.2) * X.2) := rfl

theorem transport_isLorentz {e f : Long} (he : Q2 e = 1) (hf : Q2 f = 1) :
    IsLorentz (transport he hf) := hypRot_isLorentz _ _ _

theorem transportFlip_isLorentz {e f : Long} (he : Q2 e = 1) (hf : Q2 f = 1) :
    IsLorentz (transportFlip he hf) := hypFlip_isLorentz _ _ _

theorem transport_detL {e f : Long} (he : Q2 e = 1) (hf : Q2 f = 1) :
    detL (transport he hf) = 1 := hypRot_detL _ _ _

theorem transportFlip_detL {e f : Long} (he : Q2 e = 1) (hf : Q2 f = 1) :
    detL (transportFlip he hf) = -1 := hypFlip_detL _ _ _

theorem transport_preservesFuture {e f : Long} (he : FutureUnit e) (hf : FutureUnit f) :
    PreservesFuture (transport he.2 hf.2) :=
  hypRot_preservesFuture _ _ _ (pairing_pos he hf).1

theorem transportFlip_preservesFuture {e f : Long} (he : FutureUnit e) (hf : FutureUnit f) :
    PreservesFuture (transportFlip he.2 hf.2) :=
  hypFlip_preservesFuture _ _ _ (pairing_pos he hf).2

/-- The transporter does what it is built for. -/
theorem transport_unit {e f : Long} (he : Q2 e = 1) (hf : Q2 f = 1) :
    transport he hf e = f := by
  simp only [Q2] at he
  apply Prod.ext <;> simp only [transport_apply]
  · linear_combination f.1 * he
  · linear_combination f.2 * he

theorem transportFlip_unit {e f : Long} (he : Q2 e = 1) (hf : Q2 f = 1) :
    transportFlip he hf e = f := by
  simp only [Q2] at he
  apply Prod.ext <;> simp only [transportFlip_apply]
  · linear_combination f.1 * he
  · linear_combination f.2 * he

/-- **PROVED (§8).  Transitivity of the future Lorentz action on normalized future
units**, with an explicit orientation-preserving transporter. -/
theorem futureUnit_orbit_transitive {e f : Long} (he : FutureUnit e) (hf : FutureUnit f) :
    ∃ T : Long ≃ₗ[ℝ] Long, IsLorentz T ∧ PreservesFuture T ∧ IsProper T ∧ T e = f :=
  ⟨transport he.2 hf.2, transport_isLorentz _ _, transport_preservesFuture he hf,
    transport_detL _ _, transport_unit _ _⟩

/-! ## Classification of transporters -/

/-- **Case A (§9): exactly two transporters** for future-preserving Lorentz maps. -/
theorem transporter_classification {e f : Long} (he : FutureUnit e) (hf : FutureUnit f)
    {T : Long ≃ₗ[ℝ] Long} (hT : IsLorentz T) (hfut : PreservesFuture T) (hTe : T e = f) :
    (∀ X, T X = transport he.2 hf.2 X) ∨ (∀ X, T X = transportFlip he.2 hf.2 X) := by
  obtain ⟨a, c, hac, ha, hcase⟩ := futureLorentz_normal_form hT hfut
  have heQ : e.1 ^ 2 - e.2 ^ 2 = 1 := by have := he.2; simpa [Q2] using this
  rcases hcase with ⟨_, hform⟩ | ⟨_, hform⟩
  · left
    have h1 : a * e.1 + c * e.2 = f.1 := by rw [← hTe, hform e]
    have h2 : c * e.1 + a * e.2 = f.2 := by rw [← hTe, hform e]
    have hA : a = e.1 * f.1 - e.2 * f.2 := by
      linear_combination e.1 * h1 - e.2 * h2 - a * heQ
    have hC : c = e.1 * f.2 - e.2 * f.1 := by
      linear_combination e.1 * h2 - e.2 * h1 - c * heQ
    intro X
    rw [hform X, transport_apply, hA, hC]
  · right
    have h1 : a * e.1 - c * e.2 = f.1 := by rw [← hTe, hform e]
    have h2 : c * e.1 - a * e.2 = f.2 := by rw [← hTe, hform e]
    have hA : a = e.1 * f.1 + e.2 * f.2 := by
      linear_combination e.1 * h1 + e.2 * h2 - a * heQ
    have hC : c = e.1 * f.2 + e.2 * f.1 := by
      linear_combination e.2 * h1 + e.1 * h2 - c * heQ
    intro X
    rw [hform X, transportFlip_apply, hA, hC]

/-- The two transporters are genuinely different: their determinants differ. -/
theorem transport_ne_transportFlip {e f : Long} (he : Q2 e = 1) (hf : Q2 f = 1) :
    ∃ X : Long, transport he hf X ≠ transportFlip he hf X := by
  by_contra hcon
  push_neg at hcon
  have h1 : detL (transport he hf) = detL (transportFlip he hf) := by
    simp only [detL, hcon]
  rw [transport_detL, transportFlip_detL] at h1
  norm_num at h1

/-- **Case B (§9): with the orientation condition the transporter is unique.** -/
theorem proper_transporter_unique {e f : Long} (he : FutureUnit e) (hf : FutureUnit f)
    {T : Long ≃ₗ[ℝ] Long} (hT : IsLorentz T) (hfut : PreservesFuture T) (hp : IsProper T)
    (hTe : T e = f) : ∀ X, T X = transport he.2 hf.2 X := by
  rcases transporter_classification he hf hT hfut hTe with h | h
  · exact h
  · exfalso
    have : detL T = -1 := by
      simp only [detL, h]
      have := transportFlip_detL he.2 hf.2
      simpa [detL] using this
    rw [hp] at this
    norm_num at this

/-- Both classified maps really are transporters (converse direction of the
classification). -/
theorem transporters_exist_both {e f : Long} (he : FutureUnit e) (hf : FutureUnit f) :
    (IsLorentz (transport he.2 hf.2) ∧ PreservesFuture (transport he.2 hf.2) ∧
        transport he.2 hf.2 e = f ∧ detL (transport he.2 hf.2) = 1) ∧
      (IsLorentz (transportFlip he.2 hf.2) ∧ PreservesFuture (transportFlip he.2 hf.2) ∧
        transportFlip he.2 hf.2 e = f ∧ detL (transportFlip he.2 hf.2) = -1) :=
  ⟨⟨transport_isLorentz _ _, transport_preservesFuture he hf, transport_unit _ _,
      transport_detL _ _⟩,
    ⟨transportFlip_isLorentz _ _, transportFlip_preservesFuture he hf, transportFlip_unit _ _,
      transportFlip_detL _ _⟩⟩

/-! ## The stabilizer of one normalized future unit -/

/-- The reflection of the carrier fixing `e`. -/
def reflectAt {e : Long} (he : Q2 e = 1) : Long ≃ₗ[ℝ] Long := transportFlip he he

theorem transport_self {e : Long} (he : Q2 e = 1) (X : Long) : transport he he X = X := by
  simp only [Q2] at he
  apply Prod.ext <;> simp only [transport_apply]
  · linear_combination X.1 * he
  · linear_combination X.2 * he

@[simp] theorem reflectAt_apply {e : Long} (he : Q2 e = 1) (X : Long) :
    reflectAt he X =
      ((e.1 * e.1 + e.2 * e.2) * X.1 - (e.1 * e.2 + e.2 * e.1) * X.2,
        (e.1 * e.2 + e.2 * e.1) * X.1 - (e.1 * e.1 + e.2 * e.2) * X.2) := rfl

theorem reflectAt_isLorentz {e : Long} (he : Q2 e = 1) : IsLorentz (reflectAt he) :=
  transportFlip_isLorentz he he

theorem reflectAt_preservesFuture {e : Long} (he : FutureUnit e) :
    PreservesFuture (reflectAt he.2) := transportFlip_preservesFuture he he

theorem reflectAt_unit {e : Long} (he : Q2 e = 1) : reflectAt he e = e :=
  transportFlip_unit he he

theorem reflectAt_detL {e : Long} (he : Q2 e = 1) : detL (reflectAt he) = -1 :=
  transportFlip_detL he he

/-- The reflection is not the identity. -/
theorem reflectAt_ne_id {e : Long} (he : Q2 e = 1) : ∃ X : Long, reflectAt he X ≠ X := by
  by_contra hcon
  push_neg at hcon
  have h1 : detL (reflectAt he) = detL (LinearEquiv.refl ℝ Long) := by
    simp only [detL, hcon, LinearEquiv.refl_apply]
  rw [reflectAt_detL] at h1
  norm_num [detL, u₀, s₀] at h1

/-- **PROVED EXACTLY TWO (§10).**  The stabilizer of a normalized future unit inside the
future-preserving Lorentz maps consists exactly of the identity and the reflection
`reflectAt`. -/
theorem stabilizer_classification {e : Long} (he : FutureUnit e)
    {T : Long ≃ₗ[ℝ] Long} (hT : IsLorentz T) (hfut : PreservesFuture T) (hTe : T e = e) :
    (∀ X, T X = X) ∨ (∀ X, T X = reflectAt he.2 X) := by
  rcases transporter_classification he he hT hfut hTe with h | h
  · left; intro X; rw [h X, transport_self]
  · right; exact h

/-- The stabilizer really has these two elements. -/
theorem stabilizer_elements {e : Long} (he : FutureUnit e) :
    (IsLorentz (LinearEquiv.refl ℝ Long) ∧ PreservesFuture (LinearEquiv.refl ℝ Long) ∧
        (LinearEquiv.refl ℝ Long) e = e) ∧
      (IsLorentz (reflectAt he.2) ∧ PreservesFuture (reflectAt he.2) ∧ reflectAt he.2 e = e) ∧
      (∃ X : Long, reflectAt he.2 X ≠ X) := by
  refine ⟨⟨isLorentz_refl, ?_, rfl⟩, ⟨reflectAt_isLorentz he.2, reflectAt_preservesFuture he,
      reflectAt_unit he.2⟩, reflectAt_ne_id he.2⟩
  intro X hX; exact hX

/-- **The proper stabilizer is trivial.** -/
theorem proper_stabilizer_trivial {e : Long} (he : FutureUnit e)
    {T : Long ≃ₗ[ℝ] Long} (hT : IsLorentz T) (hfut : PreservesFuture T) (hp : IsProper T)
    (hTe : T e = e) : ∀ X, T X = X := by
  intro X
  rw [proper_transporter_unique he he hT hfut hp hTe X, transport_self]


/-! ## Layer 3: the reconstructed product family and its covariance

The Task-02 reconstruction theorem `generalUnit_existsUnique` says that for a
normalized unit `e` there is exactly one admissible bilinear product with unit `e`.
`mu e` *is* that product; every statement below uses only the Task-02 output
`recAt_eq`, i.e. the coordinate-free formula
`mu e X Y = L2 X e • Y + L2 Y e • X - L2 X Y • e`, together with the derived
`L2`-preservation of Lorentz maps.  No coordinate multiplication is expanded. -/

/-- The unique reconstructed product attached to a normalized unit `e`
(Task-02 `generalUnit_existsUnique`). -/
noncomputable def mu (e : Long) : BiProd := recAt e

/-- `mu e` is admissible at `e` whenever `e` is normalized. -/
theorem mu_admissible {e : Long} (hQ : Q2 e = 1) : AdmissibleAt e (mu e) := recAt_admissible hQ

/-- `mu e` is *the* admissible product at `e` (Task-02 uniqueness). -/
theorem mu_unique {e : Long} {nu : BiProd} (h : AdmissibleAt e nu) : nu = mu e := eq_recAt h

/-- Existence and uniqueness restated for the family. -/
theorem mu_existsUnique {e : Long} (hQ : Q2 e = 1) : ∃! nu : BiProd, AdmissibleAt e nu :=
  generalUnit_existsUnique hQ

/-- The only formula about `mu` used below. -/
theorem mu_eq (e X Y : Long) : mu e X Y = (L2 X e) • Y + (L2 Y e) • X - (L2 X Y) • e :=
  recAt_eq e X Y

/-- **PROVED (§6).  Central covariance theorem.**  Every Lorentz map intertwines the
reconstructed products of `e` and of `T e`.  The proof uses only linearity of `T`,
the Task-02 formula for `mu`, and the derived preservation of `L2`. -/
theorem mu_covariant {T : Long ≃ₗ[ℝ] Long} (h : IsLorentz T) (e X Y : Long) :
    T (mu e X Y) = mu (T e) (T X) (T Y) := by
  simp only [mu_eq, map_sub, map_add, map_smul, L2_of_isLorentz h]

/-! ### Multiplicative transport -/

/-- Minimal package: a bilinear product together with a distinguished unit vector. -/
structure UnitalProd where
  /-- the bilinear product -/
  prod : BiProd
  /-- the distinguished unit -/
  unit : Long

/-- The reconstructed unital algebra attached to a normalized unit. -/
noncomputable def alg (e : Long) : UnitalProd := ⟨mu e, e⟩

@[simp] theorem alg_prod (e : Long) : (alg e).prod = mu e := rfl
@[simp] theorem alg_unit (e : Long) : (alg e).unit = e := rfl

/-- `T` is an isomorphism of unital products: it matches the units and intertwines the
multiplications. -/
def IsUnitalIso (T : Long ≃ₗ[ℝ] Long) (A C : UnitalProd) : Prop :=
  T A.unit = C.unit ∧ ∀ X Y, T (A.prod X Y) = C.prod (T X) (T Y)

/-- **PROVED (§7).**  Every Lorentz map is an isomorphism of unital products from the
algebra at `e` to the algebra at `T e`. -/
theorem lorentz_isUnitalIso {T : Long ≃ₗ[ℝ] Long} (h : IsLorentz T) (e : Long) :
    IsUnitalIso T (alg e) (alg (T e)) := ⟨rfl, fun X Y => mu_covariant h e X Y⟩

/-- **PROVED (§15).  Product-family orbit theorem.**  Any two reconstructed products
attached to normalized future units are related by an orientation-preserving,
future-preserving Lorentz transport. -/
theorem product_orbit {e f : Long} (he : FutureUnit e) (hf : FutureUnit f) :
    ∃ T : Long ≃ₗ[ℝ] Long,
      IsLorentz T ∧ PreservesFuture T ∧ IsProper T ∧ IsUnitalIso T (alg e) (alg f) := by
  refine ⟨transport he.2 hf.2, transport_isLorentz _ _, transport_preservesFuture he hf,
    transport_detL _ _, ?_⟩
  constructor
  · exact transport_unit _ _
  · intro X Y
    have := mu_covariant (transport_isLorentz he.2 hf.2) e X Y
    simpa [transport_unit he.2 hf.2] using this

/-! ### Fixed-product invariance versus family covariance (§16) -/

/-- Invariance of *one* fibre of the family. -/
def FixedInvariant (T : Long ≃ₗ[ℝ] Long) (e : Long) : Prop :=
  ∀ X Y, T (mu e X Y) = mu e (T X) (T Y)

/-- **PROVED (§16).**  For a Lorentz map, invariance of the single product `mu e` holds
**exactly** when the unit is fixed.  Family covariance, by contrast, holds always. -/
theorem fixedInvariant_iff {T : Long ≃ₗ[ℝ] Long} (h : IsLorentz T) {e : Long} (hQ : Q2 e = 1) :
    FixedInvariant T e ↔ T e = e := by
  constructor
  · intro hinv
    have hmu : ∀ X Y : Long, mu (T e) X Y = mu e X Y := by
      intro X Y
      have h1 := hinv (T.symm X) (T.symm Y)
      rw [mu_covariant h] at h1
      rw [T.apply_symm_apply, T.apply_symm_apply] at h1
      exact h1
    have hadm : AdmissibleAt (T e) (mu (T e)) := mu_admissible (isLorentz_Q2_unit h hQ)
    have h2 : TwoSidedUnit (mu e) (T e) := by
      constructor
      · intro X; rw [← hmu]; exact hadm.1.1 X
      · intro X; rw [← hmu]; exact hadm.1.2 X
    exact twoSidedUnit_unique h2 (mu_admissible hQ).1
  · intro hTe X Y
    have := mu_covariant h e X Y
    rwa [hTe] at this

/-- **PROVED (negative control).**  A *fixed* reconstructed product is not invariant
under all future-preserving Lorentz maps. -/
theorem fixed_product_not_invariant :
    ∃ (e : Long) (T : Long ≃ₗ[ℝ] Long),
      FutureUnit e ∧ IsLorentz T ∧ PreservesFuture T ∧ ¬ FixedInvariant T e := by
  refine ⟨u₀, transport futureUnit_u₀.2 futureUnit_other.2, futureUnit_u₀,
    transport_isLorentz _ _, transport_preservesFuture futureUnit_u₀ futureUnit_other, ?_⟩
  intro hcon
  have h1 := (fixedInvariant_iff (transport_isLorentz futureUnit_u₀.2 futureUnit_other.2)
    futureUnit_u₀.2).mp hcon
  rw [transport_unit] at h1
  have : ((5 : ℝ) / 4) = (u₀.1 : ℝ) := congrArg Prod.fst h1
  norm_num [u₀] at this

/-- **PROVED (§10).**  Every element of the Lorentz stabilizer of `e` is an automorphism
of the reconstructed algebra at `e`. -/
theorem stabilizer_isAutomorphism {T : Long ≃ₗ[ℝ] Long} (h : IsLorentz T) {e : Long}
    (hTe : T e = e) : IsUnitalIso T (alg e) (alg e) := by
  refine ⟨hTe, fun X Y => ?_⟩
  have := mu_covariant h e X Y
  rwa [hTe] at this

/-! ## Layer 4: spacelike companions and the complementary null pair -/

/-- A normalized spacelike vector orthogonal to `e`. -/
def IsCompanion (e s : Long) : Prop := L2 e s = 0 ∧ Q2 s = -1

theorem companion_compl {e : Long} (hQ : Q2 e = 1) : IsCompanion e (NullSectorTask02.compl e) :=
  ⟨L2_compl e, by rw [Q2_compl, hQ]⟩

theorem companion_neg {e s : Long} (h : IsCompanion e s) : IsCompanion e (-s) := by
  refine ⟨?_, ?_⟩
  · have := h.1; simp at this ⊢; linarith
  · have := h.2; simpa [Q2] using this

/-- **PROVED EXACTLY TWO (§11).**  The normalized spacelike companions of a normalized
`e` are exactly `± compl e`; no spatial orientation is used in the classification. -/
theorem companion_classification {e s : Long} (hQ : Q2 e = 1) :
    IsCompanion e s ↔ (s = NullSectorTask02.compl e ∨ s = -NullSectorTask02.compl e) := by
  have hQ' : e.1 ^ 2 - e.2 ^ 2 = 1 := by simpa [Q2] using hQ
  have he1 : e.1 ≠ 0 := by
    intro h0
    rw [h0] at hQ'
    nlinarith [sq_nonneg e.2]
  constructor
  · rintro ⟨hL, hs⟩
    have hL' : e.1 * s.1 - e.2 * s.2 = 0 := by simpa using hL
    have hs' : s.1 ^ 2 - s.2 ^ 2 = -1 := by simpa [Q2] using hs
    have he2 : e.1 ^ 2 = 1 + e.2 ^ 2 := by linarith
    have hs2' : s.2 ^ 2 = 1 + s.1 ^ 2 := by linarith
    have hprod : e.1 * s.1 = e.2 * s.2 := by linarith
    have hsq : e.1 ^ 2 * s.1 ^ 2 = e.2 ^ 2 * s.2 ^ 2 := by
      linear_combination (e.1 * s.1 + e.2 * s.2) * hprod
    have hs1 : s.1 ^ 2 = e.2 ^ 2 := by
      linear_combination hsq - s.1 ^ 2 * he2 + e.2 ^ 2 * hs2'
    have hs2 : s.2 ^ 2 = e.1 ^ 2 := by linear_combination hs2' + hs1 - he2
    rcases mul_eq_zero.mp (show (s.2 - e.1) * (s.2 + e.1) = 0 by linear_combination hs2)
      with h1 | h1
    · left
      have hse : s.2 = e.1 := by linarith
      have h5 : e.1 * s.1 = e.1 * e.2 := by rw [hse] at hL'; linarith
      have hs1' : s.1 = e.2 := mul_left_cancel₀ he1 h5
      apply Prod.ext <;> simp [NullSectorTask02.compl, hs1', hse]
    · right
      have hse : s.2 = -e.1 := by linarith
      have h5 : e.1 * s.1 = e.1 * (-e.2) := by rw [hse] at hL'; linarith
      have hs1' : s.1 = -e.2 := mul_left_cancel₀ he1 h5
      apply Prod.ext <;> simp [NullSectorTask02.compl, hs1', hse]
  · rintro (rfl | rfl)
    · exact companion_compl hQ
    · exact companion_neg (companion_compl hQ)

/-- The two companions are distinct. -/
theorem compl_ne_neg_compl {e : Long} (hQ : Q2 e = 1) : NullSectorTask02.compl e ≠ -NullSectorTask02.compl e := by
  have hQ' : e.1 ^ 2 - e.2 ^ 2 = 1 := by simpa [Q2] using hQ
  intro hcon
  have h2 : e.1 = -e.1 := congrArg Prod.snd hcon
  have : e.1 = 0 := by linarith
  rw [this] at hQ'
  nlinarith [sq_nonneg e.2]

/-- **PROVED UNIQUE with an orientation datum (§13, data set D).**  Exactly one companion
has positive second coordinate. -/
theorem companion_unique_oriented {e : Long} (he : FutureUnit e) :
    ∃! s : Long, IsCompanion e s ∧ 0 < s.2 := by
  refine ⟨NullSectorTask02.compl e, ⟨companion_compl he.2, by simpa [NullSectorTask02.compl] using he.1⟩, ?_⟩
  rintro s ⟨hs, hpos⟩
  rcases (companion_classification he.2).mp hs with rfl | rfl
  · rfl
  · exfalso
    simp [NullSectorTask02.compl] at hpos
    linarith [he.1]

/-! ### The complementary null pair -/

/-- The `+` component attached to an admissible pair `(e,s)`. -/
noncomputable def nullPlus (e s : Long) : Long := (1 / 2 : ℝ) • (e + s)

/-- The `-` component attached to an admissible pair `(e,s)`. -/
noncomputable def nullMinus (e s : Long) : Long := (1 / 2 : ℝ) • (e - s)

@[simp] theorem nullPlus_coord (e s : Long) :
    nullPlus e s = ((e.1 + s.1) / 2, (e.2 + s.2) / 2) := by
  apply Prod.ext <;> simp [nullPlus] <;> ring

@[simp] theorem nullMinus_coord (e s : Long) :
    nullMinus e s = ((e.1 - s.1) / 2, (e.2 - s.2) / 2) := by
  apply Prod.ext <;> simp [nullMinus] <;> ring

theorem nullPlus_add_nullMinus (e s : Long) : nullPlus e s + nullMinus e s = e := by
  apply Prod.ext <;> simp <;> ring

theorem nullPlus_sub_nullMinus (e s : Long) : nullPlus e s - nullMinus e s = s := by
  apply Prod.ext <;> simp <;> ring

/-- **Derived, no Task-01 input.**  Both components are null. -/
theorem Q2_nullPlus {e s : Long} (hQ : Q2 e = 1) (hs : IsCompanion e s) :
    Q2 (nullPlus e s) = 0 := by
  have hQ' : e.1 ^ 2 - e.2 ^ 2 = 1 := by simpa [Q2] using hQ
  have hL : e.1 * s.1 - e.2 * s.2 = 0 := by simpa using hs.1
  have hs' : s.1 ^ 2 - s.2 ^ 2 = -1 := by simpa [Q2] using hs.2
  simp only [nullPlus_coord, Q2]
  linear_combination (1 / 4) * hQ' + (1 / 2) * hL + (1 / 4) * hs'

theorem Q2_nullMinus {e s : Long} (hQ : Q2 e = 1) (hs : IsCompanion e s) :
    Q2 (nullMinus e s) = 0 := by
  have hQ' : e.1 ^ 2 - e.2 ^ 2 = 1 := by simpa [Q2] using hQ
  have hL : e.1 * s.1 - e.2 * s.2 = 0 := by simpa using hs.1
  have hs' : s.1 ^ 2 - s.2 ^ 2 = -1 := by simpa [Q2] using hs.2
  simp only [nullMinus_coord, Q2]
  linear_combination (1 / 4) * hQ' - (1 / 2) * hL + (1 / 4) * hs'

theorem L2_nullPlus_unit {e s : Long} (hQ : Q2 e = 1) (hs : IsCompanion e s) :
    L2 (nullPlus e s) e = 1 / 2 := by
  have hQ' : e.1 ^ 2 - e.2 ^ 2 = 1 := by simpa [Q2] using hQ
  have hL : e.1 * s.1 - e.2 * s.2 = 0 := by simpa using hs.1
  simp only [nullPlus_coord, L2_coord]
  linear_combination (1 / 2) * hQ' + (1 / 2) * hL

theorem L2_nullMinus_unit {e s : Long} (hQ : Q2 e = 1) (hs : IsCompanion e s) :
    L2 (nullMinus e s) e = 1 / 2 := by
  have hQ' : e.1 ^ 2 - e.2 ^ 2 = 1 := by simpa [Q2] using hQ
  have hL : e.1 * s.1 - e.2 * s.2 = 0 := by simpa using hs.1
  simp only [nullMinus_coord, L2_coord]
  linear_combination (1 / 2) * hQ' - (1 / 2) * hL

theorem L2_nullPlus_nullMinus {e s : Long} (hQ : Q2 e = 1) (hs : IsCompanion e s) :
    L2 (nullPlus e s) (nullMinus e s) = 1 / 2 := by
  have hQ' : e.1 ^ 2 - e.2 ^ 2 = 1 := by simpa [Q2] using hQ
  have hs' : s.1 ^ 2 - s.2 ^ 2 = -1 := by simpa [Q2] using hs.2
  simp only [nullPlus_coord, nullMinus_coord, L2_coord]
  linear_combination (1 / 4) * hQ' - (1 / 4) * hs'

/-- **Derived (§12).**  `nullPlus` is idempotent for the reconstructed product `mu e`. -/
theorem mu_nullPlus_nullPlus {e s : Long} (hQ : Q2 e = 1) (hs : IsCompanion e s) :
    mu e (nullPlus e s) (nullPlus e s) = nullPlus e s := by
  have h1 : L2 (nullPlus e s) e = 1 / 2 := L2_nullPlus_unit hQ hs
  have h2 : L2 (nullPlus e s) (nullPlus e s) = 0 := by
    rw [L2_self]; exact Q2_nullPlus hQ hs
  rw [mu_eq, h1, h2]
  module

theorem mu_nullMinus_nullMinus {e s : Long} (hQ : Q2 e = 1) (hs : IsCompanion e s) :
    mu e (nullMinus e s) (nullMinus e s) = nullMinus e s := by
  have h1 : L2 (nullMinus e s) e = 1 / 2 := L2_nullMinus_unit hQ hs
  have h2 : L2 (nullMinus e s) (nullMinus e s) = 0 := by
    rw [L2_self]; exact Q2_nullMinus hQ hs
  rw [mu_eq, h1, h2]
  module

/-- **Derived (§12).**  The two components annihilate each other. -/
theorem mu_nullPlus_nullMinus {e s : Long} (hQ : Q2 e = 1) (hs : IsCompanion e s) :
    mu e (nullPlus e s) (nullMinus e s) = 0 := by
  have h1 : L2 (nullPlus e s) e = 1 / 2 := L2_nullPlus_unit hQ hs
  have h2 : L2 (nullMinus e s) e = 1 / 2 := L2_nullMinus_unit hQ hs
  have h3 : L2 (nullPlus e s) (nullMinus e s) = 1 / 2 := L2_nullPlus_nullMinus hQ hs
  rw [mu_eq, h1, h2, h3]
  apply Prod.ext <;> simp [nullPlus, nullMinus] <;> ring

/-- **The sign flip exchanges the two components (§12).** -/
theorem nullPlus_neg (e s : Long) : nullPlus e (-s) = nullMinus e s := by
  apply Prod.ext <;> simp <;> ring

theorem nullMinus_neg (e s : Long) : nullMinus e (-s) = nullPlus e s := by
  apply Prod.ext <;> simp

/-- The two components are distinct. -/
theorem nullPlus_ne_nullMinus {e s : Long} (hs : IsCompanion e s) :
    nullPlus e s ≠ nullMinus e s := by
  intro hcon
  have h0 : s = 0 := by
    rw [← nullPlus_sub_nullMinus e s, hcon, sub_self]
  have := hs.2
  rw [h0] at this
  simp [Q2] at this

/-! ### Ordered versus unordered (§13) -/

/-- **PROVED (§13).**  Once `e` is fixed, the *unordered* complementary pair is
determined: any two companions give the same pair, possibly with the labels swapped. -/
theorem nullPair_unordered {e s s' : Long} (hQ : Q2 e = 1) (hs : IsCompanion e s)
    (hs' : IsCompanion e s') :
    (nullPlus e s' = nullPlus e s ∧ nullMinus e s' = nullMinus e s) ∨
      (nullPlus e s' = nullMinus e s ∧ nullMinus e s' = nullPlus e s) := by
  rcases (companion_classification hQ).mp hs with rfl | rfl <;>
    rcases (companion_classification hQ).mp hs' with rfl | rfl
  · exact Or.inl ⟨rfl, rfl⟩
  · exact Or.inr ⟨nullPlus_neg _ _, nullMinus_neg _ _⟩
  · exact Or.inr ⟨(nullMinus_neg e _).symm, (nullPlus_neg e _).symm⟩
  · exact Or.inl ⟨rfl, rfl⟩

/-- **PROVED NON-UNIQUE (§13).**  The *ordered* pair is not determined by `(Q2, future
component, e)`: the companion `-s` gives the swapped ordered pair. -/
theorem nullPair_ordered_not_determined {e s : Long} (hs : IsCompanion e s) :
    IsCompanion e (-s) ∧ nullPlus e (-s) ≠ nullPlus e s :=
  ⟨companion_neg hs, by rw [nullPlus_neg]; exact fun h => nullPlus_ne_nullMinus hs h.symm⟩

/-! ### Transport of the null pair (§14) -/

/-- Linearity alone transports the components. -/
theorem map_nullPlus (T : Long ≃ₗ[ℝ] Long) (e s : Long) :
    T (nullPlus e s) = nullPlus (T e) (T s) := by
  simp only [nullPlus, map_smul, map_add]

theorem map_nullMinus (T : Long ≃ₗ[ℝ] Long) (e s : Long) :
    T (nullMinus e s) = nullMinus (T e) (T s) := by
  simp only [nullMinus, map_smul, map_sub]

/-- A Lorentz map carries companions of `e` to companions of `T e`. -/
theorem companion_map {T : Long ≃ₗ[ℝ] Long} (h : IsLorentz T) {e s : Long}
    (hs : IsCompanion e s) : IsCompanion (T e) (T s) :=
  ⟨by rw [L2_of_isLorentz h]; exact hs.1, by rw [h s]; exact hs.2⟩

/-- **Orientation-preserving transport preserves the labels.** -/
theorem proper_transport_compl {e f : Long} (he : FutureUnit e) (hf : FutureUnit f)
    {T : Long ≃ₗ[ℝ] Long} (hT : IsLorentz T) (hfut : PreservesFuture T) (hp : IsProper T)
    (hTe : T e = f) : T (NullSectorTask02.compl e) = NullSectorTask02.compl f := by
  have hform := proper_transporter_unique he hf hT hfut hp hTe (NullSectorTask02.compl e)
  have hQ' : e.1 ^ 2 - e.2 ^ 2 = 1 := by simpa [Q2] using he.2
  rw [hform]
  apply Prod.ext <;> simp only [transport_apply, compl_fst, compl_snd]
  · linear_combination f.2 * hQ'
  · linear_combination f.1 * hQ'

/-- **Orientation-reversing transport exchanges the labels.** -/
theorem improper_transport_compl {e f : Long} (he : FutureUnit e) (hf : FutureUnit f)
    {T : Long ≃ₗ[ℝ] Long} (hT : IsLorentz T) (hfut : PreservesFuture T) (hp : detL T = -1)
    (hTe : T e = f) : T (NullSectorTask02.compl e) = -NullSectorTask02.compl f := by
  have hQ' : e.1 ^ 2 - e.2 ^ 2 = 1 := by simpa [Q2] using he.2
  rcases transporter_classification he hf hT hfut hTe with h | h
  · exfalso
    have : detL T = 1 := by
      simp only [detL, h]
      have := transport_detL he.2 hf.2
      simpa [detL] using this
    rw [hp] at this
    norm_num at this
  · rw [h (NullSectorTask02.compl e)]
    apply Prod.ext <;>
      simp only [transportFlip_apply, compl_fst, compl_snd, Prod.fst_neg, Prod.snd_neg]
    · linear_combination (-f.2) * hQ'
    · linear_combination (-f.1) * hQ'

/-- **PROVED (§14).**  Orientation-preserving transport preserves the ordered pair. -/
theorem proper_transport_nullPair {e f : Long} (he : FutureUnit e) (hf : FutureUnit f)
    {T : Long ≃ₗ[ℝ] Long} (hT : IsLorentz T) (hfut : PreservesFuture T) (hp : IsProper T)
    (hTe : T e = f) :
    T (nullPlus e (NullSectorTask02.compl e)) = nullPlus f (NullSectorTask02.compl f) ∧
      T (nullMinus e (NullSectorTask02.compl e)) = nullMinus f (NullSectorTask02.compl f) := by
  constructor
  · rw [map_nullPlus, hTe, proper_transport_compl he hf hT hfut hp hTe]
  · rw [map_nullMinus, hTe, proper_transport_compl he hf hT hfut hp hTe]

/-- **PROVED (§14).**  Orientation-reversing transport exchanges the ordered pair. -/
theorem improper_transport_nullPair {e f : Long} (he : FutureUnit e) (hf : FutureUnit f)
    {T : Long ≃ₗ[ℝ] Long} (hT : IsLorentz T) (hfut : PreservesFuture T) (hp : detL T = -1)
    (hTe : T e = f) :
    T (nullPlus e (NullSectorTask02.compl e)) = nullMinus f (NullSectorTask02.compl f) ∧
      T (nullMinus e (NullSectorTask02.compl e)) = nullPlus f (NullSectorTask02.compl f) := by
  constructor
  · rw [map_nullPlus, hTe, improper_transport_compl he hf hT hfut hp hTe, nullPlus_neg]
  · rw [map_nullMinus, hTe, improper_transport_compl he hf hT hfut hp hTe, nullMinus_neg]

/-- **PROVED (§17).**  The residual discrete freedom is exactly the exchange of the two
null components: the unique nontrivial element of the stabilizer of `e` swaps them. -/
theorem reflectAt_swaps_nullPair {e : Long} (he : FutureUnit e) :
    reflectAt he.2 (nullPlus e (NullSectorTask02.compl e)) = nullMinus e (NullSectorTask02.compl e) ∧
      reflectAt he.2 (nullMinus e (NullSectorTask02.compl e)) = nullPlus e (NullSectorTask02.compl e) :=
  improper_transport_nullPair he he (reflectAt_isLorentz he.2) (reflectAt_preservesFuture he)
    (reflectAt_detL he.2) (reflectAt_unit he.2)

/-- **Negative control for data sets A and B (§13).**  There is a future-preserving
Lorentz map exchanging the two future null rays, so no ordering of the two null
directions is intrinsic to `(Long, Q2, future component)`. -/
theorem null_rays_exchanged :
    ∃ T : Long ≃ₗ[ℝ] Long, IsLorentz T ∧ PreservesFuture T ∧
      T ((1 : ℝ), (1 : ℝ)) = ((1 : ℝ), (-1 : ℝ)) ∧ T ((1 : ℝ), (-1 : ℝ)) = ((1 : ℝ), (1 : ℝ)) := by
  refine ⟨hypFlip 1 0 (by norm_num), hypFlip_isLorentz _ _ _,
    hypFlip_preservesFuture _ _ _ (by norm_num), ?_, ?_⟩ <;>
    · apply Prod.ext <;> simp

end NullSectorTask03
