import RequestProject.NullSectorTask03.Core
import RequestProject.NullSectorTask01.Boost

/-!
# Task 03: principal theorems

This module has two parts.

* The **late comparison layer** (§18, §19 of the task).  This is the only Task-03
  module that imports the Task-01 boost and split-complex declarations; everything
  in `Core.lean` was proved before this module exists and does not depend on it, so
  the mandated import firewall is respected.  The Task-01 objects are comparison
  targets only.
* The **principal theorems**, one group per acceptance criterion, restating results
  of `Core.lean` and of the comparison layer below.

(The comparison layer and the principal theorems share one module because every
module of this project imports the whole of Mathlib, which dominates compilation
time.)

The axiom report is produced by the `#print axioms` commands at the end.
-/

namespace NullSectorTask03

open NullSectorTask01 NullSectorTask02 Real



/-! ## The Task-01 boost as a Task-03 Lorentz map -/

/-- The Task-01 boost, packaged as a linear equivalence through the Task-03 family
`hypRot`.  The defining identity `cosh² - sinh² = 1` is the standard Mathlib fact
`Real.cosh_sq_sub_sinh_sq`. -/
noncomputable def boostEquiv (eta : ℝ) : Long ≃ₗ[ℝ] Long :=
  hypRot (Real.cosh eta) (Real.sinh eta) (Real.cosh_sq_sub_sinh_sq eta)

@[simp] theorem boostEquiv_apply (eta : ℝ) (X : Long) :
    boostEquiv eta X =
      (Real.cosh eta * X.1 + Real.sinh eta * X.2, Real.sinh eta * X.1 + Real.cosh eta * X.2) :=
  rfl

/-- **Comparison 1a.**  The packaged map is exactly the Task-01 boost `B`. -/
theorem boostEquiv_eq_B (eta : ℝ) (X : Long) : boostEquiv eta X = B eta X := by
  obtain ⟨t, x⟩ := X
  rfl

/-- **Comparison 1b.**  The Task-01 boost is a Lorentz map in the Task-03 sense. -/
theorem boost_isLorentz (eta : ℝ) : IsLorentz (boostEquiv eta) := hypRot_isLorentz _ _ _

theorem boost_preservesFuture (eta : ℝ) : PreservesFuture (boostEquiv eta) :=
  hypRot_preservesFuture _ _ _ (Real.cosh_pos eta)

theorem boost_isProper (eta : ℝ) : IsProper (boostEquiv eta) := hypRot_detL _ _ _

/-- **Comparison 2.**  The boost preserves normalized future units. -/
theorem boost_futureUnit (eta : ℝ) {e : Long} (he : FutureUnit e) :
    FutureUnit (boostEquiv eta e) :=
  futureUnit_map (boost_isLorentz eta) (boost_preservesFuture eta) he

/-! ## Comparison of the transport laws -/

theorem boost_u₀ (eta : ℝ) : boostEquiv eta u₀ = (Real.cosh eta, Real.sinh eta) := by
  apply Prod.ext <;> simp [u₀]

/-- **Comparison 3 / 6.**  The Task-01 boost *is* the independently constructed
Task-03 transporter from `u₀` to `B η u₀`.  Nothing about boosts was used to build
the transporter. -/
theorem transport_u₀_eq_boost (eta : ℝ) (X : Long) :
    transport Q2_u₀ (isLorentz_Q2_unit (boost_isLorentz eta) Q2_u₀) X = boostEquiv eta X := by
  apply Prod.ext <;> simp [u₀]

/-- The same statement in Task-01 notation. -/
theorem transport_u₀_eq_B (eta : ℝ) (X : Long) :
    transport Q2_u₀ (isLorentz_Q2_unit (boost_isLorentz eta) Q2_u₀) X = B eta X := by
  rw [transport_u₀_eq_boost, boostEquiv_eq_B]

/-- **Comparison 4.**  The central covariance relation holds for the Task-01 boost. -/
theorem boost_covariance (eta : ℝ) (e X Y : Long) :
    boostEquiv eta (mu e X Y) = mu (boostEquiv eta e) (boostEquiv eta X) (boostEquiv eta Y) :=
  mu_covariant (boost_isLorentz eta) e X Y

/-- The same relation written with the Task-01 boost `B`. -/
theorem B_covariance (eta : ℝ) (e X Y : Long) :
    B eta (mu e X Y) = mu (B eta e) (B eta X) (B eta Y) := by
  have h := boost_covariance eta e X Y
  simpa only [boostEquiv_eq_B] using h

/-- **Comparison 5.**  Specialization to the Task-01 reference unit. -/
theorem boost_covariance_u₀ (eta : ℝ) (X Y : Long) :
    boostEquiv eta (mu u₀ X Y) =
      mu (boostEquiv eta u₀) (boostEquiv eta X) (boostEquiv eta Y) :=
  boost_covariance eta u₀ X Y

/-- **Comparison 6.**  Multiplicative transport from the algebra at `u₀` to the algebra
at `B η u₀`, realized by the Task-01 boost. -/
theorem boost_isUnitalIso (eta : ℝ) :
    IsUnitalIso (boostEquiv eta) (alg u₀) (alg (boostEquiv eta u₀)) :=
  lorentz_isUnitalIso (boost_isLorentz eta) u₀

/-- The fixed product `mu u₀` is invariant under the boost **iff** the boost fixes `u₀`,
which happens exactly for `η = 0`. -/
theorem boost_fixedInvariant_iff (eta : ℝ) :
    FixedInvariant (boostEquiv eta) u₀ ↔ boostEquiv eta u₀ = u₀ :=
  fixedInvariant_iff (boost_isLorentz eta) Q2_u₀

/-! ## Comparison of the null pairs -/

theorem compl_u₀ : compl u₀ = s₀ := rfl

/-- **Comparison 7.**  The independently reconstructed null components at the reference
unit are the Task-01 idempotents. -/
theorem nullPlus_u₀_eq_ep : nullPlus u₀ s₀ = ep := by
  rw [ep_eq]
  apply Prod.ext <;> simp [u₀, s₀]

theorem nullMinus_u₀_eq_em : nullMinus u₀ s₀ = NullSectorTask01.em := by
  rw [em_eq]
  apply Prod.ext <;> simp [u₀, s₀]
  norm_num

/-- **Comparison 8a.**  The boost is orientation-preserving, hence preserves the
`+`/`-` labels of the reconstructed null pair. -/
theorem boost_preserves_labels (eta : ℝ) :
    boostEquiv eta (nullPlus u₀ (compl u₀)) =
        nullPlus (boostEquiv eta u₀) (compl (boostEquiv eta u₀)) ∧
      boostEquiv eta (nullMinus u₀ (compl u₀)) =
        nullMinus (boostEquiv eta u₀) (compl (boostEquiv eta u₀)) :=
  proper_transport_nullPair futureUnit_u₀ (boost_futureUnit eta futureUnit_u₀)
    (boost_isLorentz eta) (boost_preservesFuture eta) (boost_isProper eta) rfl

/-- In Task-01 language the `+` component is only rescaled by `exp η`; in particular its
ray, hence its label, is preserved. -/
theorem boost_ep_scaling (eta : ℝ) : boostEquiv eta ep = Real.exp eta • ep := by
  rw [boostEquiv_eq_B]; exact B_ep eta

theorem boost_em_scaling (eta : ℝ) :
    boostEquiv eta (NullSectorTask01.em) = Real.exp (-eta) • NullSectorTask01.em := by
  rw [boostEquiv_eq_B]; exact B_em eta

/-- **Comparison 8b.**  The `+`/`-` labels are exchanged exactly by the
orientation-reversing element of the stabilizer of `u₀`. -/
theorem reflect_u₀_swaps_labels :
    reflectAt Q2_u₀ ep = NullSectorTask01.em ∧ reflectAt Q2_u₀ (NullSectorTask01.em) = ep := by
  have h := reflectAt_swaps_nullPair futureUnit_u₀
  rw [compl_u₀, nullPlus_u₀_eq_ep, nullMinus_u₀_eq_em] at h
  exact h

/-! ## §19 Rapidity parametrization (late, optional) -/

/-- Every normalized future unit is `(cosh η, sinh η)`; proved *after* the algebraic
transporter classification and never used by it. -/
theorem futureUnit_rapidity {e : Long} (he : FutureUnit e) :
    ∃ eta : ℝ, e = (Real.cosh eta, Real.sinh eta) := by
  refine ⟨Real.arsinh e.2, ?_⟩
  have hs : Real.sinh (Real.arsinh e.2) = e.2 := Real.sinh_arsinh e.2
  have hcs : Real.cosh (Real.arsinh e.2) ^ 2 - Real.sinh (Real.arsinh e.2) ^ 2 = 1 :=
    Real.cosh_sq_sub_sinh_sq _
  have hcpos : 0 < Real.cosh (Real.arsinh e.2) := Real.cosh_pos _
  have hQ : e.1 ^ 2 - e.2 ^ 2 = 1 := by simpa [Q2] using he.2
  have hfac : (Real.cosh (Real.arsinh e.2) - e.1) * (Real.cosh (Real.arsinh e.2) + e.1) = 0 := by
    rw [hs] at hcs; nlinarith [hcs, hQ]
  have hc : Real.cosh (Real.arsinh e.2) = e.1 := by
    rcases mul_eq_zero.mp hfac with h | h
    · linarith
    · exfalso; linarith [he.1]
  apply Prod.ext <;> simp [hc, hs]

/-- Every proper future-preserving Lorentz map is a boost of some real rapidity.  This
is a *late* cross-check: the transporter classification in the core was obtained
without any rapidity parameter. -/
theorem proper_future_lorentz_is_boost {T : Long ≃ₗ[ℝ] Long} (hT : IsLorentz T)
    (hfut : PreservesFuture T) (hp : IsProper T) : ∃ eta : ℝ, ∀ X, T X = boostEquiv eta X := by
  obtain ⟨a, c, hac, ha, hcase⟩ := futureLorentz_normal_form hT hfut
  rcases hcase with ⟨_, hform⟩ | ⟨hdet, _⟩
  · refine ⟨Real.arsinh c, ?_⟩
    have hs : Real.sinh (Real.arsinh c) = c := Real.sinh_arsinh c
    have hcs : Real.cosh (Real.arsinh c) ^ 2 - Real.sinh (Real.arsinh c) ^ 2 = 1 :=
      Real.cosh_sq_sub_sinh_sq _
    have hcpos : 0 < Real.cosh (Real.arsinh c) := Real.cosh_pos _
    have hfac : (Real.cosh (Real.arsinh c) - a) * (Real.cosh (Real.arsinh c) + a) = 0 := by
      rw [hs] at hcs; nlinarith [hcs, hac]
    have hc : Real.cosh (Real.arsinh c) = a := by
      rcases mul_eq_zero.mp hfac with h | h
      · linarith
      · exfalso; linarith
    intro X
    rw [hform X, boostEquiv_apply, hc, hs]
  · exfalso
    rw [hp] at hdet
    norm_num at hdet


/-! # Principal theorems -/

/-! ## 1. `Q2`-preservation implies `L2`-preservation (§4) -/

/-- **Acceptance criterion 1.  PROVED.** -/
theorem task03_polarization_preserved {T : Long ≃ₗ[ℝ] Long} (h : IsLorentz T) (X Y : Long) :
    L2 (T X) (T Y) = L2 X Y := L2_of_isLorentz h X Y

/-! ## 2. Action on normalized future units (§5) -/

/-- **Acceptance criterion 2.  PROVED.** -/
theorem task03_futureUnit_action {T : Long ≃ₗ[ℝ] Long} (h : IsLorentz T)
    (hfut : PreservesFuture T) {e : Long} (he : FutureUnit e) : FutureUnit (T e) :=
  futureUnit_map h hfut he

/-- **Negative control.**  Dropping the future condition the statement fails. -/
theorem task03_futureUnit_action_needs_future :
    ∃ T : Long ≃ₗ[ℝ] Long, IsLorentz T ∧ ∃ e : Long, FutureUnit e ∧ ¬ FutureUnit (T e) :=
  futureUnit_not_preserved_by_all_lorentz

/-! ## 3–4. Covariance of the reconstructed product family and its packaging (§6, §7) -/

/-- **Acceptance criterion 3.  PROVED.**  The transformation law of the reconstructed
family under an arbitrary Lorentz map. -/
theorem task03_covariance {T : Long ≃ₗ[ℝ] Long} (h : IsLorentz T) (e X Y : Long) :
    T (mu e X Y) = mu (T e) (T X) (T Y) := mu_covariant h e X Y

/-- **Acceptance criterion 4.  PROVED.**  Packaged as multiplicative transport of unital
products. -/
theorem task03_transport_of_algebras {T : Long ≃ₗ[ℝ] Long} (h : IsLorentz T) (e : Long) :
    IsUnitalIso T (alg e) (alg (T e)) := lorentz_isUnitalIso h e

/-! ## 5–6. Orbit of normalized future units (§8) -/

/-- **Acceptance criteria 5 and 6.  PROVED.**  The future-preserving, orientation-
preserving Lorentz maps act transitively on normalized future units, by an explicit
transporter built from `Q2`, `L2`, `e` and `f` only. -/
theorem task03_unit_orbit {e f : Long} (he : FutureUnit e) (hf : FutureUnit f) :
    ∃ T : Long ≃ₗ[ℝ] Long, IsLorentz T ∧ PreservesFuture T ∧ IsProper T ∧ T e = f :=
  futureUnit_orbit_transitive he hf

/-! ## 7–8. Transport uniqueness (§9) -/

/-- **Acceptance criterion 7.  PROVED EXACTLY TWO.**  Without an orientation condition a
transporter is one of exactly two maps. -/
theorem task03_transporters_two {e f : Long} (he : FutureUnit e) (hf : FutureUnit f)
    {T : Long ≃ₗ[ℝ] Long} (hT : IsLorentz T) (hfut : PreservesFuture T) (hTe : T e = f) :
    (∀ X, T X = transport he.2 hf.2 X) ∨ (∀ X, T X = transportFlip he.2 hf.2 X) :=
  transporter_classification he hf hT hfut hTe

/-- The two are distinct, so the count is exactly two. -/
theorem task03_transporters_distinct {e f : Long} (he : FutureUnit e) (hf : FutureUnit f) :
    ∃ X : Long, transport he.2 hf.2 X ≠ transportFlip he.2 hf.2 X :=
  transport_ne_transportFlip he.2 hf.2

/-- **Acceptance criterion 8.  PROVED UNIQUE.**  With the orientation condition the
transporter is unique. -/
theorem task03_proper_transporter_unique {e f : Long} (he : FutureUnit e) (hf : FutureUnit f)
    {T : Long ≃ₗ[ℝ] Long} (hT : IsLorentz T) (hfut : PreservesFuture T) (hp : IsProper T)
    (hTe : T e = f) : ∀ X, T X = transport he.2 hf.2 X :=
  proper_transporter_unique he hf hT hfut hp hTe

/-! ## 9–10. Stabilizer and algebra automorphisms (§10) -/

/-- **Acceptance criterion 9.  PROVED EXACTLY TWO.** -/
theorem task03_stabilizer {e : Long} (he : FutureUnit e) {T : Long ≃ₗ[ℝ] Long}
    (hT : IsLorentz T) (hfut : PreservesFuture T) (hTe : T e = e) :
    (∀ X, T X = X) ∨ (∀ X, T X = reflectAt he.2 X) :=
  stabilizer_classification he hT hfut hTe

/-- The nontrivial stabilizer element exists and is not the identity. -/
theorem task03_stabilizer_nontrivial {e : Long} (he : FutureUnit e) :
    IsLorentz (reflectAt he.2) ∧ PreservesFuture (reflectAt he.2) ∧ reflectAt he.2 e = e ∧
      ∃ X : Long, reflectAt he.2 X ≠ X :=
  ⟨reflectAt_isLorentz he.2, reflectAt_preservesFuture he, reflectAt_unit he.2,
    reflectAt_ne_id he.2⟩

/-- **Acceptance criterion 10.  PROVED.**  Every stabilizer element is an automorphism of
the reconstructed algebra at `e`. -/
theorem task03_stabilizer_automorphisms {T : Long ≃ₗ[ℝ] Long} (h : IsLorentz T) {e : Long}
    (hTe : T e = e) : IsUnitalIso T (alg e) (alg e) :=
  stabilizer_isAutomorphism h hTe

/-! ## 11–13. Companions and the complementary null pair (§11, §12) -/

/-- **Acceptance criterion 11.  PROVED EXACTLY TWO.** -/
theorem task03_companions {e s : Long} (hQ : Q2 e = 1) :
    IsCompanion e s ↔ (s = compl e ∨ s = -compl e) := companion_classification hQ

theorem task03_companions_distinct {e : Long} (hQ : Q2 e = 1) : compl e ≠ -compl e :=
  compl_ne_neg_compl hQ

/-- **Acceptance criterion 12.  PROVED.**  The complementary null idempotents are derived
from `(e,s)` with no Task-01 input. -/
theorem task03_null_idempotents {e s : Long} (hQ : Q2 e = 1) (hs : IsCompanion e s) :
    Q2 (nullPlus e s) = 0 ∧ Q2 (nullMinus e s) = 0 ∧
      mu e (nullPlus e s) (nullPlus e s) = nullPlus e s ∧
      mu e (nullMinus e s) (nullMinus e s) = nullMinus e s ∧
      mu e (nullPlus e s) (nullMinus e s) = 0 ∧
      nullPlus e s + nullMinus e s = e ∧ nullPlus e s - nullMinus e s = s :=
  ⟨Q2_nullPlus hQ hs, Q2_nullMinus hQ hs, mu_nullPlus_nullPlus hQ hs, mu_nullMinus_nullMinus hQ hs,
    mu_nullPlus_nullMinus hQ hs, nullPlus_add_nullMinus e s, nullPlus_sub_nullMinus e s⟩

/-- **Acceptance criterion 13.  PROVED.**  `s ↦ -s` exchanges the two components. -/
theorem task03_sign_flip (e s : Long) :
    nullPlus e (-s) = nullMinus e s ∧ nullMinus e (-s) = nullPlus e s :=
  ⟨nullPlus_neg e s, nullMinus_neg e s⟩

/-! ## 14–15. Ordered versus unordered null pair (§13) -/

/-- **Acceptance criteria 14 and 15.  PROVED (unordered) / PROVED NON-UNIQUE (ordered).**
Once `e` is chosen the unordered pair is determined; the ordered pair is not, and the
ambiguity is exactly the swap. -/
theorem task03_unordered_pair {e s s' : Long} (hQ : Q2 e = 1) (hs : IsCompanion e s)
    (hs' : IsCompanion e s') :
    (nullPlus e s' = nullPlus e s ∧ nullMinus e s' = nullMinus e s) ∨
      (nullPlus e s' = nullMinus e s ∧ nullMinus e s' = nullPlus e s) :=
  nullPair_unordered hQ hs hs'

theorem task03_ordered_pair_not_determined {e s : Long} (hs : IsCompanion e s) :
    IsCompanion e (-s) ∧ nullPlus e (-s) ≠ nullPlus e s :=
  nullPair_ordered_not_determined hs

/-- Data sets A and B: the two null directions themselves are exchanged by a
future-preserving Lorentz map, so no ordering is intrinsic before a unit and an
orientation are chosen. -/
theorem task03_null_rays_exchanged :
    ∃ T : Long ≃ₗ[ℝ] Long, IsLorentz T ∧ PreservesFuture T ∧
      T ((1 : ℝ), (1 : ℝ)) = ((1 : ℝ), (-1 : ℝ)) ∧ T ((1 : ℝ), (-1 : ℝ)) = ((1 : ℝ), (1 : ℝ)) :=
  null_rays_exchanged

/-- Data set D: a spatial-orientation datum selects one companion, hence the ordered
pair. -/
theorem task03_orientation_selects {e : Long} (he : FutureUnit e) :
    ∃! s : Long, IsCompanion e s ∧ 0 < s.2 := companion_unique_oriented he

/-! ## 16. Transport of the null pair (§14) -/

/-- **Acceptance criterion 16.  PROVED.** -/
theorem task03_null_pair_transport {e f : Long} (he : FutureUnit e) (hf : FutureUnit f)
    {T : Long ≃ₗ[ℝ] Long} (hT : IsLorentz T) (hfut : PreservesFuture T) (hTe : T e = f) :
    (IsProper T →
        T (nullPlus e (compl e)) = nullPlus f (compl f) ∧
          T (nullMinus e (compl e)) = nullMinus f (compl f)) ∧
      (detL T = -1 →
        T (nullPlus e (compl e)) = nullMinus f (compl f) ∧
          T (nullMinus e (compl e)) = nullPlus f (compl f)) :=
  ⟨fun hp => proper_transport_nullPair he hf hT hfut hp hTe,
    fun hd => improper_transport_nullPair he hf hT hfut hd hTe⟩

/-! ## 17–18. Product-family orbit; fixed invariance versus covariance (§15, §16) -/

/-- **Acceptance criterion 17.  PROVED.**  All reconstructed products of normalized
future units form a single orbit under the proper future Lorentz maps. -/
theorem task03_product_orbit {e f : Long} (he : FutureUnit e) (hf : FutureUnit f) :
    ∃ T : Long ≃ₗ[ℝ] Long,
      IsLorentz T ∧ PreservesFuture T ∧ IsProper T ∧ IsUnitalIso T (alg e) (alg f) :=
  product_orbit he hf

/-- **Acceptance criterion 18.  PROVED.**  Fixed-product invariance holds exactly on the
stabilizer of the unit, while family covariance holds for every Lorentz map. -/
theorem task03_fixed_vs_family {T : Long ≃ₗ[ℝ] Long} (h : IsLorentz T) {e : Long}
    (hQ : Q2 e = 1) : (FixedInvariant T e ↔ T e = e) ∧ (∀ X Y, T (mu e X Y) = mu (T e) (T X) (T Y)) :=
  ⟨fixedInvariant_iff h hQ, fun X Y => mu_covariant h e X Y⟩

/-- **PROVED IMPOSSIBLE.**  A fixed reconstructed product is *not* invariant under all
future-preserving Lorentz maps. -/
theorem task03_fixed_product_not_invariant :
    ∃ (e : Long) (T : Long ≃ₗ[ℝ] Long),
      FutureUnit e ∧ IsLorentz T ∧ PreservesFuture T ∧ ¬ FixedInvariant T e :=
  fixed_product_not_invariant

/-! ## 19. The remaining freedom (§17) -/

/-- **Acceptance criterion 19.  PROVED.**  After Lorentz transport exactly one discrete
choice remains, and it is exactly the exchange of the two null components: the
stabilizer of a normalized future unit has exactly two elements, its nontrivial element
is an algebra automorphism, and that element swaps the two null components. -/
theorem task03_residual_freedom {e : Long} (he : FutureUnit e) :
    (∀ T : Long ≃ₗ[ℝ] Long, IsLorentz T → PreservesFuture T → T e = e →
        (∀ X, T X = X) ∨ (∀ X, T X = reflectAt he.2 X)) ∧
      IsUnitalIso (reflectAt he.2) (alg e) (alg e) ∧
      (∃ X : Long, reflectAt he.2 X ≠ X) ∧
      reflectAt he.2 (nullPlus e (compl e)) = nullMinus e (compl e) ∧
      reflectAt he.2 (nullMinus e (compl e)) = nullPlus e (compl e) :=
  ⟨fun _ hT hfut hTe => stabilizer_classification he hT hfut hTe,
    stabilizer_isAutomorphism (reflectAt_isLorentz he.2) (reflectAt_unit he.2),
    reflectAt_ne_id he.2, (reflectAt_swaps_nullPair he).1, (reflectAt_swaps_nullPair he).2⟩

/-! ## 20. Late comparison with Task 01 (§18, §19) -/

/-- **Acceptance criterion 20.  PROVED.**  The Task-01 boost is a proper, future-
preserving Lorentz map; it is exactly the independently constructed transporter from
`u₀`; the covariance relation holds for it; and it preserves the `+`/`-` labels, which
are exchanged precisely by the orientation-reversing stabilizer element. -/
theorem task03_task01_comparison (eta : ℝ) :
    IsLorentz (boostEquiv eta) ∧ PreservesFuture (boostEquiv eta) ∧ IsProper (boostEquiv eta) ∧
      (∀ X, boostEquiv eta X = B eta X) ∧
      (∀ X, transport Q2_u₀ (isLorentz_Q2_unit (boost_isLorentz eta) Q2_u₀) X
        = boostEquiv eta X) ∧
      (∀ e X Y, boostEquiv eta (mu e X Y)
        = mu (boostEquiv eta e) (boostEquiv eta X) (boostEquiv eta Y)) ∧
      nullPlus u₀ s₀ = ep ∧ nullMinus u₀ s₀ = NullSectorTask01.em ∧
      reflectAt Q2_u₀ ep = NullSectorTask01.em :=
  ⟨boost_isLorentz eta, boost_preservesFuture eta, boost_isProper eta,
    boostEquiv_eq_B eta, transport_u₀_eq_boost eta, boost_covariance eta,
    nullPlus_u₀_eq_ep, nullMinus_u₀_eq_em, reflect_u₀_swaps_labels.1⟩

/-- §19, deferred: rapidity parametrization, proved late and used nowhere in the core. -/
theorem task03_rapidity {T : Long ≃ₗ[ℝ] Long} (hT : IsLorentz T) (hfut : PreservesFuture T)
    (hp : IsProper T) : ∃ eta : ℝ, ∀ X, T X = boostEquiv eta X :=
  proper_future_lorentz_is_boost hT hfut hp

/-! ## Axiom report -/

#print axioms task03_polarization_preserved
#print axioms task03_futureUnit_action
#print axioms task03_covariance
#print axioms task03_transport_of_algebras
#print axioms task03_unit_orbit
#print axioms task03_transporters_two
#print axioms task03_proper_transporter_unique
#print axioms task03_stabilizer
#print axioms task03_stabilizer_automorphisms
#print axioms task03_companions
#print axioms task03_null_idempotents
#print axioms task03_sign_flip
#print axioms task03_unordered_pair
#print axioms task03_ordered_pair_not_determined
#print axioms task03_null_pair_transport
#print axioms task03_product_orbit
#print axioms task03_fixed_vs_family
#print axioms task03_fixed_product_not_invariant
#print axioms task03_residual_freedom
#print axioms task03_task01_comparison
#print axioms task03_rapidity

end NullSectorTask03
