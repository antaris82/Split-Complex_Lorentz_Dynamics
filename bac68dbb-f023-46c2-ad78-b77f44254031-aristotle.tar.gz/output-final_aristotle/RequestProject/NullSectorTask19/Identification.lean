import RequestProject.NullSectorTask19.NegativeControls

/-!
# Task 19, final layer: the comparison-only module

**COMPARISON ONLY, AND LAST.**  This module is imported by nothing but
`RequestProject.NullSectorTask19.Task19`.  No Task-19 reconstruction module imports it, and
no reconstruction theorem depends on it.  It records a single reading of results already
derived; nothing here is used as an input anywhere and no new mathematics is introduced.

## What the Task-19 reconstruction produced

1. A primitive bridge notion which mentions only the factor itself — centrality,
   normalization at parameter zero, one-parameter multiplicativity, joint continuity — with
   **no** exactness in the definition; its exact normal form is `zexp` of two explicit
   recovered rates, and the reconstruction is jointly regular automatically (Package A).
2. Two genuine equivalences, both directions proved: a primitive bridge with globally exact
   reconstruction exists iff a global directional rate exists, and iff a globally jointly
   regular exact family exists.  The misleading Task-18 endpoint name was replaced by a
   statement whose name matches its logic, and primitive bridges are shown to exist, so no
   nonexistence result is an artefact of a definition (Package B).
3. The three-condition obstruction — continuity, half-oddness, reversal oddness — is an
   exactly minimal unsatisfiable set: unsatisfiable as a whole, satisfiable after removing
   any one of the three, with explicit witnesses retained (Package C).
4. Maximal preconnected admissible domains: antipodal completeness is sufficient;
   maximality forces closure-completeness; the converse is proved only under one explicitly
   named extra hypothesis.  Maximal preconnected, maximal open preconnected and maximal
   path-connected are three genuinely different notions, and not every maximal open
   preconnected admissible domain is an inherited `Dom v` (Package D).
5. In the plain admissible class an exact characterization of maximality is available —
   maximal iff dense and antipodally complete — maximal sets exist and are not unique;
   chains of admissible sets need not have admissible unions (Package E).
6. Prescribed labels on a disconnected domain are realizable exactly when the associated
   half-odd function extends continuously to the closure compatibly with reversal;
   separation of differently labelled closures is necessary but not sufficient (Package F).
7. Of the three visible-relation classes, the same-direction and identity-degenerate classes
   are automatic for every family with vanishing first rate and half-odd directional rate;
   the antipodal class is the only nonautomatic one (Package G).
8. Complete visible-relation compatibility of a locally exact covering system of open
   domains is **equivalent** to existence of one primitive global bridge, so the global
   obstruction can be restated purely as relation incompleteness (Package H).
9. Arbitrary-domain admissibility is unchanged by `Cᵏ` for every finite `k` and by `C∞`;
   analyticity is audited separately and the exact plateau of the construction is shown to
   be incompatible with analytic continuation (Package I).

## The conventional reading

Read conventionally, the pattern 1–9 says that the local internal data differ from one fixed
global reference by a discrete central factor whose rate is a half-integer label, that the
only surviving global incompatibility is the one visible across direction reversal, and that
this single incompatibility can be presented equivalently as a rate condition, as a bridge
condition, or as a relation-compatibility condition.

This paragraph is a *reading* of already-derived statements.  No group, covering, cocycle,
bundle, cohomology, connection or classification theorem was constructed, imported, or
needed anywhere in the reconstruction; the discrete labels are integers attached to explicit
families and are given no interpretation beyond that.
-/

namespace NullSectorTask19

open NullSectorTask01 NullSectorTask04 NullSectorTask06 NullSectorTask07 NullSectorTask08
open NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12 NullSectorTask13
open NullSectorTask14 NullSectorTask15 NullSectorTask16 NullSectorTask17 NullSectorTask18

/-- **COMPARISON ONLY.**  The three presentations of one and the same global obstruction,
collected in a single statement for the comparison discussion.  Every component is an
already-proved reconstruction theorem; this module adds nothing. -/
theorem comparison_three_presentations :
    ((∃ b : Vec3 → ℝ, IsGlobalRate b) ↔
        ∃ c : Vec3 → ℝ → W, IsPrimitiveBridge c ∧ IsTransformationValued (recon c)) ∧
      ((∃ (ι : Type) (D : ι → Set Vec3) (U : ι → Vec3 → ℝ → W),
          IsLocalSystem D U ∧ SystemRelationComplete D U) ↔
        ∃ c : Vec3 → ℝ → W, IsPrimitiveBridge c ∧ IsTransformationValued (recon c)) ∧
      ¬ ∃ b : Vec3 → ℝ, IsGlobalRate b :=
  ⟨primitiveBridge_iff_globalRate.symm, relationComplete_system_iff_primitiveBridge,
    no_global_rate_and_no_primitive_global_bridge.1⟩

end NullSectorTask19
