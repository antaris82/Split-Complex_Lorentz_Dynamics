import RequestProject.NullSectorTask19.Identification

/-!
# Task 19 — Intrinsic Global-Obstruction Decomposition: principal endpoints

This module imports the complete Task-19 development and exposes the principal final
theorems.  It is the only module that imports the Task-19 comparison-only module
`Identification`.

## Source order

`SafeBase → PrimitiveBridge → MinimalObstruction → MaximalPreconnected → PlainMaximality
→ DisconnectedExtension → RelationCompletion → RelationBridge → HigherRegularity
→ NegativeControls → Identification → Task19`

## Status table (§85, §86)

| endpoint | Lean name | status |
| --- | --- | --- |
| primitive bridge definition independent of exactness | `task19_primitive_bridge_exists` | `PROVED` |
| primitive bridge normal form | `task19_primitive_bridge_normal_form` | `PROVED` |
| primitive bridge ↔ rate | `task19_primitiveBridge_iff_rate` | `PROVED` |
| primitive bridge ↔ global exact family | `task19_primitiveBridge_iff_family` | `PROVED` |
| exact minimality of the three-condition obstruction | `task19_three_conditions_minimal` | `PROVED` |
| maximal preconnected admissible classification | `task19_maximal_preconnected` | `PARTIAL` (sufficiency and closure-completeness proved; converse `CONDITIONAL` on `AccessibleMissing`) |
| maximal open preconnected classification | `task19_maximal_open_not_Dom` | `REFUTED` (not every one is an inherited `Dom v`) |
| plain admissible maximality | `task19_plain_maximality` | `PROVED` (existence and exact criterion); uniqueness `REFUTED` |
| disconnected label extension theorem | `task19_label_extension` | `PROVED` (closure criterion); separation sufficiency `REFUTED` |
| relation-complete local system | `task19_relation_completeness` | `PROVED` (definition and separation from coverage) |
| only antipodal relation nonautomatic? | `task19_only_antipodal_nonautomatic` | `PROVED` |
| relation completion ↔ primitive bridge | `task19_relation_iff_bridge` | `PROVED` |
| `Cᵏ` equivalence | `task19_ck_equivalence` | `PROVED` |
| `C∞` equivalence | `task19_smooth_equivalence` | `PROVED` |
| analyticity audit | `task19_analytic_audit` | `PARTIAL` (plateau obstruction proved; arbitrary-domain analytic admissibility `OPEN`) |
| arbitrary spatial word problem | — | `OPEN`, not entered: no Task-19 theorem required it |

Formal Lean endpoints are exactly the `task19_*` theorems below.  Everything else in the
`TASK19_AUDIT.md` narrative is a paper-level reading.
-/

namespace NullSectorTask19

open scoped ContDiff

open NullSectorTask01 NullSectorTask04 NullSectorTask06 NullSectorTask07 NullSectorTask08
open NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12 NullSectorTask13
open NullSectorTask14 NullSectorTask15 NullSectorTask16 NullSectorTask17 NullSectorTask18

/-! ## Package A — the primitive bridge -/

/-- **TASK-19 ENDPOINT.**  Primitive bridges exist, locally exact ones exist, and no
primitive bridge has a globally exact reconstruction.  Exactness never enters the definition
of the object whose existence is asserted or denied. -/
theorem task19_primitive_bridge_exists :
    (∃ c : Vec3 → ℝ → W, IsPrimitiveBridge c) ∧
      (∃ c : Vec3 → ℝ → W, IsPrimitiveBridge c ∧ IsLocallyExact (recon c)) ∧
      ¬ ∃ c : Vec3 → ℝ → W, IsPrimitiveBridge c ∧ IsTransformationValued (recon c) :=
  primitiveBridge_boundary

/-- **TASK-19 ENDPOINT.**  The exact normal form of every primitive bridge, together with
uniqueness of the realizing pair of rates. -/
theorem task19_primitive_bridge_normal_form {c : Vec3 → ℝ → W} (hc : IsPrimitiveBridge c)
    {n : Vec3} (hn : IsUnitAxis n) :
    (∀ θ : ℝ, c n θ = zexp (primRateA c n) (primRateB c n) θ) ∧
      ∀ α β : ℝ, (∀ θ : ℝ, c n θ = zexp α β θ) → α = primRateA c n ∧ β = primRateB c n :=
  ⟨fun θ => primitiveBridge_normal_form hc hn θ, fun _ _ h => primitiveBridge_rates_unique hc hn h⟩

/-- **TASK-19 ENDPOINT.**  A primitive bridge is determined by the **pair** of its rates but
**not** by the directional rate alone. -/
theorem task19_primitive_bridge_determination :
    (∀ c d : Vec3 → ℝ → W, IsPrimitiveBridge c → IsPrimitiveBridge d →
        ∀ n : Vec3, IsUnitAxis n → primRateA c n = primRateA d n →
          primRateB c n = primRateB d n → ∀ θ : ℝ, c n θ = d n θ) ∧
      ∃ c d : Vec3 → ℝ → W, IsPrimitiveBridge c ∧ IsPrimitiveBridge d ∧
        (∀ n : Vec3, IsUnitAxis n → primRateB c n = primRateB d n) ∧
        ∃ n : Vec3, IsUnitAxis n ∧ ∃ θ : ℝ, c n θ ≠ d n θ :=
  ⟨fun _ _ hc hd _ hn hA hB θ => primitiveBridge_ext hc hd hn hA hB θ,
    primitiveBridge_not_determined_by_directional_rate⟩

/-! ## Package B — the two equivalences -/

/-- **TASK-19 ENDPOINT.**  Existence of a primitive bridge with globally exact
reconstruction is **equivalent** to existence of a global directional rate. -/
theorem task19_primitiveBridge_iff_rate :
    (∃ c : Vec3 → ℝ → W, IsPrimitiveBridge c ∧ IsTransformationValued (recon c)) ↔
      ∃ b : Vec3 → ℝ, IsGlobalRate b :=
  primitiveBridge_iff_globalRate

/-- **TASK-19 ENDPOINT.**  It is also equivalent to existence of a globally jointly regular
exact representative. -/
theorem task19_primitiveBridge_iff_family :
    (∃ c : Vec3 → ℝ → W, IsPrimitiveBridge c ∧ IsTransformationValued (recon c)) ↔
      ∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧ IsTransformationValued U :=
  primitiveBridge_iff_globalExactFamily

/-- **TASK-19 ENDPOINT.**  The corrected nonexistence endpoint: name and logical statement
coincide, and the two negations are recorded as a conjunction, not as a definition. -/
theorem task19_no_rate_no_bridge :
    (¬ ∃ b : Vec3 → ℝ, IsGlobalRate b) ∧
      ¬ ∃ c : Vec3 → ℝ → W, IsPrimitiveBridge c ∧ IsTransformationValued (recon c) :=
  no_global_rate_and_no_primitive_global_bridge

/-! ## Package C — minimality -/

/-- **TASK-19 ENDPOINT.**  The three rate conditions form an exact minimal unsatisfiable
set, with the three pairwise witnesses preserved. -/
theorem task19_three_conditions_minimal :
    (¬ SatisfiableSet (Finset.univ : Finset RateCond)) ∧
      (∀ S : Finset RateCond, S ⊂ Finset.univ → SatisfiableSet S) ∧
      (RateHalfOdd signRate ∧ RateRev signRate ∧ ¬ RateCont signRate) ∧
      (RateCont rateZero ∧ RateRev rateZero ∧ ¬ RateHalfOdd rateZero) ∧
      (RateCont rateHalf ∧ RateHalfOdd rateHalf ∧ ¬ RateRev rateHalf) :=
  ⟨three_conditions_minimal_unsatisfiable.1, three_conditions_minimal_unsatisfiable.2,
    three_witnesses_preserved.1, three_witnesses_preserved.2.1, three_witnesses_preserved.2.2⟩

/-- **TASK-19 ENDPOINT.**  The obstruction at its three logically separate levels: rates,
primitive bridges, exact families. -/
theorem task19_obstruction_three_levels :
    (¬ ∃ b : Vec3 → ℝ, RateCont b ∧ RateHalfOdd b ∧ RateRev b) ∧
      (¬ ∃ c : Vec3 → ℝ → W, IsPrimitiveBridge c ∧
        (∀ n : Vec3, IsUnitAxis n → primRateA c n = 0) ∧ RateHalfOdd (primRateB c) ∧
        RateRev (primRateB c)) ∧
      ¬ ∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧ IsTransformationValued U :=
  ⟨obstruction_rate_level, obstruction_primitiveBridge_level, obstruction_family_level⟩

/-! ## Package D — maximal preconnected admissible domains -/

/-- **TASK-19 ENDPOINT, `PARTIAL`/`CONDITIONAL`.**  Antipodal completeness is sufficient for
maximality; maximality forces closure-completeness; the converse is proved only under the
explicitly named hypothesis `AccessibleMissing`.  The empty set lies in the class and is not
maximal. -/
theorem task19_maximal_preconnected :
    (∀ D : Set Vec3, PreconnAdmClass D → AntipodalComplete D → IsMaximalIn PreconnAdmClass D) ∧
      (∀ D : Set Vec3, IsMaximalIn PreconnAdmClass D → ∀ p : Sph, p ∈ closure (sphSet D) →
        (p : Vec3) ∈ D ∨ -(p : Vec3) ∈ D) ∧
      (∀ D : Set Vec3, IsMaximalIn PreconnAdmClass D → AccessibleMissing D →
        AntipodalComplete D) ∧
      (PreconnAdmClass (∅ : Set Vec3) ∧ ¬ IsMaximalIn PreconnAdmClass (∅ : Set Vec3)) :=
  ⟨boundary_maximal_preconnected.1, boundary_maximal_preconnected.2.1,
    boundary_maximal_preconnected.2.2, empty_not_maximal⟩

/-- **TASK-19 ENDPOINT.**  The three maximality notions — preconnected, open preconnected,
path-connected — are genuinely different. -/
theorem task19_three_maximality_notions :
    IsMaximalIn PreconnAdmClass lexA ∧ IsMaximalIn PathConnAdmClass lexA ∧
      ¬ OpenDomain lexA ∧ IsMaximalIn OpenConnAdmClass (Dom e1) ∧
      ¬ IsMaximalIn PreconnAdmClass (Dom e1) :=
  three_maximality_notions_differ

/-- **TASK-19 ENDPOINT, `REFUTED`.**  Not every maximal open preconnected admissible domain
is an inherited domain `Dom v`. -/
theorem task19_maximal_open_not_Dom :
    ∃ E : Set Vec3, IsMaximalIn OpenConnAdmClass E ∧ YDom ⊆ E ∧ ∀ v : Vec3, E ≠ Dom v :=
  exists_maximal_openConnAdm_not_Dom

/-! ## Package E — the plain admissible class -/

/-- **TASK-19 ENDPOINT.**  In the plain admissible class: an exact maximality criterion, an
explicit maximal member, failure of uniqueness, and failure of chain-union admissibility. -/
theorem task19_plain_maximality :
    (∀ D : Set Vec3, UnitSet D →
        (IsMaximalIn AdmClass D ↔ DenseDom D ∧ AntipodalComplete D ∧ AntipodalFree D)) ∧
      IsMaximalIn AdmClass flipSet ∧
      (∃ D E : Set Vec3, IsMaximalIn AdmClass D ∧ IsMaximalIn AdmClass E ∧ D ≠ E) ∧
      ((∀ k : ℕ, IsAdmissibleDomain (bandSet k)) ∧
        (∀ k l : ℕ, k ≤ l → bandSet k ⊆ bandSet l) ∧
        bandUnion = (⋃ k : ℕ, bandSet k) ∧ ¬ IsAdmissibleDomain bandUnion) :=
  ⟨fun _ hunit => maximal_adm_iff hunit, exists_maximal_adm, maximal_adm_not_unique,
    chain_union_not_admissible⟩

/-! ## Package F — disconnected label data -/

/-- **TASK-19 ENDPOINT.**  The exact extension criterion for prescribed component labels, on
the closure of the domain, together with the label rigidity on components, the necessity of
separation, and the refutation of its sufficiency. -/
theorem task19_label_extension :
    (∀ (D : Set Vec3) (hunit : UnitSet D) (l : Vec3 → ℤ),
        LabelRealized D l ↔
          ∃ g : C(closure (sphSet D), ℝ),
            (∀ (n : Vec3) (h : n ∈ D),
              g ⟨⟨n, hunit n h⟩, subset_closure h⟩ = (l n : ℝ) + 1 / 2) ∧
            (∀ (n : Vec3) (h : n ∈ D) (h' : -n ∈ D),
              g ⟨⟨-n, hunit _ h'⟩, subset_closure h'⟩ =
                -g ⟨⟨n, hunit n h⟩, subset_closure h⟩)) ∧
      (∀ (D : Set Vec3) (l : Vec3 → ℤ), LabelRealized D l → ∀ j k : ℤ, j ≠ k →
        closure (sphSet (LabelLevel D l j)) ∩ closure (sphSet (LabelLevel D l k)) = ∅) ∧
      ((∀ j k : ℤ, j ≠ k →
          closure (sphSet (LabelLevel accDom accLabel j)) ∩
            closure (sphSet (LabelLevel accDom accLabel k)) = ∅) ∧
        ¬ LabelRealized accDom accLabel) :=
  ⟨fun _ hunit l => label_closure_extension_criterion hunit l,
    fun _ _ h _ _ hjk => label_levels_separated h hjk, separation_not_sufficient⟩

/-! ## Package G — visible-relation coverage -/

/-- **TASK-19 ENDPOINT.**  The same-direction and identity-degenerate relation classes are
automatic; the antipodal class is not.  Adding exactly the antipodal comparison datum makes
a family relation complete, and relation completeness returns it. -/
theorem task19_only_antipodal_nonautomatic :
    (∀ U : Vec3 → ℝ → W, IsJointlyRegularFamily U → RateZeroHalfOdd U →
        (IsRelationComplete U ↔ AntipodalRelated U)) ∧
      (∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧ RateZeroHalfOdd U ∧
        ¬ AntipodalRelated U) :=
  ⟨fun _ hU hr => relationComplete_iff_antipodalRelated hU hr, antipodal_class_not_automatic⟩

/-- **TASK-19 ENDPOINT.**  Relation completeness is strictly stronger than set-theoretic
direction coverage. -/
theorem task19_relation_completeness :
    CoversDirections Dom ∧ CoherentOverlaps Dom inhSystem ∧
      (∀ v : Vec3, v ≠ 0 → IsTransformationValuedOn (Dom v) (inhSystem v)) ∧
      ¬ SystemRelationComplete Dom inhSystem :=
  ⟨coverage_not_relationComplete.1, fun _ _ _ _ _ _ => rfl,
    coverage_not_relationComplete.2.2.1, coverage_not_relationComplete.2.2.2⟩

/-! ## Package H — relation completion versus the bridge -/

/-- **TASK-19 ENDPOINT.**  The genuine equivalence: a relation-complete locally exact
covering system of open domains exists **iff** a primitive global bridge with globally exact
reconstruction exists. -/
theorem task19_relation_iff_bridge :
    (∃ (ι : Type) (D : ι → Set Vec3) (U : ι → Vec3 → ℝ → W),
        IsLocalSystem D U ∧ SystemRelationComplete D U) ↔
      ∃ c : Vec3 → ℝ → W, IsPrimitiveBridge c ∧ IsTransformationValued (recon c) :=
  relationComplete_system_iff_primitiveBridge

/-- **TASK-19 ENDPOINT.**  The global obstruction restated purely as relation
incompleteness, together with the explicit counterexample in which ordinary overlaps are
coherent and only the antipodal relation class fails. -/
theorem task19_global_obstruction_as_relations :
    (¬ ∃ (ι : Type) (D : ι → Set Vec3) (U : ι → Vec3 → ℝ → W),
        IsLocalSystem D U ∧ SystemRelationComplete D U) ∧
      IsLocalSystem Dom inhSystem ∧ CoherentOverlaps Dom inhSystem ∧
      ¬ SystemRelationComplete Dom inhSystem :=
  ⟨global_obstruction_is_relation_incompleteness.1, inhSystem_isLocalSystem,
    inhSystem_relation_counterexample.2.1, inhSystem_relation_counterexample.2.2.2.2.2.1⟩

/-! ## Package I — regularity -/

/-- **TASK-19 ENDPOINT.**  For every finite `k` and every set of unit directions, continuous
admissibility and `Cᵏ` admissibility coincide. -/
theorem task19_ck_equivalence (k : ℕ) (D : Set Vec3) :
    IsAdmissibleDomain D ↔ IsCkAdmissibleDomain (k : WithTop ℕ∞) D :=
  admissible_iff_ckAdmissible k

/-- **TASK-19 ENDPOINT.**  The same holds at `C∞`, for arbitrary domains. -/
theorem task19_smooth_equivalence (D : Set Vec3) :
    IsAdmissibleDomain D ↔ IsCkAdmissibleDomain ∞ D :=
  admissible_iff_smoothAdmissible

/-- **TASK-19 ENDPOINT, `PARTIAL`.**  The analyticity audit, kept separate from smoothness:
the exact plateau of the construction is impossible for an analytic function, while
antipodal-free domains do carry an analytic rate.  No arbitrary-domain analytic statement is
claimed. -/
theorem task19_analytic_audit :
    (∀ f : ℝ → ℝ, AnalyticOnNhd ℝ f Set.univ → ∀ p q c : ℝ, p < q →
        (∀ x ∈ Set.Ioo p q, f x = c) → ∀ x : ℝ, f x = c) ∧
      (∀ D : Set Vec3, (∀ n ∈ D, IsUnitAxis n) → AntipodalFree D →
        IsCkAdmissibleDomain ω D) :=
  ⟨control_c1_needs_construction.2, fun _ hunit hfree => antipodalFree_analyticAdmissible hunit hfree⟩

/-! ## Package J — the controls -/

/-- **TASK-19 ENDPOINT.**  The eight negative controls, collected. -/
theorem task19_controls :
    (∃ c : Vec3 → ℝ → W, IsPrimitiveBridge c ∧
        (∀ n : Vec3, IsUnitAxis n → ∀ θ : ℝ, c n θ ∈ Z) ∧ ¬ IsLocallyExact (recon c)) ∧
      ((∃ c : Vec3 → ℝ → W, IsPrimitiveBridge c ∧ IsLocallyExact (recon c)) ∧
        ¬ ∃ c : Vec3 → ℝ → W, IsPrimitiveBridge c ∧ IsTransformationValued (recon c)) ∧
      (∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧ IsTransformationValuedOn multiD U ∧
        rateBeta U e1 ≠ rateBeta U p35) ∧
      (IsMaximalIn OpenConnAdmClass (Dom e1) ∧ ¬ IsMaximalIn PreconnAdmClass (Dom e1) ∧
        IsMaximalIn PreconnAdmClass lexA ∧ ¬ OpenDomain lexA) ∧
      (CoversDirections Dom ∧ CoherentOverlaps Dom inhSystem ∧
        ¬ SystemRelationComplete Dom inhSystem) ∧
      ((∀ (D : Set Vec3) (l : Vec3 → ℤ), LabelRealized D l → ∀ j k : ℤ, j ≠ k →
          closure (sphSet (LabelLevel D l j)) ∩ closure (sphSet (LabelLevel D l k)) = ∅) ∧
        ¬ LabelRealized accDom accLabel) ∧
      ((∀ N : ℕ, ContDiff ℝ ∞ (stair N)) ∧
        (∀ f : ℝ → ℝ, AnalyticOnNhd ℝ f Set.univ → ∀ p q c : ℝ, p < q →
          (∀ x ∈ Set.Ioo p q, f x = c) → ∀ x : ℝ, f x = c)) ∧
      (IsMaximalIn AdmClass flipSet ∧
        ∃ D E : Set Vec3, IsMaximalIn AdmClass D ∧ IsMaximalIn AdmClass E ∧ D ≠ E) :=
  ⟨control_centrality_not_local_exactness, control_bridge_not_global,
    control_connectedness_needed, control_openness_needed, control_coverage_not_relations,
    control_labels_not_arbitrary, control_c1_needs_construction,
    control_maximality_not_canonicality⟩

/-! ## Comparison layer (imported only here) -/

/-- **COMPARISON ONLY.**  The three presentations of the single global obstruction. -/
theorem task19_comparison :
    ((∃ b : Vec3 → ℝ, IsGlobalRate b) ↔
        ∃ c : Vec3 → ℝ → W, IsPrimitiveBridge c ∧ IsTransformationValued (recon c)) ∧
      ((∃ (ι : Type) (D : ι → Set Vec3) (U : ι → Vec3 → ℝ → W),
          IsLocalSystem D U ∧ SystemRelationComplete D U) ↔
        ∃ c : Vec3 → ℝ → W, IsPrimitiveBridge c ∧ IsTransformationValued (recon c)) ∧
      ¬ ∃ b : Vec3 → ℝ, IsGlobalRate b :=
  comparison_three_presentations

/-! ## §93 — axiom report -/

#print axioms task19_primitive_bridge_exists
#print axioms task19_primitive_bridge_normal_form
#print axioms task19_primitive_bridge_determination
#print axioms task19_primitiveBridge_iff_rate
#print axioms task19_primitiveBridge_iff_family
#print axioms task19_no_rate_no_bridge
#print axioms task19_three_conditions_minimal
#print axioms task19_obstruction_three_levels
#print axioms task19_maximal_preconnected
#print axioms task19_three_maximality_notions
#print axioms task19_maximal_open_not_Dom
#print axioms task19_plain_maximality
#print axioms task19_label_extension
#print axioms task19_only_antipodal_nonautomatic
#print axioms task19_relation_completeness
#print axioms task19_relation_iff_bridge
#print axioms task19_global_obstruction_as_relations
#print axioms task19_ck_equivalence
#print axioms task19_smooth_equivalence
#print axioms task19_analytic_audit
#print axioms task19_controls
#print axioms task19_comparison

end NullSectorTask19
