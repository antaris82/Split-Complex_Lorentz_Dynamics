import RequestProject.NullSectorTask30.Task30

/-!
# Task 31, Package D: the liftability predicate of an ordinary transition system

**HARD TARGET B, first step (items 39–42).**

`InternalLiftable P S` is, by definition, exactly the conditional input of Task XXX:

```
InternalLiftable P S  :=  Nonempty (CompatibleContinuousInternalTransitions P S)
```

It depends only on

* the inherited ordinary transition system `S` (the frozen Task-XXVII interface), and
* the frozen internal projection `P`,

and on **nothing else**: no candidate, no refinement, no representative choice and no kernel
adjustment enter the statement.

Everything else in this module is a *theorem* (never a definitional restatement) obtained
from the certified Task-XXIX interface:

* `internalLiftable_iff_canTrivialiseSimultaneously` — the predicate is the inherited
  Task-XXVIII/XXIX simultaneous-trivializability of *any* refined candidate (item 40);
* `internalLiftable_rep_choice_independent`, `internalLiftable_gauge_independent`,
  `internalLiftable_refinement_independent` — the auxiliary lift choices used to *discover*
  the defect are irrelevant (items 41, 42).

Nothing in this module asserts that `InternalLiftable` holds; the existence audit is
Packages E and F.
-/

set_option synthInstance.maxHeartbeats 400000
set_option maxHeartbeats 1000000

namespace NullSectorTask31

open NullSectorTask28 NullSectorTask29 NullSectorTask30

universe u v w t

section Predicate

variable {B : Type u} [TopologicalSpace B] {ι : Type t} {G : Type v} [Group G]
  [TopologicalSpace G] {L : Type w} [Group L] [TopologicalSpace L] [IsTopologicalGroup L]

/-- **PACKAGE D (item 39), principal definition.**  An ordinary transition system is
*internally liftable* (through the frozen internal projection `P`) when compatible
normalized continuous internal transitions exist on its original overlaps.  This is exactly
the conditional input consumed by Task XXX. -/
def InternalLiftable (P : InternalProjection L G) (S : TransitionSystem B ι G) : Prop :=
  Nonempty (CompatibleContinuousInternalTransitions P S)

variable {P : InternalProjection L G} {S : TransitionSystem B ι G}

/-- **PACKAGE D (item 40), REQUIRED ENDPOINT.**  Liftability is the inherited Task-XXVIII
predicate `CanTrivialiseSimultaneously` of *any* refined internal candidate.  This is the
Task-XXIX theorem, not a definitional unfolding. -/
theorem internalLiftable_iff_canTrivialiseSimultaneously
    (C : InternalTransitionCandidate P S) :
    InternalLiftable P S ↔ CanTrivialiseSimultaneously P S C :=
  (canTrivialiseSimultaneously_iff_exists_compatible_transitions C).symm

/-- **PACKAGE D (item 40).**  The same statement with the Task-XXIX solvability predicate. -/
theorem internalLiftable_iff_canTrivialise (C : InternalTransitionCandidate P S) :
    InternalLiftable P S ↔ CanTrivialise C :=
  (compatibilityReady_iff_exists_compatible_transitions C).symm

/-- **PACKAGE D (item 41), representative-choice independence.**  Two refined candidates over
the same ordinary system are simultaneously trivializable together: the initially chosen
local internal representatives do not affect liftability. -/
theorem internalLiftable_rep_choice_independent (C C' : InternalTransitionCandidate P S) :
    CanTrivialise C ↔ CanTrivialise C' :=
  canTrivialise_candidate_independent C C'

/-- **PACKAGE D (item 41), gauge independence.**  Adjusting the stored representatives by an
admissible continuous kernel adjustment does not affect liftability. -/
theorem internalLiftable_gauge_independent (C : InternalTransitionCandidate P S) (ε : Adj C) :
    CanTrivialise (adjust C ε) ↔ InternalLiftable P S :=
  (canTrivialise_adjust_iff C ε).trans (internalLiftable_iff_canTrivialise C).symm

/-- **PACKAGE D (item 41), refinement independence.**  Replacing the auxiliary Task-XXVIII
refinement by a finer one does not affect liftability, in both directions. -/
theorem internalLiftable_refinement_independent (C : InternalTransitionCandidate P S)
    (R : CandidateRefinement C) :
    CanTrivialise (restrict C R) ↔ InternalLiftable P S :=
  (canTrivialise_restrict_iff C R).trans (internalLiftable_iff_canTrivialise C).symm

/-- **PACKAGE D (item 42), the required principle, in one statement.**  Liftability is a
property of the ordinary transition system relative to the fixed internal projection: it is
equivalent to the solvability verdict of *every* candidate, of *every* adjusted candidate and
of *every* refinement of it. -/
theorem internalLiftable_is_property_of_ordinary_system
    (C : InternalTransitionCandidate P S) (ε : Adj C) (R : CandidateRefinement C) :
    (InternalLiftable P S ↔ CanTrivialise C) ∧
      (InternalLiftable P S ↔ CanTrivialise (adjust C ε)) ∧
      (InternalLiftable P S ↔ CanTrivialise (restrict C R)) :=
  ⟨internalLiftable_iff_canTrivialise C, (internalLiftable_gauge_independent C ε).symm,
    (internalLiftable_refinement_independent C R).symm⟩

/-! ## Elementary sufficient condition: an ordinary system with trivial transitions -/

/-- **PACKAGE F (item 55), the positive mechanism.**  An ordinary transition system all of
whose transitions are the identity is internally liftable: the constant internal transition
system solves every requirement. -/
theorem internalLiftable_of_transitions_trivial (hg : ∀ (i j : ι) (x : ↥(S.U i ∩ S.U j)),
    S.g i j x = 1) : InternalLiftable P S :=
  ⟨{ v := fun _ _ _ => 1
     continuous_v := fun _ _ => continuous_const
     proj_v := fun i j x => by rw [map_one, hg i j x]
     v_self := fun _ _ => rfl
     v_symm := fun _ _ _ => inv_one.symm
     v_trans := fun _ _ _ _ => one_mul 1 }⟩

end Predicate

/-! ## The inherited (Task-XXVII) reading of the predicate -/

section Inherited

open NullSectorTask27

variable {B : Type u} [TopologicalSpace B] {ι : Type t}

/-- **PACKAGE D.**  Liftability of an inherited Task-XXVII ordinary transition system through
the certified internal projection read over the fixed visible model group. -/
def OrdinaryInternalLiftable (S : NullSectorTask28.OrdinaryTransitionSystem B ι) : Prop :=
  InternalLiftable ModelBridge.modelInternalProjection (ofOrdinary S)

/-- **PACKAGE D.**  For the inherited data, liftability is the Task-XXIX solvability of the
inherited candidate. -/
theorem ordinaryInternalLiftable_iff_canTrivialise (S : NullSectorTask28.OrdinaryTransitionSystem B ι)
    (C : InternalTransitionCandidate ModelBridge.modelInternalProjection (ofOrdinary S)) :
    OrdinaryInternalLiftable S ↔ CanTrivialise C :=
  internalLiftable_iff_canTrivialise C

end Inherited

end NullSectorTask31
