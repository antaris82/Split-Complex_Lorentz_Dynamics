import RequestProject.NullSectorTask01.Basic
import RequestProject.NullSectorTask01.SplitComplex
import RequestProject.NullSectorTask01.Boost
import RequestProject.NullSectorTask01.Strata
import RequestProject.NullSectorTask01.Limits

/-!
# Task 01: principal theorems

This module imports the complete Task 01 development and states the principal
final theorems, one for each acceptance criterion.  Everything is a restatement
or an immediate combination of the results proved in the imported modules.

Lean version: `leanprover/lean4:v4.28.0`.
Mathlib revision: `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (tag `v4.28.0`).
-/

namespace NullSectorTask01

open Filter Topology

/-- **(1)** The longitudinal 1+1 quadratic form is the restriction of the 3+1
Lorentz form along the canonical embedding `ι(t,x) = (t,x,0,0)`. -/
theorem task01_restriction (X : Long) : Q4 (iota X) = Q2 X := Q4_iota X

/-- **(2)** The split-complex idempotents are complementary (idempotent,
orthogonal, summing to `1`, differing by `j`) and null for `Q₂`. -/
theorem task01_idempotents :
    jL ⋆ jL = oneL ∧
    ep ⋆ ep = ep ∧ em ⋆ em = em ∧ ep ⋆ em = 0 ∧ em ⋆ ep = 0 ∧
    ep + em = oneL ∧ ep - em = jL ∧
    Q2 ep = 0 ∧ Q2 em = 0 :=
  ⟨jL_mulL_jL, ep_mulL_ep, em_mulL_em, ep_mulL_em, em_mulL_ep,
    ep_add_em, ep_sub_em, Q2_ep, Q2_em⟩

/-- **(3)** Existence and uniqueness of the complementary decomposition
`X = a • e₊ + b • e₋`. -/
theorem task01_unique_decomposition (X : Long) :
    ∃! p : ℝ × ℝ, P p.1 p.2 = X := by
  refine ⟨(qp X, qm X), P_qp_qm X, ?_⟩
  rintro ⟨a, b⟩ h
  have h1 : qp (P a b) = qp X := by rw [h]
  have h2 : qm (P a b) = qm X := by rw [h]
  simp only [qp_P, qm_P] at h1 h2
  simp [h1, h2]

/-- **(4)** The quadratic form in complementary coordinates is exactly the
product of the coefficients. -/
theorem task01_Q2_eq_product (a b : ℝ) : Q2 (P a b) = a * b := Q2_P a b

/-- **(5)** The closed coefficient quadrant matches the future-causal cone and is
exhaustively and disjointly partitioned into `zero`, the two boundary strata,
and the interior stratum; the quadratic form vanishes on the boundary strata and
is strictly positive on the interior stratum, with converses inside the sector. -/
theorem task01_strata {a b : ℝ} (h : FutureCausalCoeff a b) :
    FutureCausalVec (P a b) ∧
    (IsZero a b ∨ IsPlusBoundary a b ∨ IsMinusBoundary a b ∨ IsInterior a b) ∧
    (Q2 (P a b) = 0 ↔ (IsZero a b ∨ IsPlusBoundary a b ∨ IsMinusBoundary a b)) ∧
    (0 < Q2 (P a b) ↔ IsInterior a b) :=
  ⟨(futureCausal_iff a b).mp h, strata_exhaustive h, Q2_eq_zero_iff h, Q2_pos_iff_interior h⟩

/-- **(6)** A longitudinal boost acts on complementary coefficients by reciprocal
scaling. -/
theorem task01_boost_action (eta a b : ℝ) :
    B eta (P a b) = P (Real.exp eta * a) (Real.exp (-eta) * b) := B_P eta a b

/-- **(7)** The product of the complementary coefficients is a boost invariant.
(Proved directly in `invProd_boost_direct`, and independently as a corollary of
Lorentz invariance in `invProd_boost_via_Q2`.) -/
theorem task01_invariant_product (eta a b : ℝ) :
    (Real.exp eta * a) * (Real.exp (-eta) * b) = a * b :=
  invProd_boost_direct eta a b

/-- **(8)** Regime A: with the first coefficient fixed the family `P(a₀, ε)`
converges in the carrier to the `+` boundary point `P(a₀,0)`, its quadratic form
tends to `0`, the limit point lies in the `+` boundary stratum, and every member
with `ε > 0` lies in the interior stratum. -/
theorem task01_boundary_family {a0 : ℝ} (h : 0 < a0) :
    Tendsto (fun eps : ℝ => Fp a0 eps) (𝓝[>] (0 : ℝ)) (𝓝 (P a0 0)) ∧
    Tendsto (fun eps : ℝ => Q2 (Fp a0 eps)) (𝓝[>] (0 : ℝ)) (𝓝 0) ∧
    IsPlusBoundary a0 0 ∧
    ∀ eps : ℝ, 0 < eps → IsInterior a0 eps :=
  ⟨tendsto_Fp a0, tendsto_Q2_Fp a0, Fp_zero_mem_plusBoundary h,
    fun _ he => Fp_pos_mem_interior h he⟩

/-- The symmetric `-` boundary family. -/
theorem task01_boundary_family_minus {b0 : ℝ} (h : 0 < b0) :
    Tendsto (fun eps : ℝ => Fm b0 eps) (𝓝[>] (0 : ℝ)) (𝓝 (P 0 b0)) ∧
    Tendsto (fun eps : ℝ => Q2 (Fm b0 eps)) (𝓝[>] (0 : ℝ)) (𝓝 0) ∧
    IsMinusBoundary 0 b0 ∧
    ∀ eps : ℝ, 0 < eps → IsInterior eps b0 :=
  ⟨tendsto_Fm b0, tendsto_Q2_Fm b0, Fm_zero_mem_minusBoundary h,
    fun _ he => Fm_pos_mem_interior h he⟩

/-- **(9)** The two limiting regimes are mathematically distinguished: Regime A
(one coefficient fixed, no positivity needed) converges in the carrier, while Regime B (product fixed
at `I > 0`) has constant quadratic form `I` and admits no limit in the carrier,
its first ordinary coordinate diverging. -/
theorem task01_regimes {I : ℝ} (a0 : ℝ) (hI : 0 < I) :
    Tendsto (fun eps : ℝ => Fp a0 eps) (𝓝[>] (0 : ℝ)) (𝓝 (P a0 0)) ∧
    Tendsto (fun eps : ℝ => Q2 (Fp a0 eps)) (𝓝[>] (0 : ℝ)) (𝓝 0) ∧
    (∀ b : ℝ, b ≠ 0 → Q2 (G I b) = I) ∧
    Tendsto (fun b : ℝ => (G I b).1) (𝓝[>] (0 : ℝ)) atTop ∧
    ¬ ∃ L : Long, Tendsto (fun b : ℝ => G I b) (𝓝[>] (0 : ℝ)) (𝓝 L) := by
  exact ⟨tendsto_Fp a0, tendsto_Q2_Fp a0, fun _ hb => Q2_G hb, tendsto_G_fst_atTop hI,
    not_tendsto_G hI⟩

end NullSectorTask01
