import RequestProject.NullSectorTask01.Basic

/-!
# Task 01, Layer 2: split-complex structure and null coordinates on `Long`

We equip the longitudinal carrier `Long = ℝ × ℝ` with the split-complex product,
exhibit the two complementary idempotents `e₊`, `e₋`, and build the resulting
null-coordinate decomposition.  All identities are *derived* from the definitions.
-/

namespace NullSectorTask01

/-- Split-complex multiplication on the longitudinal carrier. -/
def mulL (X Y : Long) : Long := (X.1 * Y.1 + X.2 * Y.2, X.1 * Y.2 + X.2 * Y.1)

@[inherit_doc] scoped infixl:70 " ⋆ " => mulL

@[simp] theorem mulL_apply (t x s y : ℝ) : (t, x) ⋆ (s, y) = (t * s + x * y, t * y + x * s) := rfl

/-- The unit of the split-complex product. -/
def oneL : Long := (1, 0)

/-- The split-complex imaginary unit, with `j ⋆ j = 1`. -/
def jL : Long := (0, 1)

@[simp] theorem oneL_def : oneL = ((1 : ℝ), (0 : ℝ)) := rfl
@[simp] theorem jL_def : jL = ((0 : ℝ), (1 : ℝ)) := rfl

theorem mulL_comm (X Y : Long) : X ⋆ Y = Y ⋆ X := by
  obtain ⟨t, x⟩ := X; obtain ⟨s, y⟩ := Y
  apply Prod.ext <;> simp [mulL] <;> ring

theorem mulL_assoc (X Y Z : Long) : (X ⋆ Y) ⋆ Z = X ⋆ (Y ⋆ Z) := by
  obtain ⟨t, x⟩ := X; obtain ⟨s, y⟩ := Y; obtain ⟨u, v⟩ := Z
  apply Prod.ext <;> simp [mulL] <;> ring

@[simp] theorem oneL_mulL (X : Long) : oneL ⋆ X = X := by
  obtain ⟨t, x⟩ := X; simp [mulL, oneL]

/-- `j ⋆ j = 1`. -/
theorem jL_mulL_jL : jL ⋆ jL = oneL := by simp [mulL, jL, oneL]

/-- The `+` idempotent `e₊ = (1 + j)/2`. -/
noncomputable def ep : Long := (1 / 2 : ℝ) • (oneL + jL)

/-- The `-` idempotent `e₋ = (1 - j)/2`. -/
noncomputable def em : Long := (1 / 2 : ℝ) • (oneL - jL)

theorem ep_eq : ep = ((1 / 2 : ℝ), (1 / 2 : ℝ)) := by
  norm_num [ep, oneL, jL, Prod.ext_iff]

theorem em_eq : em = ((1 / 2 : ℝ), (-(1 / 2) : ℝ)) := by
  norm_num [em, oneL, jL, Prod.ext_iff]

theorem ep_mulL_ep : ep ⋆ ep = ep := by
  norm_num [ep_eq, mulL, Prod.ext_iff]

theorem em_mulL_em : em ⋆ em = em := by
  norm_num [em_eq, mulL, Prod.ext_iff]

theorem ep_mulL_em : ep ⋆ em = (0 : Long) := by
  norm_num [ep_eq, em_eq, mulL, Prod.ext_iff]

theorem em_mulL_ep : em ⋆ ep = (0 : Long) := by
  rw [mulL_comm, ep_mulL_em]

theorem ep_add_em : ep + em = oneL := by
  norm_num [ep_eq, em_eq, oneL, Prod.ext_iff]

theorem ep_sub_em : ep - em = jL := by
  norm_num [ep_eq, em_eq, jL, Prod.ext_iff]

/-! ## Null coordinates -/

/-- The `+` null coordinate `q₊(t,x) = t + x`. -/
def qp (X : Long) : ℝ := X.1 + X.2

/-- The `-` null coordinate `q₋(t,x) = t - x`. -/
def qm (X : Long) : ℝ := X.1 - X.2

@[simp] theorem qp_apply (t x : ℝ) : qp (t, x) = t + x := rfl
@[simp] theorem qm_apply (t x : ℝ) : qm (t, x) = t - x := rfl

/-- Assembly of a longitudinal vector from complementary null coefficients. -/
noncomputable def P (a b : ℝ) : Long := a • ep + b • em

theorem P_eq (a b : ℝ) : P a b = ((a + b) / 2, (a - b) / 2) := by
  apply Prod.ext <;> simp [P, ep_eq, em_eq] <;> ring

@[simp] theorem P_fst (a b : ℝ) : (P a b).1 = (a + b) / 2 := by rw [P_eq]

@[simp] theorem P_snd (a b : ℝ) : (P a b).2 = (a - b) / 2 := by rw [P_eq]

/-- **Exact reconstruction.** Every longitudinal vector is the sum of its two
complementary null components. -/
theorem P_qp_qm (X : Long) : P (qp X) (qm X) = X := by
  obtain ⟨t, x⟩ := X
  apply Prod.ext <;> simp [P_eq]

@[simp] theorem qp_P (a b : ℝ) : qp (P a b) = a := by
  simp only [qp, P_fst, P_snd]; ring

@[simp] theorem qm_P (a b : ℝ) : qm (P a b) = b := by
  simp only [qm, P_fst, P_snd]; ring

/-- Uniqueness of the complementary decomposition. -/
theorem P_injective : Function.Injective (fun p : ℝ × ℝ => P p.1 p.2) := by
  rintro ⟨a, b⟩ ⟨c, d⟩ h
  simp only at h
  have h1 : qp (P a b) = qp (P c d) := by rw [h]
  have h2 : qm (P a b) = qm (P c d) := by rw [h]
  simp only [qp_P, qm_P] at h1 h2
  simp [h1, h2]

/-- **Acceptance criterion 3.**  The explicit linear equivalence between ordinary
longitudinal coordinates and complementary null coefficients. -/
noncomputable def nullEquiv : Long ≃ₗ[ℝ] ℝ × ℝ where
  toFun X := (qp X, qm X)
  invFun p := P p.1 p.2
  left_inv X := P_qp_qm X
  right_inv p := by obtain ⟨a, b⟩ := p; simp
  map_add' X Y := by
    obtain ⟨t, x⟩ := X; obtain ⟨s, y⟩ := Y
    apply Prod.ext <;> simp [qp, qm] <;> ring
  map_smul' c X := by
    obtain ⟨t, x⟩ := X
    apply Prod.ext <;> simp [qp, qm] <;> ring

@[simp] theorem nullEquiv_apply (X : Long) : nullEquiv X = (qp X, qm X) := rfl
@[simp] theorem nullEquiv_symm_apply (a b : ℝ) : nullEquiv.symm (a, b) = P a b := rfl

/-! ## The quadratic form in complementary coordinates -/

/-- Neutral shorthand for the product of the two complementary coefficients. -/
def invProd (a b : ℝ) : ℝ := a * b

@[simp] theorem invProd_def (a b : ℝ) : invProd a b = a * b := rfl

/-- **Acceptance criterion 4.**  The Lorentz quadratic form is exactly the product
of the complementary null coefficients. -/
theorem Q2_P (a b : ℝ) : Q2 (P a b) = invProd a b := by
  simp only [Q2, P_fst, P_snd, invProd]; ring

theorem Q2_eq_qp_mul_qm (X : Long) : Q2 X = qp X * qm X := by
  obtain ⟨t, x⟩ := X; simp only [Q2, qp, qm]; ring

/-- **Acceptance criterion 2 (null part).** -/
theorem Q2_ep : Q2 ep = 0 := by rw [ep_eq]; simp [Q2]

theorem Q2_em : Q2 em = 0 := by rw [em_eq]; simp [Q2]

end NullSectorTask01
