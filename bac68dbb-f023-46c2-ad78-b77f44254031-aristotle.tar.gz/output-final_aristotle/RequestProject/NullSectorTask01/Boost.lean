import RequestProject.NullSectorTask01.SplitComplex

/-!
# Task 01, Layer 3: longitudinal boosts and the invariant product

The proper orthochronous longitudinal boost of rapidity `η` is defined on `Long`
and extended to `Vec4` by leaving the two transverse coordinates fixed.  Its
action on the complementary null coefficients is derived from the standard
hyperbolic identities `Real.cosh_add_sinh` and `Real.cosh_sub_sinh`.
-/

namespace NullSectorTask01

open Real

/-- Longitudinal boost of rapidity `η` on the longitudinal carrier. -/
noncomputable def B (eta : ℝ) (X : Long) : Long :=
  (cosh eta * X.1 + sinh eta * X.2, sinh eta * X.1 + cosh eta * X.2)

/-- Longitudinal boost of rapidity `η` on the ambient carrier: the transverse
coordinates `y`, `z` are unchanged. -/
noncomputable def B4 (eta : ℝ) (X : Vec4) : Vec4 :=
  (cosh eta * X.1 + sinh eta * X.2.1, sinh eta * X.1 + cosh eta * X.2.1, X.2.2.1, X.2.2.2)

@[simp] theorem B_apply (eta t x : ℝ) :
    B eta (t, x) = (cosh eta * t + sinh eta * x, sinh eta * t + cosh eta * x) := rfl

@[simp] theorem B4_apply (eta t x y z : ℝ) :
    B4 eta (t, x, y, z) =
      (cosh eta * t + sinh eta * x, sinh eta * t + cosh eta * x, y, z) := rfl

/-- The ambient boost restricts to the longitudinal boost along `iota`. -/
theorem B4_iota (eta : ℝ) (X : Long) : B4 eta (iota X) = iota (B eta X) := by
  obtain ⟨t, x⟩ := X; rfl

/-- Invariance of the 3+1 Lorentz form under the longitudinal boost. -/
theorem Q4_B4 (eta : ℝ) (X : Vec4) : Q4 (B4 eta X) = Q4 X := by
  obtain ⟨t, x, y, z⟩ := X
  have h := Real.cosh_sq_sub_sinh_sq eta
  simp only [B4_apply, Q4_apply]
  nlinarith [h, sq_nonneg t, sq_nonneg x]

/-- Invariance of the 1+1 Lorentz form under the longitudinal boost. -/
theorem Q2_B (eta : ℝ) (X : Long) : Q2 (B eta X) = Q2 X := by
  obtain ⟨t, x⟩ := X
  have h := Real.cosh_sq_sub_sinh_sq eta
  simp only [B_apply, Q2_apply]
  nlinarith [h, sq_nonneg t, sq_nonneg x]

/-- The boost acts on `e₊` by the factor `exp η`. -/
theorem B_ep (eta : ℝ) : B eta ep = Real.exp eta • ep := by
  have h : cosh eta + sinh eta = Real.exp eta := Real.cosh_add_sinh eta
  rw [ep_eq]
  refine Prod.ext ?_ ?_ <;>
    simp only [B_apply, Prod.smul_mk, smul_eq_mul] <;>
    · rw [← h]; ring

/-- The boost acts on `e₋` by the factor `exp (-η)`. -/
theorem B_em (eta : ℝ) : B eta em = Real.exp (-eta) • em := by
  have h : cosh eta - sinh eta = Real.exp (-eta) := Real.cosh_sub_sinh eta
  rw [em_eq]
  refine Prod.ext ?_ ?_ <;>
    simp only [B_apply, Prod.smul_mk, smul_eq_mul] <;>
    · rw [← h]; ring

/-- **Acceptance criterion 6.**  In complementary null coordinates the boost acts
by reciprocal scaling. -/
theorem B_P (eta a b : ℝ) : B eta (P a b) = P (Real.exp eta * a) (Real.exp (-eta) * b) := by
  have hp : cosh eta + sinh eta = Real.exp eta := Real.cosh_add_sinh eta
  have hm : cosh eta - sinh eta = Real.exp (-eta) := Real.cosh_sub_sinh eta
  rw [P_eq, P_eq]
  refine Prod.ext ?_ ?_ <;> simp only [B_apply] <;> rw [← hp, ← hm] <;> ring

/-- The null coefficients transform multiplicatively. -/
theorem qp_B (eta : ℝ) (X : Long) : qp (B eta X) = Real.exp eta * qp X := by
  rw [← P_qp_qm X, B_P]
  simp

theorem qm_B (eta : ℝ) (X : Long) : qm (B eta X) = Real.exp (-eta) * qm X := by
  rw [← P_qp_qm X, B_P]
  simp

/-! ## Invariance of the product of complementary coefficients

Two independent proofs are given.
-/

/-- **Proof 1 (direct).**  Depends only on `Real.exp_neg` / `Real.exp_ne_zero`,
not on any Lorentz-invariance statement. -/
theorem invProd_boost_direct (eta a b : ℝ) :
    invProd (Real.exp eta * a) (Real.exp (-eta) * b) = invProd a b := by
  simp only [invProd, Real.exp_neg]
  field_simp

/-- **Proof 2 (as a corollary of Lorentz invariance).**  Depends on `Q2_B`
(invariance of the quadratic form) and `Q2_P` (the null-coordinate formula for
the quadratic form), and on `B_P`. -/
theorem invProd_boost_via_Q2 (eta a b : ℝ) :
    invProd (Real.exp eta * a) (Real.exp (-eta) * b) = invProd a b := by
  have h1 : Q2 (B eta (P a b)) = Q2 (P a b) := Q2_B eta (P a b)
  rw [B_P, Q2_P, Q2_P] at h1
  exact h1

end NullSectorTask01
