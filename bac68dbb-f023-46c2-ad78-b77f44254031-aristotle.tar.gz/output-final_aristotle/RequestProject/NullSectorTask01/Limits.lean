import RequestProject.NullSectorTask01.Strata
import RequestProject.NullSectorTask01.Boost

/-!
# Task 01, Layer 5: the two elementary boundary families and the two limiting regimes

`Long = ℝ × ℝ` carries its standard (finite-dimensional real, product) topology,
and all limits below are genuine topological limits with respect to it, taken
along the filter `𝓝[>] 0` of the punctured right neighbourhood of `0`.
-/

namespace NullSectorTask01

open Filter Topology

/-- `P` is continuous in each argument (jointly, in fact). -/
theorem continuous_P : Continuous fun p : ℝ × ℝ => P p.1 p.2 := by
  have : (fun p : ℝ × ℝ => P p.1 p.2) = fun p : ℝ × ℝ => ((p.1 + p.2) / 2, (p.1 - p.2) / 2) := by
    funext p; exact P_eq p.1 p.2
  rw [this]
  fun_prop

theorem continuous_P_right (a : ℝ) : Continuous fun b : ℝ => P a b := by
  have h : (fun b : ℝ => P a b) = fun b : ℝ => ((a + b) / 2, (a - b) / 2) :=
    funext fun b => P_eq a b
  rw [h]; fun_prop

theorem continuous_P_left (b : ℝ) : Continuous fun a : ℝ => P a b := by
  have h : (fun a : ℝ => P a b) = fun a : ℝ => ((a + b) / 2, (a - b) / 2) :=
    funext fun a => P_eq a b
  rw [h]; fun_prop

/-! ## The `+` boundary family -/

/-- The `+` boundary family with the first coefficient held fixed at `a₀`. -/
noncomputable def Fp (a0 : ℝ) (eps : ℝ) : Long := P a0 eps

/-- The `-` boundary family with the second coefficient held fixed at `b₀`. -/
noncomputable def Fm (b0 : ℝ) (eps : ℝ) : Long := P eps b0

theorem Q2_Fp (a0 eps : ℝ) : Q2 (Fp a0 eps) = a0 * eps := by
  rw [Fp, Q2_P, invProd_def]

theorem Q2_Fm (b0 eps : ℝ) : Q2 (Fm b0 eps) = eps * b0 := by
  rw [Fm, Q2_P, invProd_def]

theorem Fp_zero_mem_plusBoundary {a0 : ℝ} (h : 0 < a0) : IsPlusBoundary a0 0 :=
  ⟨h, rfl⟩

theorem Fp_pos_mem_interior {a0 eps : ℝ} (h : 0 < a0) (he : 0 < eps) : IsInterior a0 eps :=
  ⟨h, he⟩

theorem Fm_zero_mem_minusBoundary {b0 : ℝ} (h : 0 < b0) : IsMinusBoundary 0 b0 :=
  ⟨rfl, h⟩

theorem Fm_pos_mem_interior {b0 eps : ℝ} (h : 0 < b0) (he : 0 < eps) : IsInterior eps b0 :=
  ⟨he, h⟩

/-! ## Regime A: one coefficient fixed, the other tending to `0⁺` -/

/-- **Acceptance criterion 8 (vector-level limit).**  `P (a₀, ε) → P (a₀, 0)` as
`ε → 0⁺`, as a topological limit in the carrier `Long`. -/
theorem tendsto_Fp (a0 : ℝ) :
    Tendsto (fun eps : ℝ => Fp a0 eps) (𝓝[>] (0 : ℝ)) (𝓝 (P a0 0)) :=
  ((continuous_P_right a0).tendsto 0).mono_left nhdsWithin_le_nhds

/-- The symmetric statement for the `-` family. -/
theorem tendsto_Fm (b0 : ℝ) :
    Tendsto (fun eps : ℝ => Fm b0 eps) (𝓝[>] (0 : ℝ)) (𝓝 (P 0 b0)) :=
  ((continuous_P_left b0).tendsto 0).mono_left nhdsWithin_le_nhds

/-- In Regime A the quadratic form tends to `0`. -/
theorem tendsto_Q2_Fp (a0 : ℝ) :
    Tendsto (fun eps : ℝ => Q2 (Fp a0 eps)) (𝓝[>] (0 : ℝ)) (𝓝 0) := by
  have h : (fun eps : ℝ => Q2 (Fp a0 eps)) = fun eps : ℝ => a0 * eps := by
    funext eps; exact Q2_Fp a0 eps
  rw [h]
  have : Tendsto (fun eps : ℝ => a0 * eps) (𝓝 (0 : ℝ)) (𝓝 (a0 * 0)) :=
    (continuous_const.mul continuous_id).tendsto 0
  simpa using this.mono_left nhdsWithin_le_nhds

theorem tendsto_Q2_Fm (b0 : ℝ) :
    Tendsto (fun eps : ℝ => Q2 (Fm b0 eps)) (𝓝[>] (0 : ℝ)) (𝓝 0) := by
  have h : (fun eps : ℝ => Q2 (Fm b0 eps)) = fun eps : ℝ => eps * b0 := by
    funext eps; exact Q2_Fm b0 eps
  rw [h]
  have : Tendsto (fun eps : ℝ => eps * b0) (𝓝 (0 : ℝ)) (𝓝 (0 * b0)) :=
    (continuous_id.mul continuous_const).tendsto 0
  simpa using this.mono_left nhdsWithin_le_nhds

/-! ## Regime B: the product of the coefficients held fixed -/

/-- The branch of the level set `a b = I` parameterized by the second coefficient. -/
noncomputable def G (I : ℝ) (b : ℝ) : Long := P (I / b) b

/-- On this branch the quadratic form is constantly `I`. -/
theorem Q2_G {I b : ℝ} (hb : b ≠ 0) : Q2 (G I b) = I := by
  rw [G, Q2_P, invProd_def, div_mul_cancel₀ _ hb]

/-- The first ordinary coordinate of the Regime-B branch diverges as `b → 0⁺`. -/
theorem tendsto_G_fst_atTop {I : ℝ} (hI : 0 < I) :
    Tendsto (fun b : ℝ => (G I b).1) (𝓝[>] (0 : ℝ)) atTop := by
  have hdiv : Tendsto (fun b : ℝ => I / b) (𝓝[>] (0 : ℝ)) atTop := by
    have h := (tendsto_inv_nhdsGT_zero (𝕜 := ℝ)).const_mul_atTop hI
    simpa [div_eq_mul_inv] using h
  have hid : Tendsto (fun b : ℝ => b) (𝓝[>] (0 : ℝ)) (𝓝 0) :=
    tendsto_id.mono_left nhdsWithin_le_nhds
  have hsum : Tendsto (fun b : ℝ => I / b + b) (𝓝[>] (0 : ℝ)) atTop := hdiv.atTop_add hid
  have : (fun b : ℝ => (G I b).1) = fun b : ℝ => (I / b + b) / 2 := by
    funext b; simp [G]
  rw [this]
  exact hsum.atTop_div_const (by norm_num)

/-- **Regime B has no finite vector limit.**  The branch `G` is unbounded in its
first ordinary coordinate, hence does not converge in `Long` as `b → 0⁺`. -/
theorem not_tendsto_G {I : ℝ} (hI : 0 < I) :
    ¬ ∃ L : Long, Tendsto (fun b : ℝ => G I b) (𝓝[>] (0 : ℝ)) (𝓝 L) := by
  rintro ⟨L, hL⟩
  have hfst : Tendsto (fun b : ℝ => (G I b).1) (𝓝[>] (0 : ℝ)) (𝓝 L.1) :=
    (continuous_fst.tendsto L).comp hL
  exact not_tendsto_nhds_of_tendsto_atTop (tendsto_G_fst_atTop hI) L.1 hfst

/-- Concrete unboundedness statement for Regime B. -/
theorem G_unbounded {I : ℝ} (hI : 0 < I) (M : ℝ) :
    ∀ d > 0, ∃ b : ℝ, 0 < b ∧ b < d ∧ M < (G I b).1 := by
  intro d hd
  have h := (tendsto_G_fst_atTop hI).eventually_gt_atTop M
  rw [eventually_nhdsWithin_iff, Metric.eventually_nhds_iff] at h
  obtain ⟨r, hr, hball⟩ := h
  have hmin : (0 : ℝ) < min (r / 2) (d / 2) := lt_min (by linarith) (by linarith)
  refine ⟨min (r / 2) (d / 2), hmin, ?_, ?_⟩
  · calc min (r / 2) (d / 2) ≤ d / 2 := min_le_right _ _
      _ < d := by linarith
  · refine hball ?_ hmin
    have h1 : min (r / 2) (d / 2) ≤ r / 2 := min_le_left _ _
    rw [Real.dist_eq, sub_zero, abs_of_pos hmin]
    linarith

end NullSectorTask01
