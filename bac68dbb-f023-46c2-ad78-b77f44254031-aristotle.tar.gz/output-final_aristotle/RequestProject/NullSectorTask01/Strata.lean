import RequestProject.NullSectorTask01.SplitComplex

/-!
# Task 01, Layer 4: the future-causal coefficient sector and its strata

Everything here is an elementary statement about the closed quadrant
`{(a,b) : 0 ≤ a ∧ 0 ≤ b}` of complementary null coefficients.  The terminology
(`zero`, `plusBoundary`, `minusBoundary`, `interior`) is purely geometric.
-/

namespace NullSectorTask01

/-- The closed coefficient quadrant. -/
def FutureCausalCoeff (a b : ℝ) : Prop := 0 ≤ a ∧ 0 ≤ b

/-- The future-causal longitudinal cone, written in ordinary coordinates. -/
def FutureCausalVec (X : Long) : Prop := 0 ≤ X.1 ∧ 0 ≤ Q2 X

/-- **Acceptance criterion 5 (sector correspondence).**  The closed coefficient
quadrant corresponds exactly to the future-causal longitudinal cone. -/
theorem futureCausal_iff (a b : ℝ) : FutureCausalCoeff a b ↔ FutureCausalVec (P a b) := by
  constructor
  · rintro ⟨ha, hb⟩
    refine ⟨?_, ?_⟩
    · simp only [P_fst]; linarith
    · rw [Q2_P]; exact mul_nonneg ha hb
  · rintro ⟨ht, hq⟩
    rw [Q2_P, invProd_def] at hq
    simp only [P_fst] at ht
    have hsum : 0 ≤ a + b := by linarith
    constructor
    · nlinarith
    · nlinarith

/-- Every future-causal longitudinal vector arises from the quadrant. -/
theorem futureCausalVec_iff (X : Long) :
    FutureCausalVec X ↔ FutureCausalCoeff (qp X) (qm X) := by
  rw [futureCausal_iff, P_qp_qm]

/-! ## The four strata -/

/-- The zero stratum. -/
def IsZero (a b : ℝ) : Prop := a = 0 ∧ b = 0

/-- The `+` boundary stratum. -/
def IsPlusBoundary (a b : ℝ) : Prop := 0 < a ∧ b = 0

/-- The `-` boundary stratum. -/
def IsMinusBoundary (a b : ℝ) : Prop := a = 0 ∧ 0 < b

/-- The interior stratum. -/
def IsInterior (a b : ℝ) : Prop := 0 < a ∧ 0 < b

/-- **Exhaustiveness.**  Every point of the closed quadrant lies in exactly one
of the four strata (existence part). -/
theorem strata_exhaustive {a b : ℝ} (h : FutureCausalCoeff a b) :
    IsZero a b ∨ IsPlusBoundary a b ∨ IsMinusBoundary a b ∨ IsInterior a b := by
  obtain ⟨ha, hb⟩ := h
  rcases eq_or_lt_of_le ha with ha0 | ha0
  · rcases eq_or_lt_of_le hb with hb0 | hb0
    · exact Or.inl ⟨ha0.symm, hb0.symm⟩
    · exact Or.inr (Or.inr (Or.inl ⟨ha0.symm, hb0⟩))
  · rcases eq_or_lt_of_le hb with hb0 | hb0
    · exact Or.inr (Or.inl ⟨ha0, hb0.symm⟩)
    · exact Or.inr (Or.inr (Or.inr ⟨ha0, hb0⟩))

/-- **Mutual exclusivity**, in the form of pairwise disjointness. -/
theorem strata_disjoint (a b : ℝ) :
    ¬(IsZero a b ∧ IsPlusBoundary a b) ∧
    ¬(IsZero a b ∧ IsMinusBoundary a b) ∧
    ¬(IsZero a b ∧ IsInterior a b) ∧
    ¬(IsPlusBoundary a b ∧ IsMinusBoundary a b) ∧
    ¬(IsPlusBoundary a b ∧ IsInterior a b) ∧
    ¬(IsMinusBoundary a b ∧ IsInterior a b) := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩ <;>
    rintro ⟨h1, h2⟩ <;>
    simp only [IsZero, IsPlusBoundary, IsMinusBoundary, IsInterior] at h1 h2 <;>
    obtain ⟨x1, y1⟩ := h1 <;> obtain ⟨x2, y2⟩ := h2 <;> linarith

/-! ## Quadratic form on the strata -/

theorem Q2_of_plusBoundary {a b : ℝ} (h : IsPlusBoundary a b) : Q2 (P a b) = 0 := by
  rw [Q2_P, invProd_def, h.2, mul_zero]

theorem Q2_of_minusBoundary {a b : ℝ} (h : IsMinusBoundary a b) : Q2 (P a b) = 0 := by
  rw [Q2_P, invProd_def, h.1, zero_mul]

theorem Q2_of_zero {a b : ℝ} (h : IsZero a b) : Q2 (P a b) = 0 := by
  rw [Q2_P, invProd_def, h.1, zero_mul]

theorem Q2_of_interior {a b : ℝ} (h : IsInterior a b) : 0 < Q2 (P a b) := by
  rw [Q2_P, invProd_def]; exact mul_pos h.1 h.2

/-- Converse inside the sector: vanishing of the quadratic form forces a
boundary (or zero) stratum. -/
theorem strata_of_Q2_eq_zero {a b : ℝ} (h : FutureCausalCoeff a b) (hq : Q2 (P a b) = 0) :
    IsZero a b ∨ IsPlusBoundary a b ∨ IsMinusBoundary a b := by
  rw [Q2_P, invProd_def] at hq
  rcases strata_exhaustive h with h0 | hp | hm | hi
  · exact Or.inl h0
  · exact Or.inr (Or.inl hp)
  · exact Or.inr (Or.inr hm)
  · exact absurd hq (ne_of_gt (mul_pos hi.1 hi.2))

/-- Converse inside the sector: strict positivity of the quadratic form
characterizes the interior stratum. -/
theorem interior_of_Q2_pos {a b : ℝ} (h : FutureCausalCoeff a b) (hq : 0 < Q2 (P a b)) :
    IsInterior a b := by
  rw [Q2_P, invProd_def] at hq
  obtain ⟨ha, hb⟩ := h
  refine ⟨lt_of_le_of_ne ha ?_, lt_of_le_of_ne hb ?_⟩ <;> rintro rfl <;> simp at hq

theorem Q2_pos_iff_interior {a b : ℝ} (h : FutureCausalCoeff a b) :
    0 < Q2 (P a b) ↔ IsInterior a b :=
  ⟨interior_of_Q2_pos h, Q2_of_interior⟩

theorem Q2_eq_zero_iff {a b : ℝ} (h : FutureCausalCoeff a b) :
    Q2 (P a b) = 0 ↔ (IsZero a b ∨ IsPlusBoundary a b ∨ IsMinusBoundary a b) := by
  refine ⟨strata_of_Q2_eq_zero h, ?_⟩
  rintro (h0 | hp | hm)
  · exact Q2_of_zero h0
  · exact Q2_of_plusBoundary hp
  · exact Q2_of_minusBoundary hm

/-- Nonzero states in the sector are classified by exactly three strata. -/
theorem nonzero_strata_trichotomy {a b : ℝ} (h : FutureCausalCoeff a b)
    (hne : ¬ IsZero a b) :
    IsPlusBoundary a b ∨ IsMinusBoundary a b ∨ IsInterior a b := by
  rcases strata_exhaustive h with h0 | hp | hm | hi
  · exact absurd h0 hne
  · exact Or.inl hp
  · exact Or.inr (Or.inl hm)
  · exact Or.inr (Or.inr hi)

end NullSectorTask01
