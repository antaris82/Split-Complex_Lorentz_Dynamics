import RequestProject.NullSectorTask15.RateSeparation

/-!
# Task 15, Layer 6 (§VII, §IX): exactly what remains free, and the final verdict

This layer states, with a theorem for each row, the exact type of the surviving freedom,
and it repairs nothing: no familiar structure is added to close the remaining gap.

| candidate datum | status | theorem |
| --- | --- | --- |
| free constants only | **too small** | `central_rates_not_constant` |
| free functions of the direction | **exactly this** | `regular_family_exact_parametrization` |
| free functions of the path parameter | **excluded** | `no_free_path_function` |
| path/history-dependent central data | **still present** (inherited `±1`) | `regular_closed_path_residual` |
| obstruction to any global regular choice | **no** | `global_regular_lift_exists` |

The §IX verdict is therefore alternative **3**: *direction-dependent central state data
survive*, with the exact class of the missing datum recorded in
`task15_missing_datum_class`.
-/

namespace NullSectorTask15

open NullSectorTask01 NullSectorTask04 NullSectorTask06 NullSectorTask07 NullSectorTask08
open NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12 NullSectorTask13
open NullSectorTask14

/-! ## §VII — the exact parametrization of the surviving freedom -/

/-- **PRINCIPAL THEOREM (§VII): the surviving freedom is exactly two real functions of the
direction.**  Every regular multi-axis lift is the family attached to its own two rate
functions, and every pair of rate functions occurs. -/
theorem regular_family_exact_parametrization :
    (∀ U : Vec3 → ℝ → W, IsRegularFamily U → ∀ n : Vec3, IsUnitAxis n → ∀ θ : ℝ,
        U n θ = famOf (rateAlpha U) (rateBeta U) n θ) ∧
      (∀ a b : Vec3 → ℝ, IsRegularFamily (famOf a b) ∧
        ∀ n : Vec3, IsUnitAxis n →
          rateAlpha (famOf a b) n = a n ∧ rateBeta (famOf a b) n = b n) :=
  ⟨fun _ hU _ hn θ => regularFamily_param_spec hU hn θ,
    fun a b => regular_family_arbitrary_parameters a b⟩

/-- **PRINCIPAL THEOREM (§VII), negative control: the freedom is strictly larger than a pair
of constants.**  There is a regular multi-axis lift whose first central rate takes different
values in two different directions. -/
theorem central_rates_not_constant :
    ∃ U : Vec3 → ℝ → W, IsRegularFamily U ∧ rateAlpha U axA ≠ rateAlpha U axB := by
  classical
  obtain ⟨hfam, hpar⟩ := regular_family_arbitrary_parameters
    (fun k => if k = axA then (1 : ℝ) else 0) (fun _ => 0)
  refine ⟨_, hfam, ?_⟩
  rw [(hpar axA axA_unit).1, (hpar axB axB_unit).1]
  have hne : axB ≠ axA := by
    intro hcon
    have := congrArg Prod.fst hcon
    simp [axA, axB] at this
  simp [hne]

/-- **PRINCIPAL THEOREM (§VII), negative control: no free function of the path parameter
survives.**  Once the direction is fixed, the whole parameter dependence of a regular lift
is determined by two real numbers, and these are unique. -/
theorem no_free_path_function {n : Vec3} (hn : IsUnitAxis n) (U : ℝ → W) :
    IsContinuousAxisLift n U ↔ ∃ α β : ℝ, ∀ θ, U θ = zexp α β θ ⋆ Un n θ :=
  continuousAxisLift_classification hn U

/-- **PRINCIPAL THEOREM (§VII): path-dependent central data are *not* removed by
regularity.**  For every regular multi-axis lift the internal element of the inherited
closed mixed path is the accumulated central residual multiplied by the inherited defect
`-1`, while the induced algebra automorphism is the identity. -/
theorem regular_closed_path_residual {U : Vec3 → ℝ → W} {z : Vec3 → ℝ → W}
    (hz : ∀ n θ, z n θ ∈ Z) (hU : ∀ n θ, U n θ = z n θ ⋆ Un n θ) :
    liftWordVal U closedPath = zWord z closedPath ⋆ (-w1) ∧
      wordAut closedPath = LinearMap.id := by
  refine ⟨?_, closed_path_internal_residual.1⟩
  rw [regular_word_factor hz hU, closedPath_val]

/-- **PRINCIPAL THEOREM (§VII), negative control: global regular lifts do exist.**  The
obstruction of Task 14 concerns exact multiplicativity of an assignment defined on
*transformations*; it does not obstruct the existence of a regular multi-axis lift.  The
inherited reference family is the member with vanishing central rates. -/
theorem global_regular_lift_exists :
    IsRegularFamily (famOf (fun _ => 0) (fun _ => 0)) ∧
      (∀ n : Vec3, ∀ θ : ℝ, famOf (fun _ => 0) (fun _ => 0) n θ = Un n θ) := by
  refine ⟨(regular_family_arbitrary_parameters _ _).1, fun n θ => ?_⟩
  rw [famOf, zexp]
  norm_num
  exact one_mul_W (Un n θ)

/-! ## §IX — the final verdict -/

/-- **THE TASK-15 VERDICT (§IX): alternative 3 — direction-dependent central state data
survive.**

1. Regular multi-axis lifts exist, so alternative 5 (no global regular lift) is refuted.
2. Every regular multi-axis lift is *exactly* the exponential–rotation family attached to
   two real rate functions of the direction, so nothing beyond two real numbers per
   direction survives — and nothing less.
3. Both rate functions are completely free, so alternative 1 (unique closure) is refuted;
   they need not be constant, so alternative 2 (one global two-parameter freedom) is
   refuted as well. -/
theorem task15_final_verdict :
    IsRegularFamily (famOf (fun _ => 0) (fun _ => 0)) ∧
      (∀ U : Vec3 → ℝ → W, IsRegularFamily U → ∀ n : Vec3, IsUnitAxis n → ∀ θ : ℝ,
        U n θ = zexp (rateAlpha U n) (rateBeta U n) θ ⋆ Un n θ) ∧
      (∀ a b : Vec3 → ℝ, IsRegularFamily (famOf a b) ∧
        ∀ n : Vec3, IsUnitAxis n →
          rateAlpha (famOf a b) n = a n ∧ rateBeta (famOf a b) n = b n) ∧
      (∃ U : Vec3 → ℝ → W, IsRegularFamily U ∧ rateAlpha U axA ≠ rateAlpha U axB) :=
  ⟨global_regular_lift_exists.1,
    fun _ hU _ hn θ => regularFamily_param_spec hU hn θ,
    fun a b => regular_family_arbitrary_parameters a b,
    central_rates_not_constant⟩

/-- **THE MISSING DATUM (§VII, §IX).**  The exact class of the datum that would still be
required to determine the central residual: a choice, for every unit direction, of an
element of `ℝ × ℝ` — equivalently a section of the trivial `ℝ²`-bundle over the set of unit
directions.  The statement below is the formal content of that claim: the assignment of the
rate pair to a regular family is surjective onto all such sections and determines the family
completely, so the missing datum is exactly one section and nothing more. -/
theorem task15_missing_datum_class :
    (∀ a b : Vec3 → ℝ, ∃ U : Vec3 → ℝ → W, IsRegularFamily U ∧
        ∀ n : Vec3, IsUnitAxis n → rateAlpha U n = a n ∧ rateBeta U n = b n) ∧
      (∀ U V : Vec3 → ℝ → W, IsRegularFamily U → IsRegularFamily V →
        (∀ n : Vec3, IsUnitAxis n → rateAlpha U n = rateAlpha V n ∧
            rateBeta U n = rateBeta V n) →
        ∀ n : Vec3, IsUnitAxis n → ∀ θ : ℝ, U n θ = V n θ) := by
  refine ⟨fun a b => ⟨famOf a b, (regular_family_arbitrary_parameters a b).1,
      fun n hn => (regular_family_arbitrary_parameters a b).2 n hn⟩, ?_⟩
  intro U V hU hV hrate n hn θ
  rw [regularFamily_param_spec hU hn θ, regularFamily_param_spec hV hn θ,
    (hrate n hn).1, (hrate n hn).2]

end NullSectorTask15
