import RequestProject.NullSectorTask15.ResidualAudit

/-!
# Task 15, Layer 7 (§VIII): late structural comparison — **COMPARISON ONLY**

This module is imported by nothing except `RequestProject.NullSectorTask15.Task15`, and no
reconstruction result of Layers 0–6 depends on it.  Sections III–VII were completed before
it was written, and the comparison below is *purely structural*: it compares dependency
counts, never contents.

The earlier formalized heuristic situation of the very first task in this project had

```
two independently variable real quantities  +  one compatibility relation
      →  one residual degree of freedom.
```

The question asked in §VIII is whether the independently derived Task-15 central-rate
problem has the same *dependency shape*.  The theorem below records the answer as it was
proved in Layers 4–6:

* two independent real residual rates survive per direction — and they are not even tied
  across directions;
* multi-axis coherence supplies **no** additional independent relation;
* neither rate becomes a function of the other;
* consequently the structure is *not* "two quantities minus one relation": it is
  "two quantities minus **zero** relations", i.e. the underdetermination is strictly
  larger than the earlier Option-C shape;
* only the strictly stronger transformation-valued requirement supplies relations, and
  those close the first rate completely while leaving the second discretely free — a
  dependency shape different from Option C in both directions.

No heuristic dictionary between the rates and any earlier informal quantity is asserted
anywhere; the comparison is at the level of counts of free parameters and relations only.
-/

namespace NullSectorTask15

open NullSectorTask01 NullSectorTask04 NullSectorTask06 NullSectorTask07 NullSectorTask08
open NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12 NullSectorTask13
open NullSectorTask14

/-- **COMPARISON ONLY (§VIII).**  The structural comparison with the earlier
underdetermination, stated exactly as it follows from Layers 4–6.

1. *Both rates survive and are mutually independent*: for every pair of real numbers there
   is a regular lift realizing them in a prescribed direction, so fixing one value
   constrains the other in no way.
2. *No additional relation from multi-axis coherence*: two different directions may carry
   two completely unrelated pairs.
3. *One further relation appears only under the stronger transformation-valued
   requirement*, and it closes the first rate (`α = 0`) while the second survives in a
   discrete set. -/
theorem optionC_structural_comparison :
    (∀ (n : Vec3), IsUnitAxis n → ∀ a₁ b₁ : ℝ, ∃ U : Vec3 → ℝ → W, IsRegularFamily U ∧
        rateAlpha U n = a₁ ∧ rateBeta U n = b₁) ∧
      (∀ (n m : Vec3), IsUnitAxis n → IsUnitAxis m → n ≠ m → ∀ a₁ b₁ a₂ b₂ : ℝ,
        ∃ U : Vec3 → ℝ → W, IsRegularFamily U ∧
          rateAlpha U n = a₁ ∧ rateBeta U n = b₁ ∧
          rateAlpha U m = a₂ ∧ rateBeta U m = b₂) ∧
      (∀ U : Vec3 → ℝ → W, IsRegularFamily U → IsTransformationValued U →
        ∀ n : Vec3, IsUnitAxis n →
          rateAlpha U n = 0 ∧ ∃ k : ℤ, rateBeta U n = k + 1 / 2) := by
  refine ⟨fun n hn a₁ b₁ => ?_, fun n m hn hm hnm a₁ b₁ a₂ b₂ =>
      central_rates_independent_across_axes hn hm hnm a₁ b₁ a₂ b₂, fun U hU hV n hn =>
      ⟨autValued_forces_alpha_zero hU hV hn, autValued_forces_beta_half_odd hU hV hn⟩⟩
  obtain ⟨hfam, hpar⟩ := regular_family_arbitrary_parameters (fun _ => a₁) (fun _ => b₁)
  exact ⟨_, hfam, (hpar n hn).1, (hpar n hn).2⟩

end NullSectorTask15
