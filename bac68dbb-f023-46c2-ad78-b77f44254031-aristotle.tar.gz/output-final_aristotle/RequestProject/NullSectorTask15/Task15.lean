import RequestProject.NullSectorTask15.OptionCAudit

/-!
# Task 15 — top module: principal theorem set and axiom report

This module imports the complete Task-15 development and exposes the principal results.
Each exposed name is an alias of the theorem proved in the corresponding layer; no new
mathematics happens here.

Layer order:

```
Task15.SafeBase
  → RegularLift          (§III, continuity layer)
  → DifferentiableLift   (§III, stronger regularity layer)
  → MixedComposition     (§IV)
  → Infinitesimal        (§V)
  → RateSeparation       (§VI)
  → ResidualAudit        (§VII, §IX)
  → OptionCAudit         (§VIII, COMPARISON ONLY)
```

The `#print axioms` block at the end is the axiom report.
-/

namespace NullSectorTask15

/-! ## §III — regular one-axis lifts -/

alias task15_axis_lift_factorization := axisLift_iff
alias task15_axis_lift_residual_unique := axisLift_residual_unique
alias task15_continuous_lift_classification := continuousAxisLift_classification
alias task15_continuous_lift_parameters_unique := continuousAxisLift_parameters_unique
alias task15_differentiability_not_stronger := continuousAxisLift_differentiable
alias task15_differentiable_lift_classification := differentiableAxisLift_classification

/-! ## §IV — the finite central composition law -/

alias task15_central_discrepancy_central := central_discrepancy_mem_Z
alias task15_composition_law := composition_law
alias task15_central_discrepancy_unit := central_discrepancy_unit
alias task15_central_discrepancy_assoc := central_discrepancy_assoc
alias task15_central_discrepancy_normalization := central_discrepancy_units
alias task15_central_discrepancy_redefinition := central_discrepancy_redefinition
alias task15_regular_word_factor := regular_word_factor
alias task15_regular_word_defect_split := regular_word_defect_split
alias task15_mixed_regular_central_defect := mixed_regular_central_defect

/-! ## §V — the infinitesimal central residual -/

alias task15_regular_generator := hasDerivAt_regularLift_zero
alias task15_family_parameters := regularFamily_param_spec
alias task15_family_parameters_unique := regularFamily_param_unique
alias task15_central_residual_split := regularFamily_generator
alias task15_rates_arbitrary := regular_family_arbitrary_parameters
alias task15_rates_independent_across_axes := central_rates_independent_across_axes
alias task15_transformation_valued_alpha := autValued_forces_alpha_zero
alias task15_transformation_valued_beta := autValued_forces_beta_half_odd
alias task15_transformation_valued_antipodal := autValued_antipodal_odd
alias task15_central_rate_classification := central_rate_classification

/-! ## §VI — spatial rate versus central rate -/

alias task15_rate_family_generator := rateFam_generator
alias task15_generator_components_independent := generator_components_independent
alias task15_common_spatial_rate_leaves_central_free := common_spatial_rate_leaves_central_free
alias task15_central_rates_leave_spatial_rate_free := central_rates_leave_spatial_rate_free

/-! ## §VII, §IX — what remains free, and the verdict -/

alias task15_exact_parametrization := regular_family_exact_parametrization
alias task15_rates_not_constant := central_rates_not_constant
alias task15_no_free_path_function := no_free_path_function
alias task15_closed_path_residual := regular_closed_path_residual
alias task15_global_regular_lift_exists := global_regular_lift_exists
alias task15_verdict := task15_final_verdict
alias task15_missing_datum := task15_missing_datum_class

/-! ## §VIII — late structural comparison, COMPARISON ONLY -/

alias task15_optionC_comparison := optionC_structural_comparison

/-! ## Axiom report -/

#print axioms task15_axis_lift_factorization
#print axioms task15_axis_lift_residual_unique
#print axioms task15_continuous_lift_classification
#print axioms task15_continuous_lift_parameters_unique
#print axioms task15_differentiability_not_stronger
#print axioms task15_differentiable_lift_classification
#print axioms task15_central_discrepancy_central
#print axioms task15_composition_law
#print axioms task15_central_discrepancy_unit
#print axioms task15_central_discrepancy_assoc
#print axioms task15_central_discrepancy_normalization
#print axioms task15_central_discrepancy_redefinition
#print axioms task15_regular_word_factor
#print axioms task15_regular_word_defect_split
#print axioms task15_mixed_regular_central_defect
#print axioms task15_regular_generator
#print axioms task15_family_parameters
#print axioms task15_family_parameters_unique
#print axioms task15_central_residual_split
#print axioms task15_rates_arbitrary
#print axioms task15_rates_independent_across_axes
#print axioms task15_transformation_valued_alpha
#print axioms task15_transformation_valued_beta
#print axioms task15_transformation_valued_antipodal
#print axioms task15_central_rate_classification
#print axioms task15_rate_family_generator
#print axioms task15_generator_components_independent
#print axioms task15_common_spatial_rate_leaves_central_free
#print axioms task15_central_rates_leave_spatial_rate_free
#print axioms task15_exact_parametrization
#print axioms task15_rates_not_constant
#print axioms task15_no_free_path_function
#print axioms task15_closed_path_residual
#print axioms task15_global_regular_lift_exists
#print axioms task15_verdict
#print axioms task15_missing_datum
#print axioms task15_optionC_comparison

end NullSectorTask15
