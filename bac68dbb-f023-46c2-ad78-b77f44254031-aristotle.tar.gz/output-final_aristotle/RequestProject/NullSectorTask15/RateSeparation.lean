import RequestProject.NullSectorTask15.Infinitesimal

/-!
# Task 15, Layer 5 (§VI): the spatial rate and the central rates are independent

Two rate notions must be kept strictly apart.

1. The **spatial automorphism rate** `lam` of Task 14: the reparametrization
   `θ ↦ Un n (lam · θ)` of the inherited reference implementation, whose infinitesimal
   effect sits entirely in the derived generator direction `J n`.  Task 14 proved that a
   *linear* arbitrary-axis generator assignment forces one common spatial rate.

2. The **central residual generator** `α n • 1 + β n • S` of §V, which sits entirely in the
   exact centre.

This layer proves that the first has **no logical consequence** for the second.  The
generator of a rate-`lam` regular lift splits into two components living in disjoint
inherited coordinate directions, and the triple `(lam, α, β)` is recovered from the
generator injectively (`generator_components_independent`); every triple occurs
(`rateFam_generator`), even with one *common* spatial rate for all directions and
completely arbitrary central rates (`common_spatial_rate_leaves_central_free`).
-/

namespace NullSectorTask15

open NullSectorTask01 NullSectorTask04 NullSectorTask06 NullSectorTask07 NullSectorTask08
open NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12 NullSectorTask13
open NullSectorTask14

/-! ## Rate-reparametrized regular lifts -/

/-- **NEUTRAL DEFINITION (§VI).**  The regular lift of spatial rate `lam` with central rates
`a n, b n`. -/
noncomputable def rateFam (lam : ℝ) (a b : Vec3 → ℝ) (n : Vec3) (θ : ℝ) : W :=
  zexp (a n) (b n) θ ⋆ Un n (lam * θ)

@[simp] theorem rateFam_zero (lam : ℝ) (a b : Vec3 → ℝ) (n : Vec3) :
    rateFam lam a b n 0 = w1 := by
  rw [rateFam, mul_zero, Un_zero, zexp_zero, one_mul_W]

/-- **DERIVED (§VI).**  A rate-`lam` family obeys the reparametrized one-axis group law. -/
theorem rateFam_group {n : Vec3} (hn : IsUnitAxis n) (lam : ℝ) (a b : Vec3 → ℝ) (θ φ : ℝ) :
    rateFam lam a b n (θ + φ) = rateFam lam a b n θ ⋆ rateFam lam a b n φ := by
  have hz := (zexp_isCentralHom (a n) (b n)).mul θ φ
  have hzZ : zexp (a n) (b n) φ ∈ Z := by
    have := (zexp_isCentralHom (a n) (b n)).mem φ
    rwa [center_eq_Z] at this
  rw [rateFam, rateFam, rateFam, hz, mul_add, Un_group hn]
  exact (central_pair_shuffle hzZ (Un n (lam * θ)) (Un n (lam * φ))).symm

/-- **DERIVED (§VI).**  A rate-`lam` family implements the reparametrized inherited
automorphism family. -/
theorem rateFam_conj (n : Vec3) (lam : ℝ) (a b : Vec3 → ℝ) (θ : ℝ) (x : W) :
    (rateFam lam a b n θ ⋆ x) ⋆ rateFam lam a b n (-θ) = PhiGen n (lam * θ) x := by
  have hinv : zexp (a n) (b n) θ ⋆ zexp (a n) (b n) (-θ) = w1 := by
    have h := (zexp_isCentralHom (a n) (b n)).mul θ (-θ)
    rw [add_neg_cancel, (zexp_isCentralHom (a n) (b n)).unit] at h
    exact h.symm
  have hzZ : zexp (a n) (b n) (-θ) ∈ Z := by
    have := (zexp_isCentralHom (a n) (b n)).mem (-θ)
    rwa [center_eq_Z] at this
  have harg : lam * -θ = -(lam * θ) := by ring
  calc (rateFam lam a b n θ ⋆ x) ⋆ rateFam lam a b n (-θ)
      = ((zexp (a n) (b n) θ ⋆ Un n (lam * θ)) ⋆ x)
          ⋆ (zexp (a n) (b n) (-θ) ⋆ Un n (-(lam * θ))) := by rw [rateFam, rateFam, harg]
    _ = (zexp (a n) (b n) θ ⋆ zexp (a n) (b n) (-θ))
          ⋆ ((Un n (lam * θ) ⋆ x) ⋆ Un n (-(lam * θ))) := by
        rw [mul_assoc_W (zexp (a n) (b n) θ) (Un n (lam * θ)) x]
        rw [central_pair_shuffle hzZ (Un n (lam * θ) ⋆ x) (Un n (-(lam * θ)))]
    _ = PhiGen n (lam * θ) x := by rw [hinv, one_mul_W]; rfl

/-! ## The generator of a rate-reparametrized regular lift -/

private theorem hasDerivAt_expc' (α : ℝ) (θ : ℝ) :
    HasDerivAt (fun t : ℝ => Real.exp (α * t)) (Real.exp (α * θ) * α) θ := by
  have h : HasDerivAt (fun t : ℝ => α * t) α θ := by
    simpa using (hasDerivAt_id θ).const_mul α
  simpa using h.exp

private theorem hasDerivAt_cosc' (β : ℝ) (θ : ℝ) :
    HasDerivAt (fun t : ℝ => Real.cos (β * t)) (-Real.sin (β * θ) * β) θ := by
  have h : HasDerivAt (fun t : ℝ => β * t) β θ := by
    simpa using (hasDerivAt_id θ).const_mul β
  simpa using h.cos

private theorem hasDerivAt_sinc' (β : ℝ) (θ : ℝ) :
    HasDerivAt (fun t : ℝ => Real.sin (β * t)) (Real.cos (β * θ) * β) θ := by
  have h : HasDerivAt (fun t : ℝ => β * t) β θ := by
    simpa using (hasDerivAt_id θ).const_mul β
  simpa using h.sin

private theorem hasDerivAt_coshl (lam : ℝ) (θ : ℝ) :
    HasDerivAt (fun t : ℝ => Real.cos (lam * t / 2)) (-Real.sin (lam * θ / 2) * (lam / 2)) θ := by
  have h : HasDerivAt (fun t : ℝ => lam * t / 2) (lam / 2) θ := by
    simpa using ((hasDerivAt_id θ).const_mul lam).div_const 2
  simpa using h.cos

private theorem hasDerivAt_sinhl (lam : ℝ) (θ : ℝ) :
    HasDerivAt (fun t : ℝ => Real.sin (lam * t / 2)) (Real.cos (lam * θ / 2) * (lam / 2)) θ := by
  have h : HasDerivAt (fun t : ℝ => lam * t / 2) (lam / 2) θ := by
    simpa using ((hasDerivAt_id θ).const_mul lam).div_const 2
  simpa using h.sin

/-- **PRINCIPAL THEOREM (§VI): the generator of a rate-`lam` regular lift.**  The spatial
rate appears only in the derived generator direction, the central rates only in the exact
centre. -/
theorem rateFam_generator (lam : ℝ) (a b : Vec3 → ℝ) (n : Vec3) :
    HasDerivAt (rateFam lam a b n)
      (zc (a n) (b n) - (lam * 2⁻¹ : ℝ) • Jmap n) 0 := by
  have he : rateFam lam a b n = fun θ : ℝ =>
      (Real.exp (a n * θ) * Real.cos (b n * θ) * Real.cos (lam * θ / 2)) • w1
      + (Real.exp (a n * θ) * Real.sin (b n * θ) * Real.cos (lam * θ / 2)) • wS
      + (-(Real.exp (a n * θ) * Real.cos (b n * θ) * Real.sin (lam * θ / 2))) • Jmap n
      + (Real.exp (a n * θ) * Real.sin (b n * θ) * Real.sin (lam * θ / 2)) • spat n := by
    funext θ
    rw [rateFam, zexp]
    have h := zc_mul_Un n (Real.exp (a n * θ) * Real.cos (b n * θ))
      (Real.exp (a n * θ) * Real.sin (b n * θ)) (lam * θ)
    rw [h]
  rw [he]
  have dA : HasDerivAt
      (fun θ : ℝ => Real.exp (a n * θ) * Real.cos (b n * θ) * Real.cos (lam * θ / 2))
      (a n) 0 := by
    simpa using ((hasDerivAt_expc' (a n) 0).mul (hasDerivAt_cosc' (b n) 0)).mul
      (hasDerivAt_coshl lam 0)
  have dB : HasDerivAt
      (fun θ : ℝ => Real.exp (a n * θ) * Real.sin (b n * θ) * Real.cos (lam * θ / 2))
      (b n) 0 := by
    simpa using ((hasDerivAt_expc' (a n) 0).mul (hasDerivAt_sinc' (b n) 0)).mul
      (hasDerivAt_coshl lam 0)
  have dC : HasDerivAt
      (fun θ : ℝ => -(Real.exp (a n * θ) * Real.cos (b n * θ) * Real.sin (lam * θ / 2)))
      (-(lam / 2)) 0 := by
    have h := ((hasDerivAt_expc' (a n) 0).mul (hasDerivAt_cosc' (b n) 0)).mul
      (hasDerivAt_sinhl lam 0)
    simpa using h.neg
  have dD : HasDerivAt
      (fun θ : ℝ => Real.exp (a n * θ) * Real.sin (b n * θ) * Real.sin (lam * θ / 2))
      0 0 := by
    simpa using ((hasDerivAt_expc' (a n) 0).mul (hasDerivAt_sinc' (b n) 0)).mul
      (hasDerivAt_sinhl lam 0)
  have h := (((dA.smul_const w1).add (dB.smul_const wS)).add
    (dC.smul_const (Jmap n))).add (dD.smul_const (spat n))
  refine h.congr_deriv ?_
  rw [zc]
  module

/-! ## §VI — the two rate notions are logically independent -/

/-- **PRINCIPAL THEOREM (§VI): independence of the two rate notions.**  The spatial rate and
the two central rates are recovered separately and injectively from the generator: no value
of one constrains any value of the other. -/
theorem generator_components_independent {n : Vec3} (hn : IsUnitAxis n)
    {lam α β lam' α' β' : ℝ}
    (h : zc α β - (lam * 2⁻¹ : ℝ) • Jmap n = zc α' β' - (lam' * 2⁻¹ : ℝ) • Jmap n) :
    lam = lam' ∧ α = α' ∧ β = β' := by
  have hnn : n.1 ^ 2 + n.2.1 ^ 2 + n.2.2 ^ 2 = 1 := by
    have := hn
    simp only [IsUnitAxis, h3, dot3_apply] at this
    nlinarith [this]
  have h0 := congrFun h 0
  have h7 := congrFun h 7
  have h4 := congrFun h 4
  have h5 := congrFun h 5
  have h6 := congrFun h 6
  simp only [Pi.sub_apply, Pi.smul_apply, smul_eq_mul, zc_coord_0, zc_coord_7,
    zc_coord_4, zc_coord_5, zc_coord_6,
    Jmap_coord_4, Jmap_coord_5, Jmap_coord_6] at h0 h7 h4 h5 h6
  refine ⟨?_, by simpa using h0, by simpa using h7⟩
  have e1 : (lam - lam') * n.1 = 0 := by linarith
  have e2 : (lam - lam') * n.2.1 = 0 := by linarith
  have e3 : (lam - lam') * n.2.2 = 0 := by linarith
  have hsq : (lam - lam') ^ 2 = 0 := by
    linear_combination ((lam - lam') * n.1) * e1 + ((lam - lam') * n.2.1) * e2
      + ((lam - lam') * n.2.2) * e3 - (lam - lam') ^ 2 * hnn
  have hz : lam - lam' = 0 := by nlinarith [hsq]
  linarith

/-- **PRINCIPAL THEOREM (§VI): a common spatial rate leaves the central rates completely
free.**  Even when *one and the same* spatial rate is used for every direction — the
situation produced by the inherited linear-coherence result — every pair of real functions
of the direction still occurs as the central residual data. -/
theorem common_spatial_rate_leaves_central_free (lam : ℝ) (a b : Vec3 → ℝ) :
    (∀ n : Vec3, IsUnitAxis n → rateFam lam a b n 0 = w1) ∧
      (∀ n : Vec3, IsUnitAxis n → ∀ θ φ : ℝ,
        rateFam lam a b n (θ + φ) = rateFam lam a b n θ ⋆ rateFam lam a b n φ) ∧
      (∀ n : Vec3, IsUnitAxis n → ∀ (θ : ℝ) (x : W),
        (rateFam lam a b n θ ⋆ x) ⋆ rateFam lam a b n (-θ) = PhiGen n (lam * θ) x) ∧
      (∀ n : Vec3, HasDerivAt (rateFam lam a b n)
        (zc (a n) (b n) - (lam * 2⁻¹ : ℝ) • Jmap n) 0) :=
  ⟨fun n _ => rateFam_zero lam a b n,
    fun _ hn θ φ => rateFam_group hn lam a b θ φ,
    fun n _ θ x => rateFam_conj n lam a b θ x,
    fun n => rateFam_generator lam a b n⟩

/-- **PRINCIPAL THEOREM (§VI): conversely, the central rates do not fix the spatial rate.**
For fixed central rates the spatial rate still ranges over all real numbers, and different
spatial rates give different generators. -/
theorem central_rates_leave_spatial_rate_free {n : Vec3} (hn : IsUnitAxis n) (α β : ℝ)
    {lam lam' : ℝ} (hne : lam ≠ lam') :
    zc α β - (lam * 2⁻¹ : ℝ) • Jmap n ≠ zc α β - (lam' * 2⁻¹ : ℝ) • Jmap n := by
  intro hcon
  exact hne (generator_components_independent hn hcon).1

end NullSectorTask15
