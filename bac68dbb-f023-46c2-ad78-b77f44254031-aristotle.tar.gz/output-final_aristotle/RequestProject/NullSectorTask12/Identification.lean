import RequestProject.NullSectorTask12.CarrierEndomorphisms
import RequestProject.NullSectorTask11.Identification

/-!
# Task 12, Layer 11: late conventional comparison — **COMPARISON ONLY**

Every statement in this module is labelled **COMPARISON ONLY**.  Nothing here is used in
the reconstruction core: this module is imported by the top-level `Task12.lean` and by
nothing else, and each theorem only *re-reads*, in conventional language, a result that
was already established intrinsically in Layers 0–10.

The conventional identification used is the Task-08 comparison isomorphism `toMat` of the
reconstructed carrier with the algebra of `2 × 2` complex matrices.

**No spin claim (§45).**  Even where the reconstructed minimal carriers coincide with the
conventional carrier of a spinorial representation, nothing of the sort is concluded
here.  Task 12 establishes intrinsic algebraic carrier structure only; the minimal
algebraic left carrier is **NOT** a physical state space.
-/

namespace NullSectorTask12

open NullSectorTask08 NullSectorTask09 NullSectorTask10 NullSectorTask11

/-! ## COMPARISON ONLY — 1. generated carriers are matrix left ideals -/

/-- **COMPARISON ONLY.**  Under the comparison isomorphism the intrinsically defined
generated carrier of `e` is exactly the conventional left ideal `M₂(ℂ) · toMat e`. -/
theorem comparison_Lgen_eq_left_ideal (e y : W) :
    y ∈ Lgen e ↔ ∃ X : Matrix (Fin 2) (Fin 2) ℂ, X * toMat e = toMat y := by
  constructor
  · rintro ⟨x, rfl⟩
    exact ⟨toMat x, (toMat_mul x e).symm⟩
  · rintro ⟨X, hX⟩
    obtain ⟨x, rfl⟩ := toMat_bijective.2 X
    refine (mem_Lgen_iff _ _).2 ⟨x, toMat_bijective.1 ?_⟩
    rw [toMat_mul]
    exact hX

/-- **COMPARISON ONLY.**  The intrinsically derived self-product generators of the
minimal carriers are exactly idempotent matrices different from `0` and `1`; in the
conventional language these are the rank-one idempotents. -/
theorem comparison_generator_idempotent {e : W} (he : IsSelfProduct e) (hne : e ≠ 0)
    (hnull : IsNullElt e) :
    toMat e * toMat e = toMat e ∧ toMat e ≠ 0 ∧ toMat e ≠ 1 := by
  refine ⟨by rw [← toMat_mul, he], ?_, ?_⟩
  · intro hzero
    have h0 : toMat (0 : W) = 0 := by simpa using toMat_smul (0 : ℝ) (0 : W)
    refine hne (toMat_bijective.1 ?_)
    rw [hzero, h0]
  · intro hone
    have he1 : e = w1 := toMat_bijective.1 (by rw [hone, toMat_one])
    have : IsNullElt w1 := he1 ▸ hnull
    have h0 : nRe w1 = 0 := this.1
    simp [nRe, w1] at h0

/-! ## COMPARISON ONLY — 2. dimensions -/

/-- **COMPARISON ONLY.**  Every minimal left carrier has real dimension four; in the
conventional picture this is the real dimension of a minimal left ideal of the algebra of
`2 × 2` complex matrices, i.e. of a two-complex-dimensional column-type module. -/
theorem comparison_minimal_dimension {L : Submodule ℝ W} (hL : IsMinimalLeftCarrier L) :
    Module.finrank ℝ L = 4 := finrank_of_isMinimal hL

/-! ## COMPARISON ONLY — 3. the internal endomorphism algebra -/

/-- **COMPARISON ONLY.**  Under the comparison isomorphism an internal endomorphism of a
minimal left carrier is multiplication by a complex scalar. -/
theorem comparison_internalEndo_is_complex_scalar {e : W} (he : IsSelfProduct e)
    (hne : e ≠ 0) (h0 : e 0 = 1 / 2) (h7 : e 7 = 0)
    {T : Lgen e →ₗ[ℝ] Lgen e} (hT : IsInternalEndo (isLeftCarrier_Lgen e) T) :
    ∃ c : ℂ, ∀ ψ : Lgen e, toMat ((T ψ : Lgen e) : W) = c • toMat ((ψ : Lgen e) : W) := by
  obtain ⟨z, hz, hzT⟩ := internalEndo_eq_central he hne h0 h7 hT
  obtain ⟨a, b, rfl⟩ := (mem_Z_iff z).1 hz
  refine ⟨(a : ℂ) + (b : ℂ) * Complex.I, ?_⟩
  intro ψ
  rw [hzT ψ, toMat_mul]
  have hzc : toMat (a • w1 + b • wS)
      = ((a : ℂ) + (b : ℂ) * Complex.I) • (1 : Matrix (Fin 2) (Fin 2) ℂ) :=
    comparison_toMat_zc a b
  rw [hzc, smul_mul_assoc, one_mul]

/-- **COMPARISON ONLY.**  The intrinsically derived internal endomorphism algebra of a
minimal left carrier has real dimension two: conventionally, it is the field of complex
scalars. -/
theorem comparison_endomorphism_algebra {e : W} (he : IsSelfProduct e) (hne : e ≠ 0)
    (h0 : e 0 = 1 / 2) (h7 : e 7 = 0) :
    Module.finrank ℝ (EndoSpace (isLeftCarrier_Lgen e)) = 2 :=
  finrank_EndoSpace he hne h0 h7

/-- **COMPARISON ONLY — NOT PHYSICAL STATE SPACE.**  The comparison establishes an exact
correspondence of algebraic objects and nothing else: the reconstructed minimal left
carriers are the minimal left ideals of the comparison matrix algebra, they have real
dimension four, and their internal endomorphism algebra has real dimension two.  No
physical carrier, no state space, no representation content is claimed. -/
theorem comparison_summary {e : W} (he : IsSelfProduct e) (hne : e ≠ 0)
    (hnull : IsNullElt e) (h0 : e 0 = 1 / 2) (h7 : e 7 = 0) :
    (∀ y : W, y ∈ Lgen e ↔ ∃ X : Matrix (Fin 2) (Fin 2) ℂ, X * toMat e = toMat y) ∧
    (toMat e * toMat e = toMat e ∧ toMat e ≠ 0 ∧ toMat e ≠ 1) ∧
    Module.finrank ℝ (Lgen e) = 4 ∧
    Module.finrank ℝ (EndoSpace (isLeftCarrier_Lgen e)) = 2 :=
  ⟨comparison_Lgen_eq_left_ideal e, comparison_generator_idempotent he hne hnull,
    finrank_Lgen_eq_four hne hnull, comparison_endomorphism_algebra he hne h0 h7⟩

end NullSectorTask12
