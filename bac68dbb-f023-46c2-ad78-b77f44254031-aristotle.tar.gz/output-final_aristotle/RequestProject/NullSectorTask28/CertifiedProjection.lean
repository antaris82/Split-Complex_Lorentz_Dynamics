import RequestProject.NullSectorTask28.RepresentativeChange

/-!
# Task 28, Package B (instantiation): the inherited certified projection as an
`InternalProjection`

**IMPORT LAYER.  `Lift`, `GvisG`, `projCore`, `KerSign`, the four inherited visible domains
`Vset i` and the inherited continuous local representatives `sec i` are used exactly as
certified in the earlier layers; none of them is redefined and the one-fibre covering
theorem is not rebuilt (items 3–7).**

What is *added* here is the minimum topological plumbing needed to view the certified data
through the Task-28 interface:

* the inherited carrier topologies, transported to the packaged group carriers
  `↥LiftG` and `↥GvisG` (induced from the inherited carrier `W` and from the inherited
  space of maps `W → W`, so no new topology is invented);
* continuity of the packaged group operations;
* continuity and surjectivity of the packaged projection `projCore`;
* the local sections, restated for the packaged carriers from the inherited `sec i`;
* centrality and discreteness of the inherited kernel `KerSign`.

The resulting term `certifiedInternalProjection : InternalProjection ↥LiftG ↥GvisG` is the
instance on which the whole Task-28 development is non-vacuous.  Package L's refutation
(a whole-domain representative need not exist) is derived here from the inherited
no-global-section theorem.
-/

set_option synthInstance.maxHeartbeats 1000000
set_option maxHeartbeats 1000000

namespace NullSectorTask28

open NullSectorTask01 NullSectorTask04 NullSectorTask06 NullSectorTask07 NullSectorTask08
open NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12 NullSectorTask13
open NullSectorTask14 NullSectorTask15 NullSectorTask16 NullSectorTask17 NullSectorTask18
open NullSectorTask19 NullSectorTask20 NullSectorTask21 NullSectorTask23

namespace Certified

/-! ## Topologies on the packaged group carriers -/

/-- **INHERITED TOPOLOGY, transported.**  The packaged internal group carries the topology
induced from the inherited carrier `W`. -/
instance liftGTopology : TopologicalSpace (↥LiftG) :=
  TopologicalSpace.induced (fun u : ↥LiftG => ((u : WG).val : W)) inferInstance

theorem continuous_liftVal : Continuous fun u : ↥LiftG => ((u : WG).val : W) :=
  continuous_induced_dom

theorem liftVal_injective : Function.Injective fun u : ↥LiftG => ((u : WG).val : W) := by
  intro u v h
  exact Subtype.ext (WG.ext h)

instance : ContinuousMul (↥LiftG) := by
  constructor
  refine continuous_induced_rng.2 ?_
  exact continuous_mulW_comp (continuous_liftVal.comp continuous_fst)
    (continuous_liftVal.comp continuous_snd)

instance : ContinuousInv (↥LiftG) := by
  constructor
  refine continuous_induced_rng.2 ?_
  show Continuous fun u : ↥LiftG => (((u⁻¹ : ↥LiftG) : WG).val : W)
  have h : (fun u : ↥LiftG => (((u⁻¹ : ↥LiftG) : WG).val : W))
      = fun u : ↥LiftG => conjW ((u : WG).val) := by
    funext u
    show ((u : WG).inv : W) = conjW ((u : WG).val)
    rw [← invW_of, invW_eq_conjW u.2]
  rw [h]
  exact continuous_conjW.comp continuous_liftVal

instance : IsTopologicalGroup (↥LiftG) := ⟨⟩

instance : T2Space (↥LiftG) :=
  Topology.IsEmbedding.t2Space (f := fun u : ↥LiftG => ((u : WG).val : W))
    ⟨⟨rfl⟩, liftVal_injective⟩

/-- **INHERITED TOPOLOGY, transported.**  The packaged visible group carries the topology
induced from the inherited space of maps of the carrier. -/
instance gvisGTopology : TopologicalSpace (↥GvisG) :=
  TopologicalSpace.induced
    (fun U : ↥GvisG => (((U : (Module.End ℝ W)ˣ) : Module.End ℝ W) : W → W)) inferInstance

theorem continuous_gvisVal :
    Continuous fun U : ↥GvisG => (((U : (Module.End ℝ W)ˣ) : Module.End ℝ W) : W → W) :=
  continuous_induced_dom

/-! ## The packaged carriers and the inherited Task-23 carriers -/

/-- The packaged internal element, read in the inherited topological carrier. -/
def toLiftT (u : ↥LiftG) : LiftT := ⟨(u : WG).val, u.2⟩

theorem continuous_toLiftT : Continuous toLiftT :=
  Continuous.subtype_mk continuous_liftVal _

/-- The inherited internal element, read in the packaged group. -/
noncomputable def ofLiftT (u : LiftT) : ↥LiftG :=
  ⟨WG.ofInvertible (isInvertible_of_mem_Lift u.2), u.2⟩

@[simp] theorem toLiftT_ofLiftT (u : LiftT) : toLiftT (ofLiftT u) = u := rfl

theorem continuous_ofLiftT : Continuous ofLiftT :=
  continuous_induced_rng.2 continuous_subtype_val

theorem mem_visImageFun_of_GvisG (U : ↥GvisG) :
    (((U : (Module.End ℝ W)ˣ) : Module.End ℝ W) : W → W) ∈ visImageFun := by
  obtain ⟨p, hp⟩ := U.2
  exact ⟨p, congrArg (fun F : W →ₗ[ℝ] W => (F : W → W)) hp⟩

/-- The packaged visible element, read in the inherited topological carrier. -/
def toGvisT (U : ↥GvisG) : GvisT :=
  ⟨(((U : (Module.End ℝ W)ˣ) : Module.End ℝ W) : W → W), mem_visImageFun_of_GvisG U⟩

theorem continuous_toGvisT : Continuous toGvisT :=
  Continuous.subtype_mk continuous_gvisVal _

theorem toGvisT_injective : Function.Injective toGvisT := by
  intro U V h
  have hfun : (((U : (Module.End ℝ W)ˣ) : Module.End ℝ W) : W → W)
      = (((V : (Module.End ℝ W)ˣ) : Module.End ℝ W) : W → W) := congrArg Subtype.val h
  exact Subtype.ext (Units.ext (DFunLike.coe_injective hfun))

/-- **DERIVED.**  The packaged projection and the inherited projection agree. -/
theorem toGvisT_projCore (u : ↥LiftG) : toGvisT (projCore u) = pr (toLiftT u) := rfl

/-! ## The interface data -/

theorem continuous_projCore : Continuous (projCore : ↥LiftG → ↥GvisG) := by
  refine continuous_induced_rng.2 ?_
  show Continuous fun u : ↥LiftG =>
    ((((projCore u : ↥GvisG) : (Module.End ℝ W)ˣ) : Module.End ℝ W) : W → W)
  have h : (fun u : ↥LiftG =>
      ((((projCore u : ↥GvisG) : (Module.End ℝ W)ˣ) : Module.End ℝ W) : W → W))
      = fun u : ↥LiftG => ((pr (toLiftT u) : GvisT) : W → W) := rfl
  rw [h]
  exact continuous_subtype_val.comp (continuous_pr.comp continuous_toLiftT)

theorem surjective_projCore : Function.Surjective (projCore : ↥LiftG → ↥GvisG) := by
  intro U
  obtain ⟨u, hu⟩ := pr_surjective (toGvisT U)
  refine ⟨ofLiftT u, toGvisT_injective ?_⟩
  rw [toGvisT_projCore, toLiftT_ofLiftT, hu]

/-- **PACKAGE B (item 25).**  The inherited local sections, restated for the packaged
carriers: around every packaged visible element there is an open set carrying a continuous
section of the packaged projection.  Nothing new is proved: the section is the inherited
normalized local representative `sec i`. -/
theorem hasLocalSection_projCore (k : ↥GvisG) :
    ∃ V : Set (↥GvisG), IsOpen V ∧ k ∈ V ∧ ∃ s : ↥GvisG → ↥LiftG,
      ContinuousOn s V ∧ ∀ y ∈ V, projCore (s y) = y := by
  classical
  obtain ⟨i, hi⟩ := exists_mem_Vset (toGvisT k)
  refine ⟨toGvisT ⁻¹' Vset i, (isOpen_Vset i).preimage continuous_toGvisT, hi, ?_⟩
  refine ⟨fun y => if h : toGvisT y ∈ Vset i then ofLiftT (sec i ⟨toGvisT y, h⟩) else 1,
    ?_, ?_⟩
  · rw [continuousOn_iff_continuous_restrict]
    have h : (Set.restrict (toGvisT ⁻¹' Vset i)
        fun y => if h : toGvisT y ∈ Vset i then ofLiftT (sec i ⟨toGvisT y, h⟩) else 1)
        = fun y : ↥(toGvisT ⁻¹' Vset i) => ofLiftT (sec i ⟨toGvisT (y : ↥GvisG), y.2⟩) := by
      funext y
      exact dif_pos (show toGvisT (y : ↥GvisG) ∈ Vset i from y.2)
    rw [h]
    refine continuous_ofLiftT.comp ((continuous_sec i).comp ?_)
    exact Continuous.subtype_mk (continuous_toGvisT.comp continuous_subtype_val) _
  · intro y hy
    have hy' : toGvisT y ∈ Vset i := hy
    refine toGvisT_injective ?_
    show toGvisT (projCore (if h : toGvisT y ∈ Vset i then ofLiftT (sec i ⟨toGvisT y, h⟩)
      else 1)) = toGvisT y
    rw [dif_pos hy', toGvisT_projCore, toLiftT_ofLiftT, pr_sec]

/-! ## The inherited kernel -/

theorem mem_ker_iff_val {z : ↥LiftG} :
    z ∈ (projCore : ↥LiftG →* ↥GvisG).ker ↔ ((z : WG).val = w1 ∨ (z : WG).val = -w1) :=
  mem_KerSign_iff

theorem ker_central_projCore (z : ↥LiftG) (hz : z ∈ (projCore : ↥LiftG →* ↥GvisG).ker)
    (l : ↥LiftG) : z * l = l * z := by
  refine Subtype.ext (WG.ext ?_)
  show (z : WG).val ⋆ (l : WG).val = (l : WG).val ⋆ (z : WG).val
  rcases mem_ker_iff_val.1 hz with h | h
  · rw [h, one_mul_W, mul_one_W]
  · rw [h, neg_mul_W, mul_neg_W, one_mul_W, mul_one_W]

instance finite_ker_projCore : Finite ((projCore : ↥LiftG →* ↥GvisG).ker : Subgroup ↥LiftG) := by
  have h : ((projCore : ↥LiftG →* ↥GvisG).ker : Set ↥LiftG)
      = {⟨1, LiftG.one_mem⟩, ⟨WG.negOne, negOne_mem_LiftG⟩} := ker_projCore
  have hfin : (((projCore : ↥LiftG →* ↥GvisG).ker : Set ↥LiftG)).Finite := by
    rw [h]; exact (Set.finite_singleton _).insert _
  exact hfin.to_subtype

theorem ker_discrete_projCore :
    DiscreteTopology ((projCore : ↥LiftG →* ↥GvisG).ker : Subgroup ↥LiftG) :=
  Finite.instDiscreteTopology

/-- **PACKAGE B, principal.**  The certified internal projection, packaged as a Task-28
interface.  Every field is an inherited fact; no global section is chosen. -/
noncomputable def certifiedInternalProjection : InternalProjection (↥LiftG) (↥GvisG) where
  proj := projCore
  continuous_proj := continuous_projCore
  surjective_proj := surjective_projCore
  hasLocalSection := hasLocalSection_projCore
  ker_central := ker_central_projCore
  ker_discrete := ker_discrete_projCore

@[simp] theorem certifiedInternalProjection_proj (u : ↥LiftG) :
    certifiedInternalProjection.proj u = projCore u := rfl

/-- **DERIVED.**  The kernel of the packaged interface is exactly the inherited two-element
sign kernel. -/
theorem certified_Ker_eq : certifiedInternalProjection.Ker = KerSign := rfl

/-- **DERIVED.**  The inherited sign element is a nontrivial kernel element: the ambiguity of
Task 28 really is two-valued. -/
theorem negOne_mem_certified_Ker :
    (⟨WG.negOne, negOne_mem_LiftG⟩ : ↥LiftG) ∈ certifiedInternalProjection.Ker ∧
      (⟨WG.negOne, negOne_mem_LiftG⟩ : ↥LiftG) ≠ 1 := by
  constructor
  · exact mem_ker_iff_val.2 (Or.inr rfl)
  · intro h
    exact WG.negOne_ne_one (congrArg (fun z : ↥LiftG => (z : WG)) h)

/-! ## Package L — the certified refutation of whole-domain representability (item 93)

The inherited no-global-section theorem is *specialized*, not reproved. -/

theorem ofLiftT_surjective : Function.Surjective ofLiftT := fun u =>
  ⟨toLiftT u, Subtype.ext (WG.ext rfl)⟩

instance : CompactSpace (↥LiftG) :=
  ⟨by
    have h : IsCompact (Set.range ofLiftT) := isCompact_range continuous_ofLiftT
    rwa [ofLiftT_surjective.range_eq] at h⟩

instance : CompactSpace (↥GvisG) :=
  ⟨by
    have h : IsCompact (Set.range (projCore : ↥LiftG → ↥GvisG)) :=
      isCompact_range continuous_projCore
    rwa [surjective_projCore.range_eq] at h⟩

theorem toGvisT_surjective : Function.Surjective toGvisT := by
  intro g
  obtain ⟨w, hw⟩ := pr_surjective g
  exact ⟨projCore (ofLiftT w), by rw [toGvisT_projCore, toLiftT_ofLiftT, hw]⟩

/-- **DERIVED.**  The packaged visible group and the inherited visible carrier are the same
topological space; the identification is a homeomorphism because the packaged group is
compact and the inherited carrier is separated. -/
noncomputable def gvisHomeo : ↥GvisG ≃ₜ GvisT :=
  Continuous.homeoOfEquivCompactToT2
    (f := Equiv.ofBijective toGvisT ⟨toGvisT_injective, toGvisT_surjective⟩) continuous_toGvisT

@[simp] theorem gvisHomeo_apply (U : ↥GvisG) : gvisHomeo U = toGvisT U := rfl

/-- **PACKAGE L (items 91–93, 116, 117), principal negative control.**  Local continuous
representability does **not** imply representability over a whole domain: the identity
ordinary map on the packaged visible group has no continuous internal representative over
its whole domain.  This is the inherited no-global-section theorem, specialized. -/
theorem no_whole_domain_internal_rep :
    ¬ certifiedInternalProjection.HasContinuousInternalRep (id : ↥GvisG → ↥GvisG) Set.univ := by
  rintro ⟨u, hcont, hproj⟩
  refine no_continuous_global_rep ⟨fun g => toLiftT (u (gvisHomeo.symm g)), ?_, ?_⟩
  · exact continuous_toLiftT.comp
      ((continuousOn_univ.1 hcont).comp gvisHomeo.symm.continuous)
  · intro g
    have h1 : projCore (u (gvisHomeo.symm g)) = gvisHomeo.symm g :=
      hproj (gvisHomeo.symm g) (Set.mem_univ _)
    have h2 : toGvisT (projCore (u (gvisHomeo.symm g))) = g := by
      rw [h1]
      exact congrArg (fun z : GvisT => z) (gvisHomeo.apply_symm_apply g)
    rw [← toGvisT_projCore]
    exact h2

/-- **PACKAGE C, specialized to the certified projection.**  Every continuous ordinary map
into the packaged visible group is locally continuously representable. -/
theorem certified_exists_local_continuous_internal_rep {X : Type*} [TopologicalSpace X]
    {g : X → ↥GvisG} (hg : Continuous g) (x : X) :
    ∃ V : Set X, IsOpen V ∧ x ∈ V ∧
      certifiedInternalProjection.HasContinuousInternalRep g V :=
  certifiedInternalProjection.exists_local_continuous_internal_rep hg x

end Certified

end NullSectorTask28
