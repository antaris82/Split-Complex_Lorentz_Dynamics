import RequestProject.NullSectorTask27.Task27

/-!
# Task 28, Packages A and B: the frozen ordinary transition system and the frozen internal
projection

**IMPORT LAYER.  No Task-XXVII source is edited and no earlier definition is rebuilt.**

Package A (items 22–24) *imports and exposes* the Task-XXVII endpoint:
`NullSectorTask27.OrdinaryTransitionSystem` already packages the index type, the open chart
domains, the covering property, the continuous transition maps `g_ij` and the identity,
inverse and triple-overlap laws.  Nothing is added to it here: the Task-28 name
`OrdinaryTransitionSystem` is a literal abbreviation of the inherited structure.

Package B (items 25–27) freezes the *interface* of an already certified two-to-one internal
projection: a topological group `L`, a topological group `G`, a continuous surjective
homomorphism `proj : L →* G`, the requirement that around every point of `G` there is an
open neighbourhood carrying a continuous section of `proj`, and the two structural facts
about the kernel that the later packages use (it is central, and it carries the discrete
topology).  *No new global section theorem is proved here and no global section is chosen*
(items 26, 27): only the local data already certified in the earlier layers is named.

The whole Task-28 development is carried out for an arbitrary such interface, and the
certified internal projection of the earlier layers is exhibited as an instance in
`RequestProject.NullSectorTask28.CertifiedProjection`.
-/

set_option synthInstance.maxHeartbeats 400000
set_option maxHeartbeats 1000000

namespace NullSectorTask28

universe u v t

/-! ## Package A — the frozen ordinary transition system (items 22–24)

The inherited Task-XXVII structure is exposed under a Task-28 name.  It contains **no new
mathematics** (item 24). -/

/-- **IMPORTED, unchanged (items 22–24).**  The ordinary transition system produced by
Task XXVII: an index type, open chart domains covering the base, continuous transition maps
into the fixed visible model group, and the identity, inverse and triple-overlap laws. -/
abbrev OrdinaryTransitionSystem (B : Type u) [TopologicalSpace B] (ι : Type t) :=
  NullSectorTask27.OrdinaryTransitionSystem B ι

/-! ## Package B — the frozen internal projection interface (items 25–27) -/

/-- **NEWLY DEFINED (items 25–27), principal interface.**  The data of an already certified
two-to-one style internal projection, frozen as an interface:

* a continuous homomorphism `proj : L →* G` of topological groups;
* surjectivity of `proj` (pointwise representability, Level A);
* a continuous section of `proj` on an open neighbourhood of every point of `G`
  (the inherited local-section atlas of the group projection);
* centrality of the kernel;
* discreteness of the kernel.

No global section is chosen and no global section theorem is asserted. -/
structure InternalProjection (L : Type u) (G : Type v) [Group L] [TopologicalSpace L]
    [IsTopologicalGroup L] [Group G] [TopologicalSpace G] where
  /-- The certified projection, as a group homomorphism. -/
  proj : L →* G
  /-- The projection is continuous. -/
  continuous_proj : Continuous proj
  /-- The projection is surjective: every ordinary element is pointwise representable. -/
  surjective_proj : Function.Surjective proj
  /-- Around every ordinary element there is an open set carrying a continuous section. -/
  hasLocalSection : ∀ k : G, ∃ V : Set G, IsOpen V ∧ k ∈ V ∧ ∃ s : G → L,
    ContinuousOn s V ∧ ∀ y ∈ V, proj (s y) = y
  /-- The kernel is central. -/
  ker_central : ∀ z ∈ proj.ker, ∀ l : L, z * l = l * z
  /-- The kernel carries the discrete topology. -/
  ker_discrete : DiscreteTopology (proj.ker : Subgroup L)

namespace InternalProjection

variable {L : Type u} {G : Type v} [Group L] [TopologicalSpace L] [IsTopologicalGroup L]
  [Group G] [TopologicalSpace G] (P : InternalProjection L G)

/-- **NEUTRAL NOTATION.**  The kernel of the frozen projection.  In the certified instance it
is the inherited two-element sign kernel. -/
def Ker : Subgroup L := P.proj.ker

theorem mem_Ker_iff {z : L} : z ∈ P.Ker ↔ P.proj z = 1 := MonoidHom.mem_ker

theorem proj_ker (z : P.Ker) : P.proj (z : L) = 1 := z.2

instance : DiscreteTopology (P.Ker) := P.ker_discrete

theorem ker_comm {z : L} (hz : z ∈ P.Ker) (l : L) : z * l = l * z := P.ker_central z hz l

/-- **DERIVED (Level A, item 108).**  Pointwise representability: every ordinary element has
an internal representative.  This is the inherited surjectivity, restated. -/
theorem exists_internal_rep_pointwise (k : G) : ∃ l : L, P.proj l = k := P.surjective_proj k

/-- **DERIVED.**  Two internal elements have the same projection exactly when they differ by
a kernel element on the left. -/
theorem proj_eq_iff_mul_ker {a b : L} : P.proj a = P.proj b ↔ b * a⁻¹ ∈ P.Ker := by
  rw [Ker, MonoidHom.mem_ker, map_mul, map_inv, mul_inv_eq_one, eq_comm]

end InternalProjection

end NullSectorTask28
