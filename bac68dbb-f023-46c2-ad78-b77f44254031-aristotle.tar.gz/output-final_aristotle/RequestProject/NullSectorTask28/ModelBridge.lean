import RequestProject.NullSectorTask28.InternalTransitionInterface

/-!
# Task 28: the frozen internal projection read over the fixed visible model group

The Task-XXVII transition maps take their values in the fixed *model* visible group
`GvisModel` (the orientation-preserving isometries of the model carrier), while the certified
internal projection of the earlier layers projects onto the *reconstructed* visible group
`GvisG`.  This module supplies the bridge, so that the whole Task-28 development applies
verbatim to the inherited Task-XXVII frame transitions:

* a generic transport of a frozen `InternalProjection` along an isomorphism of topological
  groups (no new mathematics, pure repackaging);
* the identification of the reconstructed visible group with the fixed model visible group.
  Its *algebraic* half is the already certified isomorphism of the reconstructed visible
  group with the standard rotation matrix group (`NullSectorTask21.visibleRotationEquiv`),
  which is **not** reproved here; what is added is the elementary passage from rotation
  matrices to isometries of the model carrier, and the topological half — the identification
  is a homeomorphism because the reconstructed group is compact and the model group is
  separated;
* the resulting `modelInternalProjection : InternalProjection ↥LiftG GvisModel`.

No inherited definition is modified and the one-fibre covering theorem is not rebuilt.
-/

set_option synthInstance.maxHeartbeats 1000000
set_option maxHeartbeats 1000000

namespace NullSectorTask28

open NullSectorTask01 NullSectorTask04 NullSectorTask06 NullSectorTask07 NullSectorTask08
open NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12 NullSectorTask13
open NullSectorTask14 NullSectorTask15 NullSectorTask16 NullSectorTask17 NullSectorTask18
open NullSectorTask19 NullSectorTask20 NullSectorTask21 NullSectorTask23 NullSectorTask26
open NullSectorTask27
open Matrix Module Certified

/-! ## Generic transport of the interface along a group isomorphism -/

namespace InternalProjection

variable {L : Type*} {G : Type*} [Group L] [TopologicalSpace L] [IsTopologicalGroup L]
  [Group G] [TopologicalSpace G]

/-- **DERIVED (packaging only).**  A frozen internal projection can be read over an
isomorphic topological group.  Nothing new is proved: every field is transported. -/
noncomputable def transport (P : InternalProjection L G) {G' : Type*} [Group G']
    [TopologicalSpace G'] (Φ : G ≃* G') (hΦ : Continuous Φ) (hΦ' : Continuous Φ.symm) :
    InternalProjection L G' where
  proj := (Φ : G →* G').comp P.proj
  continuous_proj := hΦ.comp P.continuous_proj
  surjective_proj := Φ.surjective.comp P.surjective_proj
  hasLocalSection := by
    intro k
    obtain ⟨V, hV, hk, s, hs, hsec⟩ := P.hasLocalSection (Φ.symm k)
    refine ⟨Φ.symm ⁻¹' V, hV.preimage hΦ', hk, fun y => s (Φ.symm y), ?_, ?_⟩
    · exact hs.comp hΦ'.continuousOn fun y hy => hy
    · intro y hy
      show Φ (P.proj (s (Φ.symm y))) = y
      rw [hsec _ hy]
      simp
  ker_central := by
    intro z hz l
    refine P.ker_central z ?_ l
    have h : Φ (P.proj z) = 1 := hz
    exact MonoidHom.mem_ker.2 (Φ.injective (by rw [h, map_one]))
  ker_discrete := by
    have hker : ((Φ : G →* G').comp P.proj).ker = P.proj.ker := by
      ext z
      constructor
      · intro hz
        have h : Φ (P.proj z) = 1 := hz
        exact MonoidHom.mem_ker.2 (Φ.injective (by rw [h, map_one]))
      · intro hz
        have h : P.proj z = 1 := hz
        exact MonoidHom.mem_ker.2 (by simp [h])
    rw [hker]
    exact P.ker_discrete

@[simp] theorem transport_proj (P : InternalProjection L G) {G' : Type*} [Group G']
    [TopologicalSpace G'] (Φ : G ≃* G') (hΦ : Continuous Φ) (hΦ' : Continuous Φ.symm) (l : L) :
    (P.transport Φ hΦ hΦ').proj l = Φ (P.proj l) := rfl

end InternalProjection

/-! ## From rotation matrices to isometries of the model carrier -/

namespace ModelBridge

/-- The standard orthonormal basis of the model carrier, as an orthonormal basis. -/
noncomputable abbrev mbas : OrthonormalBasis (Fin 3) ℝ Model := EuclideanSpace.basisFun (Fin 3) ℝ

/-- **DERIVED.**  An orthogonal matrix acts on the model carrier by an inner-product
preserving map. -/
theorem inner_toEuclideanLin {M : Matrix (Fin 3) (Fin 3) ℝ} (h : Mᵀ * M = 1) (x y : Model) :
    (inner ℝ (Matrix.toEuclideanLin M x) (Matrix.toEuclideanLin M y) : ℝ) = inner ℝ x y := by
  have key : ∀ z w : Model, (inner ℝ z w : ℝ) = (WithLp.ofLp z) ⬝ᵥ (WithLp.ofLp w) := by
    intro z w
    simp [PiLp.inner_apply, dotProduct, mul_comm]
  have h1 : ∀ z : Model, WithLp.ofLp (Matrix.toEuclideanLin M z) = M *ᵥ (WithLp.ofLp z) :=
    fun _ => rfl
  rw [key, key, h1, h1, dotProduct_mulVec, ← vecMul_transpose, vecMul_vecMul, h, vecMul_one]

/-- **NEWLY DEFINED.**  The isometry of the model carrier attached to an orthogonal matrix. -/
noncomputable def isomOfMat {M : Matrix (Fin 3) (Fin 3) ℝ} (h : Mᵀ * M = 1) :
    Model ≃ₗᵢ[ℝ] Model :=
  (LinearMap.isometryOfInner (Matrix.toEuclideanLin M)
    (inner_toEuclideanLin h)).toLinearIsometryEquiv rfl

@[simp] theorem isomOfMat_apply {M : Matrix (Fin 3) (Fin 3) ℝ} (h : Mᵀ * M = 1) (x : Model) :
    isomOfMat h x = Matrix.toEuclideanLin M x := rfl

theorem isomOfMat_toLinearMap {M : Matrix (Fin 3) (Fin 3) ℝ} (h : Mᵀ * M = 1) :
    ((isomOfMat h).toLinearEquiv : Model →ₗ[ℝ] Model) = Matrix.toEuclideanLin M := rfl

/-- **DERIVED.**  The determinant of the attached isometry is the determinant of the
matrix. -/
theorem det_isomOfMat {M : Matrix (Fin 3) (Fin 3) ℝ} (h : Mᵀ * M = 1) :
    LinearMap.det ((isomOfMat h).toLinearEquiv : Model →ₗ[ℝ] Model) = M.det := by
  rw [isomOfMat_toLinearMap, Matrix.toEuclideanLin_eq_toLin_orthonormal, LinearMap.det_toLin]

/-- **DERIVED.**  A rotation matrix gives an element of the fixed model visible group. -/
theorem isomOfMat_mem_GvisModel {M : Matrix (Fin 3) (Fin 3) ℝ}
    (hM : M ∈ Matrix.specialOrthogonalGroup (Fin 3) ℝ) :
    isomOfMat ((mul_eq_one_comm (M := Matrix (Fin 3) (Fin 3) ℝ)).1
      ((Matrix.mem_orthogonalGroup_iff (Fin 3) ℝ).1
        (Matrix.mem_specialOrthogonalGroup_iff.1 hM).1)) ∈ GvisModel := by
  obtain ⟨-, hdet⟩ := Matrix.mem_specialOrthogonalGroup_iff.1 hM
  refine (mem_SOOf_iff_det_pos model_rank_three modelOrient _).2 ?_
  rw [det_isomOfMat, hdet]
  norm_num

/-- The orthogonality relation of a rotation matrix, in the form used above. -/
theorem transpose_mul_self_of_SO3 {M : Matrix (Fin 3) (Fin 3) ℝ}
    (hM : M ∈ Matrix.specialOrthogonalGroup (Fin 3) ℝ) : Mᵀ * M = 1 :=
  (mul_eq_one_comm (M := Matrix (Fin 3) (Fin 3) ℝ)).1
    ((Matrix.mem_orthogonalGroup_iff (Fin 3) ℝ).1
      (Matrix.mem_specialOrthogonalGroup_iff.1 hM).1)

/-- **NEWLY DEFINED.**  The homomorphism from the standard rotation matrix group to the fixed
model visible group. -/
noncomputable def so3ToModel : Matrix.specialOrthogonalGroup (Fin 3) ℝ →* GvisModel where
  toFun M := ⟨isomOfMat (transpose_mul_self_of_SO3 M.2), isomOfMat_mem_GvisModel M.2⟩
  map_one' := by
    refine Subtype.ext (LinearIsometryEquiv.ext fun x => ?_)
    show Matrix.toEuclideanLin (1 : Matrix (Fin 3) (Fin 3) ℝ) x = x
    simp
  map_mul' M N := by
    refine Subtype.ext (LinearIsometryEquiv.ext fun x => ?_)
    show Matrix.toEuclideanLin
        ((M : Matrix (Fin 3) (Fin 3) ℝ) * (N : Matrix (Fin 3) (Fin 3) ℝ)) x
      = Matrix.toEuclideanLin (M : Matrix (Fin 3) (Fin 3) ℝ)
          (Matrix.toEuclideanLin (N : Matrix (Fin 3) (Fin 3) ℝ) x)
    show WithLp.toLp 2
        (((M : Matrix (Fin 3) (Fin 3) ℝ) * (N : Matrix (Fin 3) (Fin 3) ℝ)) *ᵥ WithLp.ofLp x)
      = WithLp.toLp 2 ((M : Matrix (Fin 3) (Fin 3) ℝ) *ᵥ
          ((N : Matrix (Fin 3) (Fin 3) ℝ) *ᵥ WithLp.ofLp x))
    rw [Matrix.mulVec_mulVec]

theorem so3ToModel_apply (M : Matrix.specialOrthogonalGroup (Fin 3) ℝ) (x : Model) :
    ((so3ToModel M : GvisModel) : Model ≃ₗᵢ[ℝ] Model) x
      = Matrix.toEuclideanLin (M : Matrix (Fin 3) (Fin 3) ℝ) x := rfl

/-! ### The matrix of an element of the model group -/

/-- The matrix of an element of the model group in the standard orthonormal basis. -/
noncomputable def matOfModel (k : GvisModel) : Matrix (Fin 3) (Fin 3) ℝ :=
  LinearMap.toMatrix mbas.toBasis mbas.toBasis
    (((k : Model ≃ₗᵢ[ℝ] Model).toLinearEquiv : Model →ₗ[ℝ] Model))

theorem matOfModel_entry (k : GvisModel) (i j : Fin 3) :
    matOfModel k i j = (inner ℝ (mbas i) ((k : Model ≃ₗᵢ[ℝ] Model) (mbas j)) : ℝ) := by
  rw [matOfModel, LinearMap.toMatrix_apply]
  simp [OrthonormalBasis.coe_toBasis_repr_apply, OrthonormalBasis.repr_apply_apply]

theorem matOfModel_orthogonal (k : GvisModel) : (matOfModel k)ᵀ * matOfModel k = 1 := by
  ext i j
  rw [Matrix.mul_apply]
  simp only [Matrix.transpose_apply, matOfModel_entry]
  have hcomm : ∀ l : Fin 3, (inner ℝ (mbas l) ((k : Model ≃ₗᵢ[ℝ] Model) (mbas i)) : ℝ)
      = inner ℝ ((k : Model ≃ₗᵢ[ℝ] Model) (mbas i)) (mbas l) := fun l => real_inner_comm _ _
  simp only [hcomm]
  rw [mbas.sum_inner_mul_inner, LinearIsometryEquiv.inner_map_map]
  by_cases h : i = j
  · subst h; simp [EuclideanSpace.basisFun_apply]
  · simp [h, EuclideanSpace.basisFun_apply, EuclideanSpace.inner_single_left,
      EuclideanSpace.single_apply]

theorem matOfModel_det (k : GvisModel) : (matOfModel k).det = 1 := by
  have hpos : 0 < (matOfModel k).det := by
    have hdet := (mem_SOOf_iff_det_pos model_rank_three modelOrient
      (k : Model ≃ₗᵢ[ℝ] Model)).1 k.2
    rwa [matOfModel, LinearMap.det_toMatrix]
  have hsq : (matOfModel k).det * (matOfModel k).det = 1 := by
    have h := congrArg Matrix.det (matOfModel_orthogonal k)
    rw [Matrix.det_mul, Matrix.det_transpose, Matrix.det_one] at h
    exact h
  nlinarith [hpos, hsq]

theorem matOfModel_mem_SO3 (k : GvisModel) :
    matOfModel k ∈ Matrix.specialOrthogonalGroup (Fin 3) ℝ :=
  Matrix.mem_specialOrthogonalGroup_iff.2
    ⟨(Matrix.mem_orthogonalGroup_iff (Fin 3) ℝ).2
      ((mul_eq_one_comm (M := Matrix (Fin 3) (Fin 3) ℝ)).1 (matOfModel_orthogonal k)),
      matOfModel_det k⟩

theorem so3ToModel_matOfModel (k : GvisModel) :
    so3ToModel ⟨matOfModel k, matOfModel_mem_SO3 k⟩ = k := by
  refine Subtype.ext (LinearIsometryEquiv.ext fun x => ?_)
  have h : ((matOfModel k) : Matrix (Fin 3) (Fin 3) ℝ)
      = LinearMap.toMatrix mbas.toBasis mbas.toBasis
        (((k : Model ≃ₗᵢ[ℝ] Model).toLinearEquiv : Model →ₗ[ℝ] Model)) := rfl
  show Matrix.toEuclideanLin (matOfModel k) x = (k : Model ≃ₗᵢ[ℝ] Model) x
  rw [Matrix.toEuclideanLin_eq_toLin_orthonormal, h, Matrix.toLin_toMatrix]
  rfl

theorem so3ToModel_surjective : Function.Surjective so3ToModel :=
  fun k => ⟨⟨matOfModel k, matOfModel_mem_SO3 k⟩, so3ToModel_matOfModel k⟩

theorem so3ToModel_injective : Function.Injective so3ToModel := by
  intro M N h
  have hfun : ∀ x : Model, Matrix.toEuclideanLin (M : Matrix (Fin 3) (Fin 3) ℝ) x
      = Matrix.toEuclideanLin (N : Matrix (Fin 3) (Fin 3) ℝ) x := by
    intro x
    have := congrArg (fun z : GvisModel => (z : Model ≃ₗᵢ[ℝ] Model) x) h
    simpa [so3ToModel_apply] using this
  refine Subtype.ext (Matrix.toEuclideanLin.injective ?_)
  exact LinearMap.ext hfun

/-! ### The reconstructed visible group and the model visible group -/

/-- **DERIVED, principal.**  The reconstructed visible group is isomorphic to the fixed model
visible group.  The algebraic content is the already certified identification of the
reconstructed group with the standard rotation matrix group; nothing of it is reproved. -/
noncomputable def gvisMulEquiv : ↥GvisG ≃* GvisModel :=
  visibleRotationEquiv.trans (MulEquiv.ofBijective so3ToModel
    ⟨so3ToModel_injective, so3ToModel_surjective⟩)

theorem gvisMulEquiv_apply (U : ↥GvisG) (x : Model) :
    ((gvisMulEquiv U : GvisModel) : Model ≃ₗᵢ[ℝ] Model) x
      = Matrix.toEuclideanLin (rotMat ((U : (Module.End ℝ W)ˣ) : Module.End ℝ W)) x := rfl

/-! ### Topology: the identification is a homeomorphism -/

instance : T2Space (Model ≃ₗᵢ[ℝ] Model) :=
  Topology.IsEmbedding.t2Space (f := fun f : Model ≃ₗᵢ[ℝ] Model => (f : Model → Model))
    ⟨⟨rfl⟩, fun _ _ h => LinearIsometryEquiv.ext (congrFun h)⟩

theorem continuous_gvisMulEquiv : Continuous (gvisMulEquiv : ↥GvisG → GvisModel) := by
  rw [continuous_gvisModel_iff]
  intro m
  have hmat : ∀ i j : Fin 3, Continuous fun U : ↥GvisG =>
      rotMat ((U : (Module.End ℝ W)ˣ) : Module.End ℝ W) i j := by
    intro i j
    have hval : Continuous fun U : ↥GvisG =>
        (((U : (Module.End ℝ W)ˣ) : Module.End ℝ W) : W → W) (spat (be j)) :=
      (continuous_apply (spat (be j))).comp continuous_gvisVal
    fin_cases i
    · exact (continuous_apply 1).comp hval
    · exact (continuous_apply 2).comp hval
    · exact (continuous_apply 3).comp hval
  have hgoal : ∀ U : ↥GvisG, ((gvisMulEquiv U : GvisModel) : Model ≃ₗᵢ[ℝ] Model) m
      = WithLp.toLp 2 (fun i => ∑ j, rotMat ((U : (Module.End ℝ W)ˣ) : Module.End ℝ W) i j
          * (WithLp.ofLp m) j) := by
    intro U
    rw [gvisMulEquiv_apply]
    rfl
  simp only [hgoal]
  refine (PiLp.continuous_toLp 2 (fun _ : Fin 3 => ℝ)).comp (continuous_pi fun i => ?_)
  exact continuous_finset_sum _ fun j _ => (hmat i j).mul continuous_const

/-- **DERIVED, principal.**  The identification of the reconstructed visible group with the
fixed model visible group is a homeomorphism: the reconstructed group is compact and the
model group is separated. -/
noncomputable def gvisHomeoModel : ↥GvisG ≃ₜ GvisModel :=
  Continuous.homeoOfEquivCompactToT2 (f := gvisMulEquiv.toEquiv) continuous_gvisMulEquiv

theorem continuous_gvisMulEquiv_symm : Continuous (gvisMulEquiv.symm : GvisModel → ↥GvisG) :=
  gvisHomeoModel.symm.continuous

/-! ## The certified internal projection over the fixed model visible group -/

/-- **PACKAGE B (instantiation), principal.**  The certified two-to-one internal projection,
read over the fixed visible model group in which the Task-XXVII transition maps take their
values. -/
noncomputable def modelInternalProjection : InternalProjection (↥LiftG) GvisModel :=
  certifiedInternalProjection.transport gvisMulEquiv continuous_gvisMulEquiv
    continuous_gvisMulEquiv_symm

@[simp] theorem modelInternalProjection_proj (u : ↥LiftG) :
    modelInternalProjection.proj u = gvisMulEquiv (projCore u) := rfl

/-! ## The Task-XXVII frame transitions, locally continuously representable -/

variable {B : Type*} [TopologicalSpace B] {ι : Type*}

/-- **CENTRAL SUCCESS CRITERION, first half.**  Every continuous ordinary frame transition of
the inherited Task-XXVII system is locally continuously representable through the certified
two-to-one internal projection. -/
theorem ordinary_transition_locally_representable (S : OrdinaryTransitionSystem B ι) (i j : ι)
    (x : ↥(S.U i ∩ S.U j)) :
    ∃ V : Set ↥(S.U i ∩ S.U j), IsOpen V ∧ x ∈ V ∧
      modelInternalProjection.HasContinuousInternalRep (S.g i j) V :=
  modelInternalProjection.exists_local_continuous_internal_rep (S.continuous_g i j) x

/-- **CENTRAL SUCCESS CRITERION, packaged.**  The inherited Task-XXVII transition system
carries a frozen internal transition candidate: refined overlaps with continuous internal
representatives.  Compatibility is *not* claimed. -/
noncomputable def ordinaryInternalCandidate (S : OrdinaryTransitionSystem B ι) :
    InternalTransitionCandidate modelInternalProjection (ofOrdinary S) :=
  candidateOfSystem modelInternalProjection (ofOrdinary S)

end ModelBridge

end NullSectorTask28
