import RequestProject.NullSectorTask17.RegularityAudit

/-!
# Task 17, final layer: the comparison-only module

**COMPARISON ONLY, AND LAST (§70).**  This module is imported by nothing but
`RequestProject.NullSectorTask17.Task17`.  No reconstruction module of Task 17 — or of any
earlier task — imports it, and no reconstruction theorem depends on it.  It contains a
single reading of results that have already been derived; nothing here is used as an input
anywhere, and no new mathematics is introduced.

## What the Task-17 reconstruction produced

1. The inherited domains `Dom v` are nonempty exactly for `v ≠ 0`, open in the inherited
   unit-direction subspace, antipodal-free, and path-connected through an explicit
   renormalized straight-line path (Package A).
2. On such a domain an exact jointly regular representative has `α = 0` and a *constant*
   half-odd rate, i.e. a single integer label; the family is then *equal* to the explicit
   model `locFam k`, and conversely each `locFam k` qualifies (Packages B, C).
3. Admissibility of an arbitrary direction set is characterized exactly by the existence of
   a continuous rate function which is half-odd on the set and odd on the antipodal pairs
   it contains.  Antipodal-freeness is sufficient but not necessary; connectedness forces a
   single label; the inherited domains are neither exhaustive nor maximal (Package D).
4. Relative factors between arbitrary local representatives are central units, uniquely
   determined, given by an integer-labelled one-parameter central law, direction-independent
   on preconnected overlaps, and composing along arbitrary finite chains (Package E).
5. Local data — even with all transition factors equal to the unit — reconstruct no global
   sign-relaxed family; the missing datum is exactly the comparison across direction
   reversal (Package F).
6. Requiring continuously differentiable rate functions changes none of the above
   (Package G).

## The conventional reading

The pattern 1–6 is the one conventionally described by saying that the internal
representatives refine the visible transformations two-fold: a consistent choice of
internal representative exists over any region of directions omitting antipodal pairs and
is labelled by an integer there, consecutive choices differ by a discrete central factor,
and the local choices never assemble into a global one because the comparison across
reversal is inconsistent with continuity.

This paragraph is a *reading* of already-derived statements.  No group, covering,
cocycle, bundle, or classification theorem was constructed, imported, or needed anywhere in
the reconstruction; the discrete labels are integers attached to explicit families and are
given no interpretation beyond that.
-/

namespace NullSectorTask17

open NullSectorTask01 NullSectorTask04 NullSectorTask06 NullSectorTask07 NullSectorTask08
open NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12 NullSectorTask13
open NullSectorTask14 NullSectorTask15 NullSectorTask16

/-- **COMPARISON ONLY.**  The two facts that the informal reading above compresses: on an
inherited domain the exact representatives are exactly the integer-labelled models, and two
of them differ by the central factor of the label difference. -/
theorem comparison_local_pattern (k l : ℤ) (v : Vec3) (n : Vec3) (θ : ℝ) :
    IsTransformationValuedOn (Dom v) (locFam k) ∧
      locFam k n θ = zexp 0 ((k : ℝ) - l) θ ⋆ locFam l n θ :=
  ⟨locFam_transformationValuedOn k v, (locFam_overlap k l n θ).1⟩

end NullSectorTask17
