import RequestProject.NullSectorTask17.Identification

/-!
# Task 17: the principal theorems

This module imports the complete Task-17 development and exposes the principal final
theorems, one group per package, together with the axiom report.

Source order of the development:

```
SafeBase
  → DomainGeometry        (Package A)
  → RateRigidity          (Package B)
  → LocalExhaustion       (Package C)
  → AdmissibleDomains     (Package D)
  → OverlapTransitions    (Package E)
  → Reconstruction        (Package F)
  → RegularityAudit       (Package G)
  → Identification        (COMPARISON ONLY, last)
  → Task17
```

`Identification` is imported by this module only; no reconstruction module depends on it.

## Status table (Package H, §60–§61)

| entry | status |
|---|---|
| globally exact jointly regular representative | **REFUTED** (inherited: `no_global_jointly_regular_transformationValued`) |
| globally sign-relaxed jointly regular representative | **PROVED** unique (inherited: `signValued_eq_reference`) |
| local exact existence | **PROVED** (`task17_locFam_hypotheses`) |
| local pointwise rate classification | **PROVED** on arbitrary sets (`task17_pointwise_rates`) |
| domainwise rate constancy | **PROVED** on every nonempty `Dom v`, and on every preconnected admissible set (`task17_beta_const_on_Dom`, `task17_label_const_of_preconnected`); **REFUTED** without connectedness (`task17_label_not_const`) |
| complete local-family exhaustion | **PROVED** (`task17_local_exhaustion`, `task17_local_classification`) |
| admissible-domain classification | **PROVED** as an exact criterion (`task17_admissible_criterion`); antipodal pairs **not** an obstruction (`task17_antipodal_pair_admissible`); antipodal-freeness sufficient (`task17_antipodalFree_admissible`); "contained in some `Dom v`" **REFUTED** (`task17_YDom_not_subset_Dom`); maximality of `Dom v` **REFUTED** (`task17_Dom_not_maximal`) |
| overlap-factor classification | **PROVED** (`task17_overlap_central`, `task17_overlap_unique`, `task17_overlap_integer`, `task17_overlap_direction_independent`, `task17_overlap_param_law`) |
| finite overlap-chain coherence | **PROVED** for arbitrary finite chains (`task17_overlap_chain3`, `task17_overlap_chain_finite`); no infinite product is defined anywhere |
| reconstruction from local data | **REFUTED** for existence (`task17_no_reconstruction`), **PROVED** for uniqueness (`task17_reconstruction_unique`); missing datum identified (`task17_missing_datum`) |
| stronger regularity | **PROVED** to add no restriction (`task17_c1_classification`, `task17_c1_labels`, `task17_c1_domains`, `task17_c1_overlap`) |
| arbitrary spatial word problem | **OPEN** — untouched in Task 17 |
-/

namespace NullSectorTask17

open NullSectorTask01 NullSectorTask04 NullSectorTask06 NullSectorTask07 NullSectorTask08
open NullSectorTask09 NullSectorTask10 NullSectorTask11 NullSectorTask12 NullSectorTask13
open NullSectorTask14 NullSectorTask15 NullSectorTask16

/-! ## Package A — intrinsic geometry of the inherited domains -/

theorem task17_dom_rescaling {c : ℝ} (hc : 0 < c) (v : Vec3) : Dom (c • v) = Dom v :=
  Dom_smul_pos hc v

theorem task17_dom_nonempty_iff (v : Vec3) : (Dom v).Nonempty ↔ v ≠ 0 :=
  Dom_nonempty_iff v

theorem task17_dom_normalized_iff (v : Vec3) : nrmz v ∈ Dom v ↔ v ≠ 0 :=
  nrmz_mem_Dom_iff v

theorem task17_dom_antipodal_free {v n : Vec3} (h : n ∈ Dom v) : -n ∉ Dom v :=
  Dom_antipodal_free h

theorem task17_dom_open (v : Vec3) : IsOpen (sphSet (Dom v)) := isOpen_sphSet_Dom v

theorem task17_dom_path {v n₀ n₁ : Vec3} (h₀ : n₀ ∈ Dom v) (h₁ : n₁ ∈ Dom v) {t : ℝ}
    (ht : t ∈ Set.Icc (0 : ℝ) 1) :
    IsUnitAxis (segPath n₀ n₁ t) ∧ segPath n₀ n₁ t ∈ Dom v :=
  ⟨(segPath_mem_Dom h₀ h₁ ht).1, segPath_mem_Dom h₀ h₁ ht⟩

theorem task17_dom_path_connected {v : Vec3} (hv : v ≠ 0) :
    IsPathConnected (sphSet (Dom v)) := isPathConnected_sphSet_Dom hv

theorem task17_dom_connected {v : Vec3} (hv : v ≠ 0) : IsConnected (sphSet (Dom v)) :=
  isConnected_sphSet_Dom hv

/-! ## Package B — discrete-value rigidity -/

theorem task17_pointwise_rates {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    {D : Set Vec3} (hV : IsTransformationValuedOn D U) {n : Vec3} (hn : n ∈ D)
    (hun : IsUnitAxis n) :
    rateAlpha U n = 0 ∧ ∃ k : ℤ, rateBeta U n = (k : ℝ) + 1 / 2 :=
  pointwise_rates hU hV hn hun

theorem task17_beta_const_on_Dom {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    {v : Vec3} (hv : v ≠ 0) (hV : IsTransformationValuedOn (Dom v) U) :
    ∀ n ∈ Dom v, ∀ m ∈ Dom v, rateBeta U n = rateBeta U m :=
  beta_const_on_Dom hU hv hV

theorem task17_local_label_exists {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    {v : Vec3} (hv : v ≠ 0) (hV : IsTransformationValuedOn (Dom v) U) :
    ∃ k : ℤ, ∀ n ∈ Dom v, rateAlpha U n = 0 ∧ rateBeta U n = (k : ℝ) + 1 / 2 :=
  exists_local_label hU hv hV

theorem task17_local_label_unique {U : Vec3 → ℝ → W} {v : Vec3} (hv : v ≠ 0) {k l : ℤ}
    (hk : ∀ n ∈ Dom v, rateBeta U n = (k : ℝ) + 1 / 2)
    (hl : ∀ n ∈ Dom v, rateBeta U n = (l : ℝ) + 1 / 2) : k = l :=
  local_label_unique hv hk hl

/-! ## Package C — local-family exhaustion -/

theorem task17_equal_rates_equal_families {U V : Vec3 → ℝ → W}
    (hU : IsJointlyRegularFamily U) (hV : IsJointlyRegularFamily V) {D : Set Vec3}
    (hunit : ∀ n ∈ D, IsUnitAxis n)
    (hrate : ∀ n ∈ D, rateAlpha U n = rateAlpha V n ∧ rateBeta U n = rateBeta V n) :
    ∀ n ∈ D, ∀ θ : ℝ, U n θ = V n θ :=
  eq_of_rates_eq hU hV hunit hrate

theorem task17_local_exhaustion {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    {v : Vec3} (hv : v ≠ 0) (hexact : IsTransformationValuedOn (Dom v) U) :
    ∃! k : ℤ, ∀ n ∈ Dom v, ∀ θ : ℝ, U n θ = locFam k n θ :=
  local_exact_eq_locFam_unique hU hv hexact

theorem task17_locFam_hypotheses (k : ℤ) (v : Vec3) :
    IsJointlyRegularFamily (locFam k) ∧ IsTransformationValuedOn (Dom v) (locFam k) :=
  locFam_local_hypotheses k v

theorem task17_local_classification {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    {v : Vec3} (hv : v ≠ 0) :
    IsTransformationValuedOn (Dom v) U ↔ ∃! k : ℤ, ∀ n ∈ Dom v, ∀ θ : ℝ,
      U n θ = locFam k n θ :=
  local_family_classification hU hv

/-! ## Package D — admissible domains -/

theorem task17_admissible_necessary {U : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    {D : Set Vec3} (hunit : ∀ n ∈ D, IsUnitAxis n)
    (hexact : IsTransformationValuedOn D U) :
    (∀ n ∈ D, rateAlpha U n = 0) ∧
      (∀ n ∈ D, ∃ k : ℤ, rateBeta U n = (k : ℝ) + 1 / 2) ∧
      (Continuous fun s : Sph => rateBeta U (s : Vec3)) ∧
      (∀ n ∈ D, -n ∈ D → rateBeta U (-n) = -rateBeta U n) :=
  admissible_necessary hU hunit hexact

theorem task17_antipodal_pair_admissible {n : Vec3} (hn : IsUnitAxis n) :
    IsAdmissibleDomain ({n, -n} : Set Vec3) ∧
      ∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧
        IsTransformationValuedOn ({n, -n} : Set Vec3) U ∧
        rateBeta U n = 1 / 2 ∧ rateBeta U (-n) = -(1 / 2) :=
  antipodal_pair_admissible hn

theorem task17_antipodalFree_admissible {D : Set Vec3} (hunit : ∀ n ∈ D, IsUnitAxis n)
    (hfree : AntipodalFree D) :
    (∀ k : ℤ, IsTransformationValuedOn D (locFam k)) ∧ IsAdmissibleDomain D :=
  antipodalFree_admissible hunit hfree

theorem task17_admissible_criterion {D : Set Vec3} (hunit : ∀ n ∈ D, IsUnitAxis n) :
    IsAdmissibleDomain D ↔ ∃ b : Vec3 → ℝ, (Continuous fun s : Sph => b (s : Vec3)) ∧
      (∀ n ∈ D, ∃ k : ℤ, b n = (k : ℝ) + 1 / 2) ∧ (∀ n ∈ D, -n ∈ D → b (-n) = -b n) :=
  admissible_iff_exists_rate_function hunit

theorem task17_label_const_of_preconnected {U : Vec3 → ℝ → W}
    (hU : IsJointlyRegularFamily U) {D : Set Vec3} (hunit : ∀ n ∈ D, IsUnitAxis n)
    (hpre : IsPreconnected (sphSet D)) (hexact : IsTransformationValuedOn D U) :
    ∀ n ∈ D, ∀ m ∈ D, rateBeta U n = rateBeta U m :=
  label_const_of_preconnected hU hunit hpre hexact

theorem task17_label_not_const {n : Vec3} (hn : IsUnitAxis n) :
    ∃ U : Vec3 → ℝ → W, IsJointlyRegularFamily U ∧
      IsTransformationValuedOn ({n, -n} : Set Vec3) U ∧
      rateBeta U n ≠ rateBeta U (-n) :=
  label_not_const_without_connectedness hn

theorem task17_YDom_admissible_open_connected :
    IsAdmissibleDomain YDom ∧ IsOpen (sphSet YDom) ∧ IsPathConnected (sphSet YDom) :=
  ⟨YDom_admissible, YDom_open, YDom_pathConnected⟩

theorem task17_YDom_not_subset_Dom (v : Vec3) : ¬ YDom ⊆ Dom v := YDom_not_subset_Dom v

theorem task17_Dom_not_maximal {v : Vec3} (hv : v ≠ 0) :
    ∃ D : Set Vec3, Dom v ⊂ D ∧ IsAdmissibleDomain D := Dom_not_maximal hv

/-! ## Package E — overlap transitions -/

theorem task17_overlap_central {U V : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    (hV : IsJointlyRegularFamily V) {n : Vec3} (hn : IsUnitAxis n) (θ : ℝ) :
    ovl U V n θ ∈ Z ∧ U n θ = ovl U V n θ ⋆ V n θ :=
  ovl_central_and_factor hU hV hn θ

theorem task17_overlap_unique {U V : Vec3 → ℝ → W} (hV : IsJointlyRegularFamily V)
    {n : Vec3} (hn : IsUnitAxis n) {θ : ℝ} {c : W} (h : U n θ = c ⋆ V n θ) :
    c = ovl U V n θ :=
  ovl_unique hV hn h

theorem task17_overlap_integer {U V : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    (hV : IsJointlyRegularFamily V) {DU DV : Set Vec3}
    (hexU : IsTransformationValuedOn DU U) (hexV : IsTransformationValuedOn DV V)
    {n : Vec3} (hnU : n ∈ DU) (hnV : n ∈ DV) (hn : IsUnitAxis n) :
    ∃ j : ℤ, ∀ θ : ℝ, ovl U V n θ = zexp 0 (j : ℝ) θ :=
  ovl_integer hU hV hexU hexV hnU hnV hn

theorem task17_overlap_direction_independent {U V : Vec3 → ℝ → W}
    (hU : IsJointlyRegularFamily U) (hV : IsJointlyRegularFamily V) {D : Set Vec3}
    (hunit : ∀ n ∈ D, IsUnitAxis n) (hpre : IsPreconnected (sphSet D))
    (hexU : IsTransformationValuedOn D U) (hexV : IsTransformationValuedOn D V) :
    ∀ n ∈ D, ∀ m ∈ D, ∀ θ : ℝ, ovl U V n θ = ovl U V m θ :=
  ovl_direction_independent hU hV hunit hpre hexU hexV

theorem task17_overlap_param_law {U V : Vec3 → ℝ → W} (hU : IsJointlyRegularFamily U)
    (hV : IsJointlyRegularFamily V) {n : Vec3} (hn : IsUnitAxis n)
    (hαU : rateAlpha U n = 0) (hαV : rateAlpha V n = 0) (θ φ : ℝ) :
    ovl U V n (θ + φ) = ovl U V n θ ⋆ ovl U V n φ ∧ ovl U V n 0 = w1 :=
  ovl_param_law hU hV hn hαU hαV θ φ

theorem task17_overlap_chain3 {U V T : Vec3 → ℝ → W} (hV : IsJointlyRegularFamily V)
    {n : Vec3} (hn : IsUnitAxis n) (θ : ℝ) :
    ovl U V n θ ⋆ ovl V T n θ = ovl U T n θ :=
  ovl_chain3 hV hn θ

theorem task17_overlap_chain_finite (F : ℕ → Vec3 → ℝ → W)
    (hF : ∀ j : ℕ, IsJointlyRegularFamily (F j)) {n : Vec3} (hn : IsUnitAxis n) (θ : ℝ)
    (N : ℕ) : chainOvl F n θ N = ovl (F 0) (F N) n θ :=
  chainOvl_eq F hF hn θ N

/-! ## Package F — reconstruction from local data -/

theorem task17_reconstruction_unique {ι : Type} {D : ι → Set Vec3}
    (hcov : ∀ n : Vec3, IsUnitAxis n → ∃ i, n ∈ D i) {U V : Vec3 → ℝ → W}
    (h : ∀ i : ι, ∀ n ∈ D i, ∀ θ : ℝ, U n θ = V n θ) :
    ∀ n : Vec3, IsUnitAxis n → ∀ θ : ℝ, U n θ = V n θ :=
  reconstruction_unique hcov h

theorem task17_local_exact_not_sign_relaxed {U : Vec3 → ℝ → W}
    (hU : IsJointlyRegularFamily U) {v : Vec3} (hv : v ≠ 0)
    (hexact : IsTransformationValuedOn (Dom v) U) : ¬ IsSignTransformationValued U :=
  exact_local_not_signTransformationValued hU hv hexact

theorem task17_reference_not_locally_exact {v : Vec3} (hv : v ≠ 0) :
    ¬ IsTransformationValuedOn (Dom v) refFam :=
  refFam_not_exact_on_Dom hv

theorem task17_no_reconstruction :
    ∃ F : Vec3 → Vec3 → ℝ → W,
      (∀ v : Vec3, IsJointlyRegularFamily (F v)) ∧
      (∀ v : Vec3, IsTransformationValuedOn (Dom v) (F v)) ∧
      (∀ n : Vec3, IsUnitAxis n → n ∈ Dom n) ∧
      (∀ (v w n : Vec3), IsUnitAxis n → ∀ θ : ℝ, ovl (F v) (F w) n θ = w1) ∧
      (∀ (v w : Vec3), ∀ n : Vec3, ∀ θ : ℝ, F v n θ = F w n θ) ∧
      ¬ ∃ G : Vec3 → ℝ → W, IsJointlyRegularFamily G ∧ IsSignTransformationValued G ∧
        ∀ v : Vec3, ∀ n ∈ Dom v, ∀ θ : ℝ, G n θ = F v n θ :=
  local_data_do_not_reconstruct

theorem task17_missing_datum :
    ¬ ∃ b : Vec3 → ℝ, (Continuous fun s : Sph => b (s : Vec3)) ∧
      (∀ n : Vec3, IsUnitAxis n → ∃ k : ℤ, b n = (k : ℝ) + 1 / 2) ∧
      (∀ n : Vec3, IsUnitAxis n → b (-n) = -b n) :=
  no_global_halfodd_odd_rate

/-! ## Package G — stronger regularity -/

theorem task17_c1_labels (v : Vec3) (k : ℤ) :
    IsC1JointlyRegularFamily (locFam k) ∧ IsTransformationValuedOn (Dom v) (locFam k) ∧
      ∀ n ∈ Dom v, rateBeta (locFam k) n = (k : ℝ) + 1 / 2 :=
  c1_labels_unrestricted v k

theorem task17_c1_classification {U : Vec3 → ℝ → W} (hU : IsC1JointlyRegularFamily U)
    {v : Vec3} (hv : v ≠ 0) :
    IsTransformationValuedOn (Dom v) U ↔ ∃! k : ℤ, ∀ n ∈ Dom v, ∀ θ : ℝ,
      U n θ = locFam k n θ :=
  c1_local_family_classification hU hv

theorem task17_c1_domains {D : Set Vec3} (hunit : ∀ n ∈ D, IsUnitAxis n)
    (hfree : AntipodalFree D) :
    ∃ U : Vec3 → ℝ → W, IsC1JointlyRegularFamily U ∧ IsTransformationValuedOn D U :=
  c1_antipodalFree_admissible hunit hfree

theorem task17_c1_domains_antipodal {n : Vec3} (hn : IsUnitAxis n) :
    ∃ U : Vec3 → ℝ → W, IsC1JointlyRegularFamily U ∧
      IsTransformationValuedOn ({n, -n} : Set Vec3) U :=
  c1_antipodal_pair_admissible hn

theorem task17_c1_overlap {U V : Vec3 → ℝ → W} (hU : IsC1JointlyRegularFamily U)
    (hV : IsC1JointlyRegularFamily V) {DU DV : Set Vec3}
    (hexU : IsTransformationValuedOn DU U) (hexV : IsTransformationValuedOn DV V)
    {n : Vec3} (hnU : n ∈ DU) (hnV : n ∈ DV) (hn : IsUnitAxis n) :
    ∃ j : ℤ, ∀ θ : ℝ, ovl U V n θ = zexp 0 (j : ℝ) θ :=
  c1_overlap_same hU hV hexU hexV hnU hnV hn

/-! ## Comparison only -/

theorem task17_comparison_local_pattern (k l : ℤ) (v : Vec3) (n : Vec3) (θ : ℝ) :
    IsTransformationValuedOn (Dom v) (locFam k) ∧
      locFam k n θ = zexp 0 ((k : ℝ) - l) θ ⋆ locFam l n θ :=
  comparison_local_pattern k l v n θ

/-! ## Axiom report -/

#print axioms task17_dom_rescaling
#print axioms task17_dom_nonempty_iff
#print axioms task17_dom_normalized_iff
#print axioms task17_dom_antipodal_free
#print axioms task17_dom_open
#print axioms task17_dom_path
#print axioms task17_dom_path_connected
#print axioms task17_dom_connected
#print axioms task17_pointwise_rates
#print axioms task17_beta_const_on_Dom
#print axioms task17_local_label_exists
#print axioms task17_local_label_unique
#print axioms task17_equal_rates_equal_families
#print axioms task17_local_exhaustion
#print axioms task17_locFam_hypotheses
#print axioms task17_local_classification
#print axioms task17_admissible_necessary
#print axioms task17_antipodal_pair_admissible
#print axioms task17_antipodalFree_admissible
#print axioms task17_admissible_criterion
#print axioms task17_label_const_of_preconnected
#print axioms task17_label_not_const
#print axioms task17_YDom_admissible_open_connected
#print axioms task17_YDom_not_subset_Dom
#print axioms task17_Dom_not_maximal
#print axioms task17_overlap_central
#print axioms task17_overlap_unique
#print axioms task17_overlap_integer
#print axioms task17_overlap_direction_independent
#print axioms task17_overlap_param_law
#print axioms task17_overlap_chain3
#print axioms task17_overlap_chain_finite
#print axioms task17_reconstruction_unique
#print axioms task17_local_exact_not_sign_relaxed
#print axioms task17_reference_not_locally_exact
#print axioms task17_no_reconstruction
#print axioms task17_missing_datum
#print axioms task17_c1_labels
#print axioms task17_c1_classification
#print axioms task17_c1_domains
#print axioms task17_c1_domains_antipodal
#print axioms task17_c1_overlap
#print axioms task17_comparison_local_pattern

end NullSectorTask17
