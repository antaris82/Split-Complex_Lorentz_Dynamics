# TASK 19 AUDIT — Intrinsic Global-Obstruction Decomposition

Primitive bridge criteria, maximal admissible geometry, relation completion, and
higher-regularity closure.

---

## 0. Toolchain, revision, source order

| item | value |
| --- | --- |
| Lean | `4.28.0` (`lean-toolchain`, unchanged) |
| Mathlib | pinned in `lake-manifest.json` at rev `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (tag `v4.28.0`) |
| Lake target | `RequestProject` (glob `RequestProject.+`), so the Task-19 modules are part of the default build |
| new layer | `RequestProject/NullSectorTask19/` |

**Source order (§9 of the request).**

```
SafeBase
  → PrimitiveBridge
    → MinimalObstruction
      → MaximalPreconnected
        → PlainMaximality
          → DisconnectedExtension
            → RelationCompletion
              → RelationBridge
                → HigherRegularity
                  → NegativeControls
                    → Identification   (COMPARISON ONLY)
                      → Task19
```

Each module imports exactly its predecessor; the chain is linear.  `SafeBase` imports
`RequestProject.NullSectorTask18.NegativeControls`, i.e. the Task-18 reconstruction layer
only.

**Imports actually used from Mathlib** (transitively, through the inherited layers): the real
analysis, topology, `ContDiff`, Tietze-extension, bump-function and Zorn-lemma parts of
`Mathlib`.  The Task-19 modules themselves add no new `import Mathlib.*` line; they inherit
the ambient `Mathlib` import of the earlier layers.

---

## 1. Reconstruction firewall report (§1–§9, audited mechanically before writing this file)

| firewall clause | status | evidence |
| --- | --- | --- |
| only the Task-18 reconstruction layer is imported | **OK** | `SafeBase.lean` line 1 imports `RequestProject.NullSectorTask18.NegativeControls` |
| `NullSectorTask18.Identification` never imported | **OK** | mechanical scan: the string occurs only inside a Task-19 *docstring* stating the firewall |
| `NullSectorTask18.Task18` never imported | **OK** | same scan |
| Task-19 comparison module imported only by `Task19` | **OK** | `RequestProject.NullSectorTask19.Identification` occurs as an `import` only in `Task19.lean` |
| no conventional geometric/physical vocabulary in reconstruction modules | **OK** | the scan for `Spin`, `SU(2)`, `SO(3)`, spinor, projective representation, covering space, fibre/principal bundle, Čech, cocycle, cohomology, connection, holonomy, gauge, fundamental group, quantum, particle words returns only the two *negative* sentences that state the firewall itself |
| nothing quotiented, no central factor or sign discarded | **OK** | no `Quotient`, `Setoid` or sign-collapsing construction appears in the layer |
| no preferred maximal admissible domain assumed | **OK** | maximality is always a hypothesis or a constructed conclusion; non-uniqueness is proved |
| relation completion not reduced to ordinary overlap | **OK** | `SystemRelationComplete` is defined by quantification over relations; `CoherentOverlaps` is a separate, strictly weaker predicate, and the separation is proved |
| `C¹` construction not assumed to extend | **OK** | `stair_contDiff_infty` is proved, not assumed |
| `IsGlobalBridge` replaced | **OK** | the Task-19 primitive notion `IsPrimitiveBridge` contains no exactness clause |

---

## 2. Exact definitions introduced in Task 19

| name | module | statement |
| --- | --- | --- |
| `allUnit` | SafeBase | `{n : Vec3 | IsUnitAxis n}` |
| `negSph`, `negSet` | SafeBase | the reversal homeomorphism of the unit-direction space and its action on sets |
| `RateCont`, `RateHalfOdd`, `RateRev` | SafeBase | the three rate conditions |
| `rateZero`, `rateHalf`, `signRate` | SafeBase | the three pairwise witnesses |
| `IsPrimitiveBridge` | PrimitiveBridge | central at every unit direction, `c n 0 = w1`, `c n (θ+φ) = c n θ ⋆ c n φ`, jointly continuous.  **No exactness.** |
| `recon` | PrimitiveBridge | `recon c n θ = c n θ ⋆ refFam n θ` |
| `primRateA`, `primRateB` | PrimitiveBridge | the two explicit recovered rates of a primitive bridge |
| `IsLocallyExact` | PrimitiveBridge | exact on every inherited domain |
| `IsGlobalRate` | PrimitiveBridge | `RateCont ∧ RateHalfOdd ∧ RateRev` |
| `bridgeOfRate` | PrimitiveBridge | the primitive bridge attached to a rate function |
| `RateCond`, `RateCond.holds`, `SatisfiableSet` | MinimalObstruction | the finite condition type and its satisfiability predicate |
| `PathConnAdmClass` | MaximalPreconnected | path-connected admissible class |
| `MissingSet`, `AccessibleMissing` | MaximalPreconnected | the missing set of a domain, and the exact extra hypothesis |
| `DenseDom` | PlainMaximality | closure of the domain is everything |
| `sepFun` | PlainMaximality | a continuous function of the direction obtained from a continuous function on the unit-direction space |
| `bandSet`, `bandRate`, `bandUnion` | PlainMaximality | the explicit admissible chain and its non-admissible union |
| `ratioSet`, `flipSet` | PlainMaximality | the explicit maximal admissible set |
| `LabelRealized`, `LabelLevel` | DisconnectedExtension | prescribed labels and their level sets |
| `accPt`, `accLabel`, `accDom` | DisconnectedExtension | the accumulating counterexample |
| `VisRelation` | RelationCompletion | the intrinsic relation object (Task-16 coincidence, fixed input) |
| `SameDirectionRel`, `AntipodalRel`, `DegenerateRel` | RelationCompletion | the three classes |
| `RelationSatisfiedBy` | RelationCompletion | the minimal comparison datum for one relation |
| `IsRelationComplete`, `SystemRelationComplete` | RelationCompletion | relation completeness of a family and of an indexed system |
| `RateZeroHalfOdd`, `AntipodalRelated` | RelationCompletion | the pointwise rate hypothesis; the antipodal comparison datum |
| `inhSystem` | RelationCompletion | the inherited local system |
| `IsLocalSystem`, `CoherentOverlaps` | RelationBridge | locally exact open covering system; ordinary overlap coherence |
| `glueRate` | RelationBridge | the glued directional rate of a covering system |
| `IsCkJointlyRegularFamily`, `IsCkAdmissibleDomain` | HigherRegularity | regularity at an arbitrary smoothness index `r` |

---

## 3. Theorem inventory by package

### Package A — a primitive bridge notion independent of exactness (§10–§18)

| theorem | content |
| --- | --- |
| `primitiveBridge_jointlyRegular` | **primitive bridge → jointly regular family** (§17a) |
| `primitiveBridge_normal_form` | every primitive bridge equals `zexp (primRateA c n) (primRateB c n) θ` (§13) |
| `primitiveBridge_rates_unique` | the realizing pair of rates is unique (§13) |
| `primitiveBridge_ext` | a primitive bridge is determined by the **pair** of rates (§14) |
| `primitiveBridge_not_determined_by_directional_rate` | it is **not** determined by the directional rate alone (§14) |
| `recon_locallyExact_iff` | **equivalence** (§15): reconstruction locally exact ⟺ first rate vanishes and directional rate half-odd |
| `recon_globallyExact_iff` | **equivalence** (§16): globally exact ⟺ additionally reversal-odd |
| `primitiveBridge_locallyExact`, `primitiveBridge_globallyExact` | the two implications of §17b, §17c stated separately |
| `exists_primitiveBridge`, `primitiveBridge_boundary` | primitive bridges exist, locally exact ones exist (§24) |

Both directions of §15 and §16 are proved, so both are called equivalences (§18).

### Package B — the two equivalences (§19–§24)

| theorem | content |
| --- | --- |
| `IsGlobalRate` | the explicit rate predicate (§19) |
| `primitiveBridge_iff_globalRate` | **PROVED equivalence** (§20) |
| `primitiveBridge_iff_globalExactFamily` | **PROVED equivalence** (§21) |
| `no_global_rate_and_no_primitive_global_bridge` | the corrected endpoint (§23): a *conjunction of two negations*, not a definition-driven nonexistence |
| `primitiveBridge_boundary` | §24: the nonexistence is not an artefact — the primitive object exists |

Neither equivalence fails, so §22 requires no extra hypothesis.

### Package C — minimality of the three-condition obstruction (§25–§32)

| theorem | content |
| --- | --- |
| `no_rate_all_three`, `rate_conditions_unsat` | no rate satisfies all three (§26) |
| `drop_continuity`, `drop_halfOddness`, `drop_reversalOddness` | removing one restores existence (§27–§29) |
| `three_conditions_minimal_unsatisfiable` | **exact minimal-unsatisfiable-set statement** (§30) |
| `obstruction_rate_level`, `obstruction_primitiveBridge_level`, `obstruction_family_level` | the three logically separate levels (§31) |
| `three_witnesses_preserved` | the three explicit witnesses retained (§32) |

### Package D — maximal preconnected admissible domains (§33–§41)

| theorem | content | status |
| --- | --- | --- |
| `antipodalComplete_maximal` | antipodal completeness ⟹ maximal | `PROVED` |
| `empty_not_maximal` | the empty case, explicitly (§35) | `PROVED` |
| `maximal_closureComplete` | maximal ⟹ closure-complete (new necessary condition) | `PROVED` |
| `maximal_antipodalComplete_of_accessible` | converse under `AccessibleMissing` (§37) | `CONDITIONAL` |
| `three_maximality_notions_differ` | preconnected / open preconnected / path-connected differ (§38) | `PROVED` |
| `exists_maximal_openConnAdm_not_Dom` | **not** every maximal open preconnected domain is a `Dom v` (§39, §40) | `REFUTED` |

The intended unconditional equivalence of §34 is **not** available; the missing step is
exactly the hypothesis `AccessibleMissing`, and the proved substitute is closure-completeness.
No hemisphere or projective-space theorem is imported anywhere (§36, §41).

### Package E — plain admissible maximality (§42–§48)

| theorem | content | status |
| --- | --- | --- |
| `maximal_adm_iff` | maximal ⟺ dense ∧ antipodally complete ∧ antipodal-free | `PROVED` |
| `chain_union_not_admissible` | an explicit increasing chain of admissible sets whose union is not admissible (§44, §45) | `PROVED` (failure mechanism: the ambient continuous rate is forced to be non-half-odd at the limit) |
| `exists_maximal_adm` | an explicit maximal admissible set `flipSet` (§42) — obtained **without** a maximality principle, precisely because chain closure fails (§43) | `PROVED` |
| `maximal_adm_not_unique` | maximal admissible sets are not unique (§47, §48) | `REFUTED` (uniqueness) |

Existence, uniqueness and canonicality are kept apart: existence is proved, uniqueness is
refuted, canonicality is therefore unavailable and is never inferred.

### Package F — disconnected component labels (§49–§57)

| theorem | content | status |
| --- | --- | --- |
| `label_const_on_components` | the label is constant on every connected component (§50) | `PROVED` |
| `label_levels_separated` | differently labelled level sets have disjoint closures — separation is **necessary** (§51, §52) | `PROVED` |
| `two_label_extension` | for two labels with disjoint closures, separation is sufficient (§53, positive half) | `PROVED` |
| `separation_not_sufficient` | an explicit accumulating domain with one-point level sets whose labels are not realizable (§53, negative half) | `REFUTED` (sufficiency) |
| `label_closure_extension_criterion` | **full necessity-and-sufficiency criterion**, stated on the closure (§54) | `PROVED` |
| `four_label_control` | the Task-18 four-label domain preserved (§56) | positive control |
| `no_accumulation_control` | the no-accumulation theorem preserved (§57) | negative control |

### Package G — complete visible-relation coverage (§58–§66)

| theorem | content | status |
| --- | --- | --- |
| `visRelation_trichotomy` | the three proved classes, from the fixed Task-16 classification (§58–§60) | `PROVED` |
| `RelationSatisfiedBy`, `relationSatisfied_of_mem_common_domain` | the minimal comparison datum, and when it is already implied (§61) | `PROVED` |
| `family_periodic`, `same_direction_automatic` | same-direction relations are automatic from the local one-parameter law (§62) | `PROVED` |
| `family_at_int_two_pi`, `degenerate_automatic` | identity-degenerate relations are automatic from the local models (§63) | `PROVED` |
| `relationComplete_iff_antipodalRelated` | the antipodal class is the **only** nonautomatic one (§64) | `PROVED` |
| `antipodal_class_not_automatic` | and it is genuinely nonautomatic | `PROVED` |
| `IsRelationComplete`, `SystemRelationComplete` | relation completeness, defined independently of coverage (§66) | definition |
| `coverage_not_relationComplete` | direction coverage does not give relation completeness | `REFUTED` |

§65 has an empty answer: no further nonautomatic class exists.

### Package H — relation completion versus the primitive bridge (§67–§73)

| theorem | content | status |
| --- | --- | --- |
| `primitiveBridge_of_systemRelationComplete` | **sufficiency** (§68): relation completeness of a locally exact open covering system builds one primitive global bridge | `PROVED` |
| `systemRelationComplete_of_primitiveBridge` | **necessity** (§69) | `PROVED` |
| `relationComplete_system_iff_primitiveBridge` | the **genuine equivalence** (§70) | `PROVED` |
| `inhSystem_relation_counterexample` | coherent overlaps, same-direction and degenerate classes satisfied, antipodal class failing, no bridge (§71) | `PROVED` |
| `global_obstruction_is_relation_incompleteness` | the global obstruction restated purely as relation incompleteness (§72) | `PROVED` |

Because both directions hold, §71 is realized in the sharper form: not one direction of the
equivalence fails, but the *common* content of both sides is refuted, and the explicit
counterexample localizes the failure in the antipodal class.  No groupoid, bundle, covering
or cocycle language is used (§73).

### Package I — regularity above `C¹` (§74–§81)

| theorem | content | status |
| --- | --- | --- |
| `stair_contDiff_infty` | the staircase step is `C∞`, not merely `C¹` (§74, §75) | `PROVED` |
| `exists_smooth_rate` | the smooth rate matching a half-odd continuous rate on an arbitrary set (§77) | `PROVED` |
| `admissible_iff_smoothAdmissible` | continuous admissibility ⟺ `C∞` admissibility, arbitrary domains (§78) | `PROVED` |
| `admissible_iff_ckAdmissible` | the same for every finite `k` (§76) | `PROVED` |
| `analytic_plateau_forces_constant` | an analytic function with an exact plateau is constant (§81) | `PROVED` |
| `antipodalFree_analyticAdmissible` | antipodal-free domains do carry an analytic rate | `PROVED` |
| arbitrary-domain analytic admissibility | not claimed | `OPEN` |

§79 has an empty answer for smoothness: no step prevents it.  §80 is respected —
analyticity is never inferred from smoothness; it is treated as the separate problem of §81.

### Package J — negative controls (§82–§84)

`control_centrality_not_local_exactness`, `control_bridge_not_global`,
`control_connectedness_needed`, `control_openness_needed`, `control_coverage_not_relations`,
`control_labels_not_arbitrary`, `control_c1_needs_construction`,
`control_maximality_not_canonicality`, `boundary_maximal_preconnected`.

---

## 4. Dependency graph of the Task-19 development

```
Task-18 reconstruction layer
        ↓
     SafeBase            (unit-direction topology, reversal, rate predicates, witnesses)
        ↓
  PrimitiveBridge        (Packages A, B)
        ↓
 MinimalObstruction      (Package C)
        ↓
MaximalPreconnected      (Package D)
        ↓
  PlainMaximality        (Package E)
        ↓
DisconnectedExtension    (Package F)
        ↓
 RelationCompletion      (Package G)
        ↓
  RelationBridge         (Package H)
        ↓
 HigherRegularity        (Package I)
        ↓
 NegativeControls        (Package J)
        ↓
  Identification         (COMPARISON ONLY)
        ↓
     Task19              (endpoints, status table, axiom report)
```

Additional assumptions used by particular arrows, stated explicitly:

* Package D, the converse arrow *maximal ⟹ antipodally complete* requires `AccessibleMissing`.
* Package H, the sufficiency arrow requires **openness** of the domains of the system (used
  only to make the glued rate continuous) and **coverage** of every unit direction.
* Package I, the analytic arrow requires antipodal-freeness; no arbitrary-domain analytic
  arrow exists.

---

## 5. Final status table (§85, §86, §87)

Formal Lean endpoints are the `task19_*` theorems in `Task19.lean`; everything else in this
document is a paper-level reading of them.

| endpoint | Lean endpoint | status |
| --- | --- | --- |
| primitive bridge definition independent of exactness | `task19_primitive_bridge_exists` | `PROVED` |
| primitive bridge normal form | `task19_primitive_bridge_normal_form` | `PROVED` |
| primitive bridge ↔ rate | `task19_primitiveBridge_iff_rate` | `PROVED` |
| primitive bridge ↔ global exact family | `task19_primitiveBridge_iff_family` | `PROVED` |
| exact minimality of the three-condition obstruction | `task19_three_conditions_minimal` | `PROVED` |
| maximal preconnected admissible classification | `task19_maximal_preconnected` | `PARTIAL`; converse `CONDITIONAL` on `AccessibleMissing` |
| maximal open preconnected classification | `task19_maximal_open_not_Dom` | `REFUTED` |
| plain admissible maximality | `task19_plain_maximality` | `PROVED`; uniqueness `REFUTED` |
| disconnected label extension theorem | `task19_label_extension` | `PROVED`; separation-sufficiency `REFUTED` |
| relation-complete local system | `task19_relation_completeness` | `PROVED` |
| only antipodal relation nonautomatic? | `task19_only_antipodal_nonautomatic` | `PROVED` (yes) |
| relation completion ↔ primitive bridge | `task19_relation_iff_bridge` | `PROVED` |
| `Cᵏ` equivalence | `task19_ck_equivalence` | `PROVED` |
| `C∞` equivalence | `task19_smooth_equivalence` | `PROVED` |
| analyticity | `task19_analytic_audit` | `PARTIAL`; arbitrary-domain case `OPEN` |
| arbitrary spatial word problem | — | `OPEN`, not entered; no Task-19 theorem required it |

Nothing above is described as a *complete* classification except where necessity,
sufficiency and hypotheses are all explicit: that applies to the plain-admissible maximality
criterion, the closure extension criterion for labels, the relation/bridge equivalence, and
the `Cᵏ`/`C∞` equivalences.  It does **not** apply to the maximal preconnected case.

---

## 6. Required Task-XIX verdict

> Can the global exact obstruction be decomposed intrinsically into an exact equivalence
> between a primitive central bridge, a global directional-rate condition, and complete
> visible-relation compatibility, while independently classifying the maximal local domains
> and the admissible disconnected label data?

**Yes for the three-way equivalence; partly for the domain classification.**  The three
statements

* existence of a primitive central bridge with globally exact reconstruction,
* existence of a continuous, half-odd, reversal-odd global directional rate,
* existence of a relation-complete locally exact covering system of open domains,

are pairwise equivalent, with all six implications proved, and all three are false.  The
maximal-domain branch and the disconnected-label branch do **not** collapse into that
equivalence: they remain genuinely independent, and one of them (maximal preconnected) is
only conditionally classified.

The seven required separate answers:

1. **Is the three-condition obstruction genuinely minimal in the exact logical sense?**
   **Yes.**  `three_conditions_minimal_unsatisfiable`: the set of the three conditions is
   unsatisfiable and every proper subset is satisfiable — an exact minimal unsatisfiable set,
   with explicit witnesses.
2. **Does a primitive bridge criterion exist without global exactness built into its
   definition?**  **Yes.**  `IsPrimitiveBridge` mentions only centrality, normalization,
   one-parameter multiplicativity and joint continuity; such bridges exist, and locally exact
   ones exist.  The nonexistence statement is therefore not an artefact of the definition.
3. **Is complete visible-relation compatibility equivalent to existence of that bridge?**
   **Yes.**  `relationComplete_system_iff_primitiveBridge`, both directions proved
   constructively.  Consequently the global obstruction can be restated purely as failure of
   complete visible-relation compatibility.
4. **Do maximal preconnected admissible domains admit a complete intrinsic
   classification?**  **Not yet.**  Antipodal completeness is sufficient; maximality forces
   closure-completeness; the converse needs the explicitly named `AccessibleMissing`.  In
   addition, maximal *open* preconnected admissible domains are **not** all inherited domains.
5. **Do maximal arbitrary admissible domains exist?**  **Yes**, and they are classified
   exactly (dense, antipodally complete, antipodal-free) and are **not** unique.  Chains of
   admissible sets need not have admissible unions, so no maximality principle is invoked;
   existence comes from an explicit construction.
6. **Do disconnected label assignments admit an explicit extension theorem?**  **Yes**, in
   the closure form: realizable ⟺ the half-odd function extends continuously to the closure
   compatibly with reversal.  Separation of differently labelled closures is necessary but
   not sufficient.
7. **Can arbitrary-domain admissibility be hardened from `C¹` to `C∞`?**  **Yes**, for every
   finite `k` and for `∞`, for arbitrary domains.  Analyticity is not inferred: the exact
   plateau on which the construction relies is impossible for an analytic function, and the
   arbitrary-domain analytic question is left `OPEN`.

A negative branch is an acceptable outcome, and three branches are negative and formally
isolated: the maximal-open refutation, the separation-sufficiency refutation, and the
non-uniqueness of maximal admissible sets.

---

## 7. Failed attempts and changed theorem boundaries (§83, §84)

1. **Intended:** *inclusion-maximal preconnected admissible ⟺ antipodally complete*,
   unconditionally.
   **Outcome:** the forward direction could not be proved intrinsically.  Adjoining a single
   missing direction can destroy preconnectedness, and the intrinsic argument does not supply
   a preconnected antipodal-free part of the missing set accumulating at the domain.
   **Replacement:** `maximal_closureComplete` (a genuinely proved weaker necessary condition)
   plus `maximal_antipodalComplete_of_accessible` under the named hypothesis
   `AccessibleMissing`.  Recorded formally in `boundary_maximal_preconnected`.
2. **Intended:** *separation of differently labelled component closures is necessary and
   sufficient*.
   **Outcome:** sufficiency is false; `separation_not_sufficient` exhibits a domain with
   one-point (hence separated) level sets whose labels are not realizable.
   **Replacement:** the closure extension criterion `label_closure_extension_criterion`,
   which is necessary *and* sufficient, plus the two-label positive result.
3. **Intended:** apply a maximality principle to the plain admissible class.
   **Outcome:** chain unions of admissible sets need not be admissible
   (`chain_union_not_admissible`), so the principle is unavailable.
   **Replacement:** an explicit maximal admissible set, verified against the proved criterion.
4. **Intended:** *every maximal open preconnected admissible domain is an inherited domain*.
   **Outcome:** refuted by `exists_maximal_openConnAdm_not_Dom`.

---

## 8. Unresolved mathematical obligations

1. Whether *maximal preconnected admissible ⟹ antipodally complete* holds without
   `AccessibleMissing`.
2. A structural description of the maximal open preconnected admissible domains beyond the
   proof that they are not exhausted by the inherited ones.
3. Whether every set of unit directions that is admissible carries an **analytic** rate; only
   the antipodal-free case is settled.
4. Whether the maximal admissible sets admit any intrinsic invariant distinguishing them, in
   the absence of uniqueness.
5. Whether the closure extension criterion of Package F can be re-expressed purely in terms
   of the component labels themselves, without reference to an extending function.

---

## 9. Source ledger

**IMPORTED STANDARD RESULT** (Mathlib, at the pinned revision):

* `ContinuousMap.exists_restrict_eq` — Tietze extension, used for the closure extension
  criterion and for the rate extension.
* `exists_continuous_zero_one_of_isClosed` — Urysohn separation, used for adjoining a point
  to an admissible set and for the two-label extension.
* `UniformContinuous.exists_contDiff_dist_le` — smooth approximation of a uniformly
  continuous function (`Mathlib/Analysis/Calculus/BumpFunction/SmoothApprox.lean`).
* `Real.smoothTransition.contDiff` — the smooth transition function is `Cⁿ` for every `n`.
* `ContDiff.of_le`, `ContDiff.comp`, `ContDiff.sum`, `contDiff_const` — smoothness calculus.
* `AnalyticOnNhd.eqOn_of_preconnected_of_eventuallyEq` — the identity theorem, used only in
  the analyticity audit.
* `zorn_subset_nonempty` — used only after chain closure was proved for the open preconnected
  admissible class.
* `Function.Periodic.int_mul`, `Real.cos_add_int_mul_two_pi`, `Real.sin_add_int_mul_two_pi`,
  `Real.cos_add_pi`, `Real.sin_add_pi` — parameter periodicity.
* Standard topology: `isOpen_Ioo`, `closure_singleton`, `isClosed_closure`,
  `continuous_iff_continuousAt`, `ContinuousAt.congr`, `IsPreconnected` API.

**DERIVED IN TASK 19:** every declaration listed in §2 and §3 above.

**INHERITED FROM EARLIER TASKS** (used as fixed input, not re-derived): the carrier and its
product, the reference family, joint regularity and the recovered rates, the Task-16
coincidence classification (`coincidence_iff_coords`, `coincidence_same_axis_iff`,
`coincidence_neg_axis`, `coincidence_cross_classification`), the admissibility criterion
`admissible_iff_exists_rate_function`, `admissible_necessary`, `famOfZ_exact_on`, the
inherited domains `Dom v` with their openness and preconnectedness, the Task-18 staircase
`stair` and its plateau lemma, the four-label domain `multiD`, the domains `YDom` and `lexA`,
and the global nonexistence endpoints `no_global_halfodd_odd_rate` and
`no_global_jointly_regular_transformationValued`.

---

## 10. Build, warning, prohibited-construct and axiom report (§89–§93)

* **Focused Task-19 build:** each Task-19 module builds individually; the last one,
  `RequestProject.NullSectorTask19.Task19`, builds cleanly.
* **Complete project build:** `Build completed successfully (8238 jobs).`
* **Warnings:** none in the Task-19 layer.  The only diagnostics emitted by the Task-19
  modules are the `#print axioms` informational messages in `Task19.lean`.
* **Prohibited constructs:** a mechanical scan of `RequestProject/NullSectorTask19/` for
  `sorry`, `admit`, custom `axiom`, `@[implemented_by]`, `native_decide`, `bv_decide` and
  `unsafe` returns **no match**.
* **Axioms.**  `#print axioms` on every one of the twenty-two principal Task-19 endpoints
  reports exactly

  ```
  [propext, Classical.choice, Quot.sound]
  ```

  the three standard Lean/Mathlib axioms, and nothing else.
