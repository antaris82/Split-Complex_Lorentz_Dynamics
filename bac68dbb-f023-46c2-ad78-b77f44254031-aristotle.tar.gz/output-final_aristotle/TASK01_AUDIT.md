# TASK01_AUDIT

Audit of the Task 01 formal development: longitudinal causal decomposition
inside 3+1 Minkowski space. Everything below is a statement about real vector
spaces, quadratic forms, real coefficients, and topological limits. No physical
interpretation is attached to any coefficient, product, or parameter.

All Lean names below live in the namespace `NullSectorTask01`.

---

## 1. Exact definitions

| Name | File | Definition |
| --- | --- | --- |
| `Vec4` | `Basic.lean` | `abbrev Vec4 : Type := ℝ × ℝ × ℝ × ℝ`, coordinates `(t,x,y,z)` |
| `Long` | `Basic.lean` | `abbrev Long : Type := ℝ × ℝ`, coordinates `(t,x)` |
| `Q4` | `Basic.lean` | `Q4 X = X.1^2 − X.2.1^2 − X.2.2.1^2 − X.2.2.2^2` (signature `(+,−,−,−)`) |
| `Q2` | `Basic.lean` | `Q2 X = X.1^2 − X.2^2` |
| `iota` | `Basic.lean` | `iota (t,x) = (t,x,0,0)` (the subspace `y = 0`, `z = 0`) |
| `mulL`, `⋆` | `SplitComplex.lean` | `(t,x) ⋆ (s,y) = (t·s + x·y, t·y + x·s)` |
| `oneL` | `SplitComplex.lean` | `(1,0)` |
| `jL` | `SplitComplex.lean` | `(0,1)` |
| `ep` | `SplitComplex.lean` | `e₊ = (1/2) • (oneL + jL)` |
| `em` | `SplitComplex.lean` | `e₋ = (1/2) • (oneL − jL)` |
| `qp` | `SplitComplex.lean` | `q₊(t,x) = t + x` |
| `qm` | `SplitComplex.lean` | `q₋(t,x) = t − x` |
| `P` | `SplitComplex.lean` | `P a b = a • e₊ + b • e₋` |
| `nullEquiv` | `SplitComplex.lean` | the `ℝ`-linear equivalence `Long ≃ₗ[ℝ] ℝ × ℝ`, `X ↦ (q₊ X, q₋ X)`, inverse `(a,b) ↦ P a b` |
| `invProd` | `SplitComplex.lean` | `invProd a b = a * b` (neutral shorthand) |
| `FutureCausalCoeff` | `Strata.lean` | `0 ≤ a ∧ 0 ≤ b` |
| `FutureCausalVec` | `Strata.lean` | `0 ≤ X.1 ∧ 0 ≤ Q2 X` |
| `IsZero` | `Strata.lean` | `a = 0 ∧ b = 0` |
| `IsPlusBoundary` | `Strata.lean` | `0 < a ∧ b = 0` |
| `IsMinusBoundary` | `Strata.lean` | `a = 0 ∧ 0 < b` |
| `IsInterior` | `Strata.lean` | `0 < a ∧ 0 < b` |
| `B` | `Boost.lean` | `B η (t,x) = (cosh η · t + sinh η · x, sinh η · t + cosh η · x)` |
| `B4` | `Boost.lean` | `B4 η (t,x,y,z) = (cosh η · t + sinh η · x, sinh η · t + cosh η · x, y, z)` |
| `Fp` | `Limits.lean` | `F₊(ε) = P a₀ ε` |
| `Fm` | `Limits.lean` | `F₋(ε) = P ε b₀` |
| `G` | `Limits.lean` | `G(b) = P (I / b) b` |

Derived normal forms (proved, not assumed):
`ep = (1/2, 1/2)` (`ep_eq`), `em = (1/2, −1/2)` (`em_eq`),
`P a b = ((a+b)/2, (a−b)/2)` (`P_eq`).

`Long` carries its standard product topology as a finite-dimensional real vector
space; all limits are taken in that topology, along the filter `𝓝[>] (0 : ℝ)`.

---

## 2. Theorem inventory

### `Basic.lean` — ambient structure
| Theorem | Statement |
| --- | --- |
| `iota_injective` | `ι` is injective |
| `Q4_iota` | `Q4 (ι X) = Q2 X` |

### `SplitComplex.lean` — split-complex algebra and null coordinates
| Theorem | Statement |
| --- | --- |
| `mulL_comm`, `mulL_assoc`, `oneL_mulL` | `⋆` is commutative, associative, with unit `oneL` |
| `jL_mulL_jL` | `j ⋆ j = 1` |
| `ep_eq`, `em_eq` | coordinate form of the idempotents |
| `ep_mulL_ep` | `e₊ ⋆ e₊ = e₊` |
| `em_mulL_em` | `e₋ ⋆ e₋ = e₋` |
| `ep_mulL_em`, `em_mulL_ep` | `e₊ ⋆ e₋ = 0 = e₋ ⋆ e₊` |
| `ep_add_em` | `e₊ + e₋ = 1` |
| `ep_sub_em` | `e₊ − e₋ = j` |
| `P_eq`, `P_fst`, `P_snd` | coordinate form of `P` |
| `P_qp_qm` | `P (q₊ X) (q₋ X) = X` (exact reconstruction) |
| `qp_P`, `qm_P` | `q₊(P a b) = a`, `q₋(P a b) = b` |
| `P_injective` | uniqueness of the coefficients |
| `nullEquiv` (+ `nullEquiv_apply`, `nullEquiv_symm_apply`) | explicit linear equivalence `Long ≃ₗ[ℝ] ℝ × ℝ` |
| `Q2_P` | `Q2 (P a b) = invProd a b = a·b` |
| `Q2_eq_qp_mul_qm` | `Q2 X = q₊ X · q₋ X` |
| `Q2_ep`, `Q2_em` | `Q2 e₊ = 0`, `Q2 e₋ = 0` |

### `Strata.lean` — future-causal sector
| Theorem | Statement |
| --- | --- |
| `futureCausal_iff` | `0 ≤ a ∧ 0 ≤ b ↔ (0 ≤ t ∧ 0 ≤ Q2)` for `(t,x) = P a b` |
| `futureCausalVec_iff` | the same, read off from an arbitrary vector |
| `strata_exhaustive` | every quadrant point lies in one of the four strata |
| `strata_disjoint` | the four strata are pairwise disjoint |
| `nonzero_strata_trichotomy` | nonzero sector points lie in exactly one of the three nonzero strata |
| `Q2_of_zero`, `Q2_of_plusBoundary`, `Q2_of_minusBoundary` | `Q2 = 0` on the boundary strata |
| `Q2_of_interior` | `0 < Q2` on the interior stratum |
| `strata_of_Q2_eq_zero`, `interior_of_Q2_pos` | converses inside the sector |
| `Q2_eq_zero_iff`, `Q2_pos_iff_interior` | the two converses in biconditional form |

### `Boost.lean` — longitudinal boosts
| Theorem | Statement |
| --- | --- |
| `B4_iota` | the ambient boost restricts to the longitudinal boost along `ι` |
| `Q4_B4` | `Q4 (B4 η X) = Q4 X` |
| `Q2_B` | `Q2 (B η X) = Q2 X` |
| `B_ep` | `B η e₊ = exp(η) • e₊` |
| `B_em` | `B η e₋ = exp(−η) • e₋` |
| `B_P` | `B η (P a b) = P (exp(η)·a) (exp(−η)·b)` |
| `qp_B`, `qm_B` | `q₊(B η X) = exp(η)·q₊ X`, `q₋(B η X) = exp(−η)·q₋ X` |
| `invProd_boost_direct` | invariance of `a·b`, proved from exponential identities only |
| `invProd_boost_via_Q2` | invariance of `a·b`, proved from `Q2_B`, `B_P`, `Q2_P` |

### `Limits.lean` — boundary families and limiting regimes
| Theorem | Statement |
| --- | --- |
| `continuous_P`, `continuous_P_right`, `continuous_P_left` | continuity of the assembly map |
| `Q2_Fp`, `Q2_Fm` | `Q2 (F₊ ε) = a₀·ε`, `Q2 (F₋ ε) = ε·b₀` |
| `Fp_zero_mem_plusBoundary`, `Fm_zero_mem_minusBoundary` | stratum of the endpoint |
| `Fp_pos_mem_interior`, `Fm_pos_mem_interior` | stratum of the members with `ε > 0` |
| `tendsto_Fp`, `tendsto_Fm` | vector-level limits `F₊(ε) → P a₀ 0`, `F₋(ε) → P 0 b₀` as `ε → 0⁺` |
| `tendsto_Q2_Fp`, `tendsto_Q2_Fm` | `Q2 → 0` along the same filter |
| `Q2_G` | `Q2 (G b) = I` for `b ≠ 0` |
| `tendsto_G_fst_atTop` | `(G b).1 → +∞` as `b → 0⁺` |
| `not_tendsto_G` | `G` has **no** limit in `Long` as `b → 0⁺` |
| `G_unbounded` | concrete unboundedness: for every `M` and every `d > 0` there is `0 < b < d` with `M < (G b).1` |

### `Task01.lean` — principal final theorems
`task01_restriction`, `task01_idempotents`, `task01_unique_decomposition`,
`task01_Q2_eq_product`, `task01_strata`, `task01_boost_action`,
`task01_invariant_product`, `task01_boundary_family`,
`task01_boundary_family_minus`, `task01_regimes`.

---

## 3. Dependency graph

```
3+1 Lorentz form                      (Q4, Basic.lean)
    ↓                                 [Q4_iota]
longitudinal 1+1 subspace             (iota, Q2)
    ↓                                 [jL_mulL_jL, ep_eq, em_eq]
split-complex idempotents             (mulL, ep, em)
    ↓                                 [P_qp_qm, qp_P, qm_P, nullEquiv, Q2_P]
complementary null coordinates        (qp, qm, P)
    ↓                                 [futureCausal_iff, strata_exhaustive, strata_disjoint,
    ↓                                  Q2_eq_zero_iff, Q2_pos_iff_interior]
causal-stratum classification         (FutureCausalCoeff, IsZero/IsPlusBoundary/…)
    ↓                                 [Q4_B4, Q2_B, B_ep, B_em, B_P]
longitudinal boost action             (B, B4)
    ↓                                 [invProd_boost_direct, invProd_boost_via_Q2]
invariant product                     (invProd)
    ↓                                 [tendsto_Fp, tendsto_Fm, Q2_G, not_tendsto_G]
boundary families                     (Fp, Fm, G)
```

Additional assumptions required by individual arrows, beyond the listed inputs:

* *split-complex idempotents → null coordinates*: none beyond the field
  operations of `ℝ` (the factor `1/2` requires `2 ≠ 0` in `ℝ`).
* *causal-stratum classification*: none; the correspondence
  `0 ≤ a ∧ 0 ≤ b ↔ 0 ≤ t ∧ 0 ≤ Q2` is an ordered-field statement about `ℝ`.
* *longitudinal boost action*: the standard real hyperbolic identities
  `cosh²η − sinh²η = 1`, `cosh η + sinh η = exp η`, `cosh η − sinh η = exp(−η)`
  (imported from Mathlib, see §9).
* *invariant product*: `exp(−η) = (exp η)⁻¹` and `exp η ≠ 0` for the direct
  proof; `Q2_B`, `B_P`, `Q2_P` for the corollary proof.
* *boundary families*: the standard product topology on `Long = ℝ × ℝ`, and
  `I > 0` for the Regime-B divergence statement (`Q2_G` itself needs only
  `b ≠ 0`).

All arrows are algebraic or kinematic. No dynamical dependency is claimed or
implied by any of them.

---

## 4. Causal-stratum table

Sector: `FutureCausalCoeff a b`, i.e. `0 ≤ a ∧ 0 ≤ b`; vector `(t,x) = P a b`,
so `t = (a+b)/2`, `x = (a−b)/2`.

| Stratum | Coefficient condition | Vector | `Q2 (P a b)` | Lean names |
| --- | --- | --- | --- | --- |
| `zero` | `a = 0 ∧ b = 0` | `(0,0)` | `= 0` | `IsZero`, `Q2_of_zero` |
| `plusBoundary` | `0 < a ∧ b = 0` | `(a/2, a/2)`, `t = x > 0` | `= 0` | `IsPlusBoundary`, `Q2_of_plusBoundary` |
| `minusBoundary` | `a = 0 ∧ 0 < b` | `(b/2, −b/2)`, `t = −x > 0` | `= 0` | `IsMinusBoundary`, `Q2_of_minusBoundary` |
| `interior` | `0 < a ∧ 0 < b` | `t > \|x\|` | `> 0` | `IsInterior`, `Q2_of_interior` |

Exhaustive: `strata_exhaustive`. Mutually exclusive: `strata_disjoint`.
Converses inside the sector: `Q2_eq_zero_iff` (vanishing `Q2` ⟺ zero or one of
the two boundary strata) and `Q2_pos_iff_interior` (positive `Q2` ⟺ interior).

---

## 5. Boost-transformation table

| Object | Image under `B η` | Lean name |
| --- | --- | --- |
| `(t,x)` | `(cosh η·t + sinh η·x, sinh η·t + cosh η·x)` | `B` (definition) |
| `(t,x,y,z)` | boost in `(t,x)`, `y`, `z` unchanged | `B4` (definition) |
| `ι X` | `ι (B η X)` | `B4_iota` |
| `Q4 X` | unchanged | `Q4_B4` |
| `Q2 X` | unchanged | `Q2_B` |
| `e₊` | `exp(η) • e₊` | `B_ep` |
| `e₋` | `exp(−η) • e₋` | `B_em` |
| `q₊ X` | `exp(η) · q₊ X` | `qp_B` |
| `q₋ X` | `exp(−η) · q₋ X` | `qm_B` |
| `P a b` | `P (exp(η)·a) (exp(−η)·b)` | `B_P` |

The exponential factors are *derived* from `Real.cosh_add_sinh` and
`Real.cosh_sub_sinh`; they are not postulated.

---

## 6. Invariant-product result

`invProd a b = a · b` satisfies

```
invProd (exp η · a) (exp (−η) · b) = invProd a b .
```

Two independent proofs are recorded, with clearly separated dependencies:

1. **`invProd_boost_direct`** — depends only on the exponential API
   (`Real.exp_neg`, `Real.exp_ne_zero`, via `field_simp`). It does **not** use
   `Q2`, `Q2_B`, `Q2_P` or the boost definition.
2. **`invProd_boost_via_Q2`** — depends on `Q2_B` (Lorentz invariance of the
   quadratic form), `B_P` (the boost action in null coordinates), and `Q2_P`
   (the null-coordinate formula `Q2 (P a b) = a·b`). It uses no exponential
   identity beyond those already used inside `B_P`.

The relation to `Q2` is exactly `Q2_P`: the invariant product is the value of the
Lorentz quadratic form on `P a b`, so its boost invariance is the null-coordinate
transcription of `Q2_B`.

---

## 7. Regime A / Regime B comparison

Both regimes are taken along `b → 0⁺` (resp. `ε → 0⁺`), i.e. along the filter
`𝓝[>] (0 : ℝ)` in `ℝ`, with limits in the standard topology of `Long`.

| | Regime A: `P (a₀, ε)`, `a₀` fixed | Regime B: `G(b) = P (I/b, b)`, `I > 0` fixed |
| --- | --- | --- |
| Quadratic form | `Q2 = a₀·ε` (`Q2_Fp`), tends to `0` (`tendsto_Q2_Fp`) | `Q2 = I` constant (`Q2_G`) |
| First coordinate `t` | `(a₀+ε)/2 → a₀/2` | `(I/b + b)/2 → +∞` (`tendsto_G_fst_atTop`) |
| Vector limit | exists: `P(a₀,0)` (`tendsto_Fp`) | **does not exist** in `Long` (`not_tendsto_G`) |
| Stratum data | `ε > 0`: interior; endpoint: `plusBoundary` | every member interior; no endpoint in the carrier |
| Unboundedness | none | `G_unbounded`: coordinates exceed any `M` arbitrarily close to `0` |

So the two constraints are mathematically distinct: fixing one coefficient
produces a convergent family whose invariant product degenerates to `0`, whereas
fixing the invariant product at `I > 0` produces a family that leaves every
bounded set of the carrier and has no limit there. No projective completion is
introduced; the obstruction is recorded as an actual non-convergence theorem.

---

## 8. Unresolved mathematical obligations

None outstanding for the stated scope. Explicitly:

* the development contains no `sorry`, no `admit`, no `axiom`;
* every acceptance criterion of the task is realized by a named theorem
  (see §2 and the mapping in §10);
* the only "negative" result requested — the absence of a finite vector limit in
  Regime B — is proved (`not_tendsto_G`), not assumed.

Deliberately **not** addressed (out of scope by the task statement): any
projective or conformal completion of the carrier, any structure beyond the
fixed longitudinal plane, transverse directions other than as inert coordinates,
and any interpretation of the coefficients `a`, `b`, of the product `a·b`, or of
the parameter `ε`.

---

## 9. Source ledger

### IMPORTED STANDARD RESULT (Mathlib, revision `8f9d9cff6bd728b17a24e163c9402775d9e6a365`)

| Declaration | Mathlib module | Used for |
| --- | --- | --- |
| `Real.cosh_sq_sub_sinh_sq` | `Mathlib/Analysis/Complex/Trigonometric.lean` | `Q4_B4`, `Q2_B` |
| `Real.cosh_add_sinh` | `Mathlib/Analysis/Complex/Trigonometric.lean` | `B_ep`, `B_P` |
| `Real.cosh_sub_sinh` | `Mathlib/Analysis/Complex/Trigonometric.lean` | `B_em`, `B_P` |
| `Real.exp_neg` | `Mathlib/Analysis/Complex/Exponential.lean` | `invProd_boost_direct` (via `field_simp`) |
| `tendsto_inv_nhdsGT_zero` | `Mathlib/Topology/Algebra/Order/Field.lean` | `tendsto_G_fst_atTop` |
| `Filter.Tendsto.const_mul_atTop` | `Mathlib/Order/Filter/AtTopBot/Field.lean` | `tendsto_G_fst_atTop` |
| `Filter.Tendsto.atTop_add` (`to_additive` of `Filter.Tendsto.atTop_mul'`) | `Mathlib/Topology/Order/LeftRightNhds.lean` | `tendsto_G_fst_atTop` |
| `Filter.Tendsto.atTop_div_const` | `Mathlib/Order/Filter/AtTopBot/Field.lean` | `tendsto_G_fst_atTop` |
| `not_tendsto_nhds_of_tendsto_atTop` | `Mathlib/Topology/Order/OrderClosed.lean` | `not_tendsto_G` |
| `nhdsWithin_le_nhds`, `Continuous.tendsto` | `Mathlib/Topology/ContinuousOn.lean`, `Mathlib/Topology/Basic.lean` | Regime-A limits |
| `Metric.eventually_nhds_iff`, `Real.dist_eq` | `Mathlib/Topology/MetricSpace/*` | `G_unbounded` |

Standard mathematical background (textbook level, not needed as an extra
assumption anywhere): the Lorentz form of signature `(+,−,−,−)`, hyperbolic
parameterization of proper orthochronous boosts, and the split-complex (double)
numbers `ℝ ⊕ ℝ j`, `j² = 1`, with its idempotent basis. These are covered, e.g.,
by the standard treatment of Minkowski geometry in general relativity textbooks
(Misner–Thorne–Wheeler, *Gravitation*, ch. 1–2) and by the classical theory of
the split-complex numbers. In the present development every such fact is
re-derived from the definitions rather than imported informally.

### DERIVED IN TASK 01

All declarations listed in §1 and §2 are defined and proved inside this project,
from the definitions above plus the imported Mathlib results in the table.

---

## 10. Build and axiom report

Environment:

* Lean toolchain `leanprover/lean4:v4.28.0` (`lean-toolchain`);
* Mathlib `v4.28.0`, commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365`
  (`lake-manifest.json`).

Imports actually used:

* `RequestProject/NullSectorTask01/Basic.lean`: `import Mathlib`;
* `SplitComplex.lean`: `import RequestProject.NullSectorTask01.Basic`;
* `Strata.lean`: `import RequestProject.NullSectorTask01.SplitComplex`;
* `Boost.lean`: `import RequestProject.NullSectorTask01.SplitComplex`;
* `Limits.lean`: `import RequestProject.NullSectorTask01.Strata`,
  `import RequestProject.NullSectorTask01.Boost`;
* `Task01.lean`: imports all five modules above.

Build: `lake build` completes successfully for the whole `RequestProject`
library, including `RequestProject.NullSectorTask01.Task01`. No `sorry`,
`admit`, custom `axiom`, or `@[implemented_by]` occurs in the development.

Axiom dependencies (`#print axioms`) of the principal final theorems — each of

`task01_restriction`, `task01_idempotents`, `task01_unique_decomposition`,
`task01_Q2_eq_product`, `task01_strata`, `task01_boost_action`,
`task01_invariant_product`, `task01_boundary_family`,
`task01_boundary_family_minus`, `task01_regimes`,
and additionally `Q4_B4`, `invProd_boost_via_Q2` —

depends exactly on

```
[propext, Classical.choice, Quot.sound]
```

i.e. only on the standard Lean/Mathlib axioms.

### Acceptance-criterion mapping

| Criterion | Theorem |
| --- | --- |
| 1 restriction of the Lorentz form | `task01_restriction` (`Q4_iota`) |
| 2 idempotents complementary and null | `task01_idempotents` |
| 3 unique decomposition | `task01_unique_decomposition`, `nullEquiv` |
| 4 `Q2 (P a b) = a·b` | `task01_Q2_eq_product` (`Q2_P`) |
| 5 partition of the causal quadrant | `task01_strata`, `strata_disjoint` |
| 6 reciprocal boost scaling | `task01_boost_action` (`B_P`) |
| 7 invariance of `a·b` | `task01_invariant_product` (+ `invProd_boost_via_Q2`) |
| 8 boundary limit of `P(a₀,ε)` | `task01_boundary_family` (`tendsto_Fp`) |
| 9 Regime A vs Regime B | `task01_regimes` (`tendsto_Fp` vs `not_tendsto_G`) |
| 10 no additional structure | by inspection: the only defined objects are those in §1 |
