# TASK 10 AUDIT

**Split-Complex Lorentz Dynamics — Experiment 2, Task 10**
Distinguished momentum axis: longitudinal/transverse sectors, integer- versus half-angle
action, and a first evolution probe.

All Task-10 results are carrier-and-transformation results. No physical object, no state
space, no evolution law and no dynamical equation is derived or assumed anywhere in this
task.

---

## 1. Exact toolchain

| Item | Value |
| --- | --- |
| Lean toolchain | `leanprover/lean4:v4.28.0` (`lean-toolchain`) |
| Mathlib | tag `v4.28.0`, commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (`lake-manifest.json`) |
| Build target | `RequestProject` library (`lakefile.toml`, glob `RequestProject.+`) |
| Task-10 entry point | `RequestProject/NullSectorTask10/Task10.lean` |

No toolchain change was made for Task 10.

### Mathlib declarations actually used in Task 10

`IMPORTED STANDARD RESULT` in every case below.

| Declaration | Mathlib module | Used for |
| --- | --- | --- |
| `Real.sin_sq_add_cos_sq` | `Mathlib/Analysis/SpecialFunctions/Trigonometric/Basic` | Pythagorean identity |
| `Real.cos_add`, `Real.sin_add` | same | rotation and lift group laws |
| `Real.cos_two_mul`, `Real.sin_two_mul` | same | derivation of the half angle |
| `Real.cos_neg`, `Real.sin_neg` | same | inverse of the lift |
| `Real.cos_pi`, `Real.sin_pi`, `Real.cos_two_pi`, `Real.sin_two_pi`, `Real.cos_pi_div_two`, `Real.sin_pi_div_two` | same | `2π`/`4π` values |
| `Real.hasDerivAt_cos`, `Real.hasDerivAt_sin` | `Mathlib/Analysis/SpecialFunctions/Trigonometric/Deriv` | infinitesimal generator |
| `hasDerivAt_pi`, `hasDerivAt_const`, `HasDerivAt.mul_const`, `.add`, `.sub` | `Mathlib/Analysis/Calculus/Deriv/*` | infinitesimal generator |
| `Real.exp_zero`, `Real.exp_add`, `Real.exp_ne_zero`, `Real.exp_eq_one_iff` | `Mathlib/Analysis/SpecialFunctions/Exp` | the second internal lift |
| `Submodule.span`, `Submodule.span_le`, `Submodule.mem_span_pair`, `Submodule.mem_span_singleton`, `Submodule.mem_inf`, `Submodule.mem_sup_left/right` | `Mathlib/LinearAlgebra/Span/*` | all submodule work |
| `finrank_span_eq_card`, `finrank_span_singleton`, `Fintype.linearIndependent_iff` | `Mathlib/LinearAlgebra/*` | exact dimensions |
| `smul_left_injective`, `mul_self_pos`, `inv_ne_zero`, `eq_div_iff`, `inv_mul_eq_div` | `Mathlib/Algebra/*` | scalar bookkeeping |

Everything else in Task 10 is `DERIVED IN TASK 10` or inherited from Tasks 01/04/07/08/09
of this same project.

---

## 2. Exact Task-08/09 imports

Task 10 has exactly **one** external import, in `SafeBase.lean`:

```
import RequestProject.NullSectorTask09.Existence
```

Every other Task-10 module imports only its immediate Task-10 predecessor:

```
Task09.Existence
   ↓
Task10.SafeBase
   ↓
Task10.AxisDecomposition
   ↓
Task10.OldAxialRotation
   ↓
Task10.AlgebraExtension
   ↓
Task10.VectorChannels
   ↓
Task10.InternalLift
   ↓
Task10.StateAction
   ↓
Task10.HalfAngleSectors
   ↓
Task10.AxialDerivation
   ↓
Task10.DynamicsDiagnostic
   ↓
Task10.Identification
   ↓
Task10.Task10
```

Inherited data actually used:

* carrier `W = Wit8 = Fin 8 → ℝ`, product `wit8Mul` (notation `⋆`), unit `w1`;
* derived basis `w1, wA, wB, wC, wP, wQ, wR, wS` and the complete Task-08 multiplication
  table (`wit8_wX_wY`) and coordinate lemmas (`wit8Mul_coord_i`);
* the arithmetic helper lemmas of `Task09.SafeBase`;
* the old carrier `Vec4`, `Q4`, `L4`, `Rest`, `dot3`, `e₀`, `dirA`, `dirB`, `dirC`;
* the embedding `ι₃ = iota3 : Vec4 →ₗ[ℝ] W`;
* the Task-09 central plane `Z = spanℝ{1, S}` with `mem_Z_iff`, `central_mul_rule`,
  `finrank_Z = 2`;
* the Task-09 coefficient functions `nRe`, `nSc` and the two branches `Ncand 1` (`N₊`)
  and `Ncand (-1)` (`N₋`).

`Task09.Identification` (the Task-09 conventional identification layer) is **not**
imported by any Task-10 module.

---

## 3. Experiment-1 firewall

No Experiment-1 result, terminology, construction, representation, formula, source or Lean
declaration is used. Task 10 imports exactly one module, `RequestProject.NullSectorTask09.Existence`,
which belongs to the cumulative Experiment-2 development; the transitive closure of that
import contains only Experiment-2 modules and Mathlib.

---

## 4. Representation-target firewall

Mechanical scan of the eleven reconstruction modules

```
SafeBase, AxisDecomposition, OldAxialRotation, AlgebraExtension, VectorChannels,
InternalLift, StateAction, HalfAngleSectors, AxialDerivation, DynamicsDiagnostic
```

for the forbidden target names

```
spin, spin-1, spin-1/2, helicity, photon, fermion, spinor, Pauli, SU(2), Spin(3),
double cover, Weyl, Dirac, polarization vector, Jones vector, rotor, Maxwell,
Hamiltonian, gauge
```

returns hits only inside firewall statements that *declare the words unused* (the module
docstring of `SafeBase.lean`, the neutral-terminology note of `VectorChannels.lean`, and
the "`λ` is not an energy, mass, frequency or Hamiltonian" disclaimer of
`DynamicsDiagnostic.lean`). No such word occurs as a definition, a theorem name, an import
or a construction target.

No standard representation, rotor implementation, matrix representation or Lie-group
construction is imported anywhere in Task 10.

`Identification.lean` is the only module using conventional terminology, every statement in
it is labelled **COMPARISON ONLY**, and it is imported only by `Task10.lean`.

---

## 5. Distinguished-axis definition

```lean
def axis : Vec4 := dirA                       -- (0, 1, 0, 0)
def Long  : Submodule ℝ Vec4 := Submodule.span ℝ {axis}
def Trans : Submodule ℝ Vec4 := Submodule.span ℝ {dirB, dirC}
```

`axis` is one inherited normalized old spatial direction and nothing else. Within the
Task-10 core it is called **DISTINGUISHED AXIS**; the words *momentum*, *particle*,
*mass*, *energy*, *frequency* and *wavelength* are never attached to it.

Carrier-side counterparts:

```lean
def LongW  : Submodule ℝ W := Submodule.span ℝ {wA}
def TransW : Submodule ℝ W := Submodule.span ℝ {wB, wC}
```

---

## 6. Longitudinal/transverse decomposition

`DERIVED IN TASK 10` (`AxisDecomposition.lean`):

| Statement | Name |
| --- | --- |
| `Long ≤ Rest`, `Trans ≤ Rest` | `Long_le_Rest`, `Trans_le_Rest` |
| `Long ⊓ Trans = ⊥` | `Long_inf_Trans` |
| `Long ⊔ Trans = Rest` | `Long_sup_Trans` |
| complementarity inside `Rest` | `rest_isCompl` |
| uniqueness of the decomposition | `rest_decomp_unique` |
| `dot3 axis X = 0` for `X ∈ Trans` | `axis_orthogonal_Trans` |

Answer to Conservation-of-Difficulty question 1: **yes**, `Rest = Long ⊕ Trans`
(`task10_axis_decomposition`).

---

## 7. Old axial rotation

```lean
noncomputable def rot (θ : ℝ) : Vec4 →ₗ[ℝ] Vec4
rot θ (t, a, b, c) = (t, a, cos θ * b - sin θ * c, sin θ * b + cos θ * c)
```

| Statement | Name |
| --- | --- |
| `rot θ e₀ = e₀`, `rot θ axis = axis` | `rot_e₀`, `rot_axis` |
| `rot θ B = cos θ • B + sin θ • C` | `rot_dirB` |
| `rot θ C = -sin θ • B + cos θ • C` | `rot_dirC` |
| `rot 0 = id` | `rot_zero` |
| `rot (θ + φ) = rot θ ∘ rot φ` | `rot_add` |
| `rot (2π) = id` | `rot_two_pi` |
| `Q4 (rot θ X) = Q4 X` | `Q4_rot` |
| `dot3 (rot θ X) (rot θ Y) = dot3 X Y` | `dot3_rot` |
| `Long`, `Trans` preserved | `rot_mem_Long`, `rot_mem_Trans` |

No lift inside `W` is introduced at this stage.

---

## 8. Algebra-extension existence and uniqueness

The extension problem is posed *before* any candidate exists:

```lean
structure IsAxialExtension (θ : ℝ) (Φ : W →ₗ[ℝ] W) : Prop where
  unital : Φ w1 = w1
  mul    : ∀ x y, Φ (x ⋆ y) = Φ x ⋆ Φ y
  old    : ∀ X : Vec4, Φ (iota3 X) = iota3 (rot θ X)
```

**Uniqueness first.** Because `W` is generated multiplicatively by `1, A, B, C`, the values
of any extension on `P, Q, R, S` are *forced*:

`forced_wA`, `forced_wB`, `forced_wC`, `forced_wP`, `forced_wQ`, `forced_wR`, `forced_wS`,
then `axialExtension_unique`.

**Existence afterwards.** The explicit map `Phi θ` is written down only after the forced
values are known; `Phi_mul`, `Phi_iota3`, `Phi_isAxialExtension` and finally

```lean
theorem axialExtension_existsUnique (θ : ℝ) : ∃! Φ : W →ₗ[ℝ] W, IsAxialExtension θ Φ
```

Answer to question 2: **yes, uniquely** (`task10_algebra_extension`).

Group law (`Phi_zero`, `Phi_add`, `Phi_two_pi`, `Phi_four_pi`, `Phi_neg_comp`,
`Phi_bijective`) gives `Φ 0 = id`, `Φ(θ+φ) = Φθ ∘ Φφ` and `Φ(2π) = id` on the *entire*
algebra.

---

## 9. Complete action on the Task-08 basis

`DERIVED IN TASK 10`, not prescribed (`task10_extension_on_basis`):

| `x` | `Φθ x` |
| --- | --- |
| `1` | `1` |
| `A` | `A` |
| `B` | `cos θ • B + sin θ • C` |
| `C` | `-sin θ • B + cos θ • C` |
| `P = AB` | `cos θ • P + sin θ • Q` |
| `Q = AC` | `-sin θ • P + cos θ • Q` |
| `R = BC` | `R` |
| `S = ABC` | `S` |

Both Task-09 norm branches are preserved *separately*, not exchanged
(`nRe_Phi`, `nSc_Phi`, `Ncand_Phi`, `both_branches_preserved`,
`task10_both_branches_preserved`):

```
N₊(Φθ x) = N₊(x)      and      N₋(Φθ x) = N₋(x)      for all θ, x.
```

---

## 10. Longitudinal/transverse channel classification

Real level (`VectorChannels.lean`):

* `Phi_fixes_LongW` — the longitudinal line is fixed pointwise;
* `Phi_preserves_TransW` — the transverse plane is preserved;
* `Phi_fixed_iff`, `Phi_fixed_rest_iff` — for `sin θ ≠ 0` the fixed set inside the old
  rest carrier is exactly `LongW`;
* `TransW_irreducible` — for `sin θ ≠ 0` the transverse plane has no proper nonzero
  invariant subspace, so no further invariant old spatial subspace is forced.

`Z`-level, using the already derived central plane `Z = spanℝ{1, S}` (`zsc u v := u•1 + v•S`)
and `Zline ψ := spanℝ{ψ, S ⋆ ψ}`:

```lean
def chPlus  : W := wB - wP
def chMinus : W := wB + wP
```

| Channel | Transformation factor | Name |
| --- | --- | --- |
| longitudinal `LongW` | `zsc 1 0` | `Phi_on_LongW` |
| `Zline chPlus` | `zsc (cos θ) (sin θ)` | `Phi_on_Zline_chPlus` |
| `Zline chMinus` | `zsc (cos θ) (−sin θ)` | `Phi_on_Zline_chMinus` |

Exactness (`zChannel_classification`): a nonzero `ψ` in the `Z`-linear transverse span
transforms under every `Φθ` by multiplication by a single element of `Z` **iff** it lies in
`Zline chPlus ∪ Zline chMinus`. Neither the lines nor the factors were prescribed.

The two transverse factors are mutually inverse (`transverse_factors_inverse`) and the three
factors are pairwise distinct (`channel_factors_distinct`).

Answer to question 3: **one longitudinal fixed channel and two oppositely transforming
transverse `Z`-channels** (`task10_channel_classification`).

Answer to question 4: **yes**, `Φ(2π) = id` on the whole algebra (`task10_algebra_two_pi`).

---

## 11. Internal-lift existence and classification

The lift problem (`InternalLift.lean`, §16–17) is posed with **no formula**:

```lean
def K : Submodule ℝ W := Submodule.span ℝ {w1, wR}          -- R ⋆ R = -1

structure IsKLift (U : ℝ → W) : Prop where
  mem   : ∀ θ, U θ ∈ K
  unit  : U 0 = w1
  group : ∀ θ φ, U (θ + φ) = U θ ⋆ U φ
  conj  : ∀ θ x, (U θ ⋆ x) ⋆ U (-θ) = Phi θ x
```

**Existence.** `Ustd θ := cos (θ/2) • 1 − sin (θ/2) • R` is a lift (`Ustd_isKLift`).

**Derivation of the half angle.** The conjugation of a general normalized element of `K`
is computed (`conj_coords`): conjugation by `a•1 + b•R` with `a² + b² = 1` is the rotation
with data `(a² − b², −2ab)` — the *doubled* angle. Combining the group law at `(θ, −θ)`
with the conjugation condition on the transverse generator `B` yields four bilinear
equations whose unique solution, up to one scalar, is the half-angle formula. Nothing was
inserted by hand.

**Exact classification** (`klift_classification`):

```
IsKLift U  ↔  ∃ k : ℝ → ℝ, IsScalarFactor k ∧ ∀ θ, U θ = k θ • Ustd θ
```

where `IsScalarFactor k` means `k 0 = 1`, `k θ ≠ 0`, `k (θ+φ) = k θ * k φ`. Every scalar
factor really does give a lift (`klift_of_scalarFactor`), and every scalar factor is
automatically positive (`IsScalarFactor.pos`, since `k θ = k (θ/2)²`).

Answer to question 5: **yes**, an internal lift exists inside `K` (`task10_internal_lift_exists`).

Answer to question 6: **no**, the lift is *not* unique after `U 0 = 1`. The scalar factor
cannot be removed by any condition referring only to the conjugation action, because it
cancels there. An explicitly different lift is exhibited with `k θ = exp θ`
(`klift_not_unique`, `task10_internal_lift_classification`).

**A derived — not postulated — sharpening.** `klift_branch_forces_k`: if the lift is
additionally required to preserve the Task-09 branch `N₊` under **left multiplication**,

```
∀ θ ψ,  N₊ (U θ ⋆ ψ) = N₊ ψ,
```

then `k θ ² = 1`; with `k θ > 0` this forces `k ≡ 1` and hence `U = Ustd`. The condition is
stated purely in already-established Task-09 data and is independent of the conjugation
action. It appears as an explicit hypothesis of that theorem and of
`task10_internal_lift_normalized`, never as a global convention.

---

## 12. `2π`/`4π` periodicity comparison

| Object | `2π` | `4π` |
| --- | --- | --- |
| algebra action `Φ` | `Φ(2π) = id_W` (`Phi_two_pi`) | `Φ(4π) = id_W` (`Phi_four_pi`) |
| distinguished lift `Ustd` | `Ustd(2π) = −1` (`Ustd_two_pi`) | `Ustd(4π) = 1` (`Ustd_four_pi`) |
| general lift `U` | `U(2π) = (−c) • 1`, `c > 0` | `U(4π) = c² • 1` (`klift_periodicity`) |

The sharp value `−1` is a statement about the distinguished representative, or about a lift
carrying the derived branch-preservation hypothesis; it is **not** claimed for an arbitrary
lift. This is recorded again in §22 below.

Answer to question 7: `Ustd(2π) = −1`, `Ustd(4π) = 1`; for a general lift only
`U(2π) = −c • 1`, `U(4π) = c² • 1` with `c > 0`.

---

## 13. State-action definition

`W` is now regarded merely as a left module over itself. This is a **probe**: no external
state space is introduced and no minimal ideal is selected.

```lean
noncomputable def StateAction   (θ : ℝ) (ψ : W) : W := Ustd θ ⋆ ψ
noncomputable def StateActionOf (U : ℝ → W) (θ : ℝ) (ψ : W) : W := U θ ⋆ ψ
```

| Statement | Name |
| --- | --- |
| `StateAction 0 ψ = ψ` | `StateAction_zero` |
| `StateAction (θ+φ) ψ = StateAction θ (StateAction φ ψ)` | `StateAction_add` |
| `StateAction (2π) ψ = −ψ` | `StateAction_two_pi` |
| `StateAction (4π) ψ = ψ` | `StateAction_four_pi` |
| `StateAction (2π) ψ ≠ ψ` for `ψ ≠ 0` | `StateAction_two_pi_ne` |
| general lift: `= (−c) • ψ`, `c > 0` | `stateAction_two_pi_general` |
| general lift: `= c² • ψ` | `stateAction_four_pi_general` |

**§24 comparison, at theorem level** (`algebra_vs_state_two_pi`,
`algebra_ne_state_two_pi`, `task10_state_action_periodicity`, `task10_algebra_vs_state`):

```
Φ(2π) x = x        (algebra / observable transformation)
StateAction (2π) x = −x   (left-state transformation)
Φ(2π) x ≠ StateAction (2π) x   whenever x ≠ 0.
```

Answer to question 8: **yes**, the left action of the lift shows half-angle behaviour.

---

## 14. Half-angle-sector classification

Sectors (`HalfAngleSectors.lean`), defined by left multiplication by the transverse
generator `R` against the central element `S`:

```lean
SectorPlus  = {ψ | R ⋆ ψ = + S ⋆ ψ}
SectorMinus = {ψ | R ⋆ ψ = − S ⋆ ψ}
```

`DERIVED IN TASK 10`:

| Statement | Name |
| --- | --- |
| `R ψ = ±S ψ ⟺ A ψ = ±ψ` (axis eigenspaces) | `mem_SectorPlus_iff_axis`, `mem_SectorMinus_iff_axis` |
| coordinate form | `mem_SectorPlus_iff_coords`, `mem_SectorMinus_iff_coords` |
| real spanning families | `SectorPlus_eq_span`, `SectorMinus_eq_span` |
| linear independence | `sPlusB_indep`, `sMinusB_indep` |
| exact real dimension `4` (= `Z`-dimension `2`) | `finrank_SectorPlus`, `finrank_SectorMinus` |
| both nonzero | `SectorPlus_ne_bot`, `SectorMinus_ne_bot` |
| two `Z`-lines each | `SectorPlus_eq_two_Zlines`, `SectorMinus_eq_two_Zlines` |
| trivial intersection | `SectorPlus_inf_SectorMinus` |
| together span `W` | `SectorPlus_sup_SectorMinus` |
| preserved by the state action | `StateAction_mem_SectorPlus/Minus` |

Explicitly, `SectorPlus = Zline (1 + A) ⊔ Zline (B + P)` and
`SectorMinus = Zline (1 − A) ⊔ Zline (B − P)`.

**Half-angle weights (§22).** With
`vectorFactorPlus θ := zsc (cos θ) (sin θ)` and `vectorFactorMinus θ := zsc (cos θ) (−sin θ)`
— exactly the two *transverse vector* channel factors of §10 —

```
ψ ∈ SectorPlus   ⟹   StateAction θ ψ = vectorFactorMinus (θ/2) ⋆ ψ
ψ ∈ SectorMinus  ⟹   StateAction θ ψ = vectorFactorPlus  (θ/2) ⋆ ψ
```

(`halfAngle_SectorPlus`, `halfAngle_SectorMinus`). The angular dependence of the sectors is
therefore exactly **half** that of the transverse vector channels; the term
**HALF-ANGLE SECTOR** is used only because this was formally established.

For a general lift `U = k • Ustd` the same statement holds with the common extra scalar
`k θ`; the scalar is identical on both sectors and so does not affect the weight comparison.

Answer to question 9: the sectors above, of `Z`-dimension `2` each, together spanning `W`.

---

## 15. Transverse-state-orientation verdict

**Verdict: NO — additional data would be required, and none is introduced.**

`no_canonical_transverse_state_orientation` (`task10_no_transverse_orientation`) exhibits

```
θ = π,     ψ = 1 + B ≠ 0,     B ⋆ ψ = ψ,
```

for which

```
StateAction π ψ = C − R      and      B ⋆ (C − R) = −(C − R) ≠ C − R.
```

So the analogous eigenspace condition along a *transverse* generator is **not** preserved by
the state action, whereas the distinguished-axis sectors are (§14). The present algebraic
data therefore single out the distinguished axis and do **not** canonically determine a
state orientation inside the transverse `B`–`C` plane.

Answer to question 10: **further state data is required.**

---

## 16. Axial-derivation classification

Problem (`AxialDerivation.lean`, §25), with
`transForm x y := x 2 * y 2 + x 3 * y 3` the pullback of the inherited old Euclidean
rest-space form to the transverse coordinates (`transForm_iota3`):

```lean
structure IsAxialDerivation (D : W →ₗ[ℝ] W) : Prop where
  leibniz : ∀ x y, D (x ⋆ y) = D x ⋆ y + x ⋆ D y
  unit    : D w1 = 0
  axis    : D wA = 0
  trans   : ∀ x ∈ TransW, D x ∈ TransW
  skew    : ∀ x ∈ TransW, ∀ y ∈ TransW, transForm (D x) y + transForm x (D y) = 0
```

Solution, obtained by *solving*, not assuming: skewness forces `D B = l • C`,
`D C = −l • B` (`forced_transverse`), and Leibniz then forces

`D P = l • Q` (`deriv_forced_wP`), `D Q = −l • P` (`deriv_forced_wQ`),
`D R = 0` (`deriv_forced_wR`), `D S = 0` (`deriv_forced_wS`).

| Statement | Name |
| --- | --- |
| `IsAxialDerivation D ↔ ∃ l, D = l • Dgen` | `axialDerivation_classification` |
| the generator exists | `Dgen_isAxialDerivation` |
| exact dimension `1` | `finrank_axialDerivations` |
| uniqueness after `D B = C` | `axialDerivation_unique_of_orientation` |

Action of the normalized generator (`task10_generator_on_basis`):

| `x` | `1` | `A` | `B` | `C` | `P` | `Q` | `R` | `S` |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `Dgen x` | `0` | `0` | `C` | `−B` | `Q` | `−P` | `0` | `0` |

**Intrinsic formula (§27), derived after the classification** (`Dgen_eq_Ccom`,
`Dgen_eq_half_commutator`):

```
Dgen x = ½ • (x ⋆ R − R ⋆ x).
```

**Comparison with the infinitesimal generator of `Φθ`** (`hasDerivAt_Phi_zero`):

```
HasDerivAt (fun θ => Φθ x) (Dgen x) 0.
```

Answer to question 11: the solution space is exactly the real line `ℝ • Dgen`, of dimension
`1`.

---

## 17. Generator-rate freedom

`DynamicsDiagnostic.lean`, §28. The negative control succeeds:

* `scaled_isAxialDerivation` — for **every** real `λ`, `λ • Dgen` satisfies all the
  structural conditions;
* `generator_direction_fixed` — every axial derivation is such a multiple;
* `generator_rate_not_fixed` — distinct `λ` give distinct maps.

Hence, recorded exactly as §28 demands:

> **the current kinematic/algebraic structure fixes the generator direction but does not
> fix an evolution rate.**

`λ` is a real scalar. It is not an energy, a mass, a frequency or a Hamiltonian, and no rule
relating any evolution parameter to a generator scale is introduced. The rotation parameter
`θ` is never identified with a physical time.

A **second** independent unfixed scale is recorded (`lift_scale_not_fixed`): the
multiplicative scalar function of the internal-lift classification (§11).

Answer to question 12: **direction only**.

---

## 18. Conservation-of-Difficulty graph

```
Task-08/09 algebra  (W, ⋆, 1, A, B, C, P, Q, R, S, ι₃, Q4, Z, N₊, N₋)
        ↓                              [no new algebraic input]
distinguished old spatial axis A
        ↓                              [inherited old Euclidean rest form]
Rest = Long ⊕ Trans
        ↓                              [ordinary old spatial rotation about A]
rot θ : one-parameter old isometry group
        ↓                              [multiplicative generation by 1,A,B,C]
Φθ : unique algebra-automorphism extension            → Φ(2π) = id
        ↓                              [central plane Z, already derived]
longitudinal weight-0 channel  +  two transverse Z-channels
        ↓                              [K = span{1,R}, R² = −1, already derived]
internal lift U : classified as k • Ustd, half angle DERIVED
        ↓                              ├── free scalar k  ▲ UNFIXED SCALE 1
        ↓                              └── k ≡ 1 only under the derived branch condition
StateAction θ ψ = U θ ⋆ ψ                              → Ustd(2π) = −1  vs  Φ(2π) = id
        ↓                              [left multiplication by R against S]
half-angle sectors R ψ = ±S ψ, Z-dimension 2 each
        ↓
transverse state orientation NOT selected              ▲ ADDITIONAL DATA REQUIRED
        ↓                              [Leibniz + axis annihilation + skewness]
axial derivations = ℝ • Dgen, dim 1, Dgen = ½(·R − R·)
        ↓
generator direction fixed, rate free                   ▲ UNFIXED SCALE 2
```

Arrows requiring an assumption beyond the inherited data:

* `internal lift → k ≡ 1` requires the *extra hypothesis* of §11 (branch preservation under
  left multiplication). Without it only `U = k • Ustd` is available.
* No arrow in the graph is a dynamical dependency. All are algebraic or kinematic.

---

## 19. Late conventional comparison — COMPARISON ONLY

`Identification.lean`, imported only by `Task10.lean`. Every statement is labelled
**COMPARISON ONLY** and is a restatement of an already proved neutral result.

1. `comparison_vector_weights` — the longitudinal channel carries the constant factor
   `zsc 1 0` (weight `0`) and the two transverse `Z`-channels carry the mutually inverse
   factors `zsc (cos θ) (±sin θ)` (weights `±1`). This is the pattern of the axial
   decomposition of a conventional spin-1 representation.
2. `comparison_double_valued_lift` — `Φ(2π) = id`, `Ustd(2π) = −1`, `Ustd(4π) = 1`: the
   pattern conventionally described as the double-valued lift of spatial rotations.
   `comparison_lift_scale_freedom` records that the lift is not unique, so any conventional
   identification must also fix the scalar freedom.
3. `comparison_half_angle_sectors` — the two distinguished-axis sectors transform with the
   transverse vector factor at half the angle, with opposite senses: the transformation law
   conventionally associated with projections `±1/2` along the distinguished axis.
   `comparison_transverse_orientation_requires_more_data` records that a transverse
   orientation would conventionally require a superposition or a further state-axis choice.
4. `comparison_generator` — `Dgen` is the derivative of `Φθ` at `θ = 0` and equals
   `½(x R − R x)`: the pattern of the usual infinitesimal generator of rotations about a
   distinguished axis. `comparison_no_rate_selected` records that the scale is not fixed.

**§32 spin-1 diagnostic (COMPARISON ONLY).** The weight-`0` longitudinal channel
(`comparison_longitudinal_channel_is_fixed`) is a transformation-theoretic fact about the
carrier only. Conventional massive spin-1 representations may contain a longitudinal mode,
whereas a physical massless spin-1 field carries additional constraints that remove a
longitudinal physical polarization. Task 10 neither derives nor imposes such constraints.

**§33 spin-1/2 diagnostic (COMPARISON ONLY).** The two half-angle sectors support the
conventional reading as projections `±1/2` along the distinguished axis. Separately: a spin
orientation transverse to the distinguished axis would require a superposition or a further
state-axis choice; §15 proves that the present data do **not** canonically select one.

**§31 physical-interpretation firewall.** No photon, no fermion, no physical longitudinal
polarization mode and no physical half-integer state has been derived. Task 10 establishes
transformation structure only.

### Outcome (§35)

The proved results match **Outcome C**: a half-angle lift and distinguished-axis state
sectors are reconstructed, but transverse state orientation requires additional data. Two
refinements must be attached, both proved rather than assumed:

* the half-angle lift is **not unique** — a multiplicative scalar function remains free
  (§11), so the sharp `U(2π) = −1` is a statement about a distinguished representative or
  about a lift carrying the derived branch-preservation hypothesis;
* the axial evolution probe fixes only a generator direction, not a rate (§17), which is the
  `Outcome E` component of the answer.

---

## 20. Build report

```
$ lake build
Build completed successfully (8120 jobs).

$ lake build RequestProject.NullSectorTask10.Task10
Build completed successfully.
```

Scan for `sorry`, `admit`, `axiom` declarations and `@[implemented_by]` over
`RequestProject/NullSectorTask10/`: **no occurrences**.

The build is free of errors and of linter warnings, and no linter is disabled anywhere in
Task 10.

---

## 21. Axiom report

`#print axioms` for all twenty-one principal Task-10 theorems (see the end of
`Task10.lean`) reports, in every case, exactly

```
[propext, Classical.choice, Quot.sound]
```

covering

```
task10_axis_decomposition            task10_old_axial_rotation
task10_algebra_extension             task10_extension_on_basis
task10_vector_sectors                task10_channel_classification
task10_both_branches_preserved       task10_algebra_two_pi
task10_internal_lift_exists          task10_internal_lift_classification
task10_internal_lift_normalized      task10_lift_periodicity
task10_lift_periodicity_general      task10_state_action_periodicity
task10_algebra_vs_state              task10_half_angle_sectors
task10_no_transverse_orientation     task10_axial_derivations
task10_generator_on_basis            task10_rate_freedom
task10_identification
```

No custom axiom is introduced anywhere in the project by Task 10.

---

## 22. Unresolved mathematical obligations

1. **The internal-lift scalar freedom is genuinely open.** `klift_classification` leaves a
   multiplicative, nowhere-vanishing, normalized function `k : ℝ → ℝ` free, and
   `klift_not_unique` shows the freedom is realized. No condition formulated purely in terms
   of the conjugation action can remove it, since `k` cancels there. The sharp statements
   `U(2π) = −1` and `StateAction (2π) ψ = −ψ` are therefore stated for the distinguished
   representative `Ustd`, or under the explicit derived hypothesis of
   `klift_branch_forces_k`. Whether some *other* already-established datum of Tasks 01–09
   also forces `k ≡ 1` is not settled here.
2. **No continuity or measurability hypothesis was needed or imposed on `k`.** The
   classification is purely algebraic; the standard analytic classification of multiplicative
   functions `ℝ → ℝ_{>0}` (which would give `k θ = exp (α θ)` under continuity) is *not*
   proved here, and no such hypothesis is used.
3. **Lifts outside `K` are not classified.** §17 asked whether a lift may be chosen inside
   `K = spanℝ{1, R}`; the answer is yes, and the lifts *inside* `K` are classified exactly.
   Whether the full algebra `W` admits further, essentially different, conjugation-implementing
   one-parameter families outside `K` is not addressed.
4. **Only the derivative at `θ = 0` is established.** `hasDerivAt_Phi_zero` identifies `Dgen`
   as the infinitesimal generator at the identity. A full analytic Lie-theoretic development
   (`Φθ = exp (θ Dgen)`, differentiability at every `θ`) is not carried out; §27 explicitly
   permits this.
5. **Generator scale.** Nothing in the reconstructed structure selects a scale for the axial
   generator. A later theory would need an additional rule relating an evolution parameter to
   a generator scale; Task 10 determines only that no such scale is already fixed.
6. **Transverse state orientation.** §15 proves that the present data do not select one. What
   *additional* datum would select one is deliberately not investigated.
7. **State space.** `W` was used only as a left module over itself, as a probe. Whether any
   physically meaningful state space exists, and whether these sectors survive in it, is
   outside Task 10 and is not addressed.

---

## Source ledger

| Item | Status |
| --- | --- |
| real trigonometric and exponential identities | IMPORTED STANDARD RESULT (Mathlib, §1) |
| real linear algebra: spans, dimension, linear independence | IMPORTED STANDARD RESULT (Mathlib, §1) |
| derivative of `sin`, `cos`; `hasDerivAt_pi` | IMPORTED STANDARD RESULT (Mathlib, §1) |
| carrier `W`, product, basis, multiplication table, `ι₃`, `Q4` | inherited, Tasks 07/08 of this project |
| central plane `Z`, `nRe`, `nSc`, branches `N₊`, `N₋` | inherited, Task 09 of this project |
| distinguished axis, `Long`, `Trans`, `Rest = Long ⊕ Trans` | DERIVED IN TASK 10 |
| `rot θ` and its group/invariance properties | DERIVED IN TASK 10 (standard rotation, explicitly given) |
| forced extension values, uniqueness, `Φθ`, group law, `Φ(2π) = id` | DERIVED IN TASK 10 |
| channel classification, branch preservation | DERIVED IN TASK 10 |
| lift existence, half-angle derivation, exact classification, non-uniqueness | DERIVED IN TASK 10 |
| state action, `2π`/`4π`, algebra-vs-state separation | DERIVED IN TASK 10 |
| half-angle sectors, dimensions, weights, §23 verdict | DERIVED IN TASK 10 |
| axial derivations, dimension, intrinsic formula, rate freedom | DERIVED IN TASK 10 |
| conventional comparison statements | COMPARISON ONLY, `Identification.lean` |
