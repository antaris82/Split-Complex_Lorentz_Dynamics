# TASK XXXI AUDIT — Global existence closure and the intrinsic kernel obstruction

Lean version `4.28.0`; Mathlib commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365`.

---

## 0. Scope

Task XXXI continues strictly from the Task-XXX endpoint and closes the last spatial existence
arrow:

> given the inherited ordinary oriented metric rank-three frame transition system and the
> independently reconstructed internal double-cover projection, determine exactly when the
> local internal representatives admit simultaneous continuous global compatibility.

No Task-XXX (or earlier) source file is modified.  All new material lives in
`RequestProject/NullSectorTask31/`.

---

## 1. Module chain

```
NullSectorTask30.Task30                (imported unchanged)
        ↓
LiftabilityPredicate.lean              Package D
        ↓
GlobalMapHardening.lean                Packages A, B
        ↓
UniversalExistenceAudit.lean           Packages E, F
        ↓
IntrinsicDefectState.lean              Packages G, H
        ↓
DefectNeutrality.lean                  Packages I, K, L
        ↓
ExistenceClassification.lean           Packages J (global half), M
        ↓
SpatialClosureInterface.lean           Packages N, Q, R
        ↓
GlobalCoveringHardening.lean           Package C
        ↓
FrameFamilyRealization.lean            Package F (realization of the negative example)
        ↓
Task31.lean                            endpoints + axiom report
```

---

## 2. Exact definitions introduced in Task XXXI

| Name | Meaning |
| --- | --- |
| `InternalLiftable P S` | `Nonempty (CompatibleContinuousInternalTransitions P S)` — the conditional input of Task XXX, read as a property of the ordinary system. |
| `OrdinaryInternalLiftable S` | the same for an inherited Task-XXVII `OrdinaryTransitionSystem`, through `ModelBridge.modelInternalProjection`. |
| `UniversalInternalLiftability` | the universal question: is every inherited ordinary system liftable? |
| `adjShift C ε i j k a b c x` | the inherited admissible change factor `ε_jk · ε_ij · ε_ik⁻¹`. |
| `DefectSystem C` | a continuous kernel-valued family on all triple-overlap defect domains of `C`. |
| `DefectSystem.ofCandidate C`, `DefectSystem.neutral C` | the candidate's own triple defect; the everywhere-identity system. |
| `DefectEquivalent d d'` | `∃ ε, d' = adjShift ε · d` on every defect domain (the Task-XXIX representative-change law). |
| `defectSetoid C`, `DefectClass C` | the proved equivalence relation and its quotient. |
| `defectState C`, `neutralDefectState C` | the class of the candidate's defect; the neutral class. |
| `IsNeutralDefectState C` | `defectState C = neutralDefectState C`. |
| `IsNeutralGlobalKernelDefect P S` | every candidate of `S` has neutral defect state — the intrinsic global datum. |
| `ClosureStatus`, `spatialClosureVerdict` | the three admissible verdicts; the Task-XXXI verdict. |
| `SpatialInternalLiftClosure P S M F` | the frozen spatial closure interface. |
| `FrameModelSection M` | the explicitly stated extra datum of Package C: a continuous section of `k ↦ k • ref`. |
| `chartPi P M i` | the chart model of the global map: `(b, a) ↦ (b, proj a • ref)`. |
| `topSet`, `botSet`, `chartTwoSheeted` | the local two-sheeted product data. |
| `Examples.badSystem`, `Examples.goodSystem` | the explicit negative and positive inherited-class systems. |

Not defined and not used anywhere: characteristic classes, Čech/singular/sheaf cohomology,
spin structures, smoothness, connections, curvature, physical spin.

---

## 3. Theorem inventory (principal endpoints)

### Package A — the frozen Task-XXX object
* `GluedInternalFrameSystem.globalObject_frozen_interface`

### Package B — surjectivity and exact fibres
* `OrdinaryFrameModel.ract_transitive`, `OrdinaryFrameModel.ract_existsUnique`
* `OrdinaryFrameSide.eq_of_chart`, `OrdinaryFrameSide.ract_existsUnique_fibre`,
  `OrdinaryFrameSide.exists_ract`
* `GluedInternalFrameSystem.toFrame_act_ker`
* `GluedInternalFrameSystem.toFrame_surjective`  ← **required endpoint**
* `GluedInternalFrameSystem.toFrame_fibre_nonempty`
* `GluedInternalFrameSystem.toFrame_fibre_torsor`
* `GluedInternalFrameSystem.toFrameFibreEquivKer`, `…toFrame_fibre_card`,
  `…toFrame_fibre_card_two`
* `internalToFrame_surjective`, `internalToFrame_fibre_nonempty_over_every_frame`,
  `internalToFrame_fibre_torsor_over_every_frame`,
  `internalToFrame_fibre_card_two_over_every_frame`

### Package C — local two-sheeted product
* `toFrame_in_chartPi`, `chartPi_preimage_botSet`
* `chartTwoSheeted`, `chartTwoSheeted_fst`, `exists_local_two_sheeted_product`
* `task27FrameModelSection` (the extra datum, satisfied by the inherited model frame space)

### Package D — the liftability predicate
* `internalLiftable_iff_canTrivialiseSimultaneously`, `internalLiftable_iff_canTrivialise`
* `internalLiftable_rep_choice_independent`, `internalLiftable_gauge_independent`,
  `internalLiftable_refinement_independent`, `internalLiftable_is_property_of_ordinary_system`
* `internalLiftable_of_transitions_trivial`

### Packages E, F — the existence audit and the examples
* `UniversalInternalLiftability` (the question, stated)
* `Examples.badSystem`, `Examples.badSystem_not_internalLiftable`
* `Examples.goodSystem`, `Examples.goodSystem_internalLiftable`
* `exists_inherited_ordinary_system_not_internalLiftable` ← **required endpoint**
* `exists_inherited_ordinary_system_internalLiftable` ← **required endpoint**
* `not_universalInternalLiftability`, `internalLiftability_is_genuinely_global`
* realization of the negative example as an inherited *topological frame family*:
  `badFamilyBase`, `badTriv₀`, `badTriv₁`, `badTriv`, `continuousOn_badOverlap`, `badFamily`,
  `badFamily_transition_ft`, `badFamily_not_internalLiftable`,
  `exists_inherited_frame_family_not_internalLiftable`,
  `badFamily_not_isNeutralGlobalKernelDefect`

### Packages G, H — the intrinsic defect state
* `central_shift_inv_mul`, `central_shift_mul`
* `adjShift_one`, `adjShift_comp`, `adjShift_inv_mul`
* `defectEquivalent_refl`, `defectEquivalent_symm`, `defectEquivalent_trans`, `defectSetoid`
* `defectState`, `neutralDefectState`, `isNeutralDefectState_iff_equivalent`
* `isNeutralDefectState_iff_canTrivialise`

### Packages I, K, L — neutrality, invariance, information
* `isNeutralDefectState_rep_choice_independent`, `…gauge_independent`,
  `…refinement_independent`
* `isNeutralGlobalKernelDefect_iff_exists`, `isNeutralGlobalKernelDefect_iff_canonical`
* `goodSystem_isNeutralGlobalKernelDefect`, `badSystem_not_isNeutralGlobalKernelDefect`
* `globalKernelDefect_state_is_nontrivial`

### Packages J, M — the exact classification and the global conclusion
* `internalLiftable_iff_globalKernelDefect_neutral` ← **central success theorem**
* `globalKernelDefect_neutral_iff_canTrivialiseSimultaneously`
* `neutralDefect_constructs_globalTwofoldInternalFrameLift` ← **required endpoint**
* `globalObject_adaptedCharts_imp_neutralDefect`, `spatial_existence_chain`

### Packages N, Q — verdict and interface
* `spatialClosureVerdict`, `spatialClosureVerdict_justified`
* `SpatialInternalLiftClosure`, `spatialInternalLiftClosure`,
  `spatialInternalLiftClosure_status`

---

## 4. Dependency graph

```
Task XXVI/XXVII ordinary oriented metric rank-three frame family
        ↓  (unchanged)
Task XXVIII certified projection  proj : Lift → Gvis,  KerSign,  triple defect δ
        ↓  (unchanged)
Task XXIX  representative-change law, kernel adjustments,
           CanTrivialise ↔ compatible continuous internal transitions
        ↓  (unchanged)
Task XXX   compatible transitions ⟹ GluedInternalFrameSystem
        ↓
Task XXXI  Package B : Π surjective, every fibre a kernel torsor, two points per fibre
           Package C : local V × Ker product in the inherited charts
           Package D : InternalLiftable frozen, choice/gauge/refinement independent
           Packages E,F : universal liftability REFUTED by an explicit inherited system
           Packages G–I : intrinsic global kernel-defect state and its neutrality
           Package J  : InternalLiftable ↔ IsNeutralGlobalKernelDefect
           Package M  : neutral defect ⟹ global twofold surjective equivariant object
           Package N  : Verdict N
```

Extra assumptions that are **not** part of the inherited interface, and are therefore carried
explicitly wherever used:

* `FrameModelSection M` (Package C) — a continuous section of the model orbit map.  It is
  *proved* for the inherited model frame space (`task27FrameModelSection`), but it is not a
  field of `OrdinaryFrameModel`, so it appears as an explicit hypothesis.
* `GluedInternalFrameSystem.AdaptedCharts` (Task XXX, Package U) — needed only for the
  *reverse* implication of Package M and for the chart formula of Package C.

---

## 5. Causal/defect stratum table (the classification produced by Task XXXI)

| state of the ordinary system | intrinsic defect state | compatible internal transitions | global internal object |
| --- | --- | --- | --- |
| `IsNeutralGlobalKernelDefect S` | neutral class | exist (`InternalLiftable S`) | exists, with surjective equivariant `Π`, exact `Ker` fibres |
| `¬ IsNeutralGlobalKernelDefect S` | non-neutral class | do **not** exist | not constructed by this development |
| `Examples.goodSystem` | neutral (proved) | exist (proved) | exists |
| `Examples.badSystem` | non-neutral (proved) | do not exist (proved) | — |

---

## 6. Global-map table (Package B/C results)

| statement | status |
| --- | --- |
| `Π` continuous, over the base, equivariant through `proj` | inherited (Task XXX) |
| `Π` surjective onto all of `FrameTotal` | **PROVED** (Task XXXI) |
| every ordinary frame has a nonempty upstairs fibre | **PROVED** |
| every fibre is a free transitive `Ker`-set | **PROVED** (over every point) |
| fibre cardinality two for the certified kernel | **PROVED** |
| local `V × Ker` product in the inherited charts | **PROVED** (`chartTwoSheeted`) |
| `IsCoveringMap Π` | **NOT PACKAGED** (item 36/37 stopping rule) |

---

## 7. The negative example, in full

Base `B := ↥GvisModel` (the reconstructed visible model group as a topological space);
index type `Bool`; cover `U₀ = U₁ = univ`; transitions

```
g₀₀ = g₁₁ = 1,      g₀₁ (b) = b,      g₁₀ (b) = b⁻¹ .
```

Continuity, the identity law, the inverse law and the triple-overlap law are verified
directly (`Examples.badSystem`), so this is an instance of the frozen Task-XXVII interface
`OrdinaryTransitionSystem`.

If compatible continuous internal transitions existed, `v₀₁` would be a continuous map on the
whole visible group with `proj (v₀₁ b) = b`, i.e. a continuous global internal representative
of the identity map of the visible group.  The certified layers already refuted this
(`NullSectorTask23.no_continuous_global_rep`, specialized in
`NullSectorTask28.Certified.no_whole_domain_internal_rep`).  Hence
`Examples.badSystem_not_internalLiftable`.

What this uses: only the explicit transition data above and one inherited theorem about the
projection itself.  What it does **not** use: any characteristic class, any cohomology theory,
any standard non-spin manifold or bundle, any spin obstruction theorem.

Realization as a frame family.  The example is not only an `OrdinaryTransitionSystem` (the
frozen Task-XXVII output interface, which is exactly the input class of the existence
question): it is additionally realized as an actual inherited topological frame family
(`badFamily`, in `FrameFamilyRealization.lean`), with base `↥GvisModel`, cover `{univ, univ}`
indexed by `Bool`, and the two local trivializations `badTriv₀`, `badTriv₁` whose overlap
comparison is continuous (`continuousOn_badOverlap`).  Its extracted transition data agrees
with the transitions above (`badFamily_transition_ft`), and the family is proved
non-liftable and non-neutral (`badFamily_not_internalLiftable`,
`badFamily_not_isNeutralGlobalKernelDefect`,
`exists_inherited_frame_family_not_internalLiftable`).

---

## 8. Regime comparison: liftability is a genuine global property

| system (same base, same cover) | transitions | liftable | intrinsic state |
| --- | --- | --- | --- |
| `Examples.goodSystem` | all trivial | yes | neutral |
| `Examples.badSystem` | identity / inverse | no | non-neutral |

Consequently neither universal liftability nor universal non-liftability holds, and the
intrinsic invariant is not definitionally trivial (negative controls 115, 116, 119, 120).

---

## 9. Unresolved mathematical obligations

1. `IsCoveringMap Π` is not packaged; only the explicit local product `chartTwoSheeted` and
   the exact fibre theorems are proved.
2. The local product theorem is stated in the inherited chart models
   (`topSet ≃ₜ botSet × Ker`); it is not transported to a homeomorphism
   `Π⁻¹(V) ≃ₜ V × Ker` of subspaces of the glued carrier and of the ordinary frame total
   space.
3. The full quotient class `defectState C` is canonical only *relative to a candidate*:
   classes of different candidates live in different quotient types.  Only **neutrality** is
   proved to be candidate-, gauge- and refinement-independent (Package L, item 88).
4. No comparison theorem with the conventional notion of a spatial `Spin(3)` structure is
   proved; the conventional comparison remains prose only (§11).

---

## 10. Source ledger

**IMPORTED STANDARD RESULT (Mathlib, Lean 4.28.0 / Mathlib `v4.28.0`,
commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365`).**

* group and subgroup API: `Commute`, `Subgroup`, `MonoidHom.ker`, `mul_inv_cancel_left`, …
* topology: `Continuous`, `ContinuousOn.restrict`, `Homeomorph`, `Continuous.subtype_mk`,
  `isOpen_univ`, `IsOpen.preimage`;
* quotients: `Quotient`, `Setoid`, `Quotient.eq`;
* cardinality: `Nat.card`, `Nat.card_congr`.

**INHERITED FROM THE EARLIER TASKS OF THIS PROJECT (unchanged).**

* Task XXIII: `no_continuous_global_rep` (no continuous global section of the certified
  projection);
* Task XXVI/XXVII: the ordinary metric-oriented rank-three frame family, `GvisModel`,
  `FramePlusModel`, `frameIsom`, the ordinary transition system interface;
* Task XXVIII: `InternalProjection`, `TransitionSystem`, `InternalTransitionCandidate`, the
  triple defect, `CanTrivialiseSimultaneously`, `modelInternalProjection`,
  `no_whole_domain_internal_rep`;
* Task XXIX: kernel adjustments, `adjust_defect`,
  `simultaneous_trivialisation_iff_kernel_equations`,
  `canTrivialise_candidate_independent`, `canTrivialise_restrict_iff`,
  `canTrivialiseSimultaneously_iff_exists_compatible_transitions`;
* Task XXX: `GluedInternalFrameSystem`, `compatibleTransitions_construct_globalInternalFrameLift`,
  `internalToFrame_*`, `AdaptedCharts`, `extractedTransitions`.

**DERIVED IN TASK XXXI.**  Everything listed in §3.

---

## 11. Late conventional comparison (Packages O, P — prose only)

After the intrinsic results above were frozen, the following purely descriptive comparison may
be recorded.  It is *not* used in any proof.

* The reconstructed `Lift` was identified in earlier layers with the standard unit-quaternion
  model, `GvisModel` with the rotation group, and the certified kernel with a two-element
  central subgroup.
* The reconstructed data — a kernel-valued triple defect, its quadruple consistency law, the
  representative-change law, the resulting equivalence class and the neutrality criterion —
  has the shape of a degree-two obstruction to lifting a structure group along a central
  two-element extension.
* Accordingly: *the internally reconstructed invariant is a candidate for later comparison
  with the standard obstruction invariant.*  No formal identity with any named characteristic
  class is asserted or proved, and no standard obstruction theorem was used anywhere in the
  reconstruction.

---

## 12. Required decision table

| Question | Verdict |
| --- | --- |
| `Π` surjective onto all `FrameTotal`? | PROVED |
| Every ordinary-frame point has upstairs fibre? | PROVED |
| Every fibre exactly a kernel torsor? | PROVED |
| Certified fibre cardinality exactly 2? | PROVED |
| Local two-sheeted product? | PROVED (in the inherited chart models) |
| `IsCoveringMap Π`? | NOT PACKAGED |
| Liftability depends only on ordinary system? | PROVED |
| Initial representative choice affects liftability? | NO, PROVED |
| Refinement affects liftability? | NO, PROVED |
| Universal liftability follows from current assumptions? | NO |
| Explicit positive example? | PROVED |
| Explicit negative example? | PROVED |
| Intrinsic defect state reconstructed? | PROVED (quotient form) |
| Defect state representative-independent? | PARTIAL — neutrality PROVED; full class canonical only per candidate |
| Defect state refinement-independent? | PARTIAL — neutrality PROVED; full class not transported across refinements |
| Neutrality exactly characterizes liftability? | PROVED |
| Non-neutral inherited example exists? | PROVED |
| Global object exists whenever defect is neutral? | PROVED |
| Global map then surjective and twofold? | PROVED |
| Universal existence closure? | REFUTED (with exact classification) |
| Conventional spatial Spin(3) identification? | DEFERRED |
| Lorentzian spin structure obtained? | NO |
| Experiment 1 and 2 joined? | NO |
| Physical spin derived? | NO |

**Verdict (Package N): N — universal existence refuted**, strengthened by the exact
classification of Verdict C: liftability holds exactly when the intrinsic global kernel-defect
state is neutral.

---

## 13. Boundary before the Experiment-1 / Experiment-2 marriage (Package R)

Known now about the spatial branch: the ordinary oriented metric rank-three frame transition
system, the certified `Lift → GvisModel` projection with its two-element central kernel, the
intrinsic global kernel-defect state, the neutrality/liftability equivalence, the conditional
global internal total space with its surjective equivariant twofold map, and the local
two-sheeted product in charts.

Explicitly absent, and nowhere asserted: any 3+1 Lorentzian spin structure; any soldering to
spacetime tangent fibres; any reconstruction of the full Lorentz metric from the spatial lift;
any relativity axioms; any connection, curvature or dynamics.

Frozen open interface question, deliberately **not** answered here: whether the
metric-oriented spatial carrier used in this branch is canonically identifiable with the
spatial sector obtained independently from the longitudinal split-complex structure.

---

## 14. Build and axiom report

### 14.1 Toolchain

| item | value |
| --- | --- |
| Lean | `4.28.0` (project `lean-toolchain`) |
| Mathlib | commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (as pinned in `lake-manifest.json`) |
| new modules | the ten files of `RequestProject/NullSectorTask31/` listed in §1 |
| imports used by the new modules | `RequestProject.NullSectorTask30.Task30` and the earlier certified layers it re-exports, plus the Mathlib modules already pulled in by those layers (group/subgroup, topology, quotient, `Nat.card`). No new external import was added. |

### 14.2 Builds

| command | result |
| --- | --- |
| `lake build RequestProject.NullSectorTask31.Task31` (focused Task-XXXI build) | success, exit code 0 |
| `lake build` (whole project) | `Build completed successfully (8350 jobs).`, exit code 0 |

Errors: none.  Warnings: no warning is emitted by any Task-XXXI module; the inherited
warnings of the earlier layers are unchanged in number and content by this task.

Source scan of `RequestProject/NullSectorTask31/`: no `sorry`, no `admit`, no `axiom`
declaration, no `native_decide`, no `bv_decide`, no `implemented_by`, no `unsafe`, no
`partial`.

### 14.3 Axiom report

`Task31.lean` runs `#print axioms` on every principal endpoint of the layer (69 reports).
Every one of them prints exactly

```
depends on axioms: [propext, Classical.choice, Quot.sound]
```

i.e. only the standard Lean/Mathlib axioms.  No custom axiom occurs anywhere in the
Task-XXXI dependency cone.

### 14.4 Failed builds preserved

The following build failures occurred while developing this layer and were repaired without
any change of mathematical content.

| # | command | error | diagnosis | repair | mathematics changed? |
| --- | --- | --- | --- | --- | --- |
| 1 | `lake build RequestProject.NullSectorTask31.LiftabilityPredicate` | `ambiguous, possible interpretations … OrdinaryTransitionSystem` | the name exists in two opened namespaces | qualified as `NullSectorTask28.OrdinaryTransitionSystem` | no |
| 2 | `lake build RequestProject.NullSectorTask31.GlobalMapHardening` | `motive is not type correct` / rewrite failure in `ract_transitive` | `mul_smul` was rewritten in the wrong direction | `rw [← mul_smul, mul_inv_cancel_left]` | no |
| 3 | `lake build RequestProject.NullSectorTask31.IntrinsicDefectState` | `invalid field notation … Quotient.eq (s := …)` | that spelling of the instance argument is not available in this Mathlib revision | used `Quotient.eq_iff_equiv` | no |
| 4 | `lake build RequestProject.NullSectorTask31.IntrinsicDefectState` | unused-binder warning in the `DefectSystem` structure field | the field binder had been written in curried form with named overlap arguments | field restated as `d : ∀ i j k : ι, C.Idx i j → C.Idx j k → C.Idx i k → (↥(S.tripleDom i j k) → L)` | no |
| 5 | `lake build RequestProject.NullSectorTask31.GlobalCoveringHardening` | elaboration failure on `ovMap` / `ovMap_apply` (metavariables) | the inherited overlap map does not determine its implicit family arguments here | supplied them explicitly (`(C := fun _ : ↥GvisModel => Model) (M := Model) (U := …) (chart := …) (i := i) (j := j)`) | no |

No intended theorem of this task turned out to be false.  The one expected-positive statement
that was *refuted* is the universal one, and it is preserved formally rather than deleted:
`UniversalInternalLiftability` is stated, and `not_universalInternalLiftability` proves its
negation (§7).
