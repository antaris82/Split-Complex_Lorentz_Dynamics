# TASK 15 AUDIT

**Null-Sector Foundation — Task 15**
Continuous central coherence after spatial closure: regular multi-axis lifts, infinitesimal
residual rates, and the remaining underdetermination.

All statements below are machine-checked. Every theorem name is the exact Lean name in
namespace `NullSectorTask15`, in the file indicated.

---

## 1. Exact toolchain

| Item | Value |
| --- | --- |
| Lean toolchain | `leanprover/lean4:v4.28.0` (`lean-toolchain`) |
| Build tool | `lake` (bundled with the toolchain) |
| Build target | `RequestProject` library (`lakefile.toml`, glob `RequestProject.+`) |
| Task-15 top module | `RequestProject.NullSectorTask15.Task15` |

No toolchain change was made for Task 15.

## 2. Exact Mathlib revision

| Item | Value |
| --- | --- |
| Dependency | `mathlib`, `rev = "v4.28.0"` (`lakefile.toml`) |
| Resolved commit | `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (`lake-manifest.json`) |

Mathlib declarations used in Task 15 are ordinary infrastructure only: `HasDerivAt` and its
combinators (`HasDerivAt.mul`, `.neg`, `.add`, `.smul_const`, `.exp`, `.sin`, `.cos`,
`.congr_deriv`), `Differentiable`, `Continuous` / `continuous_apply` / `fun_prop`,
`LinearMap` and `LinearMap.comp`, real analysis facts
(`Real.exp_pos`, `Real.exp_zero`, `Real.exp_eq_exp`, `Real.sin_sq_add_cos_sq`,
`Real.sin_eq_zero_iff`, `Real.cos_int_mul_two_pi`, `Real.pi_pos`), `Int.even_or_odd`,
and the tactics `ring`, `linarith`, `nlinarith`, `linear_combination`, `module`,
`field_simp`, `norm_num`, `simp`, `fin_cases`, `funext`, `push_cast`.

## 3. Inherited ledger (INHERITED, Tasks 08–14 and Task 11)

| Source | Object / theorem | Used for |
| --- | --- | --- |
| Task 08 | carrier `W`, product `⋆`, unit `w1`, basis `1,A,B,C,P,Q,R,S`, associativity | ambient algebra |
| Task 09 | exact centre `Z = spanℝ{w1,wS}`, `mem_Z_iff`, `Z_central`, `Z_mul_mem`, `wS_sq` | every central statement |
| Task 11 | `center_eq_Z`, `IsCentralHom`, `centralHom_iff_coeffs`, `zc`, `zc_mul_zc`, `zc_injective`, `zexp`, `zexp_isCentralHom`, `zexp_injective`, `coeff_continuous_classification` | §III classification |
| Task 12/13 | minimal carriers, `zz`, sector data | notation only (`zz = zc`) |
| Task 14 | `IsUnitAxis`, `Jmap`, `Jmap_linear`, `Jmap_eq_central_mul`, `spat`, `Un`, `Un_group`, `Un_zero`, `Un_neg`, `Un_mul_neg`, `Un_neg_mul`, `Un_implements`, `PhiGen`, `Implements`, `Implements.mul`, `implements_defect_mem_Z`, `axis_lift_iff`, `IsImplementable`, `isImplementable_comp`, `central_inv_mem_Z`, `zinv`, `AxisWord`, `wordVal`, `wordInv`, `wordAut`, `reference_word_defect`, `closedPath`, `closedPath_val`, `closed_path_internal_residual`, `full_turn_val`, `full_turn_aut`, `axA`, `axB` | everything |

Inheritance is via `RequestProject.NullSectorTask15.SafeBase`, which imports
`RequestProject.NullSectorTask14.SelectionAudit` (the top of the Task-14 *reconstruction*
chain) and, as a named dependency, `RequestProject.NullSectorTask11.ContinuousClassification`.

Nothing of Tasks 11–14 is re-proved here.

## 4. Firewall report (§II)

A mechanical scan of every Task-15 module for
`electron, fermion, photon, spinor, spin, mass, energy, momentum, frequency, Hamiltonian,
field equation, electromagnetic, gravitational, gauge, connection, projective, cocycle,
cohomology, SU(2), SO(3), Pauli, hole-tape, quantum` returns hits **only** inside the two
firewall docstrings themselves (`SafeBase.lean` §Firewalls and the header of
`MixedComposition.lean`, which states that no cohomological vocabulary is used). There is
no such notion in any definition, theorem, proof or identifier.

The central composition discrepancy of §IV is kept as an explicit carrier element: no
quotient by the centre is taken anywhere, and no equivalence of implementers is introduced.

*Late-comparison firewall.* `OptionCAudit.lean` (§VIII) is imported by nothing but
`Task15.lean`; no result of Layers 0–6 depends on it. The comparison it performs is purely
structural (counts of free parameters and relations) and asserts no dictionary between the
rates and any earlier informal quantity.

## 5. Source-order graph

```
Task14.SelectionAudit, Task11.ContinuousClassification   (inherited)
        ↓
Task15.SafeBase                     -- notation bridge, central units, cancellation
        ↓
Task15.RegularLift                  -- §III continuity layer
        ↓
Task15.DifferentiableLift           -- §III stronger regularity layer
        ↓
Task15.MixedComposition             -- §IV finite central composition law
        ↓
Task15.Infinitesimal                -- §V infinitesimal residual classification
        ↓
Task15.RateSeparation               -- §VI static rate versus central rate
        ↓
Task15.ResidualAudit                -- §VII what remains free, §IX verdict
        ↓
Task15.OptionCAudit                 -- §VIII COMPARISON ONLY
        ↓
Task15.Task15                       -- principal theorem set, axiom report
```

## 6. Exact definitions

| Name | File | Statement |
| --- | --- | --- |
| `IsAxisLift n U` | `RegularLift` | `U 0 = 1`, `U (θ+φ) = U θ ⋆ U φ`, `(U θ ⋆ x) ⋆ U (-θ) = PhiGen n θ x` |
| `IsContinuousAxisLift n U` | `RegularLift` | `IsAxisLift n U` and `Continuous U` |
| `residual n U θ` | `RegularLift` | `U θ ⋆ Un n (-θ)` |
| `IsCentralUnit z` | `SafeBase` | `z ∈ Z` with a two-sided central inverse |
| `cdisc u ui g h` | `MixedComposition` | `(u g ⋆ u h) ⋆ ui (g ∘ h)` |
| `liftWordVal`, `liftWordInv`, `zWord`, `zWordInv` | `MixedComposition` | word values of a per-axis lift and of its residual |
| `IsRegularFamily U` | `Infinitesimal` | `IsContinuousAxisLift n (U n)` for every unit axis `n` |
| `rateAlpha U n`, `rateBeta U n` | `Infinitesimal` | the two real parameters of `U n` (via `paramPair`) |
| `centralResidual U n` | `Infinitesimal` | `zc (rateAlpha U n) (rateBeta U n) = α n • 1 + β n • S` |
| `famOf a b n θ` | `Infinitesimal` | `zexp (a n) (b n) θ ⋆ Un n θ` |
| `IsTransformationValued U` | `Infinitesimal` | equal automorphisms receive equal implementers |
| `rateFam lam a b n θ` | `RateSeparation` | `zexp (a n) (b n) θ ⋆ Un n (lam · θ)` |

Inherited notation: `zc a b = zz a b = a • w1 + b • wS`, `zexp α β θ =
zc (exp(αθ) cos(βθ)) (exp(αθ) sin(βθ))`, `Un n θ = cos(θ/2) • 1 − sin(θ/2) • J n`.

## 7. Theorem inventory

### §III — regular one-axis lifts

| Theorem | Content |
| --- | --- |
| `axisLift_iff` | `IsAxisLift n U ↔ ∃ z, IsCentralHom z ∧ ∀ θ, U θ = z θ ⋆ Un n θ` |
| `axisLift_residual_unique` | the residual `z` is unique |
| `zc_mul_Un` (+ eight coordinate lemmas) | exact expansion of `zc a b ⋆ Un n θ` |
| `residual_coeffs_of_coords` | explicit recovery of `a, b` from the coordinates of the lift |
| `continuousAxisLift_classification` | **first principal theorem**: continuous ⇔ `U θ = zexp α β θ ⋆ Un n θ` |
| `continuousAxisLift_parameters_unique` | exactly two real parameters |
| `differentiable_zexp_mul_Un`, `continuousAxisLift_differentiable` | every continuous axis lift is differentiable |
| `differentiableAxisLift_classification` | the differentiable class equals the continuous class |

**No more general regular class survives**: continuity already forces the
exponential–rotation shape, and differentiability adds nothing.

### §IV — finite central composition law

| Theorem | Content |
| --- | --- |
| `central_discrepancy_mem_Z` | `c(g,h) ∈ Z` |
| `composition_law` | `u g ⋆ u h = c(g,h) ⋆ u (g∘h)` |
| `central_discrepancy_unit` | `c(g,h)` is an invertible central element |
| `central_discrepancy_assoc` | `c(g,h) c(g∘h,k) = c(h,k) c(g,h∘k)` — the only identity forced by associativity |
| `central_discrepancy_units` | `c(id,g) = c(g,id) = 1` when `u id = 1` |
| `central_discrepancy_redefinition` | `c ↦ (lam g · lam h · lam(g∘h)⁻¹) · c` |
| `regular_word_factor`, `regular_wordInv_factor` | word value = accumulated residual × inherited reference word |
| `regular_word_defect_split` | residual part and inherited `±1` part are completely separated |
| `mixed_regular_product`, `mixed_regular_central_defect` | explicit mixed two-axis defect `z n θ · z m φ · (z k ψ)⁻¹` |

Which part of `c` is fixed by the Task-14 `±1` reference defect and which comes from `z` is
exactly the content of `regular_word_defect_split`.

### §V — infinitesimal residual

| Theorem | Content |
| --- | --- |
| `hasDerivAt_regularLift_zero` | generator `= zc α β − (1/2) • J n` |
| `regularFamily_param_spec`, `regularFamily_param_unique` | the rate functions and their uniqueness |
| `regularFamily_generator` | isolation of `C(n) = α(n) 1 + β(n) S`, unique coefficients |
| `regular_family_arbitrary_parameters` | **every** pair of real functions of the direction is realized |
| `central_rates_independent_across_axes` | two directions may carry unrelated rate pairs |
| `transformationValued_full_turn`, `..._coeffs`, `..._sin_cos` | the two forced real equations |
| `autValued_forces_alpha_zero` | transformation-valued ⇒ `α ≡ 0` |
| `autValued_forces_beta_half_odd` | transformation-valued ⇒ `β n ∈ ℤ + 1/2` |
| `autValued_antipodal_odd` | transformation-valued ⇒ `α(-n) = -α(n)`, `β(-n) = -β(n)` |
| `central_rate_classification` | the packaged answer to A–F |

**Answers to §V, A–F.**

| Alternative | Verdict | Theorem |
| --- | --- | --- |
| A — one unique normalization | **refuted** for parameter-indexed lifts | `regular_family_arbitrary_parameters` |
| B — two global constants | **refuted** (rates need not be constant) | `central_rates_not_constant` |
| C — one or both may vary with `n` | **PROVED** (both vary freely) | `regular_family_arbitrary_parameters`, `central_rates_independent_across_axes` |
| D — only particular combinations constrained | **PROVED for the stronger transformation-valued notion**: `α ≡ 0`, `β ∈ ℤ+1/2`, `β` odd | `autValued_forces_alpha_zero`, `autValued_forces_beta_half_odd`, `autValued_antipodal_odd` |
| E — a path-dependent central law is required | **not required for the rates**; the inherited `±1` path defect nevertheless persists | `regular_family_exact_parametrization`, `regular_closed_path_residual` |
| F — no differentiable global regular lift exists | **refuted** | `global_regular_lift_exists` |

### §VI — static rate versus central rate

| Theorem | Content |
| --- | --- |
| `rateFam_zero`, `rateFam_group`, `rateFam_conj` | rate-`lam` families are lifts of the reparametrized family |
| `rateFam_generator` | generator `= zc (a n) (b n) − (lam/2) • J n` |
| `generator_components_independent` | `lam`, `α`, `β` are recovered separately and injectively |
| `common_spatial_rate_leaves_central_free` | one common spatial rate for all directions still admits arbitrary central rates |
| `central_rates_leave_spatial_rate_free` | fixed central rates leave the spatial rate free |

**Conclusion.** The Task-14 result that spatial linear coherence forces one common spatial
rate has **no** logical consequence for the central rates: the spatial rate lives in the
derived generator direction `J n` and the central rates in the exact centre, and the
generator determines the three numbers independently.

### §VII, §IX — what remains free

| Row | Status | Theorem |
| --- | --- | --- |
| free constants only | too small | `central_rates_not_constant` |
| free functions of direction | **exactly this** | `regular_family_exact_parametrization`, `task15_missing_datum_class` |
| free functions of a path parameter | excluded | `no_free_path_function` |
| path/history-dependent central data | inherited `±1` still present | `regular_closed_path_residual` |
| obstruction to any global regular choice | none | `global_regular_lift_exists` |

### §VIII — late structural comparison (COMPARISON ONLY)

`optionC_structural_comparison`:

* two independent real residual rates survive (per direction), and each may be prescribed
  arbitrarily;
* multi-axis coherence supplies **no** additional independent relation;
* neither rate becomes dependent on the other;
* hence the dependency shape is *two quantities and zero relations*, i.e. strictly weaker
  determination than the earlier "two quantities and one relation" shape — the apparent
  similarity to that earlier situation **fails**, in the direction of *more*, not less,
  underdetermination;
* the only relations available come from the strictly stronger transformation-valued
  requirement, which closes the first rate (`α = 0`) and leaves the second in a discrete
  set — again a different dependency shape.

No identification of either rate with any earlier informal quantity is made anywhere.

## 8. §IX — required final status

**VERDICT 3 — DIRECTION-DEPENDENT CENTRAL STATE DATA SURVIVE.**

Formal content (`task15_final_verdict`):

1. a global regular multi-axis lift exists (verdict 5 refuted);
2. every regular multi-axis lift equals `zexp (α n) (β n) θ ⋆ Un n θ` for its own rate
   functions (nothing beyond two real numbers per direction survives);
3. every pair of rate functions occurs (verdict 1 refuted);
4. the rates need not be constant (verdict 2 refuted).

Separately reported:

* **Does Task-1 Option-C-type underdetermination survive?** Yes, and in enlarged form: two
  independent real rates survive, with no compatibility relation at all between them.
* **Does 3+1 continuous coherence remove it?** No. Continuity and differentiability fix the
  *shape* of the residual (exponential–rotation) but not its two parameters; mixed-axis
  composition produces only a central discrepancy and imposes no relation.
* **Exact class of the still missing datum:** one section of the trivial `ℝ²`-bundle over
  the set of unit spatial directions — i.e. a choice of a pair of real numbers for each
  direction (`task15_missing_datum_class`). Requiring in addition that the lift be a
  function of the transformation reduces this datum to a single function
  `n ↦ β n ∈ ℤ + 1/2`, odd under `n ↦ -n`, with `α ≡ 0`.

## 9. Unresolved mathematical obligations

1. **Existence in the transformation-valued case.** §V proves the *necessity* of
   `α ≡ 0`, `β n ∈ ℤ + 1/2` and antipodal oddness for a transformation-valued regular
   family. Whether such a family exists is **not** proved: sufficiency would require the
   exact classification of all coincidences `PhiGen n θ = PhiGen m φ`, which is not
   established here and is not needed for any statement made.
2. **Continuity in the direction.** Regularity is imposed only in the parameter `θ`. No
   continuity of `n ↦ α n, β n` is assumed or derived; the freedom classified in §V and
   §VII is therefore freedom of arbitrary (possibly discontinuous) functions of direction.
3. **Words and relations.** Following the task's own restriction, no presentation of the
   spatial word problem is attempted; only the composition law needed for the infinitesimal
   analysis is derived.
4. **Intermediate regularity classes.** Only "continuous" and "differentiable" are
   compared; measurable, bounded or analytic classes are not analysed. (The algebraic —
   fully discontinuous — class is strictly larger, as already recorded in Task 11.)

## 10. Source ledger

* **IMPORTED STANDARD RESULT** — the Mathlib declarations listed in §2, used only as
  ordinary real-analysis and linear-algebra infrastructure.
* **INHERITED** — the Task-08…Task-14 and Task-11 items listed in §3, used without
  re-proof.
* **DERIVED IN TASK 15** — every declaration in `RequestProject/NullSectorTask15/`: the
  regular-lift definitions, the unique factorization, the continuous and differentiable
  classifications, the finite central composition law with its associativity, unit and
  redefinition identities, the regular word split, the exact generator, the rate functions,
  the freedom and independence theorems, the rate separation, the residual audit and the
  final verdict.

## 11. Build report

```
lake build RequestProject.NullSectorTask15.Task15     -- success (8137 jobs)
lake build                                            -- success (whole project)
```

Mechanical scans over `RequestProject/NullSectorTask15/` find no `sorry`, no `admit`, no
`axiom` declaration and no `@[implemented_by]`.

## 12. Axiom report

All 37 principal theorems exposed by `RequestProject/NullSectorTask15/Task15.lean` report
exactly

```
[propext, Classical.choice, Quot.sound]
```

(`Classical.choice` enters through the selection of the parameter pair in `paramPair` and
through ordinary Mathlib infrastructure.)
