# TASK XXX AUDIT — Conditional global gluing of the internal transition system

Quotient construction, topological local triviality, free internal-group action, and
equivariant projection to the ordinary frame total space.

**Everything in this layer is conditional.**  The input
`CompatibleContinuousInternalTransitions` is *assumed*.  Task XXX does **not** prove that it
exists for the concrete ordinary family, does **not** prove `CanTrivialiseSimultaneously`,
and does **not** solve the kernel defect equations.

---

## 0. Build environment

| Item | Value |
| --- | --- |
| Lean version | `leanprover/lean4:v4.28.0` |
| Mathlib revision | tag `v4.28.0`, commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365` |
| Focused build | `lake build RequestProject.NullSectorTask30.Task30` — green |
| Whole-project build | `lake build` — green, **8340 jobs**, 0 errors |
| Warnings | 114 total, **all pre-existing in earlier layers**; **0** in any Task-XXX module |
| Prohibited constructs | none: no `sorry`, `admit`, custom `axiom`, `implemented_by`, `native_decide`, `bv_decide`, `unsafe`, `partial` |

---

## 1. Module chain

Strictly linear, ten new modules under `RequestProject/NullSectorTask30/`:

```
GlobalGlueBase              Package A, Package K interfaces
  → InternalGlueRelation    Packages B, C          (hard target A)
  → InternalQuotient        Packages D, E          (hard target A)
  → InternalTopology        Packages F, G          (hard target B)
  → InternalGroupAction     Packages H, I, J       (hard target C)
  → GlobalFrameProjection   Packages L, M, N       (hard target C)
  → KernelFibres            Packages O, P
  → LocalComparison         Package Q
  → ConditionalGlobalInterface  Packages S, T, U, V
  → PresentationIndependence    Package R
  → OrdinaryFrameSideInstance   Package K, instantiated from Task XXVII
  → Task30                  principal endpoints + `#print axioms`
```

No earlier source file was edited.  `git diff` against the Task-XXIX endpoint shows only new
files plus this audit and a new README section.

---

## 2. Frozen conditional input (Package A)

Fixed throughout:

| Object | Origin |
| --- | --- |
| base `B` (topological), index type `ι` | Task XXVII / XXVIII |
| ordinary cover `S.U i`, transitions `S.g i j` | `NullSectorTask28.TransitionSystem`, the Task-XXVII endpoint |
| internal topological group `L` = `Lift` | inherited |
| visible group `G` = `GvisModel` in the concrete instance | inherited |
| `P : InternalProjection L G`, `proj`, kernel `P.Ker` (= `KerSign`) | Task XXVIII, frozen |
| ordinary frame total space, its charts, its right action | Task XXVII, frozen as `OrdinaryFrameSide` |
| **conditional input** `T : CompatibleContinuousInternalTransitions P S` | Task XXIX, **assumed** |

Re-exposed inherited laws (pointwise form, `GlobalGlueBase.lean`):

```
uu_proj  : proj (u_ij b) = g_ij b
uu_self  : u_ii b = 1
uu_symm  : u_ji b = (u_ij b)⁻¹
uu_trans : u_jk b * u_ij b = u_ik b
```

No new mathematics appears in Package A.

---

## 3. The transition convention, derived (Packages B, C)

The ordinary frame side transforms chart coordinates by `coord_j = g_ij • coord_i`
(Task XXVII, `frameTrivAt (triv j) = transition i j • frameTrivAt (triv i)`), and the
Task-XXIX multiplication convention is `u_jk * u_ij = u_ik`, `proj u_ij = g_ij`.  Both force
the internal coordinate to transform by **left** multiplication:

```
(i, b, a)  ~  (j, b, u_ij(b) * a)
```

This is the *first* candidate of item 28; it was not guessed.  With it:

| relation law | inherited law used | Lean name |
| --- | --- | --- |
| reflexive | `u_ii = 1` | `glueRel_refl` |
| symmetric | `u_ji = u_ij⁻¹` | `glueRel_symm` |
| transitive | `u_jk * u_ij = u_ik` (orientation `i → j → k`) | `glueRel_trans` |

Endpoint: `internalGlueRel_equivalence`.

**Consequence for the action side (item 73).**  Because the transitions act on the left, only
a **right** multiplication `a ↦ a·h` commutes with the gluing and descends.  The global
internal-group action is therefore a *right* action; the inherited one-fibre *left* coordinate
convention is untouched inside each chart.  This conversion is stated explicitly in
`InternalGroupAction.lean`.

---

## 4. Exact definitions

| Name | Statement |
| --- | --- |
| `InternalPre S L` | `Σ i : ι, ↥(S.U i) × L`, with the disjoint-union topology |
| `preIdx`, `prePt`, `preElt` | chart index, base point, internal coordinate |
| `InternalGlueRel T x y` | `∃ hb : prePt y = prePt x, preElt y = u_{idx x, idx y}(prePt x) * preElt x` |
| `InternalGlueSetoid T` | the associated setoid |
| `InternalTotal T` | `Quotient (InternalGlueSetoid T)` (quotient topology) |
| `iq T` | the quotient map |
| `ipsi T i p` | `iq T ⟨i, p⟩`, the local parametrization |
| `internalBase T` | `Quotient.lift prePt …` |
| `icoord T i` | the coordinate in chart `i`, transported by `u_ji` |
| `internalLocalEquiv T i` | the set-level chart `internalBase⁻¹(U i) ≃ U i × L` |
| `internalTop T` | the topology (quotient topology, = atlas topology) |
| `internalChart T i` | the chart as a **homeomorphism** |
| `chgDom`, `chgMap T i j` | overlap domain and change of coordinates `(b,a) ↦ (b, u_ij(b)·a)` |
| `smulPre`, `ismul T` | the pre-quotient and descended **right** `L`-actions |
| `InternalFiber T b` | `{x | internalBase T x = b}` |
| `fiberEquiv T i b hb` | fibre ≃ `L`, chart dependent |
| `toFramePre`, `internalToFrame T F` | the global map to the ordinary frame total space |
| `OrdinaryFrameModel G Fm` | frozen model-frame interface (left action, its freeness/transitivity, right action, reference frame) |
| `OrdinaryFrameSide S M Tot` | frozen ordinary frame total-space interface (base, charts, transition law, right action) |
| `GluedInternalFrameSystem` | the conditional global interface (Package S) |
| `InternalTransitionGauge T T'` | chart-indexed kernel-valued gauge relating two presentations |
| `AdaptedCharts` | the extra chart datum needed for the converse extraction |

---

## 5. Theorem inventory (principal endpoints)

Package C — gluing relation
1. `glueRel_refl`, 2. `glueRel_symm`, 3. `glueRel_trans`, 4. `internalGlueRel_equivalence`,
5. `glueRel_same_chart` (negative control: the relation does not collapse a local product).

Package D — quotient carrier
6. `InternalTotal`, 7. `iq_eq_iff`, 8. `internalBase`, 9. `internalBase_ipsi`,
10. `internalBase_surjective`, 11. `ipsi_injective`, 12. `ipsi_trans`.

Package E — set-level charts
13. `icoordPre_glueRel` (independence of representative), 14. `icoord_ipsi`,
15. `ipsi_icoord`, 16. `internalLocalEquiv`, 17. `exists_ipsi_rep`.

Package F — topology
18. `isQuotientMap_iq`, 19. `isOpen_internalTotal_iff` (**Route Q = Route A**),
20. `internalTotal_topology_eq_iSup`, 21. `continuous_internalTotal_iff`,
22. `isOpenMap_ipsi`, 23. `isOpenMap_iq`, 24. `continuous_internalBase`,
25. `isOpen_internalDom`, 26. `internalChartHomeo` / `internalChart` (**charts are
homeomorphisms**), 27. `internalTotal_topology_unique`.

Package G — chart changes
28. `internal_chart_change_continuous`, 29. `chgMap_chgMap` (inverse is the reversed
transition), 30. `chgMap_comp` (triple-overlap law), 31. `ipsi_chgMap`.

Package H — fibres
32. `InternalFiber`, 33. `internalFiber_nonempty`, 34. `icoord_chart_change`,
35. `fiberEquiv`, 36. `fiberEquiv_chart_change` (**not canonical**), 37. `fiberEquiv_ismul`.

Package I — global action
38. `glueRel_smulPre`, 39. `ismul`, 40. `ismul_one`, 41. `ismul_mul`,
42. `internalBase_ismul`, 43. `icoord_ismul`, 44. `continuous_ismul`.

Package J — freeness, transitivity
45. `internal_fibre_existsUnique_groupTransport`, 46. `ismul_free`, 47. `ismul_injective`,
48. `ismul_transitive_on_fiber`, 49. `ismul_stabilizer_trivial`.

Packages L, M, N — the global projection
50. `toFramePre_glueRel` (uses **exactly** `proj u_ij = g_ij`), 51. `internalToFrame`,
52. `internalToFrame_over_base`, 53. `continuous_internalToFrame` (chartwise),
54. `internalToFrame_equivariant`, 55. `internalToFrame_ract_range`.

Packages O, P — kernel fibres
56. `internalToFrame_ismul_ker`, 57. `internalToFrame_fibre_kerSign_torsor`,
58. `internalToFrame_eq_iff_ker`, 59. `internalToFrame_fibre_equiv_ker`,
60. `internalToFrame_fibre_card_two`.

Package Q — one-fibre comparison
61. `internalToFrame_in_chart`, 62. `fibre_comparison`,
63. `fibre_chart_independence_internal`, 64. `fibre_chart_independence_ordinary`,
65. `chart_change_intertwined`, 66. `fibre_kernel_comparison`.

Package R — presentation independence
67. `InternalTransitionGauge`, 68. `gaugeHomeo`, 69. `gaugeHomeo_over_base`,
70. `gaugeHomeo_equivariant`, 71. `gaugeHomeo_over_frame`.

Packages S, T, U, V — interface, construction, converse, conditionality
72. `GluedInternalFrameSystem`, 73. `compatibleTransitions_construct_globalInternalFrameLift`,
74. `exists_gluedInternalFrameSystem_of_compatibleTransitions`,
75. `GluedInternalFrameSystem.extractedTransition` and its four laws,
76. `GluedInternalFrameSystem.proj_extractedTransition` (needs `AdaptedCharts`),
77. `GluedInternalFrameSystem.extractedTransitions`, 78. `task30_conditionality`,
79. `task30_input_is_task29_boundary`.

Package K — inherited frame side, instantiated
80. `frameIsom_modelFrame_eq_refl`, 81. `frameRAct_modelFrame`, 82. `task27FrameModel`,
83. `task27TransitionSystem`, 84. `task27FrameSide`,
85. `task27_family_conditional_global_construction`.

---

## 6. Dependency DAG (Package W)

```
ordinary topological frame family (Task XXVII)
            +
compatible internal transition system   [ADDITIONAL CONDITIONAL INPUT — assumed]
            ↓
   local products  U i × Lift                      (InternalPre)
            ↓
   gluing relation                                 (InternalGlueRel)
            ↓            [needs u_ii = 1, u_ji = u_ij⁻¹, u_jk·u_ij = u_ik]
   global quotient carrier                         (InternalTotal, internalBase)
            ↓            [needs continuity of u_ij  ⇒  chart changes continuous]
   quotient topology = atlas-generated topology    (isOpen_internalTotal_iff)
            ↓
   continuous local trivializations                (internalChart)
            ↓            [needs the LEFT gluing convention ⇒ RIGHT global action]
   global free fibrewise Lift action               (ismul, existsUnique transport)
            +
   proj : Lift → Gvis
            ↓            [needs proj(u_ij) = g_ij and the inherited chart law
                          coord_j = g_ij • coord_i]
   continuous equivariant map to FrameTotal        (internalToFrame)
            ↓            [needs freeness of the visible action on model frames]
   exact KerSign fibres                            (internalToFrame_fibre_kerSign_torsor)
```

**Missing incoming arrow, marked OPEN:**

```
ordinary frame transition system  ⟹?  compatible internal transition system
```

is **OPEN / not proved in Task XXX** and is not drawn as a theorem anywhere in this layer.

---

## 7. Chart / transition tables

### Internal side

| object | chart `i` | chart `j` | change |
| --- | --- | --- | --- |
| point of the total space | `(b, a_i)` | `(b, a_j)` | `a_j = u_ij(b) · a_i` |
| global action | `a_i ↦ a_i · h` | `a_j ↦ a_j · h` | commutes with the change |
| fibre identification | `fiberEquiv i` | `fiberEquiv j` | left translation by `u_ij(b)` |

### Ordinary side (inherited, unchanged)

| object | chart `i` | chart `j` | change |
| --- | --- | --- | --- |
| point of `FrameTotal` | `(b, f_i)` | `(b, f_j)` | `f_j = g_ij(b) • f_i` |
| visible right action | `f_i ↦ ract f_i k` | `f_j ↦ ract f_j k` | commutes with the change |

### The two are intertwined

`internalToFrame` in chart `i` is `(b, a) ↦ (b, proj(a) • ref)`, and

`proj(u_ij(b) · a) • ref = g_ij(b) • (proj(a) • ref)`.

---

## 8. Regime of the action conventions (stop-on-hard-frontier record)

The gluing orientation was derived, not chosen; reflexivity, symmetry and transitivity were
tested against it and all three hold with the *first* candidate `a' = u_ij(b) * a`.  No
inherited formula was altered.

Left/right: no single convention both descends and reproduces the one-fibre *left*
presentation globally.  The mathematically correct outcome, recorded explicitly, is

* **global action**: right, `x · h`;
* **local coordinate comparison**: left, `a_j = u_ij(b) · a_i`;
* **downstairs**: the inherited right action `ract` of the visible group, with
  `internalToFrame (x · a) = ract (internalToFrame x) (proj a)`.

The conversion between the inherited left action of `Gvis` on model frames and the inherited
right action `frameRAct` is derived, not assumed (`OrdinaryFrameModel.ract_smul`), from
`ract ref k = k • ref` together with transitivity of the left action.

---

## 9. Required decision table

| Question | Verdict |
| --- | --- |
| Compatible internal transitions assumed? | **YES** |
| Their existence proved in Task XXX? | **NO** |
| Gluing relation well-defined? | PROVED |
| Gluing relation equivalence relation? | PROVED |
| Global quotient carrier constructed? | PROVED |
| Base projection well-defined? | PROVED |
| Local charts constructed? | PROVED |
| Correct total-space topology constructed? | PROVED (one topology; Route Q proved equal to Route A; uniqueness relative to the charts also proved) |
| Local charts homeomorphisms? | PROVED |
| Base projection continuous? | PROVED |
| Global `Lift` action descends? | PROVED (as a **right** action) |
| Global action continuous? | PROVED |
| Global action free? | PROVED |
| Action transitive on fibres? | PROVED |
| Global map to ordinary frame total space? | PROVED |
| Global map continuous? | PROVED |
| Global map equivariant? | PROVED |
| Fibres exactly kernel orbits? | PROVED |
| Certified fibres exactly two-point? | PROVED conditionally on `Nat.card P.Ker = 2` (`internalToFrame_fibre_card_two`), together with the explicit fibre ≃ kernel bijection |
| Covering-map strengthening? | NOT ATTEMPTED |
| Restriction recovers one-fibre interface? | PROVED |
| Presentation independence? | PARTIAL — proved for gauge-related presentations (chart-indexed kernel-valued `ε_i`); the general classification is left open |
| Converse transition extraction? | PARTIAL — proved with the extra `AdaptedCharts` datum, which is stated explicitly |
| Existence condition from XXIX solved? | **NO** |
| Global obstruction solved? | **NO** |
| Physical spin derived? | **NO** |

---

## 10. Negative controls (items 147–159)

| # | Control | Where it is respected |
| --- | --- | --- |
| 147 | compatible transitions are an assumption, not a Task-XXIX theorem | `task30_conditionality`; the hypothesis appears as `Nonempty …` |
| 148 | local products do not give a global object without the equivalence-relation proof | the quotient is formed only after `internalGlueRel_equivalence`; `glueRel_same_chart` shows the relation is non-degenerate |
| 149 | a quotient set alone is not a topological object | the topology is a separate module, `InternalTopology` |
| 150 | a quotient topology does not automatically give local product triviality | local triviality is *proved*, via `isOpenMap_ipsi`, which itself needs `internal_chart_change_continuous` |
| 151 | the action must descend | `glueRel_smulPre` is proved before `ismul` is defined |
| 152 | local freeness ⇏ global freeness | `ismul_free` is proved on the quotient from the chart transport, and `ismul_stabilizer_trivial` records it |
| 153 | `proj(u_ij) = g_ij` is essential | it is the only inherited law used in `toFramePre_glueRel` |
| 154 | a two-element fibre theorem is weaker than a covering map | `internalToFrame_fibre_card_two` is stated as such; no covering map is claimed |
| 155 | conditional construction ≠ existence | Package V |
| 156–158 | no characteristic class, no cohomology, no obstruction solved | none appears in the layer |
| 159 | no physical spin structure claimed | no physical statement anywhere |

---

## 11. Unresolved mathematical obligations

1. **The existence problem (inherited, untouched).**  Whether the concrete ordinary frame
   family admits a compatible normalized continuous internal transition system.  Equivalently
   (Task XXIX, imported unchanged) whether the internally derived kernel equations are
   simultaneously solvable.  Task XXX proves nothing about it.
2. **Covering-map strengthening.**  `IsCoveringMap internalToFrame` is not proved.  What is
   proved is the exact fibre theorem (fibre ≃ kernel) and the two-point count for a
   two-element kernel.  Local trivializations of `internalToFrame` over open subsets of
   `FrameTotal` would be a separate topology branch.
3. **General presentation independence.**  Only gauge-related compatible systems are compared.
   Whether *every* two compatible systems over the same ordinary transitions are related by a
   chart-indexed kernel-valued gauge is a classification question left open.
4. **Converse extraction without extra data.**  The interface plus local charts determines the
   recovered transitions and their identity/inverse/triple laws, but the projection identity
   `proj(w_ij) = g_ij` requires the charts to be adapted to the ordinary frame charts
   (`AdaptedCharts`).  Whether a canonical adapted atlas always exists on an abstract
   `GluedInternalFrameSystem` is not decided here.
5. **Universe-polymorphic packaging.**  `task30_conditionality` exhibits the carrier in the
   universe `max u w t`; no statement is made about total spaces in other universes.

---

## 12. Source ledger

### IMPORTED STANDARD RESULT (Mathlib, revision above)

| Declaration | Module | Use |
| --- | --- | --- |
| `Quotient`, `Quotient.lift`, `Quotient.sound`, `Quotient.exact`, `Quotient.inductionOn` | `Mathlib/Data/Quot.lean` (core) | the quotient carrier |
| `Quotient.instTopologicalSpace`, `continuous_quot_mk`, `isOpen_coinduced` | `Mathlib/Topology/Constructions.lean` | the quotient topology |
| `isOpen_sigma_iff`, `continuous_sigma`, `continuous_sigma_iff`, `continuous_sigmaMk` | `Mathlib/Topology/Constructions.lean` | disjoint-union arguments |
| `Topology.IsQuotientMap`, `IsQuotientMap.isOpen_preimage`, `IsQuotientMap.continuous_iff`, `IsOpenMap.isQuotientMap` | `Mathlib/Topology/QuotientMap.lean` | Route Q reasoning and continuity of the action |
| `IsOpenMap.prodMap`, `IsOpen.isOpenMap_subtype_val`, `IsOpen.preimage` | `Mathlib/Topology/Maps/*`, `Mathlib/Topology/Basic.lean` | openness of `ipsi` and of `iq` |
| `Equiv.toHomeomorphOfContinuousOpen` | `Mathlib/Topology/Homeomorph/Defs.lean` | chart homeomorphisms |
| `Homeomorph.sigmaProdDistrib` | `Mathlib/Topology/Homeomorph/Lemmas.lean` | joint continuity of the action |
| `TopologicalSpace.ext_iff`, `isOpen_iSup_iff`, `isOpen_iUnion` | `Mathlib/Topology/Order.lean`, `Mathlib/Topology/Basic.lean` | topology uniqueness |
| `Nat.card_congr` | `Mathlib/SetTheory/Cardinal/Finite.lean` | the two-point fibre count |
| group lemmas `mul_inv_cancel_left`, `inv_mul_cancel_left`, `mul_left_cancel`, `eq_inv_of_mul_eq_one_left`, `map_mul`, `mul_smul` | Mathlib algebra | routine algebra |

### INHERITED PROJECT RESULT (Tasks XXIII–XXIX, imported unchanged)

| Declaration | Task | Use |
| --- | --- | --- |
| `NullSectorTask28.InternalProjection`, `.Ker`, `.mem_Ker_iff`, `.surjective_proj`, `.continuous_proj` | XXVIII | the frozen internal projection |
| `NullSectorTask28.TransitionSystem`, `ofOrdinary` | XXVIII | the ordinary transition data |
| `NullSectorTask29.CompatibleContinuousInternalTransitions` | XXIX | **the conditional input** |
| `NullSectorTask29.canTrivialiseSimultaneously_iff_exists_compatible_transitions` | XXIX | the conditionality statement |
| `NullSectorTask27.TopologicalFrameFamily`, `frameTopology`, `continuous_frameBase`, `frameTriv`, `frameTriv_transition`, `toOrdinaryTransitionSystem` | XXVII | the ordinary frame side |
| `NullSectorTask27.TopologicalFrameTriv.homeo`, `CompatibleFrameTriv.equivariant` | XXVII | the ordinary charts and their equivariance |
| `NullSectorTask27.frameRAct`, `frameRAct_one`, `frameRAct_mul`, `frameIsom`, `frameIsom_modelBasis`, `continuous_gvisModel_smul_prod` | XXVII | the inherited right action and the model topology |
| `NullSectorTask26.GvisModel`, `FramePlusModel`, `modelFrame`, `frameMulAction`, `existsUnique_frameAction`, `isom_ext_of_frame` | XXVI | the model frame space and its actions |

### DERIVED IN TASK XXX

Everything listed in §5.  In particular the gluing relation and its equivalence, the quotient
carrier, its topology and charts, the descended right action with freeness and fibrewise
transitivity, the global projection with continuity, equivariance and exact kernel fibres, the
conditional interface, the gauge comparison, and the converse extraction.

---

## 13. Build and axiom report

`Task30.lean` runs `#print axioms` on 62 declarations covering every principal endpoint.  Each
one reports exactly

```
[propext, Classical.choice, Quot.sound]
```

(some purely structural definitions report a subset).  No non-standard axiom occurs anywhere.

```
$ lake build RequestProject.NullSectorTask30.Task30
Build completed successfully.

$ lake build
Build completed successfully (8340 jobs).
errors:   0
warnings: 114   (all pre-existing in earlier layers; 0 in Task-XXX modules)
```

---

## 14. Preserved failed-build ledger (item 174)

No intended mathematical statement turned out to be false, and **no theorem was weakened by
any repair**: every entry below is an elaboration or naming problem.

| # | Command | Exact error | Diagnosis | Repair | Statement changed? |
| --- | --- | --- | --- | --- | --- |
| 1 | `lake build …GlobalGlueBase` | `Unknown identifier 'M.smul_existsUnique'` | a section variable used only in a proof body is not auto-included | made `M` an explicit binder of each lemma | no |
| 2 | `lake build …GlobalGlueBase` | `unsolved goals … (k * l) • h • M.ref = k • M.ract M.ref (l * h)` | the `rw` chain for `ract_smul` rewrote in the wrong order | restructured with two auxiliary `have`s | no |
| 3 | `lake build …GlobalGlueBase` | `Application type mismatch … smul_left_injective` | the right-action freeness proof cancelled twice instead of once | replaced by `mul_left_cancel (M.smul_left_injective h)` | no |
| 4 | `lake build …InternalGlueRelation` | 5 × `automatically included section variable(s) unused` | `[Group L]` etc. not needed by the elementary projections | added `omit … in` before each | no |
| 5 | `lake build …InternalQuotient` | `unexpected token 'omit'; expected 'lemma'` | `omit … in` placed *between* the docstring and the declaration | moved it before the docstring | no |
| 6 | `lake build …InternalQuotient` | `rewrite failed: did not find dite (b ∈ S.U i) …` | `prePt ⟨j, …⟩` was defeq but not syntactically `b` | `show` + `simp only [prePt_mk, …]` before `dif_pos` | no |
| 7 | `lake build …InternalQuotient` | `motive is not type correct` in `ipsi_icoord` | rewriting the base point inside a dependent membership proof | replaced by `Eq.trans … (ipsi_trans …)` + `congr 1` | no |
| 8 | `lake build …InternalTopology` | `rewrite failed: Continuous (?m ∘ iq T)` | `IsQuotientMap.continuous_iff` used in the wrong direction | dropped the `←` | no |
| 9 | `lake build …InternalTopology` | `Application type mismatch … chgMap T j i ⁻¹' W` | the indices of the change-of-coordinate map were swapped in `ipsi_preimage_image` | recomputed the set identity with `chgMap T i j` | no (the identity as stated was simply mis-indexed) |
| 10 | `lake build …InternalTopology` | `Unknown constant 'Homeomorph.homeomorphOfContinuousOpen'` | wrong namespace | `Equiv.toHomeomorphOfContinuousOpen` | no |
| 11 | `lake build …InternalTopology` | `Not a definitional equality: ↑((internalChartHomeo T i) p)` | cascade of #10 | resolved by #10 plus a structure-literal definition of `internalChart` | no |
| 12 | `lake build …InternalTopology` | `unexpected token ','` at `Continuous[inferInstance, τ]` | that bracket notation does not exist here | `@Continuous _ _ inferInstance τ …` with explicit types | no |
| 13 | `lake build …InternalTopology` | `IsOpen V ↔ IsOpen V`, instance mismatch `τ` vs `instTopologicalSpaceQuotient` | with a local `TopologicalSpace` hypothesis in scope, `IsOpen` resolved to it | introduced the named `internalTop T` and stated the uniqueness theorem against it | no |
| 14 | `lake build …InternalGroupAction` | `stuck at solving universe constraint … Prod.fst` | `Prod.ext` applied with an under-determined product type | introduced `ipsi_congr` and used it instead | no |
| 15 | `lake build …InternalGroupAction` | `rewrite failed: uu T i j c hc hc' * uu T k i c hk hc` | membership proofs differed syntactically after `subst` | `show` the goal at the reduced base point first | no |
| 16 | `lake build …InternalGroupAction` | `failed to synthesize instance` at `1 • x` | `SMul` notation used for a non-instance action | restated the stabilizer control without `•` | no |
| 17 | `lake build …ConditionalGlobalInterface` | `No goals to be solved` after `congr 1` | `congr` closed the proof-argument goal itself | replaced by an explicit `Subtype.ext` rewrite | no |
| 18 | `lake build …OrdinaryFrameSideInstance` | `Invalid argument name 'τfrm' for function 'DFunLike.coe'` | the topology argument of `TopologicalFrameTriv.homeo` is anonymous | used the ambient `letI` instance instead | no |

---

## 15. Interpretation boundary

Task XXX proves only:

> compatible internal transition data are **sufficient** to construct the expected global
> topological object, with its free fibrewise internal-group action and its continuous
> equivariant projection to the reconstructed ordinary frame total space, whose fibres are
> exactly the kernel orbits.

It does **not** prove:

> the concrete ordinary frame family admits such compatible internal transitions.

That remains the isolated existence problem inherited from Task XXIX.
