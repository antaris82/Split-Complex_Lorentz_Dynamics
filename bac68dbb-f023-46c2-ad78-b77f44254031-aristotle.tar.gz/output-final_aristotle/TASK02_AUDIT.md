# TASK 02 AUDIT — Intrinsic reconstruction and canonicality audit of the longitudinal product

All statements below are machine-checked in the Lean development contained in
`RequestProject/NullSectorTask02/`. Labels used throughout:

* **INPUT** — assumed data or definition;
* **DERIVED** — proved in Task 02 from the inputs;
* **COUNTEREXAMPLE** — explicit witness proving non-uniqueness / impossibility;
* **COMPARISON ONLY** — statement in the late comparison layer, which is the only
  place where the Task-01 split-complex layer is imported;
* **UNRESOLVED** — a formal obligation that remains open (none, see §13).

---

## 1. Exact input definitions

**INPUT** (from `RequestProject.NullSectorTask01.Basic`, the single permitted import):

```lean
abbrev Long : Type := ℝ × ℝ
def Q2 (X : Long) : ℝ := X.1 ^ 2 - X.2 ^ 2
```

together with the ordinary real vector-space structure of `ℝ × ℝ`.

**DERIVED** (`LorentzData.lean`), polarization of `Q2` and its coordinate form:

```lean
noncomputable def L2 (X Y : Long) : ℝ := (Q2 (X + Y) - Q2 X - Q2 Y) / 2

theorem L2_apply (t x s y : ℝ) : L2 (t, x) (s, y) = t * s - x * y
theorem L2_self (X : Long) : L2 X X = Q2 X
theorem L2_symm (X Y : Long) : L2 X Y = L2 Y X
theorem L2_add_left / L2_add_right / L2_smul_left / L2_smul_right / L2_sub_left / L2_sub_right
theorem L2_nondegenerate {X : Long} (h : ∀ Y, L2 X Y = 0) : X = 0
```

**INPUT** (chosen coordinate vectors, `LorentzData.lean`):

```lean
def u₀ : Long := (1, 0)
def s₀ : Long := (0, 1)
```

`u₀` is *explicitly declared additional data*; §9 and §10 below prove that it is not
determined by `Q2` and the future component.

---

## 2. Import-firewall report

Core classification files and their imports:

| File | Imports |
| --- | --- |
| `LorentzData.lean` | `RequestProject.NullSectorTask01.Basic` (permitted) |
| `CandidateProduct.lean` | `RequestProject.NullSectorTask02.LorentzData` |
| `FixedUnit.lean` | `RequestProject.NullSectorTask02.CandidateProduct` |
| `Minimality.lean` | `RequestProject.NullSectorTask02.FixedUnit` |
| `GeneralUnit.lean` | `RequestProject.NullSectorTask02.FixedUnit` |
| `Canonicality.lean` | `RequestProject.NullSectorTask02.GeneralUnit` |
| `Comparison.lean` | `RequestProject.NullSectorTask02.Canonicality`, **`RequestProject.NullSectorTask01.SplitComplex`** |
| `Task02.lean` | `RequestProject.NullSectorTask02.Minimality`, `RequestProject.NullSectorTask02.Comparison` |

Mechanical token audit of the six core files (`LorentzData`, `CandidateProduct`,
`FixedUnit`, `Minimality`, `GeneralUnit`, `Canonicality`) for the forbidden
project-local tokens

```
SplitComplex  Boost  Strata  Limits  Task01
mulL  oneL  jL  ep  em  qp  qm  P  nullEquiv  invProd
```

Result (word-boundary search, `rg -n "\b<token>\b"`): **no matches at all**.

Documented false positives of the weaker substring search:

| Token | Where it occurs as a substring | Status |
| --- | --- | --- |
| `Task01` | `import RequestProject.NullSectorTask01.Basic`, `open NullSectorTask01` | permitted import / namespace of the permitted import |
| `em` | inside `theorem`, `Idempotents`, `system`-like words | false positive, prose/keyword |
| `ep` | inside `representation`, `Re-imposing`, `step`, `declaration` | false positive, prose |
| `P` | none as a standalone identifier | — |

No Task-01 declaration other than `Long`, `Q2` (and the ambient names of
`NullSectorTask01.Basic`) is used before `Comparison.lean`. In particular the
Task-02 idempotents `pplus`, `pminus` are defined from `u₀`, `s₀` only.

---

## 3. Generic product definition

**INPUT** (`CandidateProduct.lean`). The unknown product is carried by a bilinear map,
so bilinearity is structural and never an extra hypothesis:

```lean
abbrev BiProd : Type := LinearMap.BilinMap ℝ Long Long

def LeftUnit (μ : BiProd) (e : Long) : Prop := ∀ X, μ e X = X
def RightUnit (μ : BiProd) (e : Long) : Prop := ∀ X, μ X e = X
def TwoSidedUnit (μ : BiProd) (e : Long) : Prop := LeftUnit μ e ∧ RightUnit μ e
def QMultiplicative (μ : BiProd) : Prop := ∀ X Y, Q2 (μ X Y) = Q2 X * Q2 Y
def Commutative (μ : BiProd) : Prop := ∀ X Y, μ X Y = μ Y X
def Associative (μ : BiProd) : Prop := ∀ X Y Z, μ (μ X Y) Z = μ X (μ Y Z)

def AdmissibleAt (e : Long) (μ : BiProd) : Prop := TwoSidedUnit μ e ∧ QMultiplicative μ
def LeftAdmissibleAt (e : Long) (μ : BiProd) : Prop := LeftUnit μ e ∧ QMultiplicative μ
```

`AdmissibleAt` contains **no** commutativity, **no** associativity, **no** condition on
`Q2 e`, and no coordinate formula.

---

## 4. Theorem inventory

### 4.1 `LorentzData.lean` (DERIVED)

`L2_apply`, `L2_coord`, `L2_symm`, `L2_add_left`, `L2_add_right`, `L2_smul_left`,
`L2_smul_right`, `L2_neg_left`, `L2_sub_left`, `L2_sub_right`, `L2_zero_left`,
`L2_zero_right`, `L2_self`, `L2_nondegenerate`, `Q2_u₀`, `Q2_s₀`, `L2_u₀_s₀`,
`coord_decomp`.

### 4.2 `CandidateProduct.lean` (DERIVED)

* `bilin_expand` — expansion of an arbitrary bilinear product in the coordinate basis;
* `Q2_leftUnit_eq_one` — **`Q2 e = 1` is forced by a left unit alone**;
* `leftUnit_ne_zero`, `Q2_unit_eq_one`;
* `twoSidedUnit_unique`, `unit_unique_mixed` — uniqueness of the unit from the unit laws.

### 4.3 `FixedUnit.lean` (DERIVED)

`mu_u₀_u₀`, `mu_u₀_s₀`, `mu_s₀_u₀`, `mu_shape`, `mu_s₀_s₀`, `fixedUnit_formula`,
`fixedUnit_commutative`, `fixedUnit_associative`, `fixedUnit_unique`, `recU`,
`recU_admissible`, `fixedUnit_existsUnique`, `pplus`, `pminus`, `pplus_add_pminus`,
`pplus_sub_pminus`, `Q2_pplus`, `Q2_pminus`, `mu_pplus_pplus`, `mu_pminus_pminus`,
`mu_pplus_pminus`, `mu_pminus_pplus`.

### 4.4 `Minimality.lean` (DERIVED + COUNTEREXAMPLE)

`left_shape`, `leftAdmissible_dichotomy`, `twistU`, `twistU_left_admissible`,
`recU_left_admissible`, `recU_ne_twistU`, `leftAdmissible_not_unique`,
`twistU_not_rightUnit`, `twistU_not_commutative`, `twistU_not_associative`,
`testA_unique`, `testB_unique`, `testC_unique`.

### 4.5 `GeneralUnit.lean` (DERIVED + COUNTEREXAMPLE)

`compl`, `Q2_compl`, `L2_compl`, `ec_decomp`, `recAt`, `recAt_eq`, `recAt_admissible`,
`ec_expand`, `mu_compl_sq`, `generalUnit_formula`, `eq_recAt`, `exists_admissible_iff`,
`generalUnit_existsUnique`, `admissible_units_determine`, `FutureUnit`,
`futureUnit_u₀`, `futureUnit_other`, `futureUnit_not_unique`,
`admissible_product_not_intrinsic`.

### 4.6 `Canonicality.lean` (DERIVED + obstruction)

`TsymMap`, `TsymInv`, `Tsym`, `Tsym_Q2`, `Tsym_future_cone`, `Tsym_futureUnit`,
`Tsym_ne_id`, `Tsym_no_fixed_point`, `Equivariant`, `unit_map_of_equivariant`,
`no_equivariant_admissible`, `recAt_not_equivariant`, `u₀_available`,
`no_invariant_futureUnit`, `u₀_is_extra_data`.

### 4.7 `Comparison.lean` (COMPARISON ONLY)

`mulLBil`, `oneL_eq_u₀`, `mulLBil_admissible`, `mulLBil_eq_recU`, `mulL_eq_recU`,
`mulLBil_eq_recAt_u₀`, `pplus_eq_ep`, `pminus_eq_em`, `jL_square_derived`,
`ep_idem_derived`, `em_idem_derived`, `ep_em_orthogonal_derived`, `mulL_comm_derived`,
`mulL_assoc_derived`, `ep_add_em_derived`, `ep_sub_em_derived`, `Q2_ep_derived`,
`Q2_em_derived`.

### 4.8 `Task02.lean`

The principal theorems `task02_*` (see §22 of the request; each acceptance item is a
named theorem) plus the `#print axioms` report.

---

## 5. Fixed-unit classification (reference unit `u₀ = (1,0)`)

The argument starts from a genuinely arbitrary `μ : BiProd` with `AdmissibleAt u₀ μ`.

1. The unit laws give `μ u₀ u₀ = u₀`, `μ u₀ s₀ = s₀`, `μ s₀ u₀ = s₀`, so bilinearity
   leaves exactly one unknown vector `w = μ s₀ s₀` (`mu_shape`).
2. Three instances of `Q2`-multiplicativity — at `(s₀,s₀)`, `((1,1),s₀)`, `((1,1),(1,1))`
   — force `w = u₀` (`mu_s₀_s₀`). **This is the derived square relation.**
3. Hence (`fixedUnit_formula`)

   ```
   μ (t,x) (s,y) = (t s + x y, t y + x s),
   ```

   which is **PROVED UNIQUE**: `fixedUnit_unique`, and with existence
   (`recU_admissible`) `fixedUnit_existsUnique : ∃! μ, AdmissibleAt u₀ μ`.
4. Commutativity and associativity are corollaries (`fixedUnit_commutative`,
   `fixedUnit_associative`), *not* assumptions.
5. With `p₊ := ½•(u₀+s₀)`, `p₋ := ½•(u₀−s₀)` defined independently of Task 01, every
   admissible product at `u₀` satisfies

   ```
   μ p₊ p₊ = p₊,  μ p₋ p₋ = p₋,  μ p₊ p₋ = 0,  μ p₋ p₊ = 0,
   p₊ + p₋ = u₀,  p₊ − p₋ = s₀,  Q2 p₊ = 0,  Q2 p₋ = 0.
   ```

   The complementary null-idempotent structure is therefore **downstream** of the
   product reconstruction, not an independent input.

---

## 6. Weakened-assumption classification (left unit only)

For a generic `μ` with `LeftAdmissibleAt u₀ μ` the two unknown vectors
`v = μ s₀ u₀`, `w = μ s₀ s₀` are constrained by five instances of
`Q2`-multiplicativity to `v = (0, ε)`, `w = (ε, 0)` with `ε = ±1`. Hence
(`leftAdmissible_dichotomy`) exactly two branches:

| Branch | Formula | Right unit? | Commutative? | Associative? |
| --- | --- | --- | --- | --- |
| `recU` | `(t s + x y, t y + x s)` | yes | yes | yes |
| `twistU` | `(t s − x y, t y − x s)` | **no** (`twistU_not_rightUnit`) | **no** (`twistU_not_commutative`) | **no** (`twistU_not_associative`) |

`recU ≠ twistU` (`recU_ne_twistU`), so the left-unit-only problem is
**PROVED NON-UNIQUE** (`leftAdmissible_not_unique`), and each of the three extra
conditions separately restores uniqueness (`testA_unique`, `testB_unique`,
`testC_unique`).

---

## 7. Assumed versus derived

| Property | Status |
| --- | --- |
| bilinearity of `μ` | INPUT (carrier `LinearMap.BilinMap ℝ Long Long`) |
| existence of a left unit `e` | INPUT |
| existence of a right unit `e` | INPUT in `AdmissibleAt`; separately tested in §6 |
| `Q2 (μ X Y) = Q2 X · Q2 Y` | INPUT |
| `Q2 e = 1` | **DERIVED** (`Q2_leftUnit_eq_one`; left unit alone suffices) |
| uniqueness of the unit | **DERIVED** (`twoSidedUnit_unique`) |
| `μ s₀ s₀ = u₀` | **DERIVED** (`mu_s₀_s₀`) |
| coordinate formula of `μ` | **DERIVED** (`fixedUnit_formula`, `generalUnit_formula`) |
| commutativity | **DERIVED** from `AdmissibleAt u₀`; **NOT** derivable from left unit alone |
| associativity | **DERIVED** from `AdmissibleAt u₀`; **NOT** derivable from left unit alone |
| idempotent/null structure of `p₊, p₋` | **DERIVED** |
| the choice of `u₀` itself | INPUT, and provably not intrinsic (§9, §10) |

---

## 8. Arbitrary unit: existence and uniqueness

**DERIVED** (`GeneralUnit.lean`):

```lean
theorem exists_admissible_iff (e : Long) : (∃ μ : BiProd, AdmissibleAt e μ) ↔ Q2 e = 1
theorem generalUnit_existsUnique {e : Long} (hQ : Q2 e = 1) : ∃! μ : BiProd, AdmissibleAt e μ
theorem generalUnit_formula {μ : BiProd} {e : Long} (h : AdmissibleAt e μ) (X Y : Long) :
    μ X Y = (L2 X e) • Y + (L2 Y e) • X - (L2 X Y) • e
```

So `Q2 e = 1` is *equivalent* to the existence of an admissible product with unit `e`,
and for such `e` the product is unique. The uniform coordinate-free expression

```
μ_e(X,Y) = L2(X,e)·Y + L2(Y,e)·X − L2(X,Y)·e
```

is **the output** of the uniqueness analysis (`generalUnit_formula`), not an input: the
proof expands a generic `μ` in the basis `(e, compl e)`, derives `μ (compl e) (compl e) = e`
from `Q2`-multiplicativity, and only then recognises the closed form. `recAt e` is the
same expression packaged as a bilinear map and is used for the existence half.

Distinct units give distinct products (`admissible_units_determine`), by uniqueness of
the two-sided unit.

---

## 9. Future-unit result

```lean
def FutureUnit (e : Long) : Prop := e.1 > 0 ∧ Q2 e = 1
```

**COUNTEREXAMPLE / PROVED NON-UNIQUE** (`futureUnit_not_unique`): `(1,0)` and
`(5/4, 3/4)` are both future units and are different. Consequently
(`admissible_product_not_intrinsic`) there are at least two admissible products whose
units are future units, so `Q2` together with the future component does **not** select a
product.

The future unit hyperbola `{e | Q2 e = 1, e.1 > 0}` as a whole is intrinsic to the
Lorentz data; a *point* of it is not.

---

## 10. Lorentz-equivariance obstruction

**INPUT / construction** (`Canonicality.lean`), built from `Long` and `Q2` only and
independently of any Task-01 boost — a rational linear equivalence:

```
Tsym (t,x) = (5/4 · t + 3/4 · x, 3/4 · t + 5/4 · x)
```

**DERIVED**: `Tsym_Q2` (`Q2 (Tsym X) = Q2 X`), `Tsym_future_cone` (the closed set
`0 ≤ X.1 ∧ 0 ≤ Q2 X` is preserved), `Tsym_futureUnit`, `Tsym_ne_id`, and
`Tsym_no_fixed_point` (`Tsym X = X → X = 0`).

**PROVED IMPOSSIBLE** (`no_equivariant_admissible`):

```lean
¬ ∃ (e : Long) (μ : BiProd), AdmissibleAt e μ ∧ Equivariant Tsym μ
```

Proof structure: equivariance maps a two-sided unit to a two-sided unit
(`unit_map_of_equivariant`, using surjectivity of `Tsym`); uniqueness of the unit forces
`Tsym e = e`; `Tsym` has no nonzero fixed vector, so `e = 0`, contradicting the derived
`Q2 e = 1`. Equivalently `recAt_not_equivariant`: no normalized `e` gives an equivariant
product.

This is the formal content of "the algebra requires a unit choice": the statement is
entirely in terms of linear maps, `Q2`, units and product equivariance.

---

## 11. Late comparison with Task 01 (COMPARISON ONLY)

In `Comparison.lean` only:

1. `mulLBil_admissible : AdmissibleAt u₀ mulLBil` — the Task-01 product, packaged as a
   bilinear map, satisfies the Task-02 admissibility conditions at the Task-01 unit
   (`oneL_eq_u₀ : oneL = u₀`).
2. `mulLBil_eq_recU : mulLBil = recU` — obtained by applying the Task-02 uniqueness
   theorem `fixedUnit_unique`, not by coordinate rewriting; `mulL_eq_recU` is its
   pointwise form, and `mulLBil_eq_recAt_u₀` uses the general-unit uniqueness theorem.
3. `pplus_eq_ep : pplus = ep`, `pminus_eq_em : pminus = em`.
4. Task-01 split-complex identities that have become consequences of the more primitive
   Task-02 assumptions, stated for an *arbitrary* admissible `μ` at `u₀`:
   `jL_square_derived` (`μ jL jL = oneL`), `ep_idem_derived`, `em_idem_derived`,
   `ep_em_orthogonal_derived`, `mulL_comm_derived`, `mulL_assoc_derived`; and,
   independently of any product, `ep_add_em_derived`, `ep_sub_em_derived`,
   `Q2_ep_derived`, `Q2_em_derived`.

The reconstruction layer nowhere presupposes these equalities.

---

## 12. Negative-control table (required by §19 of the request)

| Input assumptions | Classification question | Verdict | Theorem |
| --- | --- | --- | --- |
| bilinear + left unit `u₀` + `Q2`-multiplicative | unique? | **PROVED NON-UNIQUE** (exactly two) | `leftAdmissible_dichotomy`, `leftAdmissible_not_unique` |
| previous row + right unit | unique? | **PROVED UNIQUE** | `testA_unique` |
| first row + commutative | unique? | **PROVED UNIQUE** | `testB_unique` |
| first row + associative | unique? | **PROVED UNIQUE** | `testC_unique` |
| bilinear + two-sided unit + `Q2`-multiplicative | are commutativity and associativity derived? | **DERIVED (both)** | `fixedUnit_commutative`, `fixedUnit_associative` |
| `Q2` + future component, no chosen unit | is a unique product intrinsically selected? | **PROVED NON-UNIQUE** (and no equivariant product exists: **PROVED IMPOSSIBLE**) | `admissible_product_not_intrinsic`, `no_equivariant_admissible` |
| `Q2` + chosen normalized unit `e` | is the compatible product unique? | **PROVED UNIQUE** (and exists iff `Q2 e = 1`) | `generalUnit_existsUnique`, `exists_admissible_iff` |

---

## 13. Final dependency graph (generated from the proved implications)

```
Long + Q2                     (INPUT)
   ↓ polarization  [no extra assumption]
L2 (symmetric, nondegenerate, L2(X,X) = Q2 X)
   ↓ + bilinear product carrier + Q2-multiplicativity + a left unit e
Q2 e = 1                      (DERIVED, forced)
   |
   |  BRANCH 1: only a left unit assumed
   ↓
exactly two products at u₀    (NON-UNIQUE: recU, twistU)
   ↓ + any one of {right unit, commutativity, associativity}
unique product at u₀
   |
   |  BRANCH 2: two-sided unit assumed
   ↓
unique product at the chosen unit e  (Q2 e = 1 required and sufficient)
   ↓ (corollary)
square relation  μ (compl e) (compl e) = e ;  at e = u₀ :  μ s₀ s₀ = u₀
   ↓ (corollary)
complementary null idempotents p₊, p₋ : idempotent, orthogonal, Q2-null
```

Concerning the chain proposed in §13 of the request:

```
Lorentz quadratic carrier → chosen normalized unit → unique bilinear
norm-compatible product → square relation → complementary null idempotents
```

* arrow 2→3 (**chosen normalized unit ⇒ unique product**): **THEOREM**
  (`generalUnit_existsUnique`);
* arrow 3→4 (**unique product ⇒ square relation**): **THEOREM** (`mu_compl_sq`,
  `mu_s₀_s₀`);
* arrow 4→5 (**square relation ⇒ null idempotents**): **THEOREM** (`task02_idempotents`);
* arrow 1→2 (**Lorentz quadratic carrier ⇒ chosen normalized unit**): **FAILS**. The
  correct statement is: the Lorentz data determine the *set* `{e | Q2 e = 1}` (and, with
  the future component, the future branch of it), but no single element of it — see
  `futureUnit_not_unique` and `no_invariant_futureUnit`. Choosing `u₀` is *coordinate
  availability*, i.e. additional data relative to the Lorentz-symmetric structure. The
  strongest justified statement is therefore

  ```
  Long + Q2 + chosen normalized unit  ⇒  unique product ⇒ square relation ⇒ idempotents
  ```

  while `Long + Q2` (with or without the future component) does **not** determine a
  product, and no admissible product is equivariant under the explicit symmetry `Tsym`.
  No additional algebraic axiom is needed once a two-sided unit is assumed; with only a
  left unit exactly one extra axiom (any of right unit / commutativity / associativity)
  is needed.

---

## 14. Unresolved mathematical obligations

None within the stated scope. Every row of the negative-control table has a verdict of
`PROVED UNIQUE`, `PROVED NON-UNIQUE`, or `PROVED IMPOSSIBLE`; no `UNRESOLVED` entries
remain, and the development contains no `sorry`, no `admit`, and no custom axiom.

Explicitly out of scope (untouched by Task 02, by instruction): other longitudinal
planes in 3+1, patching over spatial directions, boundary-curve classification,
compactification, dynamics.

---

## 15. Source ledger

### IMPORTED STANDARD RESULT (Lean/Mathlib, revision below)

| Declaration | Mathlib module | Use |
| --- | --- | --- |
| `LinearMap.BilinMap` | `Mathlib/LinearAlgebra/BilinearMap.lean` | carrier of the unknown bilinear product |
| `LinearMap.mk₂` | `Mathlib/LinearAlgebra/BilinearMap.lean` | construction of explicit bilinear products (`recU`, `twistU`, `recAt`, `mulLBil`) |
| `LinearMap.ext` | `Mathlib/Algebra/Module/LinearMap/Defs.lean` | extensionality for products |
| `LinearEquiv.ofLinear` | `Mathlib/Algebra/Module/Equiv/Basic.lean` | construction of `Tsym` |
| `Prod.ext` | `Init/Ext.lean` (Lean core) | coordinatewise equality in `ℝ × ℝ` |
| `sq_eq_zero_iff` | `Mathlib/Algebra/GroupWithZero/Basic.lean` | `q² = 0 → q = 0` in the general-unit proof |
| tactics `ring`, `linear_combination`, `nlinarith`, `norm_num`, `simp`, `module`, `abel` | `Mathlib/Tactic/*` | polynomial and module-level bookkeeping |

The `QuadraticMap` API (`QuadraticMap.polarBilin`, `QuadraticMap.associated`) was **not**
used: the polarization is defined and proved directly, which keeps the dependency
structure of §13 transparent.

### DERIVED IN TASK 02

Everything listed in §4 above, in the namespace `NullSectorTask02`.

### COMPARISON ONLY

`mulL`, `oneL`, `jL`, `ep`, `em` from `RequestProject.NullSectorTask01.SplitComplex`,
used only inside `Comparison.lean` (and re-exported through `Task02.lean`).

Standard mathematical background (for orientation only; nothing is imported from it):
the classification of two-dimensional real unital composition algebras is classical,
and the split-complex algebra is the one carrying a hyperbolic form. All statements
used here are proved from scratch in the development.

---

## 16. Environment

| Item | Value |
| --- | --- |
| Lean toolchain | `leanprover/lean4:v4.28.0` (`lean-toolchain`) |
| Mathlib | `v4.28.0`, commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (`lake-manifest.json`) |
| Build target | `RequestProject` library (`lakefile.toml`) |

Exact imports used by Task-02 files: see the table in §2. Task 01's `Basic.lean` imports
`Mathlib`, so Mathlib is available transitively in every Task-02 file; no Task-02 file
adds any further import.

---

## 17. Build report

```
lake build
```

completes successfully (all targets, including
`RequestProject.NullSectorTask02.Task02`), with no errors and no linter warnings in the
Task-02 files. A search for `sorry` / `admit` / `axiom` in `RequestProject/` returns no
occurrences (only the English word "admits" inside comments).

---

## 18. Axiom report

`#print axioms` is executed for every principal theorem at the end of `Task02.lean`.
Each of

```
task02_polarization              task02_unit_normalized          task02_unit_unique
task02_fixedUnit_formula         task02_fixedUnit_existsUnique   task02_comm_assoc_derived
task02_square_relation           task02_idempotents              task02_leftUnit_dichotomy
task02_leftUnit_not_unique       task02_minimality_tests         task02_exists_admissible_iff
task02_generalUnit_existsUnique  task02_generalUnit_formula      task02_futureUnit_not_unique
task02_product_not_intrinsic     task02_symmetry                 task02_no_equivariant_admissible
task02_u₀_extra_data             task02_comparison_admissible    task02_comparison_eq
task02_comparison_idempotents
```

depends exactly on

```
[propext, Classical.choice, Quot.sound]
```

i.e. only on the standard Lean/Mathlib axioms. No custom axiom is declared anywhere.

---

## 19. Scope statement

No physical or dynamical structure was introduced. The development contains only real
vector spaces, a quadratic form and its polarization, bilinear maps, linear
equivalences, and finitely many explicit real coefficients. No object is given a
physical interpretation; the linear equivalence `Tsym` is used purely as a
`Q2`-preserving symmetry of the carrier.
