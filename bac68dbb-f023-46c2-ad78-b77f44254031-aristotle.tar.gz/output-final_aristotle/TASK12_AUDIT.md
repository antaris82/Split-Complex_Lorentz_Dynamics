# TASK 12 AUDIT

## Hardening the candidate state carrier: invariant left carriers, reducibility, minimality, and axial stability

**Status of this document.** It is the audit required by §41 of the Task-12 statement.
The twenty-four required sections appear in order.  Status vocabulary is that of §42.

**Scope disclaimer, stated once and repeated in §21 and §24.**
Task 12 derives a **MINIMAL ALGEBRAIC LEFT CARRIER**.
It does **not** derive, and does not claim, a **PHYSICAL STATE SPACE** (§37, §45).

---

## 1. Exact toolchain

| item | value |
|---|---|
| Lean | `leanprover/lean4:v4.28.0` (`lean-toolchain`) |
| Mathlib | required as `rev = "v4.28.0"` in `lakefile.toml` |
| Mathlib commit resolved | `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (`lake-manifest.json`) |
| build tool | `lake` |
| library target | `RequestProject`, glob `RequestProject.+` |

Transitive dependency revisions, as pinned in `lake-manifest.json`:
`batteries 495c008c3e3f4fb4256ff5582ddb3abf3198026f`,
`aesop f642a64c76df8ba9cb53dba3b919425a0c2aeaf1`,
`Qq b8f98e9087e02c8553945a2c5abf07cec8e798c3`,
`proofwidgets be3b2e63b1bbf496c478cef98b86972a37c1417d`,
`importGraph 85b59af46828c029a9168f2f9c35119bd0721e6e`,
`LeanSearchClient c5d5b8fe6e5158def25cd28eb94e4141ad97c843`,
`plausible 55c8532eb21ec9f6d565d51d96b8ca50bd1fbef3`,
`Cli 4f10f47646cb7d5748d6f423f4a07f98f7bbcc9e`.

The toolchain was neither upgraded nor downgraded for Task 12.

---

## 2. Exact imported pre-identification modules

Task 12 consists of thirteen modules.  Their `import` lines are exactly:

```text
Task12/SafeBase.lean                 ← RequestProject.NullSectorTask10.AlgebraExtension
Task12/LeftCarrier.lean              ← Task12.SafeBase
Task12/GeneratedCarrier.lean         ← Task12.LeftCarrier
Task12/DimensionClassification.lean  ← Task12.GeneratedCarrier
Task12/MinimalCarrier.lean           ← Task12.DimensionClassification
Task12/CarrierFamily.lean            ← Task12.MinimalCarrier
Task12/AxisRelation.lean             ← Task12.CarrierFamily
Task12/HalfAngleRelation.lean        ← Task12.AxisRelation,
                                       RequestProject.NullSectorTask10.HalfAngleSectors
Task12/LiftStability.lean            ← Task12.HalfAngleRelation,
                                       RequestProject.NullSectorTask11.ReferenceExistence
Task12/CentralAction.lean            ← Task12.LiftStability
Task12/CarrierEndomorphisms.lean     ← Task12.CentralAction
Task12/Identification.lean           ← Task12.CarrierEndomorphisms,
                                       RequestProject.NullSectorTask11.Identification
Task12/Task12.lean                   ← Task12.Identification
```

**All inherited modules are pre-identification** except the last two lines.
`NullSectorTask11.Identification` (which transitively pulls in the Task-08 and Task-10
comparison layers) is imported **only** by `Task12/Identification.lean`, the module
labelled COMPARISON ONLY, which in turn is imported only by `Task12/Task12.lean`.

Inherited declarations actually used (INHERITED):

| source | declarations |
|---|---|
| Task 08 | `W = Wit8`, `⋆ = wit8Mul`, `wit8MulFun`, basis `w1, wA, wB, wC, wP, wQ, wR, wS`, `one_mul_W`, `mul_one_W`, `mul_assoc_W`, `add_mul_W`, `mul_add_W`, `smul_mul_W`, `mul_smul_W`, the complete multiplication table |
| Task 09 | `nRe`, `nSc`, `Ncand`, `Ncand_mul`, `Ncand_mem`, the central plane `Z`, `mem_Z_iff`, `Z_central`, `Z_mul_mem`, `finrank_Z = 2` |
| Task 10 | `Phi θ` (algebra automorphism family), `SectorPlus`, `SectorMinus`, `mem_SectorPlus_iff`, `mem_SectorPlus_iff_axis`, `finrank_SectorPlus = 4`, `wS_mul_mem_SectorPlus`, `Ustd`, `ksc`, `ksc_mul_left` |
| Task 11 | `Uref = Ustd`, `IsFullLift`, `Uref_isFullLift` |
| Task 08 comparison (COMPARISON ONLY) | `toMat`, `toMat_mul`, `toMat_one`, `toMat_smul`, `toMat_bijective`, `comparison_toMat_zc` |

No new generator, no new axis, no new product and no new scalar is introduced.

---

## 3. Experiment-1 firewall

**ENFORCED.**  Mechanical scan: no module of `RequestProject/NullSectorTask12/` imports
anything outside `RequestProject.NullSectorTask08–12` and Mathlib.  No Experiment-1
theorem, construction, source, terminology or formula is used anywhere, in the
reconstruction core or in the comparison layer.

```text
rg -n "^import" RequestProject/NullSectorTask12/*.lean
  | grep -v "NullSectorTask0[89]\|NullSectorTask1[012]"
→ NONE
```

---

## 4. Representation-target firewall

**ENFORCED in the reconstruction core.**  Scan of the twelve core modules (everything
except `Identification.lean`) for
`spinor, Weyl, Dirac, Pauli, fermion, spin-1/2, spin representation, minimal left ideal,
column vector, ℂ², rank-one, primitive idempotent, SU(2), Spin(3), simple module,
matrix rank`:

* the **only** matches are the firewall *declarations themselves*, in the doc comment of
  `SafeBase.lean` (lines 42–44) and of `Task12.lean` (line 10), which state that these
  objects are not used.  No such object occurs in any definition, statement or proof.

Two disclosed naming artefacts, both generic Mathlib namespace usage, not a matrix model
of `W`:

* `SafeBase.lean:90` uses `Matrix.trace` inside the computation of `LinearMap.trace`
  (Mathlib expands a linear-map trace through its matrix representation; this is a library
  internal, not an identification of `W`);
* `CarrierFamily.lean:313` uses `Matrix.range_cons`/`Matrix.range_empty`, the simp lemmas
  for the vector literal notation `![…]` used for the eight coordinates.

Neither introduces `M₂(ℂ)`, a complex structure, a column space or a rank notion.  The
identification of `W` with a conventional algebra appears first at
`Task12/Identification.lean` (§21 below).

**No conventional expected carrier was constructed as the first proof (§9).**  The first
proper carrier produced is `Lgen ψ` for an intrinsically characterized `ψ`; idempotency
(`IsSelfProduct`) is *derived* as the normal form of a generator
(`exists_selfProduct_generator`), not assumed (§10).

---

## 5. Physical-target firewall

**ENFORCED.**  Scan of all thirteen modules for
`photon, electron, mass, energy, frequency, Hamiltonian, Dirac equation, Pauli equation,
Maxwell, Schrödinger, wavefunction, probability, Born rule, measurement, gauge field,
field operator` → **NONE**.

Also enforced (§34, §35, §36):

* no norm, inner product, Hermitian or positive form, unit state, orthogonality — the only
  matches for `norm` are occurrences of the tactic `norm_num`;
* no quotient of states, no relation `ψ ~ λψ`, no projective construction;
* no normalization condition is imposed.  The two coordinate conditions `e 0 = 1/2`,
  `e 7 = 0` that appear in several statements are **derived**, not imposed: they are the
  content of `selfProduct_coords`, which proves that *every* nonzero self-product element
  other than the unit automatically satisfies them.

---

## 6. Left-carrier definition (DERIVED, neutral)

`RequestProject/NullSectorTask12/LeftCarrier.lean`:

```lean
def IsLeftCarrier (L : Submodule ℝ W) : Prop := ∀ x ψ : W, ψ ∈ L → x ⋆ ψ ∈ L

def IsNonzeroLeftCarrier (L : Submodule ℝ W) : Prop := IsLeftCarrier L ∧ L ≠ ⊥

def IsProperLeftCarrier (L : Submodule ℝ W) : Prop := IsNonzeroLeftCarrier L ∧ L ≠ ⊤

def IsMinimalLeftCarrier (L : Submodule ℝ W) : Prop :=
  IsNonzeroLeftCarrier L ∧ ∀ M : Submodule ℝ W, IsLeftCarrier M → M ≤ L → M = ⊥ ∨ M = L
```

The minimality definition is intrinsic: it quantifies over left-stable real subspaces of
`W` contained in `L`, with no module-theoretic vocabulary.

Auxiliary intrinsic notions used below, all in `SafeBase.lean` / `GeneratedCarrier.lean`:

```lean
Lmul a := wit8Mul a          -- left multiplication, a linear map W →ₗ[ℝ] W
Rmul b := wit8Mul.flip b     -- right multiplication
def IsNullElt (x : W) : Prop := nRe x = 0 ∧ nSc x = 0
def HasInverse (x : W) : Prop := ∃ y, x ⋆ y = w1 ∧ y ⋆ x = w1
def IsSelfProduct (e : W) : Prop := e ⋆ e = e
```

with `nRe`, `nSc` the two inherited Task-09 coefficient functions and
`Ncand z x = (nRe x) • w1 + (z * nSc x) • wS` the inherited central quadratic datum.
Branch symmetry (§15) is proved once, `null_branch_symmetric`:
`Ncand 1 x = 0 ↔ Ncand (-1) x = 0`, so neither branch `N₊`, `N₋` is preferred anywhere.

---

## 7. Generated-carrier construction

```lean
noncomputable def Lgen (ψ : W) : Submodule ℝ W := LinearMap.range (Rmul ψ)

theorem mem_Lgen_iff (ψ y : W) : y ∈ Lgen ψ ↔ ∃ x : W, x ⋆ ψ = y
theorem isLeftCarrier_Lgen (ψ : W) : IsLeftCarrier (Lgen ψ)
theorem self_mem_Lgen (ψ : W) : ψ ∈ Lgen ψ
theorem Lgen_le {L} (hL : IsLeftCarrier L) {ψ} (hψ : ψ ∈ L) : Lgen ψ ≤ L
```

`Lgen ψ` is `spanℝ {x ⋆ ψ | x : W}` in the Lean-friendly form `range (Rmul ψ)`; the two
agree because `Rmul ψ` is linear, so its range is already a subspace.  Since `w1 ⋆ ψ = ψ`,
the generator lies in its own carrier and `Lgen` is the smallest left carrier containing
`ψ` (**GENERATED CARRIER**, **LEFT-STABLE**).

---

## 8. Exact possible carrier dimensions (principal theorem, §13)

```lean
theorem finrank_Lgen_eq_eight {ψ : W} (hψ : ¬ IsNullElt ψ) : Module.finrank ℝ (Lgen ψ) = 8
theorem finrank_Lgen_eq_four  {ψ : W} (hψ : ψ ≠ 0) (hnull : IsNullElt ψ) :
    Module.finrank ℝ (Lgen ψ) = 4

theorem possible_generated_dimensions :
    {d : ℕ | ∃ ψ : W, ψ ≠ 0 ∧ Module.finrank ℝ (Lgen ψ) = d} = {4, 8}
```

**DERIVED, AXIS-INDEPENDENT.**  The exact set is `{4, 8}`; no other dimension occurs, and
both occur.  Both inclusions are proved: `⊆` from the dichotomy
`IsNullElt ψ ∨ HasInverse ψ` (`hasInverse_iff`), `⊇` by exhibiting witnesses
(`w1` for `8`; `halfSum wB = (1 + B)/2` for `4`, via `halfSum_props`, which works for any
square root of the unit with vanishing unit coordinate and so uses no chosen direction).

Proof ingredients, all elementary and coordinate-based:

* if `ψ` is not null it is invertible (`hasInverse_iff`, from `x ⋆ wconj x = Ncand 1 x`
  and the explicit central inverse `zinv`), so `Lgen ψ = ⊤` and the dimension is `8`
  (`finrank_W`);
* if `ψ` is null and nonzero, then every element of `Lgen ψ` is null (`null_mul` via
  multiplicativity of `Ncand`), hence `nRe` vanishes identically on `Lgen ψ`; the
  coordinate projection `proj4 : y ↦ ![y 0, y 4, y 5, y 6]` onto the four coordinates
  entering `nRe` with a positive sign is then injective on the subspace (if those four
  vanish, `nRe y = 0` forces the remaining four to vanish too, by positivity), which
  bounds `dim ≤ 4` (`finrank_le_four_of_nRe_zero` — an isotropy bound for a form of
  signature `(4,4)`);
* the matching lower bound comes from the normal form: a nonzero null `ψ` admits a
  self-product generator with the same carrier (`exists_selfProduct_generator`), and for a
  self-product `e` the map `Rmul e` is idempotent, so
  `dim (Lgen e) = trace (Rmul e) = 8 · e 0 = 4` (`finrank_range_of_idem`,
  `trace_Rmul`, `selfProduct_coords`).

---

## 9. Minimal dimension theorem (§17)

```lean
theorem isMinimal_iff_proper (L : Submodule ℝ W) :
    IsMinimalLeftCarrier L ↔ IsProperLeftCarrier L
theorem finrank_of_isMinimal {L} (hL : IsMinimalLeftCarrier L) : Module.finrank ℝ L = 4
theorem leftCarrier_trichotomy {L} (hL : IsLeftCarrier L) :
    L = ⊥ ∨ L = ⊤ ∨ (IsMinimalLeftCarrier L ∧ Module.finrank ℝ L = 4)
theorem exists_proper_nonzero_leftCarrier :
    ∃ L : Submodule ℝ W, IsNonzeroLeftCarrier L ∧ L ≠ ⊤
```

**Answers §9 and §38.1 affirmatively: PROPER CARRIER exist.**
**Exact minimal nonzero dimension: 4** (**MINIMAL CARRIER**).

The trichotomy is the sharpest form: *every* left carrier is `⊥`, all of `W`, or minimal
of dimension four.  In particular there is no chain of proper carriers, and
`proper_contains_minimal` holds trivially — every proper nonzero left carrier **is** a
minimal one.

Key step (`proper_eq_Lgen`): a proper carrier contains no invertible element, so all of
its elements are null, and any nonzero element `ψ` of it generates a four-dimensional
carrier inside a carrier of dimension `≤ 4`; hence `L = Lgen ψ`.

---

## 10. Minimal-generator classification (§14, §15, §16)

```lean
theorem isMinimal_Lgen_iff (ψ : W) :
    IsMinimalLeftCarrier (Lgen ψ) ↔ (ψ ≠ 0 ∧ IsNullElt ψ)

theorem isMinimal_Lgen_iff_branches (ψ : W) :
    IsMinimalLeftCarrier (Lgen ψ) ↔ ((ψ ≠ 0 ∧ Ncand 1 ψ = 0) ∧ (ψ ≠ 0 ∧ Ncand (-1) ψ = 0))

theorem isNullElt_iff_exists_kernel {ψ : W} (hψ : ψ ≠ 0) :
    IsNullElt ψ ↔ ∃ φ : W, φ ≠ 0 ∧ ψ ⋆ φ = 0
theorem isNullElt_iff_exists_right_kernel {ψ : W} (hψ : ψ ≠ 0) :
    IsNullElt ψ ↔ ∃ φ : W, φ ≠ 0 ∧ φ ⋆ ψ = 0
```

**DERIVED, AXIS-INDEPENDENT, BRANCH-SYMMETRIC.**  A nonzero `ψ` generates a minimal
carrier exactly when the inherited central quadratic datum vanishes on it; equivalently
when *both* Task-09 branches vanish (they vanish together, `null_branch_symmetric`, so
§15 is respected: neither `N₊` nor `N₋` is preferred, and both formulations are recorded);
equivalently — this is the answer to §16 — exactly when `ψ` is a **zero divisor**, i.e.
left multiplication by `ψ` has nontrivial kernel (and, symmetrically, right multiplication
does).  No determinant, rank or matrix language is used.

**Normal form of a generator (§10, §11).**  Idempotency is not assumed; it is derived
exactly as far as needed:

```lean
theorem exists_selfProduct_generator {ψ : W} (hψ : ψ ≠ 0) (hnull : IsNullElt ψ) :
    ∃ e : W, IsSelfProduct e ∧ e ≠ 0 ∧ IsNullElt e ∧ e 0 = 1/2 ∧ e 7 = 0 ∧ Lgen ψ = Lgen e
theorem selfProduct_dichotomy {e : W} (h : IsSelfProduct e) : IsNullElt e ∨ e = w1
theorem selfProduct_coords {e : W} (hidem : IsSelfProduct e) (hne : e ≠ 0) … :
    e 0 = 1/2 ∧ e 7 = 0
```

So the classification of self-product elements is carried out only in the narrow form
required: a nonzero self-product is either the unit or null, and in the null case its
`1`- and `S`-coordinates are forced to `1/2` and `0`.  No broader classification of
polynomial equations in `W` is attempted (§11).

---

## 11. Complete minimal-carrier classification (§17)

```lean
theorem isMinimal_eq_Lgen_selfProduct {L} (hL : IsMinimalLeftCarrier L) :
    ∃ e : W, IsSelfProduct e ∧ e ≠ 0 ∧ IsNullElt e ∧ e 0 = 1/2 ∧ e 7 = 0 ∧ L = Lgen e

noncomputable def emin (u : ℝ) : W :=
  ![1/2, 0, (1 - u^2) / (2*(1 + u^2)), u / (1 + u^2), 0, 0, 0, 0]
theorem isMinimal_Lgen_emin (u : ℝ) : IsMinimalLeftCarrier (Lgen (emin u))
theorem Lgen_emin_injective : Function.Injective (fun u : ℝ => Lgen (emin u))
theorem minimal_carriers_infinite : {L | IsMinimalLeftCarrier L}.Infinite
theorem minimal_carrier_not_unique :
    ∃ L L', IsMinimalLeftCarrier L ∧ IsMinimalLeftCarrier L' ∧ L ≠ L'
theorem proper_contains_minimal {L} (hL : IsProperLeftCarrier L) :
    ∃ M, IsMinimalLeftCarrier M ∧ M ≤ L
```

Answers to the five questions of §17:

| question | answer |
|---|---|
| do minimal carriers exist? | **yes** |
| exact real dimension | **4**, for every one of them |
| all the same dimension? | **yes** |
| one carrier or a family? | **FAMILY**, an infinite one |
| does every proper nonzero carrier contain a minimal one? | **yes** (indeed equals one) |

Every minimal carrier is `Lgen e` for a derived null self-product generator `e`, and
conversely.  The explicit injective real one-parameter family `emin u` — built from the
global algebra only, with no distinguished direction — shows the family is infinite.

---

## 12. Equality versus equivalence; the equivalence result (§18, §19)

Equality is distinguished from equivalence explicitly.  `Lgen_emin_injective` and
`Lgen_esph_inj` prove *literal inequality* of subspaces for distinct parameters.  The
neutral intrinsic equivalence, generated by invertible right transformations only:

```lean
def CarrierEquiv (L L' : Submodule ℝ W) : Prop :=
  ∃ r : W, (∀ ψ ∈ L, ψ ⋆ r ∈ L') ∧ (∀ ψ ∈ L, ∀ φ ∈ L, ψ ⋆ r = φ ⋆ r → ψ = φ)
    ∧ (∀ φ ∈ L', ∃ ψ ∈ L, ψ ⋆ r = φ)

theorem carrierEquiv_intertwines (r x ψ : W) : (x ⋆ ψ) ⋆ r = x ⋆ (ψ ⋆ r)
theorem minimal_carriers_equivalent {L L'} (hL : IsMinimalLeftCarrier L)
    (hL' : IsMinimalLeftCarrier L') : CarrierEquiv L L'
theorem carrierEquiv_refl, carrierEquiv_symm, carrierEquiv_trans
theorem carrier_family_verdict :
    {L | IsMinimalLeftCarrier L}.Infinite ∧
    (∀ L ∈ …, Module.finrank ℝ L = 4) ∧
    (∀ L ∈ …, ∀ L' ∈ …, CarrierEquiv L L')
```

No conventional representation equivalence is imported: the relation is defined by a
single algebra element acting on the right, and it automatically intertwines the left
action, which is exactly associativity (`carrierEquiv_intertwines`).

**§20 VERDICT: `FAMILY OF EQUIVALENT CARRIERS`.**  The inherited data
(`W`-multiplication, unit, center `Z`, distinguished axis `A`, the automorphism family
`Φθ`, the Task-09 quadratic structure) does **not** select a unique minimal left carrier:
distinct minimal carriers exist, they are pairwise equivalent, the whole family is
permuted by `Φθ`, and the axis at best distinguishes **two** of them (§13 below), never
one.  Consequently the answer to §38.18 is: **yes, an additional state-selection datum
would still be required** (`task12_selection_datum_still_required`), and Task 12 does not
supply one.  There is exactly **one** equivalence class of minimal carriers.

---

## 13. Axis-dependence audit (§28, §29) — Conservation of Difficulty

```lean
theorem axis_independent_core :
    (∃ L, IsNonzeroLeftCarrier L ∧ L ≠ ⊤) ∧
    (∀ L, IsMinimalLeftCarrier L → Module.finrank ℝ L = 4) ∧
    (∀ ψ, IsMinimalLeftCarrier (Lgen ψ) ↔ (ψ ≠ 0 ∧ IsNullElt ψ)) ∧
    {L | IsMinimalLeftCarrier L}.Infinite

theorem axis_dependent_selection :
    esph 1 0 0 = (2⁻¹ : ℝ) • (w1 + wA) ∧ esph (-1) 0 0 = (2⁻¹ : ℝ) • (w1 - wA) ∧
    (∀ θ, Submodule.map (Phi θ) (Lgen (esph 1 0 0)) = Lgen (esph 1 0 0)) ∧
    (∀ θ, Submodule.map (Phi θ) (Lgen (esph (-1) 0 0)) = Lgen (esph (-1) 0 0))
```

| result | verdict |
|---|---|
| existence of proper nonzero left carriers | **AXIS-INDEPENDENT** |
| the dimension set `{4,8}` of generated carriers | **AXIS-INDEPENDENT** |
| minimal dimension `4` | **AXIS-INDEPENDENT** |
| minimal-generator criterion (nullity / zero divisor) | **AXIS-INDEPENDENT** |
| infinitude and pairwise equivalence of the family | **AXIS-INDEPENDENT** |
| central action, `Z`-rank, endomorphism algebra | **AXIS-INDEPENDENT** |
| the two `Φ`-fixed carriers `Lgen((1 ± A)/2)` | **AXIS-DEPENDENT** |
| the half-angle sectors `H±` and everything about them | **AXIS-DEPENDENT** |

The axis contributes **no** existence, dimension or minimality statement.  It contributes
only a *selection* of two distinguished members inside an already classified family, plus
the sector decomposition.  Carrier structure existing already in `W` is thereby cleanly
separated from decomposition visible only after `A` is chosen.  No second axis is
introduced.

The explicit two-parameter generator family used for the axis analysis is

```lean
noncomputable def esph (n₁ n₂ n₃ : ℝ) : W := ![1/2, n₁/2, n₂/2, n₃/2, 0, 0, 0, 0]
theorem esph_selfProduct  (h : n₁^2 + n₂^2 + n₃^2 = 1) : IsSelfProduct (esph n₁ n₂ n₃)
theorem esph_isNullElt    (h : n₁^2 + n₂^2 + n₃^2 = 1) : IsNullElt (esph n₁ n₂ n₃)
theorem Lgen_esph_inj     -- distinct unit triples give distinct carriers
theorem Phi_esph (θ n₁ n₂ n₃ : ℝ) :
    Phi θ (esph n₁ n₂ n₃) = esph n₁ (n₂ * cos θ - n₃ * sin θ) (n₂ * sin θ + n₃ * cos θ)
```

---

## 14. Relation to the Task-10 half-angle sectors `H₊`, `H₋`

### 14.1 Are the sectors left carriers? (§22 — mandatory distinction)

```lean
theorem not_isLeftCarrier_SectorPlus  : ¬ IsLeftCarrier SectorPlus
theorem not_isLeftCarrier_SectorMinus : ¬ IsLeftCarrier SectorMinus
theorem mul_right_mem_SectorPlus  {ψ} (hψ : ψ ∈ SectorPlus)  (x : W) : ψ ⋆ x ∈ SectorPlus
theorem mul_right_mem_SectorMinus {ψ} (hψ : ψ ∈ SectorMinus) (x : W) : ψ ⋆ x ∈ SectorMinus
theorem Uref_mul_mem_SectorPlus  {ψ} (hψ : ψ ∈ SectorPlus)  (θ : ℝ) : Uref θ ⋆ ψ ∈ SectorPlus
theorem sector_versus_carrier_stability
```

**NO.**  Neither sector is left-stable under the whole algebra: `wB ⋆ e₊ ∉ H₊`.
The sectors are **right ideals**, not left carriers.  They *are* preserved by left
multiplication by the axial lift `Uref θ` for every `θ`.  This is exactly the mandatory
distinction of §22: *stability under the axial lift is strictly weaker than stability
under the whole algebra*, and the two are never conflated in this development.

The sector projectors are the intrinsic pair
`eplus = esph 1 0 0 = (1 + A)/2`, `eminus = esph (-1) 0 0 = (1 - A)/2` with
`eplus + eminus = w1`, `H± = range (Lmul e±)`, `ψ ∈ H± ↔ e± ⋆ ψ = ψ`.

### 14.2 The exact structure the sectors do preserve, and reducibility (§23)

```lean
def StabL (L : Submodule ℝ W) : Submodule ℝ W  -- {x | ∀ ψ ∈ L, x ⋆ ψ ∈ L}
theorem StabL_SectorPlus_eq_ker : StabL SectorPlus = LinearMap.ker crossPM
theorem finrank_StabL_SectorPlus : Module.finrank ℝ (StabL SectorPlus) = 6
theorem StabL_SectorPlus_algebra :
    w1 ∈ StabL SectorPlus ∧ wS ∈ StabL SectorPlus ∧ wA ∈ StabL SectorPlus ∧
    wB ∉ StabL SectorPlus ∧ ∀ x ∈ …, ∀ y ∈ …, x ⋆ y ∈ StabL SectorPlus
theorem SectorPlus_reducible :
    Zspan eplus ≤ SectorPlus ∧ Zspan eplus ≠ ⊥ ∧ Zspan eplus ≠ SectorPlus ∧
      ∀ x ∈ StabL SectorPlus, ∀ ψ ∈ Zspan eplus, x ⋆ ψ ∈ Zspan eplus
```

The weakest inherited structure the plus sector actually preserves is its exact left
stabilizer, a **six-dimensional subalgebra** of `W` (the kernel of the compression
`x ↦ e₋ ⋆ x ⋆ e₊`), containing `1`, `S` and `A` but not `B`.  Under it the sector is
**REDUCIBLE**: the two-dimensional plane `Z ⋆ e₊ = spanℝ{e₊, S ⋆ e₊}` is a proper nonzero
invariant subspace.  So the Task-10 fact `dimℝ H± = 4` must indeed not be read as
irreducibility (§5).  The sectors are not forced into the left-carrier classification.

### 14.3 Intersections with minimal carriers (§21)

```lean
theorem minimal_inf_sectors {L} (hL : IsMinimalLeftCarrier L) :
    Module.finrank ℝ (L ⊓ SectorPlus)  = 2 ∧
    Module.finrank ℝ (L ⊓ SectorMinus) = 2 ∧
    (L ⊓ SectorPlus) ⊔ (L ⊓ SectorMinus) = L ∧
    (L ⊓ SectorPlus) ⊓ (L ⊓ SectorMinus) = ⊥
```

**Every** minimal left carrier meets **each** sector in exactly two real dimensions, and
is the internal direct sum of the two intersections.  No minimal carrier lies wholly
inside either sector — the possibility explicitly warned against in §21 does not occur.
The proof uses the idempotent compressions `x ↦ s ⋆ x ⋆ e` with `s ∈ {e₊, e₋}`, whose
ranges are exactly the intersections and whose traces are `8 · s₀ · e₀ = 2`.

---

## 15. Reference-lift stability (§24)

```lean
theorem Uref_mul_mem {L} (hL : IsLeftCarrier L) (θ : ℝ) {ψ} (hψ : ψ ∈ L) : Uref θ ⋆ ψ ∈ L
theorem lift_stability_report.1 :
    ∀ L, IsMinimalLeftCarrier L → ∀ θ, Submodule.map (Lmul (Uref θ)) L = L
```

**LEFT-STABLE — every** minimal left carrier is preserved by the Task-10 reference lift,
for every `θ`, and the map is onto, not merely into.  There is nothing to classify: no
minimal carrier fails, because `Uref θ ∈ W` and left stability under all of `W` is the
defining property.  Surjectivity uses invertibility of `Uref θ` inside `W`
(`IsFullLift.group`).

---

## 16. Full-lift stability (§25)

```lean
theorem map_Lmul_fullLift {U} (hU : IsFullLift U) {L} (hL : IsLeftCarrier L) (θ : ℝ) :
    Submodule.map (Lmul (U θ)) L = L
theorem fullLift_stability_residual_free {U U'} (hU : IsFullLift U) (hU' : IsFullLift U') …
theorem lift_stability_report.2.1 :
    ∀ U, IsFullLift U → ∀ L, IsMinimalLeftCarrier L → ∀ θ, Submodule.map (Lmul (U θ)) L = L
```

**LEFT-STABLE, uniformly.**  The same holds for the *entire* Task-11 continuous family
`Uαβ(θ)`, with the derived simplification anticipated in §25: since every full lift
differs from the reference lift by an invertible **central** factor, and since a left
carrier is stable under *all* of `W`, the residual freedom is completely invisible at the
carrier level.  All minimal carriers have identical stability properties; this is derived,
not assumed.

---

## 17. Action of `Φ` on the carrier family (§26, §27)

The two actions are kept separate throughout.

```lean
theorem map_Phi_eq_map_Rmul {U} (hU : IsFullLift U) {L} (hL : IsLeftCarrier L) (θ : ℝ) :
    Submodule.map (Phi θ) L = Submodule.map (Rmul (U (-θ))) L
theorem Phi_map_Lgen (θ : ℝ) (ψ : W) :
    Submodule.map (Phi θ) (Lgen ψ) = Lgen (Phi θ ψ)
theorem isMinimal_map_Phi {L} (hL : IsMinimalLeftCarrier L) (θ : ℝ) :
    IsMinimalLeftCarrier (Submodule.map (Phi θ) L)
theorem Phi_carrier_family_action :
    (∀ θ L, IsMinimalLeftCarrier L → IsMinimalLeftCarrier (Submodule.map (Phi θ) L)) ∧
    (∀ θ, Submodule.map (Phi θ) (Lgen (esph 1 0 0)) = Lgen (esph 1 0 0)) ∧
    (∀ θ, Submodule.map (Phi θ) (Lgen (esph (-1) 0 0)) = Lgen (esph (-1) 0 0)) ∧
    Submodule.map (Phi (π/2)) (Lgen (esph 0 1 0)) ≠ Lgen (esph 0 1 0)
```

1. **Automorphism action.**  `Φθ` maps minimal carriers to minimal carriers, so it acts on
   the family.  It **fixes** the two axial carriers `Lgen((1 ± A)/2)` for every `θ`, and it
   **moves** others: the equatorial generator `esph 0 1 0` is carried to a literally
   different subspace at `θ = π/2`.  So the family decomposes into fixed points and
   nontrivial orbits; the orbits are the `Φ`-rotations of the generator triple
   `(n₁, n₂, n₃)` in the `(n₂, n₃)` plane (`Phi_esph`), with the two poles fixed.
2. **Left action.**  Left multiplication by `Uθ` preserves **every** left carrier (§15,
   §16).  This is a different statement and is proved separately.
3. **Relation.**  On a left carrier the automorphism image coincides with *right*
   multiplication by the inverse lift, `Φθ(L) = L ⋆ U(−θ)` — which is precisely why one
   action can move a carrier while the other cannot.  The two are never conflated.

---

## 18. Central-plane action (§30, §31)

```lean
theorem central_mul_mem {L} (hL : IsLeftCarrier L) {z} (_hz : z ∈ Z) {ψ} (hψ : ψ ∈ L) :
    z ⋆ ψ ∈ L
noncomputable def Sop {L} (hL : IsLeftCarrier L) : L →ₗ[ℝ] L   -- ψ ↦ S ⋆ ψ
theorem Sop_sq {L} (hL : IsLeftCarrier L) (ψ : L) : Sop hL (Sop hL ψ) = -ψ
theorem Zrank_two {L} (hL : IsMinimalLeftCarrier L) :
    ∃ ψ₁ ψ₂ ∈ L, (spanning by central coefficients) ∧ (independence)
theorem central_action_report
```

**CENTRAL ACTION, automatic.**  `S ⋆ L ⊆ L` holds for *every* left carrier with no extra
hypothesis whatsoever — it is a special case of left stability, since `S ∈ W`.  The
induced real-linear operator `Sop : L → L` satisfies `Sop ∘ Sop = -id`.  It is **not**
called multiplication by `i`; that identification appears only in §21.

**Z-rank (formally defined by the statement, not imported).**  For a minimal carrier there
exist `ψ₁, ψ₂ ∈ L` such that every `ψ ∈ L` is uniquely
`(a·1 + b·S) ⋆ ψ₁ + (c·1 + d·S) ⋆ ψ₂`, with the four real coefficients determined.  So the
carrier has **real dimension 4** and contains exactly **two independent `Z`-directions**:
`Z`-rank **2**.  No complex vector-space dimension is imported.

---

## 19. Internal endomorphism classification (§32, §33)

```lean
noncomputable def lact (hL : IsLeftCarrier L) (x : W) : L →ₗ[ℝ] L
def IsInternalEndo (hL : IsLeftCarrier L) (T : L →ₗ[ℝ] L) : Prop :=
  ∀ (x : W) (ψ : L), T (lact hL x ψ) = lact hL x (T ψ)

theorem isInternalEndo_central (hL) {z} (hz : z ∈ Z) : IsInternalEndo hL (lact hL z)
theorem internalEndo_eq_central {e} (he : IsSelfProduct e) (hne : e ≠ 0)
    (h0 : e 0 = 1/2) (h7 : e 7 = 0) {T} (hT : IsInternalEndo (isLeftCarrier_Lgen e) T) :
    ∃ z ∈ Z, ∀ ψ : Lgen e, (T ψ : W) = z ⋆ (ψ : W)
theorem endoOfZ_comp : (endoOfZ hL z).comp (endoOfZ hL z') = lact hL (z ⋆ z')
theorem range_endoOfZ_eq_EndoSpace : LinearMap.range (endoOfZ …) = EndoSpace …
theorem endoOfZ_injective
theorem finrank_EndoSpace : Module.finrank ℝ (EndoSpace (isLeftCarrier_Lgen e)) = 2
theorem carrier_endomorphism_classification
```

**INTERNAL ENDOMORPHISM — exact result.**  For a minimal left carrier `L = Lgen e`, the
real-linear self-maps commuting with the left action of the *whole* algebra are **exactly**
the left multiplications by elements of the inherited central plane `Z`.  The
correspondence `Z → End(L)` is linear, injective and multiplicative
(`endoOfZ_comp`: composition ↔ product in `Z`), hence an isomorphism of real algebras onto
the endomorphism algebra, whose real dimension is therefore exactly **2**.

The result is *derived*, not assumed to be `ℝ`, `Z` or `ℂ`: the proof evaluates `T` at the
generator `e`, shows `T e = z ⋆ e` for a unique `z` forced to lie in `Z` by commutation
with all of `W`, and extends by `ψ ⋆ e = ψ` on `Lgen e`.  It is stated only after
minimality is established, and is not called a commutant or Schur statement in the core.

Structural reading, without physical content: the scalar freedom of a minimal carrier is
exactly two-dimensional and is the *inherited* center, not a new datum.

---

## 20. Conservation-of-Difficulty graph and the eighteen §38 answers

```text
global algebra W  (Task 08 product, unit, associativity)         INHERITED
        ↓
Z = span{1,S}, center; nRe, nSc, Ncand                            INHERITED (09)
        ↓
Lmul / Rmul, trace, wconj, IsNullElt, HasInverse                  DERIVED (SafeBase)
        ↓
IsLeftCarrier / nonzero / proper / minimal                        DERIVED (LeftCarrier)
        ↓
Lψ := Lgen ψ = range (Rmul ψ), left-stable                        DERIVED (GeneratedCarrier)
        ↓
dimension classification  {4, 8}                                  DERIVED
        ↓
minimality ⇔ properness; minimal dimension 4; trichotomy          DERIVED
        ↓
minimal generator ⇔ nonzero null ⇔ zero divisor                   DERIVED
        ↓
infinite family; pairwise CarrierEquiv; one equivalence class     DERIVED
        ↓
uniqueness test → FAMILY OF EQUIVALENT CARRIERS                   DERIVED
        ↓   (only here is the axis used)
Φθ action on the family: two fixed poles, other carriers move     AXIS-DEPENDENT
        ↓
comparison with H₊, H₋: not left carriers, reducible,
    every minimal carrier meets each in dimension 2               AXIS-DEPENDENT
        ↓
reference-lift and full-lift stability (trivial, residual-free)   DERIVED
        ↓
central action: automatic, Sop² = -id, Z-rank 2                   DERIVED
        ↓
internal endomorphism algebra ≅ Z, real dimension 2               DERIVED
        ↓
late conventional identification                                  COMPARISON ONLY
```

The source order of §39 is respected mechanically by the import chain of §2: the
half-angle sectors are first imported in `HalfAngleRelation.lean`, *after* the complete
dimension, minimality, family and equivalence classification; the Task-11 lift is first
imported in `LiftStability.lean`; the conventional identification is first imported in
`Identification.lean`.

| §38 question | answer |
|---|---|
| 1. Do proper nonzero left-stable carriers exist? | **Yes** (`task12_proper_carriers_exist`) |
| 2. What dimensions can generated carriers have? | exactly **{4, 8}** |
| 3. Exact minimal nonzero dimension? | **4** |
| 4. How are minimal generators characterized? | nonzero with vanishing central quadratic datum (both branches) ⇔ zero divisor |
| 5. How many minimal left carriers exist? | infinitely many (**FAMILY**) |
| 6. Are all minimal carriers structurally equivalent? | **yes**, one equivalence class under `CarrierEquiv` |
| 7. Does the algebra select a unique one? | **no** — `FAMILY OF EQUIVALENT CARRIERS` |
| 8. Are `H±` left carriers? | **no**; they are right ideals, preserved by the axial lift only |
| 9. Are they reducible? | **REDUCIBLE** under their exact 6-dimensional left stabilizer |
| 10. Intersections with minimal carriers? | dimension **2** with each, direct sum |
| 11. Stable under `Uref`? | **yes**, all of them |
| 12. Stable under every full lift? | **yes**, all of them; residual central factor invisible |
| 13. Action of `Φθ` on the family? | permutation; two axial carriers fixed; others move |
| 14. Which results require `A`? | only the `Φ`-fixed pair and everything about `H±` |
| 15. Which properties exist before `A`? | existence, dimensions, minimality, family, equivalence, centre, endomorphisms |
| 16. How does `Z` act on a minimal carrier? | automatically; `Sop² = -id`; `Z`-rank 2 |
| 17. Exact internal endomorphism algebra? | isomorphic to `Z`, real dimension **2** |
| 18. Additional state-selection datum required? | **yes** — none is available, and Task 12 supplies none |

---

## 21. Late conventional comparison (§44) — **COMPARISON ONLY**

`RequestProject/NullSectorTask12/Identification.lean`, imported only by `Task12.lean`.
All statements below are labelled COMPARISON ONLY and establish exact correspondences, not
analogies, through the Task-08 comparison isomorphism `toMat : W → M₂(ℂ)`.

```lean
theorem comparison_Lgen_eq_left_ideal (e y : W) :
    y ∈ Lgen e ↔ ∃ X : Matrix (Fin 2) (Fin 2) ℂ, X * toMat e = toMat y
theorem comparison_generator_idempotent {e} (he : IsSelfProduct e) (hne : e ≠ 0)
    (hnull : IsNullElt e) : toMat e * toMat e = toMat e ∧ toMat e ≠ 0 ∧ toMat e ≠ 1
theorem comparison_minimal_dimension {L} (hL : IsMinimalLeftCarrier L) :
    Module.finrank ℝ L = 4
theorem comparison_internalEndo_is_complex_scalar … :
    ∃ c : ℂ, ∀ ψ : Lgen e, toMat (T ψ : W) = c • toMat (ψ : W)
theorem comparison_endomorphism_algebra … :
    Module.finrank ℝ (EndoSpace (isLeftCarrier_Lgen e)) = 2
theorem comparison_summary
```

| intrinsic Task-12 object | conventional object (COMPARISON ONLY) |
|---|---|
| `Lgen e` for a null self-product `e` | the minimal left ideal `M₂(ℂ) · P` of a `2×2` complex matrix algebra |
| derived generator `e` (null, `e ⋆ e = e`) | an idempotent matrix `≠ 0, 1`, i.e. a rank-one idempotent |
| real dimension 4 | two complex dimensions of a column-type module |
| the operator `Sop` with `Sop² = -id` | multiplication by the complex unit |
| internal endomorphism algebra `≅ Z`, real dimension 2 | the complex scalars |
| the family of minimal carriers, one equivalence class | the family of minimal left ideals, all isomorphic |

**§45.  NO SPIN CLAIM.**  Even though the conventional counterpart of a minimal left
carrier is the usual carrier of a spinorial representation, Task 12 does **not** conclude
that a fermion, physical spin-1/2, or any particle has been derived.  Nothing beyond the
algebraic correspondence above is claimed.  **NOT PHYSICAL STATE SPACE.**

---

## 22. Build report

```text
$ lake build RequestProject.NullSectorTask12.Task12
ℹ [8102/8102] Built RequestProject.NullSectorTask12.Task12 (44s)
Build completed successfully (8102 jobs).

$ lake build            # whole cumulative project, all tasks
Build completed successfully (8146 jobs).
```

No errors.  The only warnings emitted anywhere in the Task-08…12 chain are four
`unusedSimpArgs` linter hints in `NullSectorTask11/Identification.lean`, which predate
Task 12.

Mechanical scan of all thirteen Task-12 modules:

```text
$ rg -n "sorry|admit|^axiom" RequestProject/NullSectorTask12
→ no occurrence (the single textual match is the English word "admits" in a comment)
```

Per-module build (each module is a `lake build` target of the form
`RequestProject.NullSectorTask12.<Module>`).

---

## 23. Axiom report (§43)

`#print axioms` is executed inside `Task12.lean` for all sixteen principal theorems.
Recorded output:

```text
'NullSectorTask12.task12_proper_carriers_exist'            [propext, Classical.choice, Quot.sound]
'NullSectorTask12.task12_possible_carrier_dimensions'      [propext, Classical.choice, Quot.sound]
'NullSectorTask12.task12_minimal_dimension'                [propext, Classical.choice, Quot.sound]
'NullSectorTask12.task12_minimal_generator_criterion'      [propext, Classical.choice, Quot.sound]
'NullSectorTask12.task12_carrier_family'                   [propext, Classical.choice, Quot.sound]
'NullSectorTask12.task12_no_unique_carrier'                [propext, Classical.choice, Quot.sound]
'NullSectorTask12.task12_leftCarrier_trichotomy'           [propext, Classical.choice, Quot.sound]
'NullSectorTask12.task12_half_angle_sectors'               [propext, Classical.choice, Quot.sound]
'NullSectorTask12.task12_carrier_meets_sectors'            [propext, Classical.choice, Quot.sound]
'NullSectorTask12.task12_lift_stability'                   [propext, Classical.choice, Quot.sound]
'NullSectorTask12.task12_automorphism_versus_left_action'  [propext, Classical.choice, Quot.sound]
'NullSectorTask12.task12_axis_audit'                       [propext, Classical.choice, Quot.sound]
'NullSectorTask12.task12_central_action'                   [propext, Classical.choice, Quot.sound]
'NullSectorTask12.task12_carrier_endomorphisms'            [propext, Classical.choice, Quot.sound]
'NullSectorTask12.task12_selection_datum_still_required'   [propext, Classical.choice, Quot.sound]
'NullSectorTask12.task12_identification'                   [propext, Classical.choice, Quot.sound]
```

Mapping to the nine §43 headings:

| §43 heading | theorem |
|---|---|
| possible carrier dimensions | `task12_possible_carrier_dimensions` |
| minimal dimension | `task12_minimal_dimension` |
| minimal generator criterion | `task12_minimal_generator_criterion` |
| minimal carrier classification | `task12_carrier_family`, `task12_leftCarrier_trichotomy` |
| carrier equivalence theorem | `task12_carrier_family` (third conjunct), `task12_no_unique_carrier` |
| half-angle relation | `task12_half_angle_sectors`, `task12_carrier_meets_sectors` |
| full-lift stability | `task12_lift_stability` |
| central action | `task12_central_action` |
| carrier endomorphism classification | `task12_carrier_endomorphisms` |

Only the three standard Lean/Mathlib axioms occur.  No custom axiom, no `sorry`, no
`admit`, no `@[implemented_by]`.

**Source ledger.**  Every mathematical input is either (i) an inherited Task-08…11
declaration listed in §2, or (ii) standard finite-dimensional real linear algebra from
Mathlib: `Submodule`, `LinearMap.range`/`ker`/`comp`, `Module.finrank`,
`LinearMap.trace`, `LinearMap.finrank_range_of_inj`, `Submodule.map`, `LinearIndependent`,
`Set.Infinite`, and the real/complex arithmetic tactics `ring`, `linarith`, `nlinarith`,
`norm_num`, `field_simp`, `fin_cases`, `simp`.  No matrix rank, no conventional spinor
module, no pre-built simple-module classification is used in the reconstruction core;
coordinate proofs use the independently reconstructed Task-08 basis, as permitted.

---

## 24. Unresolved mathematical obligations

Stated honestly; none of these is required by the §46 acceptance criteria, and none is
silently assumed anywhere.

1. **No global parametrization of the family of all minimal carriers is proved.**  It is
   proved that the family is infinite, that every member is `Lgen e` for a derived null
   self-product generator, and that two explicit families (`emin u`, `esph n₁ n₂ n₃` with
   `n₁² + n₂² + n₃² = 1`) inject into it.  It is **not** proved that these exhaust the
   family, nor is the family exhibited as a manifold or homogeneous space.
2. **The exact set of `Φθ`-fixed minimal carriers is not classified.**  It is proved that
   the two axial carriers `Lgen((1 ± A)/2)` are fixed for every `θ`, and that at least one
   equatorial carrier is moved.  A complete determination of the fixed locus (expected to
   be exactly the two poles, for `θ` not a multiple of `2π`) is left open.
3. **The generator of a given minimal carrier is not shown to be unique.**  Uniqueness of
   the *central* multiplier is proved (`central_unique_on_Lgen`), which suffices for the
   endomorphism theorem, but the set of all generators of a fixed minimal carrier is not
   classified.
4. **`CarrierEquiv` is proved reflexive, symmetric on minimal carriers, and transitive,
   and all minimal carriers are proved equivalent; it is not proved to be an equivalence
   relation on arbitrary subspaces.**  The symmetry lemma carries a minimality hypothesis.
5. **The exact left stabilizer is computed for `H₊` only.**  By the evident symmetry the
   same six-dimensional result holds for `H₋`, but only `¬ IsLeftCarrier SectorMinus`,
   right-ideal stability and lift stability are proved for the minus sector; the
   corresponding stabilizer dimension and reducibility statement are not formalized.
6. **No selection datum is offered.**  The §20 verdict is `FAMILY OF EQUIVALENT CARRIERS`;
   whether any *further* inherited structure could select one carrier is answered
   negatively only for the data listed in §20 of the task statement, which are the only
   data available.
7. **NOT PHYSICAL STATE SPACE.**  The relation between a minimal algebraic left carrier
   and any physical state space is entirely outside Task 12 and remains open by design.
