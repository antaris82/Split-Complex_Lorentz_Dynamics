# TASK13_AUDIT.md

Split-Complex Lorentz Dynamics — Experiment 2, Task 13

**Universal axial action on an arbitrary minimal carrier: sector restriction, central
residual freedom, carrier equivalence, and selection audit.**

Status labels used throughout: `INHERITED`, `DERIVED`, `AXIS-RELATIVE`,
`CARRIER-INDEPENDENT`, `CARRIER-DEPENDENT`, `CENTRAL`, `COMMON FACTOR`, `RELATIVE FACTOR`,
`REFERENCE LIFT`, `FULL LIFT`, `INTERTWINED`, `FIXED CARRIER`, `MOVED CARRIER`,
`SELECTION FREEDOM`, `NO NORMALIZATION DERIVED`, `ADDITIONAL COMPATIBILITY`,
`COMPARISON ONLY`, `NOT PHYSICAL SPIN`, `UNRESOLVED`.

---

## 1. Exact toolchain

| Item | Value |
| --- | --- |
| Lean toolchain | `leanprover/lean4:v4.28.0` (file `lean-toolchain`) |
| Build target | `RequestProject` library (`lakefile.toml`), module `RequestProject.NullSectorTask13.Task13` |

## 2. Exact Mathlib revision

| Item | Value |
| --- | --- |
| Mathlib | `v4.28.0`, commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (file `lake-manifest.json`) |

Mathlib declarations actually used in Task 13 are elementary: `Submodule`,
`Submodule.map`, `Module.finrank`, `Submodule.eq_of_le_of_finrank_eq`,
`finrank_span_eq_card`, `LinearMap.ker`, `LinearMap.range`,
`LinearMap.finrank_range_add_finrank_ker`, `Fintype.linearIndependent_iff`,
`Real.sin_sq_add_cos_sq`, `Real.cos_two_mul'`, `Real.sin_two_mul`, `Real.cos_add`,
`Real.sin_add`, `Real.cos_pi`, `Real.cos_pi_div_two`, `Real.sin_pi_div_two`,
`Real.cos_two_pi`, `Real.sin_two_pi`, `Real.exp_zero`, `sq_eq_zero_iff`,
`mul_self_eq_one_iff`, and the tactics `ring`, `linarith`, `nlinarith`,
`linear_combination`, `field_simp`, `positivity`, `module`, `fin_cases`, `norm_num`.

## 3. Source-order graph (module chain)

```
Task12.HalfAngleRelation, Task12.CentralAction, Task12.CarrierEndomorphisms   (INHERITED)
        ↓
Task13.SafeBase
        ↓
Task13.MinusSectorHardening          (§1: H₋ hardening — closes the Task-12 obligation)
        ↓
Task13.CarrierSlices                 (§7, §8: arbitrary minimal L, K₊(L), K₋(L))
        ↓
Task13.SliceCentralStructure         (§9, §10, §41: Z-stability, central rank, generators)
        ↓
Task13.ReferenceRestriction          (§12, §13: first import of Uref)
        ↓
Task13.ReferenceSectorAction         (§14–§18, §41)
        ↓
Task13.FullLiftRestriction           (§19–§21, §40)
        ↓
Task13.RelativeSectorAction          (§22, §23, §28)
        ↓
Task13.InfinitesimalRestriction      (§24, §25, §26)
        ↓
Task13.CarrierIntertwiners           (§29–§33)
        ↓
Task13.AutomorphismCarrierAction     (§34)
        ↓
Task13.FixedCarrierLocus             (§35, §36)
        ↓
Task13.SelectionAudit                (§37, §38, §39, §50, §51)
        ↓
Task13.Identification                (§52, §53 — COMPARISON ONLY)
        ↓
Task13.Task13                        (principal theorems, axiom report)
```

The source-order firewall of §46 is respected: the arbitrary minimal carrier and both
slices are defined (`CarrierSlices`) and their central structure classified
(`SliceCentralStructure`) **before** the reference implementer is imported
(`ReferenceRestriction` is the first Task-13 module reachable from `Uref`), and the full
`(α, β)` family enters only afterwards (`FullLiftRestriction`).  The conventional
identification is imported by `Task13.Task13` only.

## 4. Inherited theorem ledger (INHERITED, used but not reproved)

From Task 08: the carrier `W = Fin 8 → ℝ`, the bilinear product `⋆` with its complete
derived multiplication table, the two-sided unit `w1`, associativity.
From Task 09: the central plane `Z = spanℝ{w1, wS}`, `wS ⋆ wS = -w1`, centrality
(`Z_central`), the branch functions `nRe`, `nSc`, `Ncand`, and multiplicativity
`Ncand_mul`.
From Task 10: the axial automorphism family `Phi` with `Phi 0 = id`,
`Phi (θ+φ) = Phi θ ∘ Phi φ`, `Phi (2π) = id`, bijectivity, and its action on the derived
basis; the sectors `SectorPlus`, `SectorMinus` with `mem_SectorPlus_iff_axis`,
`mem_SectorPlus_iff` (`R ψ = S ψ`), their dimensions `4`; the reference implementer
`Ustd`; `Ustd (2π) = -w1`, `Ustd (4π) = w1`; `ksc_mul_left`; the derivation `Dgen`.
From Task 11: `IsFullLift`, `IsContinuousFullLift`, `IsCentralHom`, the exact lift
classification `fullLift_classification` (`U = z ⋆ Uref`, `z` central), the continuous
classification (`U = zexp α β ⋆ Uref`), `continuousFullLift_parameters_unique`, the
generator `zc α β − (1/2)•wR` with `inducedDer_generator`, the conditional test
`PreservesLeftQuadratic` with `Nplus_compatibility_classification`.
From Task 12: `IsLeftCarrier`, `IsMinimalLeftCarrier`, `Lgen`, `Zspan`, `StabL`,
`isMinimal_eq_Lgen_selfProduct`, `finrank_Lgen_eq_four`, `finrank_of_isMinimal`,
`minimal_inf_sectors` (the `2+2` split), `minimal_carriers_equivalent`, `CarrierEquiv`,
`esph` and its sphere family, `Phi_esph`, `Phi_map_Lgen`, `Lgen_esph_inj`,
`map_Lmul_fullLift`, `map_Phi_eq_map_Rmul`, `central_smul_ne_zero`, `finrank_Zspan`,
`compress_mem_Zspan`, `trace_Lmul_comp_Rmul`, `finrank_range_of_idem`.

## 5. Experiment-1 firewall

No construction, theorem, module, name or numerical formula of Experiment 1 occurs
anywhere in Task 13.  Task 13 imports only Task-08…Task-12 modules of the present
experiment, and (in the comparison layer only) the Task-08/Task-11/Task-12 identification
modules.  A mechanical scan for `Experiment 1` / `Experiment1` in the Task-13 sources
returns only the two firewall statements themselves.

## 6. Conventional-representation firewall

A mechanical scan of the twelve reconstruction modules (`SafeBase` …`SelectionAudit`) for
`spin`, `spinor`, `spin-1/2`, `Weyl`, `Dirac`, `Pauli`, `fermion`, `C²`, `ℂ²`, `SU(2)`,
`Spin(3)`, `double-valued`, `projective`, `minimal spinor module` returns **only** the
firewall declarations in the module docstrings (and the sentence in `CarrierSlices`
stating that the slices are *not* called spin components).  No basis, normalization or
formula was chosen in order to reproduce a familiar object: the two slice factors are
computed from `R ψ = ± S ψ`, and the two-sphere parametrization of the carrier family is
produced by the intrinsic construction `e ↦ e^† ⋆ e` of §35 below.

## 7. Physical-target firewall

None of the words of §4 of the task (particle, electron, photon, mass, momentum, energy,
frequency, helicity, polarization, Hamiltonian, wavefunction, probability, measurement,
unitarity, Hilbert space, Born rule, Dirac/Pauli/Maxwell/Schrödinger equation, field
operator, gauge field) occurs as a construction, an import or a target in the Task-13
reconstruction core; a mechanical scan returns only the firewall statements.  The
parameter `θ` is never called time, proper time or phase-evolution time (§45).

## 8. Full-rotation firewall

Only the single inherited one-parameter axial family about the already selected axis `wA`
occurs.  No `SO(3)`, no rotation group, no `Spin(3)`, no second spatial direction, no
boost, no carrier-level Lorentz action is constructed (mechanical scan: only the firewall
statements).

## 9. `H₋` hardening result (§1)

Module `Task13.MinusSectorHardening`.  Everything is derived, not inferred from a `+ ↔ −`
symmetry; the symmetry is itself *proved* as an inner automorphism statement.

| Obligation | Result | Theorem |
| --- | --- | --- |
| 1. exact real dimension | `dimℝ StabL(H₋) = 6` | `finrank_StabL_Hminus` |
| 2. subalgebra | contains `1, S, A`, not `B`, closed under `⋆` | `StabL_Hminus_algebra` |
| 3. exact coordinate characterization | `x ∈ StabL(H₋) ↔ x₂ + x₄ = 0 ∧ x₃ + x₅ = 0` | `mem_StabL_Hminus_iff_coords` |
| (comparison) | `x ∈ StabL(H₊) ↔ x₂ − x₄ = 0 ∧ x₃ − x₅ = 0` | `mem_StabL_Hplus_iff_coords` |
| 4. relation to `StabL(H₊)` | the inner automorphism `x ↦ B ⋆ x ⋆ B` (which sends `A ↦ −A`) carries one onto the other | `conjB_StabL_iff`, `conjB_maps_StabL`, `conjB_mul`, `conjB_conjB`, `conjB_wA` |
| 5. explicit invariant subspace | `Zspan e₋`, of dimension `2` | `Hminus_reducible` |
| 6. reducibility | `REDUCIBLE`: proper, nonzero, invariant | `Hminus_reducible` |
| kernel form | `StabL(H₋) = ker (x ↦ e₊ ⋆ x ⋆ e₋)` | `StabL_Hminus_eq_ker` |
| basis | `{1, A, B − P, C − Q, R, S}` | `StabL_Hminus_eq_span`, `stabMinusB_indep` |

Summary theorem: `minus_sector_hardening_report`.  Only after this module do the
downstream modules use symmetric plus/minus language.

## 10. Arbitrary-carrier slice definitions (§7, §8)

`L` is arbitrary subject only to `IsMinimalLeftCarrier L`; no idempotent-generated or
axial representative is fixed anywhere in the classification.

```
Kplus  L := L ⊓ Hplus     (Hplus  = SectorPlus  = {ψ | A ⋆ ψ =  ψ})
Kminus L := L ⊓ Hminus    (Hminus = SectorMinus = {ψ | A ⋆ ψ = -ψ})
```

Inherited/reused: `finrank_Kplus`, `finrank_Kminus` (`= 2` each),
`carrier_slice_direct_sum` (`K₊ ⊔ K₋ = L`, `K₊ ⊓ K₋ = ⊥`), the explicit decomposition
`ψ = e₊ ⋆ ψ + e₋ ⋆ ψ` (`slice_decomposition`), non-triviality and properness
(`exists_ne_zero_Kplus`, `exists_ne_zero_Kminus`, `slices_proper`).

## 11. Central-rank classification (§9, §10)

| Statement | Theorem | Label |
| --- | --- | --- |
| both slices are `Z`-stable | `Kplus_central_stable`, `Kminus_central_stable` | `CENTRAL` |
| every nonzero element of a slice generates it over `Z` | `Kplus_eq_Zspan`, `Kminus_eq_Zspan` | central rank `1` |
| the central coefficients are unique | `Kplus_central_representation`, `Kminus_central_representation` | exact |
| generator freedom | nonzero central elements act simply transitively on the generators | `slice_generator_freedom`, `SELECTION FREEDOM` |
| commutant of the central action on a slice | exactly the central multiplications (2 real parameters) | `slice_plus_central_commutant`, `slice_minus_central_commutant` |

The rank statement is **not** inferred from "a 2-dimensional real space is a
1-dimensional space over a quadratic extension": it is proved from `Z`-stability, the
inherited dimension `2` of the slice and `finrank_Zspan`.  The slice and a generator of
the slice are kept strictly distinct; no generator is normalized.

## 12. Reference action classification (§13–§18)

Restricted action `ρ_{L,ref}(θ)(ψ) = Uref θ ⋆ ψ` (`rhoRef`):
well-defined, real-linear (by type), invertible with inverse at `−θ`, identity at `0`,
one-parameter group law, continuous in `θ`, and `ρ(2π) = −id`, `ρ(4π) = id`
(`reference_restriction_report`).

Exact sector actions, derived from `R ψ = ± S ψ` (**not** transferred from Task 10):

| Sector | Exact action | Theorem |
| --- | --- | --- |
| `K₊(L)` | `Uref θ ⋆ ψ = (cos(θ/2)·1 − sin(θ/2)·S) ⋆ ψ` | `reference_action_plus_exact` |
| `K₋(L)` | `Uref θ ⋆ ψ = (cos(θ/2)·1 + sin(θ/2)·S) ⋆ ψ` | `reference_action_minus_exact` |

Both slices are preserved, with equality of images obtained from invertibility
(`reference_preserves_plus_slice`, `reference_preserves_minus_slice`).

Opposite-sector theorem (§17), `reference_relative_action_exact`:

```
c₊(θ) ⋆ c₋(θ) = 1,     c₋(θ) ⋆ c₊(θ) = 1,
c₊(θ) = Rel(θ) ⋆ c₋(θ),  Rel(θ) = c₊(θ) ⋆ c₊(θ) = cos θ·1 − sin θ·S.
```

So the two sector actions are **mutually inverse central units** — an *opposite sector
factor pair*, equivalently a *half-angle pair*, the relative factor running at the full
angle.  Both are one-parameter groups (`reference_sector_factors_group`).

Carrier independence (§18), `reference_action_carrier_independent`: the same two central
elements govern the plus and minus slices of *every* minimal carrier.  Label:
`CARRIER-INDEPENDENT`; the action depends only on the axis-relative sector, never on the
literal carrier.

Commutant of the restricted axial family on a slice (§41): equal to the commutant of the
central action, `slice_plus_axial_commutant`.  (At the exceptional values `θ ∈ 2πℤ` the
individual restricted map is a real scalar, so commutation at a single parameter value is
strictly weaker — recorded, not conflated.)

## 13. Full-lift action classification (§19–§21, §40)

The whole Task-11 family is retained: `α, β` are never set to zero.

* `rhoFull` for an arbitrary `IsFullLift U`: well-defined, identity at `0`, group law,
  invertible (`full_lift_restriction_report`).
* Every full lift preserves both slices, with equality of images
  (`fullLift_preserves_slices`) — no continuity, no normalization used.
* Exact factors, derived from `U = z ⋆ Uref` and the reference-sector theorem:
  `U θ ⋆ ψ₊ = (z θ ⋆ c₊(θ)) ⋆ ψ₊`, `U θ ⋆ ψ₋ = (z θ ⋆ c₋(θ)) ⋆ ψ₋`
  (`full_lift_action_plus_exact`, `full_lift_action_minus_exact`).
* Closed form for the continuous family (`continuous_full_lift_sector_factors`):

```
c₊(α,β,θ) = e^{αθ}·( cos(βθ − θ/2)·1 + sin(βθ − θ/2)·S )
c₋(α,β,θ) = e^{αθ}·( cos(βθ + θ/2)·1 + sin(βθ + θ/2)·S )
```

* §40: `U θ ⋆ (z ⋆ ψ) = z ⋆ (U θ ⋆ ψ)` for every central `z`
  (`fullLift_central_compatibility`) — the restricted action commutes with the internal
  endomorphism algebra `EndW(L) ≅ Z`; proved from centrality.

## 14. Common versus relative freedom (§22, §23)

| Part | Content | Label |
| --- | --- | --- |
| common | the residual `z θ` (for the continuous family `e^{αθ}(cos βθ + sin βθ·S)`), identical on both slices | `COMMON FACTOR`, arbitrary |
| relative | `Rel(θ) = cos θ·1 − sin θ·S`, the unique solution of `c₊(θ) = r ⋆ c₋(θ)` | `RELATIVE FACTOR`, rigid |

Theorems: `relative_factor_division_free` (division-free identity, valid for every
residual), `cMinus_full_inverse` (invertibility of the minus factor),
`relative_factor_unique` (uniqueness of `r`), `common_versus_relative_classification`
(both, for an arbitrary minimal carrier and an arbitrary full lift),
`relative_action_parameter_independent` (the continuous form, for two arbitrary parameter
pairs).

**§23 verdict.**  All full lifts implementing the inherited automorphism family induce the
*same* relative transformation between the two axis-relative slices: the relative action
is `LIFT-INDEPENDENT` and `CARRIER-INDEPENDENT`, and the exact invariant is the central
element `Rel(θ) = cos θ·1 − sin θ·S`.  Conservation of difficulty: the two-parameter
freedom does not disappear — it is entirely *common*, i.e. it survives in the internal
carrier action but cancels in the relative sector action.

## 15. Infinitesimal classification (§24–§26)

With `G(α,β) = α·1 + β·S − (1/2)·R` (`Ggen`):

| Sector | Exact restricted generator | Theorem |
| --- | --- | --- |
| `K₊(L)` | `α·1 + (β − 1/2)·S` | `infinitesimal_plus_exact` |
| `K₋(L)` | `α·1 + (β + 1/2)·S` | `infinitesimal_minus_exact` |

Both slices are stable (`infinitesimal_preserves_slices`).  Common part `α·1 + β·S`;
relative part `∓(1/2)·S`; difference of the two restricted generators is exactly `−S` for
every `(α, β)` (`infinitesimal_relative_exact`, `infinitesimal_common_relative_split`).
Hence: **every** combination of `α` and `β` affects the two slices equally, **no**
combination distinguishes them, and the whole residual freedom disappears from the
relative generator.  The two restricted generators never agree
(`infinitesimal_sectors_never_agree`), and distinct `(α, β)` are visible on the carrier
(`residual_visible_on_carrier`).

§26 separation theorem (`rate_versus_residual_separation`): for every `(α, β)` the induced
derivation is exactly `Dgen`, so the Task-10 rate is forced to `λ = 1`, while the whole
`(α, β)`-plane is invisible to the algebra.  `λ` is therefore *not* a combination of `α`
and `β`; the Task-11 distinction is preserved.

## 16. Carrier-equivalence / intertwiner classification (§29–§33)

The Task-12 equivalence `T_r(ψ) = ψ ⋆ r` is used with its three defining properties only;
`r` is never assumed globally invertible.

* `carrier_equiv_intertwines_left` — commutes with left multiplication by *every* algebra
  element (associativity), hence with `Uref` (`carrier_equiv_intertwines_reference`), with
  every full lift (`carrier_equiv_intertwines_fullLift`) and with the infinitesimal
  implementer (`carrier_equiv_intertwines_generator`).  The Task-11 residual freedom is
  irrelevant to carrier equivalence.  Label: `INTERTWINED`.
* `mul_right_mem_Hplus`, `mul_right_mem_Hminus` — right multiplication preserves each
  sector (from the `A`-eigenrelation and associativity, not from dimensions).
* `carrier_equiv_preserves_slices` — `T_r(K₊(L)) = K₊(L')` and `T_r(K₋(L)) = K₋(L')`;
  surjectivity is obtained from the slice decomposition together with injectivity of
  `T_r`, not from equal dimensions.
* `universal_axial_carrier_type` — combination of all of the above.

**§33 verdict: `UNIVERSAL AXIAL CARRIER TYPE`.**  Exact criterion: for every pair `L, L'`
of minimal carriers there is `r` with `T_r(K₊(L)) = K₊(L')`, `T_r(K₋(L)) = K₋(L')`,
`T_r ∘ (U θ ·) = (U θ ·) ∘ T_r` for every full lift, and identical central sector factors
on both sides.

## 17. Φ-carrier-family action (§34)

Separate namespace and separate definition: `phiCarrier θ L = Submodule.map (Phi θ) L`.

* `phi_maps_minimal_carriers` — minimal carriers go to minimal carriers.
* `phiCarrier_zero`, `phiCarrier_add` — one-parameter group action on the family.
* `internal_action_versus_carrier_action` — the internal action `ψ ↦ U θ ⋆ ψ` preserves
  *every* minimal carrier; the family action equals right multiplication by `U(−θ)` and
  **moves** the equatorial carrier `Lgen(esph 0 1 0)` at `θ = π/2` (`MOVED CARRIER`).

The two actions are never conflated: no theorem in Task 13 mixes them.

## 18. Exact fixed-locus theorem (§35, §36)

The Task-12 gap is closed by an exact **global parametrization** of the carrier family,
obtained intrinsically:

* `dg` — the inherited coordinate reflection fixing `1, A, B, C` and reversing
  `P, Q, R, S` (instrumental; no metric or conjugation structure is attached).
* `dg_mul_coord_0` — the unit coordinate of `e^† ⋆ e` is the sum of squares of the
  coordinates of `e`, hence positive.
* `dg_mul_coord_4567` — the four reversed coordinates of `e^† ⋆ e` vanish identically.
* `minimal_eq_Lgen_esph` — **every** minimal left carrier equals `Lgen (esph n)` for a real
  unit vector `n`; the multiplicativity of the inherited central quadratic datum puts `n`
  on the unit sphere, and minimality upgrades the inclusion of carriers to an equality.
* `minimal_carrier_parametrization` — together with the Task-12 converse and injectivity:
  the family of minimal left carriers **is** the unit two-sphere.

Consequences:

| Statement | Theorem |
| --- | --- |
| fixity at one parameter value: `Φθ(Lgen(esph n)) = Lgen(esph n) ↔ (cos θ = 1 ∧ sin θ = 0) ∨ (n₂ = n₃ = 0)` | `phi_fixed_single_angle` |
| global fixity: `(∀θ, Φθ(L) = L) ↔ L = Lgen e₊ ∨ L = Lgen e₋` | `phi_fixed_carrier_iff` |
| the exact fixed locus is the two-element set `{Lgen e₊, Lgen e₋}`, and the two are distinct | `phi_fixed_locus_exact` |

§36 is respected: fixity at a single `θ` is strictly weaker — for `θ ∈ 2πℤ` the map is the
identity and fixes every carrier; these exceptional angles are recorded separately and are
not confused with global axial invariance.

## 19. Carrier-selection verdict (§37, §38, §39)

**`AXIAL DATA SELECT A FINITE FAMILY`** — exactly two minimal carriers
(`axial_selection_verdict`).  The family of minimal carriers is infinite; the axial data
cut it down to precisely the two axial members, but do not select a unique one.

§38 separation (`selection_versus_transformation`): the transformation law is universal —
it holds for every minimal carrier, fixed or moved — while selection has the strictly
weaker answer above.  Deriving a universal transformation law therefore does **not** settle
representative selection; this is stated explicitly.

§39 (`axial_carriers_not_distinguished_by_action`): the two axial carriers are used as
witnesses/controls only.  An explicit moved carrier (an equatorial point of the sphere)
carries exactly the same restricted reference action as the axial ones, so neither
simplicity nor `Φ`-fixity distinguishes them as far as the one-axis transformation
structure is concerned.  No claim that `e₊` or `e₋` is *the* carrier is made anywhere.

## 20. Normalization negative control (§50)

**`NO NORMALIZATION DERIVED FROM CARRIER STRUCTURE`** (`no_normalization_derived`).  For
arbitrary `(α, β)` the corresponding continuous full lift

* implements the inherited automorphism family (`IsContinuousFullLift`),
* preserves every minimal carrier,
* preserves both axis-relative slices,
* acts on each slice by a central factor,
* and is intertwined by every carrier equivalence.

Hence minimality, the `2+2` axis splitting, `Z`-stability, carrier equivalence, slice
invariance and `Φ`-implementation *together* impose no condition whatsoever on `(α, β)`.
Distinct parameter pairs give genuinely distinct lifts
(`residual_parameters_distinct`).  This negative result is not hidden: it is one of the
principal Task-13 outputs.

## 21. Conservation-of-Difficulty graph and the twenty-five answers (§49)

```
Task-12 minimal-carrier structure
        ↓  (difficulty: the missing H₋ side)
H₋ stabilizer + reducibility        →  closed exactly (dim 6, subalgebra, reducible)
        ↓  (difficulty: arbitrary carrier instead of a preferred one)
K₊(L), K₋(L) for arbitrary L        →  2+2, Z-stable, central rank 1
        ↓  (difficulty: derive, not transfer, the action)
reference restriction               →  two conjugate half-angle central factors
        ↓  (difficulty: keep the whole lift family)
full (α,β) family                   →  common central factor × fixed relative factor
        ↓  (difficulty: is the residual freedom removable?)
relative rigidity                   →  YES rigid relatively, NO constraint on (α,β)
        ↓  (difficulty: is the structure carrier-dependent?)
carrier intertwiners                →  UNIVERSAL AXIAL CARRIER TYPE
        ↓  (difficulty: does anything select a carrier?)
Φ-fixed locus                       →  exactly two carriers; selection not unique
        ↓
residual difficulty exported: the choice among the two axial carriers, the whole (α,β)
plane, and every question outside the single selected axis.
```

| # | Question | Answer |
| --- | --- | --- |
| 1 | Is the missing `H₋` stabilizer the expected counterpart of the `H₊` one? | Yes — dimension `6`, subalgebra, coordinates `x₂ + x₄ = x₃ + x₅ = 0`; and the counterpart relation is *proved* as conjugation by `B`. |
| 2 | Is `H₋` reducible under its exact stabilizer? | Yes, `REDUCIBLE`; explicit invariant plane `Zspan e₋`. |
| 3 | Is each `K₊(L)` stable under `Z`? | Yes. |
| 4 | Is each `K₋(L)` stable under `Z`? | Yes. |
| 5 | Exact central rank of each slice? | One (real dimension two, unique central coefficients). |
| 6 | Does `Uref` preserve both slices for every minimal carrier? | Yes, with equality of images. |
| 7 | Exact action on `K₊(L)`? | `cos(θ/2)·1 − sin(θ/2)·S`. |
| 8 | Exact action on `K₋(L)`? | `cos(θ/2)·1 + sin(θ/2)·S`. |
| 9 | Is the opposite-sector relation universal? | Yes — mutually inverse central units, relative factor `cos θ·1 − sin θ·S`. |
| 10 | Does the reference action depend on the literal carrier? | No — `CARRIER-INDEPENDENT`. |
| 11 | How does arbitrary `(α,β)` modify each slice? | By the common central residual: `c_±(α,β,θ) = e^{αθ}(cos(βθ ∓ θ/2)·1 + sin(βθ ∓ θ/2)·S)`. |
| 12 | Which part of that freedom is common? | All of it. |
| 13 | Which part survives in the relative action? | None. |
| 14 | Is the relative action independent of the full-lift choice? | Yes — exact invariant `Rel(θ) = cos θ·1 − sin θ·S`. |
| 15 | Exact restricted infinitesimal generators? | `α·1 + (β ∓ 1/2)·S`. |
| 16 | Which infinitesimal freedom is common, which relative? | `α·1 + β·S` common; `∓(1/2)·S` relative, parameter-free. |
| 17 | Do Task-12 carrier equivalences preserve the axis slices? | Yes, onto. |
| 18 | Do they intertwine `Uref`? | Yes (associativity). |
| 19 | Do they intertwine every full lift? | Yes, for arbitrary `(α, β)`. |
| 20 | One axial transformation type across all minimal carriers? | Yes — `UNIVERSAL AXIAL CARRIER TYPE`. |
| 21 | How does `Φ` act on the family of minimal carriers? | As a one-parameter group action permuting them; equals right multiplication by `U(−θ)`; moves non-axial carriers. |
| 22 | Exact global `Φ`-fixed minimal-carrier locus? | Exactly `{Lgen e₊, Lgen e₋}`. |
| 23 | Does the axial structure select one carrier, several, or a family? | `AXIAL DATA SELECT A FINITE FAMILY` — exactly two. |
| 24 | Does any carrier-intrinsic requirement force `α = β = 0`? | No — `NO NORMALIZATION DERIVED`. |
| 25 | Where exactly does the unresolved freedom remain? | In the choice between the two axial carriers, in the entire `(α, β)` plane (visible on the carrier, invisible to the algebra and to the relative sector action), and in the discontinuous residual class inherited from Task 11. |

## 22. Late conventional comparison (§52, §53) — `COMPARISON ONLY`

Module `Task13.Identification`, imported by `Task13.Task13` only.  Under the Task-08
comparison isomorphism `toMat` with `2 × 2` complex matrices:

* `comparison_sector_factors` — the reconstructed plus factor is the complex scalar
  `cos(θ/2) − i sin(θ/2)`, the minus factor its conjugate `cos(θ/2) + i sin(θ/2)`.
* `comparison_restricted_action` — on an arbitrary minimal carrier the restricted action is
  multiplication by these two conjugate half-angle phases on the two slices.
* `comparison_minimal_carrier` — the reconstructed minimal carriers are exactly the minimal
  left ideals of the comparison algebra, parameterized by the two-sphere of rank-one
  projections.
* `comparison_summary` — the exact correspondence, in one statement.

**Permitted conclusion, and nothing more (§53):** *the independently reconstructed one-axis
carrier action is algebraically equivalent to the standard axial spinorial action.*
`NOT PHYSICAL SPIN`: no fermion, no physical spin-1/2, no electron, no quantum mechanics
and no physical state interpretation follows from Task 13.

## 23. Experiment-1 comparison (report level only)

*Already shared before Task 13* (as recorded in the earlier audits): the spin-factor /
Jordan boundary, the associative Clifford-like closure, and the central
square-root-of-minus-one structure.

*Experiment-2-only layers so far*: the central multiplicative quadratic extension
(Task 09), the exact centre (Task 11), the full axial lift classification (Task 11), the
minimal-carrier classification (Task 12), the axis-relative `2+2` carrier splitting
(Task 12/13), and — new in Task 13 — the one-axis carrier transformation classification,
the common/relative central-freedom separation, the carrier-intertwiner compatibility, the
exact global parametrization of the minimal-carrier family and the exact `Φ`-fixed locus.

No claim is made that Experiment 1 independently verifies the Task-13 carrier-action
theorem: no such theorem is present there.

## 24. Build report

```
lake build                                            -- whole project, succeeds
lake build RequestProject.NullSectorTask13.Task13     -- Task 13 chain, succeeds
```

No `sorry`, `admit`, custom `axiom` or `@[implemented_by]` occurs in any Task-13 module
(mechanical scan).  No linter is disabled anywhere in Task 13.

## 25. Axiom report (§56)

`#print axioms` is executed in `Task13.lean` for all twenty-three exposed principal
theorems, covering minus-sector hardening, slice central rank, exact reference actions,
exact full-lift actions, relative-factor rigidity, infinitesimal restriction,
carrier-intertwiner compatibility, universal axial-carrier type, the exact `Φ`-fixed locus,
the selection verdict, the `2π`/`4π` audit, central compatibility, the slice commutants,
the additional-compatibility test and the comparison summary.  Every one of them reports
exactly

```
[propext, Classical.choice, Quot.sound]
```

No other axiom dependency is observed anywhere in Task 13.

## 26. Unresolved mathematical obligations

1. **Selection.**  The axial data reduce the minimal-carrier family to exactly two members
   but do not choose between them; no further intrinsic datum available in Tasks 08–13
   breaks the tie.  `UNRESOLVED` (selection), `SETTLED` (locus).
2. **Residual freedom.**  The whole `(α, β)` plane survives every carrier-structural
   requirement.  It is visible on the carrier and invisible both to the algebra
   automorphism and to the relative sector action.  Any normalization would have to be
   introduced as a new, explicitly labelled condition (as in §51).
3. **Discontinuous lifts.**  The Task-11 algebraic (non-continuous) residual class is
   strictly larger than the continuous one and is not parameterized; the Task-13 statements
   which quantify over `IsFullLift` do cover it, but the closed-form factors of §13 above
   are stated for the continuous family only.
4. **Slice endomorphisms.**  Only the two commutants needed for the one-axis reduced
   carrier are classified (§41); no general representation-theoretic classification is
   attempted, by design.
5. **Other axes.**  Everything here is relative to the single inherited axis `A`.  Whether
   the two-sphere parametrization interacts with a second axis, and what the corresponding
   fixed loci are, is outside Task 13 by the full-rotation firewall.
6. **Uniqueness of the two-sphere parametrization up to the inherited structure.**  The
   parametrization is proved exact (bijective onto the family), but no intrinsic
   characterization of the sphere *as a geometric object* is given, and none is used.
7. **Nothing physical.**  No inner product, no projective quotient, no probability, no
   dynamics, no physical state interpretation is introduced, and none follows.
