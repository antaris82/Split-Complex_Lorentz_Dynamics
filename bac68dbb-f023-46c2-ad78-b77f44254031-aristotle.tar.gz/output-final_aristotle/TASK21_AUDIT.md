# TASK 21 AUDIT

*(written by the Task-XXII completion run, after — and only after — the focused Task-21
build, the whole-project build, the prohibited-proof scan and the axiom audit were all
green.)*

---

## 0. Verdict

> **TASK XXI COMPLETION: PASS**
> **TASK XXI FOCUSED BUILD: PASS**
> **WHOLE PROJECT BUILD: PASS**

The interrupted Task-XXI mathematics survives completion and full-project compilation.

No intended Task-XXI theorem had to be weakened, corrected or removed. Every declaration
that existed in the interrupted archive still has exactly the statement it had there; the
only Task-XXI source file that changed is `NormalizedCentralCarrier.lean`, and every change
in it is the replacement of a `sorry` by a proof (plus the small number of private helper
lemmas those proofs need). The other twelve inherited Task-XXI source files are **byte for
byte identical** to the archive — see the hash table in §1.3.

---

## 1. Provenance

### 1.1 Run identifiers

| item | value |
| --- | --- |
| interrupted Task-XXI run identifier | not recorded in the archive; the interrupted run left no summary entry, no `Task21.lean`, and no `TASK21_AUDIT.md` |
| Task-XXII completion run | the run that produced this file; its commits are `Task XXII Phase 1-9: complete NormalizedCentralCarrier.lean (24 sorries -> 0)` and `Task XXII: Task21.lean endpoint module, Task22.lean marker; focused and full builds green` |
| starting repository state | commit `39c6f86` (“Initial commit”), the exact interrupted Task-XXI archive |

### 1.2 Toolchain

| item | value |
| --- | --- |
| Lean | `leanprover/lean4:v4.28.0` (`lean --version` → `Lean (version 4.28.0, x86_64-unknown-linux-gnu, commit 7e01a1bf5c70fc6167d49c345d3bf80596e9a79b, Release)`) |
| Mathlib revision | `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (`inputRev` `v4.28.0`) |
| batteries | `495c008c3e3f4fb4256ff5582ddb3abf3198026f` |
| aesop | `f642a64c76df8ba9cb53dba3b919425a0c2aeaf1` |
| Qq | `b8f98e9087e02c8553945a2c5abf07cec8e798c3` |
| proofwidgets | `be3b2e63b1bbf496c478cef98b86972a37c1417d` |
| importGraph | `85b59af46828c029a9168f2f9c35119bd0721e6e` |
| LeanSearchClient | `c5d5b8fe6e5158def25cd28eb94e4141ad97c843` |
| plausible | `55c8532eb21ec9f6d565d51d96b8ca50bd1fbef3` |
| Cli | `4f10f47646cb7d5748d6f423f4a07f98f7bbcc9e` |

The toolchain was neither upgraded nor downgraded.

### 1.3 Source archive hashes

Git blob hashes, archive state `39c6f86` versus final state.

| file | archive blob | final blob | changed |
| --- | --- | --- | --- |
| `SafeBase.lean` | `9088ebc…` | `9088ebc…` | no |
| `GroupPackaging.lean` | `2c62bc3…` | `2c62bc3…` | no |
| `CoreQuaternionEquiv.lean` | `1834a3f…` | `1834a3f…` | no |
| `SU2Model.lean` | `d5bbf81…` | `d5bbf81…` | no |
| `VisibleRotationCandidate.lean` | `63f8a94…` | `63f8a94…` | no |
| `CoreProjection.lean` | `8fd6da8…` | `8fd6da8…` | no |
| `SectionObstruction.lean` | `aabe839…` | `aabe839…` | no |
| `CentralComplex.lean` | `ed01b88…` | `ed01b88…` | no |
| `CentralProduct.lean` | `a819b3c…` | `a819b3c…` | no |
| `NormalizedCentralCarrier.lean` | `7447cfe…` | `c5cb37a…` | **yes** |
| `SignStructures.lean` | `38241ef…` | `38241ef…` | no |
| `TorsorPlacement.lean` | `0d2ae09…` | `0d2ae09…` | no |
| `NegativeControls.lean` | `3a55cec…` | `3a55cec…` | no |
| `Task21.lean` | — | `754fbe7…` | **new** |
| `Task22.lean` | — | `ee2a2d0…` | **new** |

SHA-256 of the final files:

```
2f50c67694508df7fa215f1b97a2e856d55712adf607ada13293b902c03bd056  CentralComplex.lean
840303ce8eaad480e4f235e461011d370c7fb6e77d13f5456ccbda398cc52dfc  CentralProduct.lean
5075dea606b8caed21b4fed334dc77b8ea063d23382e8022b502f824b33a9080  CoreProjection.lean
645da72d94a884766fcafaeec79d35b1ff6efdf8c74c007df49527c84778f23a  CoreQuaternionEquiv.lean
5ef6219bff09b2bbfec0c810553b1f7e4b208e7a744fdd62ab66810e9fe08d68  GroupPackaging.lean
2eca690717faac626c1de24e70b7ecba8db41429bcc8cafef873bf1d399e26ce  NegativeControls.lean
d043e2070e933081cd2f13e14a6af567ba5b4b4f81d140ee52891e035e2bdb90  NormalizedCentralCarrier.lean
c0692653311dbeaae318c9ee7cb6447d47874f3c5094bd0bef8efba9c73ec29d  SU2Model.lean
0809dba20122a2db87b6ff2186d9fe1381bc22992f71f7b6b7cd8bb7cec695c3  SafeBase.lean
375ee94207bc26ed838e2fc87e54b200bad3a3394da35350f7cd0bc9637b862d  SectionObstruction.lean
e7c2b9851e52848f2b81479fd87ed24b7ed5780c4f5ec2f5e73bac5e1332464c  SignStructures.lean
ac98ff9b30bfbe2f273e2c5549a187b42899f22f139d6fdb40cae3b256c94f79  Task21.lean
5a8826bc141767a83ac2381a7817d1b4b5a6f9632a36df13b93fd65da35b4c49  Task22.lean
9f33df35fdf221e55144d5d4dc3e0814725f026abbc01b4fa6655bae95858cd2  TorsorPlacement.lean
1a729781ad12f1879b518063cd6c710eea08d7bd1d5ec1e8ff48df634c3f62b4  VisibleRotationCandidate.lean
```

---

## 2. Timeout provenance

Stated explicitly, as required:

* the original **Task XXI timed out**;
* the original archive contained **13 Task-XXI modules / 2655 lines**;
* the original `NormalizedCentralCarrier.lean` contained **all 24 `sorry` occurrences, on 22
  source lines, in a 135-line module**; no other Task-XXI file contained a `sorry`;
* **no final `Task21.lean`, no `TASK21_AUDIT.md`, no focused build report, no whole-project
  build report, no warning inventory and no `#print axioms` inventory existed before Task
  XXII**;
* the three later modules `SignStructures.lean`, `TorsorPlacement.lean` and
  `NegativeControls.lean` had no local `sorry` but had never been compiled, because they
  transitively import the unfinished normalization module.

---

## 3. Source inventory

Import order (linear chain; each module imports exactly its predecessor, with the single
extra edge `CoreQuaternionEquiv → NullSectorTask20.Identification`):

```
SafeBase
  → GroupPackaging
  → CoreQuaternionEquiv        (+ import RequestProject.NullSectorTask20.Identification)
  → SU2Model
  → VisibleRotationCandidate
  → CoreProjection
  → SectionObstruction
  → CentralComplex
  → CentralProduct
  → NormalizedCentralCarrier
  → SignStructures
  → TorsorPlacement
  → NegativeControls
  → Task21                      (endpoint module, new in Task XXII)
  → Task22                      (completion marker, new in Task XXII)
```

`SafeBase` enters the inherited development through the single import
`RequestProject.NullSectorTask20.NegativeControls`.

| file | lines (archive) | lines (final) | classification |
| --- | ---: | ---: | --- |
| `SafeBase.lean` | 112 | 112 | reconstruction |
| `GroupPackaging.lean` | 321 | 321 | reconstruction |
| `CoreQuaternionEquiv.lean` | 218 | 218 | comparison |
| `SU2Model.lean` | 162 | 162 | comparison |
| `VisibleRotationCandidate.lean` | 549 | 549 | comparison |
| `CoreProjection.lean` | 130 | 130 | comparison |
| `SectionObstruction.lean` | 138 | 138 | comparison |
| `CentralComplex.lean` | 189 | 189 | comparison |
| `CentralProduct.lean` | 255 | 255 | comparison |
| `NormalizedCentralCarrier.lean` | 135 | 614 | comparison — **completed by Task XXII** |
| `SignStructures.lean` | 147 | 147 | comparison |
| `TorsorPlacement.lean` | 154 | 154 | comparison |
| `NegativeControls.lean` | 145 | 145 | comparison |
| `Task21.lean` | — | 220 | endpoint packaging (new) |
| `Task22.lean` | — | 42 | completion marker (new) |
| **total** | **2655** | **3396** | |

---

## 4. Phase 0 — reproducing the pre-timeout boundary

The nine modules preceding the interruption were built in order with the pinned toolchain:

```
lake build RequestProject.NullSectorTask21.CentralProduct
→ Build completed successfully (8187 jobs).
```

All of `SafeBase`, `GroupPackaging`, `CoreQuaternionEquiv`, `SU2Model`,
`VisibleRotationCandidate`, `CoreProjection`, `SectionObstruction`, `CentralComplex`,
`CentralProduct` compiled **without any repair**. The inherited environment is therefore
exactly what the interrupted run left; every source-closed Task-XXI declaration listed above
really does compile.

**No repair outside `NormalizedCentralCarrier.lean` was necessary anywhere in Task XXII.**

---

## 5. What Task XXII proved — exact definitions added

All of the following live in `RequestProject/NullSectorTask21/NormalizedCentralCarrier.lean`.
Notation: `W` is the inherited eight-dimensional carrier, `⋆` the inherited product, `w1` its
unit, `zc a b = a • w1 + b • wS` the exact central plane, `Lift` the internal core carrier,
`CUnit` the invertible centre, `LiftZ = CUnit ⋆ Lift` the full internal carrier, `WG` the
packaged invertible elements, and `LiftG, CUnitG, LiftZG` their packaged subgroups.

Definitions inherited from the archive and **not** modified:

```lean
abbrev Rpos : Type := {x : ℝ // 0 < x}
def CUnit1 : Set W := {z : W | ∃ a b : ℝ, a ^ 2 + b ^ 2 = 1 ∧ z = zc a b}
def LiftZ1 : Set W := {u : W | ∃ z ∈ CUnit1, ∃ g ∈ Lift, u = z ⋆ g}
def circleNegOne : Circle := ⟨-1, _⟩
```

Auxiliary definitions **added** by Task XXII, used only to discharge the existing
obligations (they introduce no new object of study — `nsq` is the coordinate sum of squares
of the inherited carrier, `circWG` and `splitMap` are packaging maps):

```lean
def nsq (x : W) : ℝ :=
  x 0 ^ 2 + x 1 ^ 2 + x 2 ^ 2 + x 3 ^ 2 + x 4 ^ 2 + x 5 ^ 2 + x 6 ^ 2 + x 7 ^ 2

noncomputable def circWG (c : Circle) : WG        -- the central element of a phase
noncomputable def splitMap : Rpos × LiftZ1G →* LiftZG
```

The two facts about `nsq` that carry the modulus split are

```lean
theorem nsq_zc_mul (a b : ℝ) (x : W) : nsq (zc a b ⋆ x) = (a ^ 2 + b ^ 2) * nsq x
theorem nsq_of_Lift {u : W} (hu : u ∈ Lift) : nsq u = 1
```

both proved from the inherited coefficient multiplication law alone.

---

## 6. Repair ledger — every edit made by Task XXII

Classification key: **PC** = proof completion only; **ER** = engineering repair; **TW** =
theorem weakening; **TS** = theorem strengthening; **RF** = refactor required by compilation.

| # | declaration | file | class | note |
| --- | --- | --- | --- | --- |
| 1 | `polarEquiv` | `NormalizedCentralCarrier.lean` | PC | constructed explicitly: forward map `z ↦ (‖z‖, z/‖z‖)`, inverse `(r,c) ↦ r • c`; both inverse identities and `map_mul'` proved. Statement unchanged. |
| 2 | `polarEquiv_fst` | same | PC | holds by `rfl` against the constructed equivalence |
| 3 | `polarEquiv_snd` | same | PC | holds by `rfl` |
| 4 | `CUnit1_subset_CUnit` | same | PC | from `a² + b² = 1 ⇒ ¬(a = 0 ∧ b = 0)` |
| 5 | `CUnit1G` (3 obligations) | same | PC | identity `zc 1 0 = w1`; multiplication via the two-square identity `(ac−bd)² + (ad+bc)² = (a²+b²)(c²+d²)`; inverse via uniqueness of inverses applied to `zc a (−b)` |
| 6 | `LiftZ1G` (3 obligations) | same | PC | identity `w1 = zc 1 0 ⋆ w1`; multiplication via the inherited `central_swap` plus closure of `CUnit1` and `Lift`; inverse via uniqueness of inverses applied to `zc a (−b) ⋆ g'` with `g'` the inherited core inverse |
| 7 | `posCentral` (5 obligations) | same | PC | carrier/inverse witnesses `zc r 0`, `zc r⁻¹ 0`; membership `zc r 0 ∈ LiftZ`; `map_one'`, `map_mul'` from the central product rule. The declared positive-real model was kept. |
| 8 | `liftZSplit` | same | PC | proved via the auxiliary homomorphism `splitMap (r, v) = posCentral r * v`, shown injective and surjective for the actual intrinsic `LiftZ`. Existence of the decomposition uses `r = √(a²+b²)`; uniqueness uses `nsq`. Statement unchanged. |
| 9 | `muNorm` | same | PC | `(c, q) ↦ ofComplex c ⋆ fromQuat q`; homomorphism from `central_swap`, `ofComplex_mul` and `fromQuat_mul`. `UQ` was not replaced by SU(2). |
| 10 | `muNorm_surjective` | same | PC | from the defining shape of `LiftZ1` plus the inherited `quatOf`/`fromQuat` inverse identities |
| 11 | `ker_muNorm` | same | PC | derived from the intrinsic intersection theorem `CUnit_inter_Lift` of `CentralProduct.lean`; result is exactly `{(1,1), (−1,−1)}` |
| 12 | `nuU2` (3 obligations) | same | PC | membership from `‖c‖ = 1` and the inherited `quatMat_mem_unitary`; identity and multiplication from `quatMat_one`, `quatMat_mul`. Single matrix model reused. |
| 13 | `nuU2_surjective` | same | PC | a square root `c` of `det A` exists and has modulus one; `c⁻¹ • A ∈ SU(2)`; the inherited `toSU_surjective` finishes. No dimension counting. |
| 14 | `ker_nuU2` | same | PC | kernel computed exactly (`det` forces `c² = 1`, then injectivity of `quatMat`) and shown equal to `muNorm.ker` |
| 15 | `normalizedQuotientEquiv` | same | — | untouched; now typechecks and builds because its dependencies are complete |
| 16 | `normalizedU2Equiv` | same | — | untouched; now typechecks and builds |
| 17 | helper lemmas `nsq`, `zc_mul_coords`, `nsq_zc_mul`, `zc_smul_eq`, `nsq_of_Lift`, `w1_mem_CUnit1`, `CUnit1_mul_mem`, `CUnit1_inv_pair`, `CUnit1_neg_mem`, `LiftZ1_subset_LiftZ`, `nsq_of_LiftZ1`, `LiftZ1G_le_LiftZG`, `zc_pos_mem_CUnit`, `posCentral_val`, `splitMap`, `splitMap_val`, `splitMap_injective`, `splitMap_surjective`, `liftZSplit_symm_val`, `circle_ne_zero`, `circle_coord_sq`, `ofComplex_circle_mem`, `circWG`, `circWG_val`, `muNorm_val`, `fromQuat_neg_one`, `fromQuat_injective`, `ofComplex_eq_w1`, `ofComplex_eq_neg_w1`, `smul_mem_unitary`, `nuU2_val`, `unitary_det_norm`, `quatMat_neg_one`, `ker_nuU2_set` | same | PC | new auxiliary lemmas, all proved; none of them changes an existing statement |
| 18 | `Task21.lean` | new file | RF | endpoint packaging only: `alias`es of existing theorems (so statements cannot drift), the single composite `liftZU2Split`, and the `#print axioms` commands |
| 19 | `Task22.lean` | new file | RF | completion marker; `#print axioms` on the sixteen originally unresolved declarations |

**No TW, no TS.** No intended Task-XXI theorem turned out to be false or overstrong, so
there is **no mathematical boundary change** to report.

---

## 7. Formal result ledger

| claim | Lean declaration | status |
| --- | --- | --- |
| `Lift ≃` unit quaternions | `liftQuatEquiv` | `PROVED` |
| the same two maps are a homeomorphism | `liftQuatHomeo` | `PROVED` |
| `UQ ≃ SU(2)`, `Lift ≃ SU(2)` | `quatSUEquiv`, `liftSUEquiv` | `PROVED` |
| `Gvis ≃ SO(3)` | `visibleRotationEquiv` | `PROVED` |
| intrinsic projection = quaternionic rotation map | `coreProjection_diagram` | `PROVED` |
| core kernel `= {±1}` | `ker_projCore`, `quatRot_kernel` | `PROVED` |
| set-theoretic section exists | `exists_group_section`, `exists_core_section` | `PROVED` |
| quotient-compatible choice ↔ continuous section | `continuous_section_iff_continuous_choice` | `PROVED` |
| no continuous global section | `no_continuous_core_section` | `PROVED` |
| `CUnit ≃ ℂˣ` | `cUnitComplexEquiv` | `PROVED` |
| `CUnit ∩ Lift = {±1}` | `CUnit_inter_Lift`, `inter_CUnitG_LiftG` | `PROVED` |
| product-map surjectivity, diagonal-sign kernel | `mu_surjective`, `ker_mu` | `PROVED` |
| `LiftZ` central-product quotient | `centralProductEquiv`, `liftZStandardEquiv` | `PROVED` |
| `ℂˣ ≃ ℝ₊ × U(1)` in the implemented model | `polarEquiv` | `PROVED` |
| positive modulus splits from `LiftZ` | `liftZSplit` | `PROVED` |
| normalized quotient `(U(1) × UQ)/Δℤ₂` | `normalizedQuotientEquiv` + `ker_muNorm` | `PROVED` |
| normalized carrier `≃ U(2)` | `normalizedU2Equiv` | `PROVED` (abstract group equivalence) |
| full carrier `≃ ℝ₊ × U(2)` | `liftZU2Split` | `PROVED` (composition of the two above) |
| core sign distinct from direction reversal | `two_sign_structures_distinct`, `revQuot_not_two_element` | `PROVED` |
| half-odd labels become central phase weights | `toComplex_labelBridge_circle` | `PROVED` |
| full turn ↔ integer weight difference | `full_turn_eq_iff_int_difference` | `PROVED` |
| mod-2 / full-turn information loss | `full_turn_remembers_only_parity` | `PROVED` |
| principal negative controls | `task21_negative_controls` | `PROVED` |
| `Spin(3)` named model, `Spinᶜ(3)` named model | — | `NOT FORMALIZED` (the installed library has `spinGroup` only for a general Clifford algebra, with no three-dimensional specialization and no `Spinᶜ` object; the quotient expressions above are kept as the formally proved objects) |
| topological/smooth structure on the `SU(2)`, `SO(3)`, `U(2)` identifications | — | `NOT FORMALIZED` (see §8) |

### Scope of the equivalences

Every equivalence in the table is an equivalence of **abstract multiplicative groups**, with
the single exception of `liftQuatHomeo`, which is the only statement of the development whose
conclusion contains topology (a homeomorphism between the unit sphere of `ℍ` and the internal
core carrier with its subspace topology). In particular `normalizedU2Equiv` is **not** claimed
to be a Lie-group or topological-group equivalence: no topology or smooth structure appears in
its statement.

---

## 8. Required final decision table

| Claim | Final status |
| --- | --- |
| `Lift ≃` unit quaternions | **PROVED** |
| `Lift ≃ SU(2)` | **PROVED** |
| `Gvis ≃ SO(3)` | **PROVED** |
| intrinsic projection = quaternionic rotation map | **PROVED** |
| core kernel = `{±1}` | **PROVED** |
| set-theoretic section exists | **PROVED** |
| continuous section impossible | **PROVED** |
| `CUnit ≃ ℂ×` | **PROVED** |
| `CUnit ∩ Lift = {±1}` | **PROVED** |
| `LiftZ` central-product quotient | **PROVED** |
| `ℂ× ≃ ℝ₊ × U(1)` in the implemented model | **PROVED** |
| positive modulus splits from `LiftZ` | **PROVED** |
| normalized quotient `(U(1)×UQ)/Δℤ₂` | **PROVED** |
| normalized carrier ≃ `U(2)` | **PROVED** (abstract group equivalence) |
| full carrier ≃ `ℝ₊ × U(2)` | **PROVED** (`liftZU2Split`, composition of the two implemented equivalences) |
| core sign distinct from direction reversal | **PROVED** |
| half-odd labels become central phase weights | **PROVED** |
| mod-2/full-turn sign loses integer-weight information | **PROVED** |
| focused Task-XXI build | **PASS** |
| full-project build | **PASS** |
| prohibited-proof scan | **PASS** |
| axiom audit | **PASS** |

---

## 9. Build ledger

### 9.1 Phase-0 dependency build

```
$ cd /…/request-project
$ lake build RequestProject.NullSectorTask21.CentralProduct
Build completed successfully (8187 jobs).
```

### 9.2 Focused Task-XXI build

```
$ cd /…/request-project
$ lake build RequestProject.NullSectorTask21.Task21
Build completed successfully (8192 jobs).
```

**TASK XXI FOCUSED BUILD: PASS.**

### 9.3 Whole-project build (hard acceptance condition)

```
$ cd /…/request-project
$ lake build
Build completed successfully (8264 jobs).
```

* working directory: the project root;
* Lean `4.28.0`, Mathlib `8f9d9cff6bd728b17a24e163c9402775d9e6a365`;
* job count reported by Lake: **8264**;
* errors: **0**;
* modules that had to rebuild: only the Task-XXI modules from `NormalizedCentralCarrier`
  onward, plus the two new files. No pre-existing module of Tasks 1–20 was edited, and none
  needed rebuilding for any reason other than being already up to date;
* effect of Task-XXII repairs on earlier tasks: **none** — no file outside
  `RequestProject/NullSectorTask21/` was modified.

**WHOLE PROJECT BUILD: PASS.**

### 9.4 Warning inventory

`lake build` emits **114 warnings**, all from the Lean/Mathlib style linters and all
pre-existing (they come from source written before Task XXII):

| location | count |
| --- | ---: |
| `RequestProject/NullSectorTask11/…` | 4 |
| `RequestProject/NullSectorTask14/…` | 68 |
| `RequestProject/NullSectorTask21/…` | 42 |

By kind:

| kind | count |
| --- | ---: |
| “This simp argument is unused” | 45 |
| “this tactic is never executed” | 20 |
| “'ring' tactic does nothing” | 9 |
| “try 'simp' instead of 'simpa'” | 5 |
| `Quaternion.mul_re / mul_imI / mul_imJ / mul_imK` deprecated (use `re_mul` / `imI_mul` / …) | 16 |
| “Used `tac1 <;> tac2` where `(tac1; tac2)` would suffice” | 2 |
| “'linear_combination …' tactic does nothing” | 5 |
| unused variable / unused section variable | 6 |
| “'norm_num' / 'nlinarith' tactic does nothing” | 2 |
| other single-instance linter notes | 4 |

The 42 Task-XXI warnings are located in `SU2Model.lean` (20), `VisibleRotationCandidate.lean`
(8), `CoreQuaternionEquiv.lean` (4), `TorsorPlacement.lean` (3), `CoreProjection.lean` (2)
and are all in files whose bytes were **not** touched by Task XXII; leaving them untouched is
required by the Task-XXII scope freeze (source-closed modules must not be rewritten merely for
cosmetics). **No warning at all is emitted by the files Task XXII wrote**
(`NormalizedCentralCarrier.lean`, `Task21.lean`, `Task22.lean`). No warning is an error, and
none indicates an unsound or incomplete proof; the deprecation notices name replacements that
still exist in the pinned Mathlib revision.

---

## 10. Engineering provenance / failbuild ledger

Every failed build during Task XXII, preserved. All four failures are of the same command,

```
lake build RequestProject.NullSectorTask21.NormalizedCentralCarrier
```

and all are **engineering** failures in newly written proof scripts; none of them touched a
theorem statement, and none of them indicates that an intended Task-XXI theorem was false.

### Failure 1

* command: `lake build RequestProject.NullSectorTask21.NormalizedCentralCarrier`
* module: `RequestProject/NullSectorTask21/NormalizedCentralCarrier.lean`
* messages (five errors):
  * `306:46: Type mismatch — u has type WG but is expected to have type Wit8`
  * `431:6: Type mismatch — Eq.symm this has type ofComplex (↑cq.1)⁻¹ = fromQuat ↑cq.2 but is expected to have type fromQuat ↑cq.2 = ofComplex (↑cq.1)⁻¹`
  * `485:6: Ambiguous term star_smul — Quaternion.star_smul vs StarModule.star_smul`
  * `483:88: unsolved goals ⊢ c • A * star (c • A) = 1` (a consequence of the previous error)
  * `561:28: Unknown constant Matrix.unitaryGroup.coe_one`
* diagnosis: (i) a `show` in `splitMap_surjective` named the packaged invertible element
  instead of its carrier value; (ii) an orientation slip in the equality extracted inside
  `ker_muNorm`; (iii) two `open` namespaces both export `star_smul`; (iv) a guessed name for
  the coercion of the unit of `Matrix.unitaryGroup`.
* classification: engineering (proof-script), not mathematical.
* repair: `u` → `u.val`; `exact this.symm` → `exact this`; `star_smul` →
  `StarModule.star_smul`; replaced the guessed lemma by a local `rfl`-proved coercion fact.
* theorem boundary: unchanged.
* next build result: Failure 2.

### Failure 2

* command: as above
* module/lines: `NormalizedCentralCarrier.lean:308`, `:310`
* message: `unsolved goals` after `field_simp` in the two arithmetic side conditions
  `rr * (a / rr) − 0 * (b / rr) = a` and `rr * (b / rr) + 0 * (a / rr) = b`
* diagnosis: the nonvanishing hypothesis `rr ≠ 0` was not in context, so `field_simp` could
  not clear the denominators.
* classification: engineering.
* repair: added `have hne : rr ≠ 0 := ne_of_gt hpos` before the two `have`s.
* theorem boundary: unchanged.
* next build result: Failure 3.

### Failure 3

* command: as above
* module/lines: `NormalizedCentralCarrier.lean:309`, `:311`
* message: `unsolved goals` — same two goals, now in the cleared form left by `field_simp`
  (e.g. `rr * a − 0 * b = rr * a`).
* diagnosis: `field_simp` clears denominators but does not finish a purely ring-theoretic
  residue.
* classification: engineering.
* repair: appended `ring` after each `field_simp`.
* theorem boundary: unchanged.
* next build result: **PASS** — `Build completed successfully (8188 jobs).`

### Non-failures

* the Phase-0 dependency build (§9.1) passed on the first attempt;
* the three downstream modules `SignStructures`, `TorsorPlacement`, `NegativeControls` built
  on the first attempt after the normalization repair, with no edits;
* `Task21.lean`, `Task22.lean` and the whole-project build each passed on the first attempt.

---

## 11. Proof-integrity ledger

### 11.1 Prohibited-token scan

Scanned: the complete directory `RequestProject/NullSectorTask21/` (all 15 files, helper
modules included).

| token | occurrences |
| --- | ---: |
| `sorry` | **0** |
| `admit` | **0** |
| custom `axiom` declarations | **0** |
| `implemented_by` / `@[implemented_by]` | **0** |
| `native_decide` | **0** |
| `bv_decide` | **0** |
| `unsafe` | **0** |
| `partial` | **0** |

A repository-wide scan for `^axiom `, `@[implemented_by]`, `native_decide`, `bv_decide`
likewise returns nothing.

Placeholder count: **24 → 0**, exactly as required.

### 11.2 Axiom audit

`#print axioms` is executed in `Task21.lean` (69 commands) and in `Task22.lean` (16 commands),
covering **78 distinct declarations**: the twenty principal constructions/equivalences and the
`task21_*` endpoint aliases, plus the sixteen declarations that were unresolved in the
interrupted archive.

**Every one of the 78 reports exactly**

```
depends on axioms: [propext, Classical.choice, Quot.sound]
```

The audited names are:

```
CUnit1G  CUnit1_subset_CUnit  LiftZ1G  cUnitComplexEquiv  centralProductEquiv  ker_muNorm
ker_nuU2  liftQuatEquiv  liftQuatHomeo  liftSUEquiv  liftZSplit  liftZStandardEquiv
liftZU2Split  mu  muNorm  muNorm_surjective  muStd  normalizedQuotientEquiv
normalizedU2Equiv  nuU2  nuU2_surjective  polarEquiv  polarEquiv_fst  polarEquiv_snd
posCentral  projCore  projZ  quatSUEquiv  splitMap  visibleRotationEquiv
task21_central_identification_not_unique  task21_centre_coefficient  task21_centre_continuous
task21_centre_continuous_inverse  task21_centre_core_intersection
task21_centre_core_intersection_packaged  task21_controls
task21_core_homeomorphism_same_map  task21_core_kernel  task21_core_quaternion_inv
task21_core_quaternion_inverse_identities  task21_core_quaternion_mul
task21_core_quaternion_one  task21_core_sign_free  task21_core_sign_invisible
task21_full_turn_integer  task21_full_turn_parity_only  task21_group_section_exists
task21_kernel_does_not_determine  task21_label_differences_integers  task21_mu_kernel
task21_mu_std_kernel  task21_mu_std_surjective  task21_mu_surjective
task21_no_continuous_section  task21_normalized_kernel  task21_normalized_surjective
task21_phase_weight  task21_polar_modulus  task21_polar_phase  task21_projection_diagram
task21_projection_not_injective  task21_projection_surjective  task21_quat_rotation_kernel
task21_reversal_quotient_not_two_element  task21_section_and_relations
task21_section_exists  task21_section_iff_choice  task21_sign_structures_distinct
task21_split_injective  task21_split_surjective  task21_su2_injective  task21_su2_surjective
task21_u2_kernel  task21_u2_surjective  task21_visible_injective
task21_visible_noncommuting  task21_visible_surjective
```

* the established project baseline `propext`, `Classical.choice`, `Quot.sound` is **confirmed
  by the actual output**, not assumed;
* **no additional axiom** occurs anywhere, so there is nothing to explain individually;
* **`sorryAx = 0`**: the string `sorryAx` occurs in no axiom report and in no source file.

---

## 12. Source ledger

### IMPORTED STANDARD RESULT

Cited by exact Mathlib module and declaration, as installed at revision
`8f9d9cff6bd728b17a24e163c9402775d9e6a365`.

| declaration | module |
| --- | --- |
| `Quaternion`, `Quaternion.normSq`, `Quaternion.normSq_def'` | `Mathlib/Algebra/Quaternion.lean`, `Mathlib/Analysis/Quaternion.lean` |
| group structure of `Metric.sphere (0 : ℍ) 1` (`Metric.unitSphere.coe_one`, `Metric.unitSphere.coe_mul`) | `Mathlib/Analysis/Normed/Field/UnitBall.lean` |
| `Circle`, `Circle.norm_coe`, `Circle.coe_one`, `Circle.coe_mul`, `Circle.ext`, `Circle.exp`, `Circle.coe_exp`, `Submonoid.unitSphere` | `Mathlib/Analysis/SpecialFunctions/Complex/Circle.lean`, `Mathlib/Analysis/Normed/Field/UnitBall.lean` |
| `Matrix.unitaryGroup`, `Matrix.mem_unitaryGroup_iff`, `Matrix.specialUnitaryGroup` | `Mathlib/LinearAlgebra/Matrix/UnitaryGroup.lean` |
| `Matrix.specialOrthogonalGroup` | `Mathlib/LinearAlgebra/Matrix/SpecialLinearGroup.lean`, `Mathlib/LinearAlgebra/Matrix/Orthogonal.lean` |
| `Matrix.det_smul`, `Matrix.det_mul`, `Matrix.det_conjTranspose`, `Matrix.star_eq_conjTranspose`, `Matrix.det_fin_two` | `Mathlib/LinearAlgebra/Matrix/Determinant/Basic.lean` |
| `Complex.normSq_apply`, `Complex.normSq_eq_norm_sq`, `Complex.mul_conj`, `Complex.star_def`, `Complex.ofReal_ne_zero`, `Complex.real_smul` | `Mathlib/Analysis/SpecialFunctions/Complex/…`, `Mathlib/Data/Complex/Basic.lean` |
| `IsSepClosed.exists_pow_nat_eq` (existence of a complex square root) | `Mathlib/FieldTheory/IsSepClosed.lean` |
| `Positive.val_mul`, `Positive.coe_inv` and the group structure on `{x : ℝ // 0 < x}` | `Mathlib/Algebra/Order/Positive/Ring.lean`, `Mathlib/Algebra/Order/Positive/Field.lean` |
| `QuotientGroup.quotientKerEquivOfSurjective`, `QuotientGroup.quotientMulEquivOfEq`, `MulEquiv.ofBijective`, `MulEquiv.prodCongr`, `Subgroup.inclusion`, `SetLike.ext'` | `Mathlib/GroupTheory/QuotientGroup/Basic.lean`, `Mathlib/Algebra/Group/Equiv/Basic.lean`, `Mathlib/Algebra/Group/Subgroup/Basic.lean` |
| `StarModule.star_smul`, `smul_mul_smul_comm`, `norm_smul`, `norm_pos_iff`, `mem_sphere_zero_iff_norm` | `Mathlib/Algebra/Star/Module.lean`, `Mathlib/Analysis/Normed/Group/Basic.lean` |

### DERIVED IN TASK 21 (completed in Task XXII)

Everything listed in §6 and §7 that is not in the table above, in particular: the eight-
dimensional carrier and its product, `Lift`, `CUnit`, `LiftZ`, `CUnit1`, `LiftZ1` and their
packaged subgroups; the coordinate modulus `nsq` and its two multiplicativity/normalization
lemmas; `polarEquiv` with its two coordinate formulas; `posCentral`, `splitMap`, `liftZSplit`;
`muNorm`, `muNorm_surjective`, `ker_muNorm`, `normalizedQuotientEquiv`; `nuU2`,
`nuU2_surjective`, `ker_nuU2`, `normalizedU2Equiv`; and the packaging composite
`liftZU2Split`.

---

## 13. Unresolved mathematical obligations

1. **`Spin(3)` and `Spinᶜ(3)` as named library objects — `NOT FORMALIZED`.** The installed
   Mathlib provides `spinGroup` for a general Clifford algebra, but no three-dimensional
   model, no equivalence of it with the unit quaternions, and no `Spinᶜ` object at all.
   The quotient descriptions `normalizedQuotientEquiv` and `normalizedU2Equiv` are kept as the
   formally proved objects; no source-level statement calls them `Spinᶜ(3)`.
2. **Topology of the identifications.** Only `liftQuatHomeo` carries topology. Whether
   `liftSUEquiv`, `visibleRotationEquiv`, `liftZSplit`, `normalizedU2Equiv` and
   `liftZU2Split` are also homeomorphisms (and *a fortiori* Lie-group isomorphisms) is **not
   formalized** and is not claimed anywhere.
3. **Open questions inherited from Tasks 17–20** — the arbitrary spatial word problem, the
   arbitrary-domain analytic admissibility question, and the independence of the disconnected
   label criterion from the rate torsor — are untouched by Task XXI and remain open. Task XXII
   did not reopen them.
4. The 42 pre-existing Task-XXI linter warnings listed in §9.4 remain, by scope freeze.

---

## 14. Hard acceptance conditions — checklist

| condition | status |
| --- | --- |
| 1. `NormalizedCentralCarrier.lean` contains zero `sorry` | ✅ |
| 2. entire Task-XXI directory contains zero prohibited proof holes | ✅ (§11.1) |
| 3. `SignStructures.lean` builds | ✅ |
| 4. `TorsorPlacement.lean` builds | ✅ |
| 5. `NegativeControls.lean` builds | ✅ |
| 6. final `Task21.lean` exists and builds | ✅ |
| 7. all principal endpoints receive an axiom audit | ✅ (78 declarations, §11.2) |
| 8. focused Task-XXI build green | ✅ (8192 jobs) |
| 9. full project `lake build` green | ✅ (8264 jobs) |
| 10. all warnings documented | ✅ (§9.4) |
| 11. all failbuilds preserved as provenance | ✅ (§10) |
| 12. `TASK21_AUDIT.md` written only after the green full build | ✅ |
| 13. no new mathematics beyond completion | ✅ (§6: no TW/TS; one packaging composite) |
