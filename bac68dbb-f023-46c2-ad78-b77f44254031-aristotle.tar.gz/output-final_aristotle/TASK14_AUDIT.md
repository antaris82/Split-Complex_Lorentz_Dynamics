# TASK 14 AUDIT

**Split-Complex Lorentz Dynamics — Experiment 2, Task 14**
Multi-axis compatibility on the minimal carrier: independent axis reconstruction, mixed
composition, central defects, and spatial closure.

All statements below are machine-checked. Every theorem name given is the exact Lean name
in namespace `NullSectorTask14`, in the file indicated.

---

## 1. Exact toolchain

| Item | Value |
| --- | --- |
| Lean toolchain | `leanprover/lean4:v4.28.0` (`lean-toolchain`) |
| Build tool | `lake` (bundled with the toolchain) |
| Build target | `RequestProject` library (`lakefile.toml`, glob `RequestProject.+`) |
| Task-14 top module | `RequestProject.NullSectorTask14.Task14` |

No toolchain change was made for Task 14.

## 2. Exact Mathlib revision

| Item | Value |
| --- | --- |
| Dependency | `mathlib`, `rev = "v4.28.0"` (`lakefile.toml`) |
| Resolved commit | `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (`lake-manifest.json`) |

Mathlib declarations used in the Task-14 modules are ordinary infrastructure only:
`Submodule`, `LinearMap`, `Module.finrank`, `LinearEquiv.finrank_eq`, real trigonometry
(`Real.sin_two_mul`, `Real.cos_two_mul'`, `Real.sin_sq_add_cos_sq`, `Real.cos_pi`,
`Real.sin_pi`, `Real.cos_pi_div_two`, `Real.sin_pi_div_two`, `Real.cos_two_pi`,
`Real.sin_two_pi`, `Real.sqrt`), `HasDerivAt` for the two derived infinitesimal
generators, and the tactics `ring`, `linarith`, `nlinarith`, `linear_combination`,
`module`, `field_simp`, `norm_num`, `simp`, `fin_cases`, `funext`.

**No** pre-built rotation group, spin group, quaternion, Pauli-matrix or Lie-algebra
classification is imported anywhere — see §4.

## 3. Complete inherited theorem ledger (INHERITED)

Task 14 inherits, and re-proves nothing of, the following.

| Source | Object / theorem | Used for |
| --- | --- | --- |
| Task 04 | `Vec3`, `Vec4`, `sp`, `dot3`, `Rest` | old spatial data |
| Task 07 | `dirA`, `dirB`, `e₀` | old spatial basis directions |
| Task 08 | `W = Wit8`, `⋆`, basis `1,A,B,C,P,Q,R,S`, `iota3`, `dirC`, associativity and the complete multiplication table | ambient algebra |
| Task 09 | `Z = CentralPlane = span{1,S}`, `mem_Z_iff`, `Z_central`, `wS_sq` | exact central plane |
| Task 10 | `Phi θ` (A-axis automorphism family) | first-axis comparison only |
| Task 11 | `center_eq_Z` (exact centre), `IsFullLift`, lift classification | every relative-central theorem |
| Task 12 | `IsLeftCarrier`, `IsMinimalLeftCarrier`, `Lgen`, `esph`, `minimal_eq_Lgen_esph`, `Lgen_esph_inj`, `isMinimal_Lgen_esph`, `minimal_carriers_equivalent`, `finrank_of_isMinimal = 4` | carriers and the sphere parametrization |
| Task 13 | `Kplus/Kminus`, `Uref`, `cPlusRef`, `cMinusRef`, `RelRef`, `zz`, one-axis sector and fixed-locus theorems | A-axis side of the comparison |

Inheritance is via `RequestProject.NullSectorTask14.SafeBase`, which imports
`RequestProject.NullSectorTask13.SelectionAudit`.

## 4. Full-rotation firewall

The reconstruction modules (`SafeBase` … `SelectionAudit`) contain **no** occurrence, in
code or in identifier names, of: `SO(3)`, `SU(2)`, `Spin`, spin group, rotation double
cover, quaternion, Pauli, Euler, Rodrigues, spinor, Bloch, projective representation,
2-cocycle, group extension, Clifford group, Pin group. The internal generators are named
`Jmap`, `GA`, `GB`, `GC`; the implementer algebra is `ImplAlg`; the emergent antisymmetric
spatial operation is `spCross`; the finite implementations are `Un`, `Uref`, `UBref`.

Conventional names occur **only** in `Identification.lean`, which is imported only by
`Task14.lean`, is labelled **COMPARISON ONLY**, and is used by no reconstruction result.

No topological input (`π₁`, covering spaces, simple connectedness) is used anywhere: the
two-valued defect is obtained algebraically from finite compositions
(`reference_word_defect`, `closed_path_internal_residual`).

## 5. Physical firewall

No particle, fermion, electron, photon, spin observable, measurement, helicity,
polarization, momentum, mass, energy, frequency, Hamiltonian, wavefunction, Hilbert space,
probability, Born rule or field equation occurs anywhere in Task 14. No inner product,
Hermitian form, unitarity, norm of a state, or orthogonality of carrier elements is
introduced; the inherited spatial form `h3 = dot3` is used only on the old spatial
subspace, where it already exists. No projective identification `ψ ∼ zψ` is made anywhere:
the central defect is kept explicit (§17, §18, §20).

## 6. Source-order graph (§68)

```
Task13.SelectionAudit  (inherited)
        ↓
Task14.SafeBase
        ↓
SecondAxisOldStructure          -- §9   independent B old-space decomposition
        ↓
SecondAxisAutomorphism          -- §10–§11 independent B old family + unique extension
        ↓
SecondAxisImplementation        -- §12–§14 unrestricted implementation problem, forced plane
        ↓
SecondAxisCarrierSlices         -- §15–§16 B slices, dimensions, central lines
        ↓
SecondAxisSectorAction          -- §17–§18 B reduced and relative action
        ↓
TwoAxisSliceComparison          -- §19–§20 A/B slice intersections
        ↓
MixedProjectors                 -- §21–§23 mixed projector algebra
        ↓
MixedFiniteComposition          -- §24 order dependence of the automorphisms
        ↓
MixedInfinitesimalComposition   -- §25, §27–§30 mixed products, commutator, third axis, signs
        ↓
ImplementerClosure              -- §26 minimal product-closed implementer algebra
        ↓
AxisGeneratorMap                -- §31–§34 the intrinsic map J and its algebra
        ↓
GenericAxis                     -- §35–§39 arbitrary unit axis
        ↓
GenericTwoAxisComposition       -- §40–§43 generic two-axis comparison and closure
        ↓
ReferenceWordDefect             -- §44–§46 words, central defect, exact reference defect set
        ↓
FullLiftDefect                  -- §47–§48 full per-axis lift freedom
        ↓
CoherenceAudit                  -- §49–§54 obstruction, closed path, path dependence
        ↓
CarrierIntertwiners             -- §55–§56 mixed words on arbitrary minimal carriers
        ↓
CarrierFamilyAction             -- §57–§58 induced action on the carrier family
        ↓
CommonFixedLocus                -- §59–§60 fixed loci and selection
        ↓
SelectionAudit                  -- §30, §65–§67 rate, isotropy, orientation
        ↓
Identification  (COMPARISON ONLY)  -- §75–§76
        ↓
Task14                          -- §70 principal names, §78 axiom report
```

No module imports a later one; in particular the generic-axis modules are imported only
*after* the independent two-axis result, as §35 requires.

## 7. Independent second-axis reconstruction report
(**INDEPENDENT SECOND-AXIS DERIVATION**)

The `B`-axis system is built from `W`, the inherited old spatial subspace `Rest`, the
inherited form `dot3`, the associative product, the exact centre and the minimal-carrier
structure — never by conjugating the `A`-axis formulas.

1. **Old-space decomposition (§9).** `LongB := span{B}`, `TransB := {v ∈ Rest | h(v,B) = 0}`.
   `second_axis_decomposition` proves `LongB ⊓ TransB = ⊥` and `LongB ⊔ TransB = Rest`;
   `finrank_LongB = 1`, `finrank_TransB = 2` (`SecondAxisOldStructure`). The ordered basis
   of `TransB` is *not* part of the definition: `TransB_eq_span` and
   `dirA_dirC_linearIndependent` derive that `A, C` span it, from the inherited
   orthogonality relations.
2. **Old transformation (§10).** `rotB φ` fixes the old temporal unit and `B`, preserves
   `Rest`, `TransB` and `dot3`, is nontrivial on `TransB`, and satisfies
   `rotB 0 = id`, `rotB (φ+χ) = rotB φ ∘ rotB χ` — packaged as
   `rotB_isSecondAxisOldFamily : IsSecondAxisOldFamily rotB`.
3. **Extension (§11).** `secondAxisExtension_unique` and
   `second_axis_extension_exists_unique` prove there is exactly one unital multiplicative
   extension `PhiB φ` of `rotB φ`; `PhiB_zero`, `PhiB_add` give the group law (both derived
   from the uniqueness theorem, not from a formula), and `second_axis_basis_table` gives
   the complete action

   | `x` | `PhiB φ x` |
   | --- | --- |
   | `1` | `1` |
   | `A` | `cos φ · A − sin φ · C` |
   | `B` | `B` |
   | `C` | `sin φ · A + cos φ · C` |
   | `P` | `cos φ · P + sin φ · R` |
   | `Q` | `Q` |
   | `R` | `−sin φ · P + cos φ · R` |
   | `S` | `S` |

   This table is *derived*; it is not the A-axis table relabelled (the fixed noncentral
   direction is `Q`, not `R`).
4. **Internal implementation (§12–§13).** The unrestricted problem `IsBLift` prescribes no
   subspace, no normalization and no half-angle. `second_axis_forced_plane` proves the
   smallest product-closed subspace containing a reference family is exactly
   `span{1, Q}`, of real dimension two, and `wQ_sq : Q ⋆ Q = −1` is derived.
   `second_axis_half_angle_forced` derives the half-parameter constraint from the
   conjugation requirement; only then is `UBref φ = cos(φ/2)·1 + sin(φ/2)·Q` introduced
   and verified (`UBref_isBLift`). The derived generator is `GB = (1/2)·Q`
   (`hasDerivAt_UBref_zero`), with `GB ⋆ GB = −(1/4)·1`.
5. **Lift freedom (§14).** `bLift_relative_central` proves that any two implementations of
   the same `PhiB φ` differ by a factor in the **exact centre**, using the Task-11 theorem
   `center_eq_Z` explicitly; `bLift_relative_factor` is the factorized form. The answer is
   *not* imported from the A-axis result.

## 8. Orientation / sign audit

| Datum | Status |
| --- | --- |
| ordering of `A,B,C` | **INHERITED** (Task 08 basis) |
| sign of `S` | **CHOICE**: `central_sign_audit` proves `−S` satisfies the same defining relations (central, square `−1`) |
| orientation of each axial parameter | **CHOICE**: `second_axis_orientation_branches` proves `rotB` and `φ ↦ rotB(−φ)` both satisfy the complete inherited requirement list and are different families |
| sign of each infinitesimal implementer | tied to the previous two: `orientation_global_sign` proves reversing `S` reverses *all* axis generators simultaneously; `per_axis_sign_is_axis_reversal` proves a per-axis sign flip is exactly the relabeling `n ↦ −n` |
| sign relating the mixed commutator to the third axis | **FORCED up to one relation**: `generator_sign_classification` proves `[εA GA, εB GB] = εC GC ↔ εA εB = εC` |

No sign discrepancy is absorbed by renaming; the branch used from §10 onwards is recorded
as a documented convention.

## 9. Second-axis carrier result (§15–§18)

For `H_{B,±} := {ψ | B ψ = ±ψ}` and `K_{B,±}(L) := L ⊓ H_{B,±}`:

* `second_axis_carrier_split` — for every minimal `L`: `K_{B,+} ⊓ K_{B,−} = ⊥` and
  `K_{B,+} ⊔ K_{B,−} = L`;
* `second_axis_slice_dimensions` — both slices are **two-dimensional** (proved from the
  relations `B² = 1`, `A B = −B A` for this axis, not inferred from the A-axis theorem);
* `second_axis_slices_central_lines` — each slice is exactly the set of central multiples
  of any one of its nonzero elements: exact `Z`-rank one, no preferred generator;
* `second_axis_action_plus_exact` / `second_axis_action_minus_exact` — the reduced action
  is multiplication by `cBplus φ = cos(φ/2)·1 − sin(φ/2)·S` resp.
  `cBminus φ = cos(φ/2)·1 + sin(φ/2)·S`;
* `second_axis_relative_action_exact` — the relative factor is `RelB φ = cos φ·1 − sin φ·S`,
  and it is unique;
* `second_axis_relative_action_independent` — the relative factor is independent of the
  carrier, of the chosen implementation and of the residual central freedom;
* `second_axis_matches_first_axis` — **only after** the independent derivation:
  `cBplus = cPlusRef`, `cBminus = cMinusRef`, `RelB = RelRef`. The identity is **DERIVED**
  (different sector relations, different implementer planes), not conventional.

## 10. Two-axis slice comparison (§19–§20)

`two_axis_slice_intersections` — for **every** carrier `L`,

| | `K_{B,+}` | `K_{B,−}` |
| --- | --- | --- |
| `K_{A,+}` | `⊥` | `⊥` |
| `K_{A,−}` | `⊥` | `⊥` |

with the exceptional coincidence recorded separately: for one and the same axis the
intersection is the whole slice, of dimension two (`same_axis_slice_intersection`).
`two_axis_decompositions_transverse` states the two `2+2` decompositions of one carrier
share no nonzero vector. The generic criterion is
`generic_mixed_intersection_zero`: for unit `n, m` the slices `K_{n,σ} ∩ K_{m,τ}` vanish
unless `h(n,m) = στ`, which by `eq_of_h3_eq_one` / `eq_neg_of_h3_eq_neg_one` forces
`n = ±m`.

## 11. Mixed-projector algebra (§21–§23)

Projectors are introduced only after their properties are proved:
`ep n := (1/2)(1 + n)`, `em n := (1/2)(1 − n)`.

`mixed_projector_data` collects: idempotency of all four, `ep ⋆ em = 0`, `ep + em = 1`, the
derived mixed sandwich coefficients

```
(e_{A,+} e_{B,+}) e_{A,+} = (1/2) e_{A,+},   (e_{B,+} e_{A,+}) e_{B,+} = (1/2) e_{B,+},
```

and `finrank (K_{A,+} L) = finrank (K_{B,+} L)` obtained from an explicit linear
equivalence `mixedEquiv` built from `2 • (ep m ⋆ ·)`. `mixed_composition_nonzero` shows the
mixed composition is nonzero; `mixed_left_inverse` shows it is invertible between the two
central lines. Coefficients are never called amplitudes and no probability reading occurs.

## 12. Finite-composition report (§24–§25, §42–§43)

* **Automorphisms, order dependence.** `mixed_automorphisms_commute_iff`:
  `Φ^A_θ ∘ Φ^B_φ = Φ^B_φ ∘ Φ^A_θ` **iff** `(sin θ = 0 ∧ sin φ = 0) ∨ cos θ = 1 ∨ cos φ = 1`.
  This is a complete classification, not a single counterexample;
  `mixed_automorphisms_order_dependent_example` and `half_turns_commute` are the two
  extreme cases. Status: **ORDER DEPENDENT**.
* **Internal products.** `UA_UB_product`, `UB_UA_product` and
  `mixed_reference_product_difference`:

  ```
  U_A(θ) U_B(φ) − U_B(φ) U_A(θ) = −2 sin(θ/2) sin(φ/2) · P.
  ```

* **Generic products.** `generic_reference_product_shape`:

  ```
  U_n(θ) U_m(φ) = (cos(θ/2)cos(φ/2) − sin(θ/2)sin(φ/2) h(n,m))·1
                  − J( cos(θ/2)sin(φ/2) m + sin(θ/2)cos(φ/2) n
                       + sin(θ/2)sin(φ/2) (n×m) ),
  ```

  where `×` is the emergent operation `spCross` of §33 — no axis-angle formula was
  inserted.
* **Closure.** `qnrm` (the sum of the four occupied coordinates squared) is multiplicative
  on `ImplAlg` (`qnrm_mul`), every reference implementation has `qnrm = 1` (`qnrm_Un`), and
  `exists_axis_repr` proves every unit element of `ImplAlg` **is** some `U_k(ψ)`. Hence
  `generic_reference_composition_closes`: the product of two arbitrary-axis reference
  implementations is again a single reference implementation. Status: **CLOSED**, with no
  extra noncentral degree of freedom.

## 13. Infinitesimal-closure report (§27–§30)

Derived generators (as derivatives at the zero parameter, not postulated):
`GA = −(1/2)·R`, `GB = (1/2)·Q`, `GC = −(1/2)·P`.

```
GA GB = −(1/4)P      GB GA = (1/4)P      GA GB + GB GA = 0
[GA,GB] = GC        [GB,GC] = GA        [GC,GA] = GB
GA² = GB² = GC² = −(1/4)·1
```

`commutator_not_central` proves `GC ∉ Z`: the commutator produces a genuinely new
noncentral direction, reconstructed intrinsically. `infinitesimal_closure` proves the
system closes with **no** further generators. `third_axis_relation` compares the third
direction with the inherited old spatial direction `C` *without identifying them by name*:

```
GA = −(1/2)(S ⋆ A),  GB = −(1/2)(S ⋆ B),  GC = −(1/2)(S ⋆ C),
```

so the commutator direction is exactly the one attached to the inherited third old spatial
direction, with the sign and normalization stated. `generator_sign_classification` fixes
the admissible sign patterns (§8 above).

## 14. Minimal implementer-algebra classification (§26)

`ImplAlg = span{1, P, Q, R}` (given by coordinates, not by a spanning set):

* **spanning set / normal form** — `mem_ImplAlg_iff`: `x = a·1 + b·P + c·Q + d·R`;
* **closure** — `ImplAlg_productClosed`;
* **multiplication table** — `qelt_mul`:

  ```
  (a,b,c,d)(a',b',c',d') =
    ( aa' − bb' − cc' − dd',
      ab' + ba' − cd' + dc',
      ac' + ca' + bd' − db',
      ad' + da' − bc' + cb' );
  ```

* **real dimension** — `finrank_ImplAlg = 4`;
* **minimality** — `ImplAlg_minimal`: every product-closed subspace containing both
  reference families contains `ImplAlg`;
* **centre inside the subalgebra** — `ImplAlg_center`: the elements of `ImplAlg` commuting
  with all of `ImplAlg` are exactly the real multiples of `1`, and `S ∉ ImplAlg`. Thus the
  exact centre `Z` of `W` is **not** contained in the implementer algebra.

## 15. Generic axis-generator theorem (§31–§35)

`Jmap n := n₁·R − n₂·Q + n₃·P`, derived from the three basis-axis cases
(`Jmap_basis_cases`), not defined by a conventional formula.

| Question | Result |
| --- | --- |
| exists? | yes, `Jmap` / `JmapL : Vec3 →ₗ[ℝ] W` |
| linear? | yes, `Jmap_linear` (additive and homogeneous) |
| `J(n)²` | `Jmap_sq : J(n)² = −h(n,n)·1` |
| symmetric product | `Jmap_symmetric_product : J(n)J(m) + J(m)J(n) = −2h(n,m)·1` |
| antisymmetric product | `Jmap_antisymmetric_product : J(n)J(m) − J(m)J(n) = −2 J(n×m)` |
| full product | `Jmap_mul : J(n)J(m) = −h(n,m)·1 − J(n×m)` |
| emergent operation | `spCross`, defined only **after** the antisymmetric relation was derived |
| late identification | `Jmap_eq_central_mul : J(n) = S ⋆ n` (an **output**, stated after the basis reconstruction and the linearity proof) |

## 16. Arbitrary-axis carrier theorem (§36–§39)

For every unit `n` (`IsUnitAxis n : h(n,n) = 1`) and every minimal carrier `L`:

* `generic_carrier_split` — `K_{n,+} ⊓ K_{n,−} = ⊥`, `K_{n,+} ⊔ K_{n,−} = L`, both of
  dimension two;
* `generic_slices_central_lines` — each slice is one line over the exact centre `Z`;
* `Un n θ := cos(θ/2)·1 − sin(θ/2)·J(n)` with `Un_group`, `Un_mul_neg`, `Un_neg_mul`,
  `PhiGen_unital`, `PhiGen_mul`, `PhiGen_group` — group law, invertibility, implementation
  of the automorphism;
* `generic_preserves_slices` — every minimal carrier and both slices are preserved;
* `generic_action_exact` — the reduced action is by `cPlusRef θ` and `cMinusRef θ`;
* `generic_relative_action_universal` — the relative factor is `RelRef θ` for **every**
  axis, carrier and parameter.

**Verdict: UNIVERSAL ALL-AXIS RELATIVE LAW.**

## 17. Reference word-defect classification (§44–§46)

* `Implements u ui F` — an internal element implementing an algebra automorphism by
  conjugation, with a two-sided inverse; `Implements.mul` proves conjugation by a product
  of implementers is the composition of automorphisms (§44), and `word_implements` extends
  this to words `wordVal l` with automorphism `wordAut l`;
* `implements_defect_mem_Z` (§45) — **any** two implementations of the same automorphism
  differ by an element of the **exact centre** `Z` (Task-11 `center_eq_Z` is the only
  external input). It is **not** assumed to be `±1`;
* `reference_word_defect` (§46) — for words built from the reference axis implementations
  the defect satisfies `qnrm = 1` and lies in `Z ∩ ImplAlg = ℝ·1` (`Z_inter_ImplAlg`),
  hence equals `+1` or `−1`;
* `reference_word_defect_set_exact` — the defect set is **exactly** `{1, −1}`: both occur,
  the value `−1` realized by `reference_word_defect_minus_one_realized` (the full-parameter
  one-axis word, `U_n(2π) = −1`, `Φ_n(2π) = id`).

Status: **REFERENCE DEFECT** = `{+1, −1}`, exactly.

## 18. Full-lift residual-freedom classification (§47–§48)

* `axis_lift_iff` — an element implements `Φ_n(θ)` **iff** it is `z ⋆ U_n(θ)` with `z` an
  invertible element of `Z` (both directions proved; `central_inv_mem_Z` shows the inverse
  of a central element is central);
* `mixed_full_lift_product` — independent per-axis residuals combine into **one common**
  central factor: `(z U_n(θ))(z' U_m(φ)) = (z z')(U_n(θ) U_m(φ))`. No relation between the
  residuals of different axes is required, and none is produced;
* `full_lift_defect_exact` — the full-lift defect set is the whole set of invertible
  central elements: for every `(a,b) ≠ (0,0)` there are two implementations of the same
  automorphism with defect exactly `zz a b`;
* `full_lift_defect_not_pm_one` — explicitly, defect `2·1` occurs: strictly more than
  `{±1}`;
* `full_lift_relative_invisible` — for **every** axis and residual the two sector factors
  are the reference ones multiplied by the *same* residual, so the relative sector law is
  unchanged;
* `multi_axis_residual_freedom_verdict` (§48, the central negative control) — the three
  statements above, packaged. Independent per-axis central choices **neither cancel nor
  obstruct**: they combine into a single common central factor, remain invisible to the
  relative sector action, and remain visible as an absolute central defect.

Status: **COMMON CENTRAL FREEDOM**; one-axis invisible freedom stays invisible *relatively*
and stays visible *absolutely*; **no** compatibility relation between axes is forced.

## 19. Coherent-lift existence / obstruction result (§49–§51)

`coherent_lift_obstructed` — there is **no** assignment `U` of internal implementers to the
implementable algebra automorphisms with `U(g ∘ h) = U(g) U(h)`.

The obstruction is derived, not assumed:

1. `half_turn_automorphisms_commute` — `Φ_A(π)` and `Φ_B(π)` commute (proved algebraically
   from `J(A)J(B) = −J(B)J(A)`, the sign being central and hence invisible on
   automorphisms);
2. `half_turn_implementers_anticommute` — **every** pair of implementers of these two
   automorphisms, carrying arbitrary central residuals, satisfies `u v = −(v u)`;
3. multiplicativity would force `u v = v u`, hence `u v = 0`, contradicting
   `implements_ne_zero`.

Status: **AUTOMORPHISMS CLOSE BUT INTERNAL IMPLEMENTATIONS HAVE CENTRAL DEFECT**; a
globally multiplicative coherent assignment is **OBSTRUCTED**. Nothing is quotiented away
(§51): no section is normalized, and no central factor is discarded.

## 20. Path-independence audit (§52–§54)

* `closedPath = [(A,π), (B,π), (A,π), (B,π)]`;
* `closed_path_internal_residual` — `wordAut closedPath = id` while
  `wordVal closedPath = −1`;
* `path_dependence_explicit` — the empty word and `closedPath` induce the *same*
  automorphism with internal implementations `1` and `−1`: exact central discrepancy `−1`.

Status: **PATH DEPENDENT**, with defect exactly `−1` (a reference defect; by §17 no other
value is possible for reference words).

Three closure notions are kept separate (`three_closure_notions`, §54):

| | statement | status |
| --- | --- | --- |
| A | implementable automorphisms are closed under composition (`isImplementable_comp`) | **CLOSED** |
| B | reference implementations close (`generic_reference_composition_closes`) | **CLOSED** |
| C | arbitrary full implementations close only up to a central factor (`mixed_full_lift_product`) | **CLOSED UP TO CENTRAL DEFECT** |

A positive answer for one is never used to obtain another.

## 21. Multi-axis carrier-equivalence report (§55–§56)

* `word_action_intertwined` — a Task-12 carrier equivalence (right multiplication)
  commutes with the left action of **every** mixed word; `full_lift_action_intertwined` is
  the same for arbitrary full implementations. Both are associativity, applied to words of
  arbitrary length — not inferred from the single-axis theorem;
* `carrier_equiv_matches_generic_slices` — the equivalence matches the two slices of
  **every** unit axis;
* `multi_axis_carrier_type` — one and the same equivalence does all of this at once, and
  both carriers carry the same exact sector factors for every axis.

**Verdict: UNIVERSAL MULTI-AXIS CARRIER TYPE.**

## 22. Carrier-family mixed-action report (§57–§58)

The Task-13 sphere parametrization is used only as an already proved coordinate theorem.
The action on it is **derived**:

* `conj_spat_raw` — a constraint-free algebraic identity: for arbitrary reals `c, s` and
  arbitrary `n, p`,

  ```
  (c·1 − s·J(n)) p (c·1 + s·J(n))
     = (c² − s² h(n,n))·p + 2cs·(n×p) + 2s² h(n,p)·n ;
  ```

* `PhiGen_spat` — for a unit axis this becomes `Φ_n(θ)(p) = rotv n θ p` with

  ```
  rotv n θ p = cos θ · p + sin θ · (n×p) + (1 − cos θ) h(n,p) · n ;
  ```

  the whole-parameter coefficients emerge from the half-parameter ones through the
  standard double-parameter identities;
* `rotv_preserves_form` — the derived coordinate action preserves `h`, proved from
  multiplicativity of the automorphism and `spat_sq` (so the sphere family is preserved,
  rather than assumed to be);
* `PhiGen_map_Lgen`, `generic_carrier_family_action` — on carriers:
  `Φ_n(θ)(L_{esph p}) = L_{esph (rotv n θ p)}`;
* `secondAxis_carrier_family_action` — the explicit second-axis coordinate action
  `(p₁,p₂,p₃) ↦ (cos φ p₁ + sin φ p₃, p₂, cos φ p₃ − sin φ p₁)`;
* `mixed_carrier_family_action` — the two independently reconstructed actions compose by
  composing the coordinate actions.

## 23. Common fixed-locus theorem (§59)

* `generic_fixed_carrier_iff` — for unit `n` and a sphere point `p`, the carrier
  `L_{esph p}` is fixed by the whole `n`-family **iff** `p = n` or `p = −n`;
* `no_common_fixed_carrier` — for unit `n, m` with `n ≠ m` and `n ≠ −m`, **no** minimal
  left carrier is fixed by both families;
* `one_axis_fixed_locus_moved` — each of the two carriers fixed by one axis is moved by the
  other.

**Verdict: NO COMMON FIXED CARRIER.**

## 24. Selection verdict (§60)

`two_axis_selection_verdict` — two independently reconstructed nonparallel axes select
**none**: the one-axis two-point fixed locus is *not* narrowed to one carrier; it is
destroyed, since neither of its two members survives the second family and no other
carrier is fixed by both. No interpretation as selection of a state is attached
(**NOT PHYSICAL SPIN**).

Related audits:

* **Rate (§65).** `rate_freedom_axis_local` — axis-locally every nonzero rescaling of the
  parameter still gives a one-parameter family implementing the corresponding
  automorphisms: **RATE-DEPENDENT** data at the level of one axis. The Task-10 separation
  of the automorphism rate `λ` from the internal residual is retained.
* **Isotropy (§66).** `isotropy_forces_common_rate` — if the axis-generator assignment is
  the *linear* map of §31–§32 and is a real multiple of `J(n)` on each unit axis, the
  multiples on `A`, `B` and their diagonal coincide: the inherited spatial structure
  **does** force one common normalization. This is distinct from central lift freedom.
* **Orientation (§67).** `orientation_global_sign`, `per_axis_sign_is_axis_reversal`,
  `generator_sign_classification` — one global orientation choice controls all axis signs;
  a per-axis sign is the relabeling `n ↦ −n`.

## 25. Conservation-of-Difficulty report (§71)

| # | Question | Answer | Theorem |
| --- | --- | --- | --- |
| 1 | Second axis without first-axis covariance? | Yes | §7 chain, `rotB_isSecondAxisOldFamily`, `second_axis_extension_exists_unique` |
| 2 | Reduced carrier action structurally identical to the first axis? | Yes | `second_axis_matches_first_axis` |
| 3 | Derived or conventional? | **DERIVED** (different sector relations, different implementer plane) | `second_axis_action_plus_exact`, `second_axis_forced_plane` |
| 4 | Smallest product-closed algebra containing two axis implementations? | `span{1,P,Q,R}`, dimension 4 | `ImplAlg_minimal`, `finrank_ImplAlg` |
| 5 | Do distinct axis implementations commute? | No | `mixed_reference_product_difference` |
| 6 | What does their commutator generate? | The third noncentral direction `P` | `mixed_commutator`, `commutator_not_central` |
| 7 | Does the infinitesimal system close? | Yes, no new generators | `infinitesimal_closure` |
| 8 | Third axis forced? | Yes | `mixed_commutator` |
| 9 | Sign/orientation of it fixed? | Fixed up to one relation `εA εB = εC` | `generator_sign_classification` |
| 10 | Intrinsic axis-to-generator map? | Yes, `Jmap` | `Jmap_basis_cases` |
| 11 | Linear? | Yes | `Jmap_linear` |
| 12 | `J(n)²`? | `−h(n,n)·1` | `Jmap_sq` |
| 13 | Symmetric / antisymmetric products? | `−2h(n,m)·1` and `−2 J(n×m)` | `Jmap_symmetric_product`, `Jmap_antisymmetric_product` |
| 14 | Same `2+2` carrier structure for every unit direction? | Yes | `generic_carrier_split` |
| 15 | Relative `±` law axis-independent? | Yes — **UNIVERSAL ALL-AXIS RELATIVE LAW** | `generic_relative_action_universal` |
| 16 | Do finite mixed reference implementations close? | Yes | `generic_reference_composition_closes` |
| 17 | Same automorphism ⇒ central discrepancy? | Yes, always | `implements_defect_mem_Z` |
| 18 | Which central elements for reference words? | Exactly `{1, −1}` | `reference_word_defect_set_exact` |
| 19 | What changes with arbitrary per-axis lift freedom? | Defect set becomes all invertible central elements | `full_lift_defect_exact` |
| 20 | Does one-axis invisible freedom stay invisible? | Invisible relatively, visible absolutely | `multi_axis_residual_freedom_verdict` |
| 21 | Globally multiplicative coherent assignment? | **No** | `coherent_lift_obstructed` |
| 22 | Exact composition defect? | Central; for reference words exactly `±1` | `implements_defect_mem_Z`, `reference_word_defect_set_exact` |
| 23 | Explicit closed paths with nontrivial residual? | Yes, residual `−1` | `closed_path_internal_residual` |
| 24 | Mixed-axis transformation carrier-independent? | Yes | `multi_axis_carrier_type` |
| 25 | Second-axis action on the sphere coordinates? | Derived `rotv`, explicit `B` case | `generic_carrier_family_action`, `secondAxis_carrier_family_action` |
| 26 | Common globally fixed carriers for nonparallel axes? | **None** | `no_common_fixed_carrier` |
| 27 | Does a second axis resolve the two-point ambiguity? | It removes it: none selected | `two_axis_selection_verdict` |
| 28 | Does isotropy force a common generator rate? | Yes, for a linear assignment | `isotropy_forces_common_rate` |
| 29 | One global orientation controlling all signs? | Yes | `orientation_global_sign` |
| 30 | New data required for multi-axis gluing? | **None beyond the inherited data** for the automorphisms and the reference implementations; a *choice* of section is unavoidable, and it necessarily fails to be multiplicative | `three_closure_notions`, `coherent_lift_obstructed` |

**Overall outcome labels (§72):**
`MULTI-AXIS CLOSURE DERIVED WITHOUT NEW DATA` (automorphisms and reference
implementations), together with
`AUTOMORPHISMS CLOSE BUT INTERNAL IMPLEMENTATIONS HAVE CENTRAL DEFECT`,
`PATH DEPENDENCE REMAINS` (defect `−1`), and
`NO COMMON FIXED CARRIER FOR NONPARALLEL AXES`.

## 26. Late conventional comparison (COMPARISON ONLY, §75–§76)

`Identification.lean`, imported only by `Task14.lean`:

* `comparison_implementer_relations` — `P² = Q² = R² = −1`, `PQ = −R`, `QP = R`,
  `QR = −P`, `RQ = P`, `RP = −Q`, `PR = Q`: the conventional unit-quaternion relations in
  the left-handed sign convention;
* `comparison_implementer_algebra` — dimension 4, product-closed, contains every reference
  implementation;
* `comparison_bracket_relations` — the derived brackets are those of the conventional
  three-dimensional rotation Lie algebra;
* `comparison_double_cover` — `U_n(2π) = −1`, `U_n(4π) = 1`, `Φ_n(2π) = id`;
  `comparison_closed_path` — the closed mixed path has residual `−1`: conventional
  double-cover behaviour, here obtained purely algebraically;
* `comparison_residual_larger_than_sign` — what does **not** correspond: the residual
  freedom of arbitrary implementations is the whole group of invertible central elements,
  not `±1`, and nothing is identified projectively.

Permitted conclusion (`comparison_summary`): *the independently reconstructed
minimal-carrier action closes algebraically across spatial axes and is equivalent, in this
late comparison, to the standard full spatial spinorial rotation structure.*
**NOT PHYSICAL SPIN**: no fermion, observable, measurement or angular momentum is derived.

## 27. Build report

```
$ lake build
Build completed successfully.
```

* All Task-14 modules are default targets (`lakefile.toml` glob `RequestProject.+`).
* No `sorry`, no `admit`, no `axiom`, no `@[implemented_by]` occurs in any Task-14 file
  (checked by search over `RequestProject/NullSectorTask14/`).
* Files: 22 reconstruction/comparison modules plus `Task14.lean`.

## 28. Axiom report (§78)

`#print axioms` is run in `Task14.lean` for the principal theorems covering second-axis
reconstruction, mixed composition, the mixed commutator, the minimal implementer algebra,
the axis-generator map, generic-axis reconstruction, the word-defect theorems, the
coherence obstruction, multi-axis carrier universality, the common fixed locus and the
selection verdict. Every one reports exactly

```
[propext, Classical.choice, Quot.sound]
```

— the three standard Lean/Mathlib axioms. No custom axiom and no `native_decide` is used.

## 29. Unresolved mathematical obligations

1. **Only reference sections are classified globally.** `coherent_lift_obstructed` rules out
   an exactly multiplicative assignment; the *complete* classification of all possible
   sections `g ↦ U(g)` modulo central rescaling (the full set of composition defects
   `c(g,h) ∈ Z` realizable by *some* section) is not carried out here. Only its two
   extreme cases — reference words (`{±1}`) and arbitrary per-axis lifts (all invertible
   central elements) — are settled.
2. **Words are not classified up to relations.** `wordAut` and `wordVal` are studied
   through their values; a presentation of the group generated by the axis automorphisms
   is not derived.
3. **Continuity/differentiability of arbitrary lifts across axes.** The residual central
   factors are classified pointwise in the parameter; no continuity is imposed or derived
   for the multi-axis case (single-axis continuity is Task 11).
4. **The rate audit is settled only for linear assignments.** `isotropy_forces_common_rate`
   assumes linearity of the axis-generator assignment (as derived in §31–§32); the
   nonlinear alternatives are not classified.
5. **Nonparallel-axis intersections in degenerate configurations.** The generic criterion
   `generic_mixed_intersection_zero` covers `h(n,m) ≠ στ`; the borderline case `n = ±m` is
   recorded as the exceptional coincidence but its carrier-level consequences are only
   given for the basis pair.
6. **Optional additional compatibility tests (§74).** The Task-09 `N₊`/`N₋` preservation
   tests were *not* applied to the multi-axis system; they remain available as
   **ADDITIONAL COMPATIBILITY** conditions and are not part of the inherited data.
