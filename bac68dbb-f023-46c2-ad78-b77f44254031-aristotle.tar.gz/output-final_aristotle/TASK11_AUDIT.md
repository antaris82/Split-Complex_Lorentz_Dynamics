# TASK 11 AUDIT
## Split-Complex Lorentz Dynamics — Experiment 2, Task 11
### Hardening the axial lift: full-carrier classification, central freedom, continuity, and infinitesimal separation

This audit documents the formal Lean development in
`RequestProject/NullSectorTask11/`.  Every claim below is backed by a
machine-checked theorem; the theorem name and its module are given in each case.

Status vocabulary used throughout (§38):
`INHERITED`, `DERIVED`, `FULL-CARRIER LIFT`, `ALGEBRAIC FREEDOM`,
`CONTINUOUS FREEDOM`, `CENTRAL FREEDOM`, `VISIBLE GENERATOR`,
`INVISIBLE GENERATOR COMPONENT`, `CONDITIONAL COMPATIBILITY`, `NOT INHERITED`,
`NORMALIZATION NOT ASSUMED`, `NORMALIZATION DERIVED CONDITIONALLY`,
`RATE FREEDOM`, `UNRESOLVED`, `COMPARISON ONLY`.

---

## 1. Exact toolchain

| Item | Value |
| --- | --- |
| Lean toolchain | `leanprover/lean4:v4.28.0` (file `lean-toolchain`) |
| Mathlib | `v4.28.0`, commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (file `lake-manifest.json`) |
| Build target | `RequestProject` library (`lakefile.toml`, globs `RequestProject.+`) |
| Build command | `lake build` |

No toolchain change was made for Task 11; the environment is exactly the
cumulative Experiment-2 environment.

Every Task-11 module imports (transitively) the whole of Mathlib, as do all
earlier modules of the project.

---

## 2. Source ledger

**IMPORTED STANDARD RESULT (Mathlib).**  Only ordinary real analysis and
elementary algebra are used.  The declarations actually relied on, with the
module in which they are used:

| Declaration | Used in |
| --- | --- |
| `intervalIntegral.integral_hasDerivAt_right` | `ContinuousClassification.lean` |
| `intervalIntegral.intervalIntegral_pos_of_pos_on` | `ContinuousClassification.lean` |
| `intervalIntegral.integral_comp_add_left`, `integral_interval_sub_left`, `integral_add`, `integral_sub`, `integral_const_mul` | `ContinuousClassification.lean` |
| `is_const_of_deriv_eq_zero` | `ContinuousClassification.lean` |
| `HasDerivAt.exp`, `HasDerivAt.cos`, `HasDerivAt.sin`, `HasDerivAt.mul`, `HasDerivAt.smul_const`, `HasDerivAt.add`, `HasDerivAt.neg`, `HasDerivAt.deriv` | `ContinuousClassification.lean`, `InfinitesimalLift.lean` |
| `Real.exp_add`, `Real.exp_ne_zero`, `Real.exp_pos`, `Real.exp_eq_one_iff`, `Real.sin_sq_add_cos_sq`, `Real.cos_add`, `Real.sin_add`, `Real.sin_pi_div_two` | several |
| `Submodule.exists_isCompl`, `Submodule.linearProjOfIsCompl`, `Submodule.linearProjOfIsCompl_apply_left/right`, `irrational_sqrt_two` | `ContinuousClassification.lean` (§20 discontinuous witness) |
| `Complex.exp_add_mul_I`, `Complex.norm_exp`, `Complex.I_sq`, `Matrix.det_fin_two_of`, `Matrix.det_mul`, `Matrix.det_smul` | `Identification.lean` (**COMPARISON ONLY**) |

**INHERITED (Experiment 2, Tasks 08–10).**  See §3.

**DERIVED IN TASK 11.**  Everything listed in §§7–22 below.

For the standard mathematics used (one-parameter subgroups of a
two-dimensional commutative real algebra; continuous solutions of a bilinear
recursion; existence of a discontinuous additive function on ℝ using a
Hamel-type complement) no source beyond Mathlib is cited, because the
development proves these statements itself in the intrinsic basis rather than
importing them.

---

## 3. Exact Task-09 / Task-10 imports

Import graph of the Task-11 modules (`grep -n '^import'`):

```
SafeBase                 ← RequestProject.NullSectorTask10.AlgebraExtension
CenterRigidity           ← Task11.SafeBase
FullLift                 ← Task11.CenterRigidity
RelativeLiftRigidity     ← Task11.FullLift
ReferenceExistence       ← Task11.RelativeLiftRigidity, RequestProject.NullSectorTask10.InternalLift
ExactLiftClassification  ← Task11.ReferenceExistence
ContinuousClassification ← Task11.ExactLiftClassification
PeriodicityAudit         ← Task11.ContinuousClassification
QuadraticCompatibility   ← Task11.PeriodicityAudit
InfinitesimalLift        ← Task11.QuadraticCompatibility
GeneratorSeparation      ← Task11.InfinitesimalLift, RequestProject.NullSectorTask10.AxialDerivation
Identification           ← Task11.GeneratorSeparation, Task10.Identification, Task08.Identification
Task11                   ← Task11.Identification
```

Inherited data actually used:

* **Task 08** — the carrier `W`, the bilinear product `⋆`, the unit `w1`,
  associativity, the eight derived basis elements `w1, wA, wB, wC, wP, wQ, wR,
  wS` and the complete multiplication table.
* **Task 09** — the central two-plane `Z = spanℝ{w1, wS}`, `wS ⋆ wS = -w1`,
  `Z_central`, `Z_coeff_unique`, `central_mul_rule`; the coefficient functions
  `nRe`, `nSc` with their multiplicativity, and the two quadratic branches
  `Ncand 1`, `Ncand (-1)` — the latter used **only** in the conditional layer.
* **Task 10** — the axial algebra-automorphism family `Phi` with `Phi_zero`,
  `Phi_add`, `Phi_two_pi`; the two-plane `K = spanℝ{w1, wR}` and `ksc` (used
  only to *state* the §16 comparison); the explicit lift `Ustd` with
  `Ustd_zero`, `Ustd_group`, `Ustd_conj`, `Ustd_two_pi`, `Ustd_four_pi`,
  `nRe_Ustd`, `nSc_Ustd`; the derivation generator `Dgen` with
  `Dgen_eq_half_commutator` and `hasDerivAt_Phi_zero`, and the Task-10 rate
  classification `axialDerivation_classification`.

Nothing stronger about internal implementers is assumed anywhere.

---

## 4. Experiment-1 firewall

No construction, theorem, formula, source, terminology, repository content or
result of Experiment 1 is used.  Task 11 imports only modules of the cumulative
Experiment-2 development listed in §3.  The Task-11 modules were scanned for
Experiment-1 identifiers; there are none.

---

## 5. Physical-target firewall

The forbidden target vocabulary of §2 of the task (`spin`, `spin-1`,
`spin-1/2`, `spinor`, `fermion`, `photon`, `Maxwell`, `Dirac`, `Weyl`, `Pauli`,
`helicity`, `polarization`, `wavefunction`, `quantum state`, `unitarity`,
`Hilbert space`, `probability`, `Hamiltonian`, `energy`, `frequency`, `mass`,
`Schrödinger evolution`, `gauge symmetry`) occurs in **no** Task-11 module as a
definition, a theorem name, an import or a target.

A mechanical scan (`rg -in` over `RequestProject/NullSectorTask11/`) returns
matches only in two places, both of which are *firewall declarations in prose*:
`ReferenceExistence.lean` line 13 ("It is not called a rotor, a spin lift or a
unitary transformation") and the firewall paragraphs of `SafeBase.lean`.  No
identifier, statement or proof uses these notions.

The generator `G` of §28 is never called a Hamiltonian, and `θ` is never called
a time.

---

## 6. Conventional-algebra firewall

`Complex`, `ℂ`, `M₂(ℂ)`, `Matrix`, determinant, complex phase, projective
representation, unitary group, `Spin` group, `SU(2)` and Clifford-group notions
appear in **exactly one** Task-11 module, `Identification.lean`, which is
labelled `COMPARISON ONLY` and is imported by nothing except the top-level
`Task11.lean`.  The Task-08/09/10 identification modules are imported at that
same single point and nowhere earlier: no reconstruction module of Task 11
imports any identification module.

In particular the exact center theorem, the relative-lift theorem, the
algebraic and continuous lift classifications, the periodicity audit, the
conditional compatibility layer and the generator separation are all proved on
the independently reconstructed real carrier `W`, without matrices and without
a complex-number identification.

---

## 7. Exact center theorem (§9)

**DERIVED.**

```lean
def CenterW : Set W := {z : W | ∀ x : W, z ⋆ x = x ⋆ z}

theorem center_eq_Z : CenterW = (Z : Set W)
theorem mem_center_iff (z : W) : z ∈ CenterW ↔ ∃ a b : ℝ, z = zc a b
```
(`CenterRigidity.lean`; `zc a b = a • w1 + b • wS` from `SafeBase.lean`.)

The center was **not** assumed to equal `Z`.  The proof follows the strategy
demanded by §9: an arbitrary `z : W` is written in the Task-08 basis,
commutation is imposed with a minimal generating set, the resulting coefficient
constraints are solved, and the surviving elements are then checked to commute
with all of `W` (`Z_central`, inherited).

**Smallest generating subset actually needed:** `{wA, wB}` — two generators, not
three.

```lean
theorem coords_of_comm_wA {z : W} (h : z ⋆ wA = wA ⋆ z) : z 2 = 0 ∧ z 3 = 0 ∧ z 4 = 0 ∧ z 5 = 0
theorem coords_of_comm_wB {z : W} (h : z ⋆ wB = wB ⋆ z) … : z 1 = 0 ∧ z 6 = 0
theorem centralizer_pair_eq_Z : CentralizerOf {wA, wB} = (Z : Set W)
```

Commutation with `wA` alone kills the coordinates of `wB, wC, wP, wQ`;
commutation with `wB` then kills those of `wA` and `wR`; the two surviving
coordinates are those of `w1` and `wS`.

---

## 8. Exact centralizer theorem (§10)

**DERIVED.**

```lean
def CentralizerOf (T : Set W) : Set W := {z : W | ∀ x ∈ T, z ⋆ x = x ⋆ z}

theorem centralizer_triple_eq_center : CentralizerOf {wA, wB, wC} = CenterW
theorem centralizer_pair_eq_Z        : CentralizerOf {wA, wB}     = (Z : Set W)
theorem centralizer_single_ne_center : CentralizerOf {wA}         ≠ CenterW
```

So the centralizer of the old generating triple **is** already the full center —
this was not assumed — and the two-element subset `{wA, wB}` already suffices.
The one-generator case is a genuine **negative control**: the centralizer of
`{wA}` is strictly larger than the center (`wA` itself commutes with `wA` but is
not central; cf. `wR_not_mem_center` for a second non-central element).

---

## 9. Arbitrary-full-lift definition (§6, §7, §8)

**FULL-CARRIER LIFT.**  The Task-10 restriction `U θ ∈ K` is removed completely;
`U : ℝ → W` is arbitrary and no membership in `K` or `Z` is assumed.

```lean
structure IsFullLift (U : ℝ → W) : Prop where
  unit  : U 0 = w1
  group : ∀ θ φ : ℝ, U (θ + φ) = U θ ⋆ U φ
  conj  : ∀ (θ : ℝ) (x : W), (U θ ⋆ x) ⋆ U (-θ) = Phi θ x

structure IsContinuousFullLift (U : ℝ → W) : Prop extends IsFullLift U where
  cont : Continuous U
```
(`FullLift.lean`.)

The two-sided inverse law is **derived** from the group law, not assumed:

```lean
theorem IsFullLift.mul_neg (θ : ℝ) : U θ ⋆ U (-θ) = w1
theorem IsFullLift.neg_mul (θ : ℝ) : U (-θ) ⋆ U θ = w1
```

together with the cancellation lemmas `inv_cancel_left`, `cancel_inv_left` and
`ne_zero`.  No external group-of-units structure is introduced.

Continuity (§8) is a *separate* predicate: it is never used to define a lift and
the algebraic classification never presupposes it.  Differentiability is **not**
used in the main classification (it appears only in the corollary layer §20 of
this audit).

---

## 10. Relative-lift theorem (§11–§14)

**DERIVED.**  For two arbitrary full lifts define the neutral relative element

```lean
noncomputable def rel (U V : ℝ → W) (θ : ℝ) : W := U θ ⋆ V (-θ)
```

Nothing is prescribed about it.  What follows from the two conjugation laws is
proved:

```lean
theorem rel_comm_image (θ : ℝ) (x : W) : rel U V θ ⋆ x = x ⋆ rel U V θ   -- commutes with everything
theorem rel_mem_center (θ : ℝ) : rel U V θ ∈ CenterW                     -- hence central, by §7
theorem rel_zero : rel U V 0 = w1
theorem rel_add (θ φ) : rel U V (θ + φ) = rel U V θ ⋆ rel U V φ
theorem rel_neg (θ) : rel U V θ ⋆ rel U V (-θ) = w1
```

The functional equation of §13 is therefore **derived, not assumed**: `z = rel U V`
satisfies `z 0 = 1`, `z (θ+φ) = z θ ⋆ z φ`, and `z (-θ)` is the two-sided inverse
of `z θ`.  This is packaged as

```lean
structure IsCentralHom (z : ℝ → W) : Prop where
  mem  : ∀ θ, z θ ∈ CenterW
  unit : z 0 = w1
  mul  : ∀ θ φ, z (θ + φ) = z θ ⋆ z φ
```

**Upper classification (§14), before any explicit witness:**

```lean
theorem fullLift_relative_classification {V : ℝ → W} (hV : IsFullLift V) (U : ℝ → W) :
    IsFullLift U ↔ ∃ z : ℝ → W, IsCentralHom z ∧ ∀ θ, U θ = z θ ⋆ V θ
```

together with

```lean
theorem residual_preserves_action …  -- every residual map preserves the implemented Φ-action
```

The theorem answers all three questions of §14: the residual map takes values in
the exact center, it satisfies the one-parameter multiplicative law, and every
such residual map preserves the implemented action.

---

## 11. First reference-lift import location (§5, §15)

`RequestProject/NullSectorTask11/ReferenceExistence.lean`, **line 2**:

```lean
import RequestProject.NullSectorTask10.InternalLift
```

This is the first (and, in the reconstruction core, the only) point at which the
Task-10 explicit lift becomes visible.  Modules `SafeBase`, `CenterRigidity`,
`FullLift` and `RelativeLiftRigidity` — which contain the exact center theorem,
the arbitrary-lift definition and the *complete* relative rigidity theorem — do
not import it, so no half-angle formula can have driven those results.

The witness is introduced under the neutral name

```lean
noncomputable def Uref : ℝ → W := Ustd
theorem Uref_isFullLift : IsFullLift Uref
theorem Uref_isContinuousFullLift : IsContinuousFullLift Uref
theorem exists_continuousFullLift : ∃ U, IsContinuousFullLift U
```

It is not called a rotor, a spin lift or a unitary transformation.

---

## 12. Algebraic lift classification (§15, §16)

**ALGEBRAIC FREEDOM.**

```lean
theorem fullLift_classification (U : ℝ → W) :
    IsFullLift U ↔ ∃ z : ℝ → W, IsCentralHom z ∧ ∀ θ, U θ = z θ ⋆ Uref θ

theorem fullLift_classification_coeffs (U : ℝ → W) :
    IsFullLift U ↔ ∃ f g : ℝ → ℝ, IsCentralCoeffHom f g ∧ ∀ θ, U θ = zc (f θ) (g θ) ⋆ Uref θ
```
(`ExactLiftClassification.lean`.)  The coefficient form spells the freedom out
in the derived basis `1, S`:

```lean
structure IsCentralCoeffHom (f g : ℝ → ℝ) : Prop where
  f_zero : f 0 = 1
  g_zero : g 0 = 0
  f_add  : ∀ θ φ, f (θ + φ) = f θ * f φ - g θ * g φ
  g_add  : ∀ θ φ, g (θ + φ) = f θ * g φ + g θ * f φ
```

with the derived non-degeneracy `0 < f θ ^ 2 + g θ ^ 2`.

**§16 — Conservation of Difficulty: where the Task-10 real factor sits.**

```lean
theorem residual_S_coeff_eq_zero_of_mem_K … : (∀ θ, U θ ∈ K) → ∀ θ, g θ = 0
theorem mem_K_of_residual_real …            : (∀ θ, g θ = 0) → ∀ θ, U θ ∈ K
theorem isKLift_iff (U) : IsKLift U ↔ IsFullLift U ∧ ∀ θ, U θ ∈ K
theorem exists_fullLift_not_mem_K : ∃ U, IsContinuousFullLift U ∧ ¬ (∀ θ, U θ ∈ K)
```

**Verdict:** the Task-10 residual real multiplicative function was **not** the
complete full-carrier freedom.  It is exactly the intersection of the larger
central freedom with `K`, i.e. the slice `g ≡ 0` (in which case
`U θ = f θ • Uref θ`).  A continuous full lift leaving `K` exists, so the
inclusion is strict.

---

## 13. Continuous lift classification (§18, §19, §20)

**CONTINUOUS FREEDOM.**  This closes the principal unresolved obligation of
Task 10.

```lean
noncomputable def zexp (α β θ : ℝ) : W :=
  zc (Real.exp (α * θ) * Real.cos (β * θ)) (Real.exp (α * θ) * Real.sin (β * θ))

theorem centralHom_continuous_classification (z : ℝ → W) :
    (IsCentralHom z ∧ Continuous z) ↔ ∃ α β : ℝ, ∀ θ, z θ = zexp α β θ

theorem continuousFullLift_classification (U : ℝ → W) :
    IsContinuousFullLift U ↔ ∃ α β : ℝ, ∀ θ, U θ = zexp α β θ ⋆ Uref θ
```
(`ContinuousClassification.lean`.)

This is a **complete classification**, not a family of examples: the forward
direction starts from an arbitrary continuous full lift.

Proof route, entirely inside the derived real basis `1, S` (§19): continuity of
the coefficient pair `(f,g)` plus the derived bilinear recursions forces
differentiability by an averaging/primitive argument
(`coeff_differentiable`); the group law then yields a linear ODE system
(`coeff_hasDerivAt`); two explicitly constructed quantities have vanishing
derivative and are therefore constant, which pins the solution
(`coeff_continuous_classification`).  No identification of the central plane
with conventional complex numbers is used, and no theorem about complex
characters is imported.

**§20 — ALGEBRAIC ≠ CONTINUOUS, stated explicitly.**

```lean
theorem exists_additive_not_linear :
    ∃ F : ℝ → ℝ, (∀ x y, F (x+y) = F x + F y) ∧ ¬ ∃ c, ∀ θ, F θ = c * θ

theorem exists_centralHom_not_continuous :
    ∃ z : ℝ → W, IsCentralHom z ∧ ¬ ∃ α β : ℝ, ∀ θ, z θ = zexp α β θ
```

Discontinuous pathological residual homomorphisms therefore really do remain
possible at the purely algebraic level (the witness is built from a
ℚ-linear complement of `span ℚ {√2}`, using `Submodule.exists_isCompl` and
`Submodule.linearProjOfIsCompl`; this uses the axiom of choice, which is part of
the standard Lean/Mathlib axiom set — see §26).  The two classes are never
silently identified.

---

## 14. Exact residual parameter count

**Exactly two real continuous degrees of freedom**, and they are independent:

```lean
theorem zexp_injective {α β α' β' : ℝ} (h : ∀ θ, zexp α β θ = zexp α' β' θ) : α = α' ∧ β = β'
theorem continuousFullLift_parameters_unique {α β α' β' : ℝ}
    (h : ∀ θ, zexp α β θ ⋆ Uref θ = zexp α' β' θ ⋆ Uref θ) : α = α' ∧ β = β'
```

Summary of the count:

| Freedom | Size |
| --- | --- |
| `ALGEBRAIC FREEDOM` (all full lifts) | all central multiplicative maps `ℝ → Z`, including discontinuous ones (infinite-dimensional as a ℚ-vector-space phenomenon) |
| `CONTINUOUS FREEDOM` | exactly 2 real parameters `(α, β)` |
| Task-10 `K`-restricted freedom | the slice `β`-component `g ≡ 0`; continuous case: 1 real parameter `α` |

---

## 15. General `2π` / `4π` theorem (§21, §22)

**DERIVED.**  Nothing is assumed to be `-1` or `1`.

```lean
theorem continuousFullLift_two_pi {U α β} (hU : ∀ θ, U θ = zexp α β θ ⋆ Uref θ) :
    U (2π) = zc (-(exp (α·2π) · cos (β·2π))) (-(exp (α·2π) · sin (β·2π)))

theorem continuousFullLift_four_pi {U α β} (hU : ∀ θ, U θ = zexp α β θ ⋆ Uref θ) :
    U (4π) = zc (exp (α·4π) · cos (β·4π)) (exp (α·4π) · sin (β·4π))
```
(`PeriodicityAudit.lean`; `Task11.task11_periodicity` collects both.)

The exact dependence on the remaining continuous freedom is therefore explicit.
The Task-10 reference values are recovered as the special case `α = β = 0`:

```lean
theorem reference_two_pi_four_pi : Uref (2π) = -w1 ∧ Uref (4π) = w1
theorem two_pi_value_depends_on_parameters :
    ∃ U V, IsContinuousFullLift U ∧ IsContinuousFullLift V ∧ U (2π) ≠ V (2π)
```

**§22, at theorem level (not prose):**

```lean
theorem algebra_two_pi : Phi (2π) = LinearMap.id
theorem algebra_periodicity_does_not_fix_lift : Phi (2π) = LinearMap.id ∧ Uref (2π) ≠ w1
```

Periodicity of the algebra automorphism does not by itself determine periodicity
of an internal implementer.

---

## 16. `N₊` compatibility classification (§23, §24)

**CONDITIONAL COMPATIBILITY — NOT INHERITED.**  Nothing in Tasks 08–10 requires
an internal lift to interact with the Task-09 quadratic branches.  The predicate

```lean
def PreservesLeftQuadratic (N : W → W) (U : ℝ → W) : Prop :=
  ∀ (θ : ℝ) (x : W), N (U θ ⋆ x) = N x
```

is an explicitly *added* structural test and is carried as a hypothesis in every
theorem of `QuadraticCompatibility.lean`.  It supports none of the results of
§§7–15 above.

Branch-parameterized criterion (the only branch input is the proved relation
`ζ * ζ = 1`):

```lean
theorem preservesLeftQuadratic_iff {ζ : ℝ} (hζ : ζ * ζ = 1) (U : ℝ → W) :
    PreservesLeftQuadratic (Ncand ζ) U ↔ ∀ θ, nRe (U θ) = 1 ∧ nSc (U θ) = 0
```

Classification among the already classified continuous full lifts:

```lean
theorem Nplus_compatibility_classification {U} (hU : IsContinuousFullLift U) :
    PreservesLeftQuadratic Nplus U ↔ U = Uref
```

Uniqueness was not assumed; it is the outcome.  The reference lift is **proved**
to satisfy the condition (`nRe_Uref`, `nSc_Uref`), not assumed to.  The test
removes both continuous parameters: `α = 0` and `β = 0`.

---

## 17. `N₋` compatibility classification (§25)

```lean
theorem Nminus_compatibility_classification {U} (hU : IsContinuousFullLift U) :
    PreservesLeftQuadratic Nminus U ↔ U = Uref

theorem Nplus_Nminus_compatibility_equiv (U : ℝ → W) :
    PreservesLeftQuadratic Nplus U ↔ PreservesLeftQuadratic Nminus U
```

The proof is **not** a renaming of the `N₊` result: it runs through the
branch-parameterized criterion above, whose only branch input is the *proved*
sign relation `ζ * ζ = 1`, satisfied by both `ζ = 1` and `ζ = -1`.  Neither
branch is selected.

**Outcome of the three admissible verdicts of §25:** the two compatibility
classes **coincide** — and they coincide for *every* map `U`, not just for
continuous full lifts.  The branch difference is invisible to this condition,
because the condition forces the `S`-coefficient of `U θ` to vanish, and the two
branches differ only in the sign attached to that coefficient.

---

## 18. Simultaneous compatibility classification (§26)

```lean
theorem simultaneous_compatibility_classification {U} (hU : IsContinuousFullLift U) :
    (PreservesLeftQuadratic Nplus U ∧ PreservesLeftQuadratic Nminus U) ↔ U = Uref
```

Simultaneous compatibility is **not stronger** than either branch separately: by
§17 the two conditions are equivalent, so their conjunction removes nothing
further.  This remains a conditional structural test, not a physical
normalization principle.

---

## 19. Normalization-status audit (§17, §27)

`NORMALIZATION NOT ASSUMED.`  None of

```
a² + b² = 1,  N(U θ) = 1,  boundedness,  periodicity,  U(2π) = -1,  U(4π) = 1,
fixed determinant,  fixed modulus,  unit norm
```

is assumed anywhere in `SafeBase`, `CenterRigidity`, `FullLift`,
`RelativeLiftRigidity`, `ReferenceExistence`, `ExactLiftClassification`,
`ContinuousClassification` or `PeriodicityAudit`.  The only normalization in the
definition of a lift is `U 0 = 1`, which is a base-point condition, not a norm
condition.  In particular the classification theorems admit lifts with
`α ≠ 0`, which are unbounded and aperiodic.

`NORMALIZATION DERIVED CONDITIONALLY.`  Under the *explicit* conditional test of
§23 a unit-like relation is obtained as a theorem:

```lean
theorem normalization_derived {U α β} (hU : ∀ θ, U θ = zexp α β θ ⋆ Uref θ)
    (hcont : IsContinuousFullLift U) (hpres : PreservesLeftQuadratic Nplus U) :
    (∀ θ, nRe (U θ) = 1 ∧ nSc (U θ) = 0) ∧
    (∀ θ, (exp (αθ)·cos (βθ))² + (exp (αθ)·sin (βθ))² = 1)
```

| Status | Statement |
| --- | --- |
| `ASSUMED NORMALIZATION` | none |
| `DERIVED CONSEQUENCE OF AN EXPLICIT COMPATIBILITY CONDITION` | unit squared modulus of the residual central factor, and in fact `α = β = 0`, i.e. `U = Uref` |

---

## 20. Differentiable-lift theorem (§28)

```lean
structure IsDifferentiableFullLift (U : ℝ → W) : Prop extends IsFullLift U where
  diff : Differentiable ℝ U

noncomputable def leftGen (U : ℝ → W) : W := deriv U 0
```

The derivative is taken in the inherited finite-dimensional real topology of `W`
(`W = Fin 8 → ℝ` with its product norm); `HasDerivAt` is the rigorous form used.

```lean
theorem continuousFullLift_iff_differentiableFullLift (U : ℝ → W) :
    IsContinuousFullLift U ↔ IsDifferentiableFullLift U
```

**Differentiability is not an extra hypothesis:** the continuous classification
already produces differentiable maps, so the corollary layer costs nothing and —
as required by §8 — the main classification was proved under continuity alone.

```lean
theorem hasDerivAt_fullLift_zero (α β : ℝ) :
    HasDerivAt (fun θ => zexp α β θ ⋆ Uref θ) (zc α β - (2⁻¹ : ℝ) • wR) 0

theorem differentiableFullLift_generator {U} (hU : IsDifferentiableFullLift U) :
    ∃ α β, (∀ θ, U θ = zexp α β θ ⋆ Uref θ) ∧ leftGen U = zc α β - (2⁻¹ : ℝ) • wR

theorem generator_classification (G : W) :
    (∃ U, IsDifferentiableFullLift U ∧ leftGen U = G) ↔ G + (2⁻¹ : ℝ) • wR ∈ Z
```

`G` is a carrier element acting by left multiplication; it is given no dynamical
name.

---

## 21. Infinitesimal generator decomposition (§29, §30)

**VISIBLE GENERATOR / INVISIBLE GENERATOR COMPONENT.**

```lean
def inducedDer (G : W) : W → W := fun x => G ⋆ x - x ⋆ G

theorem inducedDer_generator (a b : ℝ) : inducedDer (zc a b - (2⁻¹ : ℝ) • wR) = Dgen

theorem differentiableFullLift_inducedDer {U} (hU : IsDifferentiableFullLift U) :
    inducedDer (leftGen U) = Dgen ∧
      ∀ x, HasDerivAt (fun θ => Phi θ x) (inducedDer (leftGen U) x) 0
```

No commutator formula was prescribed: the relation between `G` and the inherited
infinitesimal algebra generator `Dgen` is derived, and it *is* the commutator.
The two roles are kept apart at theorem level:

```lean
theorem leftMul_generator_not_derivation {U} (hU : IsDifferentiableFullLift U) :
    ¬ (∀ x y, leftGen U ⋆ (x ⋆ y) = (leftGen U ⋆ x) ⋆ y + x ⋆ (leftGen U ⋆ y))
```

so `G` acting by **left multiplication** is not a derivation, whereas
`inducedDer G` **is** the derivation generating the algebra automorphism.

**Exact invisible freedom (§30), not assumed central beforehand:**

```lean
theorem inducedDer_eq_iff_sub_mem_center (G G' : W) :
    inducedDer G = inducedDer G' ↔ G - G' ∈ CenterW

theorem invisible_generator_freedom (G G' : W) :
    inducedDer G = inducedDer G' ↔ ∃ a b : ℝ, G - G' = zc a b

theorem generator_visible_invisible_split {U} (hU : IsDifferentiableFullLift U) :
    ∃ z, z ∈ CenterW ∧ leftGen U = z - (2⁻¹ : ℝ) • wR ∧
      inducedDer (leftGen U) = Dgen ∧ inducedDer ((-(2⁻¹) : ℝ) • wR) = Dgen
```

Decomposition table:

| Component of `G` | Status |
| --- | --- |
| `zc α β = α·1 + β·S` (an arbitrary element of the exact center) | `INVISIBLE GENERATOR COMPONENT` — `CENTRAL FREEDOM`, two real parameters |
| `-(1/2)·R` (fixed) | `VISIBLE GENERATOR` — its commutator is exactly `Dgen` |

The classification of invisible changes `G ↦ G'` is tied back to §7: the
difference is invisible **iff** it lies in `CenterW`, which by the exact center
theorem is exactly `Z`.

---

## 22. Comparison with the Task-10 rate freedom (§31)

Task 10 proved that all structurally admissible axial derivations form the real
line `λ • Dgen` (`axialDerivation_classification`).  Task 11 determines the
logical relation to the residual lift freedom — by proof, not by analogy:

```lean
theorem rate_freedom_collapses {U} (hU : IsDifferentiableFullLift U) (l : ℝ) :
    (∀ x, inducedDer (leftGen U) x = l • Dgen x) ↔ l = 1

theorem residual_freedom_invisible {U V} (hU : …) (hV : …) :
    inducedDer (leftGen U) = inducedDer (leftGen V) ∧ leftGen U - leftGen V ∈ CenterW
```

| Freedom | Where it lives | Visible in the algebra action? |
| --- | --- | --- |
| `RATE FREEDOM` `λ • Dgen` (Task 10) | the space of derivations | **yes** — different `λ` give different derivations |
| Residual lift freedom `(α, β)` (Task 11) | the exact center of `W` | **no** — every full lift of the fixed `Φ` induces the same derivation |

**Verdict: the two freedoms are independent, not two names for one freedom.**
Once the automorphism family `Φ` is *fixed*, an internal implementer of it has
rate exactly `λ = 1`; the whole two-parameter residual family is invisible under
conjugation.  Conversely, rescaling the rate changes the derivation and hence
changes `Φ` itself, which is outside the class of lifts considered here.

---

## 23. Conservation-of-Difficulty graph and the seventeen questions (§34)

```
Task-10 algebra automorphism Φ                (INHERITED)
        ↓
arbitrary full-carrier lift  IsFullLift        (DERIVED, §9 of this audit)
        ↓
exact center / centralizer classification      (DERIVED, §§7–8)
        ↓
comparison of two arbitrary lifts  rel         (DERIVED, §10)
        ↓
upper residual-freedom theorem                 (DERIVED, §10; no reference formula used)
        ↓
reference lift introduced  Uref                (§11 — first import here)
        ↓
exact algebraic lift classification            (DERIVED, §12)
        ↓
continuous residual classification             (DERIVED, §13; parameter count §14)
        ↓
general periodicity 2π / 4π                    (DERIVED, §15)
        ↓
N₊ conditional compatibility                   (CONDITIONAL, §16)
        ↓
N₋ conditional compatibility                   (CONDITIONAL, §17)
        ↓
simultaneous compatibility                     (CONDITIONAL, §18)
        ↓
differentiable lift generator                  (DERIVED, §20)
        ↓
algebra-generator comparison / separation      (DERIVED, §§21–22)
        ↓
late conventional comparison                   (COMPARISON ONLY, §24)
```

Answers to the seventeen questions of §34:

1. **Is the previously known central two-plane the full center?**  Yes —
   `center_eq_Z`.
2. **What is the centralizer of the generating triple?**  Exactly the center —
   `centralizer_triple_eq_center`; already `{wA, wB}` suffices, while `{wA}`
   alone does not.
3. **If two full internal lifts implement the same `Φ`, how can they differ?**
   Exactly by a central, multiplicative, base-point-normalized factor —
   `rel_isCentralHom`, `fullLift_relative_classification`.
4. **Was the Task-10 real factor the complete freedom?**  No — it is the
   `K`-slice `g ≡ 0` of a strictly larger freedom; `exists_fullLift_not_mem_K`.
5. **Complete algebraic residual freedom?**  All central multiplicative maps
   `ℝ → Z` — `fullLift_classification`, coefficient form
   `IsCentralCoeffHom`.
6. **Complete continuous residual freedom?**  Exactly the family `zexp α β` —
   `centralHom_continuous_classification`, `continuousFullLift_classification`.
7. **How many independent continuous parameters remain?**  Exactly two —
   `continuousFullLift_parameters_unique`.
8. **Exact general `2π` / `4π` values?**  `continuousFullLift_two_pi`,
   `continuousFullLift_four_pi` (see §15).
9. **Which values belong only to the reference lift?**  `-1` at `2π` and `1` at
   `4π` hold exactly in the case `α = β = 0`; `two_pi_value_depends_on_parameters`.
10. **What does conditional preservation of `N₊` remove?**  Both continuous
    parameters; it leaves exactly `Uref`.
11. **What does conditional preservation of `N₋` remove?**  The same; the two
    classes coincide.
12. **What does simultaneous preservation remove?**  Nothing beyond either
    branch separately.
13. **Does any normalization emerge as a theorem?**  Yes, but only *conditionally*
    — `normalization_derived`; nothing is assumed.
14. **Exact infinitesimal generator of an arbitrary differentiable lift?**
    `G = α·1 + β·S − (1/2)·R` — `differentiableFullLift_generator`.
15. **Which part is visible to the algebra automorphism?**  The `-(1/2)·R`
    component; its commutator is exactly `Dgen`.
16. **Which part is invisible?**  The central part `α·1 + β·S`, and *only* it —
    `inducedDer_eq_iff_sub_mem_center`.
17. **How is this different from the Task-10 free rate `λ`?**  The rate freedom
    is visible in the derivation and is fixed to `λ = 1` by any lift of the fixed
    `Φ`; the lift freedom is invisible.  They are independent — §22.

---

## 24. Late conventional comparison (§40) — **COMPARISON ONLY**

`RequestProject/NullSectorTask11/Identification.lean` is the only module of
Task 11 in which a conventional identification appears; it imports the Task-08
comparison isomorphism `toMat : W ≅ M₂(ℂ)` and is imported only by `Task11.lean`.
No conventional theorem supports any earlier result.

```lean
theorem comparison_toMat_zc (a b : ℝ) : toMat (zc a b) = ((a : ℂ) + b*I) • 1
theorem comparison_center_eq_scalars (z : W) : z ∈ CenterW ↔ ∃ c : ℂ, toMat z = c • 1
theorem comparison_residual_freedom (α β θ : ℝ) :
    toMat (zexp α β θ) = Complex.exp ((α + β*I) * θ) • 1
theorem comparison_two_parameters (α β : ℝ) : ‖Complex.exp ((α + β*I)*1)‖ = Real.exp α
theorem comparison_relative_element … : ∃ c : ℂ, toMat (rel U V θ) = c • 1
theorem comparison_det_Uref (θ : ℝ) : (toMat (Uref θ)).det = 1
theorem comparison_det_general (α β θ : ℝ) :
    (toMat (zexp α β θ ⋆ Uref θ)).det = Complex.exp ((α + β*I) * θ) ^ 2
theorem comparison_invisible_component (G G' : W) :
    inducedDer G = inducedDer G' ↔ ∃ c : ℂ, toMat (G - G') = c • 1
```

Read conventionally: the exact center is the algebra of complex scalar matrices;
the residual continuous freedom is the one-parameter subgroup of the
multiplicative group of nonzero complex scalars generated by `α + βi` (two real
parameters: a modulus rate and an argument rate); the quotient of two
implementers is a nonzero complex scalar; and the invisible infinitesimal
component is the kernel of the commutator action, i.e. again the scalars.  The
unit determinant of the reference lift is recorded *after the fact* as a
consequence, never used as an input.

**§41.**  Nothing physical is concluded.  No phase, no probability amplitude, no
quantum mechanics, no energy evolution has been derived; Task 11 determines
algebraic and analytic freedom in internal implementations only.

---

## 25. Build report

```
$ lake build
Build completed successfully (8133 jobs).
```

All twelve Task-11 modules and the top-level `Task11.lean` compile.  A mechanical
scan of `RequestProject/NullSectorTask11/` for `sorry`, `admit`, `axiom` and
`@[implemented_by]` returns no match: no `sorry`, no `admit`, no custom axiom and
no unverified implementation is present.  No matrix representation and no
complex-number identification is used to prove any reconstruction-core
classification (§6).

---

## 26. Axiom report (§39)

`#print axioms` is executed inside `RequestProject/NullSectorTask11/Task11.lean`
for the principal theorems.  Every one of them reports

```
[propext, Classical.choice, Quot.sound]
```

i.e. only the three standard Lean/Mathlib axioms.

| Required item (§39) | Theorem printed |
| --- | --- |
| exact center theorem | `task11_center` (= `center_eq_Z`), `task11_centralizer` |
| relative lift rigidity | `task11_relative_lift`, `task11_relative_classification` |
| full algebraic lift classification | `task11_algebraic_classification`, `task11_K_slice` |
| continuous lift classification | `task11_continuous_classification`, `task11_parameter_count` |
| `N₊` compatibility theorem | `task11_Nplus_compatibility` |
| `N₋` compatibility theorem | `task11_Nminus_compatibility` |
| simultaneous compatibility theorem | `task11_simultaneous_compatibility` |
| infinitesimal generator theorem | `task11_infinitesimal_generator` |
| generator-separation theorem | `task11_generator_separation`, `task11_rate_vs_lift_freedom` |
| (further) periodicity, normalization, comparison | `task11_periodicity`, `task11_reference_periodicity`, `task11_normalization`, `task11_identification` |

`Classical.choice` enters through ordinary Mathlib real analysis and, in
`exists_centralHom_not_continuous`, through the ℚ-linear complement used to build
the discontinuous residual witness of §20.

---

## 27. Unresolved mathematical obligations

1. `UNRESOLVED` — **Structure of the algebraic (discontinuous) residual class.**
   §20 proves that the algebraic freedom is strictly larger than the continuous
   freedom and exhibits a witness.  A complete parameterization of all central
   multiplicative maps `ℝ → Z` (equivalently, of all group homomorphisms from
   `(ℝ,+)` into the multiplicative group of the derived central plane) is *not*
   given; only the continuous ones are classified completely.  Such a
   parameterization is inherently choice-dependent.
2. `UNRESOLVED` — **Measurability/Baire-type intermediate classes.**  Whether
   weaker regularity (measurability, local boundedness) already forces the
   continuous family is not addressed here.
3. `UNRESOLVED` — **Right-multiplication and two-sided compatibility variants.**
   The conditional test of §23 is a *left* multiplication condition.  The
   corresponding right-sided and two-sided conditions are not analysed.
4. `NOT INHERITED` / deliberately out of scope — state-carrier reduction
   (minimal left/right ideals, irreducible modules, minimal or projective state
   spaces) is not attempted, per §32; new transverse axes and general momentum
   directions are excluded by §33.
5. `COMPARISON ONLY` — the conventional readings of §24 are recorded as
   comparisons; nothing depends on them.

---

## HARD STOP

The full-carrier axial lift and its infinitesimal freedom have been completely
classified and hardened.  No minimal state carrier, irreducible module,
spin-type sector, massless constraint, field equation, general momentum
direction, boosted state, time evolution or dynamical structure is introduced,
and no Task 12 is proposed.
