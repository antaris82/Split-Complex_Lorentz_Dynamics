# TASK 07 AUDIT — minimal associative closure forced by two orthogonal longitudinal sectors

Status vocabulary used below: `INPUT`, `INHERITED`, `DERIVED`,
`NEW PRODUCT DIRECTION`, `FORCED RELATION`, `OUTSIDE OLD CARRIER`, `CLOSED`,
`MINIMAL`, `EXISTENCE WITNESS`, `UNIQUE UP TO ISOMORPHISM`, `COMPARISON ONLY`,
`OBSTRUCTION`, `UNRESOLVED`.

---

## 1. Exact toolchain

| item | value |
| --- | --- |
| Lean | `leanprover/lean4:v4.28.0` (`lean-toolchain`) |
| Mathlib | `v4.28.0`, commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (`lake-manifest.json`) |
| build command | `lake build` (all modules are default targets of the `RequestProject` library) |

---

## 2. Exact source ledger (Task-07 modules, in dependency order)

| # | module | role |
| --- | --- | --- |
| 1 | `RequestProject/NullSectorTask07/SafeBase.lean` | inherited data, `oldSq`, the two selected directions |
| 2 | `RequestProject/NullSectorTask07/AmbientExtension.lean` | `AssociativeE`, `TwoSidedUnitE`, `PreservesOldSquares`, `AmbientExt` |
| 3 | `RequestProject/NullSectorTask07/Polarization.lean` | recovery of the inherited symmetric product |
| 4 | `RequestProject/NullSectorTask07/TwoDirections.lean` | `genA`, `genB` and their derived relations |
| 5 | `RequestProject/NullSectorTask07/MixedProduct.lean` | first definition of `genP`, forced relations |
| 6 | `RequestProject/NullSectorTask07/NewDirection.lean` | old-carrier square obstruction, non-membership |
| 7 | `RequestProject/NullSectorTask07/ForcedRelations.lean` | relation summary, linear independence |
| 8 | `RequestProject/NullSectorTask07/GeneratedClosure.lean` | `Gsub`, normal form, closure, dimension, table |
| 9 | `RequestProject/NullSectorTask07/Minimality.lean` | `IsGenClosed`, minimality |
| 10 | `RequestProject/NullSectorTask07/DirectWitness.lean` | fresh four-dimensional existence witness |
| 11 | `RequestProject/NullSectorTask07/Uniqueness.lean` | uniqueness of the product, closure isomorphism |
| 12 | `RequestProject/NullSectorTask07/SignAudit.lean` | generator-order/sign diagnostic |
| 13 | `RequestProject/NullSectorTask07/Identification.lean` | **COMPARISON ONLY** late identification |
| 14 | `RequestProject/NullSectorTask07/Task07.lean` | principal theorems, `#print axioms` |

**Source-order report.** The derivation chain is modules 1–9. The existence
witness (10) imports the derivation (9) and is imported by nothing in 1–9. The
identification layer (13) is imported only by `Task07.lean` (14). Mechanically:

```
rg -n "import RequestProject.NullSectorTask07.Identification" RequestProject
→ RequestProject/NullSectorTask07/Task07.lean
rg -n "import RequestProject.NullSectorTask07.DirectWitness" RequestProject
→ RequestProject/NullSectorTask07/Uniqueness.lean
```

so `classification / forced table` strictly precedes `direct finite-dimensional
witness`, which strictly precedes `conventional identification`.

---

## 3. Exact inherited theorems (INHERITED)

Task 07 imports exactly one external module,
`RequestProject.NullSectorTask06.AssociativityObstruction`. Its transitive
closure is

```
NullSectorTask01.Basic
NullSectorTask02.LorentzData, CandidateProduct, FixedUnit
NullSectorTask04.Lorentz4, RestSpace, Sectors, GlobalExtension
NullSectorTask06.SafeBase, GenericExtension, AssociativityObstruction
```

No Task-04 or Task-06 late conventional-identification module
(`Task04.Identification`, `Task06.Identification`, `Task06.Task04Comparison`) is
reachable from any Task-07 module.

Inherited declarations actually used:

| declaration | use |
| --- | --- |
| `NullSectorTask01.Vec4`, `Q4` | original carrier and quadratic form |
| `NullSectorTask04.L4`, `e₀` | polarized form, normalized future unit |
| `NullSectorTask04.Rest`, `Vec3`, `sp`, `dot3` | rest-space structure |
| `NullSectorTask04.vec4_ext`, `vec4_decomp`, `Q4_sp` | coordinate bookkeeping |
| `NullSectorTask04.BiProd4`, `SectorCompatible`, `Associative4` | statement of the inherited no-go |
| `NullSectorTask04.M_expand`, `M_rest_sq`, `M_rest_symm`, `M_unit_left/right` | forced consequences of sector compatibility |
| `NullSectorTask06.symForced` | the forced symmetric product `μsym` |
| `NullSectorTask06.r₁`, `r₂` | two orthonormal rest directions |
| `NullSectorTask06.not_exists_associative_sectorCompatible` | the Task-06 no-go (INPUT MOTIVATION only) |

The Task-06 no-go is restated as
`NullSectorTask07.inherited_no_associative_closure`
(= `task07_inherited_no_go`) and is **not** used in any Task-07 proof.

---

## 4. Experiment-1 firewall

No theorem, formula, terminology, source, repository, paper, prompt, Lean
declaration or result of Experiment 1 is used. The Task-07 modules import
nothing outside the ledger of §3 plus Mathlib (reached transitively through
`NullSectorTask01.Basic`, which contains `import Mathlib`). Only general-purpose
Mathlib material is used: `LinearMap`, `Submodule`, `Module.finrank`,
`LinearIndependent`, `Matrix` (identification layer only), and the tactics
`simp`, `ring`, `module`, `linear_combination`, `fin_cases`, `nlinarith`,
`linarith`.

---

## 5. Target-structure firewall

Mechanical scan of the twelve reconstruction modules (1–12 of §2) for

```
clifford | geometric algebra | exterior | bivector | multivector | quaternion |
pauli | spin | complexif | pseudoscalar | matrix
```

returns **zero hits** (case-insensitive). No standard implementation of any such
structure is imported anywhere in the derivation, and no conventional name is
used before the identification layer. The words `matrix`/`Matrix` occur only in
`Identification.lean` and in this audit below §21.

---

## 6. Ambient-extension definition (INPUT)

```lean
def AssociativeE (mul : E →ₗ[ℝ] E →ₗ[ℝ] E) : Prop :=
  ∀ x y z : E, mul (mul x y) z = mul x (mul y z)

def TwoSidedUnitE (mul : E →ₗ[ℝ] E →ₗ[ℝ] E) (u : E) : Prop :=
  (∀ x, mul u x = x) ∧ (∀ x, mul x u = x)

def PreservesOldSquares (mul : E →ₗ[ℝ] E →ₗ[ℝ] E) (emb : Vec4 →ₗ[ℝ] E) : Prop :=
  ∀ X : Vec4, mul (emb X) (emb X) = emb (oldSq X)

structure AmbientExt (E : Type*) [AddCommGroup E] [Module ℝ E] where
  mul       : E →ₗ[ℝ] E →ₗ[ℝ] E
  oneE      : E
  assoc     : AssociativeE mul
  unit      : TwoSidedUnitE mul oneE
  iota      : Vec4 →ₗ[ℝ] E
  iota_inj  : Function.Injective iota
  iota_e₀   : iota e₀ = oneE
  oldsq     : PreservesOldSquares mul iota
```

`E` is an arbitrary real vector space: no dimension, basis, grading,
commutativity, norm, involution, conjugation or orientation is assumed, and
`iota (Vec4)` is **not** assumed closed under `mul` — that is precisely the
Task-06 assumption being removed.

---

## 7. Old-square preservation (INHERITED, not a new assumption)

```lean
noncomputable abbrev musym : BiProd4 := NullSectorTask06.symForced
noncomputable def oldSq (X : Vec4) : Vec4 := musym X X
```

| theorem | statement |
| --- | --- |
| `oldSq_eq_musym` | `oldSq X = μsym X X` |
| `oldSq_apply` | `oldSq (t,v) = (t² + h(v,v), 2t·v)` in coordinates |
| `oldSq_time` | `(oldSq X).1 = X.1*X.1 + dot3 X.2 X.2` |
| `oldSq_time_nonneg` | `0 ≤ (oldSq X).1` |
| `sectorCompatible_sq` | `SectorCompatible M → M X X = oldSq X` for every `X` |

`sectorCompatible_sq` is the exact sense in which `PreservesOldSquares` is
**inherited**: it retains a diagonal already forced by the complete family of
longitudinal `1+1` sectors, and adds nothing new.

---

## 8. Polarization theorem (DERIVED)

```lean
theorem AmbientExt.polarization (X Y : Vec4) :
  S.mul (S.iota X) (S.iota Y) + S.mul (S.iota Y) (S.iota X) = (2:ℝ) • S.iota (musym X Y)
```

proved from `oldSq_add` (`oldSq (X+Y) = oldSq X + oldSq Y + 2 • μsym X Y`) and
bilinearity alone. The symmetric sector data is therefore **recovered**, not
assumed; only the antisymmetric mixed content is left free.

Negative control row 1 (“Does the retained square law imply the old symmetric
product after embedding?”) → **PROVED**, `AmbientExt.polarization`.

---

## 9. Two-generator inherited relations (DERIVED)

Selected directions (`SafeBase.lean`):

```lean
def dirA : Vec4 := sp r₁        def dirB : Vec4 := sp r₂
```

with `L4 e₀ dirA = 0`, `L4 e₀ dirB = 0`, `Q4 dirA = -1`, `Q4 dirB = -1`,
`L4 dirA dirB = 0` (`L4_e₀_dirA`, `L4_e₀_dirB`, `Q4_dirA`, `Q4_dirB`,
`L4_dirA_dirB`). No third spatial direction occurs in any Task-07 module.

```lean
def AmbientExt.genA : E := S.iota dirA      -- A
def AmbientExt.genB : E := S.iota dirB      -- B
```

| theorem | relation | provenance |
| --- | --- | --- |
| `genA_sq` | `A ⋆ A = 1` | `oldSq dirA = e₀`, `iota_e₀` |
| `genB_sq` | `B ⋆ B = 1` | `oldSq dirB = e₀`, `iota_e₀` |
| `gen_anticomm_sum` | `A ⋆ B + B ⋆ A = 0` | polarization + `μsym dirA dirB = 0` |
| `genBA` | `B ⋆ A = -(A ⋆ B)` | solved form of the previous |

Dependency actually realized in the Lean sources:

```
old longitudinal sector structure → old square law (oldSq)
   → polarization → relations for A and B
```

---

## 10. First definition of `P`

`P` is introduced **after** §9, in `MixedProduct.lean`:

```lean
def AmbientExt.genP : E := S.mul S.genA S.genB
```

Nothing is assumed about `P`.

---

## 11. Forced relations involving `P` (FORCED RELATION)

| theorem | relation |
| --- | --- |
| `mul_genA_genB` | `A ⋆ B = P` |
| `mul_genB_genA` | `B ⋆ A = -P` |
| `mul_genA_genP` | `A ⋆ P = B` |
| `mul_genP_genA` | `P ⋆ A = -B` |
| `mul_genB_genP` | `B ⋆ P = -A` |
| `mul_genP_genB` | `P ⋆ B = A` |
| `genP_sq` | `P ⋆ P = -1` |
| `genP_ne_zero` | `P ≠ 0` |

All are consequences of associativity, the unit laws and the §9 relations.

---

## 12. Old-carrier non-membership (OUTSIDE OLD CARRIER)

Standalone obstruction (coordinates only):

```lean
theorem oldSq_ne_neg_e₀ (X : Vec4) : oldSq X ≠ - e₀
```

because `(oldSq X).1 = X.1² + h(v,v) ≥ 0 ≠ -1`.

```lean
theorem AmbientExt.genP_not_image     : ¬ ∃ X : Vec4, S.iota X = S.genP
theorem AmbientExt.genP_not_mem_range : S.genP ∉ LinearMap.range S.iota
```

The proof uses **only** injectivity of `ι`, the retained square law, the
independently derived `P ⋆ P = -1` and elementary real positivity. The global
Task-06 no-go is not invoked.

**NEW PRODUCT DIRECTION FORCED.**

---

## 13. Linear-independence theorem (DERIVED)

`e₀, dirA, dirB` are linearly independent in the original carrier
(`e₀_dirA_dirB_indep`, coordinate proof). Combined with §12:

```lean
theorem AmbientExt.gen_indep_coeffs :
  α • 1 + β • A + γ • B + δ • P = 0 → α = 0 ∧ β = 0 ∧ γ = 0 ∧ δ = 0
theorem AmbientExt.genFamily_linearIndependent : LinearIndependent ℝ S.genFamily
```

with `genFamily = ![1, A, B, P]`. (The independence is *not* deduced from
non-membership alone.)

---

## 14. Generated-closure theorem (CLOSED)

```lean
def AmbientExt.gcomb (α β γ δ : ℝ) : E := α • S.oneE + β • S.genA + γ • S.genB + δ • S.genP
def AmbientExt.Gsub : Submodule ℝ E := Submodule.span ℝ (Set.range S.genFamily)
```

| theorem | content |
| --- | --- |
| `mem_Gsub_iff` | `x ∈ G ↔ ∃ α β γ δ, x = α•1+β•A+γ•B+δ•P` (normal form, existence) |
| `gcomb_injective` | the four coefficients are unique (normal form, uniqueness) |
| `mul_gcomb` | the coefficient law of a product of two normal forms |
| `Gsub_mul_closed` | `G ⋆ G ⊆ G` |

Derived coefficient law (`mul_gcomb`), obtained from the relations and
bilinearity only:

```
(α,β,γ,δ) ⋆ (α',β',γ',δ') =
  ( αα' + ββ' + γγ' − δδ',
    αβ' + βα' − γδ' + δγ',
    αγ' + βδ' + γα' − δβ',
    αδ' + βγ' − γβ' + δα' )
```

### Derived multiplication table (`multiplication_table`)

| ⋆ | `1` | `A` | `B` | `P` |
| --- | --- | --- | --- | --- |
| **`1`** | `1` (unit law) | `A` (unit law) | `B` (unit law) | `P` (unit law) |
| **`A`** | `A` (unit law) | `1` (`genA_sq`) | `P` (`mul_genA_genB`) | `B` (`mul_genA_genP`) |
| **`B`** | `B` (unit law) | `−P` (`mul_genB_genA`) | `1` (`genB_sq`) | `−A` (`mul_genB_genP`) |
| **`P`** | `P` (unit law) | `−B` (`mul_genP_genA`) | `A` (`mul_genP_genB`) | `−1` (`genP_sq`) |

Every entry cites an earlier theorem or a unit law; the algebra was **not**
defined by this table.

### Word reduction

`Minimality.word_reduction` and `GeneratedClosure.Gsub_is_closed_subspace`
give the equivalent algebra-generation statement: `G` is product-closed, contains
`1, A, B`, and is contained in every product-closed subspace containing
`1, A, B`; hence every finite associative word in `A, B` reduces to a real
combination of `1, A, B, P`. No free-algebra machinery is used.

---

## 15. Exact dimension theorem (DERIVED)

```lean
theorem AmbientExt.finrank_Gsub : Module.finrank ℝ S.Gsub = 4
```

proved from `finrank_span_eq_card` and the independence theorem. The number `4`
is an output: the ambient `E` has unspecified — possibly infinite — dimension
throughout.

---

## 16. Minimality theorem (MINIMAL)

```lean
structure AmbientExt.IsGenClosed (H : Submodule ℝ E) : Prop where
  one_mem : S.oneE ∈ H;  genA_mem : S.genA ∈ H;  genB_mem : S.genB ∈ H
  mul_mem : ∀ x ∈ H, ∀ y ∈ H, S.mul x y ∈ H

theorem AmbientExt.genP_mem_of_isGenClosed : IsGenClosed H → S.genP ∈ H
theorem AmbientExt.Gsub_le_of_isGenClosed  : IsGenClosed H → S.Gsub ≤ H
theorem AmbientExt.Gsub_least              : IsGenClosed S.Gsub ∧ ∀ H, IsGenClosed H → S.Gsub ≤ H
```

Every associative product-closed extension containing the two inherited spatial
generators contains the whole derived `G`.

---

## 17–18. First direct finite-dimensional witness, and its associativity

Constructed only after §§11–16, in `DirectWitness.lean`, on a **fresh** carrier
`Wit := Fin 4 → ℝ` (not the original `Vec4`), with the product taken verbatim
from the derived coefficient law of §14:

```lean
def witMulFun (x y : Wit) : Wit :=
  ![x 0*y 0 + x 1*y 1 + x 2*y 2 - x 3*y 3,
    x 0*y 1 + x 1*y 0 - x 2*y 3 + x 3*y 2,
    x 0*y 2 + x 1*y 3 + x 2*y 0 - x 3*y 1,
    x 0*y 3 + x 1*y 2 - x 2*y 1 + x 3*y 0]
def witMul : Wit →ₗ[ℝ] Wit →ₗ[ℝ] Wit := LinearMap.mk₂ ℝ witMulFun …
```

| theorem | content |
| --- | --- |
| `witMul` (construction) | bilinearity |
| `witMul_one_left`, `witMul_one_right`, `witTwoSidedUnit` | two-sided unit `witOne` |
| `witMul_assoc`, `witAssociative` | **associativity**, direct computation |
| `witA_sq`, `witB_sq` | generator squares `= witOne` |
| `witAnticomm`, `witB_mul_witA` | anticommutation |
| `witA_mul_witB`, `witP_sq` | `A⋆B = P`, `P⋆P = −witOne` |
| `wit_indep_coeffs` | `witOne, witA, witB, witP` linearly independent |

No known algebra is imported; associativity is proved by expanding the derived
formula.

---

## 19. Uniqueness / isomorphism result (UNIQUE UP TO ISOMORPHISM)

* `bilinear_product_unique` — two bilinear products on the derived
  four-dimensional carrier agreeing on the sixteen basis pairs are equal: the
  derived table determines the product.
* `AmbientExt.witToE` — the generator-preserving linear map
  `1 ↦ 1, A ↦ A, B ↦ B, P ↦ P`; `witToE_mul` proves multiplicativity,
  `witToE_injective` injectivity, `witToE_range` that its range is exactly `G`.
* `AmbientExt.witEquivGsub : Wit ≃ₗ[ℝ] S.Gsub` — the resulting isomorphism.
* `AmbientExt.closureEquiv S S' : S.Gsub ≃ₗ[ℝ] S'.Gsub` with
  `closureEquiv_oneE`, `closureEquiv_genA`, `closureEquiv_genB`,
  `closureEquiv_genP` and `closureEquiv_mul`: the closures of any two ambient
  extensions are isomorphic by the generator-preserving, unit-preserving,
  multiplicative linear equivalence.

No standard classification theorem is used.

---

## 20. Generator-order / sign diagnostic (DERIVED)

| transformation | effect on `P` | theorem |
| --- | --- | --- |
| `A ↔ B` | `P ↦ −P` | `swap_generators` |
| `A ↦ −A` | `P ↦ −P` | `neg_genA_mixed` |
| `B ↦ −B` | `P ↦ −P` | `neg_genB_mixed` |
| `A ↦ −A, B ↦ −B` | `P ↦ P` | `neg_both_mixed` |

The sign-flipped generators satisfy the same relations
(`neg_generators_relations`); the same diagnostic holds in the witness
(`wit_sign_audit`). No geometric or physical reading is attached.

---

## 21. Late conventional identification — COMPARISON ONLY

Obtained only after §§11–20, in `Identification.lean`:

```lean
def witToMat (x : Wit) : Matrix (Fin 2) (Fin 2) ℝ :=
  !![x 0 + x 1, x 2 + x 3; x 2 - x 3, x 0 - x 1]
```

`witToMat_bijective`, `witToMat_add`, `witToMat_smul`, `witToMat_mul`,
`witToMat_one` prove that this is a bijective, real-linear, multiplicative,
unital map. Hence:

> **COMPARISON ONLY.** The derived minimal associative closure is isomorphic,
> as a unital real algebra, to the algebra of `2 × 2` real matrices — the
> conventional algebra generated by two anticommuting real square roots of the
> unit, also known as the split quaternions. Images of the derived generators:
> `A ↦ !![1,0;0,-1]`, `B ↦ !![0,1;1,0]`, `P ↦ !![0,1;-1,0]`.

This identification is used in no earlier proof and is imported by no derivation
module.

---

## 22. Relation to Task 06, and the updated Conservation-of-Difficulty graph

Task 06 proved: **associative closure inside `Vec4` is impossible** for every
sector-compatible product. Task 07 changed exactly one assumption — that mixed
products must remain inside `Vec4` — and kept everything else, in particular the
whole forced diagonal square law.

Formally supported statement:

> The Task-06 obstruction localized the failed assumption correctly:
> old-carrier product closure was incompatible with global associativity once
> two independent spatial directions were combined.

This is supported by `task07_new_direction` (the local reason: the mixed product
squares to `−1`, and no inherited square equals `−e₀`), together with
`task07_closure` and `task07_witness` (removing the closure requirement produces
a consistent four-dimensional associative system with exactly the retained
two-generator relations). Task 06 is not “wrong” or “evaded”: its hypothesis set
included old-carrier closure, which Task 07 drops.

```
inherited longitudinal 1+1 sector products
        ↓
forced diagonal square law  oldSq          (sectorCompatible_sq)
        ↓
Task-06 no-go inside Vec4                  (inherited_no_associative_closure, INPUT)
        ↓
ambient extension, closure assumption removed   (AmbientExt)
        ↓
polarization recovers μsym                 (polarization)
        ↓
two orthogonal generators: A²=B²=1, AB+BA=0 (genA_sq, genB_sq, gen_anticomm_sum)
        ↓
mixed product P := A⋆B                     (genP)
        ↓
forced relations, P⋆P = −1                 (forced_relations)
        ↓
P ∉ range ι, P ≠ 0                         (genP_not_mem_range, genP_ne_zero)
        ↓
1,A,B,P independent                        (genFamily_linearIndependent)
        ↓
G := span{1,A,B,P} closed, normal form     (Gsub_mul_closed, mem_Gsub_iff)
        ↓
finrank G = 4                              (finrank_Gsub)
        ↓
minimality                                 (Gsub_le_of_isGenClosed)
        ↓
direct four-dimensional witness            (witness_summary)
        ↓
uniqueness up to generator-preserving iso  (closureEquiv_*, bilinear_product_unique)
        ↓
COMPARISON ONLY identification             (identification_summary)
```

**Outcome (§33 of the task): Outcome C.** `P` must leave the old carrier, and
one new direction gives a finite minimal associative closure, of dimension four,
completely classified before any conventional identification.

---

## 23. Negative controls (§39) — every row closed

| question | result | exact theorem |
| --- | --- | --- |
| Does the retained square law imply the old symmetric product after embedding? | **PROVED** | `AmbientExt.polarization` |
| Do the two selected spatial generators square to the unit? | **PROVED** | `AmbientExt.genA_sq`, `AmbientExt.genB_sq` |
| Do they anticommute? | **PROVED** | `AmbientExt.gen_anticomm_sum`, `AmbientExt.genBA` |
| What is the square of their mixed product? | **DERIVED** `P⋆P = −1` | `AmbientExt.genP_sq` |
| Can that mixed product lie in the embedded old carrier? | **REFUTED** | `AmbientExt.genP_not_image`, `AmbientExt.genP_not_mem_range` |
| Is the mixed product nonzero? | **PROVED** | `AmbientExt.genP_ne_zero` |
| Does one new product direction suffice for closure? | **PROVED (yes)** | `AmbientExt.Gsub_mul_closed` |
| Are `1,A,B,P` linearly independent? | **PROVED** | `AmbientExt.genFamily_linearIndependent` |
| What is the exact generated dimension? | **DERIVED** `4` | `AmbientExt.finrank_Gsub` |
| Is the generated span multiplicatively closed? | **PROVED** | `AmbientExt.Gsub_mul_closed`, `AmbientExt.mul_gcomb` |
| Is it minimal? | **PROVED** | `AmbientExt.Gsub_le_of_isGenClosed`, `AmbientExt.Gsub_least` |
| Does an independent finite-dimensional associative witness exist? | **PROVED** | `witness_summary` (`witMul_assoc`, `witTwoSidedUnit`, …) |
| Is the minimal generated structure unique up to generator-preserving isomorphism? | **PROVED** | `bilinear_product_unique`, `AmbientExt.closureEquiv_*` |
| What does generator exchange do to the mixed direction? | **DERIVED** `P ↦ −P` | `AmbientExt.swap_generators`, `AmbientExt.sign_audit` |

### §32 Conservation-of-Difficulty answers

1. Yes — the two-direction contradiction disappears once mixed products may
   leave `Vec4` (`task07_closure`, `task07_witness`).
2. Yes (`task07_new_direction`).
3. Yes (`task07_linear_independence`).
4. The nine identities of §11 (`task07_forced_relations`).
5. Yes (`task07_closure`).
6. Exactly `4` (`task07_dimension`).
7. Yes (`task07_minimality`).
8. Yes (`task07_witness`).
9. Yes (`task07_uniqueness`).
10. Yes, by `P ↦ −P` for exchange and for either single sign flip
    (`task07_sign_audit`).

---

## 24. Build report

```
$ lake build
Build completed successfully (8050 jobs).
```

No errors and no warnings in any Task-07 module. A repository scan
(`rg -n "sorry|admit\b|^axiom |@\[implemented_by" RequestProject/NullSectorTask07`)
returns nothing.

Per-module builds used during development:

```
lake build RequestProject.NullSectorTask07.SafeBase
…
lake build RequestProject.NullSectorTask07.Task07
```

---

## 25. Axiom report

`#print axioms` at the end of `Task07.lean` reports, for each of the sixteen
principal theorems

```
task07_inherited_square_law, task07_inherited_no_go, task07_polarization,
task07_generator_relations, task07_forced_relations, task07_new_direction,
task07_linear_independence, task07_normal_form, task07_closure,
task07_multiplication_table, task07_dimension, task07_minimality,
task07_witness, task07_uniqueness, task07_sign_audit, task07_identification
```

exactly

```
[propext, Classical.choice, Quot.sound]
```

No `sorry`, no `admit`, no custom axiom, no `@[implemented_by]`.

---

## 26. Unresolved mathematical obligations

1. **Non-vacuity of the full ambient hypothesis set is not established here.**
   All Task-07 structural theorems are conditional in exactly the sense the task
   prescribes: *any* associative ambient extension preserving the old square law
   must contain the derived `G`. Producing an ambient extension of the **whole**
   four-dimensional carrier `Vec4` would require a third rest-space generator
   (the square law also constrains the remaining spatial direction), which the
   §29 firewall explicitly forbids in Task 07. What *is* proved unconditionally
   is that the derived two-generator relation system is consistent: the
   four-dimensional witness of §17 satisfies bilinearity, the two-sided unit,
   associativity, `A² = B² = 1`, `AB + BA = 0`, `AB = P`, `P² = −1`, with
   `1, A, B, P` independent. The existence question for the full embedding is
   recorded as `UNRESOLVED` and deliberately left to a later stage.
2. The interaction of the derived closure with the third rest-space direction is
   not investigated (§29 firewall).
3. No norm, conjugation, involution, trace or determinant is introduced, and the
   independent Task-06 norm obstruction is untouched (§30 firewall).
4. The relation of the derived closure to the Lorentz form `Q4` beyond the
   retained square law is not addressed.
