# TASK 03 AUDIT

## Lorentz covariance of the reconstructed product family, transport between units, and residual null-sector ambiguity

Status labels used below: `INPUT`, `DERIVED`, `COUNTEREXAMPLE`, `DISCRETE CHOICE`,
`COMPARISON ONLY`, `UNRESOLVED`.

All statements refer to declarations in the namespace `NullSectorTask03`, in

```
RequestProject/NullSectorTask03/Core.lean          (core, Task-01-firewalled)
RequestProject/NullSectorTask03/Task03.lean        (late Task-01 comparison layer;
                                                    principal theorems; axiom report)
```

---

## 1. Exact imported Task-02 inputs — `INPUT`

`Core.lean` imports exactly one module,
`RequestProject.NullSectorTask02.GeneralUnit`, and through it the Task-02 chain
`LorentzData → CandidateProduct → FixedUnit → GeneralUnit` together with
`RequestProject.NullSectorTask01.Basic` (carrier and quadratic form only).

The following imported objects are used:

| Object | Source module | Role |
| --- | --- | --- |
| `Long = ℝ × ℝ` | `NullSectorTask01.Basic` | carrier |
| `Q2 (t,x) = t^2 - x^2` | `NullSectorTask01.Basic` | quadratic form |
| `L2 X Y = (Q2 (X+Y) - Q2 X - Q2 Y)/2` | `Task02.LorentzData` | polarization |
| `L2_coord`, `L2_self`, `L2_u₀_s₀`, `coord_decomp` | `Task02.LorentzData` | coordinate facts |
| `u₀ = (1,0)`, `s₀ = (0,1)`, `Q2_u₀`, `Q2_s₀` | `Task02.LorentzData` | reference vectors |
| `BiProd`, `LeftUnit`, `RightUnit`, `TwoSidedUnit`, `AdmissibleAt` | `Task02.CandidateProduct` | product carrier and admissibility |
| `twoSidedUnit_unique` | `Task02.CandidateProduct` | uniqueness of a two-sided unit |
| `compl e = (e.2, e.1)`, `Q2_compl`, `L2_compl` | `Task02.GeneralUnit` | orthogonal companion |
| `recAt`, `recAt_eq`, `recAt_admissible`, `eq_recAt`, `generalUnit_existsUnique` | `Task02.GeneralUnit` | the general normalized-unit reconstruction and its uniqueness |
| `FutureUnit e := e.1 > 0 ∧ Q2 e = 1` | `Task02.GeneralUnit` | normalized future unit |

`mu e := recAt e` (`Core.lean`) is *the* unique admissible product at `e`; the only
property of it used anywhere in Task 03 is the Task-02 output formula

```
mu e X Y = L2 X e • Y + L2 Y e • X - L2 X Y • e          (mu_eq)
```

together with `mu_admissible` and the Task-02 uniqueness theorem.

## 2. Forbidden Task-01 imports before comparison — import-firewall report

`Core.lean` imports only `RequestProject.NullSectorTask02.GeneralUnit`.  In
particular none of

```
RequestProject.NullSectorTask01.SplitComplex
RequestProject.NullSectorTask01.Boost
RequestProject.NullSectorTask01.Strata
RequestProject.NullSectorTask01.Limits
RequestProject.NullSectorTask01.Task01
RequestProject.NullSectorTask02.Comparison
RequestProject.NullSectorTask02.Task02
```

is reachable from `Core.lean` (the Task-02 chain used here stops at
`GeneralUnit`, which does not import the Task-02 comparison layer).

A word-boundary token scan of `Core.lean` for

```
Task01.SplitComplex  Task01.Boost  Task01.Strata  Task01.Limits  Task01.Task01
mulL  jL  ep  em  qp  qm  P  B4  B  oneL  invProd
```

is reported in §20 below, with every match individually documented.  Exactly two
matches occur, both of them prose false positives inside comments and neither of
them a reference to a Task-01 declaration:

* `Core.lean:463` — `/-- **Case B (§9): with the orientation condition …** -/`,
  the label of Case B of §9 of the task;
* `Core.lean:946` — `/-- **Negative control for data sets A and B (§13).** …`,
  the labels of the data sets of §13 of the task.

The scan is *not* weakened to suppress these; they are documented individually.
No other listed token occurs, and in particular the *word* `P` never occurs (the
letter `P` appears only inside identifiers such as `Prod`, `PreservesFuture`,
`IsProper`, `nullPlus`, which are not word-boundary matches).

Task-01 declarations enter only in `Task03.lean`, which is the last module of the
development and is compiled only after the whole of `Core.lean` has compiled.

## 3. Definitions of Lorentz, future-preserving and orientation conditions — `DERIVED`

```lean
def IsLorentz (T : Long ≃ₗ[ℝ] Long) : Prop := ∀ X, Q2 (T X) = Q2 X

def FutureTimelike (X : Long) : Prop := 0 < X.1 ∧ 0 < Q2 X

def PreservesFuture (T : Long ≃ₗ[ℝ] Long) : Prop :=
  ∀ X, FutureTimelike X → FutureTimelike (T X)

def detL (T : Long ≃ₗ[ℝ] Long) : ℝ := (T u₀).1 * (T s₀).2 - (T s₀).1 * (T u₀).2

def IsProper (T : Long ≃ₗ[ℝ] Long) : Prop := detL T = 1

def ProperFutureLorentz (T : Long ≃ₗ[ℝ] Long) : Prop :=
  IsLorentz T ∧ PreservesFuture T ∧ IsProper T
```

No orientation condition is built into `PreservesFuture`; the orientation datum is
carried by the *separate* concrete number `detL T`, computed in the coordinate
basis `(u₀, s₀)`.  That the two notions are genuinely different is proved:
`detL_eq_one_or_neg_one` shows `detL T = ±1` for every Lorentz map, and
`transport_ne_transportFlip` exhibits, for every pair of normalized future units,
two distinct future-preserving transporters with opposite determinants.

Normal form (`lorentz_normal_form`, `futureLorentz_normal_form`), proved by explicit
coordinate computation from `Q2`-preservation alone: with `a = (T u₀).1`,
`c = (T u₀).2` one has `a² - c² = 1` and either

```
T (t,x) = (a t + c x, c t + a x)     and detL T =  1
```

or

```
T (t,x) = (a t - c x, c t - a x)     and detL T = -1,
```

and `PreservesFuture T ↔ 0 < (T u₀).1 = a` (`preservesFuture_iff`).

## 4. `Q2 → L2` preservation theorem — `DERIVED`

`L2_of_isLorentz : IsLorentz T → ∀ X Y, L2 (T X) (T Y) = L2 X Y`.

Preservation of the polarization is **not** a second axiom: it follows from
`L2 X Y = (Q2 (X+Y) - Q2 X - Q2 Y)/2` and additivity of `T`.  The whole normal-form
analysis, and hence every later result, depends on this derivation.

Row of the negative-control table: **Does `Q2` preservation imply `L2`
preservation? — PROVED.**

## 5. Normalized-unit orbit classification — `DERIVED`

* `futureUnit_map`: a future-preserving Lorentz map sends normalized future units
  to normalized future units. **PROVED.**
* `futureUnit_not_preserved_by_all_lorentz`: `-id` is a Lorentz map which does not
  preserve the future condition. **COUNTEREXAMPLE** (the future hypothesis is
  necessary).
* `futureUnit_orbit_transitive`: any two normalized future units are related by a
  future-preserving **and** orientation-preserving Lorentz map. **PROVED**, so the
  normalized future units form exactly one orbit; the freedom in the choice of
  unit is a Lorentz orbit, not a family of inequivalent structures.

## 6. Transporter existence theorem — `DERIVED`

For normalized `e`, `f` put

```
A = e.1 f.1 - e.2 f.2  ( = L2 e f )
C = e.1 f.2 - e.2 f.1  ( the coordinate determinant of the pair )
```

Then `A² - C² = (Q2 e)(Q2 f) = 1` (`transport_coeff`) and

```
transport he hf := hypRot A C  :  X ↦ (A X.1 + C X.2, C X.1 + A X.2)
```

satisfies `IsLorentz`, `detL = 1`, `PreservesFuture` (from `0 < A`,
`pairing_pos`) and `transport he hf e = f` (`transport_unit`).

The orientation-reversing partner uses `A' = e.1 f.1 + e.2 f.2`,
`C' = e.1 f.2 + e.2 f.1`:

```
transportFlip he hf := hypFlip A' C' : X ↦ (A' X.1 - C' X.2, C' X.1 - A' X.2),
```

with `detL = -1`, `PreservesFuture`, and `transportFlip he hf e = f`.

Both constructions use only `Q2`, its polarization, and the coordinates of `e`
and `f`.  **No Task-01 boost and no rapidity parameter is used.**

## 7. Transporter uniqueness / non-uniqueness classification — `DISCRETE CHOICE`

`transporter_classification`: if `T` is Lorentz, future-preserving and `T e = f`
(for normalized future `e`, `f`) then `T = transport he hf` or
`T = transportFlip he hf`, pointwise.  Together with
`transport_ne_transportFlip` and `transporters_exist_both`:

| Case | Result |
| --- | --- |
| A — future-preserving only | **PROVED EXACTLY TWO** transporters (`detL = +1` and `detL = -1`) |
| B — future-preserving + `detL = 1` | **PROVED UNIQUE** (`proper_transporter_unique`) |

## 8. Stabilizer classification — `DISCRETE CHOICE`

For a normalized future unit `e` put `reflectAt he := transportFlip he he`, i.e.

```
reflectAt he (t,x) = ((e.1²+e.2²) t - 2 e.1 e.2 x, 2 e.1 e.2 t - (e.1²+e.2²) x),
```

the `L2`-orthogonal reflection fixing `e`.

* `stabilizer_classification`: a future-preserving Lorentz `T` with `T e = e` is
  either the identity or `reflectAt he`. **PROVED EXACTLY TWO.**
* `stabilizer_elements`: both are genuine (`reflectAt` is Lorentz,
  future-preserving, fixes `e`) and `reflectAt he ≠ id` (`reflectAt_ne_id`,
  by the determinant).
* `proper_stabilizer_trivial`: adding `detL = 1` leaves only the identity.
  **PROVED UNIQUE.**
* Explicit representatives: `LinearEquiv.refl ℝ Long` and `reflectAt he`; at
  `e = u₀` the second is `(t,x) ↦ (t,-x)`.
* `stabilizer_isAutomorphism`: **every** stabilizer element is an automorphism of
  the reconstructed algebra `(Long, mu e, e)` — proved from the covariance theorem,
  not assumed.

## 9. Product covariance result — `DERIVED`

`mu_covariant : IsLorentz T → T (mu e X Y) = mu (T e) (T X) (T Y)`.

Proof: rewrite both sides by the Task-02 formula `mu_eq`, push `T` through the
linear operations, and use `L2_of_isLorentz`.  The coordinate multiplication of
Task 01 is never expanded; the hypothesis is only `Q2`-preservation (future
preservation is not needed for the covariance identity itself).

Packaged form (§7 of the task):

```lean
structure UnitalProd where
  prod : BiProd
  unit : Long

def alg (e : Long) : UnitalProd := ⟨mu e, e⟩

def IsUnitalIso (T) (A C : UnitalProd) : Prop :=
  T A.unit = C.unit ∧ ∀ X Y, T (A.prod X Y) = C.prod (T X) (T Y)
```

`lorentz_isUnitalIso : IsLorentz T → IsUnitalIso T (alg e) (alg (T e))`.

## 10. Fixed-product invariance versus family covariance — `DERIVED`

```
Fixed-product invariance :  FixedInvariant T e := ∀ X Y, T (mu e X Y) = mu e (T X) (T Y)
Family covariance        :  ∀ X Y, T (mu e X Y) = mu (T e) (T X) (T Y)
```

* Family covariance holds for **every** Lorentz map (`mu_covariant`).
* `fixedInvariant_iff : IsLorentz T → Q2 e = 1 → (FixedInvariant T e ↔ T e = e)`.
  The forward direction uses covariance, surjectivity of `T`, and the Task-02
  uniqueness of a two-sided unit; no extra hypothesis is needed beyond `Q2 e = 1`.
* `fixed_product_not_invariant`: the transporter from `u₀` to `(5/4, 3/4)` is
  future-preserving Lorentz and does **not** leave `mu u₀` invariant.
  **COUNTEREXAMPLE.**

Hence the Task-02 fixed-product obstruction is exactly the statement that a
non-stabilizing Lorentz map moves the fibre; it is *not* a failure of covariance of
the family.

## 11. General spacelike-companion classification — `DISCRETE CHOICE`

`IsCompanion e s := L2 e s = 0 ∧ Q2 s = -1`.

`companion_classification` (for `Q2 e = 1`): `IsCompanion e s ↔ s = compl e ∨ s = -compl e`,
with `compl e = (e.2, e.1)`, and `compl_ne_neg_compl` shows the two are distinct:
**PROVED EXACTLY TWO**.  No orientation is used in the classification.

`companion_unique_oriented`: for a normalized *future* unit there is exactly one
companion with positive second coordinate — this is the (purely discrete)
orientation datum.

## 12. Ordered / unordered null-pair classification — `DISCRETE CHOICE`

```
nullPlus  e s = (1/2) • (e + s)
nullMinus e s = (1/2) • (e - s)
```

Derived without any Task-01 input, for every admissible pair `(e,s)`:

| Statement | Name |
| --- | --- |
| `Q2 (nullPlus e s) = 0`, `Q2 (nullMinus e s) = 0` | `Q2_nullPlus`, `Q2_nullMinus` |
| `mu e p₊ p₊ = p₊`, `mu e p₋ p₋ = p₋` | `mu_nullPlus_nullPlus`, `mu_nullMinus_nullMinus` |
| `mu e p₊ p₋ = 0` | `mu_nullPlus_nullMinus` |
| `p₊ + p₋ = e`, `p₊ - p₋ = s` | `nullPlus_add_nullMinus`, `nullPlus_sub_nullMinus` |
| `p₊(e,-s) = p₋(e,s)`, `p₋(e,-s) = p₊(e,s)` | `nullPlus_neg`, `nullMinus_neg` |
| `p₊ ≠ p₋` | `nullPlus_ne_nullMinus` |

Dependence on the data sets:

| Data set | Unordered pair `{p₊,p₋}` | Ordered pair `(p₊,p₋)` |
| --- | --- | --- |
| A `(Long, Q2)` | the two null **lines** are determined, but they are exchanged by a Lorentz map (`null_rays_exchanged`) | not determined |
| B `(Long, Q2, future)` | determined as an unordered pair of future null rays; still exchanged by the future-preserving map `(t,x) ↦ (t,-x)` | not determined |
| C `(Long, Q2, future, e)` | **determined**: `nullPair_unordered` — two companions give the same pair up to swap | **not determined**: `nullPair_ordered_not_determined` (the swap really occurs) |
| D `(Long, Q2, future, e, spatial orientation)` | determined | **determined**: `companion_unique_oriented` selects `s`, hence `(p₊,p₋)` |

So the `+`/`-` labels are **not** intrinsic to the Lorentz data, to the future
component, or even to the chosen unit; they are exchanged by a residual symmetry
of order two and are fixed exactly by an orientation choice.

## 13. Lorentz transport of the null idempotents — `DERIVED`

* `map_nullPlus`, `map_nullMinus`: `T (p±(e,s)) = p±(T e, T s)` for any linear `T`
  (pure linearity).
* `companion_map`: a Lorentz map carries companions of `e` to companions of `T e`.
* `proper_transport_compl`: a proper future transporter with `T e = f` satisfies
  `T (compl e) = compl f`; `improper_transport_compl`: one with `detL T = -1`
  satisfies `T (compl e) = -compl f`.
* Consequently `proper_transport_nullPair` (labels preserved) and
  `improper_transport_nullPair` (labels exchanged).
* `reflectAt_swaps_nullPair`: the nontrivial stabilizer element of `e` swaps
  `p₊(e, compl e)` and `p₋(e, compl e)`.

## 14. Product-family orbit / isomorphism result — `DERIVED`

`product_orbit`: for all normalized future `e`, `f` there is a Lorentz,
future-preserving, orientation-preserving `T` with
`IsUnitalIso T (alg e) (alg f)`, i.e. `T e = f` and
`T (mu e X Y) = mu f (T X) (T Y)`.

Weakest justified wording: the reconstructed products form **one orbit of the
proper future Lorentz group**, equivalently a single isomorphism class of unital
algebras-with-unit under Lorentz linear equivalences.  What is canonical is the
orbit (equivalence relation: conjugation by a future-preserving Lorentz linear
equivalence of `(Long,Q2)`), **not** any individual product: no single fibre `mu e`
is Lorentz-invariant (§10).

## 15. Conservation-of-difficulty dependency graph — generated from the proofs

```
(Long, Q2)                                        [INPUT]
   │  polarization identity
   ▼
L2 and its Lorentz preservation                   [DERIVED: L2_of_isLorentz]
   │  coordinate normal form
   ▼
Lorentz maps = 2 components × ℝ-family            [DERIVED: lorentz_normal_form,
   │                                               detL_eq_one_or_neg_one]
   │  + future component (extra datum: sign of (T u₀).1)
   ▼
future-preserving Lorentz maps act on             [DERIVED: futureUnit_map]
normalized future units
   │  explicit algebraic transporter
   ▼
single orbit of normalized future units           [DERIVED: futureUnit_orbit_transitive]
   │  Task-02 reconstruction + covariance
   ▼
single orbit of reconstructed products            [DERIVED: mu_covariant, product_orbit]
   │  stabilizer of the chosen unit
   ▼
residual group of order two                       [DISCRETE CHOICE: stabilizer_classification]
   │  its action on the null components
   ▼
unordered complementary null pair is fixed,       [DERIVED: nullPair_unordered,
ordered pair is exchanged                          reflectAt_swaps_nullPair]
   │  add a spatial-orientation datum
   ▼
ordered null pair (p₊,p₋)                         [DISCRETE CHOICE: companion_unique_oriented]
```

Extra assumptions attached to the arrows (none of them hidden in a definition):

* "Lorentz maps → action on future units" needs `PreservesFuture`; without it the
  statement is false (`futureUnit_not_preserved_by_all_lorentz`).
* "single orbit of units → single orbit of products" needs only `IsLorentz`
  (covariance), plus `Q2 e = 1` for the fibres to exist (Task-02).
* "residual group of order two → ordered pair" needs a genuinely new discrete
  datum; nothing in `(Long, Q2, future, e)` selects it.

Answers to the four audit questions of §17:

1. The normalized-unit freedom is **a single Lorentz orbit**, not a continuous
   family of inequivalent structures.
2. The product freedom is **one isomorphism class** represented in different
   Lorentz frames, not a continuous family of inequivalent products.
3. After quotienting by Lorentz transport a residual **discrete** ambiguity of
   order exactly two remains (the stabilizer of the chosen unit).
4. That ambiguity **is exactly** the exchange of the two null components: the
   nontrivial stabilizer element swaps `p₊` and `p₋` and is an algebra
   automorphism; nothing larger remains.

## 16. Late comparison with Task 01 — `COMPARISON ONLY`

In the comparison layer at the head of `Task03.lean` (the only Task-03 module
importing `RequestProject.NullSectorTask01.Boost`, hence `SplitComplex`):

| Result | Name |
| --- | --- |
| `boostEquiv η` is a linear equivalence and equals the Task-01 boost `B η` | `boostEquiv_eq_B` |
| It is Lorentz, future-preserving, proper | `boost_isLorentz`, `boost_preservesFuture`, `boost_isProper` |
| It maps normalized future units to normalized future units | `boost_futureUnit` |
| It **is** the independently constructed transporter from `u₀` to `B η u₀` | `transport_u₀_eq_boost`, `transport_u₀_eq_B` |
| Covariance holds for it | `boost_covariance`, `B_covariance` |
| Multiplicative transport `alg u₀ → alg (B η u₀)` | `boost_isUnitalIso` |
| `mu u₀` is boost-invariant iff the boost fixes `u₀` | `boost_fixedInvariant_iff` |
| `compl u₀ = s₀`, `nullPlus u₀ s₀ = ep`, `nullMinus u₀ s₀ = em` | `compl_u₀`, `nullPlus_u₀_eq_ep`, `nullMinus_u₀_eq_em` |
| Boost preserves the `+`/`-` labels; in Task-01 form the components are only rescaled by `exp(±η)` | `boost_preserves_labels`, `boost_ep_scaling`, `boost_em_scaling` |
| The labels are exchanged exactly by the orientation-reversing stabilizer element | `reflect_u₀_swaps_labels` |
| (§19, deferred) every normalized future unit is `(cosh η, sinh η)`; every proper future Lorentz map is a boost | `futureUnit_rapidity`, `proper_future_lorentz_is_boost` |

Rapidity is used **nowhere** in the core: the transporter, its uniqueness, the
stabilizer and the covariance theorem are purely algebraic.

## 17. Negative-control table (§21)

| Question | Outcome | Theorem |
| --- | --- | --- |
| Does `Q2` preservation imply `L2` preservation? | **PROVED** | `L2_of_isLorentz` |
| Does every future Lorentz map act on normalized future units? | **PROVED** (and **PROVED IMPOSSIBLE** without the future condition) | `futureUnit_map`, `futureUnit_not_preserved_by_all_lorentz` |
| Is the product family covariant? | **PROVED** | `mu_covariant` |
| Are all future normalized units in one orbit? | **PROVED** | `futureUnit_orbit_transitive` |
| Is transport unique without orientation data? | **PROVED EXACTLY TWO** | `transporter_classification`, `transport_ne_transportFlip` |
| Is transport unique with orientation data? | **PROVED UNIQUE** | `proper_transporter_unique` |
| Is a fixed product invariant under all Lorentz maps? | **PROVED IMPOSSIBLE** | `fixed_product_not_invariant` |
| Is a fixed product invariant exactly under the stabilizer of its unit? | **PROVED** | `fixedInvariant_iff` |
| Is a spacelike companion of `e` unique? | **PROVED EXACTLY TWO** | `companion_classification`, `compl_ne_neg_compl` |
| Is the ordered null pair intrinsic? | **PROVED NON-UNIQUE** (exchanged by a residual symmetry) | `nullPair_ordered_not_determined`, `null_rays_exchanged`, `reflectAt_swaps_nullPair` |
| Is the unordered null pair intrinsic once `e` is chosen? | **PROVED** | `nullPair_unordered` |
| Are all `mu_e` Lorentz-isomorphic? | **PROVED** | `product_orbit` |

No row is `UNRESOLVED`.

## 18. Source ledger

**IMPORTED STANDARD RESULT (Mathlib).**  Only elementary library material is used;
each item is a declaration of the installed revision (see §19):

| Declaration | Module | Use |
| --- | --- | --- |
| `LinearEquiv`, `LinearEquiv.ofLinear`, `LinearEquiv.refl`, `LinearEquiv.neg`, `map_add`, `map_smul`, `map_sub`, `LinearEquiv.apply_symm_apply` | `Mathlib/Algebra/Module/Equiv/*`, `Mathlib/Algebra/Group/Hom/*` | carrier of Lorentz maps |
| `LinearMap.mk₂`, `LinearMap.BilinMap` | `Mathlib/LinearAlgebra/BilinearMap.lean` | carrier of bilinear products (via Task 02) |
| `Prod.ext`, `Prod.mk.injEq` | `Mathlib/Data/Prod/Basic.lean` | coordinate reasoning |
| `mul_eq_zero`, `sq_nonneg` | `Mathlib/Algebra/Order/Ring/Lemmas.lean` | sign case splits |
| `Real.cosh_sq_sub_sinh_sq`, `Real.cosh_pos`, `Real.sinh_arsinh` | `Mathlib/Analysis/SpecialFunctions/Trigonometric/*`, `Mathlib/Analysis/SpecialFunctions/Arsinh.lean` | comparison layer only |
| tactics `ring`, `linarith`, `nlinarith`, `linear_combination`, `norm_num`, `simp`, `module`, `field_simp` | `Mathlib/Tactic/*` | kernel-checked automation |

**IMPORTED PROJECT RESULT (Task 02).**  Listed in §1; in particular the general
normalized-unit reconstruction `recAt` with `recAt_eq`, `recAt_admissible`,
`eq_recAt`, `generalUnit_existsUnique`, and `twoSidedUnit_unique`.

**COMPARISON TARGET (Task 01, late layer only).**  `B`, `ep`, `em`, `B_ep`, `B_em`,
`ep_eq`, `em_eq`.

**DERIVED IN TASK 03.**  Everything else: `IsLorentz`, `FutureTimelike`,
`PreservesFuture`, `detL`, `IsProper`, `L2_of_isLorentz`, `lorentz_normal_form`,
`preservesFuture_iff`, `futureLorentz_normal_form`, `detL_eq_one_or_neg_one`,
`hypRot`, `hypFlip`, `transport`, `transportFlip`, `pairing_pos`, `transport_unit`,
`futureUnit_map`, `futureUnit_orbit_transitive`, `transporter_classification`,
`proper_transporter_unique`, `reflectAt`, `stabilizer_classification`,
`proper_stabilizer_trivial`, `mu`, `mu_covariant`, `UnitalProd`, `alg`,
`IsUnitalIso`, `lorentz_isUnitalIso`, `product_orbit`, `FixedInvariant`,
`fixedInvariant_iff`, `fixed_product_not_invariant`, `stabilizer_isAutomorphism`,
`IsCompanion`, `companion_classification`, `companion_unique_oriented`,
`nullPlus`, `nullMinus` and all their identities, `nullPair_unordered`,
`proper_transport_nullPair`, `improper_transport_nullPair`,
`reflectAt_swaps_nullPair`, `null_rays_exchanged`, and the `task03_*` principal
theorems.

For the standard mathematics behind the classification of `O(1,1)` no external
theorem is imported: §20 of the task forbids solving the problem by importing a
group classification, and the normal form is proved from scratch on the concrete
carrier.

## 19. Exact toolchain

```
Lean            : 4.28.0            (lean-toolchain: leanprover/lean4:v4.28.0)
Mathlib         : v4.28.0, commit 8f9d9cff6bd728b17a24e163c9402775d9e6a365
lakefile.toml   : unchanged (no dependency upgraded or added)
```

## 20. Exact imports and import-firewall scan

```
Core.lean        : import RequestProject.NullSectorTask02.GeneralUnit
Task03.lean      : import RequestProject.NullSectorTask03.Core
                   import RequestProject.NullSectorTask01.Boost
```

Token scan of `Core.lean` (word-boundary, case-sensitive) — see §2:

```
Task01.SplitComplex : 0 matches
Task01.Boost        : 0 matches
Task01.Strata       : 0 matches
Task01.Limits       : 0 matches
Task01.Task01       : 0 matches
mulL, jL, oneL      : 0 matches
ep, em, qp, qm      : 0 matches
P, B4               : 0 matches
invProd             : 0 matches
B                   : 2 matches, both in comments (lines 463, 946), documented
                      individually in §2: the task's own labels "Case B" and
                      "data sets A and B".  Neither is a Task-01 declaration.
```

The substrings `ep`, `em`, `P` also occur inside ordinary words (`separate`,
`theorem`, `Prod`, `BiProd`), which are not word-boundary matches; the scan is
not weakened to suppress anything.

## 21. Build report

```
$ lake build
✔ Built RequestProject.NullSectorTask01.Basic / SplitComplex / Strata / Boost / Limits / Task01
✔ Built RequestProject.NullSectorTask02.LorentzData / CandidateProduct / FixedUnit /
        Minimality / GeneralUnit / Canonicality / Comparison / Task02
✔ Built RequestProject.NullSectorTask03.Core
✔ Built RequestProject.NullSectorTask03.Task03
Build completed successfully (8043 jobs).
```

The build is free of errors and of linter warnings.

No `sorry`, no `admit`, no `axiom` declaration occurs anywhere in
`RequestProject/NullSectorTask03/`, and none occurs anywhere in `RequestProject/`.

## 22. Axiom report

`#print axioms` for every principal theorem is executed at the end of
`Task03.lean`.  Each of

```
task03_polarization_preserved   task03_futureUnit_action
task03_covariance               task03_transport_of_algebras
task03_unit_orbit               task03_transporters_two
task03_proper_transporter_unique task03_stabilizer
task03_stabilizer_automorphisms task03_companions
task03_null_idempotents         task03_sign_flip
task03_unordered_pair           task03_ordered_pair_not_determined
task03_null_pair_transport      task03_product_orbit
task03_fixed_vs_family          task03_fixed_product_not_invariant
task03_residual_freedom         task03_task01_comparison
task03_rapidity
```

depends only on the standard Lean/Mathlib foundations

```
propext, Classical.choice, Quot.sound
```

and on definitions/theorems of Tasks 01–03.  No project-specific axiom exists.

## 23. Unresolved mathematical obligations

None within the scope fixed by the task: every row of the negative-control table
is closed with a positive or negative theorem, and every acceptance criterion of
§28 is formally resolved.

Deliberately *not* addressed (out of scope by §22, §23 of the task):

* any 3+1 statement, any other longitudinal plane, any rotation of the
  longitudinal axis;
* any dynamical, physical or interpretative content;
* group-theoretic packaging of the transporters as a Lie group (the classification
  is given concretely and no `O(1,1)` classification theorem is imported);
* rapidity beyond the two late cross-checks `futureUnit_rapidity` and
  `proper_future_lorentz_is_boost`.
