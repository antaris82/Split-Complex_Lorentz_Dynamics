# TASK XXIV AUDIT — Intrinsic oriented frame torsor and lifted frame reconstruction

## 0. Toolchain and provenance

| Item | Value |
| --- | --- |
| Lean | `leanprover/lean4:v4.28.0` (`lean-toolchain`, unchanged) |
| Mathlib | `v4.28.0` tag, as pinned in `lakefile.toml` / `lake-manifest.json` (unchanged) |
| New source | `RequestProject/NullSectorTask24/`, 8 modules, 1350 lines |
| Input layer | `RequestProject/NullSectorTask23/Task23.lean` (imported once, **unchanged**) |
| Prohibited constructs | none (`sorry`, `admit`, custom `axiom`, `implemented_by`, `native_decide`, `bv_decide`, `unsafe`, `partial`: 0 occurrences in the Task-24 directory) |

No file outside `RequestProject/NullSectorTask24/`, `README.md` and this audit was modified
(item 89: the Task-XXIII source is unchanged, not even by an added import).

## 1. Source chain

```
RequestProject.NullSectorTask23.Task23        (input, unchanged)
        ↓
NullSectorTask24.SafeBase                Package A   (freeze E, its form, its orientation datum, the visible action)
        ↓
NullSectorTask24.IntrinsicFrames         Package B   (FramePlus, nonemptiness, extensionality, basis)
        ↓
NullSectorTask24.VisibleFrameAction      Package C   (the Gvis action on FramePlus and its laws)
        ↓
NullSectorTask24.FrameTorsor             Packages D, E (freeness, transitivity, uniqueness)
        ↓
NullSectorTask24.ReferenceIndependence   Package F   (coordinate equivalence, change of reference)
        ↓
NullSectorTask24.LiftedFrames            Packages G, H, I (lifted carrier, two lifts, signs, transfer, Lift action)
        ↓
NullSectorTask24.Comparison              Package J + negative controls
        ↓
NullSectorTask24.Task24                  principal endpoints + axiom report
```

Eight modules, within the requested 6–8 range.

## 2. Exact definitions

| Name | Statement | Status |
| --- | --- | --- |
| `E` | `abbrev E : Type := Vec3` — the inherited three-dimensional spatial carrier | INHERITED DATA (packaging only) |
| `Gvis` | `abbrev Gvis : Type := GvisG` — the inherited visible group | INHERITED DATA (packaging only) |
| `LiftGrp` | `abbrev LiftGrp : Type := LiftG` — the inherited internal group | INHERITED DATA (packaging only) |
| `h3` | inherited positive-definite form on `E` | INHERITED DATA |
| `triple p q r` | `h3 (spCross p q) r` — minimal orientation datum (item 17) | NEW IN TASK 24 |
| `mat3 f` | matrix whose columns are the coordinate vectors of an ordered triple | NEW IN TASK 24 (technical) |
| `gact g p` | `spatAct ↑↑g p` — the inherited visible action on `E` | PACKAGING of an inherited definition |
| `IsOrthonormalTriple f` | `∀ i j, h3 (f i) (f j) = if i = j then 1 else 0` | NEW IN TASK 24 |
| `IsPositivelyOriented f` | `0 < triple (f 0) (f 1) (f 2)` | NEW IN TASK 24 |
| `FramePlus` | `{f : Fin 3 → E // IsOrthonormalTriple f ∧ IsPositivelyOriented f}` | NEW IN TASK 24 |
| `coordFrame` | the frame built from the inherited coordinate directions — used **only** for nonemptiness | NEW IN TASK 24 |
| `frameSmul g F` | `⟨fun i => gact g (F.vec i), …⟩`, packaged as `MulAction Gvis FramePlus` | NEW IN TASK 24 |
| `frameChange F G` | `mat3 G.vec * (mat3 F.vec)ᵀ` — the candidate transformation between two frames | NEW IN TASK 24 |
| `frameHom F G` | the unique visible element with `frameHom F G • F = G` | NEW IN TASK 24 |
| `coord F₀ g` | `g • F₀`; `coordEquiv F₀ : Gvis ≃ FramePlus` | NEW IN TASK 24 |
| `LiftedFrame F₀` | `{p : LiftGrp × FramePlus // projCore p.1 • F₀ = p.2}` | NEW IN TASK 24 |
| `liftedFrameProj F₀` | `x ↦ x.frame` | NEW IN TASK 24 |
| `signSmul F₀ e x` | `⟨(e * x.elt, x.frame), …⟩`, packaged as `MulAction KerSign (LiftedFrame F₀)` | NEW IN TASK 24 |
| `liftedSetoid F₀` | the relation "same image under `liftedFrameProj`" | NEW IN TASK 24 |
| `liftedTransfer F₀ F₁ u₀ h₀` | `x ↦ (x.elt * u₀⁻¹, x.frame)` : `LiftedFrame F₀ ≃ LiftedFrame F₁` | NEW IN TASK 24 |
| `lact u F` | `projCore u • F`, packaged as `MulAction LiftGrp FramePlus` | NEW IN TASK 24 |
| `ofLiftT`, `toGvisT`, `kerOf` | bridges between the packaged group carriers and the set-level carriers of the input layer | NEW IN TASK 24 (packaging) |
| `localLiftedFrame F₀ g` | the lifted frame induced by an inherited local representative | NEW IN TASK 24 |

`Lift`, `Gvis`, `proj`, the spatial carrier, its inner product and the inherited orientation
datum (the determinant theorem) are **not** redefined (scope firewall items 1–2).

## 3. Theorem inventory (principal endpoints, all `PROVED`)

Exposed in `Task24.lean` as `task24_*` (38 endpoints, each with `#print axioms`).

### Package A — the frozen carrier
* `gact_ip` — the visible action preserves the inherited inner product (IMPORTED: it is
  `NullSectorTask21.spatAct_preserves_inner`, restated).
* `gact_triple` — the visible action preserves the orientation datum. DERIVED IN TASK 24 from
  the inherited determinant theorem `NullSectorTask21.rotMat_det`.
* `gact_one`, `gact_mul`, `gact_add`, `gact_smul` — action and linearity laws.

### Package B — intrinsic frames
* `framePlus_nonempty`; `FramePlus.ext`, `FramePlus.ext_iff_three`;
* `frame_expand` (exact expansion), `frame_span`, `frame_linearIndependent`, `frameBasis`;
* `mat3_transpose_mul`, `mat3_det_one`, `triple_frame` (the orientation datum of a frame is
  exactly `1`).

### Package C — the visible action on frames
* `gact_orthonormalTriple`, `gact_positivelyOriented`;
* `MulAction Gvis FramePlus`, `frame_one_smul`, `frame_mul_smul`.

### Package D — freeness
* `gact_eq_self_of_fixes_frame` → `rotMat_eq_one_of_gact_id` → `eq_one_of_gact_id` →
  **`frameAction_free`**, `frameAction_free_iff`, `frameAction_cancel`,
  `stabilizer_frame_eq_bot`.

### Package E — transitivity
* `frameChange_orthogonal`, `frameChange_det`, `frameChange_mem_SO3`, `frameChange_mul_mat3`;
* **`frameAction_transitive`**, `MulAction.IsPretransitive Gvis FramePlus`;
* **`existsUnique_gvis_map_frame`**, `framePlus_free_transitive`, `frameHom`,
  `frameHom_smul`, `frameHom_unique`, `frameHom_self`.

### Package F — reference frames
* `coord_bijective`, `coordEquiv`, `coordEquiv_symm_apply`;
* `coord_change`, `coordEquiv_change`, `coordEquiv_transition`;
* **`reference_independence`**, `coord_ne_of_ne` (negative control).

### Package G — the lifted carrier
* `liftedFrameProj_surjective`, `liftedFrameProj_eq_iff`;
* **`two_lifts`**, `lifted_fibre_ncard` (`= 2`);
* **`liftedFrame_eq_iff_sign`**, `signSmul_free`;
* `liftedSetoid_iff_sign`, **`liftedQuotientEquiv`**, `liftedEltEquiv`.

### Package H — removing the reference frame
* `liftedTransfer` (explicit equivalence), `liftedTransfer_elt`, **`liftedTransfer_proj`**,
  **`liftedTransfer_sign`**, **`liftedTransfer_choice`**.

### Package I — the internal carrier acting on frames
* `lact`, `MulAction LiftGrp FramePlus`, `lact_transitive`;
* **`lact_stabilizer`** (`= KerSign`), **`lact_eq_iff`**, `lact_not_free`.

### Package J and negative controls
* `ofLiftT`, `toGvisT`, `toGvisT_injective`, `toGvisT_projCore` (bridges);
* `kerOf`, `kerOf_mem`, `ofLiftT_sact`;
* **`localLiftedFrame_overlap`**, `localLiftedFrame_same_frame`;
* `exists_nontrivial_gvis`, **`no_gvis_fixed_frame`**, `liftedFrameProj_not_injective`.

## 4. Dependency DAG (Package K)

Legend: `[I]` inherited data/theorem, `[N]` newly constructed object, `[T]` newly proved
theorem, `[C]` temporary coordinate/reference choice (**not** an intrinsic dependency).

```
[I] metric-oriented spatial carrier E  (carrier + h3 + inherited determinant theorem)
      │
      ├─[N] triple  (minimal orientation predicate, item 17)
      │        │
      │        └─[N] IsPositivelyOriented
      │
      ├─[N] IsOrthonormalTriple
      │
      └──────────────► [N] FramePlus E
                            │
   [C] coordFrame ─────────►│  (used ONLY for framePlus_nonempty; not a dependency of the definition)
                            │
[I] visible action of Gvis on E (+ inner-product preservation [I], orientation preservation [T])
                            │
                            └─[T] Gvis action on FramePlus  (Package C)
                                     │
                     ┌───────────────┴───────────────┐
        [T] frameAction_free              [T] frameAction_transitive
        (uses: frame spans E [T],          (uses: mat3 orthogonal [T], det = 1 [T],
         faithfulness of the visible        and the inherited surjectivity theorem
         representation [I])                `toRot_surjective` [I])
                     └───────────────┬───────────────┘
                                     │
                        [T] existsUnique_gvis_map_frame
                                     │
              [C] reference frame F₀ ─┴─► [T] coordEquiv F₀ : Gvis ≃ FramePlus
                                          [T] coord_change / reference_independence
                                     │
[I] projCore : Lift → Gvis  (certified in the input layer)
[I] KerSign = ker projCore = {±1}  (two elements, certified)
                                     │
                        [N] LiftedFrame F₀   ([C] F₀ temporary)
                                     │
             ┌───────────────────────┼────────────────────────┐
   [T] two lifts per frame   [T] kernel sign action free   [T] quotient ≃ FramePlus
   [T] lifts differ by a unique sign
                                     │
                        [T] liftedTransfer (F₀ ↦ F₁) + compatibilities
                             ⇒ the lifted object is reference-independent up to explicit
                               canonical equivalence (unique up to a classified kernel sign)
                                     │
                        [T] lact / lact_stabilizer = KerSign / lact_not_free
```

Arrows requiring an extra assumption:
* `frameAction_transitive` uses the **inherited surjectivity theorem** of the visible carrier
  onto the standard rotation matrices (explicitly permitted, item 34). Everything else in the
  proof is the intrinsic construction of the candidate transformation.
* `liftedTransfer` needs a **chosen internal element** `u₀` over the change-of-reference
  transformation; the dependence on that choice is exactly one kernel sign
  (`liftedTransfer_choice`).
* The Task-XXIII four-chart atlas is a **prior proof route only**: it appears nowhere in
  Packages A–I, and only in the single compatibility theorem of Package J (item 73).

## 5. Causal reading of the two actions

| Object | Acts on | Free? | Transitive? | Stabilizer |
| --- | --- | --- | --- | --- |
| `Gvis` | `FramePlus E` | YES (`frameAction_free`) | YES (`frameAction_transitive`) | trivial (`stabilizer_frame_eq_bot`) |
| `KerSign = {±1}` | `LiftedFrame F₀` | YES (`signSmul_free`) | on each fibre (`liftedFrame_eq_iff_sign`) | trivial |
| `Lift` | `FramePlus E` | **NO** (`lact_not_free`) | YES (`lact_transitive`) | exactly `KerSign` (`lact_stabilizer`) |
| `Lift` | `LiftedFrame F₀` | (in bijection with `Lift` after fixing `F₀`: `liftedEltEquiv`) | — | — |

Item 64, strongest correct formulation: **`LiftedFrame F₀` is not a free transitive
`Lift`-object over `FramePlus` in the naive sense** — the `Lift`-action *on ordinary frames*
has stabilizer `{±1}`, so it is not free; what is true is that, after retaining the sign
sheet, the lifted carrier is in explicit bijection with `Lift` itself (`liftedEltEquiv`), and
the residual `{±1}` acts freely on it with quotient `FramePlus`.

## 6. Required final decision table

| Question | Verdict |
| --- | --- |
| Intrinsic oriented orthonormal frame carrier constructed? | **PROVED** |
| Definition independent of `Gvis`? | **PROVED** (by inspection: `FramePlus` mentions only `E`, `h3`, `triple`) |
| Definition independent of reference frame? | **PROVED** (`coordFrame` occurs only in `framePlus_nonempty`) |
| `Gvis` acts on frames? | **PROVED** |
| Action free? | **PROVED** |
| Action transitive? | **PROVED** |
| Unique `Gvis` element between any two frames? | **PROVED** |
| Reference frame yields coordinate equivalence `Gvis ≃ FramePlus E`? | **PROVED** (set/group level) |
| Change of reference explicitly classified? | **PROVED** (right translation by `frameHom F₀ F₁`) |
| Lifted-frame carrier constructed? | **PROVED** |
| Exactly two lifted representatives per frame? | **PROVED** |
| Difference exactly `{±1}`? | **PROVED** |
| Lifted construction reference-independent? | **PROVED** (explicit equivalence; canonical up to one classified kernel sign) |
| Stabilizer of `Lift` action exactly `{±1}`? | **PROVED** |
| Task-XXIII local signs compatible with lifted-frame signs? | **PROVED** (one compatibility theorem, uniform in the reference frame) |
| Frame bundle over nontrivial base constructed? | **NO** |
| Spin structure constructed? | **NO** |
| Physical spin derived? | **NO** |

## 7. Negative controls

| Item | Formal statement | Verdict |
| --- | --- | --- |
| 74 | `no_gvis_fixed_frame` — no frame is fixed by the visible carrier, so the frame carrier has no distinguished element, unlike a group with its unit; and `FramePlus` is a subtype of `Fin 3 → E`, not the visible carrier | PROVED |
| 75 | `coord_ne_of_ne` — distinct reference frames give distinct coordinate maps: the equivalence does not make a reference frame intrinsic | PROVED |
| 76 / 77 | `liftedFrameProj_not_injective` — the lifted carrier is a two-valued object over a *single* frame carrier; no base space, no bundle, no spin structure is constructed (there is no manifold, tangent bundle or characteristic class anywhere in the layer) | PROVED / by construction |
| 78 | The layer contains no varying family of fibres: every construction is over the single carrier `E` | by construction |
| 79 | The four-chart atlas of the input layer is used nowhere in Packages A–I | by inspection of the imports and proofs |
| 80 | No physical vocabulary occurs in any statement | by inspection |
| item 64 | `lact_not_free` — the internal action on frames is not free | PROVED |

## 8. Unresolved mathematical obligations

1. **Topology on `FramePlus`** (item 43): not developed. The coordinate equivalence
   `coordEquiv F₀` is a bijection of sets only; no topology was inherited on the frame
   carrier, and building one (and proving the equivalence is a homeomorphism) would be a new
   development, explicitly out of budget. Recorded as an open obligation, not a failure.
2. **Formal torsor packaging**: `FramePlus` is proved to be a nonempty free transitive
   `Gvis`-set (`framePlus_free_transitive`), but no `Torsor` typeclass instance is registered;
   Mathlib's bundled torsor API is additive, and adapting it was judged not worth the cost
   (item 38 explicitly permits this).
3. **Canonicity of `liftedTransfer`**: the comparison equivalence between the two lifted
   carriers requires a choice of internal element over the change-of-reference
   transformation. The dependence is exactly one kernel sign (`liftedTransfer_choice`); a
   choice-free comparison would require additional structure and is not claimed.
4. **Package J scope**: only one compatibility theorem with the inherited local covering data
   is proved (as the task allows); no statement about continuity of the induced local lifted
   frames is made, since no topology on `FramePlus` exists here.

## 9. Failed attempts that changed a proof boundary (item 90)

No theorem statement was weakened. Two proof boundaries moved:

1. `liftedTransfer_proj` was first written as `rfl`. The kernel timed out on it: the
   definitional unfolding forces reduction of frame values built from `frameHom`, which is a
   `Classical.choose` term. The statement was kept unchanged; the proof was rewritten to use
   the compatibility condition (`LiftedFrame.spec`) and the group law instead of definitional
   equality. This is the only place where a definitional proof had to be replaced by a
   propositional one.
2. `Module.Basis` (not `Basis`) is the correct name in the installed Mathlib revision;
   `frameBasis` was adjusted accordingly. Similarly `Module.Basis.mk_apply`.

Two further build failures were routine: missing `noncomputable` markers on definitions
depending on the (noncomputable) certified projection, and two `norm_num` calls that needed
`Matrix.cons_val_two`/`Matrix.tail_cons` to reduce the third component of an explicit triple.

## 10. Source ledger

### IMPORTED STANDARD RESULT (Mathlib, exact declarations used)
* `Matrix.det_fin_three`, `Matrix.det_mul`, `Matrix.det_transpose`, `Matrix.det_one`
  (`Mathlib/LinearAlgebra/Matrix/Determinant/*`);
* `Matrix.mem_orthogonalGroup_iff`, `Matrix.mem_specialOrthogonalGroup_iff`
  (`Mathlib/LinearAlgebra/UnitaryGroup.lean`);
* `mul_eq_one_comm` (`Mathlib/Algebra/Group/Basic.lean`);
* `Module.Basis.mk`, `Module.Basis.mk_apply`, `Fintype.linearIndependent_iff`
  (`Mathlib/LinearAlgebra/Basis/*`, `Mathlib/LinearAlgebra/LinearIndependent/*`);
* `Equiv.ofBijective`, `Equiv.mulRight`, `Quotient.lift`, `Quotient.inductionOn₂`,
  `Set.ncard_pair`, `MulAction.stabilizer`, `MulAction.mem_stabilizer_iff`,
  `MonoidHom.mem_ker`, `Subgroup.eq_bot_iff_forall`, `injective_iff_map_eq_one`,
  `inv_smul_eq_iff`, `inv_eq_of_mul_eq_one_right`.

### INHERITED FROM THE EARLIER LAYERS (used unchanged, not reproved)
* `NullSectorTask04.Vec3`, `NullSectorTask14.h3`, `NullSectorTask14.spCross`,
  `NullSectorTask21.be`, `NullSectorTask21.vc`, `NullSectorTask21.cv`;
* `NullSectorTask21.spatAct`, `spatAct_one`, `spatAct_comp`, `spatAct_preserves_inner`,
  `rotMat`, `rotMat_mulVec`, `rotMat_det`, `toRot`, `toRot_injective`, `toRot_surjective`;
* `NullSectorTask21.GvisG`, `LiftG`, `WG`, `projCore`, `projCore_surjective`, `lNegOne`;
* `NullSectorTask23.KerSign`, `KerSign_eq`, `pr`, `Vset`, `sec`, `sec_eq_tau_smul`, `tauAt`,
  `Sgn`, `sact`.

### DERIVED IN TASK 24
Everything listed in §2 as NEW IN TASK 24 and every theorem listed in §3.

## 11. Build and axiom report

| Command | Result |
| --- | --- |
| `lake build RequestProject.NullSectorTask24.Task24` | **green, 8213 jobs** |
| `lake build` (whole project) | **green, 8284 jobs** |
| Warnings in `RequestProject/NullSectorTask24/` | **0** |
| Warnings project-wide | 114, all pre-existing style/deprecation notes in earlier, unmodified layers (Tasks 11, 14, 21) |
| `#print axioms` on all 38 endpoints | every one reports exactly `[propext, Classical.choice, Quot.sound]`; `sorryAx` occurs nowhere |
| Prohibited-token scan of the Task-24 directory | `sorry` 0, `admit` 0, `axiom` 0, `implemented_by` 0, `native_decide` 0, `bv_decide` 0, `unsafe` 0, `partial` 0 |

## 12. Central success criterion

> The oriented orthonormal frames of the reconstructed three-dimensional visible metric
> carrier form an intrinsic object on which `Gvis` acts freely and transitively, and the
> already certified double cover `Lift → Gvis` induces a reference-independent two-valued lift
> of that frame object.

**Met.** `FramePlus` (Package B) is defined without the visible carrier and without a
reference frame; `frameAction_free` and `frameAction_transitive` give the free transitive
action, `existsUnique_gvis_map_frame` its sharp form; `LiftedFrame` with `two_lifts`,
`liftedFrame_eq_iff_sign`, `signSmul_free`, `liftedQuotientEquiv` gives the two-valued lift,
and `liftedTransfer` with its compatibilities gives its reference independence. No frame
bundle over a varying base, no spin structure and no physical interpretation is constructed or
claimed.
