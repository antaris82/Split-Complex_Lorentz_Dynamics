# TASK 08 AUDIT

**Minimal associative closure forced by the third orthogonal spatial direction**

Status vocabulary used throughout: `INPUT`, `INHERITED`, `DERIVED`,
`NEW PRODUCT DIRECTION`, `DEPENDENT PRODUCT DIRECTION`, `OUTSIDE OLD CARRIER`,
`OUTSIDE TWO-GENERATOR CLOSURE`, `FORCED RELATION`, `CLOSED`, `NOT CLOSED`,
`MINIMAL`, `EXACT DIMENSION`, `EXISTENCE WITNESS`, `FULL OLD-CARRIER EMBEDDING`,
`OBLIGATION RESOLVED`, `UNIQUE UP TO ISOMORPHISM`, `COMPARISON ONLY`,
`COUNTEREXAMPLE`, `OBSTRUCTION`, `UNRESOLVED`.

---

## 1. Exact toolchain

| Item | Value |
| --- | --- |
| Lean version | `leanprover/lean4:v4.28.0` (`lean-toolchain`) |
| Mathlib revision | `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (`lake-manifest.json`, tag `v4.28.0`) |
| Build system | `lake`, single library `RequestProject`, `defaultTargets = ["RequestProject"]` |
| Build command | `lake build` |
| Mathlib import used by the Task-08 modules | `Mathlib` (transitively, through the inherited Task-01/02/04/06/07 base modules) |

Task 08 introduces no new external dependency and does not change the toolchain.

---

## 2. Exact source ledger

All Task-08 files live in `RequestProject/NullSectorTask08/`.  Each module imports
exactly one predecessor, so the source order is a chain and enforces the required
derivation order (§45 of the task statement).

| # | Module | Imports | Role |
| --- | --- | --- | --- |
| 0 | `SafeBase.lean` | `RequestProject.NullSectorTask07.Minimality` | inherited old-carrier data, third direction `dirC`, import ledger |
| 1 | `ThirdDirection.lean` | `…Task08.SafeBase` | `C := ι c`, derivation of `C ⋆ C = 1` |
| 2 | `InheritedRelations.lean` | `…Task08.ThirdDirection` | polarization ⇒ `AC = -CA`, `BC = -CB` |
| 3 | `NewMixedProducts.lean` | `…Task08.InheritedRelations` | first definitions `Q := A⋆C`, `R := B⋆C`, `S₃ := P⋆C`, parenthesizations |
| 4 | `ForcedRelations.lean` | `…Task08.NewMixedProducts` | complete forced-relation ledger, channel squares |
| 5 | `Membership.lean` | `…Task08.ForcedRelations` | membership in `ι(Vec4)` and in the Task-07 closure `G₂` |
| 6 | `Independence.lean` | `…Task08.Membership` | linear independence of the eight derived elements |
| 7 | `GeneratedClosure.lean` | `…Task08.Independence` | `G₃`, coefficient product law, closure, dimension, table |
| 8 | `Minimality.lean` | `…Task08.GeneratedClosure` | minimality, word reduction, `G₂ < G₃` |
| 9 | `StructuralDiagnostic.lean` | `…Task08.Minimality` | commutation diagnostic for `S₃` |
| 10 | `DirectWitness.lean` | `…Task08.StructuralDiagnostic` | direct 8-dimensional real witness `Wit8` |
| 11 | `FullVec4Embedding.lean` | `…Task08.DirectWitness` | `ι₃`, square preservation, symmetric product, ambient existence |
| 12 | `Uniqueness.lean` | `…Task08.FullVec4Embedding` | generator-preserving isomorphism, product uniqueness |
| 13 | `SignPermutationAudit.lean` | `…Task08.Uniqueness` | permutation and sign diagnostics |
| 14 | `Identification.lean` | `…Task08.SignPermutationAudit` | **COMPARISON ONLY** late identification |
| 15 | `Task08.lean` | `…Task08.Identification` | principal theorems + `#print axioms` |

`Identification.lean` is imported by `Task08.lean` and by nothing else; no
reconstruction module depends on it.

---

## 3. Exact Task-07 imports

The single entry point is `RequestProject.NullSectorTask07.Minimality`, whose
transitive closure inside the project is

```
NullSectorTask01.Basic
NullSectorTask02.LorentzData, CandidateProduct, FixedUnit
NullSectorTask04.Lorentz4, RestSpace, Sectors, GlobalExtension
NullSectorTask06.SafeBase, GenericExtension, AssociativityObstruction
NullSectorTask07.SafeBase, AmbientExtension, Polarization, TwoDirections,
                 MixedProduct, NewDirection, ForcedRelations,
                 GeneratedClosure, Minimality
```

Inherited declarations actually used:

| Declaration | Origin | Status |
| --- | --- | --- |
| `Vec4`, `Q4` | `NullSectorTask01.Basic` | INHERITED |
| `L4`, `e₀`, `sp`, `dot3`, `Vec3`, `Rest`, `vec4_ext` | `NullSectorTask04.Lorentz4/RestSpace` | INHERITED |
| `r₁`, `r₂`, `r₃`, `symForced`, `symForced_rest` | `NullSectorTask06.SafeBase/GenericExtension` | INHERITED |
| `oldSq`, `musym`, `dirA`, `dirB` | `NullSectorTask07.SafeBase` | INHERITED |
| `AmbientExt`, `AssociativeE`, `TwoSidedUnitE`, `PreservesOldSquares` | `NullSectorTask07.AmbientExtension` | INHERITED |
| polarization of the old square law | `NullSectorTask07.Polarization` | INHERITED |
| `genA`, `genB`, `genA_sq`, `genB_sq`, `mul_genA_genB`, `mul_genB_genA` | `NullSectorTask07.TwoDirections` | INHERITED |
| `genP` (`P := A ⋆ B`) and its forced relations | `NullSectorTask07.MixedProduct/ForcedRelations` | INHERITED |
| `genP ∉ range ι` | `NullSectorTask07.NewDirection` | INHERITED |
| `Gsub`, `finrank_Gsub = 4`, `Gsub_least` | `NullSectorTask07.GeneratedClosure/Minimality` | INHERITED |

**`RequestProject.NullSectorTask07.Identification` is not imported by any
Task-08 module.**  It is mentioned only in the `SafeBase.lean` doc comment, as an
explicit exclusion note.

---

## 4. Experiment-1 firewall report

No Task-08 module imports, cites, mentions, or reuses any Experiment-1 result,
formula, source, theorem, terminology, repository, paper, prompt, Lean
declaration, or interpretation.  The complete import set of the Task-08 chain is
listed in §3; every entry is an Experiment-2 module or Mathlib.

Verification performed: a recursive scan of `RequestProject/` shows no reference
to any Task-05 module (`rg -l "Task05"` → no match), and the import closure of
`Task08.SafeBase` is exactly the list in §3.

`FIREWALL: EXPERIMENT-1 — CLEAN.`
`FIREWALL: TASK-05 — NOT IMPORTED ANYWHERE.`

---

## 5. Target-structure firewall report

The reconstruction modules (items 0–13 of §2, i.e. all of
`RequestProject/NullSectorTask08/*.lean` except `Identification.lean`) were
scanned, case-insensitively, for

```
clifford, geometric algebra, exterior, grassmann, bivector, trivector,
multivector, pseudoscalar, quaternion, octonion, matrix, pauli, spinor,
complexification, wedge, hodge
```

**Result: zero occurrences.**  No such structure is used as an input, target,
proof shortcut, implementation carrier, or naming convention anywhere before the
late identification layer.  The witness of §17 below is defined as
`Fin 8 → ℝ` with an explicit coefficient formula transcribed from the derived
table; no library algebra supplies its existence, dimension, closure, or
associativity.

`FIREWALL: TARGET STRUCTURE — CLEAN.`

Source-order report: the module chain of §2 is a strict linear order, so no later
construction can leak backwards.  In particular the definitions `genQ`, `genR`,
`genS` occur (module 3) strictly after `genC_sq` (module 1) and
`pairwise_anticommutation` (module 2); the span `G3` occurs (module 7) strictly
after the independence classification (module 6); the multiplication table
(module 7, after `G3_mul_closed`) occurs strictly after all forced relations
(module 4); and the witness (module 10) occurs strictly after dimension and
minimality (modules 7–8).

---

## 6. Third-direction definition

```lean
def dirC : Vec4 := sp r₃            -- SafeBase.lean
def genC (S : AmbientExt E) : E := S.iota dirC   -- ThirdDirection.lean
```

Coordinates (`dir_coords`): `dirA = (0,1,0,0)`, `dirB = (0,0,1,0)`,
`dirC = (0,0,0,1)`; `e₀ = (1,0,0,0)`.

Inherited old-carrier data, proved in `SafeBase.lean` and collected as
`old_carrier_data` (exposed as `task08_old_carrier_data`):

```
L4 e₀ dirA = 0   L4 e₀ dirB = 0   L4 e₀ dirC = 0
Q4 dirA = -1     Q4 dirB = -1     Q4 dirC = -1
L4 dirA dirB = 0 L4 dirA dirC = 0 L4 dirB dirC = 0
```

Component lemmas: `L4_e₀_dirC`, `Q4_dirC`, `L4_dirA_dirC`, `L4_dirB_dirC`,
`dirC_mem_Rest`, `e₀_dir_indep`.

Exactly one new old spatial generator is introduced.  **No fourth spatial
direction occurs anywhere in Task 08.**

---

## 7. Inherited square and anticommutation derivation

Dependency actually realized in the source:

```
old square law (AmbientExt.oldsq)
    ↓
polarization (NullSectorTask07.Polarization)
    ↓
orthogonality (L4 dirA dirC = 0, L4 dirB dirC = 0)
    ↓
pairwise anticommutation
```

| Result | Theorem | Status |
| --- | --- | --- |
| `oldSq dirC = e₀` | `oldSq_dirC` | DERIVED (old carrier) |
| `C ⋆ C = 1` | `genC_sq` (`task08_third_generator_square`) | DERIVED |
| `A⋆C + C⋆A = 0` | `genA_genC_anticomm_sum` | FORCED RELATION |
| `B⋆C + C⋆B = 0` | `genB_genC_anticomm_sum` | FORCED RELATION |
| `C⋆A = -(A⋆C)` | `genC_genA` | FORCED RELATION |
| `C⋆B = -(B⋆C)` | `genC_genB` | FORCED RELATION |
| all three squares `A²=B²=C²=1` | `gen_squares` | DERIVED |
| all three anticommutations | `pairwise_anticommutation` (`task08_pairwise_anticommutation`) | DERIVED |

Anticommutation is nowhere imposed as an axiom: it is obtained from
`musym dirA dirC = 0` and `musym dirB dirC = 0` (`musym_dirA_dirC`,
`musym_dirB_dirC`) through the inherited polarization theorem.

---

## 8. First definitions of Q, R, and S

Introduced in `NewMixedProducts.lean`, i.e. strictly after §7:

```lean
def genQ : E := S.mul S.genA (genC S)      -- Q := A ⋆ C
def genR : E := S.mul S.genB (genC S)      -- R := B ⋆ C
def genS : E := S.mul S.genP (genC S)      -- S₃ := (A ⋆ B) ⋆ C
```

(The element called `S` in the task statement is named `genS` in Lean because the
ambient-extension datum already occupies the identifier `S`.)

Nothing about `Q`, `R`, `S₃` is assumed; every property below is a theorem.

Parenthesization theorem `genS_parenthesizations` (`task08_parenthesizations`):

```
S₃ = (A⋆B)⋆C = A⋆(B⋆C) = A⋆R = P⋆C = C⋆P     and     (A⋆C)⋆B = Q⋆B = -S₃
```

(component lemmas `genS_eq_genA_mul_genR`, `mul_genP_genC`, `mul_genC_genP`,
`genQ_mul_genB`).

---

## 9. Complete forced-relation ledger

All entries are theorems in `ForcedRelations.lean`, derived only from
`A²=B²=C²=1`, pairwise anticommutation, and associativity.  They are collected as
`task08_forced_relations`.

### Old generators against the new channels

| Product | Value | Theorem |
| --- | --- | --- |
| `A⋆Q` | `C` | `mul_genA_genQ` |
| `Q⋆A` | `-C` | `mul_genQ_genA` |
| `B⋆Q` | `-S₃` | `mul_genB_genQ` |
| `Q⋆B` | `-S₃` | `genQ_mul_genB` |
| `C⋆Q` | `-A` | `mul_genC_genQ` |
| `Q⋆C` | `A` | `mul_genQ_genC` |
| `A⋆R` | `S₃` | `mul_genA_genR` |
| `R⋆A` | `S₃` | `mul_genR_genA` |
| `B⋆R` | `C` | `mul_genB_genR` |
| `R⋆B` | `-C` | `mul_genR_genB` |
| `C⋆R` | `-B` | `mul_genC_genR` |
| `R⋆C` | `B` | `mul_genR_genC` |
| `A⋆S₃` | `R` | `mul_genA_genS` |
| `S₃⋆A` | `R` | `mul_genS_genA` |
| `B⋆S₃` | `-Q` | `mul_genB_genS` |
| `S₃⋆B` | `-Q` | `mul_genS_genB` |
| `C⋆S₃` | `P` | `mul_genC_genS` |
| `S₃⋆C` | `P` | `mul_genS_genC` |

### Interaction with the Task-07 channel `P`

| Product | Value | Theorem |
| --- | --- | --- |
| `P⋆Q` | `-R` | `mul_genP_genQ` |
| `Q⋆P` | `R` | `mul_genQ_genP` |
| `P⋆R` | `Q` | `mul_genP_genR` |
| `R⋆P` | `-Q` | `mul_genR_genP` |
| `P⋆S₃` | `-C` | `mul_genP_genS` |
| `S₃⋆P` | `-C` | `mul_genS_genP` |

### Squares of the new channels (derived, not prescribed)

| Square | Value | Theorem |
| --- | --- | --- |
| `Q⋆Q` | `-1` | `genQ_sq` |
| `R⋆R` | `-1` | `genR_sq` |
| `S₃⋆S₃` | `-1` | `genS_sq` |

### Interactions among Q, R, S₃

| Product | Value | Theorem |
| --- | --- | --- |
| `Q⋆R` | `-P` | `mul_genQ_genR` |
| `R⋆Q` | `P` | `mul_genR_genQ` |
| `Q⋆S₃` | `B` | `mul_genQ_genS` |
| `S₃⋆Q` | `B` | `mul_genS_genQ` |
| `R⋆S₃` | `-A` | `mul_genR_genS` |
| `S₃⋆R` | `-A` | `mul_genS_genR` |

Summary theorems: `forced_relations_old_generators`, `forced_relations_genS`,
`forced_relations_genP`, `forced_relations_new_channels`.

---

## 10. Membership results

### Old carrier `ι(Vec4)`

| Element | Verdict | Theorem |
| --- | --- | --- |
| `C` | **in** `ι(Vec4)` (it *is* an embedded old vector) | `genC_mem_range` |
| `P` | `OUTSIDE OLD CARRIER` | inherited Task-07 non-membership theorem |
| `Q` | `OUTSIDE OLD CARRIER` | `genQ_not_mem_range` |
| `R` | `OUTSIDE OLD CARRIER` | `genR_not_mem_range` |
| `S₃` | `OUTSIDE OLD CARRIER` | `genS_not_mem_range` |

Collected as `old_carrier_classification` (`task08_old_carrier_membership`).  The
structural argument is `not_image_of_sq_eq_neg_one`: an element whose square is
`-1` cannot be `ι X`, because the inherited square law would force
`ι (oldSq X) = -ι e₀`, contradicting injectivity of `ι` and the old carrier data.
So the classification is genuinely case-by-case and not a dimension count; note
that `C` is a mixed-product-free element and *does* lie in the old carrier,
confirming that "mixed product ⇒ outside" is not assumed.

### Task-07 closure `G₂ = spanℝ {1, A, B, P}`

| Element | Verdict | Theorem |
| --- | --- | --- |
| `C` | `OUTSIDE TWO-GENERATOR CLOSURE` | `genC_not_mem_Gsub` |
| `Q` | `OUTSIDE TWO-GENERATOR CLOSURE` | `genQ_not_mem_Gsub` |
| `R` | `OUTSIDE TWO-GENERATOR CLOSURE` | `genR_not_mem_Gsub` |
| `S₃` | `OUTSIDE TWO-GENERATOR CLOSURE` | `genS_not_mem_Gsub` |

Collected as `Gsub_membership_classification`
(`task08_two_generator_closure_membership`).  Method: the inner automorphisms
`conjBy S g x = (g ⋆ x) ⋆ g` for `g = A, B` act diagonally on the basis of `G₂`
(`conjBy_genA_gcomb`, `conjBy_genB_gcomb`) and with definite signs on each new
element (`conjBy_genA_genC`, …, `conjBy_genB_genS`).  Comparing eigen-sign
patterns forces the coefficient of each `G₂` basis vector to vanish, and the
residual scalar equations are killed by `scalar_obstruction` /
`scalar_obstruction'`.  This is a direct structural argument; no dimension count
is used.

---

## 11. Linear-independence classification

`comb8 S α β γ δ ε ζ η θ := α•1 + β•A + γ•B + δ•C + ε•P + ζ•Q + η•R + θ•S₃`.

**Theorem `comb8_eq_zero_iff`**: `comb8 S α β γ δ ε ζ η θ = 0` implies all eight
coefficients vanish.  Equivalently
`genFamily8_linearIndependent : LinearIndependent ℝ (genFamily8 S)`
(exposed as `task08_linear_independence`), where
`genFamily8 S = ![1, A, B, C, P, Q, R, S₃]`.

**No dependency occurs**: all eight elements are independent, in *every* ambient
extension `S`, i.e. the classification is uniform in `E`.  The proof multiplies a
vanishing combination on the left by each generator and by the channels and
projects (`genA_mul_comb8`, `genB_mul_comb8`, `genC_mul_comb8`, `comb8_proj`),
using the inherited nondegeneracy of `1, A, B, P` and the conjugation signs.

Consequently:

* `Q` — `NEW PRODUCT DIRECTION`
* `R` — `NEW PRODUCT DIRECTION`
* `S₃` — `NEW PRODUCT DIRECTION`
* no `DEPENDENT PRODUCT DIRECTION` occurs.

Answer to §41 of the statement: **Outcome C**.

---

## 12. Generated-span definition

Formed only after §11:

```lean
def genFamily8 : Fin 8 → E := ![S.oneE, S.genA, S.genB, genC S, S.genP, genQ S, genR S, genS S]
def G3 : Submodule ℝ E := Submodule.span ℝ (Set.range (genFamily8 S))
```

Basis index order: `0:1, 1:A, 2:B, 3:C, 4:P, 5:Q, 6:R, 7:S₃`.  No generator is
redundant (§11), so the span is defined on exactly the independently established
minimal family.

Normal form (`task08_normal_form`): every `x ∈ G₃` is `comb8 S a₀ … a₇` for some
reals (`mem_G3_iff`), and the coefficients are unique (`comb8_injective`).

---

## 13. Closure result

**Theorem `mul_comb8`** gives the derived coefficient law: the product of
`comb8 S a₀ … a₇` and `comb8 S b₀ … b₇` is again a `comb8` with explicit
bilinear coefficient expressions.  Hence

* `G3_mul_closed : x ∈ G₃ → y ∈ G₃ → x ⋆ y ∈ G₃`
* `G3_is_closed_subspace` (`task08_closure`): `1, A, B, C ∈ G₃` and `G₃ ⋆ G₃ ⊆ G₃`.

`CLOSED.`  **THREE-GENERATOR ASSOCIATIVE CLOSURE ACHIEVED.**

The complete 64-entry multiplication table is collected only afterwards, in
`table_one, table_genA, table_genB, table_genC, table_genP, table_genQ,
table_genR, table_genS`, exposed as `task08_multiplication_table`.  Every entry
cites an earlier theorem from §7 or §9; the table is never used to prove them.

Table (row `⋆` column):

| ⋆ | 1 | A | B | C | P | Q | R | S₃ |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| **1** | 1 | A | B | C | P | Q | R | S₃ |
| **A** | A | 1 | P | Q | B | C | S₃ | R |
| **B** | B | −P | 1 | R | −A | −S₃ | C | −Q |
| **C** | C | −Q | −R | 1 | S₃ | −A | −B | P |
| **P** | P | −B | A | S₃ | −1 | −R | Q | −C |
| **Q** | Q | −C | −S₃ | A | R | −1 | −P | B |
| **R** | R | S₃ | −C | B | −Q | P | −1 | −A |
| **S₃** | S₃ | R | −Q | P | −C | B | −A | −1 |

---

## 14. Exact dimension

**`finrank_G3 : Module.finrank ℝ (G3 S) = 8`** (exposed as `task08_dimension`).

`EXACT DIMENSION = 8`, an output derived from independence (§11) plus the
spanning definition (§12).  The integer `8` appears nowhere in the reconstruction
input: `SafeBase`–`Independence` contain no dimension claim; the basis index type
`Fin 8` is introduced in `Independence.lean` *after* `comb8_eq_zero_iff`.

Distinguish:

* ambient `E`: dimension unspecified, possibly infinite — never assumed finite;
* generated closure `G₃`: dimension derived, exactly `8`.

---

## 15. Minimality theorem

```lean
structure IsGenClosed3 (H : Submodule ℝ E) : Prop where
  one_mem : S.oneE ∈ H
  genA_mem : S.genA ∈ H
  genB_mem : S.genB ∈ H
  genC_mem : genC S ∈ H
  mul_mem : ∀ x ∈ H, ∀ y ∈ H, S.mul x y ∈ H
```

Forced memberships for any such `H`: `genP_mem_of_isGenClosed3`,
`genQ_mem_of_isGenClosed3`, `genR_mem_of_isGenClosed3`,
`genS_mem_of_isGenClosed3`.  Hence

* `G3_le_of_isGenClosed3 : IsGenClosed3 S H → G3 S ≤ H`
* `isGenClosed3_G3 : IsGenClosed3 S (G3 S)`
* `G3_least` (`task08_minimality`): `G₃` is itself product-closed and contained in
  every product-closed subspace containing `1, A, B, C`.

`MINIMAL.`

Word reduction (`word_reduction`, `task08_word_reduction`): since the set of
elements reachable by associative words in `A, B, C` is contained in every
`IsGenClosed3` subspace, and `G₃` is the least such, every associative word in
`A, B, C` lies in `G₃` and therefore has the unique eight-coefficient normal form
of §12.  No free-algebra quotient and no target-structure universal property is
used.

Task-07 comparison at this level: `Gsub_le_G3` and `Gsub_lt_G3` — the Task-07
closure is a **proper** subspace of `G₃`.

---

## 16. Structural diagnostic for S₃

`StructuralDiagnostic.lean`, collected as `genS_diagnostic`
(`task08_structural_diagnostic`):

| Pair | Behaviour | Theorem |
| --- | --- | --- |
| `A` vs `S₃` | commute (`A⋆S₃ = S₃⋆A = R`) | `genS_comm_genA` |
| `B` vs `S₃` | commute (`B⋆S₃ = S₃⋆B = -Q`) | `genS_comm_genB` |
| `C` vs `S₃` | commute (`C⋆S₃ = S₃⋆C = P`) | `genS_comm_genC` |
| `P` vs `S₃` | commute (`P⋆S₃ = S₃⋆P = -C`) | `genS_comm_genP` |
| `Q` vs `S₃` | commute (`Q⋆S₃ = S₃⋆Q = B`) | `genS_comm_genQ` |
| `R` vs `S₃` | commute (`R⋆S₃ = S₃⋆R = -A`) | `genS_comm_genR` |
| `S₃²` | `-1` | `genS_sq` |

No anticommuting case occurs.  Consequently `genS_central`: `S₃` commutes with
every element of `G₃`.  This is a diagnostic only; no interpretation is attached.

---

## 17. First direct finite witness

`DirectWitness.lean`.  Carrier

```lean
abbrev Wit8 : Type := Fin 8 → ℝ
```

with the product `wit8MulFun` given by eight explicit real bilinear coefficient
formulas transcribed from the derived table of §13, promoted to
`wit8Mul : Wit8 →ₗ[ℝ] Wit8 →ₗ[ℝ] Wit8`.  Basis vectors
`w1, wA, wB, wC, wP, wQ, wR, wS` are the standard coordinate vectors.

No library algebra, no representation, no known structure supplies the witness;
its carrier is a plain function space and its product is a formula.

Derived properties, each a theorem:

| Property | Theorem |
| --- | --- |
| bilinearity | by construction of `wit8Mul` as a `LinearMap` pair (`map_add'`, `map_smul'` discharged componentwise) |
| two-sided unit | `wit8Mul_one_left`, `wit8Mul_one_right`, `wit8TwoSidedUnit` |
| associativity | `wit8Mul_assoc`, `wit8Associative` |
| `A²=B²=C²=1` | `wit8_generator_squares` |
| pairwise anticommutation | `wit8_pairwise_anticommutation` |
| `wA⋆wB = wP`, `wA⋆wC = wQ`, `wB⋆wC = wR`, `wP⋆wC = wS` | `wit8_mixed_channels` |
| channel squares `= -1` | `wit8_channel_squares` |
| basis independence | `wit8_indep_coeffs` |
| complete derived table (all 64 entries) | the `wit8_wX_wY` family |
| summary | `wit8_summary` (`task08_witness`) |

`EXISTENCE WITNESS: CONSTRUCTED.`

---

## 18. Associativity proof for that witness

`wit8Mul_assoc (x y z : Wit8) : wit8Mul (wit8Mul x y) z = wit8Mul x (wit8Mul y z)`
is proved directly on coordinates: `funext i; fin_cases i` reduces the claim to
eight polynomial identities in the sixteen real coefficients of `x, y, z`, each
closed by `ring`.  No associativity is imported from an ambient structure.

---

## 19. Full Vec4 embedding

`FullVec4Embedding.lean`:

```lean
def iota3 : Vec4 →ₗ[ℝ] Wit8 where
  toFun X := ![X.1, X.2.1, X.2.2.1, X.2.2.2, 0, 0, 0, 0]
```

so that `e₀ ↦ w1`, `dirA ↦ wA`, `dirB ↦ wB`, `dirC ↦ wC` (`iota3_e₀`,
`iota3_dirA`, `iota3_dirB`, `iota3_dirC`).

**`iota3_injective : Function.Injective iota3`** — the first four coordinates are
read back off directly.

`FULL OLD-CARRIER EMBEDDING: ESTABLISHED.`

---

## 20. Square preservation for arbitrary old vectors

**`iota3_oldSq (X : Vec4) : iota3 (oldSq X) = wit8Mul (iota3 X) (iota3 X)`**
— proved for *every* old vector, not just for basis vectors, by expanding both
sides in coordinates.  Packaged as
`iota3_preservesOldSquares : PreservesOldSquares wit8Mul iota3`.

Hence the ambient-extension record

```lean
def wit8Ambient : AmbientExt Wit8
```

exists (`wit8Ambient_generators` records that its generators are `wA, wB` and its
third direction `wC`), and

* **`ambient_existence : Nonempty (AmbientExt Wit8)`** (`task08_ambient_existence`)
* **`ambient_existence_explicit`** (`task08_ambient_existence_explicit`), spelling
  out the data: `∃ m u j, AssociativeE m ∧ TwoSidedUnitE m u ∧ Injective j ∧
  j e₀ = u ∧ ∀ X, m (j X) (j X) = j (oldSq X)`.

> **THERE EXISTS A REAL ASSOCIATIVE AMBIENT EXTENSION OF THE COMPLETE OLD `Vec4`
> CARRIER PRESERVING THE INHERITED OLD SQUARE LAW.**

---

## 21. Recovery of the symmetric product

**`iota3_symmetric_product (X Y : Vec4)`**:

```
ι₃(X) ⋆ ι₃(Y) + ι₃(Y) ⋆ ι₃(X) = 2 • ι₃(μsym X Y)
```

for arbitrary old vectors, obtained by polarizing `iota3_oldSq`.  Together with
injectivity and square preservation this is `iota3_full_old_structure`
(`task08_full_vec4_embedding`).

So the witness is not a three-generator toy model: it reproduces the complete
previously reconstructed symmetric product structure of the old 3+1 carrier.

---

## 22. Task-07 obligation verdict

> **TASK07 FULL-AMBIENT EXISTENCE OBLIGATION RESOLVED POSITIVELY.**

Witness theorems cited: `task08_ambient_existence` (equivalently
`ambient_existence`), realized by the explicit record `wit8Ambient`, whose square
law is `iota3_preservesOldSquares` and whose injectivity is `iota3_injective`; the
unpacked form is `task08_ambient_existence_explicit`.

`OBLIGATION RESOLVED.`

---

## 23. Uniqueness result

`Uniqueness.lean`.

* `bilinear_product_unique` (`task08_product_uniqueness`): a bilinear product on
  `Wit8` is determined by its values on the 64 basis pairs; hence the derived
  table pins the product completely.
* `wit8ToE : Wit8 →ₗ[ℝ] E`, `x ↦ comb8 S x₀ … x₇`, is injective
  (`wit8ToE_injective`), multiplicative (`wit8ToE_mul`), has range exactly `G₃`
  (`wit8ToE_range`), and induces a linear equivalence
  `wit8EquivG3 : Wit8 ≃ₗ[ℝ] G3 S`.
* For any two ambient extensions `S`, `S'` (over possibly different carriers),
  `closureEquiv3 S S' : G3 S ≃ₗ[ℝ] G3 S'` is a linear equivalence which is
  * unit-compatible: `closureEquiv3_oneE`;
  * generator-preserving: `closureEquiv3_genA`, `closureEquiv3_genB`,
    `closureEquiv3_genC`;
  * automatically correct on all mixed channels: `closureEquiv3_mixed`
    (`P ↦ P'`, `Q ↦ Q'`, `R ↦ R'`, `S₃ ↦ S₃'`) — these are *theorems*, not part of
    the definition;
  * multiplicative: `closureEquiv3_mul`.

Collected as `task08_uniqueness`.

`UNIQUE UP TO ISOMORPHISM.`  Remaining ambiguity: none at the level of
generator-preserving maps — the map is determined on the basis and hence unique;
the statement is formulated as a linear equivalence with proved multiplicativity
rather than as an `AlgEquiv`, because `G₃` carries no `Ring` instance in this
development (the ambient product is a bare bilinear map).  This is a packaging
difference, not a mathematical gap.

---

## 24. Sign/permutation audit

`SignPermutationAudit.lean`.  All signs derived from the product definitions and
pairwise anticommutation; none assumed.

Transpositions (channel = product of the permuted pair, in the permuted order):

| Exchange | `P`-slot | `Q`-slot | `R`-slot | highest channel | Theorem |
| --- | --- | --- | --- | --- | --- |
| `A ↔ B` | `B⋆A = -P` | `B⋆C = R` | `A⋆C = Q` | `(B⋆A)⋆C = -S₃` | `swapAB_channels` |
| `A ↔ C` | `C⋆B = -R` | `C⋆A = -Q` | `B⋆A = -P` | `(C⋆B)⋆A = -S₃` | `swapAC_channels` |
| `B ↔ C` | `A⋆C = Q` | `A⋆B = P` | `C⋆B = -R` | `(A⋆C)⋆B = -S₃` | `swapBC_channels` |

Cyclic permutation `A → B → C → A`, i.e. the triple `(B, C, A)`:

| Channel | Image | Theorem |
| --- | --- | --- |
| `B⋆C` | `R` | `cyclic_channels` |
| `B⋆A` | `-P` | `cyclic_channels` |
| `C⋆A` | `-Q` | `cyclic_channels` |
| `(B⋆C)⋆A` | `+S₃` (invariant) | `cyclic_channels` |

Single sign flips:

| Flip | `P` | `Q` | `R` | `S₃` | Theorem |
| --- | --- | --- | --- | --- | --- |
| `A ↦ -A` | `-P` | `-Q` | `R` | `-S₃` | `negA_channels` |
| `B ↦ -B` | `-P` | `Q` | `-R` | `-S₃` | `negB_channels` |
| `C ↦ -C` | `P` | `-Q` | `-R` | `-S₃` | `negC_channels` |

Summary: `genS_permutation_summary` (`task08_sign_permutation_audit`) — the
highest channel changes sign under every transposition and under every single
sign flip, and is invariant under the tested cyclic permutation.  Structural
diagnostic only; no orientation machinery is introduced.

---

## 25. Late conventional identification (COMPARISON ONLY)

`Identification.lean`, imported by nothing except the top-level `Task08.lean`.

An explicit real-linear bijection `toMat : Wit8 → Matrix (Fin 2) (Fin 2) ℂ`
(inverse `fromMat`, `fromMat_toMat`, `toMat_fromMat`) satisfies

* `toMat_add`, `toMat_smul` — real-linear;
* `toMat_mul` — multiplicative: `toMat (x ⋆ y) = toMat x * toMat y`;
* `toMat_one` — unital;
* `toMat_bijective`.

Collected as `identification` (`task08_identification`).  Images of the
generators: `toMat wA = !![0,1;1,0]`, `toMat wB = !![0,-I;I,0]`,
`toMat wC = !![1,0;0,-1]`, `toMat wS = !![I,0;0,I]`.

So the independently reconstructed eight-dimensional real algebra is, as a real
algebra, the algebra of `2 × 2` complex matrices.  `COMPARISON ONLY` — no earlier
Task-08 theorem depends on this module.

---

## 26. Task-07 versus Task-08 structural comparison

`task08_task07_comparison`:

```
Gsub < G3 S,     finrank ℝ Gsub = 4,     finrank ℝ (G3 S) = 8,
C ∈ G3 S,  Q ∈ G3 S,  R ∈ G3 S,  S₃ ∈ G3 S
```

Structural inclusion, not merely a dimension statement:
`Gsub_le_G3` exhibits `G₂ = spanℝ{1,A,B,P}` as a subspace of `G₃`; it is closed
under the ambient product by the inherited Task-07 closure theorem, so it is a
**proper subalgebra** of `G₃`.  Properness is witnessed structurally by
`genC_not_mem_Gsub` (an *old* vector that leaves `G₂`), and additionally by
`genQ_not_mem_Gsub`, `genR_not_mem_Gsub`, `genS_not_mem_Gsub`.

What the third generator adds: exactly the four directions `C, Q = A⋆C,
R = B⋆C, S₃ = (A⋆B)⋆C`, i.e. one inherited old direction and three new product
directions; `4 → 8`.

---

## 27. Relationship to the Task-06 obstruction

* **Task 06**: an associative product closure *inside* the old `Vec4` carrier is
  impossible.
* **Task 07**: two old spatial directions admit a consistent minimal associative
  closure once mixed products are allowed to leave `Vec4`.
* **Task 08**: all three old spatial directions admit a common associative
  ambient closure preserving the full old square law — proved, §20.

Since the full Task-08 witness has now been proved, the following statement is
licensed:

> **The Task-06 obstruction did not prohibit associative extension; it prohibited
> associative closure inside the old carrier.**

No global `Q4`-multiplicativity claim is made or repaired; §37 of the statement is
respected (no norm, conjugation, trace, determinant, involution, adjoint,
absolute value, or new quadratic form is defined anywhere in Task 08).

---

## 28. §40 Conservation-of-Difficulty answers

| # | Question | Answer | Theorem |
| --- | --- | --- | --- |
| 1 | New product directions forced by the third old direction? | three: `Q`, `R`, `S₃` | `genFamily8_linearIndependent`, `Gsub_membership_classification` |
| 2 | Are `AC`, `BC` independent of the Task-07 closure? | yes, both outside `G₂` | `genQ_not_mem_Gsub`, `genR_not_mem_Gsub` |
| 3 | Is `(AB)C` an additional independent direction? | yes | `genS_not_mem_Gsub`, `genFamily8_linearIndependent` |
| 4 | Any apparent channel algebraically dependent? | no; all eight elements are independent | `comb8_eq_zero_iff` |
| 5 | Does the generated span close associatively? | yes | `G3_is_closed_subspace` |
| 6 | Exact dimension? | `8` | `finrank_G3` |
| 7 | Minimal closure containing all three inherited generators? | yes | `G3_least` |
| 8 | Direct finite-dimensional real witness? | yes, `Wit8` | `wit8_summary` |
| 9 | Injective copy of the complete old `Vec4`? | yes | `iota3_injective` |
| 10 | Old square law for every embedded old vector? | yes | `iota3_oldSq` |
| 11 | Polarization recovers the full old symmetric product? | yes | `iota3_symmetric_product` |
| 12 | Task-07 full-ambient existence question resolved? | positively | `ambient_existence` |
| 13 | Algebraic properties forced on `S₃`? | central in `G₃`, `S₃² = -1`, sign-odd under every transposition and single sign flip | `genS_diagnostic`, `genS_central`, `genS_permutation_summary` |

### Derived dependency graph (generated from proved results, not assumed)

```
old Vec4 data (old_carrier_data)
    ↓
Task-07 two-generator closure (Gsub, finrank_Gsub = 4)
    ↓
third old generator C (genC)
    ↓
C² = 1 (genC_sq)      ← old square law
    ↓
polarization + orthogonality ⇒ pairwise anticommutation (pairwise_anticommutation)
    ↓
Q := A⋆C, R := B⋆C (genQ, genR)
    ↓
S₃ := (A⋆B)⋆C (genS, genS_parenthesizations)
    ↓
forced relations + channel squares (forced_relations_*)
    ↓
membership (old_carrier_classification, Gsub_membership_classification)
    ↓
independence (genFamily8_linearIndependent)
    ↓
generated span G₃ (G3)
    ↓
closure (G3_is_closed_subspace)  →  multiplication table (table_*)
    ↓
dimension 8 (finrank_G3)
    ↓
minimality + word reduction (G3_least, word_reduction)
    ↓
diagnostic for S₃ (genS_diagnostic)
    ↓
direct finite witness (wit8_summary)
    ↓
full Vec4 embedding (iota3_injective)
    ↓
full old-square preservation (iota3_oldSq) → symmetric product (iota3_symmetric_product)
    ↓
ambient existence (ambient_existence)  ⇒ Task-07 obligation resolved
    ↓
uniqueness (closureEquiv3_*, bilinear_product_unique)
    ↓
sign/permutation audit (SignPermutationAudit)
    ↓
late conventional identification (identification)  [COMPARISON ONLY]
```

No arrow requires an assumption beyond: the abstract `AmbientExt` interface
(bilinear associative product, two-sided unit, injective linear `ι` with
`ι e₀ = oneE`, inherited old square law) and the inherited old-carrier
orthogonality/normalization data.  Finite-dimensionality of `E` is never assumed.

---

## 29. §48 required negative controls

| Question | Required | Result | Exact theorem |
| --- | --- | --- | --- |
| Does the inherited old square law force `C² = 1`? | prove | **yes** | `NullSectorTask08.genC_sq` |
| Does orthogonality force `AC = −CA`? | prove/refute | **yes** | `NullSectorTask08.genC_genA` |
| Does orthogonality force `BC = −CB`? | prove/refute | **yes** | `NullSectorTask08.genC_genB` |
| Is `AC` already in the Task-07 closure? | prove/refute | **no** | `NullSectorTask08.genQ_not_mem_Gsub` |
| Is `BC` already in the Task-07 closure? | prove/refute | **no** | `NullSectorTask08.genR_not_mem_Gsub` |
| Is `(AB)C` independent of the previously derived channels? | prove/refute | **yes** | `NullSectorTask08.genFamily8_linearIndependent`, `NullSectorTask08.genS_not_mem_Gsub` |
| Squares of all new mixed channels? | derive | `Q² = R² = S₃² = −1` | `genQ_sq`, `genR_sq`, `genS_sq` |
| Does the candidate generated span close? | prove/refute | **yes** | `NullSectorTask08.G3_is_closed_subspace` |
| Exact dimension? | derive | `8` | `NullSectorTask08.finrank_G3` |
| Is it minimal? | prove/refute | **yes** | `NullSectorTask08.G3_least` |
| Direct finite-dimensional associative witness? | prove/refute | **yes** | `NullSectorTask08.wit8_summary` (`wit8Mul_assoc`) |
| Complete old `Vec4` embedded injectively? | prove/refute | **yes** | `NullSectorTask08.iota3_injective` |
| Old square law preserved for every old vector? | prove/refute | **yes** | `NullSectorTask08.iota3_oldSq` |
| Full old symmetric product recovered? | prove/refute | **yes** | `NullSectorTask08.iota3_symmetric_product` |
| Task-07 ambient-existence obligation resolved? | classify | **RESOLVED POSITIVELY** | `NullSectorTask08.ambient_existence` |
| Commutation relations of `S₃`? | derive | commutes with `A,B,C,P,Q,R`; central in `G₃` | `genS_diagnostic`, `genS_central` |
| Minimal closure unique up to generator-preserving isomorphism? | prove/refute | **yes** (linear equivalence, unital, multiplicative, generator-preserving) | `NullSectorTask08.closureEquiv3_mul` et al., `task08_uniqueness` |

---

## 30. Build report, axiom report, unresolved obligations

### Build report

```
$ lake build
Build completed successfully (8098 jobs).
```

No errors, no warnings.  A scan of `RequestProject/` finds no occurrence of
`sorry`, `admit`, an `axiom` declaration, or `@[implemented_by]`.

Modules built for Task 08: the sixteen files listed in §2.

### Axiom report

`Task08.lean` runs `#print axioms` on all twenty-four principal theorems:

```
task08_old_carrier_data                  [propext, Classical.choice, Quot.sound]
task08_third_generator_square            [propext, Classical.choice, Quot.sound]
task08_pairwise_anticommutation          [propext, Classical.choice, Quot.sound]
task08_parenthesizations                 [propext, Classical.choice, Quot.sound]
task08_forced_relations                  [propext, Classical.choice, Quot.sound]
task08_old_carrier_membership            [propext, Classical.choice, Quot.sound]
task08_two_generator_closure_membership  [propext, Classical.choice, Quot.sound]
task08_linear_independence               [propext, Classical.choice, Quot.sound]
task08_normal_form                       [propext, Classical.choice, Quot.sound]
task08_closure                           [propext, Classical.choice, Quot.sound]
task08_dimension                         [propext, Classical.choice, Quot.sound]
task08_minimality                        [propext, Classical.choice, Quot.sound]
task08_word_reduction                    [propext, Classical.choice, Quot.sound]
task08_multiplication_table              [propext, Classical.choice, Quot.sound]
task08_structural_diagnostic             [propext, Classical.choice, Quot.sound]
task08_witness                           [propext, Classical.choice, Quot.sound]
task08_full_vec4_embedding               [propext, Classical.choice, Quot.sound]
task08_ambient_existence                 [propext, Classical.choice, Quot.sound]
task08_ambient_existence_explicit        [propext, Classical.choice, Quot.sound]
task08_uniqueness                        [propext, Classical.choice, Quot.sound]
task08_product_uniqueness                [propext, Classical.choice, Quot.sound]
task08_sign_permutation_audit            [propext, Classical.choice, Quot.sound]
task08_task07_comparison                 [propext, Classical.choice, Quot.sound]
task08_identification                    [propext, Classical.choice, Quot.sound]
```

Only the three standard Lean/Mathlib axioms occur; no custom axiom is introduced
anywhere in the project.

### Unresolved mathematical obligations

1. `G₃` is treated as a submodule with an externally given bilinear product; it is
   not equipped with a `Ring`/`Algebra` instance, so uniqueness (§23) is stated as
   a multiplicative linear equivalence rather than as an `AlgEquiv`.  Packaging
   only; no mathematical content is missing.
2. The uniqueness statement compares *minimal closures* of two ambient extensions.
   Classification of the ambient `E` itself (beyond the minimal closure) is not
   attempted and is out of scope.
3. Global `Q4`-multiplicativity remains obstructed (Task 06).  Task 08 deliberately
   does not repair it and introduces no norm, conjugation, or involution (§37).
4. No fourth spatial direction, no arbitrary-dimensional analogue, no
   representation, module, or spinor theory is developed — per the hard stop.

### HARD STOP

`G₃` closes.  The development stops here: no fourth generator, no dimensional
generalization, no norm extension, no involution, no dynamics, no Task 09.
