# TASK 23 AUDIT

## Local decomposition and reconstruction of the certified double cover

Local sections, overlap signs, transition data, and recovery of the global internal carrier.

This document audits the formal development in `RequestProject/NullSectorTask23/`.
It is written after both the focused build and the whole-project build were green.

---

## 0. Environment

| item | value |
| --- | --- |
| Lean toolchain | `leanprover/lean4:v4.28.0` (from `lean-toolchain`) |
| Mathlib requirement | `git https://github.com/leanprover-community/mathlib4.git`, `rev = "v4.28.0"` |
| Mathlib resolved revision | `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (from `lake-manifest.json`) |
| lakefile | `lakefile.toml`, `defaultTargets = ["RequestProject"]`, `globs = ["RequestProject.+"]` |
| focused target | `lake build RequestProject.NullSectorTask23.Task23` |
| whole-project target | `lake build` |

Because the library glob is `RequestProject.+`, every Task-23 module is part of the default
target; the whole-project build genuinely rebuilds this task.

---

## 1. Source chain and module inventory

Strict linear dependency order (each module imports exactly its predecessor):

```
RequestProject.NullSectorTask21.Task22            (fixed certified input, unchanged)
        ↓
NullSectorTask23.SafeBase        Package A
        ↓
NullSectorTask23.Cover           Package B
        ↓
NullSectorTask23.Sections        Package C
        ↓
NullSectorTask23.Transitions     Packages D, E
        ↓
NullSectorTask23.LocalProduct    Package F
        ↓
NullSectorTask23.Reconstruction  Package G   ← principal endpoint
        ↓
NullSectorTask23.GlobalSection   Package L
        ↓
NullSectorTask23.OldDomains      Package H
        ↓
NullSectorTask23.OldBridges      Packages I, J
        ↓
NullSectorTask23.Hierarchy       Package K
        ↓
NullSectorTask23.Comparison      Package M   ← the only identification module
        ↓
NullSectorTask23.Task23          endpoints + axiom audit
```

| module | lines | top-level declarations | role |
| --- | ---: | ---: | --- |
| `SafeBase.lean` | 352 | 51 | freeze the certified projection, the sign carrier, the sign action |
| `Cover.lean` | 168 | 18 | intrinsic coordinates, the four local domains, openness, covering |
| `Sections.lean` | 206 | 23 | explicit continuous local representatives and their normalizations |
| `Transitions.lean` | 261 | 26 | overlap factors, regularity, identity/inverse/triple laws, disconnected overlap |
| `LocalProduct.lean` | 130 | 13 | the local product homeomorphism |
| `Reconstruction.lean` | 228 | 32 | gluing quotient and its comparison with the certified carrier |
| `GlobalSection.lean` | 196 | 21 | the global-section obstruction read off the local data |
| `OldDomains.lean` | 171 | 15 | comparison with the earlier `Dom(v)` direction domains |
| `OldBridges.lean` | 251 | 25 | comparison with the earlier Bridge and integer-label data |
| `Hierarchy.lean` | 210 | 18 | the reconstruction hierarchy and negative controls |
| `Comparison.lean` | 226 | 10 | comparison-only identification |
| `Task23.lean` | 193 | 0 (55 aliases) | principal endpoints and `#print axioms` |
| **total** | **2592** | | |

`Task23.lean` introduces no new mathematics: every `task23_*` name is an `alias` of a theorem
proved in a source module, so no endpoint statement can drift from the statement that was
actually proved.

The Task-21/22 source was **not modified**. The only interface point is the single import
`RequestProject.NullSectorTask21.Task22` at the head of `SafeBase.lean`.

---

## 2. Exact definitions

All definitions live in namespace `NullSectorTask23`.

### 2.1 Package A — the frozen projection

```lean
def SgnSet : Set ℝ := {r : ℝ | r = 1 ∨ r = -1}
abbrev Sgn : Type := ↥SgnSet

abbrev LiftT : Type := (Lift : Set W)                  -- the certified internal carrier
abbrev GvisT : Type := (visImageFun : Set (W → W))     -- the certified visible carrier

noncomputable def pr (u : LiftT) : GvisT := ⟨⇑(proj (u : W)), proj_mem_visImageFun u.2⟩

def sact (e : Sgn) (u : LiftT) : LiftT := ⟨(e : ℝ) • (u : W), smul_mem_Lift e.2 u.2⟩

noncomputable def sgnOf {r : ℝ} (hr : r ≠ 0) : Sgn := ⟨r / |r|, …⟩

noncomputable def KerSign : Subgroup LiftG := projCore.ker
```

`Sgn` carries the inherited multiplication and is proved to be a `CommGroup`, `Finite`, and to
have `DiscreteTopology`. `sact` is the multiplicative action of the sign carrier on the
internal carrier, and `pr` is the Task-21 projection transported to the subtype level, so that
both source and target carry their inherited subspace topologies.

No covering-space vocabulary appears anywhere in this package.

### 2.2 Package B — the local domains

```lean
def qco (i : Fin 4) (u : W) : ℝ := ![u 0, -(u 6), u 5, -(u 4)] i
def Uset (i : Fin 4) : Set LiftT := {u : LiftT | qco i (u : W) ≠ 0}
def Vset (i : Fin 4) : Set GvisT := pr '' (Uset i)
noncomputable def basisElt (i : Fin 4) : W
```

`qco i` reads off the four intrinsic coordinates of an internal element in the ambient carrier
`W` used by the earlier tasks; these are exactly the coordinates in which the axis/angle
reconstruction was written. `Uset i` excludes the degeneracy locus `qco i = 0`, and `Vset i` is
its image in the visible carrier. The family is the four-element family `Vset 0, …, Vset 3`;
no standard atlas is imported.

### 2.3 Package C — the local representatives

```lean
def Upos (i : Fin 4) : Set LiftT := {u : LiftT | 0 < qco i (u : W)}
noncomputable def prPosHomeo (i : Fin 4) : ↥(Upos i) ≃ₜ ↥(Vset i)
noncomputable def sec (i : Fin 4) (g : ↥(Vset i)) : LiftT := ((prPosHomeo i).symm g : LiftT)
noncomputable def secNeg (i : Fin 4) (g : ↥(Vset i)) : LiftT := sact Sgn.negOne (sec i g)
```

`sec i` is **not** produced by global choice. It is the inverse of the map
`prPos i : ↥(Upos i) → ↥(Vset i)`, which is proved to be a continuous open bijection, so its
inverse is continuous by construction.

### 2.4 Packages D, E — the transition data

```lean
noncomputable def tauAt (i j : Fin 4) (g : GvisT) (hi : g ∈ Vset i) (hj : g ∈ Vset j) : Sgn :=
  sgnOf (qco_sec_ne_zero hi hj)
def Ovl (i j : Fin 4) : Set GvisT := Vset i ∩ Vset j
noncomputable def tau (i j : Fin 4) (g : ↥(Ovl i j)) : Sgn := tauAt i j (g : GvisT) g.2.1 g.2.2
```

### 2.5 Package F — the local product

```lean
noncomputable def locProd    (i : Fin 4) (p : ↥(Vset i) × Sgn) : ↥(Uset i)
noncomputable def locProdInv (i : Fin 4) (u : ↥(Uset i)) : ↥(Vset i) × Sgn
noncomputable def locProdEquiv (i : Fin 4) : (↥(Vset i) × Sgn) ≃ ↥(Uset i)
noncomputable def locProdHomeo (i : Fin 4) : (↥(Vset i) × Sgn) ≃ₜ ↥(Uset i)
noncomputable def preimageProdHomeo (i : Fin 4) : ↥(pr ⁻¹' (Vset i)) ≃ₜ (↥(Vset i) × Sgn)
```

### 2.6 Package G — the reconstructed carrier

```lean
abbrev Pieces : Type := Σ i : Fin 4, ↥(Vset i) × Sgn
def baseOf (x : Pieces) : GvisT := (x.2.1 : GvisT)
noncomputable def glue (x : Pieces) : LiftT := sact x.2.2 (sec x.1 x.2.1)

def RelPieces (x y : Pieces) : Prop :=
  ∃ (g : GvisT) (hx : g ∈ Vset x.1) (hy : g ∈ Vset y.1),
    baseOf x = g ∧ baseOf y = g ∧ y.2.2 = tauAt x.1 y.1 g hx hy * x.2.2

def recSetoid : Setoid Pieces where
  r := RelPieces
  iseqv := ⟨RelPieces.refl, RelPieces.symm, RelPieces.trans⟩

def LiftLocal : Type := Quotient recSetoid
noncomputable def toLift : LiftLocal → LiftT := Quotient.lift glue …
def prLocal : LiftLocal → GvisT := Quotient.lift baseOf …
```

### 2.7 Package L — the trivialization predicate

```lean
def IsGlobalRep (σ : GvisT → LiftT) : Prop := ∀ g : GvisT, pr (σ g) = g
abbrev SignFamily : Type := ∀ i : Fin 4, ↥(Vset i) → Sgn
noncomputable def secMod (c : SignFamily) (i : Fin 4) (g : ↥(Vset i)) : LiftT := sact (c i g) (sec i g)
def Trivializes (c : SignFamily) : Prop :=
  ∀ (i j : Fin 4) (g : GvisT) (hi : g ∈ Vset i) (hj : g ∈ Vset j), secMod c i ⟨g, hi⟩ = secMod c j ⟨g, hj⟩
```

### 2.8 Packages H, J — comparison objects

```lean
noncomputable def visOf {n : Vec3} (hn : IsUnitAxis n) (θ : ℝ) : GvisT   -- old axis/angle datum, seen in Gvis
def parityMap (k : ℤ) : Sgn := Sgn.negOne ^ k
def sgnHom : Sgn →* ℝ
```

### 2.9 Package K — negative-control carriers

```lean
abbrev TrivTotal : Type := GvisT × Sgn      -- the "already trivial" comparison object
def BadTotal : Type := ℝ × Bool             -- ℝ × Bool with the topology induced from ℝ × Bool via ℝ
def badProj (z : BadTotal) : ℝ
```

`BadTotal` carries a topology in which the two sheets cannot be separated; it witnesses that a
two-element fibre alone gives no local product decomposition.

---

## 3. Theorem inventory

Principal endpoints, as exposed in `Task23.lean` (left column) with the underlying source
theorem (right column).

### Package A — frozen projection

| endpoint | source |
| --- | --- |
| `task23_projection_continuous` | `continuous_pr` |
| `task23_projection_surjective` | `pr_surjective` |
| `task23_fibre` | `pr_eq_iff` : `pr u = pr v ↔ ∃ e : Sgn, v = sact e u` |
| `task23_fibre_sign_unique` | `sact_injective_sign` |
| `task23_kernel_sign_subgroup` | `KerSign_eq` |

Supporting facts also proved here: `sact_free`, `pr_sact`, `isQuotientMap_pr`,
`isClosedMap_pr`, `CompactSpace LiftT`, `invW_eq_conjW`, `continuous_mulW`.

### Package B — cover

| endpoint | source |
| --- | --- |
| `task23_cover_open` | `isOpen_Vset` |
| `task23_cover_covers` | `Vset_covers` : `⋃ i, Vset i = univ` |
| `task23_cover_minimal` | `Vset_minimal` |

`Vset_minimal` shows each `Vset i` contains a point (`pr (basisElt i)`) lying in no other
member of the family, so no proper subfamily of the four domains still covers: the atlas is the
smallest one naturally supported by the coordinates.

### Package C — local sections

| endpoint | source |
| --- | --- |
| `task23_local_section` | `pr_sec` : `pr (sec i g) = g` |
| `task23_local_section_continuous` | `continuous_sec` |
| `task23_local_section_unique` | `sec_unique` |
| `task23_local_section_normalizations` | `secNeg_spec` |
| `task23_local_section_sign_unique` | `section_sign_unique` |

Normalization (item 29/30): on each domain there are exactly two continuous representatives,
`sec i` and `secNeg i = sact (-1) (sec i)`; `sec_pos` fixes the normalization
`0 < qco i (sec i g)`, and `secNeg_spec` records the exact relation between the two choices,
so no normalization is selected silently.

### Packages D, E — transitions

| endpoint | source |
| --- | --- |
| `task23_transition` | `sec_eq_tau_smul` : `sec j g = sact (tauAt i j g) (sec i g)` |
| `task23_transition_unique` | `tauAt_unique` |
| `task23_transition_continuous` | `continuous_tau` |
| `task23_transition_locally_constant` | `isLocallyConstant_tau` |
| `task23_transition_const_on_preconnected` | `tau_const_of_isPreconnected` |
| `task23_overlap_not_preconnected` | `ovl_not_preconnected` |
| `task23_transition_id` | `tauAt_self` : `tauAt i i g = 1` |
| `task23_transition_inv` | `tauAt_symm` : `tauAt j i g = (tauAt i j g)⁻¹` |
| `task23_transition_inv_order_two` | `tauAt_symm'` : `tauAt j i g = tauAt i j g` |
| `task23_transition_triple` | `tauAt_trans` : `tauAt a c g = tauAt b c g * tauAt a b g` |

The order-two simplification `tauAt_symm'` is proved **after** the general inverse identity
`tauAt_symm`, as required.

### Package F — local product

| endpoint | source |
| --- | --- |
| `task23_local_product` | `preimageProdHomeo : ↥(pr ⁻¹' Vset i) ≃ₜ ↥(Vset i) × Sgn` |
| `task23_local_product_over_base` | `preimageProdHomeo_fst` |

The equivalence is proved bijective (`locProdEquiv`), then continuous in both directions
(`continuous_locProd`, `continuous_locProdInv`), and only then packaged as a homeomorphism.

### Package G — reconstruction (principal endpoint)

| endpoint | source |
| --- | --- |
| `task23_reconstruction` | `liftLocalHomeo : LiftLocal ≃ₜ LiftT` |
| `task23_reconstruction_proj` | `pr_toLift : pr (toLift z) = prLocal z` |
| `task23_reconstruction_injective` | `toLift_injective` |
| `task23_reconstruction_surjective` | `toLift_surjective` |

Well-definedness of the relation, its reflexivity (from `tauAt_self`), symmetry (from
`tauAt_symm`) and transitivity (from `tauAt_trans`) are `RelPieces.refl/symm/trans`;
`relPieces_iff_glue_eq` is the exact characterization of the relation.

### Package H — old direction domains

| endpoint | source |
| --- | --- |
| `task23_old_domain_map` | `visOf_mem_Vset_one_iff_Dom` |
| `task23_old_domain_induces_section` | `sec_one_eq_Un` |
| `task23_old_domain_fails` | `Vset_zero_not_from_Dom` |
| `task23_local_section_is_signed_reference` | `sec_eq_sign_Un` |

### Packages I, J — old bridges and integer labels

| endpoint | source |
| --- | --- |
| `task23_core_bridge_sign` | `core_relative_factor` |
| `task23_extended_bridge_not_sign` | `extended_relative_factor_not_sign` |
| `task23_old_family_not_core` | `locFam_notMem_Lift` |
| `task23_extended_kernel_continuum` | `extended_kernel_continuum` |
| `task23_parity` | `parityMap_eq_one_iff` |
| `task23_parity_surjective` | `parityMap_surjective` |
| `task23_parity_shift` | `Un_shift`, `sact_parity_Un` |
| `task23_full_turn_integer_trivial` | `full_turn_integer_label_trivial` |
| `task23_label_invisible` | `label_invisible_to_core` |
| `task23_labels_same_sign` | `distinct_labels_same_sign` |

### Package K — hierarchy

| endpoint | source |
| --- | --- |
| `task23_level1` | `level1_insufficient` |
| `task23_level2` | `level2_insufficient` |
| `task23_level3` | `level3_sufficient` |
| `task23_extended_needs_more` | `core_two_extended_infinite` |

### Package L — global section obstruction, read locally

| endpoint | source |
| --- | --- |
| `task23_no_global_section` | `no_continuous_global_rep` |
| `task23_global_iff_trivializable` | `globalRep_iff_trivializable` |
| `task23_no_trivialization` | `no_continuous_trivialization` |
| `task23_unavoidable_sign` | `exists_nontrivial_overlap_sign` |

### Package M — comparison only

| endpoint | source |
| --- | --- |
| `task23_ingredient_list` | `task23_ingredients` (eight-point checklist) |
| `task23_covering_map` | `isCoveringMap_pr` |
| `task23_controls` | `task23_negative_controls` |

---

## 4. Dependency graph

```
certified Task-XXI/XXII projection  (fixed input, not reproved)
        │
        ▼
Package A   pr, Sgn, sact,  pr_eq_iff,  sact_injective_sign,  KerSign
        │
        ▼
Package B   qco → Uset → Vset,  isOpen_Vset,  Vset_covers,  Vset_minimal
        │
        ▼
Package C   Upos → prPosHomeo → sec,  pr_sec,  continuous_sec,  sec_unique
        │
        ├─────────────────────────────┐
        ▼                             ▼
Package D/E  tauAt, tau            Package F  locProdHomeo, preimageProdHomeo
  sec_eq_tau_smul                     (uses sec and sgnOf only)
  continuous_tau
  isLocallyConstant_tau
  tauAt_self / _symm / _trans
        │                             │
        └──────────────┬──────────────┘
                       ▼
Package G   Pieces → RelPieces → LiftLocal → toLift → liftLocalHomeo,  pr_toLift
                       │
        ┌──────────────┼───────────────────────────┐
        ▼              ▼                           ▼
Package L        Package H / I / J            Package K
 globalRep_iff_    visOf_mem_Vset_one_iff_Dom   level1 / level2 / level3
 trivializable     Vset_zero_not_from_Dom       extended_fibre_infinite
 no_continuous_    core_relative_factor         no_local_product_of_two_element_fibre
 trivialization    extended_relative_factor_
 exists_nontrivial_  not_sign
 overlap_sign      parityMap, parity laws
        │              │                           │
        └──────────────┴─────────────┬─────────────┘
                                     ▼
Package M   task23_ingredients → isCoveringMap_pr  (comparison only)
```

Additional assumptions required by arrows, stated explicitly:

* **A → B** uses that `pr` is a quotient map (`isQuotientMap_pr`), which follows from
  continuity, surjectivity and closedness of `pr`; closedness uses compactness of the internal
  carrier, obtained from the certified homeomorphism with the unit-quaternion model. This is
  the only place where a Task-21 topological identification is *used* (it is not reproved).
* **C** requires the coordinates to be jointly continuous on the internal carrier; this is
  `continuous_qco`, proved coordinatewise.
* **D/E → G** uses no further hypothesis beyond the three τ laws.
* **G → L** uses the certified no-global-continuous-section theorem as an input; the
  equivalence itself is proved from the local data only.
* **H/I/J** additionally require the earlier axis/angle parameterization (`Un`, `Dom`,
  `labelBridge`) from Tasks 16–19; these are imported, not reproved.

No arrow assumes a principal bundle, a spin structure, a characteristic class, or any
cohomological object.

---

## 5. Local-structure tables

### 5.1 Cover table

| domain | defining condition on the internal representative | open | nonempty witness |
| --- | --- | --- | --- |
| `Vset 0` | `qco 0 u ≠ 0` | `isOpen_Vset 0` | `pr (basisElt 0)` |
| `Vset 1` | `qco 1 u ≠ 0` | `isOpen_Vset 1` | `pr (basisElt 1)` |
| `Vset 2` | `qco 2 u ≠ 0` | `isOpen_Vset 2` | `pr (basisElt 2)` |
| `Vset 3` | `qco 3 u ≠ 0` | `isOpen_Vset 3` | `pr (basisElt 3)` |

Covering: `Vset_covers`. Minimality: `Vset_minimal` — `pr (basisElt i) ∈ Vset i` and
`pr (basisElt i) ∉ Vset j` for `j ≠ i`, so all four domains are needed.

The condition `qco i u ≠ 0` is well posed on the visible carrier because it is invariant under
`u ↦ -u` (`preimage_Vset`).

### 5.2 Section table

| domain | representative | normalization | continuity | second normalization |
| --- | --- | --- | --- | --- |
| `Vset i` | `sec i` | `0 < qco i (sec i g)` (`sec_pos`) | `continuous_sec i` | `secNeg i = sact (-1) (sec i)` (`secNeg_spec`) |

`section_sign_unique`: any map `t : Vset i → LiftT` with `pr ∘ t = id` equals
`sact (e g) (sec i g)` for a unique pointwise sign, so `sec i` and `secNeg i` exhaust the
continuous choices on a connected piece.

### 5.3 Transition table

| item | statement | verdict |
| --- | --- | --- |
| existence | `sec_eq_tau_smul` | PROVED |
| uniqueness | `tauAt_unique` | PROVED |
| values in `{+1,-1}` | by construction (`tauAt … : Sgn`) | PROVED |
| continuity | `continuous_tau` | PROVED |
| local constancy | `isLocallyConstant_tau` | PROVED |
| constancy on preconnected subsets | `tau_const_of_isPreconnected` | PROVED |
| overlaps connected? | `ovl_not_preconnected` | **REFUTED** |
| `τ_aa = +1` | `tauAt_self` | PROVED |
| `τ_ba = τ_ab⁻¹` | `tauAt_symm` | PROVED |
| `τ_ba = τ_ab` (order two) | `tauAt_symm'` | PROVED (after the general law) |
| `τ_ac = τ_bc · τ_ab` | `tauAt_trans` | PROVED |

The overlap `Ovl 0 1` is **not** preconnected: `ovl_not_preconnected` exhibits two explicit
points of it, images of the two internal elements with coordinates `(√2/2, ±√2/2, 0, 0)`, on
which `tau 0 1` takes the two different values. Consequently a single sign per unordered pair
of domains is *not* available, and the development keeps the transition data pointwise
(`tauAt`) / componentwise (`tau` together with `isLocallyConstant_tau`) rather than as one
sign per pair. Only after this negative result is the constancy statement given in the
conditional form `tau_const_of_isPreconnected`.

Following item 43, and only at this point: these three equations have the form of the standard
transition-function (cocycle) identities. No cohomology class is introduced in any intrinsic
module.

### 5.4 Local product table

| item | statement | verdict |
| --- | --- | --- |
| candidate map `(g, ε) ↦ ε · s_i(g)` | `locProd` | defined |
| bijectivity | `locProdEquiv` (from `locProdInv_locProd`, `locProd_locProdInv`) | PROVED |
| explicit inverse | `locProdInv u = (pr u, sgnOf (qco i u))` | PROVED |
| continuity both directions | `continuous_locProd`, `continuous_locProdInv` | PROVED |
| `proj⁻¹(V_i) ≅ V_i × {±1}` | `preimageProdHomeo` | PROVED as a **homeomorphism** |
| compatibility with the projection | `preimageProdHomeo_fst` | PROVED |

---

## 6. Reconstruction verdict (Package G — principal endpoint)

> **Can the original global `Lift` be reconstructed exactly from the local sections and
> `{±1}` overlap data?**
>
> **PROVED.**

Precisely: the quotient `LiftLocal` of the disjoint union `Σ i, V_i × {±1}` by the relation
generated by `(g, ε)_i ∼ (g, τ_ij(g)·ε)_j` satisfies

```lean
noncomputable def liftLocalHomeo : LiftLocal ≃ₜ LiftT
theorem pr_toLift (z : LiftLocal) : pr (toLift z) = prLocal z
```

so the reconstruction recovers **both** the carrier (as a topological space, not merely as a
set) **and** the projection. The natural map is proved injective (`toLift_injective`),
surjective (`toLift_surjective`), continuous (`continuous_toLift`) and open
(`isOpenMap_toLift`) before being packaged as a homeomorphism.

---

## 7. Package H — comparison with the earlier `Dom(v)` domains

The old `Dom(v)` are domains **in direction space only**. To compare them with the new visible
local domains one must first transport a direction together with a parameter, which is the map

```lean
noncomputable def visOf {n : Vec3} (hn : IsUnitAxis n) (θ : ℝ) : GvisT
```

Results:

* `visOf_mem_Vset_zero` : `visOf hn θ ∈ Vset 0 ↔ cos (θ/2) ≠ 0` — a condition on the parameter
  alone, with **no** direction condition at all.
* `visOf_mem_Vset_one_iff_Dom` :
  `visOf hn θ ∈ Vset 1 ↔ ((n ∈ Dom e₁ ∨ -n ∈ Dom e₁) ∧ sin (θ/2) ≠ 0)`.
  So the new domain corresponds to the old direction domain only **up to direction reversal**
  and only **after** adjoining an independent parameter condition.
* `Vset_zero_not_from_Dom` : there is **no** `v` at all with
  `visOf hn θ ∈ Vset 0 ↔ n ∈ Dom v` for all `n, θ`. Proof: `Vset 0` contains the images of both
  `e₁` and `−e₁` at `θ = 0`, whereas an old domain never contains an antipodal pair.
* `sec_one_eq_Un` : an old locally exact axis/angle representative *does* induce the new local
  section on `Vset 1` where the normalization matches.
* `sec_eq_sign_Un` : every new local section value is a signed old axis/angle representative.

**Implication diagram.**

```
old Dom(v) ⊆ direction space
      │  needs an extra parameter coordinate, and only up to n ~ -n
      ▼
Vset 1  (and, symmetrically, Vset 2, Vset 3)      ← induced by an old representative
Vset 0                                            ← NOT induced by any Dom(v)
```

**Verdict: PARTIAL / REFUTED.** Old `Dom(v)` do **not** correspond exactly to the new local
domains. A subclass of the new sections (`Vset 1,2,3`, up to sign) arises from old `Dom(v)`
representatives; `Vset 0` — the parameter-degeneracy domain — does not arise from any old
direction domain. Item 64 is respected: the identification is made through the explicit map
`visOf`, never by the mere fact that both support local representatives.

---

## 8. Packages I and J — old bridges and integer labels

The two projections are kept strictly separate throughout.

### 8.1 Core projection `Lift → Gvis`

`core_relative_factor` : if `pr u = pr v` then there is a **unique** `e : Sgn` with
`v = sact e u`. So a core-exact overlap Bridge reduces exactly to `{±1}`.

**Verdict: old core Bridges reduce to transition signs — PROVED.**

### 8.2 Extended projection `LiftZ → Gvis`

`extended_relative_factor_not_sign` exhibits an explicit central element `wS` with

* `wS ∈ CUnit`,
* `proj (wS ⋆ u) = proj u` for every invertible `u`,
* `wS ≠ +1` and `wS ≠ -1`.

Moreover `wS_mul_notMem_Lift`: multiplying a core element by `wS` leaves the core carrier
altogether, and `extended_kernel_continuum` shows the extended kernel contains a continuum.
`locFam_notMem_Lift` shows the earlier continuous central family is not a family in the core
carrier at all.

**Verdict: for the extended projection — REFUTED.** The continuous `ℂ×` kernel of the extended
projection does not reduce to a sign, and it is kept out of the intrinsic core analysis
(item 74).

### 8.3 The map `ℤ → {±1}`

```lean
def parityMap (k : ℤ) : Sgn := Sgn.negOne ^ k
theorem parityMap_val         : ((parityMap k : Sgn) : ℝ) = (-1 : ℝ) ^ k
theorem parityMap_mul         : parityMap (k + l) = parityMap k * parityMap l
theorem parityMap_eq_one_iff  : parityMap k = 1 ↔ Even k
theorem parityMap_surjective  : Function.Surjective parityMap
```

`parityMap` is therefore **precisely parity reduction**, and it is realized concretely:
`Un_shift` / `sact_parity_Un` prove that shifting the angle parameter by `k` full turns acts on
the core carrier exactly by `sact (parityMap k)`.

A separate and important negative fact: for the **central label bridge** of the earlier tasks,
full-turn evaluation is **not** parity reduction —

```lean
theorem full_turn_integer_label_trivial (m : ℤ) : labelBridge (m : ℝ) (2 * π) = w1
```

i.e. every *integer* central label evaluates to `+1` after a full turn, so the induced map from
integer central labels to signs is constant. Parity appears in the parameter-shift action, not
in the full-turn evaluation of the central label.

**Verdict: integer label differences reduce to sign by parity — PARTIAL.** PROVED for the
angle-parameter shift map; REFUTED (constant `+1` instead) for the central-label full-turn map.

### 8.4 Information lost

* `distinct_labels_same_sign` : `0 ≠ 2` yet `parityMap 0 = parityMap 2`; `1 ≠ 3` yet
  `parityMap 1 = parityMap 3`. Explicit distinct integer labels with the same `τ`.
* `label_invisible_to_core` : integer label differences are invisible to the core projection.
* `sign_data_insufficient_for_extended` : explicit half-odd weights `b ≠ b'` differing by an
  even integer, agreeing after a full turn but differing at some `θ`.

So the `{±1}` transition data are **complete for reconstructing the core carrier** and
**incomplete for reconstructing the extended carrier / the full rate-and-Bridge structure**.

---

## 9. Package K — minimal reconstruction hierarchy

| level | data | reconstructs the core carrier? | Lean |
| --- | --- | --- | --- |
| 1 | visible group alone | **NO** | `level1_insufficient` |
| 2 | visible group + local sections (with all transitions trivial) | **NO** | `level2_insufficient` |
| 3 | visible group + local sections + `{±1}` overlap transitions | **YES** | `level3_sufficient` |
| 4 | visible group + old integer labels / central bridges | strictly more data than needed for the core; still insufficient for the extended carrier by a two-valued datum | `core_two_extended_infinite`, `extended_fibre_infinite` |

Level 1 and Level 2 are refuted by the same comparison object `TrivTotal = Gvis × {±1}`: it has
continuous local sections and *identically trivial* transitions
(`trivTotal_local_sections`), yet admits a global continuous section over the visible carrier,
which the certified carrier does not (`no_continuous_global_rep`). Hence no continuous
fibre-preserving map `TrivTotal → Lift` exists, and the two objects are not interchangeable:
sections without the transition data do not determine the carrier.

**Minimal sufficient level for the core carrier: Level 3.**

For the extended carrier, `extended_fibre_infinite` shows the fibre of the extended projection
over the identity is infinite, whereas the core fibre has exactly two elements
(`core_fibre_two`). Any reconstruction of `LiftZ` therefore needs data with an infinite fibre —
the continuous central phase — strictly more than `{±1}` transitions.

---

## 10. Package L — global section obstruction, read locally

```lean
theorem globalRep_iff_trivializable :
    (∃ σ : GvisT → LiftT, Continuous σ ∧ IsGlobalRep σ) ↔
      (∃ c : SignFamily, (∀ i, Continuous (c i)) ∧ Trivializes c)
```

Both directions are proved from the local data:

* `→` : from a global continuous representative, `repSign` extracts the local sign comparing it
  with `sec i`, continuous by `continuous_repSign`, and trivializing by `trivializes_repSign`.
* `←` : from a trivializing continuous sign family, `globalOfTrivialization` patches the
  modified sections together, well defined by `Trivializes` and continuous by the open cover.

`trivializes_iff_tau_eq` states the trivialization condition purely in terms of the transition
factors: `Trivializes c ↔ ∀ i j g, τ_ij(g) = c i g * c j g`.

Consequences:

* `no_continuous_trivialization` : no continuous sign family trivializes all transitions.
* `exists_nontrivial_overlap_sign` : for **every** continuous local sign modification there is a
  point of some overlap where the transition is not trivialized. So the certified global
  no-section theorem does force at least one unavoidable nontrivial overlap sign in every
  admissible continuous local decomposition of this cover.
* `exists_settheoretic_trivialization` : a *set-theoretic* trivializing family does exist.
  The obstruction is genuinely topological, not combinatorial.

**Verdict: PROVED, both directions.** Obtained directly from the local data; no standard bundle
theorem is imported for it.

---

## 11. Package M — comparison-only identification

`task23_ingredients` collects, in one statement, the eight ingredients requested in item 92:

1. continuous surjection — `continuous_pr`, `pr_surjective`;
2. discrete two-element fibre — `Sgn.discrete`, `core_fibre_two`;
3. explicit open cover — `isOpen_Vset`, `Vset_covers`;
4. continuous local sections — `continuous_sec`, `pr_sec`;
5. local product homeomorphisms — `preimageProdHomeo`, `preimageProdHomeo_fst`;
6. transition functions, continuous and locally constant — `continuous_tau`,
   `isLocallyConstant_tau`;
7. identity / inverse / triple-overlap laws — `tauAt_self`, `tauAt_symm`, `tauAt_trans`;
8. global recovery by gluing — `level3_sufficient`.

All eight hold. The conventional classification is therefore stated, in this module only:

```lean
theorem isCoveringMap_pr : IsCoveringMap pr
```

using Mathlib's own `IsCoveringMap` (`Mathlib.Topology.Covering`), with the fibre `Sgn`, a
two-element discrete space. So the reconstructed object `Lift → Gvis` is exactly a
**two-sheeted covering map** of the visible carrier. Nothing beyond this classification of the
already-reconstructed object is claimed.

**Explicitly not constructed and not claimed:** no frame bundle, no tangent bundle, no
Lorentz-frame bundle, no spin structure, no characteristic class, no `w₂`, no cohomology class,
no spacetime topology, no dynamics, no physical spin degree of freedom. No lift of any frame
bundle is constructed (item 95).

### Negative controls (`task23_negative_controls`)

| control | statement | Lean |
| --- | --- | --- |
| 98 | local sections exist but no global continuous one does | `continuous_sec` ∧ `no_continuous_global_rep` |
| 99 | a two-element fibre alone does not give local triviality | `no_local_product_of_two_element_fibre` (`BadTotal`) |
| 101 | the direction quotient `n ~ -n` is not the kernel-sign fibre | `revQuot_not_two_element` |
| 102 | integer Bridge labels are strictly finer than their parity sign | `sign_data_insufficient_for_extended` |
| 103 | core-sufficient data are not sufficient for the extended carrier | `extended_fibre_infinite` |
| 104 | no physical spin interpretation | not formalizable; nothing of the kind is stated anywhere in the development |

---

## 12. Required decision table

| Question | Verdict |
| --- | --- |
| Explicit open cover of `Gvis` found? | **PROVED** (`isOpen_Vset`, `Vset_covers`, minimal by `Vset_minimal`) |
| Continuous local sections exist on cover? | **PROVED** (`pr_sec`, `continuous_sec`) |
| Relative local factors lie exactly in `{±1}`? | **PROVED** (`sec_eq_tau_smul`, `tauAt_unique`; values in `Sgn` by construction) |
| Transition factors locally constant? | **PROVED** (`continuous_tau`, `isLocallyConstant_tau`); overlaps need **not** be connected (`ovl_not_preconnected`), so data are kept componentwise |
| Triple-overlap law? | **PROVED** (`tauAt_trans`, with `tauAt_self`, `tauAt_symm`, `tauAt_symm'`) |
| Local product decomposition? | **PROVED** as a homeomorphism (`preimageProdHomeo`) |
| Global `Lift` reconstructed from local pieces? | **PROVED** (`liftLocalHomeo`, `pr_toLift`) |
| Old `Dom(v)` correspond exactly to new local domains? | **PARTIAL / REFUTED** (`visOf_mem_Vset_one_iff_Dom`, `Vset_zero_not_from_Dom`) |
| Old core Bridges reduce to transition signs? | **PROVED** for the core projection (`core_relative_factor`); **REFUTED** for the extended one (`extended_relative_factor_not_sign`) |
| Integer label differences reduce to sign by parity? | **PARTIAL** — PROVED for the parameter-shift map (`parityMap_eq_one_iff`, `sact_parity_Un`); REFUTED for the central-label full-turn map, which is constant `+1` (`full_turn_integer_label_trivial`) |
| Sign data sufficient for reconstructing core `Lift`? | **PROVED** (`level3_sufficient`) |
| Sign data sufficient for reconstructing full `LiftZ`? | **REFUTED** (`extended_fibre_infinite`, `core_two_extended_infinite`, `sign_data_insufficient_for_extended`) |
| Global section iff transitions can be trivialized? | **PROVED**, both directions (`globalRep_iff_trivializable`) |
| Standard local two-sheeted structure exactly identified? | **PROVED** (`task23_ingredients`, `isCoveringMap_pr`) — comparison module only |
| Any frame bundle constructed? | **NO** |
| Any spin structure constructed? | **NO** |
| Any physical spin degree of freedom derived? | **NO** |

---

## 13. Regime separation and scope compliance

* Core projection `Lift → Gvis` and extended projection `LiftZ → Gvis` are analysed in
  disjoint statements and never mixed (items 73, 74). The continuous `ℂ×` kernel appears only
  in the comparison statements of §8.2 and in the negative controls.
* Conventional covering-space vocabulary appears **only** in `Comparison.lean` and in this
  document. Packages A–L are phrased in neutral terms (`local domain`, `local representative`,
  `relative factor`, `local product`, `reconstructed carrier`).
* The word "cocycle" is used only in §5.3, after the three exact equations were proved.
* The word "bundle" is not used for the constructed object; the only classification claimed is
  Mathlib's `IsCoveringMap`, after the local product homeomorphisms were proved.

---

## 14. Unresolved mathematical obligations

1. **Connectedness of the overlaps.** The chosen intrinsic four-element cover has overlaps that
   are not preconnected (`ovl_not_preconnected`), so the transition data cannot be reduced to a
   single sign per unordered pair of domains. Whether some *other* intrinsic cover of the
   visible carrier — still derived from the axis/parameter reconstruction rather than imported —
   has connected overlaps is **not** settled here.
2. **Componentwise sign inventory.** The development keeps the transition data as a locally
   constant function; it does not enumerate the connected components of each overlap or produce
   a finite table of signs. That enumeration is left open.
3. **Reconstruction of `LiftZ`.** It is proved that `{±1}` data cannot suffice
   (`extended_fibre_infinite`). An explicit minimal data set that *does* reconstruct `LiftZ`
   from local pieces is not constructed.
4. **Smooth structure.** Everything is topological. No smooth or Lie-theoretic statement is
   made about `pr`, the cover, or the sections.
5. **Uniqueness of the reconstruction.** `liftLocalHomeo` is one homeomorphism over the visible
   carrier; a uniqueness/naturality statement for it is not proved.

---

## 15. Failbuild ledger

Every failure below changed a mathematical or engineering boundary and was repaired; each is
recorded with its diagnosis and repair. The final state of the repository builds green.

| # | symptom | diagnosis | repair |
| --- | --- | --- | --- |
| 1 | `unknown identifier 'IsQuotientMap'` in `SafeBase.lean` | the predicate lives in the `Topology` scoped namespace in this Mathlib revision | added `open Topology` to the module header |
| 2 | `unknown constant 'Homeomorph.homeomorphOfContinuousOpen'` | the constructor was renamed in this revision | used `Equiv.toHomeomorphOfContinuousOpen` (verified against the installed revision) |
| 3 | `isDefEq` elaboration timeout proving continuity of the inherited product via `Continuous.comp` | the ambient product `⋆` unfolds into a large eight-coordinate expression that defeats unification | replaced by the coordinatewise lemma `continuous_mulW_comp`, proved with `continuous_pi_iff` and `fin_cases`, then `continuous_mulW` as a corollary |
| 4 | `Sigma.mk` elaboration failure inside the openness proof for `glue` | anonymous-constructor notation could not infer the sigma family | introduced the explicit helper `inc i p : Pieces := ⟨i, p⟩` with `continuous_inc` |
| 5 | `failed to compile definition … noncomputable` for `visOf` | the definition passes through real-analytic data | marked `noncomputable` |
| 6 | 15 linter warnings in the Task-23 modules (unused simp arguments, never-executed tactic branches, unused variables) | leftovers from iteration | removed the redundant simp arguments (`SafeBase.continuous_mulW_comp` now uses a bare `fin_cases i <;> fun_prop`; `Cover.qco_smul` drops the trailing `ring`; `Transitions.exPt_mem_Lift` drops `exPt`), replaced the `first | … | …` block in `GlobalSection` by the single tactic that fires, renamed two unused binders to `_`, and deleted the then-unused helper `Sgn.mul_left_self'` |

Failed approach that changed a mathematical boundary, preserved per item 115: an attempt to
classify each `τ_ij` by **one** sign per pair of domains failed, and the attempt produced the
explicit counterexample now recorded as `ovl_not_preconnected`. The boundary moved from "one
sign per overlap" to "a locally constant sign function on each overlap", and the counterexample
is preserved in the source rather than discarded (item 22 / item 38).

---

## 16. Build report

Both builds were run after the final edit.

| build | command | result | jobs | errors | Task-23 warnings |
| --- | --- | --- | ---: | ---: | ---: |
| focused | `lake build RequestProject.NullSectorTask23.Task23` | **green** | 8205 | 0 | 0 |
| whole project | `lake build` | **green** | 8276 | 0 | 0 |

Whole-project warning inventory: **114 warnings, none in `RequestProject/NullSectorTask23/`**.
All of them are pre-existing in earlier task layers, which were not modified:

| file | warnings |
| --- | ---: |
| `NullSectorTask21/SU2Model.lean` | 25 |
| `NullSectorTask14/AxisGeneratorMap.lean` | 14 |
| `NullSectorTask14/SecondAxisSectorAction.lean` | 10 |
| `NullSectorTask21/VisibleRotationCandidate.lean` | 8 |
| `NullSectorTask14/MixedInfinitesimalComposition.lean` | 7 |
| `NullSectorTask14/GenericTwoAxisComposition.lean` | 7 |
| `NullSectorTask14/SecondAxisAutomorphism.lean` | 6 |
| `NullSectorTask14/GenericAxis.lean` | 5 |
| `NullSectorTask14/CoherenceAudit.lean` | 5 |
| `NullSectorTask21/CoreQuaternionEquiv.lean` | 4 |
| `NullSectorTask14/MixedProjectors.lean` | 4 |
| `NullSectorTask11/Identification.lean` | 4 |
| `NullSectorTask21/TorsorPlacement.lean` | 3 |
| `NullSectorTask14/SafeBase.lean` | 3 |
| `NullSectorTask21/CoreProjection.lean` | 2 |
| `NullSectorTask14/SecondAxisOldStructure.lean` | 2 |
| `NullSectorTask14/SecondAxisCarrierSlices.lean` | 2 |
| `NullSectorTask14/TwoAxisSliceComparison.lean` | 1 |
| `NullSectorTask14/ImplementerClosure.lean` | 1 |
| `NullSectorTask14/Identification.lean` | 1 |

---

## 17. Axiom report and proof integrity

`Task23.lean` runs `#print axioms` on all 55 principal endpoints. The whole build emits 139
`depends on axioms` lines (the 55 endpoints plus the audits inherited from the earlier task
modules). Every single one reads exactly:

```
[propext, Classical.choice, Quot.sound]
```

There are **no** other axioms anywhere in the chain.

Proof-integrity scan of `RequestProject/NullSectorTask23/`:

| forbidden construct | occurrences |
| --- | ---: |
| `sorry` | 0 |
| `admit` | 0 |
| `axiom` declarations | 0 |
| `@[implemented_by]` | 0 |
| `native_decide` | 0 |
| `bv_decide` | 0 |
| `unsafe` / `partial` | 0 |

(The English word "admit" occurs once inside a docstring in `Hierarchy.lean` — "two-element
fibres need not admit any local product decomposition" — as prose, not as a tactic.)

The Task-21/22 source was preserved unchanged; the only files touched outside
`RequestProject/NullSectorTask23/` are this audit and `README.md`.

---

## 18. Source ledger

### IMPORTED STANDARD RESULT

Mathlib declarations relied on, in the installed revision
`8f9d9cff6bd728b17a24e163c9402775d9e6a365`:

| module | declaration | used for |
| --- | --- | --- |
| `Mathlib.Topology.Maps.Basic` | `Topology.IsQuotientMap`, `IsClosedMap`, `IsOpenMap` | `isQuotientMap_pr`, openness of `Vset i` |
| `Mathlib.Topology.Constructions` | `continuous_apply`, `continuous_pi_iff`, `continuous_subtype_val`, `Continuous.subtype_mk` | continuity throughout |
| `Mathlib.Topology.Homeomorph.Defs` | `Equiv.toHomeomorphOfContinuousOpen`, `Homeomorph.setCongr` | `prPosHomeo`, `preimageProdHomeo`, `liftLocalHomeo` |
| `Mathlib.Topology.Constructions` | `continuous_quotient_mk'`, `Quotient.mk_surjective` | the reconstruction quotient |
| `Mathlib.Topology.LocallyConstant.Basic` | `IsLocallyConstant`, `IsLocallyConstant.iff_continuous` | `isLocallyConstant_tau` |
| `Mathlib.Topology.Order.Basic` | `isOpen_lt` | openness of `Upos i` |
| `Mathlib.Topology.Separation` / `Mathlib.Topology.Compactness.Compact` | `CompactSpace`, compactness transport along a homeomorphism | `isClosedMap_pr` |
| `Mathlib.Topology.Covering` | `IsCoveringMap`, `IsCoveringMap.mk`, `Trivialization` | the comparison-only classification |
| `Mathlib.Topology.Connected.Basic` | `IsPreconnected` | `tau_const_of_isPreconnected`, `ovl_not_preconnected` |
| `Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic` | `Real.cos_add_int_mul_two_pi`, `Real.sin_add_int_mul_two_pi`, `Real.cos_zero`, `Real.sin_zero` | `full_turn_integer_label_trivial` |
| `Mathlib.Algebra.GroupPower.Basic` / `Mathlib.Algebra.Parity` | `Even.neg_one_zpow`, `Odd.neg_one_zpow`, `Int.not_even_iff_odd` | `parityMap_eq_one_iff` |
| `Mathlib.Data.Set.Finite` | `Set.Infinite`, `Set.infinite_of_injective_forall_mem` | `extended_fibre_infinite` |
| `Mathlib.Analysis.SpecialFunctions.Pow.NNRpow` etc. via `Real.sqrt` | `Real.sq_sqrt`, `Real.sqrt_nonneg` | the explicit overlap counterexample |

### IMPORTED FROM EARLIER TASKS OF THIS PROJECT (fixed input, not reproved)

| source | items used |
| --- | --- |
| `NullSectorTask08` | the ambient carrier `W`, its product `⋆`, coordinate lemmas |
| `NullSectorTask16–19` | the axis/angle parameterization `Un`, direction domains `Dom v`, `IsUnitAxis`, `Dom_no_antipodal`, the label bridge `labelBridge`, `HalfOddSet`, `reduction_loses_information`, the direction quotient `RevQuot` |
| `NullSectorTask20–22` | the core carrier `Lift`, the extended carrier `LiftZ`, the projection `proj` and its group form `projCore`, `visImageFun`, `kernel_core`, `kernel_full_continuum`, `liftQuatHomeo`, `CUnit`, `proj_central_mul`, and the no-global-continuous-section theorem |

The quaternion, `SU(2)`, `SO(3)`, `U(2)` and central-product identifications are **used as
fixed input only** and are not restated or reproved in Task 23.

### DERIVED IN TASK 23

Everything in namespace `NullSectorTask23`: the sign carrier and sign action; the four
intrinsic coordinates and the four local domains with openness, covering and minimality; the
continuous local representatives and their normalizations; the overlap factors with their
existence, uniqueness, continuity, local constancy, and the identity/inverse/triple-overlap
laws; the explicit non-preconnected overlap; the local product homeomorphisms; the gluing
quotient and its homeomorphism with the certified carrier over the visible carrier; the local
reading of the global-section obstruction; the comparison theorems with the old direction
domains, bridges and integer labels; the parity map; the four-level reconstruction hierarchy;
the negative controls; and the comparison-only covering-map classification.

---

## 19. Central success criterion

> Can the globally certified internal double-cover carrier be recovered intrinsically from
> continuous local representatives and their overlap signs, and how exactly do those overlap
> signs relate to the earlier Bridge and integer-label structures?

**Answer, formally proved:**

* **Recovery: YES.** `liftLocalHomeo : LiftLocal ≃ₜ LiftT` together with
  `pr_toLift`. The four intrinsic local domains, the four continuous local representatives, and
  the locally constant `{±1}` overlap factors are exactly sufficient to rebuild both the
  internal carrier and its projection, as topological spaces.
* **Relation to the earlier structures.** The old core Bridge reduces exactly to the unique
  overlap sign (`core_relative_factor`); the old direction domains `Dom(v)` do **not** transport
  to the new local domains without an extra parameter coordinate and only up to direction
  reversal, and one new domain has no old counterpart (`Vset_zero_not_from_Dom`); the angle
  parameter shift by `k` full turns acts by `parityMap k = (-1)^k`, so parity is exactly the
  reduction of integer label differences to overlap signs, while the *central* label bridge
  evaluates to `+1` after every full turn and so loses the label entirely; distinct integer
  labels give the same overlap sign; and the sign data, complete for the core carrier, are
  provably incomplete for the extended carrier.
