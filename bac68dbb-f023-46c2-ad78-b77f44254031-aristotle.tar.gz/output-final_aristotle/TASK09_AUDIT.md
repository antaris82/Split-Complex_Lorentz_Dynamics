# TASK 09 AUDIT

**The remaining Part-VI obstruction: multiplicative extension of the inherited Lorentz
quadratic form.**

Verdict, stated once at the top and proved in §23 below:

```
PART-VI Q4 MULTIPLICATIVITY OBSTRUCTION RESOLVED AFTER CODOMAIN ENLARGEMENT
```

The associative product carrier reconstructed in Task 08 was **not** changed. No
generator was added. Only the *codomain of the quadratic map* was enlarged, from the
real line to the internally derived central two-plane `Z = spanℝ {1, S} ⊆ W`.

---

## 1. Exact toolchain

| Item | Value |
| --- | --- |
| Lean toolchain | `leanprover/lean4:v4.28.0` (pinned in `lean-toolchain`) |
| Mathlib | commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (pinned in `lake-manifest.json`) |
| Build target | `RequestProject` library (`lakefile.toml`, glob `RequestProject.+`) |
| Task-09 root module | `RequestProject/NullSectorTask09/Task09.lean` |

No toolchain or dependency was upgraded or downgraded for Task 09.

## 2. Exact source ledger

**IMPORTED STANDARD RESULT (Mathlib).** Only general-purpose algebra and linear-algebra
infrastructure is used:

| Declaration | Module | Use |
| --- | --- | --- |
| `Submodule.span`, `Submodule.mem_span_pair`, `Submodule.subset_span`, `Submodule.sub_mem` | `Mathlib.LinearAlgebra.Span.Defs` | the central plane `Z` and membership bookkeeping |
| `LinearIndependent.pair_iff` | `Mathlib.LinearAlgebra.LinearIndependent.Defs` | independence of `1, S` |
| `finrank_span_eq_card` | `Mathlib.LinearAlgebra.Finrank` | `dimℝ Z = 2` |
| `Module.finrank` | `Mathlib.LinearAlgebra.Finrank` | statement of the dimension |
| `Set.ncard`, `Set.ncard_pair` | `Mathlib.Data.Set.Card` | the size of the solution space |
| `LinearMap.mk₂` | `Mathlib.LinearAlgebra.BilinearMap` | packaging the polarization as a bilinear map |
| `map_add`, `map_smul`, `map_neg`, `map_zero`, `map_sub` | `Mathlib.Algebra.Group.Hom.Defs` etc. | bilinearity bookkeeping for the inherited product |
| tactics `ring`, `linarith`, `nlinarith`, `norm_num`, `module`, `simp`, `funext`, `fin_cases`, `decide` | `Mathlib.Tactic` | closing coordinate identities |

**DERIVED IN TASK 09.** Everything in §§5–22 below: the quadratic interface, the scalar
no-go, the central plane and its properties, the unknown-map analysis, the forced values,
the polarization ledger, rigidity, the explicit witnesses, global multiplicativity, the
full old-`Q4` restriction, the exact classification, the image controls and the
central-sign audit.

**Standard mathematical background (informal citation, not used as a Lean input).** The
notions of a quadratic map, its polarization, and multiplicativity of a quadratic form
are classical; see e.g. T. Y. Lam, *Introduction to Quadratic Forms over Fields*, AMS
Graduate Studies in Mathematics 67, Ch. I. No classification theorem of composition
algebras or of matrix norms was used anywhere: the no-go of §7 and the classification of
§19 are proved by direct finite computation on the reconstructed basis.

## 3. Exact Task-08 imports

The whole Task-09 reconstruction core sits on a **single** inherited module:

```
RequestProject/NullSectorTask09/SafeBase.lean
    import RequestProject.NullSectorTask08.FullVec4Embedding
```

Inherited Task-08 declarations actually used:

* carrier `Wit8` (renamed `W`), bilinear product `wit8Mul` (notation `⋆`);
* two-sided unit `w1`, associativity `wit8Mul_assoc`, unit laws `wit8Mul_one_left/right`;
* the eight derived basis elements `w1, wA, wB, wC, wP, wQ, wR, wS`;
* the derived multiplication table (`wit8_wA_wB`, `wit8_wP_wC`, …, `wit8_wS_wS`);
* the injective embedding `iota3 : Vec4 →ₗ[ℝ] W` with `iota3_e₀, iota3_dirA, iota3_dirB,
  iota3_dirC`;
* the inherited square law `iota3_oldSq`;
* the inherited Lorentz form `NullSectorTask01.Q4` with `Q4_e₀, Q4_dirA, Q4_dirB, Q4_dirC`
  and the coordinate description `dir_coords`.

`RequestProject.NullSectorTask08.Identification` — the Task-08 *conventional*
identification — is imported **only** by `RequestProject/NullSectorTask09/Identification.lean`
(the late COMPARISON-ONLY layer), which in turn is imported only by `Task09.lean`. No
Task-05 module is imported anywhere in the project.

Mechanical import chain (each module has exactly one Task-09 import):

```
SafeBase ← RealScalarNoGo ← CentralPlane ← UnknownQuadraticMap ← Rigidity
        ← Existence ← ExactClassification ← CentralSignAudit ← Identification ← Task09
```

## 4. Target-structure firewall

A mechanical word scan (`rg -w`) over the eight reconstruction modules
(`SafeBase`, `RealScalarNoGo`, `CentralPlane`, `UnknownQuadraticMap`, `Rigidity`,
`Existence`, `ExactClassification`, `CentralSignAudit`) for

```
determinant  det  Matrix  Complex  ℂ  conj  star  norm  trace
adjoint  eigenvalue  Clifford  involution  reversion
```

returns exactly four hits, all of which are accounted for:

| Location | Hit | Status |
| --- | --- | --- |
| `SafeBase.lean:33–34` | the words listed inside the firewall docstring itself | documentation, not code |
| `Rigidity.lean:8` | "no coordinate polynomial, determinant, conjugation or matrix formula" | documentation, not code |
| `Existence.lean:14` | "determinant, no conjugation and no Task-08 identification is used" | documentation, not code |
| `CentralPlane.lean:113` | `simp [Matrix.range_cons, Matrix.range_empty, Set.pair_comm]` | **genuine code hit — disclosed, not weakened** |

The `CentralPlane.lean:113` occurrence is a naming artefact of Mathlib, not a use of
matrix theory. Lean's tuple notation `![w1, wS]` for a family `Fin 2 → W` is defined in
the `Matrix` namespace (`Matrix.of`/`Matrix.vecCons`), so the lemmas computing
`Set.range ![w1, wS]` are called `Matrix.range_cons` and `Matrix.range_empty`. They are
purely statements about the range of a two-element tuple. The tuple is needed only
because `finrank_span_eq_card` takes an indexed family; no Mathlib lemma
`finrank_span_pair` exists in the pinned revision. No matrix type, matrix product,
determinant or complex scalar occurs. The result proved with it, `finrank_Z = 2`, is a
statement about a real submodule of `W` only.

Nothing named in the §2 target-structure firewall of the task statement is used as an
input, an implementation shortcut, a naming convention or a target anywhere before
`Identification.lean`.

**Experiment-1 firewall.** No theorem, construction, terminology, source, repository,
formula or result of Experiment 1 is used. Task 09 depends only on Experiment-2 modules
(`NullSectorTask01`, `NullSectorTask04`, `NullSectorTask07`, `NullSectorTask08`) and on
Mathlib.

## 5. Definition of quadraticity

`RequestProject/NullSectorTask09/SafeBase.lean`.

```lean
def polar (N : W → V) (x y : W) : V := N (x + y) - N x - N y

structure IsRealQuadratic (N : W → V) : Prop where
  homog           : ∀ (r : ℝ) (x : W), N (r • x) = (r ^ 2) • N x
  polar_add_left  : ∀ x y z : W, polar N (x + y) z = polar N x z + polar N y z
  polar_smul_left : ∀ (r : ℝ) (x y : W), polar N (r • x) y = r • polar N x y
```

`V` is an arbitrary real module, so the *same* predicate is used for the real-valued
Phase-A control and for the central-valued Phase-B analysis. No Mathlib `QuadraticMap`
structure is used; the predicate is transparent and self-contained.

Consequences derived in the same module, not assumed:

| Fact | Name |
| --- | --- |
| `polar N x y = polar N y x` | `IsRealQuadratic.polar_comm` |
| `N 0 = 0` | `IsRealQuadratic.map_zero` |
| right additivity / right homogeneity of `polar` | `polar_add_right`, `polar_smul_right` |
| `polar N x x = 2 • N x` | `IsRealQuadratic.polar_self` |
| `N x = 2⁻¹ • polar N x x` | `IsRealQuadratic.eq_half_polar` |
| `polar N (-x) y = - polar N x y` | `polar_neg_left`, `polar_neg_right` |
| the polarization as an honest `W →ₗ[ℝ] W →ₗ[ℝ] V` | `IsRealQuadratic.polarBil` |

**QUADRATIC and MULTIPLICATIVE are logically distinct.** Multiplicativity is a separate
predicate:

```lean
def MultiplicativeR (NR : W → ℝ) : Prop := ∀ x y : W, NR (x ⋆ y) = NR x * NR y
def ExtendsQ4R      (NR : W → ℝ) : Prop := ∀ X : Vec4, NR (iota3 X) = Q4 X
```

Symmetry of the polarization is *not* an extra assumption; it is forced by the definition
of `polar` (`polar_comm`).

## 6. Real-valued negative-control theorem

`RequestProject/NullSectorTask09/RealScalarNoGo.lean`. The unknown map is packaged as

```lean
structure AdmissibleR (NR : W → ℝ) : Prop where
  quad : IsRealQuadratic NR
  mul  : MultiplicativeR NR
  ext  : ExtendsQ4R NR
```

**Inherited values (DERIVED, never assumed).** From the old-`Q4` restriction on the
embedded old carrier plus the Task-08 multiplication relations plus multiplicativity:

| Element | Value of `NR` | Source of the derivation |
| --- | --- | --- |
| `1` | `1` | `ext e₀`, `Q4 e₀ = 1`, `iota3 e₀ = w1` |
| `A` | `-1` | `ext dirA`, `Q4 dirA = -1` |
| `B` | `-1` | `ext dirB` |
| `C` | `-1` | `ext dirC` |
| `P` | `1` | `P = A ⋆ B`, multiplicativity: `(-1)(-1)` |
| `Q` | `1` | `Q = A ⋆ C`, multiplicativity |
| `R` | `1` | `R = B ⋆ C`, multiplicativity |
| `S` | `-1` | `S = P ⋆ C`, multiplicativity: `1 · (-1)` |

(`RealScalarNoGo.val_w1 … val_wS`, collected in `forced_values`.)

**SCALAR CODOMAIN OBSTRUCTION.**

```lean
theorem no_real_valued_extension : ¬ ∃ NR : W → ℝ, AdmissibleR NR
theorem no_real_valued_extension_explicit :
    ¬ ∃ NR : W → ℝ, IsRealQuadratic NR ∧ MultiplicativeR NR ∧ ExtendsQ4R NR
```

Exposed in `Task09.lean` as `task09_scalar_no_go`.

## 7. Minimal scalar obstruction

`RealScalarNoGo.scalar_obstruction_minimal`, exposed as `task09_minimal_scalar_obstruction`:

```lean
theorem scalar_obstruction_minimal (NR : W → ℝ)
    (hhom : ∀ (r : ℝ) (x : W), NR (r • x) = r ^ 2 * NR x)
    (hmul : MultiplicativeR NR)
    (hA : NR wA = -1) (hB : NR wB = -1) (hC : NR wC = -1) : False
```

The hypotheses actually used are strictly smaller than admissibility: **bilinearity of
the polarization is not used, and neither is the value on the unit, nor `Q4` on `e₀`, nor
`Q4` at any non-basis old vector.** Only degree-two homogeneity, multiplicativity, and
the three inherited values `-1` on the embedded old spatial directions are needed.

The obstruction element is the two-term combination `1 + S`. The exact incompatible
equations (`scalar_incompatible_equations`) are:

```
(i)   NR S = -1                                   [old Q4 restriction + Task-08 table]
(ii)  (1 + S) ⋆ (1 + S) = 2 • S                   [Task-08 relations: 1 unit, S ⋆ S = -1]
(iii) NR (2 • S) = 2² · NR S = -4                 [quadratic homogeneity + (i)]
(iv)  NR ((1+S) ⋆ (1+S)) = NR(1+S) · NR(1+S)      [multiplicativity]
(v)   NR(1+S) · NR(1+S) ≥ 0                       [reality of the codomain]
```

(iii) + (iv) give `NR(1+S)² = -4`, contradicting (v).

**Where the obstruction comes from.** It is a *combination*, and the audit records it
precisely:

| Ingredient | Load-bearing? |
| --- | --- |
| real scalar codomain (`z² ≥ 0`) | **yes** — this is the only ordering input, and it is exactly what the codomain enlargement removes |
| quadratic homogeneity | **yes** — used once, on `2 • S` |
| multiplicativity | **yes** — used three times: `A ⋆ B`, `P ⋆ C`, `(1+S) ⋆ (1+S)` |
| old-`Q4` restriction | **yes**, but only through the three values `NR A = NR B = NR C = -1` |
| bilinearity of the polarization | **no** |
| associativity of `⋆` | **no** (only the tabulated products are used) |

This is a genuinely *new* statement, not the Task-06 obstruction: the product carrier has
changed (Task 06 worked on the original real 3+1 carrier; here the carrier is the
eight-dimensional Task-08 closure, on which the *product* obstruction has already been
removed). The content is:

> **Even after the associative product carrier has been enlarged successfully, a
> real-valued quadratic multiplicative extension of `Q4` still fails.**

The smallest transparent configuration found by the proof involves one derived element
(`S`) and one two-term sum (`1 + S`).

## 8. Construction of the central plane

`RequestProject/NullSectorTask09/CentralPlane.lean`.

```lean
def CentralPlane : Submodule ℝ W := Submodule.span ℝ {w1, wS}
notation Z := CentralPlane
```

Only Task-08 data is used: the unit `1`, the derived element `S`, `S ⋆ S = -1`
(`wit8_wS_wS`, restated as `wS_sq`), and the centrality of `S` (`wS_central`, re-verified
directly on the witness carrier from the inherited coefficient law).

**Normal form (DERIVED).**

```lean
theorem mem_Z_iff (x : W) : x ∈ Z ↔ ∃ a b : ℝ, x = a • w1 + b • wS
theorem Z_coeff_unique : a • w1 + b • wS = a' • w1 + b' • wS → a = a' ∧ b = b'
theorem Z_eq_zero_iff  : a • w1 + b • wS = 0 ↔ a = 0 ∧ b = 0
```

so every element of `Z` is **uniquely** `a • 1 + b • S` (`task09_central_normal_form`).

**Complete internal multiplication (DERIVED from: `1` a two-sided unit, `S` central,
`S ⋆ S = -1`, bilinearity):**

```lean
theorem central_mul_rule (a b c d : ℝ) :
    (a • w1 + b • wS) ⋆ (c • w1 + d • wS)
      = (a * c - b * d) • w1 + (a * d + b * c) • wS
```

`Z` is *not* called complex numbers anywhere in the reconstruction core, and no
complex-number implementation is imported before the late comparison layer.

## 9. Closure, commutativity, centrality, dimension

| Property | Theorem | Statement |
| --- | --- | --- |
| closure | `Z_mul_mem` | `x ∈ Z → y ∈ Z → x ⋆ y ∈ Z` |
| commutativity | `Z_mul_comm` | `x ∈ Z → y ∈ Z → x ⋆ y = y ⋆ x` |
| centrality in all of `W` | `Z_central` | `z ∈ Z → ∀ x : W, z ⋆ x = x ⋆ z` |
| unit | `Z_one_mul` | `w1 ⋆ x = x` |
| exact real dimension | `finrank_Z` | `Module.finrank ℝ Z = 2` |

Collected as `centralPlane_summary`, exposed as `task09_central_plane`. The dimension
reuses only the already-established independence of `1` and `S` (`w1_wS_linearIndependent`,
itself an immediate consequence of `Z_eq_zero_iff`); it is not a new assumption.

## 10. Unknown-map setup (Phase B)

`RequestProject/NullSectorTask09/UnknownQuadraticMap.lean`. Two equivalent formulations.

Working form (an unknown `N : W → W` constrained to land in `Z`):

```lean
structure CentralQuadraticExtension (N : W → W) : Prop where
  quad : IsRealQuadratic N
  mem  : ∀ x : W, N x ∈ Z
  mul  : ∀ x y : W, N (x ⋆ y) = N x ⋆ N y
  ext  : ∀ X : Vec4, N (iota3 X) = Q4 X • w1
```

Literal form (an unknown `N : W → Z` with the induced multiplication `Zmul` and unit
`Zone` of the central plane):

```lean
structure CentralQuadraticExtensionZ (N : W → (Z : Submodule ℝ W)) : Prop where
  quad : IsRealQuadratic N
  mul  : ∀ x y : W, N (x ⋆ y) = Zmul (N x) (N y)
  ext  : ∀ X : Vec4, N (iota3 X) = Q4 X • Zone
```

They are the same condition: `cqeZ_iff`. Everything below is proved for the working form
and transfers.

**No candidate, coordinate polynomial or formula of any kind occurs in this module or in
the rigidity module that follows it.**

Two structural tools derived here for arbitrary admissible `N`:

```lean
theorem polar_mem       (x y : W) : polar N x y ∈ Z
theorem polar_covariant (g x y : W) : polar N (g ⋆ x) (g ⋆ y) = N g ⋆ polar N x y
theorem polar_pair      (u w : W) : polar N u (u ⋆ w) = N u ⋆ polar N w1 w
```

`polar_covariant` is the main rigidity engine; it follows from multiplicativity and
left-distributivity alone.

## 11. Inherited basis values

`Rigidity.val_wA … val_wS`, collected as `forced_basis_values`, exposed as
`task09_forced_basis_values`. For an **arbitrary** admissible `N`:

| Element | `N` value | Derivation |
| --- | --- | --- |
| `1` | `1` | `ext e₀` |
| `A` | `-1` | `ext dirA` (`Q4 dirA = -1`) |
| `B` | `-1` | `ext dirB` |
| `C` | `-1` | `ext dirC` |
| `P` | `1` | `P = A ⋆ B`, `mul` |
| `Q` | `1` | `Q = A ⋆ C`, `mul` |
| `R` | `1` | `R = B ⋆ C`, `mul` |
| `S` | `-1` | `S = P ⋆ C`, `mul` |

Here `-1` abbreviates `(-1 : ℝ) • w1`. **All eight values are forced into the real line
`ℝ • 1` inside `Z`; none of them retains any freedom.** In particular the eight diagonal
values do *not* determine `N`: the residual datum of §13 is invisible on the basis
diagonal and appears only in the off-diagonal polarization channel `(1, S)`.

## 12. Polarization constraints

### 12a. Old-`Vec4` channel (derived from `Q4`, not assumed)

Each of `1+A, 1+B, 1+C, A+B, A+C, B+C` is an embedded old vector (`sum_w1_wA`, …,
`sum_wB_wC`), so `ext` evaluates `N` on it directly from `Q4`:

```
Q4 (e₀ + dirA) = Q4 (e₀ + dirB) = Q4 (e₀ + dirC) = 0
Q4 (dirA + dirB) = Q4 (dirA + dirC) = Q4 (dirB + dirC) = -2
```

Hence (`old_polarization_constraints`, exposed as `task09_old_polarization_constraints`):

| Channel | Value |
| --- | --- |
| `BN(1,A)` | `0` |
| `BN(1,B)` | `0` |
| `BN(1,C)` | `0` |
| `BN(A,B)` | `0` |
| `BN(A,C)` | `0` |
| `BN(B,C)` | `0` |

### 12b. Mixed channels (`P, Q, R, S`)

Determined by multiplicativity applied to products of sums, together with the Task-08
table — not by an unconstrained coefficient system. The *essential* equations are:

* `polar_covariant` / `polar_pair`, which transports a channel `(u, u ⋆ w)` to
  `N u ⋆ polar N 1 w`;
* the diagonal values of §11, through `polar_self : polar N x x = 2 • N x`;
* the values `N(1+P) = N(1+Q) = N(1+R) = 2 • 1`, obtained by writing `1 + P`, `1 + Q`,
  `1 + R` as products of old sums (`val_sum_w1_wP`, `val_sum_w1_wQ`, `val_sum_w1_wR`).

Result — the **complete** `8 × 8` polarization ledger for an arbitrary admissible `N`,
with `d := BN(1,S)`:

| | `1` | `A` | `B` | `C` | `P` | `Q` | `R` | `S` |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `1` | `2·1` | 0 | 0 | 0 | 0 | 0 | 0 | `d` |
| `A` | 0 | `-2·1` | 0 | 0 | 0 | 0 | `-d` | 0 |
| `B` | 0 | 0 | `-2·1` | 0 | 0 | `d` | 0 | 0 |
| `C` | 0 | 0 | 0 | `-2·1` | `-d` | 0 | 0 | 0 |
| `P` | 0 | 0 | 0 | `-d` | `2·1` | 0 | 0 | 0 |
| `Q` | 0 | 0 | `d` | 0 | 0 | `2·1` | 0 | 0 |
| `R` | 0 | `-d` | 0 | 0 | 0 | 0 | `2·1` | 0 |
| `S` | `d` | 0 | 0 | 0 | 0 | 0 | 0 | `-2·1` |

(`polar_w1_w1 … polar_wS_wS` for the diagonal, `polar_w1_wA … polar_wR_wS` for the
vanishing entries, `polar_wA_wR = -d`, `polar_wB_wQ = d`, `polar_wC_wP = -d` for the four
non-vanishing off-diagonal channels, plus the symmetric transposes.)

So exactly **one** entry of the ledger is not a number: `d = BN(1,S)`.

## 13. Rigidity theorem

`Rigidity.rigidity`, exposed as `task09_rigidity`:

```lean
theorem rigidity {N₁ N₂ : W → W}
    (h1 : CentralQuadraticExtension N₁) (h2 : CentralQuadraticExtension N₂)
    (hd : polar N₁ w1 wS = polar N₂ w1 wS) : N₁ = N₂
```

**RIGIDITY RESULT: every admissible `N` is completely determined by the single residual
datum `d = BN(1,S)`.** The proof expands an arbitrary `x : W` in the derived basis
(`exists_decomp`), uses bilinearity of the polarization to reduce `N x = 2⁻¹ • polar N x x`
to the `64`-entry ledger of §12, and observes that the ledger depends on `N` only through
`d`.

The residual datum is *not* identified with any conventional operation. It satisfies a
derived algebraic constraint (`residual_sq`, `residual_normal`, exposed as
`task09_residual_datum`):

```lean
d ⋆ d = (-4 : ℝ) • w1        and hence      ∃ ζ, (ζ = 1 ∨ ζ = -1) ∧ d = (2 * ζ) • wS
```

The constraint comes from `N(1+S)= d` (`val_sum_w1_wS`) together with multiplicativity
applied to `(1+S) ⋆ (1+S) = 2 • S` — the very configuration that killed the real-valued
case in §7. In the central codomain it no longer contradicts anything; it merely forces
`d` to point along `S`, with a sign.

`rigidity_two_branches` records the resulting dichotomy at the level of the unknown map.

## 14. Exact residual freedom

`d ∈ { 2 • S, -2 • S }`: a single sign. **DISCRETE FREEDOM**, two values. No continuous
parameter survives; in particular the real-line direction of `d` is excluded by
`d ⋆ d = -4 • 1` (a real multiple `a • 1` would give `a² • 1`, and `a² = -4` is
impossible over `ℝ`).

## 15. First explicit candidate location

`RequestProject/NullSectorTask09/Existence.lean`, definition `Ncand`, **strictly after**
`Rigidity.lean` in the import chain. No explicit nontrivial quadratic map `W → Z` occurs
in `SafeBase`, `RealScalarNoGo`, `CentralPlane`, `UnknownQuadraticMap` or `Rigidity`.

The candidate is written directly in the independently derived Task-08 basis coordinates
(index `0 ↦ 1`, `1 ↦ A`, `2 ↦ B`, `3 ↦ C`, `4 ↦ P`, `5 ↦ Q`, `6 ↦ R`, `7 ↦ S`):

```lean
def nRe (x : W) : ℝ := x 0 ^2 - x 1 ^2 - x 2 ^2 - x 3 ^2 + x 4 ^2 + x 5 ^2 + x 6 ^2 - x 7 ^2
def nSc (x : W) : ℝ := 2 * (x 0 * x 7 - x 1 * x 6 + x 2 * x 5 - x 3 * x 4)
def Ncand (z : ℝ) (x : W) : W := (nRe x) • w1 + (z * nSc x) • wS
```

No matrix, complex number, determinant, conjugation or Task-08 identification is used.
The signs of `nRe` reproduce exactly the eight forced diagonal values of §11, and the four
terms of `nSc` reproduce exactly the four non-vanishing off-diagonal channels of §12 —
i.e. the candidate was *read off* the rigidity ledger, not imported.

## 16. Direct quadraticity proof

`Ncand_quadratic (z : ℝ) : IsRealQuadratic (Ncand z)`, exposed as `task09_quadraticity`.
Proved from the explicit polarizations `bRe`, `bSc` of `nRe`, `nSc` via `nRe_add`,
`nSc_add`, `nRe_smul`, `nSc_smul`, `bRe_add_left`, `bSc_add_left`, `bRe_smul_left`,
`bSc_smul_left`, all of which are single-line `ring` identities in the eight coordinates.
`Ncand_polar` gives the polarization in closed form. Note `Ncand z` is quadratic for
**every** real `z`; multiplicativity is what selects `z = ±1`.

## 17. Direct global multiplicativity proof

`Ncand_mul`, exposed as `task09_global_multiplicativity`:

```lean
theorem Ncand_mul (z : ℝ) (hz : z * z = 1) (x y : W) :
    Ncand z (x ⋆ y) = (Ncand z x) ⋆ (Ncand z y)
```

**Quantified over arbitrary `x y : W`, not over basis generators.** The proof rests on
the two coordinate identities

```lean
theorem nRe_mul (x y : W) : nRe (x ⋆ y) = nRe x * nRe y - nSc x * nSc y
theorem nSc_mul (x y : W) : nSc (x ⋆ y) = nRe x * nSc y + nSc x * nRe y
```

each proved directly from the inherited Task-08 coefficient law by `ring`, combined with
the internal multiplication rule `central_mul_rule` of §8. Basis data enters only through
the inherited product formula; the final statement is universally quantified.

## 18. Full old-`Q4` restriction theorem

`Ncand_ext`, exposed as `task09_old_Q4_restriction`:

```lean
theorem Ncand_ext (z : ℝ) (X : Vec4) : Ncand z (iota3 X) = Q4 X • w1
```

**Quantified over arbitrary `X : Vec4`, not over the old basis.** It reproduces the
generic `(t,x,y,z)` computation transparently, through

```lean
theorem nRe_iota3 (X : Vec4) : nRe (iota3 X) = Q4 X
theorem nSc_iota3 (X : Vec4) : nSc (iota3 X) = 0
```

both immediate from the coordinates of `iota3 X` and the definition of `Q4`. Note that
`Ncand z (iota3 X)` is real-line-valued for *every* embedded old vector and every `z`:
the `S`-component vanishes identically on the embedded old carrier.

## 19. Exact solution-space theorem

`ExactClassification.exact_classification`, exposed as `task09_exact_classification`:

```lean
theorem exact_classification (N : W → W) :
    CentralQuadraticExtension N ↔ (N = Ncand 1 ∨ N = Ncand (-1))
```

with (`task09_solution_space`):

```lean
{N : W → W | CentralQuadraticExtension N} = {Ncand 1, Ncand (-1)}
{N : W → W | CentralQuadraticExtension N}.ncard = 2
Ncand 1 ≠ Ncand (-1)
∀ z : ℝ, CentralQuadraticExtension (Ncand z) ↔ (z = 1 ∨ z = -1)
```

Also available in the literal `W → Z` form: `exists_central_extension_Z` /
`task09_existence_Z`, via `NcandZ` and `cqeZ_iff`.

**Verdict on the classification:** `EXISTENCE WITNESS`, `NON-UNIQUE`, exactly two
solutions, `DISCRETE FREEDOM` (a single sign; the last clause shows that within the
one-real-parameter family exactly `z = ±1` are admissible, so the freedom is not a
continuum). The order of proof is: rigidity (§13) → residual constraint (§14) →
explicit witnesses (§15–18) → this theorem.

## 20. Real-line image negative control

`real_line_image_impossible`, exposed as `task09_real_line_image_impossible`:

```lean
theorem real_line_image_impossible {N : W → W} (h : CentralQuadraticExtension N) :
    ¬ (∀ x : W, N x ∈ Submodule.span ℝ ({w1} : Set W))
```

**REAL-LINE IMAGE IMPOSSIBLE.** The witness is again `1 + S`: `N (1+S) = d = ±2 • S`,
which is a nonzero multiple of `S` and therefore not in `ℝ • 1` (`smul_wS_not_mem_line`).

Comparison with Phase A, formally proved and therefore stated: *the enlargement of the
product carrier alone was insufficient; multiplicative quadratic extension also forces
the codomain to use the additional central direction.* `CENTRAL COMPONENT REQUIRED`.

## 21. `S`-component witness

`S_component_attained`, exposed as `task09_S_component_attained`:

```lean
theorem S_component_attained {N : W → W} (h : CentralQuadraticExtension N) :
    ∃ x : W, (N x) 7 ≠ 0
```

For **every** admissible `N` — both branches — the `S` direction of the image is
genuinely attained; no branch is real-line-valued. No witness was prescribed in advance:
it is produced by the classification (`x = 1 + S` works, with `(N x) 7 = ±2`). Hence
there is no separate branch to classify.

## 22. Central-sign action

`RequestProject/NullSectorTask09/CentralSignAudit.lean`.

The real-linear map of the central plane with `1 ↦ 1`, `S ↦ -S` is defined intrinsically
in coordinates and is not given a conventional name:

```lean
def zFlip (x : W) : W := (x 0) • w1 - (x 7) • wS
```

| Property | Theorem |
| --- | --- |
| additive, real-homogeneous | `zFlip_add`, `zFlip_smul` |
| normal form `a • 1 + b • S ↦ a • 1 - b • S` | `zFlip_normal` |
| maps `Z` into `Z` | `zFlip_mem` |
| **preserves the induced multiplication of `Z`** | `zFlip_mul` |
| `zFlip ∘ Ncand 1 = Ncand (-1)` and conversely | `zFlip_exchanges` |
| admissibility is preserved | `zFlip_admissible` |

**Action on the solution space: it EXCHANGES the two solutions and fixes neither.** It
neither fails to preserve admissibility nor fixes a solution. Collected as
`central_sign_audit`, exposed as `task09_central_sign_action`.

**Relation to the Task-08 generator sign freedom** (`task09_generator_sign_tracking`).
Using only the already derived Task-08 generator permutation/sign data, the transposition
of the two derived spatial generators `A ↔ B`

```lean
def swapAB (x : W) : W := …          -- A ↔ B, C ↦ C, Q ↔ R, P ↦ -P, S ↦ -S
```

is proved to be an algebra automorphism of the **fixed** carrier (`swapAB_mul`) with
`swapAB wS = - wS`, and precomposition with it exchanges the two admissible maps
(`Ncand_comp_swapAB`, `generator_relabelling_exchanges`). So the residual Task-09 sign is
*not* new: it tracks exactly the already existing Task-08 ordered-generator ambiguity. No
geometric orientation terminology is introduced; the statement is purely about the
relabelling of the ordered spatial-generator data.

## 23. Part-VI obstruction verdict

`part_vi_verdict`, exposed as `task09_part_vi_verdict`:

```lean
theorem part_vi_verdict :
    (¬ ∃ NR : W → ℝ, AdmissibleR NR) ∧
    (∃ N : W → W, CentralQuadraticExtension N) ∧
    {N : W → W | CentralQuadraticExtension N}.ncard = 2
```

```
PART-VI Q4 MULTIPLICATIVITY OBSTRUCTION RESOLVED AFTER CODOMAIN ENLARGEMENT
```

The distinction demanded by the task statement, stated exactly:

* **Product-carrier enlargement** (Tasks 07–08) was *necessary but not sufficient*. On the
  Task-08 associative closure, with the real line kept as codomain, the obstruction
  persists (§§6–7). The carrier was not touched in Task 09: `W` is literally the Task-08
  witness, no generator was added, no product was modified.
* **Quadratic-map codomain enlargement** — from `ℝ` to the *internally derived* central
  two-plane `Z = spanℝ{1,S} ⊆ W` — is what resolves it. `Z` is not an external structure:
  it is a subspace of the fixed carrier, generated by the unit and the Task-08 central
  element, and closed under the inherited product (§§8–9).
* The precise Part-VI assumption that had to be relaxed is therefore: *the quadratic
  multiplicative extension takes values in the real scalars*. Nothing else was relaxed.

## 24. Updated Conservation-of-Difficulty graph

Generated from the actual results:

```
Task-08 associative witness  W, ⋆, 1, A,B,C,P,Q,R,S, S²=-1, S central, iota3, iota3_oldSq
        │                                    [INHERITED, SafeBase.lean]
        ▼
neutral quadratic interface  IsRealQuadratic, polar          [DERIVED, SafeBase.lean]
        │
        ▼
unknown real-valued map NR : W → ℝ                  [RealScalarNoGo.lean]
        │  old Q4 restriction + Task-08 table + multiplicativity
        ▼
forced values  NR 1 = 1, NR A = NR B = NR C = -1, NR P = NR Q = NR R = 1, NR S = -1
        │  + homogeneity on 2 • S, + reality of ℝ
        ▼
SCALAR CODOMAIN OBSTRUCTION   (witness 1 + S; NR(1+S)² = -4)
        │        ← the difficulty is NOT removed by the carrier enlargement
        ▼
central two-plane  Z = spanℝ{1,S}: closed, commutative, central, dim 2   [CentralPlane.lean]
        │
        ▼
unknown Z-valued map  N : W → Z (two equivalent formulations)  [UnknownQuadraticMap.lean]
        │  polar_covariant  (multiplicativity ⇒ covariance of the polarization)
        ▼
forced basis values (all eight, all in ℝ·1)  +  full 8×8 polarization ledger
        │  one entry unresolved:  d = BN(1,S)
        ▼
RIGIDITY: N determined by d;  d ⋆ d = -4·1  ⇒  d = ±2 • S          [Rigidity.lean]
        │        ← the difficulty has migrated into a single SIGN
        ▼
explicit witnesses Ncand z, z = ±1: quadraticity, global multiplicativity,
        full old-Q4 restriction                                     [Existence.lean]
        │
        ▼
EXACT CLASSIFICATION: exactly two admissible maps, DISCRETE FREEDOM
        │                                            [ExactClassification.lean]
        ├──► REAL-LINE IMAGE IMPOSSIBLE / CENTRAL COMPONENT REQUIRED
        │
        ▼
central-sign audit: 1↦1, S↦-S preserves the product of Z and EXCHANGES the two solutions;
        the same exchange is induced by the Task-08 generator transposition A ↔ B
        │        ← the residual sign is NOT a new difficulty: it is the
        │          already existing Task-08 ordered-generator ambiguity
        ▼                                            [CentralSignAudit.lean]
PART-VI Q4 MULTIPLICATIVITY OBSTRUCTION RESOLVED AFTER CODOMAIN ENLARGEMENT
        ┊
        ┊  (no earlier result depends on what follows)
        ▼
late conventional identification — COMPARISON ONLY            [Identification.lean]
```

Accounting: the Part-VI multiplicativity difficulty was **not** destroyed; it was
converted, first into the necessity of a two-dimensional codomain (§20: the real line is
provably insufficient even after the carrier fix), and then into a residual sign, which
is proved to coincide with a sign ambiguity already present in Task 08 (§22). Nothing
was assumed away.

## 25. Late conventional identification — COMPARISON ONLY

`RequestProject/NullSectorTask09/Identification.lean`, imported by `Task09.lean` only.
Everything in §§6–23 is proved without it, and no Task-09 reconstruction module imports
it. All statements here are **COMPARISON ONLY** and support no earlier existence or
uniqueness proof.

```lean
theorem identification_comparison :
    (∀ x : W, toMat (Ncand 1 x) = (toMat x).det • (1 : Matrix (Fin 2) (Fin 2) ℂ)) ∧
    (∀ x : W, toMat (Ncand (-1) x)
      = (starRingEnd ℂ) ((toMat x).det) • (1 : Matrix (Fin 2) (Fin 2) ℂ)) ∧
    toMat wS = !![Complex.I, 0; 0, Complex.I]
```

Under the Task-08 isomorphism, the independently reconstructed map `Ncand 1` is exactly
the determinant of the corresponding `2 × 2` complex matrix, regarded as a scalar element
of the centre; the second admissible map is its complex conjugate; and the internally
derived central element `S` corresponds to the central scalar `i`. The derived central
plane `Z` corresponds to the centre of that conventionally identified algebra.

So the answer to the question of §33 of the task statement is **yes**: the reconstructed
quadratic multiplicative map does correspond to a standard known operation, and the
correspondence is proved as an exact equality, not asserted.

## 26. Build report

```
$ lake build
Build completed successfully (8108 jobs).
```

Per-module:

```
lake build RequestProject.NullSectorTask09.Task09
```

The library target `RequestProject` (glob `RequestProject.+` in `lakefile.toml`) covers
every Task-09 module, so a plain `lake build` compiles the whole development. No errors
and no warnings from the Task-09 modules other than the `#print axioms` information
messages of §27.

A repository-wide search for `sorry`, `admit`, `axiom` declarations and
`@[implemented_by]` in `RequestProject/` returns no occurrence.

## 27. Axiom report

`Task09.lean` ends with `#print axioms` for all twenty-one principal theorems. Every one
of them reports exactly

```
[propext, Classical.choice, Quot.sound]
```

| # | Theorem | Axioms |
| --- | --- | --- |
| 1 | `task09_scalar_no_go` | `propext, Classical.choice, Quot.sound` |
| 2 | `task09_minimal_scalar_obstruction` | idem |
| 3 | `task09_central_plane` | idem |
| 4 | `task09_central_normal_form` | idem |
| 5 | `task09_forced_basis_values` | idem |
| 6 | `task09_old_polarization_constraints` | idem |
| 7 | `task09_residual_datum` | idem |
| 8 | `task09_rigidity` | idem |
| 9 | `task09_quadraticity` | idem |
| 10 | `task09_global_multiplicativity` | idem |
| 11 | `task09_old_Q4_restriction` | idem |
| 12 | `task09_existence` | idem |
| 13 | `task09_existence_Z` | idem |
| 14 | `task09_exact_classification` | idem |
| 15 | `task09_solution_space` | idem |
| 16 | `task09_real_line_image_impossible` | idem |
| 17 | `task09_S_component_attained` | idem |
| 18 | `task09_central_sign_action` | idem |
| 19 | `task09_generator_sign_tracking` | idem |
| 20 | `task09_part_vi_verdict` | idem |
| 21 | `task09_identification` (COMPARISON ONLY) | idem |

These are the three standard Lean/Mathlib axioms. No custom axiom is declared anywhere
in the project.

## 28. Unresolved mathematical obligations

Task 09 leaves the following genuinely open; none of them is used by, or weakens, any
theorem above.

1. **Uniqueness of the codomain.** It is proved that `ℝ` does not suffice and that
   `Z = spanℝ{1,S}` does. It is *not* proved that `Z` is the *smallest* possible codomain
   among all real subalgebras of `W`, nor that no codomain outside `W` could work. (The
   task fixed the two candidates to be tested, in that order, and both were settled.)
2. **Behaviour of `N` beyond multiplicativity.** Positivity, the zero set, invertibility
   and the fibres of the admissible maps are deliberately not investigated (§32 of the
   task statement).
3. **Weaker hypothesis sets.** The minimal scalar obstruction of §7 uses three inherited
   values and one two-term sum; whether a still smaller hypothesis set suffices (for
   instance, one inherited value rather than three, with a different witness element) is
   not settled.
4. **Non-quadratic multiplicative maps.** Only degree-two homogeneous maps are analysed.
   Multiplicative maps of other homogeneity degrees are outside the task.
5. **Everything dynamical** — one-parameter groups, generators, evolution — is explicitly
   out of scope and untouched (HARD STOP).

---

## Appendix A — the eleven Conservation-of-Difficulty questions (§31)

| # | Question | Answer | Where |
| --- | --- | --- | --- |
| 1 | Does a real-valued quadratic multiplicative extension of `Q4` exist on the Task-08 associative closure? | **No.** `SCALAR CODOMAIN OBSTRUCTION` | §6, `task09_scalar_no_go` |
| 2 | If not, what is the smallest transparent contradiction? | homogeneity + multiplicativity + `N A = N B = N C = -1`, tested on `1 + S`: `N(1+S)² = -4 < 0` | §7, `task09_minimal_scalar_obstruction` |
| 3 | Does the internally derived central two-plane `Z = span{1,S}` suffice? | **Yes.** `CENTRAL CODOMAIN` | §19, `task09_existence` |
| 4 | Is every admissible map determined uniquely? | **No** — `NON-UNIQUE`; but it *is* determined uniquely by the residual datum `BN(1,S)` | §13, §19 |
| 5 | If not, what exact freedom remains? | a single sign: `BN(1,S) = ±2 • S`, i.e. exactly two admissible maps `Ncand (±1)` | §14, §19 |
| 6 | Is that freedom discrete or continuous? | **`DISCRETE FREEDOM`**, two elements (`ncard = 2`) | §19, `task09_solution_space` |
| 7 | Is the extra central `S` direction genuinely used by the image? | **Yes**, for every admissible map. `CENTRAL COMPONENT REQUIRED`, `REAL-LINE IMAGE IMPOSSIBLE` | §20, §21 |
| 8 | How does `S ↦ -S` act on the solution space? | it preserves the multiplication of `Z` and **exchanges** the two solutions, fixing neither | §22 |
| 9 | Does the old `Q4` appear exactly on all embedded old vectors? | **Yes**, for arbitrary `X : Vec4`, both branches | §18, `task09_old_Q4_restriction` |
| 10 | Is multiplicativity valid for all elements of the eight-dimensional closure? | **Yes**, for arbitrary `x y : W` | §17, `task09_global_multiplicativity` |
| 11 | Which exact Part-VI assumption had to be relaxed? | only *"the codomain of the quadratic multiplicative map is the real scalars"*. The product carrier, the generators and `Q4` itself were all left untouched. | §23 |

## Appendix B — required negative controls (§38)

| Question | Required | Result | Theorem |
| --- | --- | --- | --- |
| Does a real-valued quadratic multiplicative extension exist? | prove/refute | **refuted** | `task09_scalar_no_go` |
| If not, what exact small configuration obstructs it? | derive | `1 + S`, with `NR A = NR B = NR C = -1`, homogeneity, multiplicativity | `task09_minimal_scalar_obstruction`, `scalar_incompatible_equations` |
| Is `span{1,S}` closed under multiplication? | prove | **yes** | `Z_mul_mem` |
| Is its multiplication commutative? | prove | **yes** | `Z_mul_comm` |
| Is it central in `W`? | prove | **yes** | `Z_central` |
| Is its exact real dimension 2? | prove | **yes** | `finrank_Z` |
| Does a `Z`-valued quadratic multiplicative extension exist? | prove/refute | **proved to exist** | `task09_existence`, `task09_existence_Z` |
| Does it reproduce `Q4` for every old `Vec4` element? | prove/refute | **yes**, all `X : Vec4` | `task09_old_Q4_restriction` |
| Is it multiplicative for every pair `x, y ∈ W`? | prove/refute | **yes**, all `x y : W` | `task09_global_multiplicativity` |
| What is the exact solution space? | classify | `{Ncand 1, Ncand (-1)}` | `task09_exact_classification`, `task09_solution_space` |
| Is any freedom discrete or continuous? | classify | **discrete**, two elements | `task09_solution_space` |
| Can an admissible map remain real-valued in practice? | prove/refute | **refuted** | `task09_real_line_image_impossible` |
| Is a nonzero `S`-component actually attained? | prove/refute | **yes**, for every admissible map | `task09_S_component_attained` |
| What does `S ↦ -S` do to the solution space? | derive | **exchanges** the two solutions | `task09_central_sign_action` |
| Is the Part-VI norm obstruction thereby resolved? | classify | **`OBSTRUCTION RESOLVED AFTER CODOMAIN ENLARGEMENT`** | `task09_part_vi_verdict` |

## Appendix C — status vocabulary index

| Term | Applies to |
| --- | --- |
| `INPUT` | the Task-08 carrier `W`, its product, unit and basis; `Q4`; `iota3` |
| `INHERITED` | `S² = -1`, centrality of `S`, `iota3_oldSq`, the Task-08 multiplication table |
| `DERIVED` | the quadratic interface, all forced values, the polarization ledger, `Z` and its properties |
| `SCALAR CODOMAIN OBSTRUCTION` | §§6–7 |
| `CENTRAL CODOMAIN` | `Z = spanℝ{1,S}`, §§8–9 |
| `QUADRATIC` | `IsRealQuadratic`, §5, §16 |
| `MULTIPLICATIVE` | `MultiplicativeR`, `CentralQuadraticExtension.mul`, §17 |
| `RIGIDITY RESULT` | §13 |
| `EXISTENCE WITNESS` | `Ncand 1`, `Ncand (-1)`, §§15–18 |
| `UNIQUE` | not applicable to the solution set; applies to determination *by the residual datum* (§13) |
| `NON-UNIQUE` | the solution set, §19 |
| `DISCRETE FREEDOM` | the residual sign, §§14, 19 |
| `CONTINUOUS FREEDOM` | does not occur |
| `REAL-LINE IMAGE IMPOSSIBLE` | §20 |
| `CENTRAL COMPONENT REQUIRED` | §§20–21 |
| `OBSTRUCTION RESOLVED` | §23, after codomain enlargement only |
| `OBSTRUCTION PERSISTS` | §§6–7, for the real codomain |
| `COMPARISON ONLY` | §25, `Identification.lean` |
| `UNRESOLVED` | §28 |
