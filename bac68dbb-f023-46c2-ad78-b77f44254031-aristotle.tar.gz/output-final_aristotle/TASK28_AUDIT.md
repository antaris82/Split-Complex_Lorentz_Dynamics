# TASK XXVIII AUDIT — Continuous internal representatives of ordinary transition data

Local liftability, kernel-valued ambiguity, triple-overlap defects, and the exact global
compatibility frontier.

Everything below is formalized in `RequestProject/NullSectorTask28/`.  No Task-XXVII (or
earlier) source file is modified; `git diff` against the previous endpoint shows only new
files.

---

## 0. Build environment

| Item | Value |
| --- | --- |
| Lean | `leanprover/lean4:v4.28.0` (`lean-toolchain`) |
| Mathlib | tag `v4.28.0`, commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (`lake-manifest.json`) |
| New modules | 8, 2023 lines |
| Focused build | `lake build RequestProject.NullSectorTask28.Task28` — green |
| Whole project | `lake build` — green (see §10) |
| `sorry` / `admit` / custom axiom / `implemented_by` / `native_decide` / `bv_decide` / `unsafe` / `partial` | none |

Module chain (strictly linear except for the two instantiation modules):

```
TransitionLiftBase            (Packages A, B: frozen inputs)
   ↓
LocalInternalRepresentatives  (Packages C, D, L: hard target A)
   ↓
KernelAmbiguity               (Packages E, F, G: hard target B)
   ↓
TripleOverlapDefect           (Packages H, I: hard target C, first half)
   ↓
RepresentativeChange          (Packages J, K, M: hard target C, second half)
   ↓
CertifiedProjection           (Package B instantiation + Package L refutation)
   ↓
InternalTransitionInterface   (Packages N, P + system-level statements)
   ↓
ModelBridge                   (the certified projection over the fixed model group)
   ↓
Task28                        (Package O, endpoints, axiom report)
```

---

## 1. Exact definitions

| Name | Statement |
| --- | --- |
| `InternalProjection L G` | frozen interface: `proj : L →* G` continuous and surjective, a continuous section of `proj` on an open neighbourhood of every point of `G`, kernel central, kernel discrete |
| `InternalProjection.Ker` | `proj.ker` — the kernel of the frozen projection (for the certified instance: the inherited two-element sign kernel `KerSign`) |
| `IsInternalRepOn P g V u` | `ContinuousOn u V ∧ ∀ x ∈ V, proj (u x) = g x` |
| `HasContinuousInternalRep P g V` | `∃ u, IsInternalRepOn P g V u` |
| `IsKerFunOn P V e` | `ContinuousOn e V ∧ ∀ x ∈ V, e x ∈ Ker` |
| `toKerFun` | the repackaging of such an `e` as a continuous map `V → Ker` |
| `relFactor u v` | `fun x => v x * (u x)⁻¹` (left convention, matching the inherited `g_ik = g_jk * g_ij`) |
| `tripleDefect uij ujk uik` | `fun x => (ujk x * uij x) * (uik x)⁻¹`, i.e. the unique `δ` with `u_jk * u_ij = δ * u_ik` |
| `OverlapRefinement P g` | auxiliary index, open subdomains covering the domain, one stored continuous representative per subdomain |
| `TransitionSystem B ι G` | open cover, continuous `g_ij`, identity/inverse/triple laws (the shape of the Task-XXVII endpoint) |
| `ofOrdinary` | the inherited `OrdinaryTransitionSystem` read as a `TransitionSystem` valued in `GvisModel` |
| `InternalTransitionCandidate P S` | refined overlaps + stored continuous representatives; **no** field asserting `δ = 1` |
| `IsCompatibleInternalTransitionSystem C` | all triple defects of `C` are trivial (the special case only) |
| `LevelC P S` | `∃ C, IsCompatibleInternalTransitionSystem C` — not assumed, not proved |
| `CanTrivialiseSimultaneously P S C` | the isolated frontier question of Task XXIX |
| `Certified.certifiedInternalProjection` | the inherited certified projection, packaged as an `InternalProjection` |
| `ModelBridge.modelInternalProjection` | the same projection read over the fixed visible model group |

---

## 2. Theorem inventory (principal endpoints)

Hard target A — local continuous representability:

1. `InternalProjection.exists_local_continuous_internal_rep` — every point has an open
   neighbourhood carrying a continuous internal representative (via an inherited local
   section; no pointwise choice).
2. `InternalProjection.exists_internal_rep_nhds` — the same, in neighbourhood form.
3. `InternalProjection.refinementOfContinuous` — the refinement exists (Package D).
4. `InternalProjection.exists_local_rep_of_transitionSystem`,
   `InternalProjection.overlapRefinement` — the same for every overlap of a transition system.
5. `candidateOfSystem` — the frozen candidate interface is inhabited.
6. `Certified.no_whole_domain_internal_rep` — **refutation**: a representative over a whole
   domain need not exist (inherited no-global-section theorem, specialized).

Hard target B — the kernel ambiguity:

7. `InternalProjection.relFactor_mem_ker` — the difference lies in the kernel.
8. `InternalProjection.relFactor_isKerFunOn` — it is continuous and kernel-valued.
9. `InternalProjection.continuous_toKerFun` — repackaged as a continuous `V → Ker`.
10. `InternalProjection.continuous_internal_reps_difference_unique_kerSign` — uniqueness.
11. `InternalProjection.isInternalRepOn_kerFun_mul` — converse.
12. `InternalProjection.internal_reps_free_transitive` — freeness and transitivity.
13. `InternalProjection.isLocallyConstant_toKerFun` — local constancy.
14. `InternalProjection.toKerFun_const_of_connected` — constancy on connected domains.
15. `InternalProjection.exists_nonconstant_kerFun_of_disconnected` — **negative control**:
    on a disconnected domain the ambiguity need not be one single sign.
16. `InternalProjection.isInternalRepOn_one`, `isInternalRepOn_inv`,
    `inv_rep_difference_unique` — identity and inverse normalizations (Package G).

Hard target C — the triple-overlap defect and its change law:

17. `InternalProjection.tripleDefect_mul` — defining identity, inherited order.
18. `InternalProjection.tripleDefect_mem_ker` — kernel-valued.
19. `InternalProjection.tripleDefect_isKerFunOn` — continuous.
20. `InternalProjection.tripleDefect_isLocallyConstant`, `tripleDefect_const_of_connected`.
21. `InternalProjection.triple_overlap_defect` — the packaged endpoint.
22. `InternalProjection.tripleDefect_unique`.
23. `InternalProjection.exact_internal_transition_compatibility_iff_defect_trivial` — the
    central compatibility boundary.
24. `InternalProjection.triple_defect_change_of_rep` — the change-of-representative law.
25. `InternalProjection.defect_changes_of_nontrivial_kerFun` — changing representatives can
    really change the defect while all ordinary transitions are preserved.
26. `InternalProjection.defect_eq_iff_changeFactor_trivial` — what is invariant.
27. `InternalProjection.quadruple_defect_consistency` — Package K (attempted, proved).
28. `InternalProjection.refinement_comparison_kerFun`, `refinement_comparison_defect` —
    Package M.

Package N, O, P and the bridge:

29. `InternalProjection.proj_rep_eq_transition` — every representative projects to exactly the
    ordinary transition.
30. `InternalProjection.local_action_diagram_commutes` — the local action diagram commutes.
31. `level_A_pointwise_representable`, `level_A_two_representatives`,
    `level_B_locally_continuously_representable`, `LevelC`, `levelC_imp_defect_trivial`,
    `defect_trivial_imp_exact_compatibility`, `exact_compatibility_of_trivialisation`.
32. `InternalTransitionCandidate.kerAmbiguity`, `defect`, `defect_isKerFunOn`,
    `defect_isLocallyConstant`, `exact_compatibility_iff_defect_trivial`.
33. `ModelBridge.gvisMulEquiv`, `ModelBridge.gvisHomeoModel`,
    `ModelBridge.modelInternalProjection`.
34. `task28_ordinary_transition_locally_representable`,
    `task28_ordinary_internal_candidate_exists` — the central success criterion for the
    inherited frame transitions.

---

## 3. Dependency graph

```
inherited ordinary transition system  (Task XXVII, unchanged)
        │
        ├─────────────► TransitionSystem / ofOrdinary        (Package A: repackaging only)
        │
inherited certified projection, its local sections and kernel (Tasks XX–XXIII, unchanged)
        │
        └─────────────► InternalProjection interface         (Package B)
                                │
                                ▼
                 local continuous representative             (Package C, hard target A)
                                │
                                ▼
                 overlap refinement carrying representatives  (Package D)
                                │
                                ▼
                 kernel-valued difference, unique             (Package E, hard target B)
                                │
                                ▼
                 local constancy / connected constancy        (Package F)
                                │
                                ▼
                 triple-overlap defect                        (Package H, hard target C)
                                │
                     ┌──────────┴──────────┐
                     ▼                     ▼
      exact compatibility ⟺ δ = 1     change-of-representative law
             (Package I)                   (Package J)
                     │                     │
                     ▼                     ▼
      quadruple consistency (K)     refinement comparison (M)
                     └──────────┬──────────┘
                                ▼
                 frozen candidate interface (P) and Level A/B/C audit (O)
```

Additional inputs used, stated explicitly:

* **centrality of the kernel** — needed only for the change-of-representative law and the
  quadruple identity (it is an inherited property of the two-element sign kernel, proved for
  the certified instance in `CertifiedProjection`);
* **discreteness of the kernel** — needed only for local constancy (proved for the certified
  instance from finiteness and separation);
* **compactness of the reconstructed visible group** and **separation of the model group** —
  needed only for the bridge of `ModelBridge`, i.e. to know that the inherited identification
  of the reconstructed visible group with the fixed model group is a homeomorphism.

---

## 4. Required decision table

| Question | Verdict |
| --- | --- |
| Every ordinary transition pointwise representable? | INHERITED (`level_A_pointwise_representable`) |
| Every ordinary transition locally continuously representable? | PROVED |
| Refinement of overlaps sufficient? | PROVED |
| Whole-overlap representative always exists? | REFUTED for the certified projection (`Certified.no_whole_domain_internal_rep`); NOT IMPLIED in general |
| Difference of two reps kernel-valued? | PROVED |
| Difference continuous? | PROVED |
| Difference uniquely `KerSign`-valued? | PROVED |
| Kernel ambiguity locally constant? | PROVED |
| Constant on connected domains? | PROVED |
| Triple-overlap defect defined intrinsically? | PROVED (derived from the inherited multiplication law) |
| Defect lies in `KerSign`? | PROVED |
| Defect continuous? | PROVED |
| Defect locally constant? | PROVED |
| Exact internal compatibility iff defect trivial? | PROVED |
| Change-of-representative law proved? | PROVED (`δ' = (ε_jk · ε_ij · ε_ik⁻¹) · δ`) |
| Quadruple consistency? | PROVED (`δ_ijk · δ_ikl = δ_jkl · δ_ijl`) |
| Compatible internal system globally exists? | OPEN (isolated as `CanTrivialiseSimultaneously`) |
| Lifted total space constructed? | NO |
| Named global lifted structure constructed? | NO |
| Characteristic class introduced? | NO |
| Physical spin derived? | NO |

---

## 5. Kernel-ambiguity and defect tables

Ambiguity of representatives on a domain `V`:

| Situation | Statement |
| --- | --- |
| `u`, `v` both represent `g` on `V` | `ε := v · u⁻¹` is continuous, kernel-valued, and `v = ε · u` |
| uniqueness | `ε` is the *only* continuous kernel-valued function with `v = ε · u` |
| converse | for any continuous kernel-valued `ε`, `ε · u` represents `g` |
| `V` connected | `ε` is constant |
| `V` disconnected | `ε` need not be constant (explicit counterexample) |

Triple overlaps, with the inherited convention `g_ik = g_jk · g_ij`:

| Situation | Statement |
| --- | --- |
| defect | `u_jk · u_ij = δ_ijk · u_ik`, `δ_ijk` kernel-valued, continuous, locally constant |
| exactness | `u_jk · u_ij = u_ik` on `V` **iff** `δ_ijk = 1` on `V` |
| change `u'_ab = ε_ab · u_ab` | `δ'_ijk = (ε_jk · ε_ij · ε_ik⁻¹) · δ_ijk` |
| invariance | `δ'_ijk = δ_ijk` **iff** `ε_jk · ε_ij = ε_ik` |
| quadruple overlaps | `δ_ijk · δ_ikl = δ_jkl · δ_ijl` |

---

## 6. Level A / Level B / Level C

| Level | Statement | Status |
| --- | --- | --- |
| A | for each point, `g_ij(b)` has an internal representative (two of them, differing by the kernel) | INHERITED (surjectivity), restated |
| B | after refining overlaps, continuous `u_ij` exist | **PROVED** — the target of Task XXVIII |
| C | representatives can be chosen so that all identity, inverse and triple laws hold exactly | **NOT ASSUMED, NOT PROVED** |

Proved about the frontier:

* `Level C ⇒ every δ_ijk = 1` (`levelC_imp_defect_trivial`);
* for a *fixed* already-chosen system, `all δ_ijk = 1 ⇒ exact triple compatibility`
  (`defect_trivial_imp_exact_compatibility`);
* a solution of the simultaneous-trivialization problem *would* produce exactly compatible
  internal transitions (`exact_compatibility_of_trivialisation`).

The existential question — can all representatives be modified simultaneously so that every
defect becomes trivial? — is isolated as `CanTrivialiseSimultaneously` and is **not answered**
here.  No external obstruction theory is imported.

---

## 7. Negative controls

| # | Control | Where |
| --- | --- | --- |
| 116 | pointwise surjectivity does not give a continuous representative over an arbitrary domain | `Certified.no_whole_domain_internal_rep` |
| 117 | local continuous representability does not imply whole-domain representability | same |
| 118 | two representatives of the same ordinary map need not be equal | `Certified.negOne_mem_certified_Ker` together with `isInternalRepOn_kerFun_mul` |
| 119 | their difference is exactly kernel-valued | `relFactor_mem_ker` |
| 120 | a continuous kernel-valued difference need not be one constant sign | `exists_nonconstant_kerFun_of_disconnected` |
| 121 | ordinary triple compatibility does not force internal triple compatibility | `defect_changes_of_nontrivial_kerFun`, `exact_internal_transition_compatibility_iff_defect_trivial` |
| 122 | the defect is derived, not postulated | it is literally the relative factor of two representatives of `g_ik` |
| 123 | a nontrivial defect is never normalized away | `InternalTransitionCandidate` has no `δ = 1` field |
| 124 | changing representatives may change the defect | `defect_changes_of_nontrivial_kerFun` |
| 125–128 | no total space, no named global lifted structure, no characteristic class, no spin statement | nothing of the kind is declared anywhere in the layer |

---

## 8. Unresolved mathematical obligations

1. **Simultaneous trivialization** (`CanTrivialiseSimultaneously`): whether the local
   representative choices can be modified so that all triple defects vanish.  Isolated, not
   answered.  This is the Task-XXIX question.
2. **Whole-overlap representability**: refuted for the certified projection over its whole
   base group; for a *general* overlap domain of a *general* transition system, whole-domain
   existence remains an additional condition, not classified here (item 95 forbids the
   classification).
3. **Normalization of identity/inverse representatives simultaneously and globally**: only
   the local statements are proved (`isInternalRepOn_one`, `isInternalRepOn_inv`,
   `inv_rep_difference_unique`); no global simultaneous normalization is claimed.
4. Nothing is asserted about gluing the local internal representatives into a total space.

---

## 9. Source ledger

**IMPORTED STANDARD RESULT (Mathlib, revision above).**

* `IsLocallyConstant.iff_continuous`, `IsLocallyConstant.apply_eq_of_preconnectedSpace`
  (`Mathlib/Topology/LocallyConstant/Basic.lean`);
* `Subtype.preconnectedSpace` (`Mathlib/Topology/Connected/Basic.lean`);
* `Finite.instDiscreteTopology`, `Topology.IsEmbedding.t2Space`
  (`Mathlib/Topology/Separation/Basic.lean`);
* `Continuous.homeoOfEquivCompactToT2` (`Mathlib/Topology/Homeomorph/Lemmas.lean`);
* `Matrix.toEuclideanLin`, `Matrix.toEuclideanLin_eq_toLin_orthonormal`,
  `OrthonormalBasis.sum_inner_mul_inner`, `PiLp.continuous_toLp`
  (`Mathlib/Analysis/InnerProductSpace/PiL2.lean`, `Mathlib/Analysis/Normed/Lp/PiLp.lean`);
* `LinearMap.isometryOfInner`, `LinearIsometry.toLinearIsometryEquiv`
  (`Mathlib/Analysis/InnerProductSpace/LinearMap.lean`, `.../LinearIsometry.lean`);
* `LinearMap.det_toMatrix`, `Matrix.toLin_toMatrix`, `Matrix.mem_specialOrthogonalGroup_iff`
  (`Mathlib/LinearAlgebra/Determinant.lean`, `Mathlib/LinearAlgebra/Matrix/*`).

**INHERITED FROM EARLIER LAYERS OF THIS PROJECT (unchanged, not reproved).**

* the certified projection `projCore : LiftG →* GvisG` and its kernel theorem
  (`NullSectorTask21.GroupPackaging`);
* its topological form `pr`, continuity, surjectivity, the four visible domains `Vset i`,
  the continuous local representatives `sec i`, and the no-global-section theorem
  (`NullSectorTask23.SafeBase`, `.Cover`, `.Sections`, `.GlobalSection`);
* the identification of the reconstructed visible group with the standard rotation matrix
  group (`NullSectorTask21.visibleRotationEquiv`);
* the ordinary topological frame-family layer and its transition system
  (`NullSectorTask27.*`, in particular `OrdinaryTransitionSystem`), and the topology of the
  fixed model group (`NullSectorTask27.ModelTopology`).

**DERIVED IN TASK XXVIII.**  Everything listed in §2, plus the topological plumbing of
`CertifiedProjection` (transport of the inherited topologies to the packaged group carriers,
continuity of the packaged operations and of the packaged projection, local sections in
packaged form, centrality and discreteness of the kernel) and the elementary passage from
rotation matrices to isometries of the model carrier in `ModelBridge`.

---

## 10. Build and axiom report

* Focused build: `lake build RequestProject.NullSectorTask28.Task28` — **green**, 0 errors,
  0 warnings in Task-XXVIII modules.
* Whole project: `lake build` — **green** (8317 jobs, 0 errors, 114 warnings, all of them
  pre-existing warnings of earlier layers; **0** warnings in a Task-XXVIII module).
* `#print axioms` is run in `Task28.lean` on 48 declarations, covering every principal
  endpoint.  Each depends only on `propext`, `Classical.choice`, `Quot.sound`.
* Grep audit: no `sorry`, `admit`, `axiom`, `implemented_by`, `native_decide`, `bv_decide`,
  `unsafe`, `partial` anywhere in `RequestProject/NullSectorTask28/`.

### Preserved build failures (item 143)

| # | Command | Error | Diagnosis | Repair | Mathematical content changed? |
| --- | --- | --- | --- | --- | --- |
| 1 | `lake build …TransitionLiftBase` | `Function expected at MonoidHom.mem_ker` | in this Mathlib revision `MonoidHom.mem_ker` is an `iff` without an explicit argument | dropped the placeholder argument | no |
| 2 | `lake build …TransitionLiftBase` | `field_simp made no progress` | the kernel characterization needed `mul_inv_eq_one`, not field normalization | rewrote the proof with `mul_inv_eq_one` | no |
| 3 | `lake build …LocalInternalRepresentatives` | application type mismatch in a `Classical.choose_spec` chain | the refinement is built by the `choose` tactic, so its fields are not syntactically `Classical.choose` | removed the redundant simp lemma; the field `covers` already provides the statement | no |
| 4 | `lake build …KernelAmbiguity` | `rewrite` failed: `ContinuousOn` pattern not found | `IsKerFunOn` is a conjunction; the rewrite targeted the wrong component | used `h.1` explicitly | no |
| 5 | `lake build …RepresentativeChange` | three mismatches in the cancellation steps and in the quadruple identity | over-eager `mul_right_cancel`/`▸` steps | replaced by explicit `calc` chains using centrality | no |
| 6 | `lake build …CertifiedProjection` | `Unknown identifier W` (and consequent instance failures) | the inherited carrier lives in an earlier namespace that was not opened | added the inherited `open` list | no |
| 7 | `lake build …CertifiedProjection` | `rewrite` failed on `Continuous (f ∘ inv)` | `continuous_induced_rng` leaves a composition; the rewrite needed the beta-reduced form | inserted `show` with the reduced form | no |
| 8 | `lake build …CertifiedProjection` | `dif_pos` not applicable | the `dite` occurred under a lambda not yet beta-reduced | inserted `show` with the applied form | no |
| 9 | `lake build …InternalTransitionInterface` | `Unknown identifier tripleDefect` | the defect lives in the `InternalProjection` namespace | added `open InternalProjection` in the candidate namespace | no |
| 10 | `lake build …ModelBridge` | `Unknown constant Matrix.det_toMatrix`, `LinearMap.toLin_toMatrix` | wrong names for this revision | `LinearMap.det_toMatrix`, `Matrix.toLin_toMatrix` | no |
| 11 | `lake build …ModelBridge` | type mismatch in the continuity of the identification | the matrix entries had to be reached through the inherited spatial action, not through `spatInv` unfolding | rewrote the entry-continuity proof by `fin_cases` on the row index | no |
| 12 | `lake build …Task28` etc. | `unexpected token 'omit'` | `omit … in` must precede the docstring | reordered | no |

No intended theorem turned out to be false; no counterexample had to replace a stated
theorem.
