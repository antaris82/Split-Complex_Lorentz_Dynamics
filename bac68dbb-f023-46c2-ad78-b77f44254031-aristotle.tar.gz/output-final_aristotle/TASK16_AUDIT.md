# Task 16 audit

**Joint direction–parameter regularity and transformation-valued closure: exact
coincidences, global existence, central defect regularity, and minimal local repair.**

---

## 1. Toolchain, revision, imports

| item | value |
|---|---|
| Lean | `leanprover/lean4:v4.28.0` (`lean-toolchain`) |
| Mathlib | `v4.28.0` tag, revision `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (`lake-manifest.json`) |
| build target | `lake build RequestProject.NullSectorTask16.Task16` (also part of the default target) |

External imports used by Task 16 (transitively, via the inherited chain): Mathlib only.
The Task-16 modules themselves import no Mathlib module directly; they import the earlier
tasks of this project, which import `Mathlib`.

Mathlib declarations used explicitly in Task-16 proofs (all verified against the installed
revision):

| declaration | module (Mathlib) | use |
|---|---|---|
| `generalized_tube_lemma` | `Mathlib/Topology/Compactness/Compact.lean` | uniformity over the compact parameter interval in `continuous_of_joint_circle` |
| `Real.mul_le_sin` | `Mathlib/Analysis/SpecialFunctions/Trigonometric/Bounds.lean` | the quarter-period lower bound `2x/π ≤ sin x` |
| `Real.cos_eq_one_iff` | `Mathlib/Analysis/SpecialFunctions/Complex/Circle.lean` (re-exported) | parameter shifts along a coincidence branch |
| `Real.sin_eq_zero_iff` | `Mathlib/Analysis/SpecialFunctions/Trigonometric/Basic.lean` | half-integer confinement of the central rate |
| `Real.cos_add_int_mul_two_pi`, `Real.sin_add_int_mul_two_pi`, `Real.cos_add_pi`, `Real.sin_add_pi`, `Real.cos_int_mul_two_pi`, `Real.cos_pi`, `Real.sin_pi_div_two` | `Mathlib/Analysis/SpecialFunctions/Trigonometric/Basic.lean` | periodicity computations |
| `intermediate_value_Icc`, `intermediate_value_Icc'` | `Mathlib/Topology/Order/IntermediateValue.lean` | a continuous integer-shifted function on an interval is constant |
| `Continuous.log`, `Real.continuous_exp/cos/sin`, `Continuous.subtype_mk`, `continuous_subtype_val` | `Mathlib/Analysis/SpecialFunctions/*`, `Mathlib/Topology/*` | continuity bookkeeping |

Everything else is **DERIVED IN TASK 16** or **INHERITED** from Tasks 08–15 of this
project.

---

## 2. Inherited data ledger (I. Inherited data and firewall)

Imported through `RequestProject.NullSectorTask15.Infinitesimal` (reconstruction chain
only; `RateSeparation` is imported additionally by the rate-audit layer):

* the associative carrier `W` with product `⋆` and unit `w1`;
* the exact centre `Z = spanℝ{w1, wS}` with `wS ⋆ wS = -w1`, `center_eq_Z`, `mem_Z_iff`,
  `Z_central`, `central_mul_rule`;
* the inherited old spatial carrier `Vec3`, the positive form `h3`, the embedding `spat`,
  the derived axis-generator map `Jmap` and its linearity;
* the unit spatial directions `IsUnitAxis` and `exists_unit_orthogonal`;
* the arbitrary-axis reference implementations `Un n θ`, the group law `Un_group`,
  `full_turn_val`, and the automorphism family `PhiGen n θ`;
* `Implements`, `Un_implements`, `implements_defect_mem_Z`, `implements_defect_factor`;
* the one-axis lift classes `IsAxisLift`, `IsContinuousAxisLift`, `axisLift_iff`,
  `continuousAxisLift_classification`, `continuousAxisLift_parameters_unique`,
  `Un_right_cancel`, `residual_coeffs_of_coords`, `zc_mul_Un*`;
* the central exponential–rotation family `zexp α β θ`, `zexp_isCentralHom`,
  `zexp_injective`;
* the Task-15 regular-family class `IsRegularFamily`, `famOf`, the recovered rates
  `rateAlpha`, `rateBeta`, `regularFamily_param_spec`, `regularFamily_param_unique`,
  `regular_family_arbitrary_parameters`;
* the Task-15 necessary consequences of transformation-valuedness
  (`IsTransformationValued`, `autValued_forces_alpha_zero`,
  `autValued_forces_beta_half_odd`, `autValued_antipodal_odd`), used as *necessary*
  conditions only — never as sufficient ones;
* the Task-15 central composition discrepancy `cdisc` with `central_discrepancy_mem_Z`,
  `composition_law`, `central_discrepancy_assoc`;
* the Task-15 rate-reparametrized families `rateFam` and
  `generator_components_independent`.

### Firewall report

*Reconstruction firewall.* A mechanical scan of
`RequestProject/NullSectorTask16/` for `spin`, `quaternion`, `Pauli`, `cocycle`,
`cohomolog`, `covering`, `fundamental group`, `bundle`, `connection`, `holonomy`,
`fermion`, `electron`, `photon`, `mass`, `energy`, `momentum`, `frequency`, `Hamiltonian`,
`electromagn`, `gravit`, `SU(2)`, `SO(3)`, `projective` returns hits only

* inside the firewall paragraph of `SafeBase.lean` that lists the prohibited notions,
* inside one disclaimer sentence of `JointRegularity.lean`,
* inside the late comparison module `Identification.lean`,
* and on the ordinary English words *covering / covers* (as in "the domains cover all unit
  directions").

No forbidden notion is constructed, imported, or used as an input.

*Late-comparison firewall.* `OptionCAudit.lean` and `Identification.lean` are imported by
`Task16.lean` only. No reconstruction module imports either, and no reconstruction theorem
depends on either.

*No-heuristic firewall.* The heuristic dictionary of §VII of the task appears nowhere in
Lean; it is recorded in §12 below, explicitly marked heuristic.

---

## 3. Source order (X. Source-order requirement)

```
SafeBase
  → ExactCoincidences            (Work Package 1)
  → JointRegularity              (Work Package 2)
  → TransformationValuedClosure  (Work Package 3)
  → RegularDefect                (Work Package 4)
  → LocalRepair                  (Work Package 5)
  → RateAudit                    (Work Package 6, first half; negative controls)
  → OptionCAudit                 (COMPARISON ONLY)
  → Identification               (COMPARISON ONLY, last)
  → Task16
```

Each module imports exactly its predecessor (`RateAudit` additionally imports the inherited
`Task15.RateSeparation`; `Identification` imports `RateAudit`). `Identification` is last
and is imported only by `Task16`.

---

## 4. Exact definitions introduced in Task 16

| name | statement |
|---|---|
| `SignRelated n m θ φ` | `∃ e, (e = 1 ∨ e = -1) ∧ Un n θ = e • Un m φ` |
| `Sph` | `{n : Vec3 // IsUnitAxis n}`, with the inherited subspace topology |
| `IsJointlyRegularFamily U` | `(∀ n, IsUnitAxis n → IsAxisLift n (U n))` together with `Continuous fun p : Sph × ℝ => U p.1 p.2` |
| `recA U s θ`, `recB U s θ` | the explicit coordinate expressions recovering the two central coefficients |
| `refFam n θ` | `Un n θ`, the inherited reference implementations read as a family |
| `IsSignTransformationValued U` | `PhiGen n θ = PhiGen m φ → U n θ = U m φ ∨ U n θ = -(U m φ)` |
| `Dom v` | `{n | IsUnitAxis n ∧ 0 < h3 n v}` |
| `IsTransformationValuedOn D U` | `∀ n ∈ D, ∀ m ∈ D, ∀ θ φ, PhiGen n θ = PhiGen m φ → U n θ = U m φ` |
| `locFam k n θ` | `zexp 0 ((k : ℝ) + 1/2) θ ⋆ Un n θ` |
| `circPath n m t` | `cos t • n + sin t • m`, the continuous path of unit directions |

`IsAxisLift`, `IsRegularFamily`, `IsTransformationValued`, `zexp`, `famOf`, `rateAlpha`,
`rateBeta`, `rateFam` are **INHERITED** from Task 15.

---

## 5. Theorem inventory

### Work Package 1 — exact transformation coincidences (`ExactCoincidences.lean`)

| theorem | content |
|---|---|
| `coincidence_iff` | `PhiGen n θ = PhiGen m φ ↔ SignRelated n m θ φ` — **necessary and sufficient**, no side condition beyond unitarity |
| `coincidence_iff_coords` | the same in inherited real coordinates: `cos(θ/2) = ± cos(φ/2)` together with `sin(θ/2) • n = ± sin(φ/2) • m` |
| `central_factor_normalization` | the central factor relating two reference implementations has vanishing `S`-component and square-one real part |
| `coincidence_add_two_pi` | parameter periodicity: `PhiGen n (θ + 2π) = PhiGen n θ` |
| `coincidence_neg_axis` | axis reversal: `PhiGen (-n) θ = PhiGen n (-θ)` |
| `coincidence_id_iff` | identity transformations: `PhiGen n θ = id ↔ ∃ k : ℤ, θ = 2πk` |
| `coincidence_same_axis_iff` | same-axis periodicity: `PhiGen n θ = PhiGen n φ ↔ ∃ k : ℤ, θ - φ = 2πk` |
| `coincidence_axis_determined` | generic case: `sin(θ/2) ≠ 0` forces `n = m` or `n = -m` |
| `coincidence_axis_undetermined_at_zero_angle` | the finite-angle degeneracy: at `θ = 2πk` every direction gives the same automorphism |

**Status: CLOSED.** The arbitrary spatial word problem is *not* addressed and is not
needed.

### Work Package 2 — joint direction–parameter regularity (`JointRegularity.lean`)

| theorem | content |
|---|---|
| `continuous_of_joint_circle` | analytic core: joint continuity of `(x,θ) ↦ (cos(b x·θ), sin(b x·θ))` implies continuity of `b` |
| `IsJointlyRegularFamily.toRegularFamily` | joint regularity is strictly stronger than the Task-15 axiswise notion |
| `recA_recB_eq` | the explicit coordinate expressions equal the two central coefficients |
| `jointlyRegular_alpha_continuous` | the **first** recovered rate is continuous |
| `jointlyRegular_beta_continuous` | the **second** recovered rate is continuous |
| `jointlyRegular_famOf` | converse: every continuous rate pair gives a jointly regular family |
| `jointRegularity_classification` | the exact equivalence |

**Answer to the Work-Package-2 question.** *Both* recovered rates must be continuous; it is
not merely some combination; joint continuity allows **no** more general phenomenon; and
the one-axis `α`/`β` parametrization needs **no** refinement. The classification is an
equivalence, not merely a necessity.

Remark on the analytic core: continuity of `n ↦ exp(i β(n) θ)` for each *fixed* `θ` would
**not** suffice (the rate could jump by a multiple of `2π/θ`); joint continuity is used
through compactness of a parameter interval. This is recorded because it is exactly the
point at which the Task-15 axiswise predicate is insufficient.

### Work Package 3 — global closure (`TransformationValuedClosure.lean`)

| theorem | content |
|---|---|
| `circPath_isUnitAxis`, `circPath_zero`, `circPath_pi`, `continuous_circPath` | an intrinsic continuous path of unit directions joining `n` to `-n` |
| `eq_of_continuous_int_shift` | a continuous function with values in a fixed translate of `ℤ` has equal endpoint values |
| `jointlyRegular_transformationValued_beta_zero` | joint regularity + transformation-valuedness force the second rate to vanish everywhere |
| `no_global_jointly_regular_transformationValued` | **alternative C**: no such family exists |
| `jointlyRegular_transformation_valuedness_fails` | explicit form: every jointly regular family has a coincident pair with different representatives |

**Structure of the obstruction.** The Task-15 necessary conditions give
`β n ∈ ℤ + 1/2` (from the parameter period) and `β (-n) = -β n` (from the reversal).
Work Package 2 makes `β` continuous. Along the intrinsic path from `n` to `-n` a
continuous half-odd function cannot change, so `β n = β (-n) = -β n`, forcing `β n = 0`,
which is not half-odd. The contradiction is **discrete**, and no external construction is
used.

### Work Package 4 — the central defect (`RegularDefect.lean`)

| theorem | content |
|---|---|
| `refFam_jointlyRegular` | the inherited reference family is jointly regular |
| `reference_signTransformationValued` | it satisfies the sign-relaxed requirement |
| `reference_sign_defect_nontrivial` | the sign `-1` really occurs (`θ = 0` versus `θ = 2π`) |
| `full_turn_forces` | a full turn forces `α = 0` and `β ∈ (1/2)ℤ`, and fixes `cos(2πβ)` |
| `signValued_rates` | the same for the sign-relaxed requirement |
| `signValued_beta_odd` | the reversal forces `β(-n) = -β(n)` (no direction regularity used) |
| `signValued_eq_reference` | **the surviving class contains exactly one family**: the inherited reference family |
| `signValued_defect_pm_one` | on closed visible relations the defect lies exactly in `{1, -1} ⊂ Z^×` |
| `defect_not_discrete_without_normalization` | negative control: without the normalization the defect realizes a central unit of arbitrary modulus (`-e^{2π}`) |
| `defect_same_axis_trivial`, `defect_chain` | the finite consistency identities, from the inherited associativity alone |

**Exact surviving class of central values.** Not all of `Z^×`; not a continuous subclass;
a **discrete two-element subset** `{1, -1}` on closed visible relations; independent of any
path or representative choice (it is determined by the axis–parameter data through the
coincidence relation). Nothing is quotiented, and no cohomological vocabulary is used.

The two sources are kept apart: the inherited discrete reference-word defect produces the
`±1`; the continuous central residual freedom is what the negative control exhibits.

### Work Package 5 — minimal local repair (`LocalRepair.lean`)

| theorem | content |
|---|---|
| `Dom_covers` | every unit direction lies in a domain |
| `Dom_no_antipodal` | a domain contains no antipodal pair |
| `Dom_scalar_eq` | inside one domain a scalar proportion forces equal scalars |
| `param_shift`, `zexp_half_odd_smul`, `Un_smul_of_branch` | the branch computations |
| `locFam_jointlyRegular` | each local family is jointly regular |
| `locFam_transformationValuedOn` | **local existence**: each `locFam k` is *exactly* transformation-valued on every domain |
| `locFam_not_global` | the same formula fails globally |
| `local_rates` | **local necessity**: on a domain, `α = 0` and `β ∈ ℤ + 1/2` |
| `locFam_rates` | the local families realize all of these values |
| `locFam_overlap` | two local choices differ by a central unit **independent of the direction** |
| `locFam_overlap_unique` | that transition factor is **unique** |
| `locFam_overlap_chain` | transitions compose along finite chains |
| `overlap_defect_central` | for *any* two regular families the discrepancy is central |
| `local_repair_status` | the assembled status |

**Minimal type of information required.** Exactly one integer label per domain, equivalently
one central-unit-valued transition factor per pair of overlapping domains, depending on the
parameter alone and not on the direction; finite chains close automatically by
associativity, so no further datum is needed for them.

**Status: GLOBAL CHOICE IMPOSSIBLE; LOCAL CHOICES SUFFICIENT ON PROPER DOMAINS AND REQUIRE
CENTRAL TRANSITION DATA.** No path-dependent datum was needed for any statement proved
here.

### Work Package 6 — the rate audit (`RateAudit.lean`)

| theorem | content |
|---|---|
| `rate_survival` | the four regimes and their surviving rate data |
| `spatial_rate_forced` | `lam = 1` is **derived**, not conventional |
| `control_no_basis_axis` … `control_rate_separation_persists` | the six negative controls |

---

## 6. Causal reading of the dependency graph

```
inherited carrier W, exact centre Z, unit directions, PhiGen, Un
        ↓
exact coincidence relation                       (Work Package 1)
        ↓
joint direction–parameter regularity              (Work Package 2)
        ↓
global transformation-valued closure: NO-GO       (Work Package 3)
        ↓
surviving class: sign-relaxed closure, unique     (Work Package 4)
        ↓
minimal local repair on proper domains            (Work Package 5)
        ↓
rate audit and negative controls                  (Work Package 6)
        ↓
Option-C comparison, late identification          (COMPARISON ONLY)
```

Every arrow is a Lean import and a theorem dependency. No arrow requires an assumption
beyond the inherited data listed in §2.

---

## 7. Rate table (VII. Final rate audit)

| requirement | `α` | `β` | `lam` |
|---|---|---|---|
| joint regularity only | arbitrary continuous function of the direction (all realized) | arbitrary continuous function of the direction (all realized) | forced to `1` by the implementation requirement (`spatial_rate_forced`) |
| + **exact** global transformation-valuedness | — (no family exists) | — (no family exists) | — |
| + **sign-relaxed** global closure | `≡ 0` | `≡ 0` | `1` |
| + exact closure on a proper domain | `≡ 0` | discrete remnant `ℤ + 1/2`, every value realized | `1` |

**Which survives:** `α` — **neither** globally nor locally (it is always forced to zero by
any closure requirement); `β` — **only a discrete remnant, and only locally**
(`ℤ + 1/2`), it is forced to `0` by the global sign-relaxed requirement and is
unrealizable under the exact global requirement. Path-dependent replacements are **not**
required by anything proved here.

**λ versus the central rates.** Still logically separate: the generator is
`α·1 + β·S − (lam/2)·J n` and the triple is recovered injectively
(`control_rate_separation_persists`, inherited). Task 16 adds only that `lam = 1` is forced
rather than conventional; it creates no relation between `lam` and `(α, β)`.

---

## 8. Negative controls (VIII)

| control | result |
|---|---|
| a particular basis axis | not used: the obstruction holds at *every* unit direction (`control_no_basis_axis`), and the path used in the proof is constructed from an arbitrary orthogonal partner produced by the inherited `exists_unit_orthogonal` |
| a particular minimal carrier | not used: no carrier occurs in any Task-16 statement or proof |
| fixing the Task-14 spatial rate | not assumed: `spatial_rate_forced` derives `lam = 1` from the implementation requirement |
| setting `α` or `β` to zero prematurely | not done: before closure every continuous pair is realized (`control_rates_not_preset`) |
| selecting the normalized reference implementation | not done: the jointly regular class is strictly larger (`control_reference_not_selected`), and the classification quantifies over all jointly regular families |
| omitting antipodal or periodic identifications | not done: both are part of the classified relation, and the antipodal one is exactly what fails — removing it (by passing to a proper domain) restores exact closure (`control_antipodal_is_the_obstruction`) |
| quotienting central discrepancies | not done: the defect is an explicit carrier element with explicit values (`control_defect_not_quotiented`) |
| importing a standard interpretation | not done: firewall report in §2; conventional language occurs only in `Identification.lean`, which nothing depends on |

---

## 9. Final verdict table (IX)

| # | question | answer |
|---|---|---|
| 1 | exact axis–angle coincidence relation | **CLOSED** — `coincidence_iff` / `coincidence_iff_coords`, with all exceptional cases derived |
| 2 | joint continuity in `(n, θ)` | **CLASSIFIED** — `jointRegularity_classification` (an equivalence) |
| 3 | recovered `α, β` regularity | **both are forced to be continuous**, and conversely every continuous pair occurs |
| 4 | global jointly regular transformation-valued family | **DOES NOT EXIST** |
| 5 | central composition defect under joint regularity | **exactly `{1, -1} ⊂ Z^×`** on closed visible relations for the surviving class; *not* discrete without that normalization |
| 6 | minimal local or relational repair | exact closure on proper domains covering all directions; local choices indexed by `ℤ`; transitions central, direction-independent, unique; finite chains close by associativity |
| 7 | spatial rate versus central rates | logically separate; `lam = 1` derived; no new relation |
| 8 | Task-1 Option-C dependency pattern | **REPLACED BY A DISCRETE GLOBAL OBSTRUCTION** (alternative **C**), repaired by domainwise data (alternative **D**); alternative **A** does not hold; **B** holds only for the sign-relaxed requirement |

**Main Task-16 status:**

```
GLOBAL REGULAR REPRESENTATIVE OBSTRUCTED; MINIMAL LOCAL REPAIR CLASSIFIED
```

with the sharper addendum, also proved: the sign-relaxed global requirement *is*
satisfiable and is satisfied by exactly one family, the inherited reference family, whose
residual defect on closed visible relations is exactly `±1`.

---

## 10. Unresolved mathematical obligations

1. **Only finite chains are treated.** `locFam_overlap_chain` closes chains of length
   three, and by iteration any finite chain. Nothing is proved about arbitrary families of
   domains indexed by an infinite set.
2. **Domainwise constancy of the local rate is not proved.** `local_rates` gives
   `β n ∈ ℤ + 1/2` at *each* direction of a domain; that the integer label is the same
   throughout a domain would need a path-connectedness argument inside `Dom v`, which is
   not carried out. Consequently the local classification is stated pointwise, and the
   family `locFam k` is proved to *realize* every label rather than to *exhaust* the
   admissible local choices as whole families.
3. **A stronger `C¹` joint notion is not analysed.** The task allowed introducing one after
   the continuous problem was classified; since the continuous classification already
   pins the families down to a two-parameter continuous family per direction, nothing was
   gained by it and it was not introduced.
4. **The arbitrary spatial word problem remains open**, by the task's own instruction. Only
   the coincidence relation on the axis–parameter representation is classified, so the
   composition defect is analysed on coincidences and on same-axis compositions, not on
   arbitrary finite words.
5. **No claim is made that the domains `Dom v` are minimal.** They are sufficient and
   proper; whether smaller domains would do, or whether some larger class of domains still
   admits exact closure, is not decided.

---

## 11. Source ledger

**IMPORTED STANDARD RESULT** (Mathlib, revision above): the declarations tabulated in §1.

**INHERITED FROM THIS PROJECT** (Tasks 08–15): the declarations tabulated in §2.

**DERIVED IN TASK 16**: every declaration in `RequestProject/NullSectorTask16/`, namely all
definitions of §4 and all theorems of §5.

For the standard mathematics used: the intermediate value property, the tube lemma for a
compact factor, and Jordan's inequality `2x/π ≤ sin x` on `[0, π/2]` are classical; they
are used here only through the Mathlib declarations named in §1.

---

## 12. Late heuristic note (NOT USED IN ANY PROOF)

Only after the structural comparison of `OptionCAudit.lean` is complete may the heuristic
dictionary of the task be mentioned:

```
alpha  <->  common marker-density / local-scale change
beta   <->  common transport / internal progression rate
```

This dictionary is **explicitly heuristic**, appears in **no Lean statement**, and is used
in **no proof**. It is recorded here only because the task asked for it to be stated after
the comparison.

---

## 13. Build and axiom report

```
$ lake build
Build completed successfully (8203 jobs).

$ lake build RequestProject.NullSectorTask16.Task16
Build completed successfully.
```

No warnings are emitted by any Task-16 module.

A mechanical scan of `RequestProject/NullSectorTask16/` finds no `sorry`, no `admit`, no
`axiom` declaration and no `@[implemented_by]` attribute.

All **35** principal theorems exposed by `Task16.lean` report

```
depends on axioms: [propext, Classical.choice, Quot.sound]
```

which are the standard Lean/Mathlib axioms only.
