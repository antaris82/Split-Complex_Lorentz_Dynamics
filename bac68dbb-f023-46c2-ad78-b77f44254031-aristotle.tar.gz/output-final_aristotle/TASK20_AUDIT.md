# TASK 20 AUDIT — Intrinsic Equivalence and Structure Audit

Phase A (intrinsic consolidation) is complete and frozen before Phase B (external
equivalence audit) begins. Everything marked **FORMAL** below is a Lean theorem in
`RequestProject/NullSectorTask20/` that builds without `sorry`; everything marked
**COMPARISON ONLY** is documentation and is *not* claimed as formally verified.

---

## 0. Toolchain, build and provenance

| item | value |
| --- | --- |
| Lean | `leanprover/lean4:v4.28.0` (`lean-toolchain`) |
| Mathlib | `v4.28.0` tag, as pinned in `lakefile.toml` / `lake-manifest.json` |
| new layer | `RequestProject/NullSectorTask20/` |
| focused build | `lake build RequestProject.NullSectorTask20.Task20` — green |
| full build | `lake build` — green, 8249 jobs |
| prohibited constructs | scan of the Task-20 layer for `sorry`, `admit`, `axiom`, `@[implemented_by]`, `native_decide`, `bv_decide`, `unsafe` returns nothing |
| axioms | every `task20_*` endpoint: `propext`, `Classical.choice`, `Quot.sound` (printed by `#print axioms` at the end of `Task20.lean`) |
| warnings | no warnings are emitted by any Task-20 module; the warnings visible in a full build come from earlier layers and are unchanged |

**Source order** (linear; each module imports exactly its predecessor):

```
SafeBase → LiftCarrier → InternalProjection → VisibleQuotient → BridgeTorsor
→ ReversalQuotient → GlobalObstruction → SectionObstruction → NegativeControls
→ Identification (COMPARISON ONLY) → Task20
```

**Reconstruction firewall, verified mechanically.** `SafeBase` imports exactly
`RequestProject.NullSectorTask19.NegativeControls`, the last *reconstruction* module of
Task 19. `RequestProject.NullSectorTask19.Identification` and
`RequestProject.NullSectorTask19.Task19` are imported by no Task-20 module. The single
Task-20 comparison module is imported by `Task20.lean` alone. A vocabulary scan of the
Task-20 reconstruction modules for `rotation`, `spinor`, `covering space`, `bundle`,
`cocycle`, `cohomology`, `holonomy`, `gauge`, `fundamental group`, `projective`, `SU(2)`,
`SO(3)`, `Spin`, `quaternion` returns nothing (the only hit is the inherited neutral phrase
"covering system of open domains"). No physical vocabulary occurs anywhere.

---

## PHASE A

### 1. Package A — the frozen intrinsic signature

| object | carrier | operations / structure | source |
| --- | --- | --- | --- |
| unit-direction carrier | `Sph = {n : Vec3 // IsUnitAxis n}` | subspace topology; compact (`isCompact_unitSet`), path-connected, preconnected (inherited) | Task 16/17/19, compactness new in Task 20 |
| real transformation parameter | `ℝ` | additive | Task 14 |
| visible transformation family | `PhiGen n θ : W →ₗ[ℝ] W` | composition | Task 14 |
| visible coincidence relation | `PhiGen n θ = PhiGen m φ`, classified by `SignRelated` | equivalence | Task 16 (`coincidence_iff`) |
| reference implementer | `Un n θ = cos(θ/2)·1 − sin(θ/2)·J n` | inherited product `⋆` | Task 14 |
| exact centre | `Z = span{1, S}`; invertible part `CUnit` | inherited product | Task 9/11 (`center_eq_Z`) |
| primitive bridge | `IsPrimitiveBridge c` (central, normalized, one-parameter, jointly continuous) | pointwise product | Task 19 |
| two recovered rates | `primRateA c`, `primRateB c` | reals per direction | Task 19 |
| locally exact representatives | `IsLocallyExact (recon c)` | — | Task 19 |
| half-odd local rate set | `HalfOddSet = {x | ∃ k : ℤ, x = k + 1/2}` | `ℤ`-action by translation | Task 18 notion, Task-20 packaging |
| integer relative differences | `ℤ` | group | Task-20 (`halfOddSet_differences`) |
| admissible direction domains | `AdmClass`, `PreconnAdmClass`, `DenseDom` | inclusion | Tasks 17–19 |
| reversal of direction | `negSph`, `negSet` | involution | Task 19 |
| relation-complete local systems | `IsLocalSystem`, `SystemRelationComplete` | — | Task 19 |

*Before/after exactness.* `Lift`, `LiftZ`, `proj`, `CUnit`, `VisQuot`, `RevQuot`,
`IsPrimitiveBridge` and the relative-factor theorems exist **before** any exactness
requirement. `HalfOddSet`, `IsLocallyExact`, `DenseDom`-maximality and the three rate
conditions are **created or restricted by exactness**.

*Global versus local.* Global: `Sph`, `VisQuot`, `Lift`, `LiftZ`, `proj`, `RevQuot`, the
three rate conditions. Local/domain-dependent: `Dom v`, local systems, local exactness,
labels on components.

*Visible versus internal equality.* Visible equality is `visRel`; internal equality is
equality in `W`. They differ exactly by the kernel computed in Package C: `visRel p q` holds
iff `Un p = ± Un q` (`visRel_iff_signRelated`).

### 2. Package B — the exact quotient represented by visible equality (FORMAL)

* `visRel` is reflexive, symmetric and transitive (proved separately, items 19).
* `VisQuot := Quotient visSetoid`; the visible map factors through it and the factorization
  is **unique** (`visLift_unique`).
* The induced map onto the visible image is a **bijection** (`visToImage_bijective`).
* **Topology (item 23):** the quotient topology *agrees* with the subspace topology on the
  visible image — the canonical bijection is a homeomorphism (`visHomeo`). Hypotheses used:
  compactness of `Sph`, the bounded-parameter representation `Lift_repr_Icc` (every internal
  element is `Un n ψ` with `ψ ∈ [0, 2π]`), and the Hausdorff property of the inherited map
  space.
* **Algebra (items 24, 25):** full closure holds. The visible image contains the identity, is
  closed under composition and under inversion (`visImage_closed_law`). No weaker structure
  (semigroup, partial monoid, …) has to be recorded.
* **Item 26:** relation completeness *is* the statement that internal data are constant on
  the classes of `visRel`; the word "descent" is not used in any theorem statement. The
  formal content is `task20_internal_choice` together with the inherited
  `relationComplete_system_iff_primitiveBridge`.

### 3. Package C — the internal object above the visible one (FORMAL)

* Core carrier `Lift = {a·1 − J v | a² + ⟨v,v⟩ = 1}`, proved equal to the set of reference
  implementers (`mem_Lift_iff_exists_Un`): closed under product (`Lift_mul_mem`, via the
  four-square identity `quat_norm_mul`) and under inversion (`Lift_inv_mem`).
* Full carrier `LiftZ = CUnit ⋆ Lift`: closed under product and inversion.
* Projection `proj u = conjugation by u`; `proj (Un n θ) = PhiGen n θ`; multiplicative on
  invertibles.
* **Kernel over the core: exactly `{1, −1}`** (`kernel_core`).
* **Kernel over the full carrier: exactly `CUnit`**, which equals the **centre** of `LiftZ`
  (`kernel_full`, `centre_LiftZ`).
* Hence the answer to item 33 is: *it depends on the subcarrier*, and both cases are proved
  (`kernel_vs_centre`). Item 34 is answered positively: the core carrier is a distinguished
  subcarrier whose kernel is a two-element set, while the larger kernel contains the
  continuous injective one-parameter family `t ↦ zexp 1 0 t` (`kernel_full_continuum`).
* **Item 35:** `Un n (2π) = −1`, `Un n (4π) = 1`, `proj (Un n (2π)) = id`, and
  `Un n (2π) ≠ Un n 0` (`full_turn_sign`). No central factor was discarded anywhere
  (item 36).

### 4. Package D — primitive bridges as relative data (FORMAL)

* **Item 37/38:** for two elements of `LiftZ` with equal projection there is **exactly one**
  invertible central factor converting one into the other
  (`relative_factor_existsUnique`); in `Lift` the relative factor is exactly a sign
  (`relative_factor_core`). Both are pure internal algebra.
* **Item 39:** the relative-factor theorems use no continuity and no exactness. By contrast
  the inherited exact normal form `c n θ = zexp (primRateA c n) (primRateB c n) θ` has
  joint continuity in its hypothesis (`IsPrimitiveBridge.cont`); that hypothesis is where
  continuity is genuinely used.
* **Items 40, 41:** inherited and unchanged — local exactness of `recon c` is *equivalent* to
  "first rate vanishes and directional rate is half-odd at every unit direction"
  (`recon_locallyExact_iff`); global exactness adds exactly reversal oddness
  (`recon_globallyExact_iff`).
* **Items 42, 43:** the labelled central factors `labelBridge b` form a group under the
  pointwise product with `labelBridge b ⋆ labelBridge b' = labelBridge (b+b')`; the
  *locally exact* ones do **not** (their labels avoid `0`), and instead form an affine
  `ℤ`-object; their relative data form exactly the group `ℤ` (`halfOddSet_differences`).

### 5. Package E — the half-odd / integer pair (FORMAL)

`halfOddSet_torsor`: nonempty, `0 ∉ HalfOddSet`, the `ℤ`-action by translation is
well-defined, **free** (item 46) and **transitive** with a unique translating integer
(item 47); hence no intrinsically distinguished origin (item 48) and the exact affine/torsor
property is recorded as a theorem (item 49).

**Items 50, 51 — reduction modulo a proper subgroup.** What survives any reduction: the value
after a full turn, which is `−1` for *every* allowed label (`labelBridge_full_turn`). What is
lost: the labels themselves — `1/2` and `5/2` differ by an even integer, have equal full-turn
value, and yet give different central factors at `θ = π/2`
(`reduction_loses_information`). Distinct labels always give distinct factors
(`labelBridge_injective`).

### 6. Package F — reversal and selector geometry (FORMAL)

* Reversal is treated as an involution; its orbit relation `revRel` is proved to be an
  equivalence and the quotient `RevQuot` is constructed with **no** conventional name.
* Fibre translations (item 54): antipodal-free ⇔ at most one domain direction per fibre;
  antipodally complete ⇔ at least one per fibre; both ⇔ **exactly one** per fibre, i.e. the
  domain is a *selector* (`selector_iff`). These use no continuity and no rate.
* Item 55: inclusion-maximal admissible ⇔ *dense selector* (`maximal_iff_dense_selector`).
* Item 56, the separation: the "selector" half is a theorem about the involution quotient
  alone; the "dense" half is *not* — it enters through the inherited rigidity of a
  continuous half-odd rate on a dense set (Task 19, `rate_const_of_dense`).
* Item 57: density is exactly the maximal-extension condition — a non-dense selector can be
  enlarged, which is the content of the inherited criterion.
* Item 58: maximal selectors are not unique, and the distinguishing datum is the fibre where
  they choose the other representative (`maximal_selectors_not_unique`).

### 7. Package G — the obstruction, and its minimal form (FORMAL)

* The three inherited conditions are frozen unchanged, and the inherited minimality theorem
  (jointly unsatisfiable, every proper subset realizable) is preserved.
* **Item 62 — the smallest intrinsic statement:** a continuous reversal-odd real rate on the
  unit directions *has a zero* (`exists_zero_of_odd`); equivalently, no continuous
  reversal-odd rate takes values in a set avoiding zero
  (`no_continuous_odd_rate_avoiding_zero`). Ingredients: preconnectedness of the direction
  carrier and the involution. Nothing else.
* **Item 63 — is the half-odd restriction essential?** *No.* The only property of the
  half-odd set that is used is `0 ∉ HalfOddSet`. The obstruction holds verbatim for the
  non-discrete set of strictly positive values (`no_positive_odd_rate`). Discreteness
  strengthens the phenomenology (it makes rates locally constant) but is *not* the source of
  the obstruction.
* **Item 64 — countermodels:** the three inherited witnesses `signRate`, `rateZero`,
  `rateHalf`, plus the vanishing rate as the countermodel for "remove the exclusion of zero"
  (`obstruction_countermodels`).

### 8. Package H — relation completeness (FORMAL, partly re-exported)

* Inherited and re-exported unchanged: same-direction and identity-degenerate coincidences
  are automatic; the reversal-related class is the only nonautomatic one; relation
  completeness of a locally exact open covering system is **equivalent** to existence of a
  primitive global bridge with globally exact reconstruction; and no such system exists
  (`task20_relation_completeness`).
* **New in Task 20, and the sharpest formulation of the whole phenomenon**
  (`task20_internal_choice`):
  * a quotient-compatible internal choice **exists** — a map from the parameter carrier to
    the internal core carrier which lifts the visible map and is constant on visible-equality
    classes;
  * **no** quotient-compatible internal choice is **continuous**.
  The proof uses only: the sign-ambiguity theorem, connectedness of the parameter carrier,
  and `Un n (2π) = −1`. Hence the obstruction is *exactly* a continuity obstruction, not a
  set-theoretic one — which is also the Package-L control against reading any nonexistence
  statement as an impossibility of choice.

### 9. Packages I and J — frozen, with the open questions marked

Both inherited packages are **frozen as Task-20 endpoints** (`task20_label_extension`,
`task20_regularity`): the statements are re-exported verbatim so that they can be cited
against the Task-20 packaging. No new theorem is added, and the open questions below remain
open.

* **Package I (disconnected labels).** The inherited Task-19 closure-extension criterion is
  necessary and sufficient, and the inherited counterexample shows that pure separation of
  differently labelled closures is *not* sufficient. Whether the criterion can be replaced by
  a purely geometric/combinatorial condition with no existential ambient function is
  **OPEN**; Task 20 adds no theorem here and makes no claim. Consequently the question
  whether the disconnected-extension problem is independent of the quotient/bridge problem is
  also recorded as **OPEN** rather than answered. What *is* proved (Task 19) is that after
  the local rate classification is fixed the two problems have disjoint hypotheses; that is
  not a proof of independence.
* **Package J (regularity).** Inherited unchanged: continuous, every finite `Cᵏ`, and smooth
  admissibility define the same arbitrary-domain class, while an analytic function with an
  exact plateau is constant, so the smooth mechanism has no literal analytic replacement;
  arbitrary-domain analytic admissibility remains **OPEN**. Task 20 adds nothing and claims
  nothing here.

---

## PHASE B — external equivalence audit

Phase B was begun only after the above was frozen. Only one comparison is carried out
formally; the rest are documentation, labelled with the required status vocabulary.

### 10. The one formal external identification

**FORMAL, EXACT EQUIVALENCE.** `task20_comparison` /
`lift_eq_image_unit_quaternions`: the map

```
fromQuat q = q.re · 1 − J (q.imI, q.imJ, q.imK)
```

is injective, unital and multiplicative from `Quaternion ℝ` into the inherited carrier, and

```
Lift = fromQuat '' { q | normSq q = 1 }.
```

So the intrinsic internal core carrier, with the inherited product, **is** the group of unit
quaternions; the explicit map and its inverse are given, which is what §90 requires for
`EXACTLY IDENTIFIED`.

*Source ledger for this item.* IMPORTED STANDARD RESULT: the quaternion algebra
`Mathlib.Algebra.Quaternion` (`Quaternion`, `Quaternion.re_mul`, `Quaternion.imI_mul`,
`Quaternion.imJ_mul`, `Quaternion.imK_mul`, `Quaternion.normSq_def'`,
`Quaternion.ext`). DERIVED IN TASK 20: the map, its multiplicativity, its injectivity, and
the image statement. The four-square (Euler) identity is *not* imported; it is proved as
`quat_norm_mul` inside the reconstruction layer, in the inherited coordinates.

### 11. Equivalence matrix (item 109)

Status vocabulary is restricted to the seven permitted values.

| intrinsic structure | exact intrinsic theorem | best established candidate | status | explicit map | inverse / converse | unmatched structure | source |
| --- | --- | --- | --- | --- | --- | --- | --- |
| internal core carrier `Lift` with `⋆` | `mem_Lift_iff_exists_Un`, `Lift_mul_mem`, `Lift_inv_mem`, `quat_norm_mul` | unit quaternions (group of norm-one quaternions) | `EXACTLY IDENTIFIED` | `fromQuat` (formal) | inverse formal (injective, image computed) | none | Hamilton's quaternions; Mathlib `Mathlib.Algebra.Quaternion` |
| full internal carrier `LiftZ` | `LiftZ_mul_mem`, `LiftZ_inv_mem`, `centre_LiftZ` | central extension of the previous group by an invertible central plane | `PARTIAL` | none formalized | — | the exact centre is a two-dimensional plane, not a circle: the "modulus" direction of the centre is unmatched by the usual normalized conventions | — |
| visible image with composition | `visImage_closed_law`, `kernel_core` | a group with a two-element kernel above it | `NO MATCH FOUND` (as a *formal* identification); the natural candidate is not constructed here | none | — | no rotation group, no orthogonal group is built in this project | — |
| visible quotient object `VisQuot` | `task20_visible_quotient`, `task20_quotient_topology` | quotient of a parameter space by an explicit relation | `EXACTLY IDENTIFIED` **internally** (it is its own object); external identification `NO MATCH FOUND` | — | — | — | — |
| kernel `{1, −1}` of the core projection | `kernel_core` | a two-element kernel | `ANALOGOUS ONLY` | — | — | a two-valued ambiguity does not by itself determine a covering object; no covering space, projection or fibre theorem is constructed (Package L, items 103, 105) | — |
| centre of `LiftZ` | `centre_LiftZ`, `kernel_full_continuum` | invertible elements of a two-dimensional commutative plane | `PARTIAL` | — | — | the continuous one-parameter freedom is genuinely present and is *not* quotiented | — |
| primitive bridge as relative factor | `relative_factor_existsUnique` | relative factor between two lifts of the same datum | `EQUIVALENT UNDER STATED HYPOTHESES` (uniqueness needs invertibility only) | — | — | — | — |
| half-odd label set with `ℤ`-action | `halfOddSet_torsor`, `halfOddSet_differences` | free transitive `ℤ`-set (affine `ℤ`-object / `ℤ`-torsor) | `EXACTLY IDENTIFIED` (as a torsor: the three torsor axioms are theorems) | translation by the unique integer | converse proved (transitivity + freeness) | none | standard notion of a torsor over a group |
| integer relative labels | `halfOddSet_differences` | the group `ℤ` | `EXACTLY IDENTIFIED` | difference map | converse proved | *not* called cohomological: no coefficient object, cochain, differential or class is constructed (item 106) | — |
| reversal involution quotient `RevQuot` | `revRel` equivalence, `selector_iff` | quotient of a set by a free involution | `EXACTLY IDENTIFIED` as such | orbit map | converse proved | the *topological* nature of the quotient (as a space) is not analysed; only fibres are | — |
| dense maximal selectors | `maximal_iff_dense_selector`, `maximal_selectors_not_unique` | dense choice of one point per orbit | `EQUIVALENT UNDER STATED HYPOTHESES` (density is the extra hypothesis) | — | — | — | — |
| global obstruction | `task20_minimal_obstruction`, `no_continuous_quotient_compatible_lift` | "a continuous odd real function on a connected involutive space vanishes" (the one-dimensional intermediate-value form) | `EXACTLY IDENTIFIED` with that elementary statement (proved here) | — | — | any deeper topological reading is *not* claimed | intermediate value theorem |
| relation completeness | `task20_relation_completeness` (inherited) | local-to-global compatibility condition | `PARTIAL` | — | — | its equivalence with bridge existence is proved; its status as an instance of a standard local-to-global theorem is not established | — |
| disconnected label extension | inherited Task-19 criterion | — | `OPEN` | — | — | — | — |
| analytic admissibility | inherited Task-19 audit | — | `OPEN` | — | — | — | — |

### 12. Internal fusion graph (item 111): which intrinsic objects are *proved* equal

```
visible equality  ── coincidence_iff ──►  internal equality up to sign
        │                                          │
        ▼                                          ▼
  VisQuot  ◄── bijective, homeomorphic ──►  visible image
        │                                          ▲
        │                       proj, kernel {1,−1}│
        ▼                                          │
 quotient-compatible internal choice  ────────►  Lift  ◄── = unit quaternions (Phase B)
        │  (exists; never continuous)               │
        ▼                                          ▼
 global obstruction  ═══ equivalent ═══  no continuous half-odd reversal-odd rate
        ║                                          ║
        ║                                     equivalent (Task 19)
        ▼                                          ▼
 relation incompleteness  ═══ equivalent ═══  no primitive global bridge
```

Proved-equal (internal equivalences): {global rate obstruction} = {primitive global bridge
nonexistence} = {global exact family nonexistence} = {relation incompleteness} =
{failure of a *continuous* quotient-compatible internal choice}; and
{antipodal-free + antipodally complete} = {selector for the reversal quotient}.

### 13. External map (item 112)

Only two classes map to an established object *by an exact theorem*: the internal core
carrier (unit quaternions) and the label pair (a `ℤ`-torsor together with its difference
group `ℤ`). The visible object, its two-element kernel, and the relation-completeness
condition are **not** externally identified in this project; they are recorded as
`NO MATCH FOUND` / `PARTIAL` in the sense of §92, not as novelty claims.

### 14. Provenance (items 114, 115): where each externally identified structure becomes unavoidable

| externally identified structure | first point where it is forced | forcing constraint |
| --- | --- | --- |
| unit quaternions as the internal core carrier | Task 14, the derivation of `Jmap` with `J n ⋆ J m = −⟨n,m⟩·1 − J(n×m)` and the reference family `Un n θ = cos(θ/2)·1 − sin(θ/2)·J n` | the requirement that a single associative carrier implement all axis families with a one-parameter law; the half-angle appears there, not later |
| the two-element ambiguity | Task 16, `coincidence_iff`: visible equality is internal equality **up to sign** | the passage from implementers to the transformations they implement |
| the continuous central freedom | Task 9/11, `center_eq_Z`: the exact centre is a two-dimensional plane | the reconstructed carrier itself; it is not introduced later and is never quotiented |
| the half-odd labels | Task 18, exactness at one point forces half-oddness of the recovered directional rate | local exactness, not a global condition |
| the integer relative labels | Task 18/19, differences of half-odd labels | the torsor structure of the label set |
| the reversal obstruction | Task 19, joint incompatibility of continuity, half-oddness and reversal oddness; sharpened in Task 20 to "a continuous odd rate has a zero" | connectedness of the direction carrier plus the exclusion of zero from the label set |

### 15. Required final verdict (item 126, the fifteen questions)

1. **Exact visible quotient object.** `VisQuot`, the quotient of `Sph × ℝ` by equality of the
   visible transformation; it is in bijection with the visible image and, with the quotient
   topology, homeomorphic to it. FORMAL.
2. **Exact internal object projecting to it.** Two of them, and the distinction matters:
   `Lift` (the reference implementers, closed under product and inverse) and
   `LiftZ = CUnit ⋆ Lift`. FORMAL.
3. **Kernel of the projection.** Over `Lift`: exactly `{1, −1}`. Over `LiftZ`: exactly the
   invertible central elements, which is also the centre of `LiftZ`. So the kernel is *not*
   an absolute invariant: it depends on the chosen internal subcarrier. FORMAL.
4. **Is the primitive bridge a standard relative-lift object?** Yes in the exact sense proved
   here: it is the unique invertible central factor between two internal lifts of the same
   visible datum. FORMAL (no continuity, no exactness used).
5. **What explains the half-odd/integer affine pair?** A free transitive `ℤ`-action on a set
   with no distinguished element — a torsor — whose difference group is exactly `ℤ`. FORMAL.
   No cohomological reading is claimed.
6. **What explains the reversal obstruction?** The elementary statement that a continuous
   odd real function on a connected involutive carrier has a zero, combined with the single
   fact that the allowed label set excludes zero. FORMAL. The discrete half-odd structure is
   **not** essential.
7. **Is relation completeness an instance of a standard local-to-global theorem?** Not
   established. It is proved *equivalent* to bridge existence and to the existence of a
   continuous quotient-compatible internal choice; whether that equivalence is an instance of
   a named standard theorem is recorded as `PARTIAL`/`OPEN`.
8. **What exactly are the maximal dense selectors?** Sets meeting every fibre of the reversal
   quotient exactly once and dense in the direction carrier; they exist, are not unique, and
   two of them are distinguished by the fibres at which they choose differently. FORMAL.
9. **Are the selector and global-obstruction phenomena the same quotient structure?** They are
   *coupled but not identical*: the selector condition is a statement about the involution
   quotient alone (proved with no continuity), while the obstruction needs connectedness plus
   the exclusion of zero. The common core is the involution; the obstruction adds topology.
10. **Does disconnected extension belong to the same framework?** Not determined. `OPEN`; no
    Task-20 theorem is claimed.
11. **Does analytic regularity reveal a genuinely new class?** Not determined. `OPEN`,
    inherited from Task 19.
12. **Is there one established construction explaining the cumulative object?**
    **NO SINGLE CLASSICAL OBJECT IDENTIFIES THE COMPLETE RECONSTRUCTED STRUCTURE** — at the
    standard of proof used here. One component is exactly identified (unit quaternions);
    the visible object and its kernel are deliberately left unidentified, since no covering
    object, bundle or class was constructed (Package L, items 104–106).
13. **Minimal collection of established structures required.** Three, as far as this audit
    proves anything: (i) the unit quaternions with their product; (ii) a torsor over `ℤ`;
    (iii) the intermediate-value property of continuous real functions on a connected
    involutive carrier. Their coupling in the reconstructed system is: (i) is the internal
    carrier above the visible quotient, (ii) labels the central factors relating internal
    lifts, and (iii) is what forbids a continuous global choice among those lifts.
14. **Is that particular coupling documented in the literature?** *No matching combined
    formulation located in the searched literature.* This is a statement about the search,
    not a novelty claim.
15. **Which cumulative correspondences are exact and which are analogies?** Exact: the
    internal core carrier; the label torsor and its difference group; the obstruction as the
    elementary odd-function statement. Analogy only: the reading of `{1, −1}` as a covering
    fibre. Not established: any identification of the visible object with a named group, and
    any cohomological reading of the integer labels.

---

## 16. Unresolved obligations

1. Arbitrary-domain analytic admissibility (inherited from Task 19).
2. A purely geometric/combinatorial criterion for disconnected label extension, and the
   independence question that depends on it.
3. Formal identification of the visible image with a named transformation group (not
   attempted; would require constructing that group and an explicit isomorphism).
4. Whether relation completeness is an instance of a named local-to-global theorem.
5. A formal statement of the topological structure of the reversal quotient as a space (only
   its fibres are analysed here).

## 17. Failed and abandoned attempts (item 122)

* An attempt to prove the topological item 23 by a direct open-map argument was abandoned;
  the compactness route (compactness of the direction carrier plus the bounded-parameter
  representation `Lift_repr_Icc`) is the one that works, and it is the reason
  `isCompact_unitSet` and `Lift_repr_Icc` exist at all.
* An attempt to obtain the sign function of an internal choice from a coordinate of the
  carrier failed (coordinates vanish); the coordinate **pairing** with the reference
  implementer works, because the reference implementer is normalized (`dotW_Un_self`).
* No counterexample was found to "disconnected extension is independent of the rate torsor",
  and no proof either; the item is left `OPEN` rather than guessed.

## 18. Source ledger

**IMPORTED STANDARD RESULT** (Mathlib, `v4.28.0`):
`Metric.isCompact_of_isClosed_isBounded`, `isCompact_iff_compactSpace`, `isCompact_Icc`,
`IsCompact.prod`, `IsCompact.image`, `intermediate_value_univ`,
`Continuous.homeoOfEquivCompactToT2`, `Equiv.ofBijective`, `Continuous.quotient_lift`,
`continuous_quotient_mk'`, `Quotient.out_eq`, `Real.cos_arccos`, `Real.sin_arccos`,
`Real.arccos_nonneg`, `Real.arccos_le_pi`, `Real.cos_add_int_mul_two_pi`,
`Real.sin_add_int_mul_two_pi`, `Real.cos_pi`, `Real.sin_pi`, `Real.cos_two_pi`,
`Real.sin_two_pi`, `Real.cos_add_pi`, `Real.sin_add_pi`, `Real.cos_pi_div_four`,
`Real.sin_sq_add_cos_sq`, `Real.exp_injective`, and (comparison module only)
`Mathlib.Algebra.Quaternion`.

**INHERITED FROM THE RECONSTRUCTION** (Tasks 1–19): the carrier `W` and its product, `w1`,
`wS`, `Z`, `zc`, `zexp`, `Jmap` with `Jmap_mul`, `Un` with `Un_group`, `PhiGen`,
`coincidence_iff`, `phiGen_eq_of_signRelated`, `center_eq_Z`, `centralizer_pair_eq_Z`,
`IsPrimitiveBridge` and its normal form, `recon_locallyExact_iff`,
`recon_globallyExact_iff`, `RateCont`/`RateHalfOdd`/`RateRev` with the three witnesses,
`negSph`, `AntipodalFree`, `AntipodalComplete`, `DenseDom`, `maximal_adm_iff`, `flipSet` and
its properties, `IsLocalSystem`, `SystemRelationComplete`,
`relationComplete_system_iff_primitiveBridge`, `global_obstruction_is_relation_incompleteness`,
`relationComplete_iff_antipodalRelated`, `coverage_not_relationComplete`.

**DERIVED IN TASK 20**: everything in `RequestProject/NullSectorTask20/`, in particular
`isCompact_unitSet`, `exists_zero_of_odd`, `Lift`, `quat_mul`, `quat_norm_mul`,
`Lift_repr_Icc`, `mem_Lift_iff_exists_Un`, `CUnit`, `LiftZ`, `proj`, `kernel_core`,
`kernel_full`, `centre_LiftZ`, `kernel_vs_centre`, `full_turn_sign`, `VisQuot`, `visHomeo`,
`visImage_closed_law`, `relative_factor_existsUnique`, `relative_factor_core`,
`HalfOddSet`, `halfOddSet_torsor`, `halfOddSet_differences`, `labelBridge`,
`reduction_loses_information`, `RevQuot`, `selector_iff`, `maximal_iff_dense_selector`,
`no_continuous_odd_rate_avoiding_zero`, `exists_quotient_compatible_lift`,
`no_continuous_quotient_compatible_lift`, `anti_overclaim_controls`, and the comparison-only
`fromQuat` identification.
