This project was edited by [Aristotle](https://aristotle.harmonic.fun).

To cite Aristotle:
- Tag @Aristotle-Harmonic on GitHub PRs/issues
- Add as co-author to commits:
```
Co-authored-by: Aristotle (Harmonic) <aristotle-harmonic@harmonic.fun>
```

# Null-Sector Foundation — Tasks 01, 02 and 03

Three self-contained, machine-checked Lean 4 developments.

**Task 01** — the split-complex / null-coordinate decomposition of a fixed 1+1 plane
inside 3+1 Minkowski space, the classification of the future-causal coefficient
quadrant, the action of longitudinal boosts, the invariant product of complementary
coefficients, and two elementary limiting regimes.

**Task 02** — a reconstruction, uniqueness and obstruction audit: starting from the
longitudinal carrier and its quadratic form alone (the split-complex multiplication
removed from the construction layer), which bilinear products are possible, and which
additional datum is needed before the algebraic structure is forced?

**Task 03** — what survives when the chosen unit is allowed to transform: preservation
of the polarization, the orbit of normalized future units, the covariance of the whole
reconstructed product family, the exact classification of transporters and of the
stabilizer of a unit, and the residual discrete ambiguity in the two complementary null
sectors.

All three are carrier-and-transformation audits. No physical ontology is attached to any
object: everything is real vector spaces, quadratic forms, bilinear maps, linear
equivalences and real coefficients.

## Environment

| Item | Value |
| --- | --- |
| Lean toolchain | `leanprover/lean4:v4.28.0` (see `lean-toolchain`) |
| Mathlib | `v4.28.0`, commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (see `lake-manifest.json`) |
| Build target | `RequestProject` library (`lakefile.toml`) |

## Layout

```
RequestProject/NullSectorTask01/Basic.lean        -- 3+1 carrier, Q₄, longitudinal 1+1 carrier, Q₂, ι
RequestProject/NullSectorTask01/SplitComplex.lean -- split-complex product, e₊/e₋, null coordinates, Q₂(P a b) = a b
RequestProject/NullSectorTask01/Strata.lean       -- future-causal quadrant and its four strata
RequestProject/NullSectorTask01/Boost.lean        -- longitudinal boosts, reciprocal scaling, invariant product
RequestProject/NullSectorTask01/Limits.lean       -- boundary families and the two limiting regimes
RequestProject/NullSectorTask01/Task01.lean       -- imports everything, states the principal final theorems

RequestProject/NullSectorTask02/LorentzData.lean      -- polarization L2 of Q₂, its properties, chosen vectors u₀, s₀
RequestProject/NullSectorTask02/CandidateProduct.lean -- unknown bilinear product, unit/multiplicativity predicates
RequestProject/NullSectorTask02/FixedUnit.lean        -- complete classification of products admissible at u₀
RequestProject/NullSectorTask02/Minimality.lean       -- left-unit-only classification and the three minimality tests
RequestProject/NullSectorTask02/GeneralUnit.lean      -- arbitrary unit: existence ⇔ Q₂ e = 1, uniqueness, future units
RequestProject/NullSectorTask02/Canonicality.lean     -- explicit rational symmetry and the equivariance obstruction
RequestProject/NullSectorTask02/Comparison.lean       -- late comparison with Task 01 (only file importing SplitComplex)
RequestProject/NullSectorTask02/Task02.lean           -- principal classification/obstruction theorems, axiom report

RequestProject/NullSectorTask03/Core.lean         -- Lorentz maps, unit orbit and transporters, product covariance, null pair
RequestProject/NullSectorTask03/Task03.lean       -- late comparison with the Task-01 boost and idempotents;
                                                  -- principal theorems, axiom report
```

Task 03 keeps its core in a single module: every module of this project imports the
whole of Mathlib, which dominates compilation time, so a short dependency chain is much
cheaper to build.  The four layers intended by the task (Lorentz maps, unit orbit,
product covariance, null pair) are the four sections of `Core.lean`.

Task 02 respects a strict import firewall: its core files import only
`RequestProject.NullSectorTask01.Basic`; the Task-01 split-complex layer enters solely
in `Comparison.lean`. See §2 of `TASK02_AUDIT.md` for the mechanical audit.

Task 03 respects the same discipline: `Core.lean` imports only
`RequestProject.NullSectorTask02.GeneralUnit`, and the Task-01 boost/split-complex
declarations are imported exclusively by `RequestProject/NullSectorTask03/Task03.lean`,
which is compiled only after the whole core has compiled.  The late comparison layer and
the principal theorems share that one module because every module of this project
imports the whole of Mathlib, which dominates compilation time.
See §2 and §20 of `TASK03_AUDIT.md`.

## Build

```
lake build
```

or, per task,

```
lake build RequestProject.NullSectorTask01.Task01
lake build RequestProject.NullSectorTask02.Task02
lake build RequestProject.NullSectorTask03.Task03
```

No development contains `sorry`, `admit`, or a custom `axiom`. All principal
theorems depend only on `propext`, `Classical.choice`, `Quot.sound`.

## Documentation

* [`TASK01_AUDIT.md`](TASK01_AUDIT.md) — Task 01 audit.
* [`TASK02_AUDIT.md`](TASK02_AUDIT.md) — Task 02 audit: input definitions, import-firewall
  report, theorem inventory, fixed-unit and weakened-assumption classifications,
  assumed-versus-derived table, arbitrary-unit result, future-unit/canonicality result,
  equivariance obstruction, late comparison with Task 01, final dependency graph,
  negative-control table, source ledger, build and axiom reports.
* [`TASK03_AUDIT.md`](TASK03_AUDIT.md) — Task 03 audit: imported Task-02 inputs,
  import-firewall report, Lorentz/future/orientation definitions, `Q2 → L2` preservation,
  unit-orbit classification, transporter existence and uniqueness, stabilizer,
  product covariance, fixed-product invariance versus family covariance, spacelike
  companions, ordered/unordered null pair, transport of the null pair, product-family
  orbit, dependency graph, late comparison with Task 01, negative-control table, source
  ledger, build and axiom reports.
