This project was edited by [Aristotle](https://aristotle.harmonic.fun).

To cite Aristotle:
- Tag @Aristotle-Harmonic on GitHub PRs/issues
- Add as co-author to commits:
```
Co-authored-by: Aristotle (Harmonic) <aristotle-harmonic@harmonic.fun>
```

# Null-Sector Foundation — Tasks 01–04, 06–21, 23

Twenty-one self-contained, machine-checked Lean 4 developments.

**Task 01** — the split-complex / null-coordinate decomposition of a fixed 1+1 plane
inside 3+1 Minkowski space, the classification of the future-causal coefficient
quadrant, the action of longitudinal boosts, the invariant product of complementary
coefficients, and two elementary limiting regimes.

**Task 02** — a reconstruction, uniqueness and obstruction audit: starting from the
longitudinal carrier and its quadratic form alone (the split-complex multiplication
removed from the construction layer), which bilinear products are possible, and which
additional datum is needed before the algebraic structure is forced?

**Task 03** — what survives when the chosen unit is allowed to transform: preservation
of the polarization, the orbit of normalized future units, the covariance of the whole
reconstructed product family, the exact classification of transporters and of the
stabilizer of a unit, and the residual discrete ambiguity in the two complementary null
sectors.

**Task 04** — leaving the single fixed spatial direction: every unit spatial direction
orthogonal to a chosen future unit defines its own longitudinal 1+1 sector, and Task 04
classifies exactly which global bilinear products on the 3+1 carrier restrict to the
reconstructed product in *every* such sector — what is thereby forced, what cross-sector
freedom remains, what commutativity and spatial isotropy remove, how orientation acts on
what survives, and whether associativity or global norm multiplicativity can survive at
all.

**Task 06** — a clean-room reconstruction of the orientation-sensitive gluing
classification, plus a universal obstruction probe. Phase A starts from a completely
unknown alternating cross-sector defect and derives, from explicit orientation-preserving
rest-space symmetries alone, exactly which defects survive; only afterwards is a nonzero
witness constructed, the solution space determined, the coordinate formula derived,
orientation reversal analysed, and the outcome compared with Task 04. Phase B returns to
an arbitrary sector-compatible bilinear product with no symmetry assumption and settles,
separately, whether global associativity and whether global `Q4` multiplicativity are
possible at all.

**Task 07** — opening exactly one Task-06 assumption: mixed products of embedded vectors
are no longer required to stay inside the original carrier. For two orthogonal spatial
directions, associativity forces a mixed product outside the old carrier, and the
two-generator system has a finite minimal associative closure.

**Task 08** — adding the third inherited orthogonal spatial direction: which further
product directions are forced, what the minimal associative closure of the complete
three-direction spatial system is, and whether it carries an injective copy of the whole
original `3+1` carrier on which the inherited square law survives.

**Task 09** — the second obstruction isolated in Part VI: can the inherited Lorentz
quadratic form be extended from the embedded old carrier to the *fixed* Task-08
associative closure as a quadratic multiplicative map? The real scalar codomain is tested
first and refuted; the internally derived central two-plane spanned by the unit and the
derived central element is then constructed, an entirely unknown map into it is analysed
before any candidate exists, rigidity is proved, and the complete solution space is
classified.

**Task 10** — one distinguished old spatial axis is selected and interpreted only as a
direction: old space splits into a longitudinal line and a transverse plane, and the
single one-parameter rotation fixing that axis is studied. Its extension to the Task-08
associative carrier is proved to exist and to be unique; the longitudinal and transverse
transformation channels are classified; an internal lift implementing the same rotation by
conjugation is sought only afterwards, found inside the derived two-plane spanned by the
unit and the transverse channel, and classified exactly — the half angle is derived, not
assumed, and a multiplicative scalar function is proved to remain free. The candidate-state
left action is then distinguished from the algebra action at `2π`, the two
distinguished-axis half-angle sectors are classified, transverse state orientation is shown
*not* to be selected by the present data, and the structure-preserving axial derivations are
shown to form exactly one real line — a fixed direction with a free scale.

**Task 11** — hardening the axial lift of Task 10. The restriction that an internal
implementer take its values in the two-plane `K = spanℝ{1, R}` is removed completely: an
arbitrary map `U : ℝ → W` is only required to satisfy `U 0 = 1`, the one-parameter group
law, and `U θ ⋆ x ⋆ U (−θ) = Φθ x`. The exact center of the reconstructed carrier is
determined intrinsically (it is exactly the derived central two-plane, already forced by
commutation with two generators), the centralizer of the generating triple is computed and
a one-generator negative control given, two arbitrary lifts are compared before any
explicit formula is introduced, and the residual freedom is classified exactly: first
algebraically (an arbitrary central multiplicative map, including discontinuous ones) and
then — under continuity alone — as a two-real-parameter intrinsic exponential–rotation
family in the derived basis `1, S`. The general `2π` and `4π` values are derived, the
Task-10 real scaling result is located as the `K`-slice of the larger freedom, both
Task-09 quadratic branches are tested symmetrically as explicitly *conditional*
compatibility conditions (with the resulting unit-like relation derived rather than
assumed), and differentiable lifts are shown to add nothing: their left generator is an
arbitrary central element plus a fixed axis term, the commutator of which is exactly the
inherited infinitesimal algebra generator. The invisible component of the generator is
proved to be exactly the center, and this freedom is formally distinguished from the
Task-10 derivation-rate freedom.

**Task 12** — hardening the candidate state carrier. The eight-dimensional reconstructed
algebra `W` had so far been used only as a probe carrier; Task 12 asks which are the
smallest nonzero *left-stable* subspaces it already contains. A neutral predicate
`IsLeftCarrier L` (`∀ x ψ, ψ ∈ L → x ⋆ ψ ∈ L`) and an intrinsic minimality notion are
defined without any module- or representation-theoretic vocabulary, and the carrier
generated by an element, `Lgen ψ = {x ⋆ ψ}`, is classified: its real dimension is `4` or
`8` and nothing else. Proper nonzero left carriers exist, every one of them is minimal of
real dimension exactly four, and a nonzero `ψ` generates a minimal carrier precisely when
the inherited central quadratic datum vanishes on it — equivalently, when `ψ` is a zero
divisor. Idempotency of a generator is derived as a normal form, not assumed. There are
infinitely many *distinct* minimal carriers, all of them equivalent under an intrinsic
equivalence given by invertible right transformations, so the inherited data yields a
FAMILY OF EQUIVALENT CARRIERS rather than a unique one. Only afterwards are the Task-10
half-angle sectors brought in: they are *not* left carriers (they are right ideals
preserved by the axial lift only), they are reducible under their exact six-dimensional
left stabilizer, and every minimal carrier meets each sector in exactly two dimensions and
is their direct sum. Every minimal carrier is preserved by the Task-10 reference lift and
by every Task-11 full lift, the residual central factor being invisible; the algebra
automorphism family, by contrast, permutes the carriers, fixing the two axial ones and
moving others — the two actions are related by `Φθ(L) = L ⋆ U(−θ)` and never conflated.
The central plane acts automatically, the induced operator of `S` squares to minus the
identity, each minimal carrier has `Z`-rank two, and its internal endomorphism algebra —
the real-linear self-maps commuting with the left action of all of `W` — is exactly the
inherited centre, of real dimension two. Existence, dimensions, minimality, family and
endomorphisms are all AXIS-INDEPENDENT; the distinguished axis contributes only a
selection of two members and the sector decomposition. A separate late module, labelled
COMPARISON ONLY, matches the reconstructed objects with their conventional counterparts;
no spin, particle or state-space claim is made.

**Task 13** — the one-axis transformation classification on an *arbitrary* minimal
carrier. The Task-12 obligation is closed first: the exact left stabilizer of the minus
sector `H₋` is computed (real dimension six, a subalgebra, the two linear coordinate
conditions `x₂ + x₄ = x₃ + x₅ = 0`), it is proved to be the image of the plus stabilizer
under the inherited inner automorphism `x ↦ B ⋆ x ⋆ B` that reverses the axis, and `H₋` is
proved reducible under it. Only then is an arbitrary minimal carrier `L` taken, with its
two axis-relative slices `K₊(L) = L ⊓ H₊` and `K₋(L) = L ⊓ H₋`: each is stable under the
exact centre and equals the plane of central multiples of *any* of its nonzero elements,
with unique coefficients, so the exact central rank is one and no generator is canonically
selected. The reference implementer is imported only afterwards, and its action on the
slices is *derived* from the sector relations `R ψ = ± S ψ`: multiplication by
`cos(θ/2)·1 ∓ sin(θ/2)·S`. The two factors are mutually inverse central units and differ
by the fixed full-angle factor `cos θ·1 − sin θ·S`. The whole Task-11 lift family is kept:
every full lift preserves both slices and acts on them by the same two factors multiplied
by the arbitrary central residual, so the residual freedom is entirely *common* and the
relative sector transformation is rigid — the same for every lift and every carrier. The
restricted infinitesimal generators are `α·1 + (β ∓ 1/2)·S`, their difference is `−S` for
all `(α, β)`, and the Task-10 rate `λ` is proved logically separate from `(α, β)`. Every
Task-12 carrier equivalence matches the slices exactly and intertwines every lift, giving
one UNIVERSAL AXIAL CARRIER TYPE. Finally the family of minimal carriers is parameterized
exactly — every minimal carrier is generated by a unique point of an explicit unit
two-sphere, proved by an intrinsic construction — and the automorphism family is shown to
fix exactly two of them, the axial ones: AXIAL DATA SELECT A FINITE FAMILY, with
NO NORMALIZATION DERIVED from carrier structure. A separate late module, labelled
COMPARISON ONLY, records the exact algebraic correspondence with the standard axial
action; NOT PHYSICAL SPIN.

**Task 14** — multi-axis compatibility on the minimal carrier. A *second* spatial axis is
reconstructed independently of the first: its old-space decomposition
`Rest = LongB ⊕ TransB` (dimensions `1 + 2`), its one-parameter old transformation with
both orientation branches audited, its unique unital multiplicative extension `ΦB` with
the complete derived basis table, and its internal implementation — the smallest
product-closed subspace forced by the unrestricted implementation problem is `span{1, Q}`,
the relation `Q ⋆ Q = −1` and the half-parameter constraint are *derived*, and the whole
Task-11 exact-centre theorem gives the relative freedom. Its carrier slices are `2 + 2`,
each one line over the exact centre, with reduced factors `cos(φ/2)·1 ∓ sin(φ/2)·S` and
relative factor `cos φ·1 − sin φ·S`; only afterwards is this compared with the first axis,
where the coincidence is derived, not conventional. The two decompositions of one carrier
are transverse (all four mixed slice intersections vanish), the mixed projector algebra is
classified (idempotents, kernels, ranges, the derived sandwich coefficient `1/2`,
invertibility between central lines), the mixed automorphisms commute exactly when
`(sin θ = sin φ = 0) ∨ cos θ = 1 ∨ cos φ = 1`, and the mixed internal products differ by
`−2 sin(θ/2) sin(φ/2)·P`. The derived generators satisfy `[GA,GB] = GC`, `[GB,GC] = GA`,
`[GC,GA] = GB` with `GC` noncentral, so a third direction is forced and identified
intrinsically as the one attached to the inherited third old spatial direction, with sign
and normalization stated. The minimal product-closed implementer algebra is exactly
`span{1,P,Q,R}`: dimension four, closed, minimal, with centre `ℝ·1` inside itself and
`S` outside. An intrinsic axis-to-generator map `J` is derived from the three basis-axis
cases, proved linear, with `J(n)² = −h(n,n)·1`, symmetric part `−2h(n,m)·1` and
antisymmetric part `−2J(n×m)` — the bilinear operation `×` being defined only after the
relation was derived — and only then identified as `J(n) = S ⋆ n`. Arbitrary unit axes
follow: `2 + 2` carrier splitting for every unit axis and every minimal carrier, the same
central factors, one **UNIVERSAL ALL-AXIS RELATIVE LAW**, and closure of the reference
implementations (every unit element of the implementer algebra *is* a reference
implementation). Words are then studied: two implementations of the same automorphism
always differ centrally; for reference words the defect set is exactly `{+1, −1}` and both
values occur; with arbitrary per-axis central lifts it becomes the whole group of
invertible central elements, invisible to the relative sector law but visible absolutely.
No exactly multiplicative assignment of implementers to automorphisms exists — two
orthogonal half-parameter automorphisms commute while *all* their implementers
anticommute — and an explicit closed mixed path returns to the identity automorphism with
internal residual `−1`: **PATH DEPENDENT**, with the three notions of closure kept apart.
Every mixed word is intertwined by every Task-12 carrier equivalence, giving one
**UNIVERSAL MULTI-AXIS CARRIER TYPE**. The induced action on the Task-13 carrier-family
sphere is derived, not assumed; the globally fixed carriers of a unit axis are exactly the
two sphere points `±n`, and for nonparallel axes there is **NO COMMON FIXED CARRIER** — a
second axis selects none. Finally the rate, isotropy and orientation freedoms are
separated: axis-local rates are free, a linear axis-generator assignment forces one common
rate, and one global orientation choice controls all axis signs. A separate late module,
labelled COMPARISON ONLY, records the correspondence with the conventional structures;
NOT PHYSICAL SPIN.

**Task 15** asks whether continuity, differentiability and mixed-axis composition constrain
the central freedom left open by Task 14. For every unit direction the internal
implementations of the inherited automorphism family are classified: each factors uniquely
as a central residual times the inherited reference implementer, and continuity forces the
residual to be `exp(α θ)[cos(β θ) 1 + sin(β θ) S]` — the exponential form is *derived*, and
differentiability adds nothing, since every continuous lift is already differentiable. The
finite central composition law `U(g) U(h) = c(g,h) U(g∘h)` is derived with `c` an invertible
central element, together with the single identity forced by associativity, the two
normalizations, the redefinition law, and an exact split of `c` into the accumulated
residual and the inherited `±1` reference-word defect. Differentiating only afterwards, the
generator is `α(n) 1 + β(n) S − (1/2) J n`. Mixed-axis coherence then imposes **no** relation
between directions: every pair of real functions `α, β` of the direction is realized, and
two directions may carry unrelated pairs — the surviving data are exactly one pair of real
numbers per direction, with no free function of the path parameter. The spatial rate and the
central rates are proved logically independent: the generator determines the three numbers
separately. Only the strictly stronger requirement that the lift be a function of the
*transformation* forces relations, and these give `α ≡ 0`, `β(n) ∈ ℤ + 1/2` and `β(-n) =
-β(n)`. Verdict: **DIRECTION-DEPENDENT CENTRAL STATE DATA SURVIVE**; the missing datum is
exactly one `ℝ²`-valued choice per direction. A separate late module, labelled COMPARISON
ONLY, compares only the dependency counts with the earlier underdetermination.

**Task 16** closes the gap left by Task 15, which imposed regularity only in the parameter
for each fixed direction. First the exact coincidence relation is classified: two
axis–parameter pairs represent the same inherited visible automorphism **exactly** when
their reference implementations agree up to a sign, with the parameter period `2π`, the
reversal `(n, θ) ↦ (-n, -θ)`, the identity parameters `2πk` and the finite-angle degeneracy
all derived from that one theorem. A strictly stronger *jointly regular* family is then
defined — continuity in the direction and the parameter together — and joint continuity is
proved to force **both** recovered rates to be continuous functions of the direction, with
an exact converse; so jointly regular families are exactly the exponential–rotation
multiples of the reference implementations with continuous rates. Combining this with the
inherited necessary central-rate restrictions closes the global problem in the negative:
**no global jointly regular transformation-valued family exists**, the obstruction being
discrete (a continuous half-odd rate cannot be odd under reversal along an intrinsic path
of directions). The strongest surviving requirement — equality up to a central sign — is
satisfied by *exactly one* family, the inherited reference family, and its composition
defect on closed visible relations is exactly `±1`, while without that normalization the
defect is not discrete at all. Finally the minimal repair is determined: on any proper
domain of directions (those with positive inherited form against a fixed direction) exact
closure is restored, such domains cover every direction, the admissible local choices are
indexed by the integers, and two local choices differ by a central unit that is independent
of the direction, uniquely determined, and composes along finite chains. Status:
**GLOBAL REGULAR REPRESENTATIVE OBSTRUCTED; MINIMAL LOCAL REPAIR CLASSIFIED.** Two separate
late modules, labelled COMPARISON ONLY, record the Option-C dependency comparison and the
conventional reading; nothing depends on them.

**Task 17** hardens the local half of the Task-16 result, importing only the strongest
Task-16 reconstruction layer. The inherited domains are analysed intrinsically: `Dom v` is
nonempty exactly for `v ≠ 0`, contains the normalized direction of `v` exactly then, is
invariant under positive rescaling of `v`, is open in the inherited unit-direction
subspace, contains no antipodal pair, and is path-connected through an explicit
renormalized straight-line path that is proved to stay unit-normalized and strictly inside
the domain; connectedness is derived from that path and from nothing else. On such a
domain the recovered half-odd rate is then proved **constant**, so an exact jointly regular
family carries a single integer label — unique — and is *equal* to the explicit model
`locFam k` at every direction of the domain and every real parameter, with the converse
proved independently: a genuine necessity-and-sufficiency classification. The exact-local
problem is then posed on an arbitrary set of directions, and solved: admissibility is
equivalent to the existence of one continuous rate function that is half-odd on the set and
odd on the antipodal pairs it contains. Consequently an antipodal pair is **not** an
obstruction (an explicit two-point domain carries the labels `1/2` and `-1/2` at once, so
the label is not constant without connectedness), absence of antipodal pairs **is**
sufficient, and two claims suggested by the Task-16 prose are refuted: an explicit
admissible, open, path-connected three-leg domain is contained in **no** `Dom v`, and no
`Dom v` is maximal among admissible domains. Overlap data are then derived rather than
imported: for two arbitrary local representatives the relative factor is central, uniquely
determined, equal to the inherited one-parameter central element of an **integer** (the
difference of the labels), multiplicative in the parameter, direction-independent on
preconnected overlaps, and composing along arbitrary **finite** chains — no infinite
product is defined anywhere. Reconstruction from local data is refuted: a covering system
whose transition factors are *all* the unit still reconstructs no global sign-relaxed
family (uniqueness of a reconstruction, by contrast, always holds), and the missing datum
is identified exactly — no rate function is at once continuous, half-odd everywhere and odd
under reversal. Finally a joint `C¹` notion is introduced only after the continuous
classification and proved to restrict neither labels, nor domains, nor overlap factors.
Status: **LOCAL PROBLEM CLOSED; GLOBAL RECONSTRUCTION REFUTED; ADMISSIBLE-DOMAIN CLASS
CHARACTERIZED AND SHOWN NOT TO BE THE TASK-16 CLASS.** One late module, labelled
COMPARISON ONLY, records the conventional reading; nothing depends on it.

**Task 18** asks what the Task-17 local-to-global mismatch actually is, importing only the
last Task-17 reconstruction layer (the Task-17 comparison module is imported by no Task-18
module). Package A closes the connected-domain result as a genuine equivalence: for a
*preconnected* set of unit directions, admissibility is equivalent to antipodal-freeness,
with the two implications proved independently, the empty domain handled explicitly (no
nonemptiness hypothesis is needed), the connected and path-connected statements derived
afterwards as corollaries, and explicit separations showing the five point-set notions are
not interchangeable. Package B fixes the class before using the word *maximal*: two
explicit maximal preconnected admissible domains are constructed without any maximality
principle, `Dom v` is proved maximal among **open preconnected** admissible sets and
refuted to be maximal among open admissible sets (an explicit larger open admissible
domain with an explicit rate function), the structural obstruction to enlargement is
identified as antipodal completeness inside the antipodal-free class, every `Dom v` is
shown to have two incomparable connected admissible extensions, and the selection of one
maximal extension is proved non-canonical. Package C separates two reconstruction problems
at theorem level: the Task-17 system has an *unrestricted literal* global extension, and
independently has **no** literal sign-relaxed reconstruction. Package D derives the bridge
intrinsically as `Bridge U n θ := ovl U refFam n θ`, with no model formula assumed: it is
central, unique under the inherited normalization, satisfies the exact factorization
`U n θ = Bridge U n θ ⋆ refFam n θ`, has rate recovered from the already reconstructed
central-rate functions, is forced to be half-odd by exactness at a single point, is
direction-independent on a preconnected exact domain, and the earlier integer transition
theorem is *recovered* from the factorization as the difference of two bridges. Package E
defines bridge-normalization keeping the removed factor as data, and proves every
bridge-normalized local exact representative equals the one global sign-relaxed reference,
hence existence **and** uniqueness of the bridge-normalized reconstruction of an arbitrary
covering local system; the three failure modes (literal gluing, sign-relaxed literal
reconstruction, failure surviving explicit conversion) are kept distinct as separate
theorems. Package F defines a global bridge and proves the equivalence *global jointly
regular exact representative ↔ one globally admissible bridge to the reference* in both
directions, so the global exact no-go is exactly the nonexistence of a global bridge; its
content is located precisely as the joint incompatibility of continuity, half-oddness and
reversal oddness of one rate function, with **each pair of the three realizable**, so
reversal oddness alone is not the obstruction. Package G separates ordinary domain overlap
from the visible coincidence relation, defines relation coverage intrinsically, and refutes
it for every antipodal-free family; the cross-domain classification is proved from the
exact Task-16 coincidence result to consist of the antipodal class and one degenerate
identity-parameter class, the latter proved harmless. Package H generalizes the antipodal
phenomenon: the half-odd label is constant on each preconnected component, the compatible
assignments are characterized, an explicit admissible domain carrying four different labels
is constructed, and accumulation of distinct labels is refuted (labels are locally
constant). Package I settles the stronger-regularity audit positively for **arbitrary**
domains: continuous admissibility is equivalent to `C¹` admissibility, the `C¹` rate being
constructed, not inferred from the special cases. Status: **CONVERSION RESOLVES THE
MISMATCH; THE RESIDUAL GLOBAL EXACT OBSTRUCTION IS EQUIVALENT TO NONEXISTENCE OF ONE GLOBAL
BRIDGE.** One late module, labelled COMPARISON ONLY, records the conventional reading and
is imported by the top module alone.

All seventeen are carrier-and-transformation audits. No physical ontology is attached to any
object: everything is real vector spaces, quadratic forms, bilinear maps, linear
equivalences and real coefficients.

## Environment

| Item | Value |
| --- | --- |
| Lean toolchain | `leanprover/lean4:v4.28.0` (see `lean-toolchain`) |
| Mathlib | `v4.28.0`, commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (see `lake-manifest.json`) |
| Build target | `RequestProject` library (`lakefile.toml`) |

## Layout

```
RequestProject/NullSectorTask01/Basic.lean        -- 3+1 carrier, Q₄, longitudinal 1+1 carrier, Q₂, ι
RequestProject/NullSectorTask01/SplitComplex.lean -- split-complex product, e₊/e₋, null coordinates, Q₂(P a b) = a b
RequestProject/NullSectorTask01/Strata.lean       -- future-causal quadrant and its four strata
RequestProject/NullSectorTask01/Boost.lean        -- longitudinal boosts, reciprocal scaling, invariant product
RequestProject/NullSectorTask01/Limits.lean       -- boundary families and the two limiting regimes
RequestProject/NullSectorTask01/Task01.lean       -- imports everything, states the principal final theorems

RequestProject/NullSectorTask02/LorentzData.lean      -- polarization L2 of Q₂, its properties, chosen vectors u₀, s₀
RequestProject/NullSectorTask02/CandidateProduct.lean -- unknown bilinear product, unit/multiplicativity predicates
RequestProject/NullSectorTask02/FixedUnit.lean        -- complete classification of products admissible at u₀
RequestProject/NullSectorTask02/Minimality.lean       -- left-unit-only classification and the three minimality tests
RequestProject/NullSectorTask02/GeneralUnit.lean      -- arbitrary unit: existence ⇔ Q₂ e = 1, uniqueness, future units
RequestProject/NullSectorTask02/Canonicality.lean     -- explicit rational symmetry and the equivariance obstruction
RequestProject/NullSectorTask02/Comparison.lean       -- late comparison with Task 01 (only file importing SplitComplex)
RequestProject/NullSectorTask02/Task02.lean           -- principal classification/obstruction theorems, axiom report

RequestProject/NullSectorTask03/Core.lean         -- Lorentz maps, unit orbit and transporters, product covariance, null pair
RequestProject/NullSectorTask03/Task03.lean       -- late comparison with the Task-01 boost and idempotents;
                                                  -- principal theorems, axiom report

RequestProject/NullSectorTask04/Lorentz4.lean       -- polarization L4 of Q4, uniqueness, the chosen unit e₀
RequestProject/NullSectorTask04/RestSpace.lean      -- rest space of e₀, the induced positive form h, coordinates
RequestProject/NullSectorTask04/Sectors.lean        -- unit spatial directions, the 1+1 embeddings, the Task-02 product
RequestProject/NullSectorTask04/GlobalExtension.lean-- unknown bilinear product, sector compatibility, derived global unit
RequestProject/NullSectorTask04/Classification.lean -- forced symmetric branch, alternating defect, exact iff classification
RequestProject/NullSectorTask04/IdentityAudit.lean  -- identity audit and the explicit counterexamples
RequestProject/NullSectorTask04/Isotropy.lean       -- stabilizer of e₀, full-isotropy classification
RequestProject/NullSectorTask04/ProperIsotropy.lean -- orientation determinant, proper-isotropy family, orientation reversal
RequestProject/NullSectorTask04/Overlap.lean        -- sector overlaps versus cross-sector gluing
RequestProject/NullSectorTask04/Identification.lean -- late conventional identification (COMPARISON ONLY)
RequestProject/NullSectorTask04/Task04.lean         -- principal theorems, axiom report

RequestProject/NullSectorTask06/SafeBase.lean       -- clean rest basis r₁ r₂ r₃, orthonormality, expansion
RequestProject/NullSectorTask06/GenericExtension.lean -- re-derived generic extension theorem, defect uniqueness
RequestProject/NullSectorTask06/ProperAction.lean   -- stabilizer of e₀, rest action, orientation determinant
RequestProject/NullSectorTask06/UnknownDefect.lean  -- unknown alternating defect, equivariance, output components
RequestProject/NullSectorTask06/Rigidity.lean       -- clean-room rigidity: basis-pair constraints, upper bound
RequestProject/NullSectorTask06/Existence.lean      -- FIRST explicit nonzero witness (only after rigidity)
RequestProject/NullSectorTask06/ExactClassification.lean -- exact solution space, coordinate formula
RequestProject/NullSectorTask06/OrientationReversal.lean -- orientation reversal, full-isotropy classification
RequestProject/NullSectorTask06/Identification.lean -- late conventional identification (COMPARISON ONLY)
RequestProject/NullSectorTask06/Task04Comparison.lean    -- late Task-04 comparison, replication verdict
RequestProject/NullSectorTask06/AssociativityObstruction.lean -- Phase B: universal associativity obstruction
RequestProject/NullSectorTask06/NormObstruction.lean -- Phase B: universal Q4-multiplicativity obstruction
RequestProject/NullSectorTask06/UniversalObstructionSummary.lean -- Phase B verdicts, minimal configuration
RequestProject/NullSectorTask06/Task06.lean         -- principal theorems, axiom report

RequestProject/NullSectorTask07/SafeBase.lean       -- inherited data, forced square law oldSq, two directions
RequestProject/NullSectorTask07/AmbientExtension.lean -- arbitrary associative unital real extension
RequestProject/NullSectorTask07/Polarization.lean   -- recovery of the inherited symmetric product
RequestProject/NullSectorTask07/TwoDirections.lean  -- derived generator relations A^2=B^2=1, AB+BA=0
RequestProject/NullSectorTask07/MixedProduct.lean   -- first definition of P = A*B, forced relations
RequestProject/NullSectorTask07/NewDirection.lean   -- old-carrier square obstruction, P outside the carrier
RequestProject/NullSectorTask07/ForcedRelations.lean -- relation summary, linear independence of 1,A,B,P
RequestProject/NullSectorTask07/GeneratedClosure.lean -- span, normal form, closure, dimension, table
RequestProject/NullSectorTask07/Minimality.lean     -- minimality among product-closed subspaces
RequestProject/NullSectorTask07/DirectWitness.lean  -- fresh four-dimensional existence witness
RequestProject/NullSectorTask07/Uniqueness.lean     -- uniqueness up to generator-preserving isomorphism
RequestProject/NullSectorTask07/SignAudit.lean      -- generator-order and sign diagnostic
RequestProject/NullSectorTask07/Identification.lean -- late conventional identification (COMPARISON ONLY)
RequestProject/NullSectorTask07/Task07.lean         -- principal theorems, axiom report

RequestProject/NullSectorTask08/SafeBase.lean       -- inherited old-carrier data, third direction dirC
RequestProject/NullSectorTask08/ThirdDirection.lean -- C = iota c, derivation of C*C = 1
RequestProject/NullSectorTask08/InheritedRelations.lean -- polarization => AC = -CA, BC = -CB
RequestProject/NullSectorTask08/NewMixedProducts.lean -- first definitions Q = A*C, R = B*C, S3 = (A*B)*C
RequestProject/NullSectorTask08/ForcedRelations.lean -- complete forced-relation ledger, channel squares
RequestProject/NullSectorTask08/Membership.lean     -- membership in the old carrier and in the Task-07 closure
RequestProject/NullSectorTask08/Independence.lean   -- independence of 1,A,B,C,P,Q,R,S3
RequestProject/NullSectorTask08/GeneratedClosure.lean -- span, coefficient law, closure, dimension, table
RequestProject/NullSectorTask08/Minimality.lean     -- minimality, word reduction, proper inclusion of Task 07
RequestProject/NullSectorTask08/StructuralDiagnostic.lean -- commutation diagnostic for the highest channel
RequestProject/NullSectorTask08/DirectWitness.lean  -- fresh eight-dimensional existence witness
RequestProject/NullSectorTask08/FullVec4Embedding.lean -- full old-carrier embedding, ambient existence
RequestProject/NullSectorTask08/Uniqueness.lean     -- uniqueness up to generator-preserving isomorphism
RequestProject/NullSectorTask08/SignPermutationAudit.lean -- permutation and sign diagnostics
RequestProject/NullSectorTask08/Identification.lean -- late conventional identification (COMPARISON ONLY)
RequestProject/NullSectorTask08/Task08.lean         -- principal theorems, axiom report

RequestProject/NullSectorTask09/SafeBase.lean       -- inherited Task-08 witness, neutral quadratic interface
RequestProject/NullSectorTask09/RealScalarNoGo.lean -- Phase A: forced real values, scalar-codomain obstruction
RequestProject/NullSectorTask09/CentralPlane.lean   -- Z = span{1,S}: closure, commutativity, centrality, dim 2
RequestProject/NullSectorTask09/UnknownQuadraticMap.lean -- Phase B: unknown Z-valued map, polarization covariance
RequestProject/NullSectorTask09/Rigidity.lean       -- forced basis values, full polarization ledger, rigidity
RequestProject/NullSectorTask09/Existence.lean      -- first explicit candidates, quadraticity, multiplicativity
RequestProject/NullSectorTask09/ExactClassification.lean -- exact solution space, image controls, Part-VI verdict
RequestProject/NullSectorTask09/CentralSignAudit.lean -- S |-> -S and the Task-08 generator sign freedom
RequestProject/NullSectorTask09/Identification.lean -- late conventional identification (COMPARISON ONLY)
RequestProject/NullSectorTask09/Task09.lean         -- principal theorems, axiom report

RequestProject/NullSectorTask10/SafeBase.lean           -- import ledger, firewalls, 8-basis extensionality
RequestProject/NullSectorTask10/AxisDecomposition.lean  -- distinguished axis, Long, Trans, Rest = Long ⊕ Trans
RequestProject/NullSectorTask10/OldAxialRotation.lean   -- rot θ, group law, Q4 invariance
RequestProject/NullSectorTask10/AlgebraExtension.lean   -- forced values, uniqueness, explicit Φθ, group law, Φ(2π) = id
RequestProject/NullSectorTask10/VectorChannels.lean     -- longitudinal/transverse sectors, exact Z-channel classification
RequestProject/NullSectorTask10/InternalLift.lean       -- K = span{1,R}, lift classification, half angle derived, scalar freedom
RequestProject/NullSectorTask10/StateAction.lean        -- candidate-state left action, 2π/4π, algebra vs state
RequestProject/NullSectorTask10/HalfAngleSectors.lean   -- Rψ = ±Sψ sectors, dimensions, half-angle factors, §23 verdict
RequestProject/NullSectorTask10/AxialDerivation.lean    -- axial derivations, exact classification, intrinsic commutator formula
RequestProject/NullSectorTask10/DynamicsDiagnostic.lean -- direction fixed, rate free
RequestProject/NullSectorTask10/Identification.lean     -- late conventional comparison (COMPARISON ONLY)
RequestProject/NullSectorTask10/Task10.lean             -- principal theorems, axiom report

RequestProject/NullSectorTask11/SafeBase.lean               -- import ledger, firewalls, central normal form zc a b
RequestProject/NullSectorTask11/CenterRigidity.lean         -- exact center CenterW = Z, centralizers, negative control
RequestProject/NullSectorTask11/FullLift.lean               -- IsFullLift / IsContinuousFullLift, derived inverse laws
RequestProject/NullSectorTask11/RelativeLiftRigidity.lean   -- relative element, centrality, upper residual-freedom theorem
RequestProject/NullSectorTask11/ReferenceExistence.lean     -- FIRST import of the explicit Task-10 lift, as Uref
RequestProject/NullSectorTask11/ExactLiftClassification.lean-- exact algebraic classification; the Task-10 K-slice (§16)
RequestProject/NullSectorTask11/ContinuousClassification.lean -- continuous residual classification, two parameters, §20
RequestProject/NullSectorTask11/PeriodicityAudit.lean       -- general 2π/4π values; algebra vs implementer periodicity
RequestProject/NullSectorTask11/QuadraticCompatibility.lean -- CONDITIONAL N₊/N₋/simultaneous tests, derived normalization
RequestProject/NullSectorTask11/InfinitesimalLift.lean      -- differentiable lifts, exact left generator
RequestProject/NullSectorTask11/GeneratorSeparation.lean    -- induced derivation, invisible component, rate freedom
RequestProject/NullSectorTask11/Identification.lean         -- late conventional comparison (COMPARISON ONLY)
RequestProject/NullSectorTask11/Task11.lean                 -- principal theorems, axiom report

RequestProject/NullSectorTask12/SafeBase.lean               -- import ledger, firewalls, Lmul/Rmul, traces, IsNullElt, HasInverse
RequestProject/NullSectorTask12/LeftCarrier.lean            -- IsLeftCarrier / nonzero / proper / minimal, all intrinsic
RequestProject/NullSectorTask12/GeneratedCarrier.lean       -- Lgen ψ, left stability, derived self-product normal form
RequestProject/NullSectorTask12/DimensionClassification.lean-- exact dimension set {4, 8}
RequestProject/NullSectorTask12/MinimalCarrier.lean         -- minimal ⇔ proper, dimension 4, zero-divisor criterion, trichotomy
RequestProject/NullSectorTask12/CarrierFamily.lean          -- infinite family, CarrierEquiv, central compression
RequestProject/NullSectorTask12/AxisRelation.lean           -- Φ action, sphere of generators, axis-dependence audit
RequestProject/NullSectorTask12/HalfAngleRelation.lean      -- FIRST import of H±: not carriers, reducible, intersections
RequestProject/NullSectorTask12/LiftStability.lean          -- reference-lift and full-lift stability; Φθ(L) = L ⋆ U(−θ)
RequestProject/NullSectorTask12/CentralAction.lean          -- automatic central action, Sop² = -id, Z-rank two
RequestProject/NullSectorTask12/CarrierEndomorphisms.lean   -- exact internal endomorphism algebra ≅ Z, dimension two
RequestProject/NullSectorTask12/Identification.lean         -- late conventional comparison (COMPARISON ONLY)
RequestProject/NullSectorTask12/Task12.lean                 -- principal theorems, axiom report
RequestProject/NullSectorTask14/SafeBase.lean                      -- import ledger, firewalls, spat, exact-centre interface
RequestProject/NullSectorTask14/SecondAxisOldStructure.lean        -- LongB, TransB, Rest = LongB ⊕ TransB, dimensions 1 + 2
RequestProject/NullSectorTask14/SecondAxisAutomorphism.lean        -- rotB, orientation branches, unique extension ΦB, basis table
RequestProject/NullSectorTask14/SecondAxisImplementation.lean      -- unrestricted lift problem, forced plane span{1,Q}, half angle, GB
RequestProject/NullSectorTask14/SecondAxisCarrierSlices.lean       -- B slices, 2 + 2 split, central lines
RequestProject/NullSectorTask14/SecondAxisSectorAction.lean        -- B reduced action, relative factor, comparison with the A axis
RequestProject/NullSectorTask14/TwoAxisSliceComparison.lean        -- all four mixed slice intersections vanish
RequestProject/NullSectorTask14/MixedProjectors.lean               -- e± projectors, mixed compositions, ranks, invertibility
RequestProject/NullSectorTask14/MixedFiniteComposition.lean        -- exact order-dependence classification of ΦA, ΦB
RequestProject/NullSectorTask14/MixedInfinitesimalComposition.lean -- mixed products, commutator, third axis, sign audit
RequestProject/NullSectorTask14/ImplementerClosure.lean            -- minimal product-closed implementer algebra span{1,P,Q,R}
RequestProject/NullSectorTask14/AxisGeneratorMap.lean              -- intrinsic map J, linearity, squares, symmetric/antisymmetric parts
RequestProject/NullSectorTask14/GenericAxis.lean                   -- arbitrary unit axis: Un, ΦGen, carrier split, universal relative law
RequestProject/NullSectorTask14/GenericTwoAxisComposition.lean     -- generic mixed products, quadratic datum, closure theorem
RequestProject/NullSectorTask14/ReferenceWordDefect.lean           -- words, central defect theorem, exact reference defect set {±1}
RequestProject/NullSectorTask14/FullLiftDefect.lean                -- full per-axis central lift freedom and its exact defect set
RequestProject/NullSectorTask14/CoherenceAudit.lean                -- coherence obstruction, closed path, path dependence, three closures
RequestProject/NullSectorTask14/CarrierIntertwiners.lean           -- mixed words on arbitrary minimal carriers, universal multi-axis type
RequestProject/NullSectorTask14/CarrierFamilyAction.lean           -- derived action on the carrier-family sphere coordinates
RequestProject/NullSectorTask14/CommonFixedLocus.lean              -- exact fixed locus, no common fixed carrier, selection verdict
RequestProject/NullSectorTask14/SelectionAudit.lean                -- rate, isotropy and orientation audits
RequestProject/NullSectorTask14/Identification.lean                -- late conventional comparison (COMPARISON ONLY)
RequestProject/NullSectorTask14/Task14.lean                        -- principal theorems, axiom report

RequestProject/NullSectorTask15/SafeBase.lean                      -- import ledger, firewalls, central units, cancellation
RequestProject/NullSectorTask15/RegularLift.lean                   -- axis lifts, unique central factorization, continuous classification
RequestProject/NullSectorTask15/DifferentiableLift.lean            -- the stronger regularity layer: differentiability is automatic
RequestProject/NullSectorTask15/MixedComposition.lean              -- central discrepancy c(g,h), associativity identity, redefinition, word split
RequestProject/NullSectorTask15/Infinitesimal.lean                 -- exact generator, central residual C(n) = α(n)1 + β(n)S, freedom classification
RequestProject/NullSectorTask15/RateSeparation.lean                -- spatial rate versus central rates: exact independence
RequestProject/NullSectorTask15/ResidualAudit.lean                 -- what remains free, missing-datum class, final verdict
RequestProject/NullSectorTask15/OptionCAudit.lean                  -- late structural comparison (COMPARISON ONLY)
RequestProject/NullSectorTask15/Task15.lean                        -- principal theorems, axiom report

RequestProject/NullSectorTask16/SafeBase.lean                      -- import ledger, firewalls, reference coordinates, unit-direction facts
RequestProject/NullSectorTask16/ExactCoincidences.lean             -- exact coincidence relation and all its exceptional cases
RequestProject/NullSectorTask16/JointRegularity.lean               -- joint (n,θ) regularity, continuity of both recovered rates, exact classification
RequestProject/NullSectorTask16/TransformationValuedClosure.lean   -- the global no-go for exact transformation-valuedness
RequestProject/NullSectorTask16/RegularDefect.lean                 -- the surviving sign-relaxed class and the exact ±1 defect
RequestProject/NullSectorTask16/LocalRepair.lean                   -- proper domains, local existence and necessity, overlap and chain data
RequestProject/NullSectorTask16/RateAudit.lean                     -- final rate audit and the negative controls
RequestProject/NullSectorTask16/OptionCAudit.lean                  -- Option-C dependency comparison (COMPARISON ONLY)
RequestProject/NullSectorTask16/Identification.lean                -- late conventional comparison (COMPARISON ONLY, last)
RequestProject/NullSectorTask16/Task16.lean                        -- principal theorems, verdict table, axiom report

RequestProject/NullSectorTask17/SafeBase.lean                      -- import ledger, firewalls, normalization, paths, ℤ+1/2 rigidity
RequestProject/NullSectorTask17/DomainGeometry.lean                -- Package A: intrinsic geometry of the inherited domains
RequestProject/NullSectorTask17/RateRigidity.lean                  -- Package B: pointwise rates and domainwise constancy
RequestProject/NullSectorTask17/LocalExhaustion.lean               -- Package C: complete local-family classification
RequestProject/NullSectorTask17/AdmissibleDomains.lean             -- Package D: admissible domains, criterion and counterexamples
RequestProject/NullSectorTask17/OverlapTransitions.lean            -- Package E: derived overlap factors and finite chains
RequestProject/NullSectorTask17/Reconstruction.lean                -- Package F: reconstruction refuted, missing datum identified
RequestProject/NullSectorTask17/RegularityAudit.lean               -- Package G: the joint C¹ audit
RequestProject/NullSectorTask17/Identification.lean                -- late conventional comparison (COMPARISON ONLY, last)
RequestProject/NullSectorTask17/Task17.lean                        -- principal theorems, status table, axiom report

RequestProject/NullSectorTask18/SafeBase.lean                      -- single inherited import, firewall ledger, shared notation
RequestProject/NullSectorTask18/ConnectedAdmissibility.lean        -- Package A: preconnected admissibility equivalence
RequestProject/NullSectorTask18/MaximalDomains.lean                -- Package B: maximal connected admissible domains
RequestProject/NullSectorTask18/ReconstructionPredicates.lean      -- Package C: the two separated reconstruction problems
RequestProject/NullSectorTask18/BridgeFactors.lean                 -- Package D: intrinsic local-to-reference bridge
RequestProject/NullSectorTask18/BridgeReconstruction.lean          -- Package E: bridge-normalized reconstruction
RequestProject/NullSectorTask18/GlobalBridgeObstruction.lean       -- Package F: global bridge and the exact no-go
RequestProject/NullSectorTask18/RelationCoverage.lean              -- Package G: overlaps versus visible coincidence relations
RequestProject/NullSectorTask18/DisconnectedDomains.lean           -- Package H: components and half-odd labels
RequestProject/NullSectorTask18/RegularityAudit.lean               -- Package I: arbitrary-domain continuous versus C¹
RequestProject/NullSectorTask18/NegativeControls.lean              -- negative controls
RequestProject/NullSectorTask18/Identification.lean                -- late conventional comparison (COMPARISON ONLY, last)
RequestProject/NullSectorTask18/Task18.lean                        -- principal theorems, status table, axiom report
```

Task 03 keeps its core in a single module: every module of this project imports the
whole of Mathlib, which dominates compilation time, so a short dependency chain is much
cheaper to build.  The four layers intended by the task (Lorentz maps, unit orbit,
product covariance, null pair) are the four sections of `Core.lean`.

Task 02 respects a strict import firewall: its core files import only
`RequestProject.NullSectorTask01.Basic`; the Task-01 split-complex layer enters solely
in `Comparison.lean`. See §2 of `TASK02_AUDIT.md` for the mechanical audit.

Task 03 respects the same discipline: `Core.lean` imports only
`RequestProject.NullSectorTask02.GeneralUnit`, and the Task-01 boost/split-complex
declarations are imported exclusively by `RequestProject/NullSectorTask03/Task03.lean`,
which is compiled only after the whole core has compiled.  The late comparison layer and
the principal theorems share that one module because every module of this project
imports the whole of Mathlib, which dominates compilation time.
See §2 and §20 of `TASK03_AUDIT.md`.

Task 04 follows the same discipline: its nine core files import only
`RequestProject.NullSectorTask01.Basic` (carrier and quadratic forms) and
`RequestProject.NullSectorTask02.FixedUnit` (the reconstructed longitudinal product).
The Task-01 split-complex layer and Mathlib's cross product enter only in
`Identification.lean`, which is a comparison layer used by no core result.
See §3 and §24 of `TASK04_AUDIT.md`.

Task 06 enforces a stricter, machine-audited firewall. Its clean-room modules import
only the uncontaminated Task-04 base layer (`GlobalExtension.lean` and its own
dependencies) and re-derive the generic extension theorem; none of the Task-04 modules
containing an explicit nonzero alternating witness is imported before the reconstruction
is complete. No explicit nonzero alternating rest-space map occurs anywhere before the
rigidity theorem — the first one is `wit3` in `Existence.lean`. Mathlib's cross product
and the Task-04 orientation modules enter only in `Identification.lean` and
`Task04Comparison.lean`. The Phase-B modules depend only on `SafeBase.lean` and
`GenericExtension.lean` and assume no symmetry whatsoever. See §§3–8 of
`TASK06_AUDIT.md` for the mechanical firewall, source-order and structural-witness
reports.

Task 07 opens exactly one assumption of Task 06 — that products of embedded vectors
must remain inside the original `3+1` carrier — and keeps everything else, in
particular the forced diagonal square law. In an arbitrary real associative unital
ambient extension with an injective embedding of the original carrier, the inherited
symmetric product is recovered by polarization; the two selected orthogonal spatial
directions are shown to square to the unit and anticommute; their mixed product
`P = A ⋆ B` is proved nonzero, to satisfy `P ⋆ P = −1`, and to lie outside the embedded
original carrier; `1, A, B, P` are independent, their span is multiplicatively closed,
has dimension exactly four, and is minimal among product-closed subspaces containing the
two generators. Only afterwards is a fresh four-dimensional witness constructed from the
derived table and proved associative, uniqueness up to a generator-preserving isomorphism
established, and — in a separate late module labelled COMPARISON ONLY — the resulting
algebra conventionally identified. The twelve reconstruction modules contain no
occurrence of any conventional target-structure name (mechanical scan, §5 of
`TASK07_AUDIT.md`); the identification module is imported only by `Task07.lean`.

Task 08 adds exactly one further inherited orthogonal spatial direction `c` to the
Task-07 two-generator system, and nothing else. From the inherited square law alone it
derives `C ⋆ C = 1`, and from polarization together with the inherited orthogonality
relations it derives the pairwise anticommutation of `A, B, C`. Only afterwards are the
mixed products `Q = A ⋆ C`, `R = B ⋆ C` and `S₃ = (A ⋆ B) ⋆ C` defined, all their
relations and squares derived, and their membership classified: `Q, R, S₃` lie outside
the embedded original carrier and, together with `C`, outside the Task-07 closure. The
eight elements `1, A, B, C, P, Q, R, S₃` are linearly independent in every ambient
extension, their span is multiplicatively closed, has dimension exactly eight, and is
minimal among product-closed subspaces containing the three inherited generators. A
fresh eight-dimensional witness is then built from the derived table and proved
associative; the *complete* original `3+1` carrier embeds into it injectively, the
inherited square law holds for every embedded old vector, and polarization recovers the
full inherited symmetric product — which resolves the ambient-existence obligation left
open by Task 07. Uniqueness up to a generator-preserving isomorphism, a sign and
permutation audit, and — in a separate late module labelled COMPARISON ONLY — the
conventional identification follow. The fourteen reconstruction modules contain no
occurrence of any conventional target-structure name (mechanical scan, §5 of
`TASK08_AUDIT.md`); the identification module is imported only by `Task08.lean`, and no
Task-08 module imports Task-07's identification layer or any Task-05 module.

Task 09 changes nothing about the product: the carrier, the unit, the eight derived basis
elements and the multiplication are literally the Task-08 witness, and no generator is
added. Only the codomain of the quadratic map moves. An unknown real-valued map that is
quadratic, multiplicative and restricts to the inherited Lorentz form on the embedded old
carrier is shown to be impossible, by a small explicit configuration using only
degree-two homogeneity, multiplicativity and three inherited values, tested on a single
two-term element. The two-plane spanned by the unit and the derived central element is
then constructed inside the fixed carrier and proved closed, commutative, central and of
exact dimension two. Only afterwards is an entirely unknown map into that plane
introduced: all eight of its basis values and its complete polarization ledger are forced,
leaving exactly one undetermined entry, which is proved to square to `-4` times the unit
and hence to be one of two values. The first explicit candidate appears only after that
rigidity theorem; quadraticity, multiplicativity for arbitrary pairs of carrier elements,
and the inherited-form restriction for arbitrary old vectors are then proved directly in
the reconstructed coordinates. The solution space has exactly two elements; no admissible
map can stay inside the real line, the extra central direction is attained by every
admissible map, and the sign flip on that direction exchanges the two solutions — the same
exchange induced by the transposition of two derived spatial generators already audited in
Task 08. The eight reconstruction modules contain no conventional target-structure name in
code apart from one disclosed naming artefact (§4 of `TASK09_AUDIT.md`); the
identification module is imported only by `Task09.lean`, and no reconstruction module
imports Task-08's identification layer.

Task 11 enforces the source order demanded of it mechanically: the exact center theorem,
the definition of an arbitrary full-carrier lift and the complete relative-lift rigidity
theorem are all proved in modules that do **not** import the Task-10 module containing the
explicit lift; that module is first imported in `ReferenceExistence.lean`. No unit-norm,
boundedness or periodicity condition is used anywhere in the classification: the only
normalization present is `U 0 = 1`, which is part of the definition of a lift. The
conditional quadratic-preservation tests are confined to `QuadraticCompatibility.lean` and
carry their hypothesis explicitly in every statement. The reconstruction modules contain no
conventional target-structure name in code; `Identification.lean` is labelled
COMPARISON ONLY and is imported only by `Task11.lean`.

Task 12 enforces its source order the same way. The complete carrier classification —
existence, the dimension set, minimality, the generator criterion, the infinite family and
its equivalence — is proved in modules that do **not** import the Task-10 half-angle
sectors or the Task-11 lift; the sectors are first imported in `HalfAngleRelation.lean`
and the lift in `LiftStability.lean`, so minimal carriers are never forced to match a
pre-existing decomposition. The twelve reconstruction modules contain no conventional
representation-target name in code, apart from two disclosed generic-Mathlib naming
artefacts (§4 of `TASK12_AUDIT.md`), and no physical-target name at all. No inner product,
norm, normalization, quotient of states or projective construction occurs anywhere;
`Identification.lean` is labelled COMPARISON ONLY and is imported only by `Task12.lean`.

Task 13 enforces the same discipline. The arbitrary minimal carrier and both slices are
defined, and their central structure classified, in modules that do **not** import the
reference implementer; `Uref` first enters in `ReferenceRestriction.lean` and the full
`(α, β)` family only in `FullLiftRestriction.lean`, so no expected coefficient is fed into
a definition. The two actions `ψ ↦ U θ ⋆ ψ` and `L ↦ Φθ(L)` have separate definitions and
separate theorem names. No `α = 0`, `β = 0`, unit-modulus, boundedness or periodicity
condition is imposed anywhere; no inner product, projective quotient or probability
reading occurs; the thirteen reconstruction modules contain no conventional
representation-target or physical-target name in code, and `Identification.lean` is
labelled COMPARISON ONLY and imported only by `Task13.lean`.

Task 14 enforces the source-order firewall of its own task statement. The second axis is
reconstructed in modules that use only `W`, the inherited old spatial subspace and form,
the associative product, the exact centre and the minimal-carrier structure; no module
obtains a `B`-axis formula by transporting an `A`-axis formula, and the structural
comparison of the two axis systems happens only after both are independently available.
Arbitrary unit axes are introduced only after the independent two-axis result, and their
implementations are built from the derived axis-generator map rather than from a
conventional arbitrary-axis formula. No conventional rotation-, spin-, quaternion- or
Pauli-related name occurs in any reconstruction module; `Identification.lean` is labelled
COMPARISON ONLY and imported only by `Task14.lean`. No inner product, unitarity, norm,
projective identification or probability reading occurs anywhere, and no central defect is
quotiented away: the two-valued reference-word defect and the larger full-lift defect are
both kept explicit.

**Literature calibration.** The final structure — a two-dimensional commutative central
subalgebra of a finite-dimensional real associative algebra, and a quadratic map into it
that is multiplicative and restricts to a given quadratic form — is standard known
mathematics, and the late comparison module identifies the two admissible maps with
conventional operations on the conventionally identified algebra. What is reconstructed
independently here is the *dependency path*, not the mathematical structure; no novelty is
claimed for the structure itself.

## Build

```
lake build
```

or, per task,

```
lake build RequestProject.NullSectorTask01.Task01
lake build RequestProject.NullSectorTask02.Task02
lake build RequestProject.NullSectorTask03.Task03
lake build RequestProject.NullSectorTask04.Task04
lake build RequestProject.NullSectorTask06.Task06
lake build RequestProject.NullSectorTask07.Task07
lake build RequestProject.NullSectorTask08.Task08
lake build RequestProject.NullSectorTask09.Task09
lake build RequestProject.NullSectorTask10.Task10
lake build RequestProject.NullSectorTask11.Task11
lake build RequestProject.NullSectorTask12.Task12
lake build RequestProject.NullSectorTask13.Task13
lake build RequestProject.NullSectorTask14.Task14
lake build RequestProject.NullSectorTask15.Task15
lake build RequestProject.NullSectorTask16.Task16
lake build RequestProject.NullSectorTask17.Task17
lake build RequestProject.NullSectorTask18.Task18
lake build RequestProject.NullSectorTask19.Task19
lake build RequestProject.NullSectorTask20.Task20
lake build RequestProject.NullSectorTask21.Task21
```

No development contains `sorry`, `admit`, or a custom `axiom`. All principal
theorems depend only on `propext`, `Classical.choice`, `Quot.sound`.

## Documentation

* [`TASK23_AUDIT.md`](TASK23_AUDIT.md) — Task 23 audit: exact definitions, theorem inventory,
  dependency graph, cover/section/transition/local-product tables, reconstruction verdict,
  comparison with the old direction domains, bridges and integer labels, reconstruction
  hierarchy, required decision table, unresolved obligations, failbuild ledger, build report
  and axiom report, source ledger.
* [`TASK21_AUDIT.md`](TASK21_AUDIT.md) — Task 21 audit: provenance and source hashes,
  timeout provenance, repair ledger, formal result ledger, decision table, build ledger with
  warning inventory, failbuild history, proof-integrity ledger, source ledger.
* [`TASK01_AUDIT.md`](TASK01_AUDIT.md) — Task 01 audit.
* [`TASK02_AUDIT.md`](TASK02_AUDIT.md) — Task 02 audit: input definitions, import-firewall
  report, theorem inventory, fixed-unit and weakened-assumption classifications,
  assumed-versus-derived table, arbitrary-unit result, future-unit/canonicality result,
  equivariance obstruction, late comparison with Task 01, final dependency graph,
  negative-control table, source ledger, build and axiom reports.
* [`TASK03_AUDIT.md`](TASK03_AUDIT.md) — Task 03 audit: imported Task-02 inputs,
  import-firewall report, Lorentz/future/orientation definitions, `Q2 → L2` preservation,
  unit-orbit classification, transporter existence and uniqueness, stabilizer,
  product covariance, fixed-product invariance versus family covariance, spacelike
  companions, ordered/unordered null pair, transport of the null pair, product-family
  orbit, dependency graph, late comparison with Task 01, negative-control table, source
  ledger, build and axiom reports.
* [`TASK04_AUDIT.md`](TASK04_AUDIT.md) — Task 04 audit: source ledger, toolchain, allowed
  imports, Experiment-1 firewall statement, `Q4 → L4` derivation, rest-space construction,
  longitudinal-sector theorem, sector compatibility, global-unit status, full extension
  classification, explicit nonuniqueness witness, symmetric-part and antisymmetric-defect
  theorems, converse reconstruction, commutative/full-isotropy/proper-isotropy
  classifications, orientation reversal, identity audit, associativity and global
  norm-multiplicativity results, overlap compatibility, Conservation-of-Difficulty graph,
  late conventional identification, import- and terminology-firewall reports,
  negative-control table, build and axiom reports, unresolved obligations.
* [`TASK06_AUDIT.md`](TASK06_AUDIT.md) — Task 06 audit: toolchain, source ledger, allowed
  inherited declarations, rejected Task-04 modules, Experiment-1 / terminology /
  structural-witness / source-order firewall reports, the re-derived generic extension
  theorem, the intrinsic proper-isotropy definition, the unknown-defect setup, basis-pair
  rigidity results, the exact solution-space classification, the first location of an
  explicit nonzero witness, the existence theorem, the coordinate formula derived after
  classification, orientation reversal, full isotropy, late conventional identification,
  the Task-04 comparison and replication verdict, the universal associativity and global
  norm results with their minimal obstruction equations, the joint theorem, the updated
  Conservation-of-Difficulty graph, the diagnostic handoff, negative-control table, build
  and axiom reports, unresolved obligations.
* [`TASK07_AUDIT.md`](TASK07_AUDIT.md) — Task 07 audit: toolchain, source ledger and
  source-order report, inherited Task-06 theorems, Experiment-1 and target-structure
  firewall reports, the ambient-extension definition, the retained square law, the
  polarization theorem, the two-generator relations, the first definition of the mixed
  product and its forced relations, the old-carrier non-membership theorem, linear
  independence, the generated-closure and normal-form theorems, the derived multiplication
  table, the exact dimension, minimality, the direct finite-dimensional witness and its
  associativity proof, the uniqueness result, the generator-order/sign diagnostic, the
  late conventional identification (COMPARISON ONLY), the updated
  Conservation-of-Difficulty graph, the negative-control table, build and axiom reports,
  unresolved obligations.
* [`TASK08_AUDIT.md`](TASK08_AUDIT.md) — Task 08 audit: toolchain, source ledger and
  source-order report, exact Task-07 import ledger, Experiment-1 and target-structure
  firewall reports, the third-direction definition, the derivation of `C ⋆ C = 1` and of
  pairwise anticommutation, the first definitions of the new mixed channels, the complete
  forced-relation ledger, membership results, the linear-independence classification, the
  generated span, the closure theorem and the full multiplication table, the exact
  dimension, minimality and word reduction, the structural diagnostic for the highest
  channel, the direct eight-dimensional witness and its associativity proof, the full
  `Vec4` embedding, square preservation for arbitrary old vectors, recovery of the
  symmetric product, the Task-07 obligation verdict, uniqueness, the sign/permutation
  audit, the late conventional identification (COMPARISON ONLY), the Task-07 versus
  Task-08 structural comparison, the relation to the Task-06 obstruction, the updated
  Conservation-of-Difficulty graph, the negative-control table, build and axiom reports,
  unresolved obligations.
* [`TASK09_AUDIT.md`](TASK09_AUDIT.md) — Task 09 audit: toolchain, source ledger, exact
  Task-08 import ledger, Experiment-1 and target-structure firewall reports (with the one
  disclosed naming artefact), the definition of quadraticity, the real-valued
  negative-control theorem, the minimal scalar obstruction with its exact incompatible
  equations, the construction of the central plane and its closure/commutativity/
  centrality/dimension, the unknown-map setup in both equivalent formulations, the
  inherited basis values, the complete polarization ledger, the rigidity theorem, the exact
  residual freedom, the first explicit candidate location, the direct quadraticity proof,
  the global multiplicativity proof, the full old-form restriction theorem, the exact
  solution-space theorem, the real-line image negative control, the central-component
  witness, the central-sign action and its relation to the Task-08 generator sign freedom,
  the Part-VI obstruction verdict, the updated Conservation-of-Difficulty graph, the late
  conventional identification (COMPARISON ONLY), build and axiom reports, unresolved
  obligations, the eleven-question Conservation-of-Difficulty appendix, the
  negative-control table and the status-vocabulary index.
* [`TASK10_AUDIT.md`](TASK10_AUDIT.md) — Task 10 audit: exact toolchain, exact Task-08/09
  import ledger, Experiment-1 and representation-target firewall reports, the
  distinguished-axis definition, the longitudinal/transverse decomposition, the old axial
  rotation, algebra-extension existence and uniqueness, the complete action on the Task-08
  basis, the longitudinal/transverse channel classification, internal-lift
  existence/classification with the scalar freedom stated as a result, the 2π/4π
  periodicity comparison, the state-action definition, the half-angle-sector
  classification, the transverse-state-orientation verdict, the axial-derivation
  classification, the generator-rate freedom, the Conservation-of-Difficulty graph, the
  late conventional comparison, build and axiom reports, and unresolved obligations.
* [`TASK11_AUDIT.md`](TASK11_AUDIT.md) — Task 11 audit: exact toolchain, source ledger,
  exact Task-09/10 import ledger, Experiment-1, physical-target and conventional-algebra
  firewall reports, the exact center theorem and the exact centralizer theorem with the
  minimal generating subset actually used, the arbitrary-full-lift definition, the
  relative-lift theorem, the first reference-lift import location, the algebraic and the
  continuous lift classifications with the exact residual parameter count, the general
  2π/4π theorem, the N₊, N₋ and simultaneous conditional-compatibility classifications,
  the normalization-status audit, the differentiable-lift theorem, the infinitesimal
  generator decomposition, the comparison with the Task-10 rate freedom, the
  Conservation-of-Difficulty graph, the late conventional comparison, build and axiom
  reports, and unresolved obligations.
* [`TASK12_AUDIT.md`](TASK12_AUDIT.md) — Task 12 audit: exact toolchain, exact
  pre-identification import ledger, Experiment-1, representation-target and
  physical-target firewall reports (with the two disclosed naming artefacts), the neutral
  left-carrier definitions, the generated-carrier construction, the exact possible carrier
  dimensions `{4, 8}`, the minimal-dimension theorem and the left-carrier trichotomy, the
  intrinsic minimal-generator criterion in its three equivalent branch-symmetric forms,
  the complete minimal-carrier classification, the equality-versus-equivalence discussion
  and the `FAMILY OF EQUIVALENT CARRIERS` verdict, the axis-dependence audit, the relation
  to `H₊` and `H₋` (not left carriers, exact stabilizer, reducibility, intersection
  dimensions), reference-lift and full-lift stability, the action of `Φ` on the carrier
  family, the central-plane action and `Z`-rank, the exact internal endomorphism algebra,
  the Conservation-of-Difficulty graph with the eighteen answers, the late conventional
  comparison (COMPARISON ONLY), build and axiom reports, and unresolved obligations.
* [`TASK13_AUDIT.md`](TASK13_AUDIT.md) — Task 13 audit: exact toolchain and Mathlib
  revision, the source-order graph, the inherited theorem ledger, the Experiment-1,
  conventional-representation, physical-target and full-rotation firewall reports, the
  complete `H₋` hardening result, the arbitrary-carrier slice definitions, the central-rank
  classification and the generator-freedom statement, the exact reference-action and
  full-lift-action classifications, the common-versus-relative freedom analysis with the
  rigidity of the relative factor, the infinitesimal classification and the `λ` separation,
  the carrier-equivalence/intertwiner classification and the universal-carrier-type
  verdict, the `Φ`-carrier-family action, the exact global fixed-locus theorem with its
  two-sphere parametrization, the carrier-selection verdict, the normalization negative
  control, the Conservation-of-Difficulty graph with the twenty-five answers, the late
  conventional comparison, the Experiment-1 comparison, build and axiom reports, and seven
  unresolved obligations.
* [`TASK14_AUDIT.md`](TASK14_AUDIT.md) — Task 14 audit: exact toolchain and Mathlib
  revision, the complete inherited theorem ledger, the full-rotation and physical firewall
  reports, the source-order graph, the independent second-axis reconstruction report, the
  orientation/sign audit, the second-axis carrier result, the two-axis slice comparison,
  the mixed-projector algebra, the finite-composition report, the infinitesimal-closure
  report, the minimal implementer-algebra classification, the generic axis-generator
  theorem, the arbitrary-axis carrier theorem, the reference word-defect classification,
  the full-lift residual-freedom classification, the coherent-lift obstruction, the
  path-independence audit, the multi-axis carrier-equivalence report, the carrier-family
  mixed-action report, the common fixed-locus theorem, the selection verdict, the
  Conservation-of-Difficulty graph with the thirty answers, the late conventional
  comparison (COMPARISON ONLY), build and axiom reports, and six unresolved obligations.
* [`TASK15_AUDIT.md`](TASK15_AUDIT.md) — Task 15 audit: exact toolchain and Mathlib
  revision, inherited ledger, firewall report, source-order graph, exact definitions,
  theorem inventory for §III–§VIII, the answers to the §V alternatives A–F, the
  spatial-rate/central-rate independence report, the table of what remains free, the §IX
  verdict with the exact class of the still missing datum, the late structural comparison,
  four unresolved obligations, source ledger, build and axiom reports.
* [`TASK16_AUDIT.md`](TASK16_AUDIT.md) — Task 16 audit: exact toolchain, Mathlib revision
  and the exact list of Mathlib declarations used, the inherited ledger, the three firewall
  reports with the mechanical-scan result, the source-order graph, the exact definitions,
  the full theorem inventory for Work Packages 1–6, the structure of the global
  obstruction, the exact surviving class of central defect values, the minimal-repair
  report with the overlap and chain statements, the rate table, the eight negative
  controls, the final verdict table with the Task-16 status, five honestly stated
  unresolved obligations, the source ledger separating imported standard results from
  results derived in Task 16, the late heuristic note (used in no proof), and the build and
  axiom reports.
* [`TASK17_AUDIT.md`](TASK17_AUDIT.md) — Task 17 audit: exact toolchain, Mathlib revision
  and the list of Mathlib declarations used, the reconstruction-firewall report, the
  source order with declaration counts, the exact definitions, the full theorem inventory
  for Packages A–G, the intrinsic domain geometry, the domainwise constancy result, the
  local-family classification, the admissible-domain criterion with its two refutations
  (antipodal pairs are not an obstruction; an explicit admissible open connected domain
  lies in no `Dom v`) and the non-maximality result, the derived overlap classification
  with the finite-chain law, the refutation of reconstruction from local data with the
  exactly identified missing datum, the `C¹` audit, the final status table with every entry
  classified `PROVED` / `REFUTED` / `CONDITIONAL` / `OPEN`, the explicit corrections to
  Task-16 documentation, six unresolved obligations, the source ledger, the failed attempts
  that changed the construction, and the build and axiom reports.
* [`TASK18_AUDIT.md`](TASK18_AUDIT.md) — Task 18 audit: exact toolchain, Mathlib revision
  and the list of Mathlib declarations used, the reconstruction-firewall report with the
  mechanical vocabulary scan, the exact definitions introduced, the full theorem inventory
  for Packages A–J, the source order with declaration counts, the final status table with
  every entry labelled `PROVED` / `REFUTED` / `CONDITIONAL` / `PARTIAL` / `OPEN`, the
  required Task-XVIII verdict, the mathematically significant failed attempts and the
  counterexamples that changed the intended classification, the unresolved obligations, the
  source ledger separating imported standard results from results derived in Task 18, and
  the build, warning, prohibited-construct and axiom reports.
* [`TASK19_AUDIT.md`](TASK19_AUDIT.md) — Task 19 audit: exact toolchain and Mathlib
  revision, the reconstruction-firewall report with its mechanical scan, the exact
  definitions introduced, the full theorem inventory for Packages A–J, the source order and
  dependency graph with the extra assumptions attached to individual arrows, the final
  status table with every entry labelled `PROVED` / `REFUTED` / `CONDITIONAL` / `PARTIAL` /
  `OPEN`, the required Task-XIX verdict with its seven separate answers, the failed attempts
  and the counterexamples that changed the intended theorem boundaries, five unresolved
  obligations, the source ledger separating imported standard results from results derived
  in Task 19, and the build, warning, prohibited-construct and axiom reports.

## Task 19 — Intrinsic Global-Obstruction Decomposition

`RequestProject/NullSectorTask19/` separates and hardens the branches left open by Task 18.
Source order:

```
SafeBase → PrimitiveBridge → MinimalObstruction → MaximalPreconnected → PlainMaximality
→ DisconnectedExtension → RelationCompletion → RelationBridge → HigherRegularity
→ NegativeControls → Identification (COMPARISON ONLY) → Task19
```

The principal results:

* a **primitive bridge** notion defined by centrality, normalization, one-parameter
  multiplicativity and joint continuity only — exactness does not occur in the definition —
  with its exact normal form and the uniqueness of its two rates;
* two proved equivalences: a primitive bridge with globally exact reconstruction exists iff
  a continuous, half-odd, reversal-odd global rate exists, and iff a globally exact jointly
  regular family exists;
* the three-condition obstruction is an **exact minimal unsatisfiable set**;
* an exact criterion for maximal admissible direction sets, an explicit maximal one, and a
  refutation of uniqueness; a refutation of chain-union admissibility; and, for the
  preconnected class, a proved necessary condition with the converse conditional on one
  named hypothesis, together with a maximal open preconnected domain that is not an
  inherited domain;
* a necessary-and-sufficient closure extension criterion for prescribed labels on a
  disconnected domain, and a counterexample refuting the sufficiency of separation;
* the classification of visible relations into three classes, of which two are automatic and
  only the antipodal one is not, and the resulting equivalence between complete
  visible-relation compatibility and existence of a primitive global bridge;
* continuous admissibility equals `Cᵏ` admissibility for every finite `k` and `C∞`
  admissibility, for arbitrary domains, with analyticity audited separately and left open.

`Task19.lean` exposes all principal endpoints and runs `#print axioms` on each; every one
depends only on `propext`, `Classical.choice` and `Quot.sound`.

## Task 20 — Intrinsic Equivalence and Structure Audit

`RequestProject/NullSectorTask20/` stops extending the reconstruction and asks what has
actually been reconstructed. Source order:

```
SafeBase → LiftCarrier → InternalProjection → VisibleQuotient → BridgeTorsor
→ ReversalQuotient → GlobalObstruction → SectionObstruction → NegativeControls
→ Identification (COMPARISON ONLY) → Task20
```

Phase A (intrinsic, no external target named anywhere):

* the **visible quotient**: equality of visible transformations is proved to be an
  equivalence, the quotient is built, the visible map factors through it uniquely, the
  induced map onto the visible image is a bijection, and — using compactness of the
  direction carrier and a bounded-parameter representation — a **homeomorphism**; the visible
  image is closed under composition and inversion, so full closure holds;
* the **internal carriers**: the core carrier, described intrinsically by the normal form
  `a·1 − J v` with `a² + ⟨v,v⟩ = 1`, is proved to be exactly the set of reference
  implementers and to be closed under product and inverse; adjoining the invertible central
  elements gives the full carrier, also closed;
* the **kernel/centre audit**: the kernel of the projection is exactly `{1, −1}` over the
  core carrier and exactly the centre over the full carrier, and the two are proved
  different — the smaller kernel is discrete while the larger one contains a continuous
  injective one-parameter family. No central factor is discarded;
* the **relative factor**: two internal lifts of the same visible datum differ by exactly one
  invertible central element (a sign, in the core carrier) — proved with no continuity and no
  exactness;
* the **label structure**: the allowed local exact rates form a free transitive `ℤ`-object
  with no distinguished origin, whose differences are exactly `ℤ`; reduction modulo a proper
  subgroup is proved to lose information, with an explicit witness;
* the **reversal quotient**: antipodal-freeness and antipodal completeness are exactly "at
  most one" and "at least one" direction per fibre, maximal admissible domains are exactly
  the dense selectors, and two maximal selectors are distinguished by the fibres where they
  choose differently;
* the **minimal obstruction**: a continuous reversal-odd rate has a zero, so no such rate can
  avoid zero — the half-odd discreteness is proved *inessential*, the obstruction already
  holding for strictly positive rates;
* the sharpest new statement: a quotient-compatible internal choice **exists**, and **no**
  quotient-compatible internal choice is **continuous**.

Phase B (comparison only, isolated in one module): the internal core carrier is identified
**exactly** with the unit quaternions by an explicit injective, unital, multiplicative map
whose image is computed. No rotation group, covering space, bundle, cocycle or cohomology
class is constructed or claimed anywhere; the equivalence matrix in `TASK20_AUDIT.md` records
each remaining comparison as `PARTIAL`, `ANALOGOUS ONLY`, `NO MATCH FOUND` or `OPEN`.

`Task20.lean` exposes all principal endpoints and runs `#print axioms` on each; every one
depends only on `propext`, `Classical.choice` and `Quot.sound`. `TASK20_AUDIT.md` contains
the frozen intrinsic signature, the package-by-package results, the equivalence matrix, the
internal fusion graph, the provenance table, the fifteen required answers, the unresolved
obligations, the failed attempts and the source ledger.

## Task 21 — Standard-model identification of the intrinsic carriers (completed and certified in Task 22)

`RequestProject/NullSectorTask21/` compares the intrinsic objects reconstructed in Tasks 1–20
with standard named algebraic objects. Source order:

```
SafeBase → GroupPackaging → CoreQuaternionEquiv → SU2Model → VisibleRotationCandidate
→ CoreProjection → SectionObstruction → CentralComplex → CentralProduct
→ NormalizedCentralCarrier → SignStructures → TorsorPlacement → NegativeControls
→ Task21 → Task22
```

`SafeBase` and `GroupPackaging` are the two reconstruction modules — no conventional named
group, matrix algebra, quaternion algebra or complex number occurs in either — and every
later module is an explicitly labelled identification / comparison module.

What is proved:

* the intrinsic **core carrier** is exactly the group of unit quaternions, by an explicit map
  with an explicit inverse, and the same two maps are a **homeomorphism** (the only statement
  in the layer whose conclusion contains topology); transported, the core carrier is
  group-equivalent to `SU(2)`;
* the **visible group** is group-equivalent to `SO(3)`, via an explicitly constructed
  three-dimensional rotation representation proved injective and surjective;
* the intrinsic **projection** agrees pointwise with the quaternionic conjugation action, the
  comparison diagram commutes, and the kernel is exactly `{±1}` — computed on the identified
  side as well as intrinsically;
* a **set-theoretic section** of the core projection exists, quotient-compatible choice and
  section are equivalent formulations, and **no continuous global section** exists;
* the intrinsic invertible **centre** is exactly `ℂˣ`, by an explicit coefficient map (not
  inferred from `S² = −1`), continuous in both directions;
* the centre meets the core carrier exactly in `{±1}`; the product map onto the full internal
  carrier is surjective with kernel the **diagonal sign pair**, giving the central-product
  quotient description of the full carrier;
* **normalization** (completed in Task 22): the polar decomposition `ℂˣ ≃* ℝ₊ × U(1)`; the
  positive central modulus splits off the full carrier as a direct factor
  `LiftZ ≃* ℝ₊ × LiftZ1`, proved for the actual intrinsic carrier through an intrinsic
  coordinate modulus; the normalized carrier is `(U(1) × unit quaternions)/Δℤ₂`, with the
  diagonal sign kernel derived from the intrinsic intersection; and the normalized carrier is
  group-equivalent to `U(2)`, whence `LiftZ ≃* ℝ₊ × U(2)`;
* **sign and torsor controls**: the internal core sign and the direction reversal are proved
  to be genuinely different two-valued structures; half-odd labels appear as central phase
  weights `exp(i b θ)`; two weights agree after a full turn exactly when they differ by an
  integer; and the full-turn value remembers only the half-odd/integer alternative.

All equivalences above are equivalences of **abstract multiplicative groups** except the one
homeomorphism explicitly mentioned; no Lie-group or smooth-structure claim is made. A named
`Spin(3)`/`Spinᶜ(3)` model is recorded as `NOT FORMALIZED`, since the installed library
provides no three-dimensional model and no `Spinᶜ` object.

`Task21.lean` exposes the principal endpoints (as `alias`es of the source theorems, so no
statement can drift) and runs `#print axioms` on each; `Task22.lean` re-audits the sixteen
declarations that were unresolved in the interrupted Task-21 archive. All 78 audited
declarations depend only on `propext`, `Classical.choice` and `Quot.sound`. Focused build
target: `lake build RequestProject.NullSectorTask21.Task21`.

`TASK21_AUDIT.md` contains the provenance and source-hash tables, the timeout provenance, the
repair ledger, the formal result ledger, the required decision table, the build ledger with
the whole-project job count and the complete warning inventory, the failbuild history, the
proof-integrity ledger and the source ledger.

## Task 23 — Local decomposition and reconstruction of the certified double cover

`RequestProject/NullSectorTask23/` decomposes the already-certified two-to-one projection
`pr : Lift → Gvis` locally and asks the narrow question: **what is the smallest local data
needed to reconstruct `Lift` and its projection globally?** The Task-21/22 source is used as
fixed input and is not modified; the quaternion, `SU(2)`, `SO(3)`, `U(2)` and central-product
identifications are not reproved.

Module chain (each module imports its predecessor):

```
RequestProject/NullSectorTask23/SafeBase.lean       -- frozen projection, sign carrier {±1}, sign action
RequestProject/NullSectorTask23/Cover.lean          -- four intrinsic coordinates, four open local domains
RequestProject/NullSectorTask23/Sections.lean       -- explicit continuous local representatives
RequestProject/NullSectorTask23/Transitions.lean    -- overlap signs, local constancy, identity/inverse/triple laws
RequestProject/NullSectorTask23/LocalProduct.lean   -- proj⁻¹(Vᵢ) ≃ₜ Vᵢ × {±1}
RequestProject/NullSectorTask23/Reconstruction.lean -- gluing quotient and its comparison with the certified carrier
RequestProject/NullSectorTask23/GlobalSection.lean  -- the global-section obstruction, read off the local data
RequestProject/NullSectorTask23/OldDomains.lean     -- comparison with the earlier Dom(v) direction domains
RequestProject/NullSectorTask23/OldBridges.lean     -- comparison with the earlier bridges and integer labels
RequestProject/NullSectorTask23/Hierarchy.lean      -- the reconstruction hierarchy and the negative controls
RequestProject/NullSectorTask23/Comparison.lean     -- the only identification module
RequestProject/NullSectorTask23/Task23.lean         -- principal endpoints and #print axioms
```

What is proved:

* an **explicit open cover** of the visible carrier by four domains obtained intrinsically from
  the axis/parameter coordinates, with a proof that no proper subfamily still covers;
* a **continuous local representative** on each domain, normalized by a positivity condition,
  defined as the inverse of an explicit continuous open bijection rather than by global choice,
  together with the exact relation between the two available normalizations;
* a **unique `{±1}` relative factor** on each overlap, proved continuous and hence locally
  constant, satisfying `τ_aa = +1`, `τ_ba = τ_ab⁻¹` and the exact triple-overlap law
  `τ_ac = τ_bc · τ_ab`; an explicit counterexample shows the overlaps of this cover need **not**
  be connected, so the sign data are kept componentwise rather than as one sign per pair;
* a **local product homeomorphism** `proj⁻¹(Vᵢ) ≃ₜ Vᵢ × {±1}` over the base;
* the **principal endpoint**: the quotient of the disjoint union of the local pieces by the
  overlap relation is homeomorphic to the certified carrier and recovers the projection as
  well — the global carrier **is** reconstructed exactly from the local sections and their
  overlap signs (`liftLocalHomeo`, `pr_toLift`);
* a **local reading of the global-section obstruction**: a global continuous section exists
  exactly when the local sections can be modified by continuous local signs making every
  transition `+1` — proved in both directions from the local data alone; hence every admissible
  continuous local decomposition of this cover carries at least one nontrivial overlap sign,
  even though a purely set-theoretic trivialization does exist;
* **comparisons**: the old `Dom(v)` do not correspond exactly to the new local domains (an extra
  parameter coordinate is needed, the match holds only up to direction reversal, and one new
  domain has no old counterpart); old core bridges reduce exactly to the overlap sign, while the
  extended projection has a central relative factor that is neither `+1` nor `-1`; shifting the
  angle parameter by `k` full turns acts by `(-1)^k`, so parity is exactly the reduction of
  integer label differences to overlap signs, while the central label bridge evaluates to `+1`
  after every full turn and loses the label entirely; distinct integer labels give equal signs;
* a **four-level reconstruction hierarchy**: the visible carrier alone and the visible carrier
  with local sections but trivial transitions are both insufficient; the visible carrier with
  local sections and the `{±1}` transitions is sufficient for the core carrier and provably
  insufficient for the extended carrier, whose fibre is infinite;
* the required **negative controls**, all formalized.

Only in the isolated comparison module, and only after all eight ingredients were proved, is
the conventional classification stated: `isCoveringMap_pr : IsCoveringMap pr`, i.e. the
reconstructed object is a two-sheeted covering map of the visible carrier. **No frame bundle,
tangent bundle, spin structure, characteristic class, cohomology class or physical
interpretation is constructed or claimed anywhere.**

`Task23.lean` exposes 55 principal endpoints as `alias`es of the source theorems and runs
`#print axioms` on each; all depend only on `propext`, `Classical.choice` and `Quot.sound`.
There is no `sorry`, no `admit`, no custom axiom, no `implemented_by`, no `native_decide` and
no `bv_decide`. Focused build target:
`lake build RequestProject.NullSectorTask23.Task23` (8205 jobs, green); whole-project
`lake build` (8276 jobs, green), with zero warnings in the Task-23 modules.

`TASK23_AUDIT.md` contains the exact definitions, the theorem inventory, the dependency graph,
the cover/section/transition/local-product tables, the reconstruction verdict, the Package
H/I/J comparison results, the reconstruction hierarchy, the required decision table, the
unresolved mathematical obligations, the failbuild ledger, the build and axiom reports and the
source ledger.

## Task 24 — intrinsic oriented frame torsor and lifted frame reconstruction

`RequestProject/NullSectorTask24/` (8 modules,
`SafeBase → IntrinsicFrames → VisibleFrameAction → FrameTorsor → ReferenceIndependence →
LiftedFrames → Comparison → Task24`) starts from the certified Task-23 layer, which is used as
input **unchanged**, and asks one narrow question: can the oriented orthonormal frames of the
reconstructed three-dimensional metric carrier be described intrinsically, and can that frame
object be lifted through the already certified projection?

What is proved:

* **Package A** freezes the inherited data — the three-dimensional carrier, its
  positive-definite form, the visible action and the preservation theorems. The only new
  ingredient is a minimal orientation datum (the inherited triple product), together with the
  derived fact that the visible action preserves it.
* **Package B** defines `FramePlus` as the subtype of ordered triples satisfying the exact
  inner-product relations and having positive orientation. The definition mentions neither the
  visible carrier nor any reference frame; a fixed coordinate triple is used only to prove
  nonemptiness. Every frame is proved to be a basis.
* **Packages C–E** give the visible action on frames, its laws, **freeness** (proved
  intrinsically: agreement on the three frame vectors, spanning, faithfulness of the inherited
  representation) and **transitivity** (the candidate transformation is constructed explicitly
  from the two frames and shown to be visible using the already certified surjectivity
  theorem), hence a unique visible transformation between any two frames.
* **Package F** introduces a reference frame only afterwards: it yields a coordinate
  bijection `Gvis ≃ FramePlus`, and two reference frames give presentations differing exactly
  by right translation by the unique transformation carrying one to the other — the reference
  frame coordinatizes the carrier, it does not define it.
* **Packages G–I** build the lifted frame carrier from the certified projection (not
  definitionally identified with the internal carrier), prove that every frame has exactly two
  lifted representatives differing by a unique kernel sign, that the sign acts freely, that the
  quotient recovers the frame carrier, that the construction is independent of the temporary
  reference frame up to an explicit equivalence (canonical up to one classified kernel sign),
  and that the internal action on frames is transitive with stabilizer exactly `{±1}` — hence
  *not* free.
* **Package J** contains one compatibility theorem with the Task-23 local data, and the
  required negative controls are formalized.

No manifold, tangent bundle, frame bundle over a varying base, principal bundle, spin
structure, characteristic class or physical interpretation is constructed or claimed.

`Task24.lean` exposes 38 principal endpoints and runs `#print axioms` on each; all depend only
on `propext`, `Classical.choice` and `Quot.sound`. There is no `sorry`, no `admit`, no custom
axiom, no `implemented_by`, no `native_decide` and no `bv_decide`. Focused build target:
`lake build RequestProject.NullSectorTask24.Task24` (8213 jobs, green); whole-project
`lake build` (8284 jobs, green), with zero warnings in the Task-24 modules.

`TASK24_AUDIT.md` contains the exact definitions, the theorem inventory, the dependency DAG
separating inherited data from new objects, new theorems and temporary coordinate choices, the
action table, the required decision table, the negative controls, the unresolved obligations,
the changed-proof-boundary ledger, the source ledger and the build and axiom reports.

## Task 25 — lifted-frame torsor hardening and one-fibre interface freeze

`RequestProject/NullSectorTask25/` (5 modules,
`LiftedFrameAction → LiftedFrameEquivariance → ReferenceTransferHardening →
OneFiberInterface → Task25`) continues from the completed Task-24 endpoint, which is used as
input **entirely unchanged** (no Task-24 file was edited, not even for imports). It closes one
precise gap: Task 24 formalized the induced internal action on the *ordinary* frame carrier
(transitive, not free, stabilizer `KerSign`) and the kernel-sign action on the lifted carrier,
but not the natural action of the full internal group on the lifted carrier itself.

What is proved:

* **Packages A–D.** The action `liftSmul : LiftGrp → LiftedFrame F₀ → LiftedFrame F₀` is
  defined directly on the internal representative (with the ordinary-frame component moved by
  the projected element), the action laws are proved, and the action is shown **free** and
  **transitive**, with the explicit transporter `y.elt * x.elt⁻¹`; hence exactly one internal
  element carries one lifted frame to another. The non-freeness downstairs is restated beside
  it, on its own carrier, so the two are never conflated.
* **Packages E–F.** The lifted-frame projection is **equivariant** along `projCore`, and the
  restriction of the new action to `KerSign` is *exactly* the inherited Task-24 sign action;
  kernel signs act trivially downstairs and freely upstairs. The Task-24 two-element fibre
  theorem is reused as a black box, not rebuilt.
* **Package G.** The inherited carrier equivalence `LiftedFrame F₀ ≃ LiftGrp` is proved
  equivariant for the new action and left multiplication, so the torsor structure upstairs is
  compatible with the intrinsic action, not merely transported along a bijection.
* **Packages H–J.** The unique downstairs reference change has **exactly two** internal lifts,
  forming one free transitive `KerSign`-orbit; each chosen lift gives an equivariant transfer
  map (the inherited right-multiplication convention commutes with the new left action, so the
  unconjugated identity is the correct one), and the two transfer maps differ by a **unique**
  kernel sign, with the converse sign-shift statement also proved.
* **Packages K, M.** The already-proved data are frozen in a record `OneFiberLiftInterface`
  that separates intrinsic data from temporary presentation data, with a proof that changing
  the temporary reference frame yields an equivalent interface (canonical up to the classified
  `Z₂` ambiguity). A neutral, *uninstantiated* record `FiberFamilyInput` names the first
  missing Task-XXVI node.

No base space, fibre family, tangent bundle, vector bundle, principal bundle, spin structure,
topology, connection or physical interpretation is introduced.

`Task25.lean` exposes 34 principal endpoints and runs `#print axioms` on each; all depend only
on `propext`, `Classical.choice` and `Quot.sound`. There is no `sorry`, no `admit`, no custom
axiom, no `implemented_by`, no `native_decide` and no `bv_decide`. Focused build target:
`lake build RequestProject.NullSectorTask25.Task25` (8218 jobs, green); whole-project
`lake build` (8289 jobs, green, 0 errors, 114 pre-existing warnings, none in a Task-25 module).

`TASK25_AUDIT.md` contains the exact definitions, the theorem inventory, the dependency graph,
the required decision table, the multiplication-convention check, the interface description,
the negative controls, the exact Task-XXVI dependency frontier, the failed-build ledger, the
unresolved obligations, the source ledger and the build and axiom reports.
