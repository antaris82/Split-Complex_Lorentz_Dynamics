This project was edited by [Aristotle](https://aristotle.harmonic.fun).

To cite Aristotle:
- Tag @Aristotle-Harmonic on GitHub PRs/issues
- Add as co-author to commits:
```
Co-authored-by: Aristotle (Harmonic) <aristotle-harmonic@harmonic.fun>
```

# Null-Sector Foundation — Tasks 01, 02, 03, 04, 06, 07, 08, 09 and 10

Nine self-contained, machine-checked Lean 4 developments.

**Task 01** — the split-complex / null-coordinate decomposition of a fixed 1+1 plane
inside 3+1 Minkowski space, the classification of the future-causal coefficient
quadrant, the action of longitudinal boosts, the invariant product of complementary
coefficients, and two elementary limiting regimes.

**Task 02** — a reconstruction, uniqueness and obstruction audit: starting from the
longitudinal carrier and its quadratic form alone (the split-complex multiplication
removed from the construction layer), which bilinear products are possible, and which
additional datum is needed before the algebraic structure is forced?

**Task 03** — what survives when the chosen unit is allowed to transform: preservation
of the polarization, the orbit of normalized future units, the covariance of the whole
reconstructed product family, the exact classification of transporters and of the
stabilizer of a unit, and the residual discrete ambiguity in the two complementary null
sectors.

**Task 04** — leaving the single fixed spatial direction: every unit spatial direction
orthogonal to a chosen future unit defines its own longitudinal 1+1 sector, and Task 04
classifies exactly which global bilinear products on the 3+1 carrier restrict to the
reconstructed product in *every* such sector — what is thereby forced, what cross-sector
freedom remains, what commutativity and spatial isotropy remove, how orientation acts on
what survives, and whether associativity or global norm multiplicativity can survive at
all.

**Task 06** — a clean-room reconstruction of the orientation-sensitive gluing
classification, plus a universal obstruction probe. Phase A starts from a completely
unknown alternating cross-sector defect and derives, from explicit orientation-preserving
rest-space symmetries alone, exactly which defects survive; only afterwards is a nonzero
witness constructed, the solution space determined, the coordinate formula derived,
orientation reversal analysed, and the outcome compared with Task 04. Phase B returns to
an arbitrary sector-compatible bilinear product with no symmetry assumption and settles,
separately, whether global associativity and whether global `Q4` multiplicativity are
possible at all.

**Task 07** — opening exactly one Task-06 assumption: mixed products of embedded vectors
are no longer required to stay inside the original carrier. For two orthogonal spatial
directions, associativity forces a mixed product outside the old carrier, and the
two-generator system has a finite minimal associative closure.

**Task 08** — adding the third inherited orthogonal spatial direction: which further
product directions are forced, what the minimal associative closure of the complete
three-direction spatial system is, and whether it carries an injective copy of the whole
original `3+1` carrier on which the inherited square law survives.

**Task 09** — the second obstruction isolated in Part VI: can the inherited Lorentz
quadratic form be extended from the embedded old carrier to the *fixed* Task-08
associative closure as a quadratic multiplicative map? The real scalar codomain is tested
first and refuted; the internally derived central two-plane spanned by the unit and the
derived central element is then constructed, an entirely unknown map into it is analysed
before any candidate exists, rigidity is proved, and the complete solution space is
classified.

**Task 10** — one distinguished old spatial axis is selected and interpreted only as a
direction: old space splits into a longitudinal line and a transverse plane, and the
single one-parameter rotation fixing that axis is studied. Its extension to the Task-08
associative carrier is proved to exist and to be unique; the longitudinal and transverse
transformation channels are classified; an internal lift implementing the same rotation by
conjugation is sought only afterwards, found inside the derived two-plane spanned by the
unit and the transverse channel, and classified exactly — the half angle is derived, not
assumed, and a multiplicative scalar function is proved to remain free. The candidate-state
left action is then distinguished from the algebra action at `2π`, the two
distinguished-axis half-angle sectors are classified, transverse state orientation is shown
*not* to be selected by the present data, and the structure-preserving axial derivations are
shown to form exactly one real line — a fixed direction with a free scale.

All nine are carrier-and-transformation audits. No physical ontology is attached to any
object: everything is real vector spaces, quadratic forms, bilinear maps, linear
equivalences and real coefficients.

## Environment

| Item | Value |
| --- | --- |
| Lean toolchain | `leanprover/lean4:v4.28.0` (see `lean-toolchain`) |
| Mathlib | `v4.28.0`, commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (see `lake-manifest.json`) |
| Build target | `RequestProject` library (`lakefile.toml`) |

## Layout

```
RequestProject/NullSectorTask01/Basic.lean        -- 3+1 carrier, Q₄, longitudinal 1+1 carrier, Q₂, ι
RequestProject/NullSectorTask01/SplitComplex.lean -- split-complex product, e₊/e₋, null coordinates, Q₂(P a b) = a b
RequestProject/NullSectorTask01/Strata.lean       -- future-causal quadrant and its four strata
RequestProject/NullSectorTask01/Boost.lean        -- longitudinal boosts, reciprocal scaling, invariant product
RequestProject/NullSectorTask01/Limits.lean       -- boundary families and the two limiting regimes
RequestProject/NullSectorTask01/Task01.lean       -- imports everything, states the principal final theorems

RequestProject/NullSectorTask02/LorentzData.lean      -- polarization L2 of Q₂, its properties, chosen vectors u₀, s₀
RequestProject/NullSectorTask02/CandidateProduct.lean -- unknown bilinear product, unit/multiplicativity predicates
RequestProject/NullSectorTask02/FixedUnit.lean        -- complete classification of products admissible at u₀
RequestProject/NullSectorTask02/Minimality.lean       -- left-unit-only classification and the three minimality tests
RequestProject/NullSectorTask02/GeneralUnit.lean      -- arbitrary unit: existence ⇔ Q₂ e = 1, uniqueness, future units
RequestProject/NullSectorTask02/Canonicality.lean     -- explicit rational symmetry and the equivariance obstruction
RequestProject/NullSectorTask02/Comparison.lean       -- late comparison with Task 01 (only file importing SplitComplex)
RequestProject/NullSectorTask02/Task02.lean           -- principal classification/obstruction theorems, axiom report

RequestProject/NullSectorTask03/Core.lean         -- Lorentz maps, unit orbit and transporters, product covariance, null pair
RequestProject/NullSectorTask03/Task03.lean       -- late comparison with the Task-01 boost and idempotents;
                                                  -- principal theorems, axiom report

RequestProject/NullSectorTask04/Lorentz4.lean       -- polarization L4 of Q4, uniqueness, the chosen unit e₀
RequestProject/NullSectorTask04/RestSpace.lean      -- rest space of e₀, the induced positive form h, coordinates
RequestProject/NullSectorTask04/Sectors.lean        -- unit spatial directions, the 1+1 embeddings, the Task-02 product
RequestProject/NullSectorTask04/GlobalExtension.lean-- unknown bilinear product, sector compatibility, derived global unit
RequestProject/NullSectorTask04/Classification.lean -- forced symmetric branch, alternating defect, exact iff classification
RequestProject/NullSectorTask04/IdentityAudit.lean  -- identity audit and the explicit counterexamples
RequestProject/NullSectorTask04/Isotropy.lean       -- stabilizer of e₀, full-isotropy classification
RequestProject/NullSectorTask04/ProperIsotropy.lean -- orientation determinant, proper-isotropy family, orientation reversal
RequestProject/NullSectorTask04/Overlap.lean        -- sector overlaps versus cross-sector gluing
RequestProject/NullSectorTask04/Identification.lean -- late conventional identification (COMPARISON ONLY)
RequestProject/NullSectorTask04/Task04.lean         -- principal theorems, axiom report

RequestProject/NullSectorTask06/SafeBase.lean       -- clean rest basis r₁ r₂ r₃, orthonormality, expansion
RequestProject/NullSectorTask06/GenericExtension.lean -- re-derived generic extension theorem, defect uniqueness
RequestProject/NullSectorTask06/ProperAction.lean   -- stabilizer of e₀, rest action, orientation determinant
RequestProject/NullSectorTask06/UnknownDefect.lean  -- unknown alternating defect, equivariance, output components
RequestProject/NullSectorTask06/Rigidity.lean       -- clean-room rigidity: basis-pair constraints, upper bound
RequestProject/NullSectorTask06/Existence.lean      -- FIRST explicit nonzero witness (only after rigidity)
RequestProject/NullSectorTask06/ExactClassification.lean -- exact solution space, coordinate formula
RequestProject/NullSectorTask06/OrientationReversal.lean -- orientation reversal, full-isotropy classification
RequestProject/NullSectorTask06/Identification.lean -- late conventional identification (COMPARISON ONLY)
RequestProject/NullSectorTask06/Task04Comparison.lean    -- late Task-04 comparison, replication verdict
RequestProject/NullSectorTask06/AssociativityObstruction.lean -- Phase B: universal associativity obstruction
RequestProject/NullSectorTask06/NormObstruction.lean -- Phase B: universal Q4-multiplicativity obstruction
RequestProject/NullSectorTask06/UniversalObstructionSummary.lean -- Phase B verdicts, minimal configuration
RequestProject/NullSectorTask06/Task06.lean         -- principal theorems, axiom report

RequestProject/NullSectorTask07/SafeBase.lean       -- inherited data, forced square law oldSq, two directions
RequestProject/NullSectorTask07/AmbientExtension.lean -- arbitrary associative unital real extension
RequestProject/NullSectorTask07/Polarization.lean   -- recovery of the inherited symmetric product
RequestProject/NullSectorTask07/TwoDirections.lean  -- derived generator relations A^2=B^2=1, AB+BA=0
RequestProject/NullSectorTask07/MixedProduct.lean   -- first definition of P = A*B, forced relations
RequestProject/NullSectorTask07/NewDirection.lean   -- old-carrier square obstruction, P outside the carrier
RequestProject/NullSectorTask07/ForcedRelations.lean -- relation summary, linear independence of 1,A,B,P
RequestProject/NullSectorTask07/GeneratedClosure.lean -- span, normal form, closure, dimension, table
RequestProject/NullSectorTask07/Minimality.lean     -- minimality among product-closed subspaces
RequestProject/NullSectorTask07/DirectWitness.lean  -- fresh four-dimensional existence witness
RequestProject/NullSectorTask07/Uniqueness.lean     -- uniqueness up to generator-preserving isomorphism
RequestProject/NullSectorTask07/SignAudit.lean      -- generator-order and sign diagnostic
RequestProject/NullSectorTask07/Identification.lean -- late conventional identification (COMPARISON ONLY)
RequestProject/NullSectorTask07/Task07.lean         -- principal theorems, axiom report

RequestProject/NullSectorTask08/SafeBase.lean       -- inherited old-carrier data, third direction dirC
RequestProject/NullSectorTask08/ThirdDirection.lean -- C = iota c, derivation of C*C = 1
RequestProject/NullSectorTask08/InheritedRelations.lean -- polarization => AC = -CA, BC = -CB
RequestProject/NullSectorTask08/NewMixedProducts.lean -- first definitions Q = A*C, R = B*C, S3 = (A*B)*C
RequestProject/NullSectorTask08/ForcedRelations.lean -- complete forced-relation ledger, channel squares
RequestProject/NullSectorTask08/Membership.lean     -- membership in the old carrier and in the Task-07 closure
RequestProject/NullSectorTask08/Independence.lean   -- independence of 1,A,B,C,P,Q,R,S3
RequestProject/NullSectorTask08/GeneratedClosure.lean -- span, coefficient law, closure, dimension, table
RequestProject/NullSectorTask08/Minimality.lean     -- minimality, word reduction, proper inclusion of Task 07
RequestProject/NullSectorTask08/StructuralDiagnostic.lean -- commutation diagnostic for the highest channel
RequestProject/NullSectorTask08/DirectWitness.lean  -- fresh eight-dimensional existence witness
RequestProject/NullSectorTask08/FullVec4Embedding.lean -- full old-carrier embedding, ambient existence
RequestProject/NullSectorTask08/Uniqueness.lean     -- uniqueness up to generator-preserving isomorphism
RequestProject/NullSectorTask08/SignPermutationAudit.lean -- permutation and sign diagnostics
RequestProject/NullSectorTask08/Identification.lean -- late conventional identification (COMPARISON ONLY)
RequestProject/NullSectorTask08/Task08.lean         -- principal theorems, axiom report

RequestProject/NullSectorTask09/SafeBase.lean       -- inherited Task-08 witness, neutral quadratic interface
RequestProject/NullSectorTask09/RealScalarNoGo.lean -- Phase A: forced real values, scalar-codomain obstruction
RequestProject/NullSectorTask09/CentralPlane.lean   -- Z = span{1,S}: closure, commutativity, centrality, dim 2
RequestProject/NullSectorTask09/UnknownQuadraticMap.lean -- Phase B: unknown Z-valued map, polarization covariance
RequestProject/NullSectorTask09/Rigidity.lean       -- forced basis values, full polarization ledger, rigidity
RequestProject/NullSectorTask09/Existence.lean      -- first explicit candidates, quadraticity, multiplicativity
RequestProject/NullSectorTask09/ExactClassification.lean -- exact solution space, image controls, Part-VI verdict
RequestProject/NullSectorTask09/CentralSignAudit.lean -- S |-> -S and the Task-08 generator sign freedom
RequestProject/NullSectorTask09/Identification.lean -- late conventional identification (COMPARISON ONLY)
RequestProject/NullSectorTask09/Task09.lean         -- principal theorems, axiom report

RequestProject/NullSectorTask10/SafeBase.lean           -- import ledger, firewalls, 8-basis extensionality
RequestProject/NullSectorTask10/AxisDecomposition.lean  -- distinguished axis, Long, Trans, Rest = Long ⊕ Trans
RequestProject/NullSectorTask10/OldAxialRotation.lean   -- rot θ, group law, Q4 invariance
RequestProject/NullSectorTask10/AlgebraExtension.lean   -- forced values, uniqueness, explicit Φθ, group law, Φ(2π) = id
RequestProject/NullSectorTask10/VectorChannels.lean     -- longitudinal/transverse sectors, exact Z-channel classification
RequestProject/NullSectorTask10/InternalLift.lean       -- K = span{1,R}, lift classification, half angle derived, scalar freedom
RequestProject/NullSectorTask10/StateAction.lean        -- candidate-state left action, 2π/4π, algebra vs state
RequestProject/NullSectorTask10/HalfAngleSectors.lean   -- Rψ = ±Sψ sectors, dimensions, half-angle factors, §23 verdict
RequestProject/NullSectorTask10/AxialDerivation.lean    -- axial derivations, exact classification, intrinsic commutator formula
RequestProject/NullSectorTask10/DynamicsDiagnostic.lean -- direction fixed, rate free
RequestProject/NullSectorTask10/Identification.lean     -- late conventional comparison (COMPARISON ONLY)
RequestProject/NullSectorTask10/Task10.lean             -- principal theorems, axiom report
```

Task 03 keeps its core in a single module: every module of this project imports the
whole of Mathlib, which dominates compilation time, so a short dependency chain is much
cheaper to build.  The four layers intended by the task (Lorentz maps, unit orbit,
product covariance, null pair) are the four sections of `Core.lean`.

Task 02 respects a strict import firewall: its core files import only
`RequestProject.NullSectorTask01.Basic`; the Task-01 split-complex layer enters solely
in `Comparison.lean`. See §2 of `TASK02_AUDIT.md` for the mechanical audit.

Task 03 respects the same discipline: `Core.lean` imports only
`RequestProject.NullSectorTask02.GeneralUnit`, and the Task-01 boost/split-complex
declarations are imported exclusively by `RequestProject/NullSectorTask03/Task03.lean`,
which is compiled only after the whole core has compiled.  The late comparison layer and
the principal theorems share that one module because every module of this project
imports the whole of Mathlib, which dominates compilation time.
See §2 and §20 of `TASK03_AUDIT.md`.

Task 04 follows the same discipline: its nine core files import only
`RequestProject.NullSectorTask01.Basic` (carrier and quadratic forms) and
`RequestProject.NullSectorTask02.FixedUnit` (the reconstructed longitudinal product).
The Task-01 split-complex layer and Mathlib's cross product enter only in
`Identification.lean`, which is a comparison layer used by no core result.
See §3 and §24 of `TASK04_AUDIT.md`.

Task 06 enforces a stricter, machine-audited firewall. Its clean-room modules import
only the uncontaminated Task-04 base layer (`GlobalExtension.lean` and its own
dependencies) and re-derive the generic extension theorem; none of the Task-04 modules
containing an explicit nonzero alternating witness is imported before the reconstruction
is complete. No explicit nonzero alternating rest-space map occurs anywhere before the
rigidity theorem — the first one is `wit3` in `Existence.lean`. Mathlib's cross product
and the Task-04 orientation modules enter only in `Identification.lean` and
`Task04Comparison.lean`. The Phase-B modules depend only on `SafeBase.lean` and
`GenericExtension.lean` and assume no symmetry whatsoever. See §§3–8 of
`TASK06_AUDIT.md` for the mechanical firewall, source-order and structural-witness
reports.

Task 07 opens exactly one assumption of Task 06 — that products of embedded vectors
must remain inside the original `3+1` carrier — and keeps everything else, in
particular the forced diagonal square law. In an arbitrary real associative unital
ambient extension with an injective embedding of the original carrier, the inherited
symmetric product is recovered by polarization; the two selected orthogonal spatial
directions are shown to square to the unit and anticommute; their mixed product
`P = A ⋆ B` is proved nonzero, to satisfy `P ⋆ P = −1`, and to lie outside the embedded
original carrier; `1, A, B, P` are independent, their span is multiplicatively closed,
has dimension exactly four, and is minimal among product-closed subspaces containing the
two generators. Only afterwards is a fresh four-dimensional witness constructed from the
derived table and proved associative, uniqueness up to a generator-preserving isomorphism
established, and — in a separate late module labelled COMPARISON ONLY — the resulting
algebra conventionally identified. The twelve reconstruction modules contain no
occurrence of any conventional target-structure name (mechanical scan, §5 of
`TASK07_AUDIT.md`); the identification module is imported only by `Task07.lean`.

Task 08 adds exactly one further inherited orthogonal spatial direction `c` to the
Task-07 two-generator system, and nothing else. From the inherited square law alone it
derives `C ⋆ C = 1`, and from polarization together with the inherited orthogonality
relations it derives the pairwise anticommutation of `A, B, C`. Only afterwards are the
mixed products `Q = A ⋆ C`, `R = B ⋆ C` and `S₃ = (A ⋆ B) ⋆ C` defined, all their
relations and squares derived, and their membership classified: `Q, R, S₃` lie outside
the embedded original carrier and, together with `C`, outside the Task-07 closure. The
eight elements `1, A, B, C, P, Q, R, S₃` are linearly independent in every ambient
extension, their span is multiplicatively closed, has dimension exactly eight, and is
minimal among product-closed subspaces containing the three inherited generators. A
fresh eight-dimensional witness is then built from the derived table and proved
associative; the *complete* original `3+1` carrier embeds into it injectively, the
inherited square law holds for every embedded old vector, and polarization recovers the
full inherited symmetric product — which resolves the ambient-existence obligation left
open by Task 07. Uniqueness up to a generator-preserving isomorphism, a sign and
permutation audit, and — in a separate late module labelled COMPARISON ONLY — the
conventional identification follow. The fourteen reconstruction modules contain no
occurrence of any conventional target-structure name (mechanical scan, §5 of
`TASK08_AUDIT.md`); the identification module is imported only by `Task08.lean`, and no
Task-08 module imports Task-07's identification layer or any Task-05 module.

Task 09 changes nothing about the product: the carrier, the unit, the eight derived basis
elements and the multiplication are literally the Task-08 witness, and no generator is
added. Only the codomain of the quadratic map moves. An unknown real-valued map that is
quadratic, multiplicative and restricts to the inherited Lorentz form on the embedded old
carrier is shown to be impossible, by a small explicit configuration using only
degree-two homogeneity, multiplicativity and three inherited values, tested on a single
two-term element. The two-plane spanned by the unit and the derived central element is
then constructed inside the fixed carrier and proved closed, commutative, central and of
exact dimension two. Only afterwards is an entirely unknown map into that plane
introduced: all eight of its basis values and its complete polarization ledger are forced,
leaving exactly one undetermined entry, which is proved to square to `-4` times the unit
and hence to be one of two values. The first explicit candidate appears only after that
rigidity theorem; quadraticity, multiplicativity for arbitrary pairs of carrier elements,
and the inherited-form restriction for arbitrary old vectors are then proved directly in
the reconstructed coordinates. The solution space has exactly two elements; no admissible
map can stay inside the real line, the extra central direction is attained by every
admissible map, and the sign flip on that direction exchanges the two solutions — the same
exchange induced by the transposition of two derived spatial generators already audited in
Task 08. The eight reconstruction modules contain no conventional target-structure name in
code apart from one disclosed naming artefact (§4 of `TASK09_AUDIT.md`); the
identification module is imported only by `Task09.lean`, and no reconstruction module
imports Task-08's identification layer.

**Literature calibration.** The final structure — a two-dimensional commutative central
subalgebra of a finite-dimensional real associative algebra, and a quadratic map into it
that is multiplicative and restricts to a given quadratic form — is standard known
mathematics, and the late comparison module identifies the two admissible maps with
conventional operations on the conventionally identified algebra. What is reconstructed
independently here is the *dependency path*, not the mathematical structure; no novelty is
claimed for the structure itself.

## Build

```
lake build
```

or, per task,

```
lake build RequestProject.NullSectorTask01.Task01
lake build RequestProject.NullSectorTask02.Task02
lake build RequestProject.NullSectorTask03.Task03
lake build RequestProject.NullSectorTask04.Task04
lake build RequestProject.NullSectorTask06.Task06
lake build RequestProject.NullSectorTask07.Task07
lake build RequestProject.NullSectorTask08.Task08
lake build RequestProject.NullSectorTask09.Task09
lake build RequestProject.NullSectorTask10.Task10
```

No development contains `sorry`, `admit`, or a custom `axiom`. All principal
theorems depend only on `propext`, `Classical.choice`, `Quot.sound`.

## Documentation

* [`TASK01_AUDIT.md`](TASK01_AUDIT.md) — Task 01 audit.
* [`TASK02_AUDIT.md`](TASK02_AUDIT.md) — Task 02 audit: input definitions, import-firewall
  report, theorem inventory, fixed-unit and weakened-assumption classifications,
  assumed-versus-derived table, arbitrary-unit result, future-unit/canonicality result,
  equivariance obstruction, late comparison with Task 01, final dependency graph,
  negative-control table, source ledger, build and axiom reports.
* [`TASK03_AUDIT.md`](TASK03_AUDIT.md) — Task 03 audit: imported Task-02 inputs,
  import-firewall report, Lorentz/future/orientation definitions, `Q2 → L2` preservation,
  unit-orbit classification, transporter existence and uniqueness, stabilizer,
  product covariance, fixed-product invariance versus family covariance, spacelike
  companions, ordered/unordered null pair, transport of the null pair, product-family
  orbit, dependency graph, late comparison with Task 01, negative-control table, source
  ledger, build and axiom reports.
* [`TASK04_AUDIT.md`](TASK04_AUDIT.md) — Task 04 audit: source ledger, toolchain, allowed
  imports, Experiment-1 firewall statement, `Q4 → L4` derivation, rest-space construction,
  longitudinal-sector theorem, sector compatibility, global-unit status, full extension
  classification, explicit nonuniqueness witness, symmetric-part and antisymmetric-defect
  theorems, converse reconstruction, commutative/full-isotropy/proper-isotropy
  classifications, orientation reversal, identity audit, associativity and global
  norm-multiplicativity results, overlap compatibility, Conservation-of-Difficulty graph,
  late conventional identification, import- and terminology-firewall reports,
  negative-control table, build and axiom reports, unresolved obligations.
* [`TASK06_AUDIT.md`](TASK06_AUDIT.md) — Task 06 audit: toolchain, source ledger, allowed
  inherited declarations, rejected Task-04 modules, Experiment-1 / terminology /
  structural-witness / source-order firewall reports, the re-derived generic extension
  theorem, the intrinsic proper-isotropy definition, the unknown-defect setup, basis-pair
  rigidity results, the exact solution-space classification, the first location of an
  explicit nonzero witness, the existence theorem, the coordinate formula derived after
  classification, orientation reversal, full isotropy, late conventional identification,
  the Task-04 comparison and replication verdict, the universal associativity and global
  norm results with their minimal obstruction equations, the joint theorem, the updated
  Conservation-of-Difficulty graph, the diagnostic handoff, negative-control table, build
  and axiom reports, unresolved obligations.
* [`TASK07_AUDIT.md`](TASK07_AUDIT.md) — Task 07 audit: toolchain, source ledger and
  source-order report, inherited Task-06 theorems, Experiment-1 and target-structure
  firewall reports, the ambient-extension definition, the retained square law, the
  polarization theorem, the two-generator relations, the first definition of the mixed
  product and its forced relations, the old-carrier non-membership theorem, linear
  independence, the generated-closure and normal-form theorems, the derived multiplication
  table, the exact dimension, minimality, the direct finite-dimensional witness and its
  associativity proof, the uniqueness result, the generator-order/sign diagnostic, the
  late conventional identification (COMPARISON ONLY), the updated
  Conservation-of-Difficulty graph, the negative-control table, build and axiom reports,
  unresolved obligations.
* [`TASK08_AUDIT.md`](TASK08_AUDIT.md) — Task 08 audit: toolchain, source ledger and
  source-order report, exact Task-07 import ledger, Experiment-1 and target-structure
  firewall reports, the third-direction definition, the derivation of `C ⋆ C = 1` and of
  pairwise anticommutation, the first definitions of the new mixed channels, the complete
  forced-relation ledger, membership results, the linear-independence classification, the
  generated span, the closure theorem and the full multiplication table, the exact
  dimension, minimality and word reduction, the structural diagnostic for the highest
  channel, the direct eight-dimensional witness and its associativity proof, the full
  `Vec4` embedding, square preservation for arbitrary old vectors, recovery of the
  symmetric product, the Task-07 obligation verdict, uniqueness, the sign/permutation
  audit, the late conventional identification (COMPARISON ONLY), the Task-07 versus
  Task-08 structural comparison, the relation to the Task-06 obstruction, the updated
  Conservation-of-Difficulty graph, the negative-control table, build and axiom reports,
  unresolved obligations.
* [`TASK09_AUDIT.md`](TASK09_AUDIT.md) — Task 09 audit: toolchain, source ledger, exact
  Task-08 import ledger, Experiment-1 and target-structure firewall reports (with the one
  disclosed naming artefact), the definition of quadraticity, the real-valued
  negative-control theorem, the minimal scalar obstruction with its exact incompatible
  equations, the construction of the central plane and its closure/commutativity/
  centrality/dimension, the unknown-map setup in both equivalent formulations, the
  inherited basis values, the complete polarization ledger, the rigidity theorem, the exact
  residual freedom, the first explicit candidate location, the direct quadraticity proof,
  the global multiplicativity proof, the full old-form restriction theorem, the exact
  solution-space theorem, the real-line image negative control, the central-component
  witness, the central-sign action and its relation to the Task-08 generator sign freedom,
  the Part-VI obstruction verdict, the updated Conservation-of-Difficulty graph, the late
  conventional identification (COMPARISON ONLY), build and axiom reports, unresolved
  obligations, the eleven-question Conservation-of-Difficulty appendix, the
  negative-control table and the status-vocabulary index.
* [`TASK10_AUDIT.md`](TASK10_AUDIT.md) — Task 10 audit: exact toolchain, exact Task-08/09
  import ledger, Experiment-1 and representation-target firewall reports, the
  distinguished-axis definition, the longitudinal/transverse decomposition, the old axial
  rotation, algebra-extension existence and uniqueness, the complete action on the Task-08
  basis, the longitudinal/transverse channel classification, internal-lift
  existence/classification with the scalar freedom stated as a result, the 2π/4π
  periodicity comparison, the state-action definition, the half-angle-sector
  classification, the transverse-state-orientation verdict, the axial-derivation
  classification, the generator-rate freedom, the Conservation-of-Difficulty graph, the
  late conventional comparison, build and axiom reports, and unresolved obligations.
