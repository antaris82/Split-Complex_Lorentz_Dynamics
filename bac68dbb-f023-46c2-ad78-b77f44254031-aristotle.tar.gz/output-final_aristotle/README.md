This project was edited by [Aristotle](https://aristotle.harmonic.fun).

To cite Aristotle:
- Tag @Aristotle-Harmonic on GitHub PRs/issues
- Add as co-author to commits:
```
Co-authored-by: Aristotle (Harmonic) <aristotle-harmonic@harmonic.fun>
```

# Null-Sector Foundation — Tasks 01, 02, 03, 04 and 06

Five self-contained, machine-checked Lean 4 developments.

**Task 01** — the split-complex / null-coordinate decomposition of a fixed 1+1 plane
inside 3+1 Minkowski space, the classification of the future-causal coefficient
quadrant, the action of longitudinal boosts, the invariant product of complementary
coefficients, and two elementary limiting regimes.

**Task 02** — a reconstruction, uniqueness and obstruction audit: starting from the
longitudinal carrier and its quadratic form alone (the split-complex multiplication
removed from the construction layer), which bilinear products are possible, and which
additional datum is needed before the algebraic structure is forced?

**Task 03** — what survives when the chosen unit is allowed to transform: preservation
of the polarization, the orbit of normalized future units, the covariance of the whole
reconstructed product family, the exact classification of transporters and of the
stabilizer of a unit, and the residual discrete ambiguity in the two complementary null
sectors.

**Task 04** — leaving the single fixed spatial direction: every unit spatial direction
orthogonal to a chosen future unit defines its own longitudinal 1+1 sector, and Task 04
classifies exactly which global bilinear products on the 3+1 carrier restrict to the
reconstructed product in *every* such sector — what is thereby forced, what cross-sector
freedom remains, what commutativity and spatial isotropy remove, how orientation acts on
what survives, and whether associativity or global norm multiplicativity can survive at
all.

**Task 06** — a clean-room reconstruction of the orientation-sensitive gluing
classification, plus a universal obstruction probe. Phase A starts from a completely
unknown alternating cross-sector defect and derives, from explicit orientation-preserving
rest-space symmetries alone, exactly which defects survive; only afterwards is a nonzero
witness constructed, the solution space determined, the coordinate formula derived,
orientation reversal analysed, and the outcome compared with Task 04. Phase B returns to
an arbitrary sector-compatible bilinear product with no symmetry assumption and settles,
separately, whether global associativity and whether global `Q4` multiplicativity are
possible at all.

All five are carrier-and-transformation audits. No physical ontology is attached to any
object: everything is real vector spaces, quadratic forms, bilinear maps, linear
equivalences and real coefficients.

## Environment

| Item | Value |
| --- | --- |
| Lean toolchain | `leanprover/lean4:v4.28.0` (see `lean-toolchain`) |
| Mathlib | `v4.28.0`, commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (see `lake-manifest.json`) |
| Build target | `RequestProject` library (`lakefile.toml`) |

## Layout

```
RequestProject/NullSectorTask01/Basic.lean        -- 3+1 carrier, Q₄, longitudinal 1+1 carrier, Q₂, ι
RequestProject/NullSectorTask01/SplitComplex.lean -- split-complex product, e₊/e₋, null coordinates, Q₂(P a b) = a b
RequestProject/NullSectorTask01/Strata.lean       -- future-causal quadrant and its four strata
RequestProject/NullSectorTask01/Boost.lean        -- longitudinal boosts, reciprocal scaling, invariant product
RequestProject/NullSectorTask01/Limits.lean       -- boundary families and the two limiting regimes
RequestProject/NullSectorTask01/Task01.lean       -- imports everything, states the principal final theorems

RequestProject/NullSectorTask02/LorentzData.lean      -- polarization L2 of Q₂, its properties, chosen vectors u₀, s₀
RequestProject/NullSectorTask02/CandidateProduct.lean -- unknown bilinear product, unit/multiplicativity predicates
RequestProject/NullSectorTask02/FixedUnit.lean        -- complete classification of products admissible at u₀
RequestProject/NullSectorTask02/Minimality.lean       -- left-unit-only classification and the three minimality tests
RequestProject/NullSectorTask02/GeneralUnit.lean      -- arbitrary unit: existence ⇔ Q₂ e = 1, uniqueness, future units
RequestProject/NullSectorTask02/Canonicality.lean     -- explicit rational symmetry and the equivariance obstruction
RequestProject/NullSectorTask02/Comparison.lean       -- late comparison with Task 01 (only file importing SplitComplex)
RequestProject/NullSectorTask02/Task02.lean           -- principal classification/obstruction theorems, axiom report

RequestProject/NullSectorTask03/Core.lean         -- Lorentz maps, unit orbit and transporters, product covariance, null pair
RequestProject/NullSectorTask03/Task03.lean       -- late comparison with the Task-01 boost and idempotents;
                                                  -- principal theorems, axiom report

RequestProject/NullSectorTask04/Lorentz4.lean       -- polarization L4 of Q4, uniqueness, the chosen unit e₀
RequestProject/NullSectorTask04/RestSpace.lean      -- rest space of e₀, the induced positive form h, coordinates
RequestProject/NullSectorTask04/Sectors.lean        -- unit spatial directions, the 1+1 embeddings, the Task-02 product
RequestProject/NullSectorTask04/GlobalExtension.lean-- unknown bilinear product, sector compatibility, derived global unit
RequestProject/NullSectorTask04/Classification.lean -- forced symmetric branch, alternating defect, exact iff classification
RequestProject/NullSectorTask04/IdentityAudit.lean  -- identity audit and the explicit counterexamples
RequestProject/NullSectorTask04/Isotropy.lean       -- stabilizer of e₀, full-isotropy classification
RequestProject/NullSectorTask04/ProperIsotropy.lean -- orientation determinant, proper-isotropy family, orientation reversal
RequestProject/NullSectorTask04/Overlap.lean        -- sector overlaps versus cross-sector gluing
RequestProject/NullSectorTask04/Identification.lean -- late conventional identification (COMPARISON ONLY)
RequestProject/NullSectorTask04/Task04.lean         -- principal theorems, axiom report

RequestProject/NullSectorTask06/SafeBase.lean       -- clean rest basis r₁ r₂ r₃, orthonormality, expansion
RequestProject/NullSectorTask06/GenericExtension.lean -- re-derived generic extension theorem, defect uniqueness
RequestProject/NullSectorTask06/ProperAction.lean   -- stabilizer of e₀, rest action, orientation determinant
RequestProject/NullSectorTask06/UnknownDefect.lean  -- unknown alternating defect, equivariance, output components
RequestProject/NullSectorTask06/Rigidity.lean       -- clean-room rigidity: basis-pair constraints, upper bound
RequestProject/NullSectorTask06/Existence.lean      -- FIRST explicit nonzero witness (only after rigidity)
RequestProject/NullSectorTask06/ExactClassification.lean -- exact solution space, coordinate formula
RequestProject/NullSectorTask06/OrientationReversal.lean -- orientation reversal, full-isotropy classification
RequestProject/NullSectorTask06/Identification.lean -- late conventional identification (COMPARISON ONLY)
RequestProject/NullSectorTask06/Task04Comparison.lean    -- late Task-04 comparison, replication verdict
RequestProject/NullSectorTask06/AssociativityObstruction.lean -- Phase B: universal associativity obstruction
RequestProject/NullSectorTask06/NormObstruction.lean -- Phase B: universal Q4-multiplicativity obstruction
RequestProject/NullSectorTask06/UniversalObstructionSummary.lean -- Phase B verdicts, minimal configuration
RequestProject/NullSectorTask06/Task06.lean         -- principal theorems, axiom report
```

Task 03 keeps its core in a single module: every module of this project imports the
whole of Mathlib, which dominates compilation time, so a short dependency chain is much
cheaper to build.  The four layers intended by the task (Lorentz maps, unit orbit,
product covariance, null pair) are the four sections of `Core.lean`.

Task 02 respects a strict import firewall: its core files import only
`RequestProject.NullSectorTask01.Basic`; the Task-01 split-complex layer enters solely
in `Comparison.lean`. See §2 of `TASK02_AUDIT.md` for the mechanical audit.

Task 03 respects the same discipline: `Core.lean` imports only
`RequestProject.NullSectorTask02.GeneralUnit`, and the Task-01 boost/split-complex
declarations are imported exclusively by `RequestProject/NullSectorTask03/Task03.lean`,
which is compiled only after the whole core has compiled.  The late comparison layer and
the principal theorems share that one module because every module of this project
imports the whole of Mathlib, which dominates compilation time.
See §2 and §20 of `TASK03_AUDIT.md`.

Task 04 follows the same discipline: its nine core files import only
`RequestProject.NullSectorTask01.Basic` (carrier and quadratic forms) and
`RequestProject.NullSectorTask02.FixedUnit` (the reconstructed longitudinal product).
The Task-01 split-complex layer and Mathlib's cross product enter only in
`Identification.lean`, which is a comparison layer used by no core result.
See §3 and §24 of `TASK04_AUDIT.md`.

Task 06 enforces a stricter, machine-audited firewall. Its clean-room modules import
only the uncontaminated Task-04 base layer (`GlobalExtension.lean` and its own
dependencies) and re-derive the generic extension theorem; none of the Task-04 modules
containing an explicit nonzero alternating witness is imported before the reconstruction
is complete. No explicit nonzero alternating rest-space map occurs anywhere before the
rigidity theorem — the first one is `wit3` in `Existence.lean`. Mathlib's cross product
and the Task-04 orientation modules enter only in `Identification.lean` and
`Task04Comparison.lean`. The Phase-B modules depend only on `SafeBase.lean` and
`GenericExtension.lean` and assume no symmetry whatsoever. See §§3–8 of
`TASK06_AUDIT.md` for the mechanical firewall, source-order and structural-witness
reports.

## Build

```
lake build
```

or, per task,

```
lake build RequestProject.NullSectorTask01.Task01
lake build RequestProject.NullSectorTask02.Task02
lake build RequestProject.NullSectorTask03.Task03
lake build RequestProject.NullSectorTask04.Task04
lake build RequestProject.NullSectorTask06.Task06
```

No development contains `sorry`, `admit`, or a custom `axiom`. All principal
theorems depend only on `propext`, `Classical.choice`, `Quot.sound`.

## Documentation

* [`TASK01_AUDIT.md`](TASK01_AUDIT.md) — Task 01 audit.
* [`TASK02_AUDIT.md`](TASK02_AUDIT.md) — Task 02 audit: input definitions, import-firewall
  report, theorem inventory, fixed-unit and weakened-assumption classifications,
  assumed-versus-derived table, arbitrary-unit result, future-unit/canonicality result,
  equivariance obstruction, late comparison with Task 01, final dependency graph,
  negative-control table, source ledger, build and axiom reports.
* [`TASK03_AUDIT.md`](TASK03_AUDIT.md) — Task 03 audit: imported Task-02 inputs,
  import-firewall report, Lorentz/future/orientation definitions, `Q2 → L2` preservation,
  unit-orbit classification, transporter existence and uniqueness, stabilizer,
  product covariance, fixed-product invariance versus family covariance, spacelike
  companions, ordered/unordered null pair, transport of the null pair, product-family
  orbit, dependency graph, late comparison with Task 01, negative-control table, source
  ledger, build and axiom reports.
* [`TASK04_AUDIT.md`](TASK04_AUDIT.md) — Task 04 audit: source ledger, toolchain, allowed
  imports, Experiment-1 firewall statement, `Q4 → L4` derivation, rest-space construction,
  longitudinal-sector theorem, sector compatibility, global-unit status, full extension
  classification, explicit nonuniqueness witness, symmetric-part and antisymmetric-defect
  theorems, converse reconstruction, commutative/full-isotropy/proper-isotropy
  classifications, orientation reversal, identity audit, associativity and global
  norm-multiplicativity results, overlap compatibility, Conservation-of-Difficulty graph,
  late conventional identification, import- and terminology-firewall reports,
  negative-control table, build and axiom reports, unresolved obligations.
* [`TASK06_AUDIT.md`](TASK06_AUDIT.md) — Task 06 audit: toolchain, source ledger, allowed
  inherited declarations, rejected Task-04 modules, Experiment-1 / terminology /
  structural-witness / source-order firewall reports, the re-derived generic extension
  theorem, the intrinsic proper-isotropy definition, the unknown-defect setup, basis-pair
  rigidity results, the exact solution-space classification, the first location of an
  explicit nonzero witness, the existence theorem, the coordinate formula derived after
  classification, orientation reversal, full isotropy, late conventional identification,
  the Task-04 comparison and replication verdict, the universal associativity and global
  norm results with their minimal obstruction equations, the joint theorem, the updated
  Conservation-of-Difficulty graph, the diagnostic handoff, negative-control table, build
  and axiom reports, unresolved obligations.
