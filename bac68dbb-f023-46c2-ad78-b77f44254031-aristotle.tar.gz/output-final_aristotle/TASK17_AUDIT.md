# TASK 17 AUDIT — Hardening the local exact-representative problem

**Status: LOCAL PROBLEM CLOSED; GLOBAL RECONSTRUCTION REFUTED; ADMISSIBLE-DOMAIN CLASS
CHARACTERIZED AND SHOWN NOT TO BE THE TASK-16 CLASS.**

---

## 0. Toolchain, revision, build target

| Item | Value |
| --- | --- |
| Lean toolchain | `leanprover/lean4:v4.28.0` (`lean-toolchain`) |
| Mathlib | `v4.28.0`, commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (`lake-manifest.json`) |
| Build target | `RequestProject` library (`lakefile.toml`), focused target `RequestProject.NullSectorTask17.Task17` |
| Full build | `lake build` — **succeeds, 8213 jobs, no errors, no warnings in any Task-17 module** |

### Mathlib declarations actually used in Task 17 (IMPORTED STANDARD RESULT)

* order/field arithmetic: `linarith`, `nlinarith`, `ring`, `positivity`, `field_simp`,
  `omega`, `Int.even_or_odd`, `mul_eq_zero`, `eq_or_lt_of_le`, `mul_pos`, `mul_nonneg`,
  `inv_pos`;
* real analysis: `Real.sqrt_pos`, `Real.sq_sqrt`, `Real.continuous_sqrt`,
  `Real.sin_eq_zero_iff`, `Real.sin_sq_add_cos_sq`, `Real.cos_neg`, `Real.sin_neg`,
  `Real.cos_add_int_mul_two_pi`, `Real.sin_add_int_mul_two_pi`, `Real.cos_int_mul_two_pi`,
  `ContDiff` and `contDiff_const`, `contDiff_fst`, `contDiff_snd`;
* point-set topology: `Continuous`, `ContinuousOn`, `ContinuousOn.restrict`,
  `Continuous.subtype_mk`, `continuous_subtype_val`, `IsOpen.preimage` (via
  `Continuous.isOpen_preimage`), `isOpen_Ioi`, `IsPreconnected`,
  `IsPreconnected.intermediate_value`, `IsPathConnected`, `IsPathConnected.isConnected`,
  `JoinedIn`, `Path`, `unitInterval`.

No other Mathlib area is used; in particular no algebraic topology, no bundle theory, no
group theory beyond the inherited carrier arithmetic.

---

## 1. Reconstruction firewall report (§1–§8)

1. **Strongest reconstruction layer imported.**  `RequestProject/NullSectorTask17/SafeBase.lean`
   imports exactly `RequestProject.NullSectorTask16.LocalRepair` — the top of the Task-16
   *reconstruction* chain.  The Task-16 modules `OptionCAudit` and `Identification`
   (comparison layers) are **not** reachable from any Task-17 reconstruction module: they
   are imported only by `RequestProject.NullSectorTask16.Task16`, which nothing in Task 17
   imports.
2. **Prohibited conventional targets.**  A mechanical scan of all Task-17 modules for
   `SO(3)`, `SU(2)`, `Spin`, `spinor`, `covering space`, `fibre/fiber bundle`,
   `principal bundle`, `line bundle`, `Čech`, `cocycle`, `transition function` in the
   geometric sense, `projective representation`, `cohomology`, `homotopy group`, and
   sphere-bundle classification returns hits **only** inside the firewall paragraph of
   `SafeBase.lean` and inside the single comparison module `Identification.lean`.
3. **Prohibited physical vocabulary.**  The same scan for `fermion`, `boson`, `photon`,
   `electron`, `helicity`, `spin`, `wavefunction`, `Hilbert space`, `quantum state`,
   `probability`, `Hamiltonian`, `field equation`, `gauge`, `connection`, `physical time`
   returns hits only in the same two places.
4. **No optimality assumed.**  The Task-16 domains are never assumed maximal, minimal,
   canonical or exhaustive; §42 and §43 below in fact *refute* exhaustiveness and
   maximality.
5. **No constancy assumed.**  The half-odd rate is only ever *proved* constant, from
   continuity plus a proved connectedness statement (`beta_const_on_Dom`,
   `label_const_of_preconnected`); the pointwise theorem `pointwise_rates` assumes nothing
   about the domain.
6. **No model assumed.**  Package C *derives* that an arbitrary admissible local family
   equals a model `locFam k`; it is never assumed.
7. **No overlap form assumed.**  Package E derives the overlap factor from two arbitrary
   families (`ovl`, `ovl_central_and_factor`, `ovl_explicit`, `ovl_integer`); the explicit
   model–model computation of Task 16 is not used as an input.
8. **Comparison module.**  `RequestProject/NullSectorTask17/Identification.lean` is
   imported by `RequestProject.NullSectorTask17.Task17` only.

---

## 2. Source order

```
RequestProject.NullSectorTask16.LocalRepair          (inherited, strongest reconstruction layer)
  → NullSectorTask17.SafeBase            (bookkeeping: normalization, paths, ℤ+1/2 rigidity)
  → NullSectorTask17.DomainGeometry      (Package A)
  → NullSectorTask17.RateRigidity        (Package B)
  → NullSectorTask17.LocalExhaustion     (Package C)
  → NullSectorTask17.AdmissibleDomains   (Package D)
  → NullSectorTask17.OverlapTransitions  (Package E)
  → NullSectorTask17.Reconstruction      (Package F)
  → NullSectorTask17.RegularityAudit     (Package G)
  → NullSectorTask17.Identification      (COMPARISON ONLY, last)
  → NullSectorTask17.Task17              (principal theorems, axiom report)
```

Declaration counts (theorems + definitions, excluding `example`s; none of the modules
contains `sorry`, `admit`, a custom `axiom`, `@[implemented_by]`, `native_decide` or
`bv_decide`):

| module | declarations |
| --- | --- |
| `SafeBase` | 27 |
| `DomainGeometry` | 20 |
| `RateRigidity` | 5 |
| `LocalExhaustion` | 7 |
| `AdmissibleDomains` | 37 |
| `OverlapTransitions` | 13 |
| `Reconstruction` | 6 |
| `RegularityAudit` | 8 |
| `Identification` (comparison) | 1 |
| `Task17` (endpoints) | 44 |

---

## 3. Exact definitions introduced in Task 17

All definitions use only the inherited carrier `W`, the inherited spatial carrier `Vec3`,
the inherited form `h3`, the inherited unit directions `IsUnitAxis`, the inherited
reference implementations `Un`, the inherited visible family `PhiGen`, and the inherited
central family `zexp`.

| name | definition |
| --- | --- |
| `nrm w` | `Real.sqrt (h3 w w)` |
| `nrmz w` | `(nrm w)⁻¹ • w` |
| `segLin n₀ n₁ t` | `(1 - t) • n₀ + t • n₁` |
| `segPath n₀ n₁ t` | `nrmz (segLin n₀ n₁ t)` |
| `sphSet S` | `{s : Sph | (s : Vec3) ∈ S}` (a direction set read inside the inherited unit-direction subspace) |
| `IsAdmissibleDomain D` | `(∀ n ∈ D, IsUnitAxis n) ∧ ∃ U, IsJointlyRegularFamily U ∧ IsTransformationValuedOn D U` |
| `AntipodalFree D` | `∀ n ∈ D, -n ∉ D` |
| `legCond p m n` | `h3 n m < (1/100) * h3 n p + n.2.2 ∧ -h3 n m < (1/100) * h3 n p + n.2.2` |
| `YDom` | unit directions satisfying `legCond` for one of the three explicit rational pairs `(pOne,mOne)`, `(pTwo,mTwo)`, `(pThree,mThree)` |
| `ovl U V n θ` | `U n θ ⋆ V n (-θ)` |
| `chainOvl F n θ N` | finite iterated product of the successive `ovl (F j) (F (j+1))` |
| `IsC1JointlyRegularFamily U` | jointly regular **and** presented by two `ContDiff ℝ 1` rate functions of the direction |

Inherited, not redefined: `Dom v = {n | IsUnitAxis n ∧ 0 < h3 n v}`,
`IsTransformationValuedOn`, `IsJointlyRegularFamily`, `IsSignTransformationValued`,
`locFam k`, `refFam`, `rateAlpha`, `rateBeta`.

---

## 4. Theorem inventory (DERIVED IN TASK 17)

### Package A — intrinsic geometry of the inherited domains (§9–§18)

| § | theorem | content |
| --- | --- | --- |
| 10 | `Dom_smul_pos`, `Dom_zero`, `mem_Dom_iff` | membership identities; invariance under positive rescaling of `v`; `Dom 0 = ∅` |
| 11 | `Dom_nonempty_iff` | `Dom v` nonempty **iff** `v ≠ 0` |
| 12 | `nrmz_mem_Dom_iff` | the normalized direction of `v` lies in `Dom v` **iff** `v ≠ 0` |
| 13 | `Dom_antipodal_free` | no antipodal pair, reproved from the inherited form only |
| 14 | `isOpen_sphSet_Dom` | `Dom v` is open in the inherited unit-direction subspace |
| 15,16 | `segLin_h3_pos`, `segLin_ne_zero`, `segPath_mem_Dom`, `joinedIn_segPath` | the explicit renormalized straight-line path between two members is defined for the whole interval, is unit-normalized, and stays strictly inside `Dom v` |
| 17 | `isPathConnected_sphSet_Dom` | every nonempty `Dom v` is path-connected |
| 18 | `isConnected_sphSet_Dom`, `isPreconnected_sphSet_Dom` | connectedness derived from the path result only |

### Package B — discrete-value rigidity (§19–§27)

| § | theorem | content |
| --- | --- | --- |
| 19,21,22 | `pointwise_rates` | for an arbitrary set `D` and an arbitrary jointly regular family exact on `D`: `α n = 0` and `β n ∈ ℤ + 1/2` at every unit `n ∈ D` |
| 20 | `recovered_form` | the recovered coefficient functions reproduce the family (Task-16 classification, in the form used) |
| 23,24 | `beta_const_on_Dom` | `β` is **constant** on every nonempty `Dom v`; proved from the proved continuity of `β` and the proved preconnectedness of `Dom v`, via the intermediate value property (`halfodd_const_of_preconnected`), with no generic local-constancy theorem |
| 25 | `label_not_const_without_connectedness` (Package D) | constancy genuinely needs the connectedness input: the two-point domain `{n,-n}` carries the two labels `1/2` and `-1/2` at once |
| 26 | `exists_local_label` | one integer `k` with `α ≡ 0`, `β ≡ k + 1/2` on the whole domain |
| 27 | `local_label_unique` | that integer is unique |

### Package C — full local-family exhaustion (§28–§34)

| § | theorem | content |
| --- | --- | --- |
| 29 | `eq_of_rates_eq` | equal recovered rates on a set of unit directions ⇒ equal families there, for all parameters |
| 30,31 | `local_exact_eq_locFam`, `local_exact_eq_locFam_unique` | local exactness + joint regularity ⇒ `U n θ = locFam k n θ` for **all** `n ∈ Dom v` and **all** `θ ∈ ℝ`, for exactly one `k` |
| 32 | `locFam_local_hypotheses` | conversely each `locFam k` is jointly regular and exact on every `Dom v` |
| 33 | `local_family_classification` | the two directions packaged as an equivalence |
| 34 | — | not needed: the classification does not fail |

### Package D — admissible direction domains (§35–§44)

| § | theorem | content |
| --- | --- | --- |
| 35,36 | `IsAdmissibleDomain` | the exact local representative problem stated for an arbitrary `D` |
| 37 | `admissible_necessary` | the complete list of forced conditions: `α = 0` on `D`; `β ∈ ℤ + 1/2` on `D`; `β` continuous on all unit directions; `β(-n) = -β(n)` for every antipodal pair **inside** `D` |
| 38 | `antipodal_pair_admissible` | **REFUTED**: an antipodal pair is not an obstruction — `{n,-n}` is admissible with labels `1/2`, `-1/2` |
| 39 | `antipodalFree_admissible` | absence of antipodal pairs **is** sufficient: every `locFam k` is exact on any antipodal-free set of unit directions |
| 40 | `admissible_iff_exists_rate_function` | exact criterion (necessity and sufficiency), so nothing further is missing |
| 41 | `label_const_of_preconnected` / `label_not_const_without_connectedness` | connectedness **does** change the classification of the label: unique on preconnected domains, not unique in general |
| 42 | `YDom_admissible`, `YDom_open`, `YDom_pathConnected`, `YDom_not_subset_Dom` | **REFUTED**: an explicit admissible, open, path-connected domain contained in no `Dom v` |
| 43 | `Dom_not_maximal` | the inherited domains are **not** maximal among admissible domains |
| 44 | — | no order-theoretic superlative is claimed for `Dom v` anywhere in Task 17 |

The §42 counterexample in detail.  With `pOne = (1,0,0)`, `pTwo = (0,1,0)`,
`pThree = (-3/5,-4/5,0)` and the transverse `mOne = (0,1,0)`, `mTwo = (-1,0,0)`,
`mThree = (4/5,-3/5,0)`, each leg is the open wedge `|h3 n m| < (1/100)·h3 n p + n₃`.
Antipodal-freeness is a purely linear consequence of the two defining inequalities of the
two legs involved (nine cases, all closed by linear arithmetic).  Openness is preimage of
`Ioi 0` under continuous linear functionals.  Path-connectedness holds because each leg is
star-shaped towards `(0,0,1)` for the renormalized straight-line path (every defining
functional is positive at `(0,0,1)`).  Non-containment: the domain contains the
normalizations of `(1,0,-1/1000)`, `(0,1,-1/1000)`, `(-3/5,-4/5,-1/1000)` and of `(0,0,1)`,
and `3·(1,0,-1/1000) + 4·(0,1,-1/1000) + 5·(-3/5,-4/5,-1/1000) = -(12/1000)·(0,0,1)`, so no
`v` can have positive inherited form against all four.

### Package E — arbitrary overlap transitions (§45–§53)

| § | theorem | content |
| --- | --- | --- |
| 45,46 | `ovl`, `ovl_central_and_factor` | the relative factor is *derived* from two arbitrary jointly regular families, not imported from the model computation |
| 47 | `ovl_central_and_factor` | it is central (and, being an inherited central unit, invertible) |
| 48 | `ovl_direction_independent` | on a preconnected set on which both families are exact it does not depend on the direction |
| 49 | `ovl_explicit`, `ovl_integer`, `ovl_param_law` | exact parameter dependence: `θ ↦ zexp 0 j θ` with `j ∈ ℤ` the difference of the labels; multiplicative in `θ`, unit at `θ = 0` |
| 50 | `ovl_unique` | uniqueness under the inherited normalization (`U 0 = w1`, one-axis group law) |
| 51 | `ovl_chain3` | three domains: the two transitions compose to the direct one |
| 52 | `chainOvl`, `chainOvl_eq` | arbitrary **finite** chains, by induction on the length |
| 53 | — | only finite chains are defined; **no infinite product occurs anywhere in Task 17**, and none is required by any statement above |

### Package F — reconstruction from local data (§54–§56)

| § | theorem | content |
| --- | --- | --- |
| 55 | `reconstruction_unique` | uniqueness always holds: two jointly regular families agreeing on every member of a covering family agree everywhere |
| 54 | `exact_local_not_signTransformationValued`, `locFam_not_signTransformationValued`, `refFam_not_exact_on_Dom` | **REFUTED**: a family exact on a nonempty `Dom v` is never sign-relaxed, and the unique global sign-relaxed family is exact on no nonempty `Dom v` |
| 54 | `local_data_do_not_reconstruct` | the sharp counterexample: a covering system of exact local representatives with **all transition factors equal to the unit** reconstructs no global sign-relaxed family |
| 56 | `no_global_halfodd_odd_rate` | the missing datum, exactly: no rate function is at once continuous on the unit directions, half-odd everywhere, and odd under reversal.  Local systems live on antipodal-free domains and never see that relation |

### Package G — stronger regularity (§57–§59)

| § | theorem | content |
| --- | --- | --- |
| 57 | `IsC1JointlyRegularFamily` | introduced only after the continuous classification is complete |
| 58 | `locFam_c1`, `c1_labels_unrestricted`, `c1_antipodalFree_admissible`, `c1_antipodal_pair_admissible`, `c1_overlap_same` | labels, domains and overlap factors are all unchanged |
| 59 | `c1_local_family_classification` | the `C¹` local classification **is** the continuous one (an equivalence, not a heuristic remark) |

---

## 5. Status table (§60, §61)

| entry | status | witness |
| --- | --- | --- |
| globally exact jointly regular representative | **REFUTED** | inherited `no_global_jointly_regular_transformationValued` |
| globally sign-relaxed jointly regular representative | **PROVED** (exists, unique) | inherited `reference_signTransformationValued`, `signValued_eq_reference` |
| local exact existence | **PROVED** | `task17_locFam_hypotheses` |
| local pointwise rate classification | **PROVED** (on arbitrary sets) | `task17_pointwise_rates` |
| domainwise rate constancy | **PROVED** on nonempty `Dom v` and on preconnected admissible sets; **REFUTED** without connectedness | `task17_beta_const_on_Dom`, `task17_label_const_of_preconnected`, `task17_label_not_const` |
| complete local-family exhaustion | **PROVED** | `task17_local_exhaustion`, `task17_local_classification` |
| admissible-domain classification | **PROVED** (exact criterion); antipodal pairs **not** an obstruction; antipodal-freeness sufficient; "contained in some `Dom v`" **REFUTED**; maximality of `Dom v` **REFUTED** | `task17_admissible_criterion`, `task17_antipodal_pair_admissible`, `task17_antipodalFree_admissible`, `task17_YDom_not_subset_Dom`, `task17_Dom_not_maximal` |
| overlap-factor classification | **PROVED** (central, unique, integer-labelled, multiplicative, direction-independent on preconnected overlaps) | `task17_overlap_central`, `task17_overlap_unique`, `task17_overlap_integer`, `task17_overlap_param_law`, `task17_overlap_direction_independent` |
| finite overlap-chain coherence | **PROVED** for arbitrary finite chains | `task17_overlap_chain3`, `task17_overlap_chain_finite` |
| reconstruction from local data | **REFUTED** (existence), **PROVED** (uniqueness), missing datum identified | `task17_no_reconstruction`, `task17_reconstruction_unique`, `task17_missing_datum` |
| stronger regularity | **PROVED** to add no restriction | `task17_c1_classification`, `task17_c1_labels`, `task17_c1_domains`, `task17_c1_overlap` |
| arbitrary spatial word problem | **OPEN** | untouched: no statement about arbitrary words of the visible family is made in Task 17 |

---

## 6. Corrections to Task-16 documentation (§62)

The following Task-16 prose is stronger than the Task-16 formal theorem it summarizes.
Each is corrected here; in each case Task 17 supplies the missing proof, or the corrected
statement.

1. *"the local families `locFam k` exhaust the admissible local choices, direction by
   direction"* (docstring of `local_rates`, `LocalRepair.lean`, and the corresponding
   sentence of the Task-16 audit).  The Task-16 theorem proves only the **pointwise** rate
   constraints `α n = 0`, `β n ∈ ℤ + 1/2`; it does not prove that the rate is the *same*
   half-odd number at different directions, nor that the family equals a model.  Both
   statements are proved for the first time in Task 17 (`beta_const_on_Dom`,
   `local_exact_eq_locFam`).
2. *"two local choices differ by a factor which is central, invertible, independent of the
   direction and uniquely determined"* (Task-16 Work-Package-5 summary).  In Task 16 this
   is proved only for the **explicit models** `locFam k`, `locFam l`, where
   direction-independence is immediate from the formula.  For arbitrary admissible local
   families it is proved in Task 17, and direction-independence then requires a
   **preconnectedness** hypothesis on the set where both families are exact
   (`ovl_direction_independent`); on a general admissible set the factor may vary with the
   direction, because the two labels may.
3. *"proper domains … cover every unit direction"* is correct, but the Task-16 wording
   *"the minimal local repair"* should not be read as an optimality statement: no Task-16
   theorem compares `Dom v` with other admissible domains.  Task 17 proves that `Dom v` is
   **not** maximal (`Dom_not_maximal`) and that the family `{Dom v}` is **not** exhaustive
   among admissible open connected domains (`YDom_not_subset_Dom`).
4. Task-16 prose describing the local transition data as "the discrete family indexed by
   `ℤ`" is accurate for the models; the Task-17 derivation shows the *integer* label of an
   overlap factor is the difference of two local labels and is determined only up to the
   choice of the two local representatives, which is why §50 (uniqueness) is stated
   relative to the inherited normalization.

---

## 7. Distinctions preserved (§63–§65)

* **Finite chains versus infinite coverings (§63).**  Everything proved about composition
  concerns chains of finite length (`ovl_chain3`, `chainOvl_eq`, the latter for arbitrary
  finite `N`).  No infinite product of transition factors is defined, and no statement in
  Task 17 quantifies over one.  Coverings by arbitrarily many domains occur only in
  `reconstruction_unique` and `local_data_do_not_reconstruct`, where the index type is
  arbitrary but **no product over it is formed**.
* **Many local domains versus an optimal domain class (§64).**  Existence of admissible
  domains is abundant (`antipodalFree_admissible`); optimality is *not* proved and is in
  fact refuted in both available directions (`Dom_not_maximal`, `YDom_not_subset_Dom`).
* **Local discrete labels versus interpretation (§65).**  A label is an integer attached to
  an explicit family on an explicit set of directions.  No interpretation of any kind is
  attached to it in any reconstruction statement; the only place where a reading is offered
  is the final comparison module, which nothing depends on.

---

## 8. Unresolved mathematical obligations

Stated honestly; none of these is used anywhere above.

1. **Exact characterization of admissible *connected* domains.**  The criterion
   `admissible_iff_exists_rate_function` is exact, but no purely geometric description of
   the admissible connected sets (e.g. in terms of antipodal distance) is proved.
2. **Maximal admissible domains.**  `Dom_not_maximal` shows the inherited domains are not
   maximal; the existence of maximal admissible domains, and any classification of them, is
   not addressed.
3. **Overlap factors on disconnected overlaps.**  Direction-independence is proved on
   preconnected overlaps.  On a general overlap the factor is central and uniquely
   determined pointwise, but no normal form across components is proved.
4. **Arbitrary spatial word problem.**  Untouched, as in Task 16.
5. **Regularity beyond `C¹`.**  Only the `C¹` layer is audited; higher smoothness or real
   analyticity of the rate functions is not considered (the models are constant, so no
   change is expected, but nothing is claimed).
6. **Non-normalized families.**  Everything assumes the inherited normalization `U n 0 =
   w1` and the one-axis group law; families violating either are outside the audit.

---

## 9. Source ledger

**IMPORTED STANDARD RESULT.**  Only the Mathlib declarations listed in §0 above; each is
used for elementary real analysis, elementary point-set topology, or arithmetic.

**INHERITED (Task 08 – Task 16 reconstruction layers).**  The carrier `W` with `⋆`, `w1`
and its exact centre `Z` with `Z_central`; `Vec3`, `h3`, `IsUnitAxis`, `exists_unit_orthogonal`;
`Un`, `Un_group`, `Un_mul_neg`, `Un_neg_axis`, `Un_right_cancel`; `PhiGen`,
`coincidence_neg_axis`, `coincidence_add_two_pi`, `coincidence_iff_coords`; `zexp`,
`zexp_injective`, `zexp_isCentralHom`, `zc`, `zc_mem_Z`; `IsAxisLift` and its inverse laws;
`IsRegularFamily`, `rateAlpha`, `rateBeta`, `regularFamily_param_spec`,
`regularFamily_param_unique`, `famOf`, `regular_family_arbitrary_parameters`;
`IsJointlyRegularFamily`, `jointlyRegular_beta_continuous`, `jointlyRegular_famOf`;
`IsTransformationValued`, `no_global_jointly_regular_transformationValued`;
`IsSignTransformationValued`, `signValued_eq_reference`, `refFam`, `refFam_jointlyRegular`,
`full_turn_forces`; `Dom`, `Dom_covers`, `IsTransformationValuedOn`, `locFam`,
`locFam_jointlyRegular`, `locFam_rates`, `locFam_transformationValuedOn`, `locFam_overlap`,
`overlap_defect_central`, `zexp_half_odd_smul`, `Un_smul_of_branch`, `zexp_zero_add`,
`zexp_zero_eq`.

**DERIVED IN TASK 17.**  Everything in §3 and §4 above.

---

## 10. Failed attempts that materially changed the construction

* An earlier plan proved domainwise constancy of the half-odd rate by appealing to a
  general "continuous integer-valued map on a connected space is constant" argument.  It
  was replaced by the intrinsic route required by §24: the explicit path of Package A, plus
  the intermediate value property applied to the single value `k + 1` lying strictly
  between two distinct half-odd numbers (`halfodd_const_of_preconnected`).
* The first attempt at §38 tried to *prove* that an antipodal pair obstructs local
  exactness.  Computing the two branch conditions showed the opposite: only the odd
  relation `β(-n) = -β(n)` is forced, which is satisfiable pointwise.  The statement was
  therefore turned into an explicit refutation with the rate function `b m = (1/2)·h3 m n`.
* The first §42 counterexample attempt used a union of three exact meridian arcs, which is
  path-connected but not open.  It was replaced by the three open wedges of `YDom`, whose
  defining functionals are all positive at `(0,0,1)`; this makes each leg star-shaped for
  the renormalized straight-line path, giving openness and path-connectedness at once.
* Direction-independence of the overlap factor was first stated without hypotheses; the
  two-point admissible domain shows this is false in general, so the statement was weakened
  to preconnected overlaps — this is correction 2 of §6.

Final repair path: the four items above; no other statement was weakened, and no statement
was strengthened after the fact.

---

## 11. Build and axiom report (§66–§68)

* `lake build` (whole project, including Tasks 01–16): **succeeds, 8213 jobs**.
* `lake build RequestProject.NullSectorTask17.Task17` (focused Task-17 build):
  **succeeds**.
* Mechanical scan of `RequestProject/NullSectorTask17/`: **no** `sorry`, **no** `admit`,
  **no** custom `axiom`, **no** `@[implemented_by]`, **no** `native_decide`, **no**
  `bv_decide`.
* No compiler warning is emitted by any Task-17 module.
* `#print axioms` for **all 43 principal endpoints** exposed by `Task17.lean` reports
  exactly

  ```
  [propext, Classical.choice, Quot.sound]
  ```

  and nothing else.  The endpoints are `task17_dom_rescaling`, `task17_dom_nonempty_iff`,
  `task17_dom_normalized_iff`, `task17_dom_antipodal_free`, `task17_dom_open`,
  `task17_dom_path`, `task17_dom_path_connected`, `task17_dom_connected`,
  `task17_pointwise_rates`, `task17_beta_const_on_Dom`, `task17_local_label_exists`,
  `task17_local_label_unique`, `task17_equal_rates_equal_families`,
  `task17_local_exhaustion`, `task17_locFam_hypotheses`, `task17_local_classification`,
  `task17_admissible_necessary`, `task17_antipodal_pair_admissible`,
  `task17_antipodalFree_admissible`, `task17_admissible_criterion`,
  `task17_label_const_of_preconnected`, `task17_label_not_const`,
  `task17_YDom_admissible_open_connected`, `task17_YDom_not_subset_Dom`,
  `task17_Dom_not_maximal`, `task17_overlap_central`, `task17_overlap_unique`,
  `task17_overlap_integer`, `task17_overlap_direction_independent`,
  `task17_overlap_param_law`, `task17_overlap_chain3`, `task17_overlap_chain_finite`,
  `task17_reconstruction_unique`, `task17_local_exact_not_sign_relaxed`,
  `task17_reference_not_locally_exact`, `task17_no_reconstruction`, `task17_missing_datum`,
  `task17_c1_labels`, `task17_c1_classification`, `task17_c1_domains`,
  `task17_c1_domains_antipodal`, `task17_c1_overlap`, `task17_comparison_local_pattern`.

---

## 12. Required final verdict

> Starting only from the Task-XVI jointly regular internal-representative framework, does
> local exact representability admit a complete intrinsic classification in terms of
> domains, discrete local labels, and compatible overlap data, and if so, which parts of
> that classification are forced rather than chosen?

**Yes for the local classification; no for the global assembly.**  Precisely:

* **Forced.**  On any admissible set of directions, exactness plus joint regularity forces
  `α = 0` and `β ∈ ℤ + 1/2` pointwise, and forces `β(-n) = -β(n)` on antipodal pairs
  contained in the set.  On any *preconnected* admissible set — in particular on every
  nonempty inherited `Dom v` — the half-odd value is forced to be **constant**, so a single
  integer label is forced, and the family is then forced to be exactly the model `locFam k`
  for that label, at every direction of the domain and every real parameter.  The relative
  factor between two such representatives is forced to be central, forced to be uniquely
  determined, forced to be the integer-labelled one-parameter central element, forced to be
  direction-independent on preconnected overlaps, and forced to compose along arbitrary
  finite chains.  Admissibility of an arbitrary direction set is forced to be equivalent to
  the existence of one continuous, half-odd-on-`D`, reversal-odd-on-`D` rate function.
* **Chosen.**  The label itself: every integer occurs, on every domain.  The domain: the
  inherited `Dom v` are neither maximal nor exhaustive; admissibility is a strictly larger
  and explicitly characterized class, which contains sets with antipodal pairs and
  connected open sets lying in no `Dom v`.
* **Impossible.**  Assembling the local data into a global object.  Even a covering system
  with *all* transition factors equal to the unit reconstructs no global sign-relaxed
  family; a locally exact family is never sign-relaxed, and the unique global sign-relaxed
  family is nowhere locally exact.  The obstruction is identified exactly and is not an
  overlap-compatibility defect: it is the reversal comparison, which no antipodal-free
  local datum can express.
* **Neutral to regularity.**  Requiring continuously differentiable rate functions changes
  none of the above.

The Conservation-of-Difficulty boundary therefore moves from "does a local exact
representative exist and what are its rates?" (Task 16) to the first genuinely unproved
requirements listed in §8 — chiefly a geometric description of admissible connected
domains, the existence of maximal admissible domains, and the arbitrary spatial word
problem.

No conventional topological or physical terminology is used as a substitute for any of the
statements above; the only place where such a reading appears is the comparison module,
which nothing depends on.
