# TASK04_AUDIT — Compatibility and gluing of all longitudinal 1+1 sectors inside 3+1 Lorentz space

Status labels used below:
`INPUT`, `DERIVED`, `FREE DATUM`, `DISCRETE CHOICE`, `CONTINUOUS FAMILY`,
`COUNTEREXAMPLE`, `OBSTRUCTION`, `COMPARISON ONLY`, `UNRESOLVED`.

---

## 1. Source ledger

### IMPORTED STANDARD RESULT (Lean / Mathlib)

Only routine algebra is imported. The exact declarations relied on are:

| Declaration | Mathlib module | Used for |
| --- | --- | --- |
| `LinearMap.mk₂` | `Mathlib/LinearAlgebra/BilinearMap.lean` | construction of bilinear maps (`mu4sym`, `altBasis`) |
| `LinearMap.BilinMap` | `Mathlib/LinearAlgebra/BilinearMap.lean` | carrier `BiProd4` of an unknown bilinear product |
| `LinearMap.ext`, `LinearMap.sub_apply`, `LinearMap.smul_apply`, `LinearMap.neg_apply`, `LinearMap.map_zero₂` | `Mathlib/Algebra/Module/LinearMap/Basic.lean` | bilinear bookkeeping |
| `LinearEquiv.prodCongr`, `LinearEquiv.refl` | `Mathlib/Algebra/Module/Equiv/Basic.lean` | lifting a spatial equivalence to `Vec4` (`liftRest`) |
| `sub_eq_zero`, `smul_eq_zero`, `two_smul`, `neg_neg`, `map_add`, `map_smul`, `map_neg`, `map_sub` | core algebra | routine rewriting |
| `Real.sqrt_pos`, `Real.sq_sqrt` | `Mathlib/Analysis/SpecialFunctions/Sqrt.lean` | normalizing a nonzero rest vector |
| `crossProduct`, `cross_apply` | `Mathlib/LinearAlgebra/CrossProduct.lean` | **comparison layer only** (§24) |
| tactics `ring`, `linarith`, `nlinarith`, `norm_num`, `simp`, `abel`, `module`, `linear_combination`, `field_simp`, `fin_cases` | Mathlib tactic library | routine goals |

### IMPORTED FROM TASKS 01–03

| Declaration | Module | Role |
| --- | --- | --- |
| `Vec4`, `Q4`, `Long`, `Q2` | `RequestProject.NullSectorTask01.Basic` | the ambient carrier and the two quadratic forms |
| `NullSectorTask02.BiProd`, `L2`, `u₀`, `s₀`, `AdmissibleAt` | `RequestProject.NullSectorTask02.LorentzData`, `.CandidateProduct` | the Task-02 formulation of an admissible longitudinal product |
| `NullSectorTask02.recU`, `recU_admissible`, `fixedUnit_unique`, `fixedUnit_commutative`, `fixedUnit_associative` | `RequestProject.NullSectorTask02.FixedUnit` | the **reconstructed** longitudinal product and its verified properties |

Nothing else from Tasks 01–03 enters the Task-04 core.

### DERIVED IN TASK 04

Everything else: see the theorem inventory in §7–§22 below.

---

## 2. Exact toolchain

| Item | Value |
| --- | --- |
| Lean toolchain | `leanprover/lean4:v4.28.0` (file `lean-toolchain`) |
| Mathlib | `v4.28.0`, commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (file `lake-manifest.json`) |
| Build target | library `RequestProject` (`lakefile.toml`, globs `RequestProject.+`) |
| Build command | `lake build` |

No dependency was upgraded, downgraded, or added.

---

## 3. Exact allowed imports from Tasks 01–03, and the import firewall

Task-04 **core** files and their `import` lines:

| File | Imports |
| --- | --- |
| `Lorentz4.lean` | `RequestProject.NullSectorTask01.Basic` |
| `RestSpace.lean` | `RequestProject.NullSectorTask04.Lorentz4` |
| `Sectors.lean` | `RequestProject.NullSectorTask04.RestSpace`, `RequestProject.NullSectorTask02.FixedUnit` |
| `GlobalExtension.lean` | `RequestProject.NullSectorTask04.Sectors` |
| `Classification.lean` | `RequestProject.NullSectorTask04.GlobalExtension` |
| `IdentityAudit.lean` | `RequestProject.NullSectorTask04.Classification` |
| `Isotropy.lean` | `RequestProject.NullSectorTask04.IdentityAudit` |
| `ProperIsotropy.lean` | `RequestProject.NullSectorTask04.Isotropy` |
| `Overlap.lean` | `RequestProject.NullSectorTask04.ProperIsotropy` |

Comparison layer (allowed to import more, used by nothing in the core):

| File | Imports |
| --- | --- |
| `Identification.lean` | `…Task04.Overlap`, `RequestProject.NullSectorTask01.SplitComplex`, `Mathlib.LinearAlgebra.CrossProduct` |
| `Task04.lean` | `…Task04.Overlap`, `…Task04.Identification` |

### Import-firewall report

Scanned the nine core files for
`Task01.SplitComplex`, `Task01.Boost`, `Task01.Strata`, `Task01.Limits`, `Task01.Task01`:
**no occurrences**. The Task-01 split-complex multiplication `mulL` is therefore
*not* used to define the Task-04 longitudinal product; `muLong` is the alias of
the Task-02 reconstruction `NullSectorTask02.recU`
(`NullSectorTask04.muLong`, `muLong_unique`).

### Terminology-firewall report

Scanned the nine core files for
`Jordan`, `SpinFactor`, `Clifford`, `GeometricAlgebra`, `Quaternion`, `Pauli`,
`crossProduct`/`CrossProduct`, `pseudoscalar`, `bivector`.

Documented occurrences (individually, no scanner weakening):

| Occurrence | File / lines | Assessment |
| --- | --- | --- |
| `JordanIdentity` (definition) and `mu4sym_jordan` (theorem) | `IdentityAudit.lean:29–30, 89–90` | **Documented false positive.** §18 of the task explicitly lists `JordanIdentity` as one of the identities that must be *tested*. It is a named equation `M (M (M X X) Y) X = M (M X X) (M Y X)`, written out in full; it is never used as a construction input, and no algebra is *defined* as a Jordan algebra anywhere in the core. |

No other occurrence. `Clifford`, `Quaternion`, `Pauli`, `bivector`,
`pseudoscalar`, `crossProduct`, `SpinFactor`, `GeometricAlgebra` do not occur in
any core file. They appear only in `Identification.lean` / `Task04.lean` /
this document, i.e. after the classification, marked `COMPARISON ONLY`.

---

## 4. Experiment-1 firewall statement

No source, theorem, terminology, formula, repository, paper, Lean declaration,
prompt, or result from Experiment 1 was used as input, target, or proof step.
The classification of §13–§17 below was obtained from the sector data alone by
explicit coordinate computation with half-turns and quarter-turns of the rest
space. The conventional names *spin factor*, *Jordan product* and *vector
product* appear only in `Identification.lean` and only after the core
classification had compiled; the comparison uses Mathlib's own
`crossProduct` and an independently written coordinate formula, and no
Experiment-1 material.

---

## 5. Derivation `Q4 → L4`

`DERIVED.` File `Lorentz4.lean`.

```
Q4 (t,x,y,z)   = t² - x² - y² - z²                (from Task01.Basic)
L4 X Y        := (Q4 (X+Y) - Q4 X - Q4 Y) / 2
```

| Result | Theorem | Status |
| --- | --- | --- |
| coordinate formula `L4 (t,x,y,z) (t',x',y',z') = t t' - x x' - y y' - z z'` | `L4_apply`, `L4_coord` | DERIVED |
| symmetry, biadditivity, bihomogeneity | `L4_symm`, `L4_add_left/right`, `L4_smul_left/right`, `L4_sub_*`, `L4_neg_*` | DERIVED |
| `L4 X X = Q4 X` | `L4_self` | DERIVED |
| **negative control:** `Q4` determines `L4` | `L4_unique_of_diagonal` | PROVED |
| nondegeneracy | `L4_nondegenerate` | DERIVED |
| `e₀ := (1,0,0,0)`, `Q4 e₀ = 1` | `e₀`, `Q4_e₀` | DERIVED |

`L4` is never an independent primitive.

---

## 6. Rest-space construction

`DERIVED.` File `RestSpace.lean`.

```
Rest    := { X | L4 e₀ X = 0 }        (submodule)
sp v    := (0, v)                     coordinate implementation
h X Y   := - L4 X Y
```

| Result | Theorem |
| --- | --- |
| `X ∈ Rest ↔ X.1 = 0` (equivalence of the two descriptions) | `mem_Rest`, `isRest_iff` |
| `Rest = range sp`, `X ∈ Rest → X = sp X.2` | `range_sp`, `rest_eq_sp` |
| `X = X.1 • e₀ + sp X.2` | `vec4_decomp` |
| `h (sp v) (sp w) = dot3 v w` (the ordinary 3-D dot product) | `h_sp` |
| `h X X = -Q4 X`, `0 ≤ h X X` on `Rest` | `h_self`, `h_nonneg` |
| equality characterization `h X X = 0 ↔ X = 0` on `Rest` | `h_eq_zero_iff` |
| coordinate directions `s₁ s₂ s₃`, `v = v₁ s₁ + v₂ s₂ + v₃ s₃` | `vec3_decomp` |

Packaged as `task04_rest_space`.

---

## 7. Longitudinal-sector theorem

`DERIVED.` File `Sectors.lean`.

```
UnitSpacelike s  :=  L4 e₀ s = 0  ∧  Q4 s = -1
iota_s (a,b)     :=  a • e₀ + b • s
```

| Result | Theorem | Status |
| --- | --- | --- |
| `UnitSpacelike s ↔ s ∈ Rest ∧ h s s = 1` | `unitSpacelike_iff` | PROVED |
| coordinate version `UnitSpacelike (sp v) ↔ dot3 v v = 1` | `unitSpacelike_sp_iff` | PROVED |
| every nonzero rest vector is a positive multiple of a unit direction | `exists_unitSpacelike_of_ne_zero` | PROVED |
| `Q4 (iotaS s X) = X.1² - X.2²  = Q2 X` | `Q4_iotaS`, `Q4_iotaS_Q2` | PROVED |
| polarized version `L4 (iotaS s X) (iotaS s Y) = L2 X Y` | `L4_iotaS` | PROVED |
| injectivity of `iotaS s` | `iotaS_injective` | PROVED |

The Task-02 product is transported, not redefined:
`muLong := NullSectorTask02.recU`, with `muLong_unique` recording that it is
*the* unique admissible product at `u₀`.
`sectorProd s X Y := iotaS s (muLong X Y)`.

Packaged as `task04_sector_embedding`, `task04_sector_product`.

---

## 8. Definition of sector compatibility

`INPUT.` File `GlobalExtension.lean`.

```
BiProd4               := LinearMap.BilinMap ℝ Vec4 Vec4      (bilinearity is in the carrier)
SectorCompatible M    := ∀ s, UnitSpacelike s → ∀ X Y : Long,
                            M (iotaS s X) (iotaS s Y) = iotaS s (muLong X Y)
```

No commutativity, associativity, unit, multiplicativity, or covariance is
assumed. Auxiliary named properties: `Commutative4`, `Associative4`,
`Q4Multiplicative`, `GlobalUnit`, and (in `IdentityAudit.lean`)
`LeftAlternative`, `Flexible`, `PowerAssoc3`, `PowerAssoc4`, `JordanIdentity`.

---

## 9. Global-unit status

**GLOBAL UNIT: DERIVED.**

| Result | Theorem |
| --- | --- |
| `M e₀ e₀ = e₀` | `M_e₀_e₀` |
| `M e₀ X = X` for all `X` | `M_unit_left` |
| `M X e₀ = X` for all `X` | `M_unit_right` |
| packaged | `M_globalUnit`, `task04_global_unit` |

Global unitality is *not* an axiom of Task 04: it follows from sector
compatibility of all longitudinal sectors together with bilinearity, because
every ambient vector lies in some longitudinal sector (`exists_sector_rep`).

---

## 10. Full extension classification

`Classification.lean`.

```
Defect  := Vec3 →ₗ[ℝ] Vec3 →ₗ[ℝ] Vec4
IsAlt A := ∀ v, A v v = 0                    (equivalently A v w = -A w v)
muOf A  := fun X Y ↦ mu4sym X Y + A X.2 Y.2
```

**Main classification (`sectorCompatible_iff`, packaged as `task04_classification`):**

```
SectorCompatible M   ↔   ∃ A : Defect, IsAlt A ∧ M = muOf A
```

with `defect_unique` (the datum `A` is unique) and
`muOf_sectorCompatible` (**converse**: every alternating `A` reconstructs a
sector-compatible product).

Status: `PROVED NON-UNIQUE` + `PROVED EXACT FAMILY`.
The free datum `A` is an alternating bilinear map `ℝ³ × ℝ³ → ℝ⁴`; its space has
real dimension `3 × 4 = 12` (an elementary dimension count, stated here for orientation; the Lean development characterizes the datum exactly but does not compute its dimension as a separate theorem). `FREE DATUM`.

---

## 11. Explicit nonuniqueness witness

`COUNTEREXAMPLE.` `sectorCompatible_not_unique`
(packaged as `task04_nonuniqueness`):

```
SectorCompatible mu4sym  ∧  SectorCompatible (muFam 1)  ∧  mu4sym ≠ muFam 1
```

The witnesses are extensionally different: evaluated on `sp s₁, sp s₂` they give
`0` and `E3 = (0,0,0,1)` respectively. `muFam lam := muOf (lam • altBasis)`.

---

## 12. Symmetric-part theorem

`DERIVED.` The symmetric part is forced and identical for every
sector-compatible product.

| Result | Theorem |
| --- | --- |
| `M (sp v) (sp v) = (dot3 v v) • e₀`, all rest vectors, not only unit ones | `M_rest_sq` |
| invariant form `X ∈ Rest → M X X = (h X X) • e₀` | `M_rest_sq'` |
| polarization: `M (sp v) (sp w) + M (sp w) (sp v) = (2 dot3 v w) • e₀` | `M_rest_symm` |
| full expansion of `M` | `M_expand` |
| `SymM M = mu4sym` | `symM_eq` |
| coordinate-free formula `mu4sym X Y = L4 X e₀ • Y + L4 Y e₀ • X − L4 X Y • e₀` | `mu4sym_coordfree` |
| coordinates: `mu4sym (a,v) (b,w) = (a b + v·w, a w + b v)` | `mu4sym_apply` |

The theorem of §11 of the prompt (`M v v = h(v,v) • e₀`) is therefore **true**,
proved from sector compatibility and bilinearity only, for arbitrary `v`.

---

## 13. Antisymmetric-defect theorem

`FREE DATUM.`

| Result | Theorem |
| --- | --- |
| `AltM M X Y = defectOf M X.2 Y.2` | `altM_eq` |
| the alternating part vanishes as soon as one argument is `e₀` | `altM_e₀` |
| `defectOf M` is alternating | `defectOf_isAlt` |
| `M = muOf (defectOf M)` | `eq_muOf_defect` |

So the entire remaining freedom is supported on `Rest × Rest → Vec4`, and it is
exactly alternating.

---

## 14. Converse reconstruction theorem

`PROVED.` `muOf_sectorCompatible : IsAlt A → SectorCompatible (muOf A)`.

This is the direction that distinguishes a genuine degree of freedom from an
artifact of an incomplete proof: *every* allowed `A` really does produce a
sector-compatible global product.

---

## 15. Commutative-extension classification

`PROVED UNIQUE.`

| Result | Theorem |
| --- | --- |
| `Commutative4 (muOf A) ↔ A = 0` | `commutative_iff_defect_zero` |
| `(SectorCompatible M ∧ Commutative4 M) ↔ M = mu4sym` | `sectorCompatible_comm_unique` |
| `SectorCompatible mu4sym` | `mu4sym_sectorCompatible` |
| `Commutative4 mu4sym` | `mu4sym_comm` |
| `GlobalUnit mu4sym`, proved directly | `mu4sym_globalUnit` |

Neutral name of the unique commutative branch: `mu4sym`. Its coordinate-free
formula (`mu4sym_coordfree`) was derived *before* any coordinate formula was
written down as a target, and no conventional name was attached at that stage.

---

## 16. Full-isotropy classification

`PROVED UNIQUE.` File `Isotropy.lean`.

```
Stabilizer R            := R e₀ = e₀ ∧ ∀ X, Q4 (R X) = Q4 X
IsotropyEquivariant M   := ∀ R, Stabilizer R → ∀ X Y, R (M X Y) = M (R X) (R Y)
```

Derived properties of a stabilizer (`task04_stabilizer_properties`):
`stab_L4`, `stab_time`, `stab_rest`, `stab_h`, `restOf_dot3`,
`stab_unitSpacelike`. No prepackaged identification with `O(3)` is used as a
proof step.

| Result | Theorem |
| --- | --- |
| the defect transforms equivariantly | `defect_equivariant` |
| a defect vanishing on the three coordinate pairs is zero | `defect_eq_zero_of_basis` |
| **full isotropy kills the defect** | `defect_zero_of_full_isotropy` |
| `(SectorCompatible M ∧ IsotropyEquivariant M) ↔ M = mu4sym` | `sectorCompatible_isotropy_unique` |
| `mu4sym` is itself equivariant | `mu4sym_isotropyEquivariant` |

The proof uses only the three coordinate reflections `fx`, `fy`, `fz`
(`stabilizer_fx/fy/fz`). Commutativity is *not* assumed: symmetry alone removes
the whole gluing freedom.

---

## 17. Proper-isotropy classification

`CONTINUOUS FAMILY` (exactly one real parameter). File `ProperIsotropy.lean`.

Orientation criterion, written out by hand (Leibniz formula in the spatial
coordinate basis):

```
alt3 v w  := (v₂w₃ - v₃w₂, v₃w₁ - v₁w₃, v₁w₂ - v₂w₁)
det3 c₁ c₂ c₃  := dot3 (alt3 c₁ c₂) c₃
detRest R      := det3 (restOf R s₁) (restOf R s₂) (restOf R s₃)
ProperStabilizer R := Stabilizer R ∧ detRest R = 1
```

Supporting pure polynomial identities: `alt3_self`, `dot3_alt3_left/right`,
`det3_rot1`, `det3_rot2`, `recip_expansion`, `alt3_of_rho`, `alt3_triple`,
`stab_columns`, `restOf_eq_rho`; from these, `alt3_proper`: a proper stabilizer
commutes with `alt3`.

| Result | Theorem | Status |
| --- | --- | --- |
| every `muFam lam` is proper-equivariant | `muFam_properEquivariant` | PROVED |
| translation of proper equivariance to the defect | `defect_properEquivariant` | PROVED |
| **the defect is a real multiple of `altBasis`** | `defect_proper_classification` | PROVED EXACT FAMILY |
| `(SectorCompatible M ∧ ProperIsotropyEquivariant M) ↔ ∃ lam, M = muFam lam` | `sectorCompatible_properIsotropy_classification` | PROVED EXACT FAMILY |
| `lam ↦ muFam lam` is injective (the family is one-dimensional, not degenerate) | `muFam_injective`, `properIsotropy_freedom_one_parameter` | PROVED |

The forward derivation uses only explicit rotations: the half-turns
`rxHalf`, `ryHalf`, `rzHalf` and the quarter-turns `rzQuarter`, `rxQuarter`,
each with `ProperStabilizer` and `detRest = 1` verified by direct computation
(`properStab_rxHalf`, …, `properStab_rxQuarter`). The half-turns force
`A s₂ s₃ ∈ ℝ E1`, `A s₃ s₁ ∈ ℝ E2`, `A s₁ s₂ ∈ ℝ E3`; the quarter-turns force the
three coefficients to be equal.

**Dimension:** exactly `1`. A basis was chosen (`altBasis`) *after* the
dimension statement was proved, and its coordinate formula is
`altBasis v w = (0, alt3 v w)`.

---

## 18. Orientation-reversal action

`DISCRETE CHOICE.`

| Result | Theorem |
| --- | --- |
| the third-coordinate reflection is an improper stabilizer, `detRest = -1` | `detRest_fz`, `not_properStabilizer_fz` |
| `liftRest fz (muFam lam X Y) = muFam (-lam) (liftRest fz X) (liftRest fz Y)` | `muFam_orientation_reversal` |

So orientation reversal acts on the surviving parameter by `lam ↦ -lam`;
the branch `lam = 0` is the unique fixed point, in agreement with §16.
Adding a spatial orientation therefore makes the *sign* of `lam` meaningful,
but does not by itself fix its magnitude (see §26 below).

---

## 19. Identity audit

For the independently reconstructed symmetric branch `mu4sym`
(`task04_identity_audit`):

| Property | Result | Theorem |
| --- | --- | --- |
| `Flexible` | PROVED | `mu4sym_flexible` |
| `PowerAssoc3` | PROVED | `mu4sym_powerAssoc3` |
| `PowerAssoc4` | PROVED | `mu4sym_powerAssoc4` |
| `JordanIdentity` | PROVED | `mu4sym_jordan` |
| `Associative4` | REFUTED BY EXPLICIT COUNTEREXAMPLE | `mu4sym_not_associative` |
| `LeftAlternative` | REFUTED BY EXPLICIT COUNTEREXAMPLE | `mu4sym_not_leftAlternative` |
| `Q4Multiplicative` | REFUTED BY EXPLICIT COUNTEREXAMPLE | `mu4sym_not_Q4Multiplicative` |

Sectorwise positives, valid for **every** sector-compatible `M`:
`sector_associative`, `sector_commutative`, `sector_qMultiplicative`.

---

## 20. Associativity result (cross-direction test)

`OBSTRUCTION.`

Counterexample triple, using two linearly independent spatial directions
`E1 = (0,1,0,0)` and `E2 = (0,0,1,0)`:

```
mu4sym (mu4sym E1 E2) E2 = mu4sym 0 E2 = 0
mu4sym E1 (mu4sym E2 E2) = mu4sym E1 e₀ = E1 ≠ 0
```

(`mu4sym_not_associative`; also packaged inside `task04_local_versus_global`,
which states in one theorem that every individual longitudinal sector of a
sector-compatible product **is** associative while the glued product is not.
This is the central local-versus-global distinction of Task 04.)

For the whole proper-isotropy family:
`muFam_not_associative (lam : ℝ) : ¬ Associative4 (muFam lam)` — for **every**
real `lam`. The exact obstruction extracted from the associator
`muFam lam (muFam lam E1 E2) E2` versus `muFam lam E1 (muFam lam E2 E2)` is the
real equation

```
-lam² = 1
```

(`muFam_associativity_equation`), which has no real solution.
`PROVED IMPOSSIBLE.`

---

## 21. Global norm-multiplicativity result

`OBSTRUCTION.`

* `SECTORWISE Q-MULTIPLICATIVITY`: PROVED, for every sector-compatible `M`
  (`sector_qMultiplicative`).
* `GLOBAL Q4-MULTIPLICATIVITY`: REFUTED. With `E1`, `E2` in two distinct
  spatial directions, `mu4sym E1 E2 = 0` so `Q4 (mu4sym E1 E2) = 0`, whereas
  `Q4 E1 · Q4 E2 = (-1)(-1) = 1` (`mu4sym_not_Q4Multiplicative`).
* For the whole family: `muFam_not_Q4Multiplicative (lam)` for every real `lam`;
  `Q4 (muFam lam E1 E2) = Q4 (lam • E3) = -lam²`, so the exact obstruction is
  again `-lam² = 1`. `PROVED IMPOSSIBLE.`

The global property is emphatically **not** inherited from the fact that every
longitudinal restriction possesses it.

---

## 22. Overlap-compatibility result

File `Overlap.lean`.

| Result | Theorem | Status |
| --- | --- | --- |
| the sector products agree wherever two sectors overlap | `sector_overlap_agreement` | PROVED |
| on the common timelike line, `sectorProd s (a,0) (b,0) = (a b) • e₀`, independently of `s` | `sector_overlap_timelike` | PROVED |
| for linearly independent spatial directions the overlap **is** the timelike line | `overlap_is_timelike_line` | PROVED |
| overlap agreement does **not** determine cross-sector multiplication | `overlap_does_not_determine_cross_sector` | REFUTED BY COUNTEREXAMPLE |

The last row is the required distinction: `mu4sym` and `muFam 1` are both
sector compatible — hence both satisfy every overlap agreement — yet they differ
already on the pair `(sp s₁, sp s₂)`.

---

## 23. Conservation-of-Difficulty graph

The graph below is the one the proofs actually produce.

```
3+1 Lorentz quadratic form  Q4                       [INPUT, Task01.Basic]
        │  polarization (unique: L4_unique_of_diagonal)
        ▼
symmetric bilinear form  L4                          [DERIVED]
        │  choice of a normalized future unit e₀
        ▼
rest space  Rest = ker (L4 e₀ ·)  and  h = -L4       [DERIVED, positive definite]
        │  every unit s ∈ Rest
        ▼
family of all longitudinal 1+1 embeddings  iota_s     [DERIVED, exact isometries]
        │  transport of the Task-02 reconstruction muLong
        ▼
sectorwise products  sectorProd s                     [IMPORTED from Task 02 + DERIVED transport]
        │  SectorCompatible M                          [INPUT]
        ▼
global two-sided unit e₀                              [DERIVED, not assumed]
forced symmetric part  mu4sym                         [DERIVED, unique]
        +
alternating cross-sector defect  A : ℝ³ ∧ ℝ³ → ℝ⁴     [FREE DATUM, dim 12]
        │
        ├── + Commutative4  ────────────► A = 0, M = mu4sym          [PROVED UNIQUE]
        ├── + full isotropy  ───────────► A = 0, M = mu4sym          [PROVED UNIQUE]
        └── + proper isotropy only ─────► A = lam • altBasis         [CONTINUOUS FAMILY, dim 1]
                                              │
                                              ├─ orientation reversal: lam ↦ -lam   [DISCRETE CHOICE]
                                              ├─ associativity:      -lam² = 1      [OBSTRUCTION]
                                              └─ global Q4-multipl.: -lam² = 1      [OBSTRUCTION]
```

No arrow requires an assumption beyond those listed on it. In particular the
arrow to the global unit requires *no* extra assumption, and no dynamical
notion enters anywhere.

### The eight audit questions of §31

1. **Does knowing every longitudinal 1+1 product determine multiplication
   between different spatial directions?** No. `sectorCompatible_not_unique`.
   It determines exactly the symmetric part (`symM_eq`).
2. **What is the exact missing datum?** An alternating bilinear map
   `A : Vec3 →ₗ Vec3 →ₗ Vec4` with `A v v = 0` (12 real parameters).
   `sectorCompatible_iff`, `defect_unique`.
3. **Is it removed by the full Lorentz stabilizer of `e₀`?** Yes, completely.
   `defect_zero_of_full_isotropy`, `sectorCompatible_isotropy_unique`.
4. **Does restricting to the proper stabilizer reintroduce orientation-sensitive
   freedom?** Yes: exactly one real parameter.
   `sectorCompatible_properIsotropy_classification`.
5. **Does orientation merely select a sign, or does a continuous coefficient
   remain?** A continuous coefficient remains; orientation reversal acts on it
   by `lam ↦ -lam` (`muFam_orientation_reversal`). None of the Task-04 inputs
   fixes its magnitude (`lam_selector_audit`).
6. **Can any allowed extension retain global norm multiplicativity?** No, for
   any real `lam` (`muFam_not_Q4Multiplicative`) and in particular not for the
   symmetric branch (`mu4sym_not_Q4Multiplicative`).
7. **Can any allowed extension be associative?** No, for any real `lam`
   (`muFam_not_associative`).
8. **Which identities does the forced symmetric product nevertheless satisfy?**
   Commutativity, two-sided unit, flexibility, power associativity in degrees 3
   and 4, and the Jordan identity. See §19.

### Answers to §30 A–F

* **A. From all longitudinal sector products alone.** Fixed: the global unit
  `e₀`, all pure spatial squares, the whole symmetric part `mu4sym`. Free: an
  alternating map on the rest space (12 real parameters).
* **B. After adding commutativity.** The whole alternating datum disappears;
  `M = mu4sym` uniquely.
* **C. After adding full isotropy covariance.** Again the whole datum disappears;
  `M = mu4sym` uniquely — with no commutativity assumption.
* **D. After adding only proper isotropy covariance.** Exactly one real
  parameter survives: `M = muFam lam`.
* **E. After adding a spatial orientation.** Orientation reversal acts by
  `lam ↦ -lam`; a spatial orientation therefore makes the sign of `lam`
  meaningful, but no Task-04 input makes any particular nonzero value canonical.
* **F. Associativity and global norm multiplicativity.** Neither is compatible
  with the four-dimensional real carrier and the reconstructed sector
  structure: both force `-lam² = 1`.

---

## 24. Late conventional identification — COMPARISON ONLY

File `Identification.lean`, imported by nothing in the core.

| Comparison | Theorem | Status |
| --- | --- | --- |
| the Task-02 reconstructed longitudinal product agrees with the Task-01 explicit split-complex multiplication | `muLong_eq_mulL` | COMPARISON ONLY |
| `mu4sym (a,v) (b,w) = (a b + v·w, a w + b v)`, i.e. the conventional commutative **spin factor / Jordan product** on `ℝ ⊕ ℝ³` | `mu4sym_eq_spinFactorProduct`, `mu4sym_is_jordan` | COMPARISON ONLY |
| the independently derived alternating operation `alt3` is Mathlib's `crossProduct` on `Fin 3 → ℝ` | `alt3_eq_crossProduct` | COMPARISON ONLY |
| consequently `muFam lam` is "spin factor plus `lam` times the vector product" | `muFam_comparison` | COMPARISON ONLY |

These names were attached only after the classification compiled; they are
outputs, never inputs, and Mathlib's `crossProduct` is used nowhere in the
derivation. No Clifford, geometric-algebra, quaternionic, matrix, spinorial or
complexified structure is introduced anywhere; the carrier remains `ℝ⁴` and the
scalar field remains `ℝ`.

---

## 25. Negative-control table (§38)

| Question | Classification | Theorem |
| --- | --- | --- |
| Does `Q4` determine `L4` by polarization? | PROVED | `L4_unique_of_diagonal` |
| Does every spatial direction produce an exact Task-02 1+1 sector? | PROVED | `Q4_iotaS_Q2`, `L4_iotaS`, `iotaS_injective`, `muLong_unique` (packaged: `task04_sector_embedding`, `task04_sector_product`) |
| Does sector compatibility imply a global unit? | PROVED | `M_globalUnit` |
| Does sector compatibility uniquely determine the global product? | PROVED NON-UNIQUE | `sectorCompatible_not_unique` |
| Is the symmetric part unique? | PROVED UNIQUE | `symM_eq`, `mu4sym_coordfree` |
| Is all remaining freedom alternating? | PROVED EXACT FAMILY | `sectorCompatible_iff`, `defectOf_isAlt`, `defect_unique`, `muOf_sectorCompatible` |
| Does commutativity remove all freedom? | PROVED UNIQUE | `sectorCompatible_comm_unique` |
| Does full isotropy remove all freedom? | PROVED UNIQUE | `sectorCompatible_isotropy_unique` |
| Does proper isotropy remove all freedom? | PROVED EXACT FAMILY (one real parameter) | `sectorCompatible_properIsotropy_classification`, `properIsotropy_freedom_one_parameter` |
| Does orientation reversal act nontrivially on any residual branch? | PROVED (`lam ↦ -lam`) | `muFam_orientation_reversal`, `detRest_fz` |
| Is the unique symmetric branch associative? | REFUTED BY COUNTEREXAMPLE | `mu4sym_not_associative` |
| Is it globally `Q4`-multiplicative? | REFUTED BY COUNTEREXAMPLE | `mu4sym_not_Q4Multiplicative` |
| Does it satisfy the Jordan identity? | PROVED | `mu4sym_jordan` |
| For the `M_λ` family, does any real `λ` yield associativity? | PROVED IMPOSSIBLE (`-λ² = 1`) | `muFam_not_associative`, `muFam_associativity_equation` |
| For the `M_λ` family, does any real `λ` yield global norm multiplicativity? | PROVED IMPOSSIBLE (`-λ² = 1`) | `muFam_not_Q4Multiplicative`, `muFam_associativity_equation` |
| Does overlap agreement already determine cross-sector multiplication? | REFUTED BY COUNTEREXAMPLE | `overlap_does_not_determine_cross_sector` |

### §26 scale question — exact equations imposed on `λ`

| Selector | Equation imposed on `λ` | Theorem |
| --- | --- | --- |
| sector compatibility | none (holds for all `λ`) | `muFam_sectorCompatible` |
| proper isotropy | none (holds for all `λ`) | `muFam_properEquivariant` |
| full isotropy | `λ = 0` | `lam_selector_audit` |
| commutativity | `λ = 0` | `lam_selector_audit` |
| associativity | `-λ² = 1` (no real solution) | `muFam_associativity_equation` |
| global `Q4`-multiplicativity | `-λ² = 1` (no real solution) | `muFam_associativity_equation` |

---

## 26. Build report

```
$ lake build
Build completed successfully (8054 jobs).
```

No `sorry`, no `admit`, no `axiom` declaration, no `@[implemented_by]` anywhere
in `RequestProject/`. Warning-free.

Task-04 files:

```
RequestProject/NullSectorTask04/Lorentz4.lean
RequestProject/NullSectorTask04/RestSpace.lean
RequestProject/NullSectorTask04/Sectors.lean
RequestProject/NullSectorTask04/GlobalExtension.lean
RequestProject/NullSectorTask04/Classification.lean
RequestProject/NullSectorTask04/IdentityAudit.lean
RequestProject/NullSectorTask04/Isotropy.lean
RequestProject/NullSectorTask04/ProperIsotropy.lean
RequestProject/NullSectorTask04/Overlap.lean
RequestProject/NullSectorTask04/Identification.lean      (COMPARISON ONLY)
RequestProject/NullSectorTask04/Task04.lean              (principal theorems + axiom report)
```

---

## 27. Axiom report

`Task04.lean` ends with `#print axioms` for each principal theorem. Every one
reports exactly

```
[propext, Classical.choice, Quot.sound]
```

i.e. only the three standard Lean/Mathlib foundational axioms. No
project-specific assumption, and no `sorryAx`.

Principal theorems audited:
`task04_polarization`, `task04_rest_space`, `task04_sector_embedding`,
`task04_sector_product`, `task04_global_unit`,
`task04_spatial_squares_and_symmetrization`, `task04_classification`,
`task04_symmetric_and_antisymmetric_parts`, `task04_nonuniqueness`,
`task04_commutative_classification`, `task04_full_isotropy_classification`,
`task04_stabilizer_properties`, `task04_proper_isotropy_classification`,
`task04_orientation_reversal`, `task04_parameter_selectors`,
`task04_identity_audit`, `task04_local_versus_global`,
`task04_family_obstructions`, `task04_overlap`, `task04_identification`.

---

## 28. Unresolved mathematical obligations

1. **Magnitude of `λ`.** No Task-04 input selects a nonzero magnitude for the
   surviving parameter; sector compatibility and proper isotropy impose no
   equation on it at all, and the two natural selectors (associativity, global
   `Q4`-multiplicativity) are outright impossible. Whether some further
   *kinematic* condition inside the real 3+1 carrier could fix `|λ|` is left
   open; nothing in Task 04 asserts or denies it.
2. **Varying the timelike unit.** The whole development fixes
   `e₀ = (1,0,0,0)`. Compatibility of the classification with a simultaneous
   change of the timelike unit and the spatial directions — i.e. full Lorentz
   covariance of the family `{muFam λ}` — is deliberately outside the Task-04
   core (§3 of the task) and is not proved here.
3. **Stabilizer generation.** The full-isotropy and proper-isotropy
   classifications use *specific* stabilizer elements (three reflections; three
   half-turns and two quarter-turns). That these generate the corresponding
   stabilizer groups is not proved and is not needed: the classifications are
   stated as equivalences and both directions are proved (the reverse direction
   for the full group, the forward direction using only the exhibited elements),
   so no gap arises.
4. **Degenerate directions.** The classification ranges over unit spacelike `s`
   only, as prescribed. Null directions are not considered; they do not give a
   nondegenerate 1+1 sector and are outside the stated problem.
