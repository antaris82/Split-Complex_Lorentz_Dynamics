# Summary of changes for run 8a3d7b9e-21c6-4236-9292-16717313ab16
Task 10 is complete: the formal development, both documents, and the audit are finished, and everything is committed.

## Formal development

Twelve new modules under `RequestProject/NullSectorTask10/`, chain-imported in the suggested order (`SafeBase → AxisDecomposition → OldAxialRotation → AlgebraExtension → VectorChannels → InternalLift → StateAction → HalfAngleSectors → AxialDerivation → DynamicsDiagnostic → Identification → Task10`). The only import outside Task 10 is a single inherited Task-09 module, recorded in the import ledger.

`Task10.lean` exposes 21 principal theorems answering the twelve Conservation-of-Difficulty questions:

1. **Axis decomposition** — the distinguished axis splits the old rest space as an internal direct sum of a longitudinal line and a transverse plane.
2. **Old axial rotation** — one-parameter group, fixes the time direction and the axis, preserves the inherited quadratic form.
3. **Algebra extension** — exists and is *unique*; the complete action on all eight inherited basis elements is derived from multiplication, not prescribed. Both inherited central norm branches are preserved separately (neither is declared preferred), and the extension is the identity at 2π.
4. **Channels** — the longitudinal line is fixed pointwise; exactly two transverse central channels exist, with mutually inverse central factors.
5. **Internal lift** — sought only after the algebra action was classified, found inside the derived two-plane spanned by the unit and the transverse element `R`. The half angle is *derived* from the group law plus the conjugation action; it is not assumed.
6. **Lift non-uniqueness** — honoring your instruction, the free multiplicative scalar factor `k(θ)` is *not* eliminated by any added normalization. The exact classification keeps it free in both directions, a second genuinely different lift is exhibited, and the general periodicity statement gives only the forced sign pattern. The sharp `U(2π) = −1` is stated for the distinguished representative, or under an explicitly carried, separately derived branch-preservation hypothesis.
7. **2π / 4π** — proved for the lift and, generally, for every lift up to the surviving scale.
8. **Algebra versus state action** — the conjugation action is already the identity at 2π, while the candidate-state left action sends ψ to −ψ there and back to ψ at 4π; the two are proved to differ at 2π on every nonzero element.
9. **Half-angle sectors** — the solution spaces of `R ψ = ± S ψ` each have real dimension 4 (central dimension 2), intersect trivially, span the carrier, split into two central lines each, and transform with the transverse vector factor at exactly half the angle.
10. **Transverse state orientation** — proved *not* selected by the present data: an explicit counterexample shows the analogous condition along a transverse generator is not preserved by the state action.
11. **Axial derivations** — the structure-preserving solution space is exactly one-dimensional, uniquely normalized by the orientation convention, with an intrinsic half-commutator formula and identified as the derivative of the algebra action at 0.
12. **Rate freedom** — every real multiple satisfies the same conditions and distinct multiples differ, so the structure fixes the generator *direction* but no evolution rate.

A separate final module carries the conventional comparison, every statement labelled COMPARISON ONLY, including the spin-1 and spin-1/2 diagnostics and the physical-interpretation firewall. The recorded verdict is Outcome C with an Outcome E component, plus the proved refinement that the lift is not unique.

## Verification

`lake build` → "Build completed successfully (8120 jobs)", with no errors and no linter warnings, and no linter disabled. No `sorry`, `admit`, custom `axiom`, or `@[implemented_by]` anywhere in the project. All 21 principal theorems report exactly `[propext, Classical.choice, Quot.sound]`.

## Documentation

`TASK10_AUDIT.md` (new) contains all 22 required sections, including both firewall reports, the complete basis-action table, the 2π/4π comparison table, the Conservation-of-Difficulty graph, the source ledger separating IMPORTED STANDARD RESULT from DERIVED IN TASK 10, the build and axiom reports, and seven explicitly stated unresolved obligations — the first of which records the surviving lift-scalar freedom as an open point rather than papering over it. `README.md` was extended with the Task-10 summary, module layout, build target, and audit link. `ARISTOTLE_SUMMARY.md` was not modified.


# Summary of changes for run 80f0a8fc-6afd-439e-b1c6-02bcc859e881
Task 09 is complete: the formal development, both documents, and all reports are in place, and the whole project builds with no `sorry`, `admit`, or custom axiom.

**Formal development** — ten modules under `RequestProject/NullSectorTask09/`, in a strict single-import chain:
`SafeBase → RealScalarNoGo → CentralPlane → UnknownQuadraticMap → Rigidity → Existence → ExactClassification → CentralSignAudit → Identification → Task09`.

Results proved:

* **Scalar negative control.** No real-valued map on the fixed Task-08 associative carrier can be simultaneously quadratic, multiplicative, and equal to the inherited Lorentz form on every embedded old vector. The minimal obstruction uses only degree-two homogeneity, multiplicativity, and the three inherited values `−1` on the embedded old spatial directions, tested on the single element `1 + S`; the exact incompatible equations are recorded. Bilinearity of the polarization and the value on the unit are not needed.
* **Central plane.** `Z = spanℝ{1,S}` is derived inside the unchanged carrier and proved closed under the inherited product, commutative, central in the whole carrier, of exact real dimension 2, with a unique normal form `a·1 + b·S` and a fully derived internal multiplication rule.
* **Rigidity before existence.** For an entirely unknown admissible map into `Z`, all eight basis values are forced (all into the real line inside `Z`), and the complete 8×8 polarization ledger is derived; exactly one entry, `BN(1,S)`, is undetermined, and it is proved to satisfy `d ⋆ d = −4·1`, hence `d = ±2·S`. Every admissible map is determined by that single datum. No explicit candidate appears before this theorem.
* **Existence and classification.** Two explicit maps, written only in the independently derived basis coordinates, are proved quadratic, multiplicative for *arbitrary* `x y` in the carrier, and equal to the inherited form on *arbitrary* old vectors. The solution space is exactly two elements — discrete freedom, a single sign.
* **Image controls.** No admissible map has image inside the real line, and every admissible map attains a nonzero `S` component.
* **Sign audit.** The map `1 ↦ 1`, `S ↦ −S` preserves the induced multiplication of `Z` and exchanges the two solutions, fixing neither; the same exchange is induced by the transposition of two derived spatial generators, so the residual ambiguity tracks the sign freedom already present in Task 08.
* **Verdict.** `PART-VI Q4 MULTIPLICATIVITY OBSTRUCTION RESOLVED AFTER CODOMAIN ENLARGEMENT` — the product carrier and generators were untouched; only the codomain moved from the real scalars to the internally derived central plane.

**Firewalls.** The reconstruction core imports exactly one Task-08 module (`FullVec4Embedding`); the Task-08 conventional identification enters only in `NullSectorTask09/Identification.lean`, imported solely by `Task09.lean`, where all statements are labelled COMPARISON ONLY. A mechanical word scan of the eight reconstruction modules for the forbidden target-structure names returns only docstring occurrences inside the firewall notes plus one genuine code hit, which is disclosed rather than suppressed: `Matrix.range_cons` / `Matrix.range_empty` in `CentralPlane.lean`, used only because Lean's two-element tuple notation lives in that namespace, needed for the dimension lemma. No matrix, determinant or complex scalar is involved. No Experiment-1 material is used.

**Build and axioms.** `lake build` completes successfully (8108 jobs). All 21 principal `task09_*` theorems report exactly `[propext, Classical.choice, Quot.sound]`. A repository-wide search finds no `sorry`, `admit`, `axiom` declaration, or `@[implemented_by]`.

**Documentation.** `TASK09_AUDIT.md` (new) contains all 28 required sections plus a Conservation-of-Difficulty appendix answering the eleven audit questions, the negative-control table, and a status-vocabulary index. `README.md` gains a Task-09 summary, the file layout, the firewall note, the build command, the audit link, and a literature-calibration paragraph separating the mathematical structure (standard) from the reconstruction methodology (no novelty claimed). `ARISTOTLE_SUMMARY.md` was read but not modified.

Unresolved obligations are listed in §28 of the audit: minimality of the codomain among all real subalgebras is not settled (only the two codomains the task specified were tested, in the specified order); positivity, zero sets and fibres are out of scope; whether a still smaller hypothesis set produces the scalar obstruction is open; non-quadratic multiplicative maps are not analysed.

# Summary of changes for run f1e4ddfc-ab30-4d3c-87a6-cd2c3a9cac29
Task 08 is complete. The formal development, documentation, firewall/source-order reports, build report, axiom report and unresolved-obligation list are all in the project.

**Lean development** — sixteen new modules under `RequestProject/NullSectorTask08/`, forming a strict single-predecessor import chain that enforces the required derivation order:
`SafeBase → ThirdDirection → InheritedRelations → NewMixedProducts → ForcedRelations → Membership → Independence → GeneratedClosure → Minimality → StructuralDiagnostic → DirectWitness → FullVec4Embedding → Uniqueness → SignPermutationAudit → Identification → Task08`.

**Derived results (Outcome C).** Exactly one third inherited orthogonal spatial generator `C` is added. From the inherited square law alone, `C ⋆ C = 1`; from polarization plus the inherited orthogonality relations, the pairwise anticommutation of `A, B, C`. Only afterwards are `Q := A⋆C`, `R := B⋆C`, `S₃ := (A⋆B)⋆C` defined; all their parenthesizations, mutual products, products with `A, B, C, P`, and squares (`Q² = R² = S₃² = −1`) are derived. `Q, R, S₃` lie outside the embedded original carrier (`C` does not — it is an embedded old vector), and `C, Q, R, S₃` all lie outside the previously reconstructed two-generator closure, each by a direct structural argument rather than a dimension count. The eight elements `1, A, B, C, P, Q, R, S₃` are linearly independent in *every* ambient extension; their span `G₃` is multiplicatively closed, has a unique eight-coefficient normal form, `finrank ℝ G₃ = 8`, and is minimal among product-closed subspaces containing the unit and the three generators (with the corresponding word-reduction theorem). `S₃` commutes with every derived generator and is central in `G₃`, with `S₃² = −1`. The complete 64-entry multiplication table is collected only after closure, every entry citing an earlier theorem.

**Witness and the critical embedding.** A fresh eight-dimensional real carrier (`Fin 8 → ℝ`) with an explicit coefficient product transcribed from the derived table is proved bilinear, unital, associative, and to satisfy all derived relations. The complete original `Vec4` embeds into it linearly and injectively; the inherited old square law holds for *every* embedded old vector, and polarization recovers the full inherited symmetric product. Hence an associative ambient extension of the whole old carrier preserving the inherited square law exists — the previously open full-ambient existence obligation is **resolved positively**. Uniqueness up to a generator-preserving, unit-preserving, multiplicative linear equivalence is proved, as is uniqueness of the product given the table. Sign and permutation diagnostics are derived (not assumed). A separate late module, labelled COMPARISON ONLY and imported by nothing but the top-level file, gives an explicit real-linear unital multiplicative bijection onto the algebra of 2×2 complex matrices.

**Verification.** `lake build` completes with 8098 jobs, zero errors and zero warnings. No `sorry`, `admit`, custom `axiom`, or `@[implemented_by]` occurs anywhere in the project. All twenty-four principal theorems report exactly `[propext, Classical.choice, Quot.sound]`. Mechanical firewall scans confirm: no Task-05 module anywhere, no Task-07 identification layer reachable from the reconstruction core, and zero occurrences of any conventional target-structure name in the fourteen reconstruction modules.

**Documentation.** `TASK08_AUDIT.md` contains all thirty required sections, including the exact toolchain (Lean 4.28.0, Mathlib `8f9d9cff6bd728b17a24e163c9402775d9e6a365`), source and import ledgers, both firewall reports, the source-order report, the full forced-relation ledger and multiplication table, the negative-control table with exact theorem names, the thirteen Conservation-of-Difficulty answers, the derived dependency graph, the build and axiom reports, and the unresolved obligations. `README.md` gains the Task-08 layout, firewall note, build command and audit link. `ARISTOTLE_SUMMARY.md` was read but not modified.

# Summary of changes for run cfbefbdb-6c5f-4448-bfb4-711535634ef7
Task 07 is complete: a new Lean development under `RequestProject/NullSectorTask07/` (14 modules), plus `TASK07_AUDIT.md` and an updated `README.md`. The whole project builds cleanly (`lake build`, 8050 jobs, no errors and no warnings), contains no `sorry`, `admit`, custom `axiom` or `@[implemented_by]`, and every principal theorem reports exactly `[propext, Classical.choice, Quot.sound]`.

**Inherited base.** `SafeBase.lean` imports exactly one earlier module (the Task-06 associativity-obstruction layer, hence only the uncontaminated Task-01/02/04/06 chain; no late identification module is reachable). It introduces the neutral name `oldSq` and proves `sectorCompatible_sq`: every sector-compatible product on the original carrier has this same diagonal, with `oldSq (t,v) = (t² + h(v,v), 2t·v)` and nonnegative time component. The Task-06 no-go is restated as an input motivation and is used in no Task-07 proof.

**Derivation chain (all conditional on an arbitrary ambient extension).** `AmbientExt` bundles an arbitrary real vector space with an associative unital bilinear product, an injective linear embedding of the original carrier sending the future unit to the ambient unit, and retention of the inherited square law; the image of the embedding is *not* assumed closed. Results, in strict source order:
* polarization recovers the whole inherited symmetric product after embedding (not assumed separately);
* the two selected orthogonal spatial directions satisfy `A⋆A = 1`, `B⋆B = 1`, `A⋆B + B⋆A = 0`;
* only then is `P := A⋆B` defined, and the nine forced relations derived, including `P⋆P = −1`;
* `oldSq X ≠ −e₀` for every `X` (transparent coordinate proof), whence `P ≠ 0` and `P ∉ range ι` — proved locally from injectivity, the retained square law, the derived `P⋆P` and real positivity, not from the global no-go;
* `1, A, B, P` are linearly independent (using independence of `e₀, a, b` as well);
* the span `G` has a unique four-coefficient normal form, is closed under the ambient product with an explicitly derived coefficient law, and `finrank ℝ G = 4`;
* every product-closed subspace containing the unit and the two generators contains `P`, hence all of `G` (minimality), with the equivalent word-reduction statement;
* the full 16-entry multiplication table is collected only after closure.

**After the classification:** a fresh four-dimensional carrier with the product taken from the derived coefficient law is proved bilinear, unital, associative and to satisfy exactly the derived relations (the derivation modules do not import it); the derived table determines the product uniquely, and the closures of any two ambient extensions are isomorphic by a generator-preserving, unit-preserving, multiplicative linear equivalence; generator exchange and either single sign flip send `P ↦ −P`, a simultaneous flip fixes it. A separate late module, labelled COMPARISON ONLY and imported only by the top-level module, identifies the derived algebra with the algebra of 2×2 real matrices by an explicit bijective linear multiplicative unital map.

**Outcome: C** — `P` must leave the old carrier, and one new direction gives a finite minimal associative closure of dimension exactly four. A mechanical scan of the twelve reconstruction modules for conventional target-structure names returns zero hits; no third spatial direction, no norm, conjugation or involution is introduced.

**Unresolved obligation (recorded in the audit):** non-vacuity of the *full* ambient hypothesis set is not established, because exhibiting an extension of the entire four-dimensional carrier would require a third rest-space generator, which the task's firewall forbids here; what is proved unconditionally is that the derived two-generator relation system is consistent, via the four-dimensional witness.

# Summary of changes for run 442e317d-6753-4add-a7ca-1a7b7c4ada29
Task 06 is complete: the full Lean development, the audit document, and the README update are in the project, the whole project builds cleanly, and nothing depends on `sorry`, `admit`, or a custom axiom.

**Formal development** — 14 new modules under `RequestProject/NullSectorTask06/` (`SafeBase`, `GenericExtension`, `ProperAction`, `UnknownDefect`, `Rigidity`, `Existence`, `ExactClassification`, `OrientationReversal`, `Identification`, `Task04Comparison`, `AssociativityObstruction`, `NormObstruction`, `UniversalObstructionSummary`, `Task06`), with 19 principal `task06_*` theorems collected in `Task06.lean`.

**Phase A — clean-room gluing classification.**
* The generic extension theorem was re-derived from scratch in a clean module: a bilinear product is sector-compatible iff it is the forced symmetric product plus a uniquely determined alternating rest-space defect, with the defect's codomain left as the full 3+1 carrier.
* Orientation-preserving isotropy was defined intrinsically from the Lorentz stabilizer of the chosen future unit together with an explicit determinant criterion; explicit half-turns, quarter-turns and cyclic transformations were constructed and used as the only symmetry input.
* Starting from an entirely unknown alternating defect, the rigidity stage derives: the temporal output component must vanish; the three basis-pair values are forced to be `c` times the corresponding rest directions for a single real parameter `c`; and the defect vanishes when that parameter is zero.
* Only after rigidity is an explicit nonzero witness constructed (first occurrence: `wit3` in `Existence.lean`), proved alternating, proper-equivariant and nonzero.
* The exact solution space is then proved to be the span of that witness, together with an explicit linear equivalence `ℝ ≃ₗ[ℝ] ProperSolutions`, i.e. exactly one continuous real degree of freedom; the coordinate formula is derived afterwards from the basis-pair classification, bilinearity and alternation.
* Orientation reversal is proved to act by `c ↦ −c`, so the only fully-isotropy-invariant defect is zero, which forces the sector-compatible product to be unique under full isotropy.
* Late layers only: comparison with the standard library operation (labelled COMPARISON ONLY) and comparison with the previously contaminated Task-04 modules. Verdict: **TASK04 PROPER-ISOTROPY RESULT REPLICATED** — the earlier methodological defect did not alter the mathematical classification, which has now been independently reconstructed under the stronger blind firewall.

**Phase B — universal obstruction probe** (depends only on the safe base and the generic extension layer, with no symmetry assumption).
* Global associativity is **universally impossible** for every sector-compatible bilinear product.
* Global multiplicativity of the 3+1 quadratic form is **universally impossible**, proved separately and independently.
* Both obstructions already appear with only two orthonormal rest directions: associativity forces a sum of real squares to equal `−1`, and norm multiplicativity forces the temporal part of the mixed product to vanish and then a rest-space square to equal `−1`. The obstructions are shown to persist under any additional hypothesis, in particular any isotropy assumption; the joint statement is recorded only as a summary. No repair, carrier enlargement or successor task is proposed.

**Documentation** — `TASK06_AUDIT.md` (33 sections: toolchain, source ledger, allowed inherited declarations, rejected modules, Experiment-1 / terminology / structural-witness / source-order firewall reports, rigidity results, solution-space classification, first-witness location, coordinate formula, orientation reversal, full isotropy, identification, Task-04 comparison and replication verdict, both universal obstructions with their exact incompatible equations, updated dependency graph, diagnostic handoff, negative-control table, build report, axiom report, unresolved obligations) and a new Task-06 section in `README.md`. `ARISTOTLE_SUMMARY.md` was left untouched.

**Verification** — `lake build` completes successfully (8068 jobs); a repository-wide scan finds no `sorry`, `admit`, `axiom` declaration or `@[implemented_by]`; the terminology scan over all eleven reconstruction and Phase-B modules returns zero hits; and all 19 principal theorems report exactly `[propext, Classical.choice, Quot.sound]`.

# Summary of changes for run 8de20cc6-2f0b-4f91-aa3f-bf8807752889
Task 04 is complete: the Lean development, documentation, firewall reports and audit are all in place, and `lake build` succeeds with no `sorry`, no `admit`, no custom axiom, and no warnings.

## Formal development

New modules under `RequestProject/NullSectorTask04/` (core chain, 9 files):
`Lorentz4 → RestSpace → Sectors → GlobalExtension → Classification → IdentityAudit → Isotropy → ProperIsotropy → Overlap`, plus `Identification.lean` (comparison only) and `Task04.lean` (principal theorems + `#print axioms`).

Main results, all theorem-backed:

* **`Q4 → L4`** derived by polarization, with the exact coordinate formula, `L4 X X = Q4 X`, and uniqueness of the polarization (`task04_polarization`).
* **Rest space** of `e₀` defined by `L4`-orthogonality; the induced form `h = -L4` is derived, shown positive semidefinite, definite, and equal to the ordinary dot product in coordinates (`task04_rest_space`).
* **Every unit spatial direction** gives an exact 1+1 Lorentz embedding, into which the previously reconstructed longitudinal product (not the explicit split-complex formula) is transported (`task04_sector_embedding`, `task04_sector_product`).
* **GLOBAL UNIT: DERIVED** — sector compatibility alone forces `e₀` to be a two-sided unit (`task04_global_unit`).
* **Pure spatial squares** and the **symmetric cross-sector combination** are completely forced, for arbitrary rest vectors (`task04_spatial_squares_and_symmetrization`).
* **Exact if-and-only-if classification:** a bilinear product is sector compatible iff it is a uniquely forced symmetric branch `mu4sym` plus an alternating rest-space defect; the defect is unique, and the **converse** holds — every alternating defect reconstructs a sector-compatible product (`task04_classification`, `task04_symmetric_and_antisymmetric_parts`). `mu4sym` has the coordinate-free form `L4 X e₀ • Y + L4 Y e₀ • X − L4 X Y • e₀`.
* **Explicit nonuniqueness witness** with a genuinely nonzero defect (`task04_nonuniqueness`).
* **Commutativity** removes all freedom (unique product); **full isotropy** removes all freedom too, with no commutativity assumption (`task04_commutative_classification`, `task04_full_isotropy_classification`).
* **Proper isotropy** leaves exactly a one-real-parameter family `muFam λ`, with injective parameterization; **orientation reversal** sends `λ ↦ −λ` (`task04_proper_isotropy_classification`, `task04_orientation_reversal`). The classification is proved from explicit half-turns and quarter-turns and a hand-written orientation determinant.
* **Identity audit:** flexible, power associative (degrees 3 and 4) and Jordan — PROVED; associative, left alternative, globally `Q4`-multiplicative — REFUTED by explicit counterexamples using two independent spatial directions. For the whole family, associativity and global norm multiplicativity each force `−λ² = 1`, impossible over ℝ (`task04_identity_audit`, `task04_family_obstructions`).
* **Local versus global:** every longitudinal sector of a sector-compatible product is associative, commutative and norm-multiplicative, while the glued product is none of these (`task04_local_versus_global`).
* **Overlaps:** sector products agree on every overlap, but overlap agreement does not determine cross-sector multiplication (`task04_overlap`).
* **Late identification (COMPARISON ONLY):** after the classification compiled, `mu4sym` is identified with the conventional spin-factor/Jordan product and the derived alternating operation with the conventional three-dimensional vector product (`task04_identification`).

## Firewalls

The nine core files import only `NullSectorTask01.Basic` and `NullSectorTask02.FixedUnit`; a mechanical scan finds no occurrence of the earlier split-complex/boost/strata/limits modules, and the only terminology hit is `JordanIdentity`, which the task itself asks to be *tested* — documented individually in the audit, with no scanner weakening. No carrier enlargement, complexification, or Clifford-style repair was attempted.

## Documentation

* `TASK04_AUDIT.md` — all 27 required sections, plus the negative-control table with exact theorem names, the parameter-selector equations, the Conservation-of-Difficulty graph, the §30 A–F answers, the import- and terminology-firewall reports, the build report and the axiom report.
* `README.md` — updated with the Task-04 summary, file layout, firewall note, build commands and audit link.

## Axiom report

Every principal theorem reports exactly `[propext, Classical.choice, Quot.sound]`.

## Unresolved obligations (recorded in the audit)

The magnitude of the surviving parameter `λ` is fixed by none of the Task-04 inputs; varying the timelike unit together with the spatial direction is outside the Task-04 core; group generation by the exhibited stabilizer elements is not proved and is not needed, since both directions of each classification are established.


# Summary of changes for run e65666e4-8611-42a9-9e02-9cab6d32b0d5
Task 03 is complete: the whole project now builds cleanly with no `sorry`, no `admit`, and no custom axiom.

**What was finished in this session**

- Completed and repaired the Task-03 core (`RequestProject/NullSectorTask03/Core.lean`) so that it compiles: qualified the ambiguous `compl` name, rewrote the companion classification and the proper/improper transport-of-companion proofs, fixed the unordered-null-pair case analysis, and removed leftover no-op tactics. The file now compiles with zero errors and zero linter warnings.
- Completed `RequestProject/NullSectorTask03/Task03.lean` (late Task-01 comparison layer plus the principal theorems and the axiom report): corrected the statement of the stabilizer-automorphism theorem (the normalization hypothesis turned out to be unnecessary and was removed) and cleaned the remaining tactic warnings.
- Built every module of the project serially and confirmed `lake build` completes successfully (8043 jobs), with a project-wide search confirming no `sorry`/`admit`/`axiom` anywhere.
- Captured the axiom report: all 21 principal theorems (`task03_polarization_preserved` … `task03_rapidity`) depend only on `propext`, `Classical.choice`, `Quot.sound`.
- Updated `README.md` and `TASK03_AUDIT.md` to the final two-module Task-03 layout, and replaced the placeholder build report and import-firewall scan with the actual results.

**Import firewall (verified mechanically)**

`Core.lean` imports exactly one module, `RequestProject.NullSectorTask02.GeneralUnit`; none of the Task-01 `SplitComplex`/`Boost`/`Strata`/`Limits`/`Task01` modules is reachable from it. A word-boundary token scan of `Core.lean` for `Task01.SplitComplex, Task01.Boost, Task01.Strata, Task01.Limits, Task01.Task01, mulL, jL, ep, em, qp, qm, P, B, B4, oneL, invProd` produced exactly two matches, both in prose comments (the task's own labels "Case B" and "data sets A and B"); each is documented individually in §2 and §20 of the audit and the scan was not weakened. Task-01 declarations enter only in `Task03.lean`, the last module compiled.

**Results established (all formally proved)**

`Q2`-preservation implies `L2`-preservation (derived from polarization, not assumed); a concrete Lorentz normal form on the 1+1 carrier with `detL = ±1` and `PreservesFuture ↔ 0 < (T u₀).1`; future-preserving Lorentz maps act on normalized future units (and the future hypothesis is necessary — counterexample given); the covariance law `T (μ_e X Y) = μ_(T e) (T X) (T Y)` for every Lorentz map, packaged as multiplicative transport of unital products; a single Lorentz orbit of normalized future units with an explicit transporter built only from `Q2`, `L2`, `e`, `f` (no boost, no rapidity); transporters are exactly two without an orientation datum and unique with it; the stabilizer of a unit has exactly two elements, both algebra automorphisms; spacelike companions of `e` are exactly `±compl e`; the complementary null pair is derived from `(e,s)` with no Task-01 input, `s ↦ −s` exchanges the two components; the unordered pair is determined once `e` is chosen while the ordered pair is not, and is fixed exactly by adding a spatial-orientation datum; null-pair transport preserves labels in the proper case and exchanges them in the improper case; all reconstructed products form one orbit of the proper future Lorentz group; fixed-product invariance holds exactly on the stabilizer of the unit (`FixedInvariant T e ↔ T e = e`), which is formally distinguished from family covariance. In the late comparison layer, the Task-01 boost is shown to be a proper future-preserving Lorentz map that coincides with the independently constructed transporter from `u₀`, satisfies the covariance relation, and matches the independently reconstructed null pair at the reference unit; rapidity parametrization appears only as a late cross-check.

Every row of the required negative-control table is closed with a positive or negative theorem; no row is `UNRESOLVED`.


# Summary of changes for run d2d4ed8c-0706-4470-a655-bde788333956
## Null-Sector Task 02 — formal reconstruction, minimality and canonicality audit

New Lean development in `RequestProject/NullSectorTask02/`, built on the Lean 4.28.0 / Mathlib v4.28.0 (commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365`) environment already pinned by the project. Everything compiles with `lake build`; there is no `sorry`, no `admit`, and no custom axiom, and each principal theorem depends exactly on `propext`, `Classical.choice`, `Quot.sound` (reported by `#print axioms` at the end of `Task02.lean`).

### Files and firewall
`LorentzData.lean` → `CandidateProduct.lean` → `FixedUnit.lean` → {`Minimality.lean`, `GeneralUnit.lean` → `Canonicality.lean`} → `Comparison.lean` → `Task02.lean`.

The six core files import only `RequestProject.NullSectorTask01.Basic` (carrier `Long`, form `Q2`); the Task-01 split-complex layer enters solely in `Comparison.lean`. A mechanical token audit (word-boundary search for `SplitComplex`, `Boost`, `Strata`, `Limits`, `Task01`, `mulL`, `oneL`, `jL`, `ep`, `em`, `qp`, `qm`, `P`, `nullEquiv`, `invProd`) returns no matches in the core files; the substring false positives (e.g. `em` inside "theorem") are documented in the audit.

### Main results
- **Polarization.** `L2` is defined from `Q2` alone; its coordinate form `ts − xy`, bilinearity, symmetry, `L2(X,X) = Q2 X` and nondegeneracy are derived.
- **Generic product.** The unknown product is carried by `LinearMap.BilinMap ℝ Long Long`; `AdmissibleAt e μ` assumes only a two-sided unit and `Q2`-multiplicativity — no commutativity, associativity, or normalization.
- **Unit condition derived.** `Q2 e = 1` is forced (a left unit already suffices), and a two-sided unit is unique.
- **Fixed unit `u₀=(1,0)`: PROVED UNIQUE.** From a generic `μ`, the formula `μ(t,x)(s,y) = (ts+xy, ty+xs)` is forced, with `∃!` existence; the square relation `μ s₀ s₀ = u₀`, commutativity, associativity, and the whole idempotent/null structure of `p₊`, `p₋` follow as corollaries.
- **Minimality: PROVED NON-UNIQUE for left unit only.** Exactly two products exist — `(ts+xy, ty+xs)` and `(ts−xy, ty−xs)` — and they are distinct. Adding separately the right-unit law, commutativity, or associativity each restores uniqueness (Tests A, B, C).
- **Arbitrary unit.** An admissible product with unit `e` exists **iff** `Q2 e = 1`; it is then unique and equals the coordinate-free expression `μ(X,Y) = L2(X,e)·Y + L2(Y,e)·X − L2(X,Y)·e`, obtained as the output of the uniqueness analysis rather than posited.
- **Canonicality: PROVED NON-UNIQUE / PROVED IMPOSSIBLE.** An explicit rational non-identity `Q2`-preserving, future-cone-preserving linear equivalence is constructed independently of Task-01 boosts; it fixes no nonzero vector, so no future normalized vector is invariant, and **no admissible unital product is equivariant** under it. Coordinate availability of `u₀` is thereby formally separated from intrinsic determination.
- **Late comparison.** The Task-01 product, packaged as a bilinear map, is admissible at the Task-01 unit and equals the reconstructed product **by the uniqueness theorem**; `p₊, p₋` coincide with the Task-01 idempotents, and several Task-01 split-complex identities are re-derived for an arbitrary admissible product.

### Dependency verdict
`Long + Q2` (with or without the future component) does **not** determine a product; `Long + Q2 + chosen normalized unit` determines it uniquely, and the square relation and null idempotents follow. With only a left unit, exactly one further axiom (right unit, commutativity, or associativity) is required. The proposed arrow "Lorentz quadratic carrier ⇒ chosen normalized unit" fails and is replaced by the correct statement in the audit.

### Documentation
`TASK02_AUDIT.md` contains the input definitions, import-firewall report, generic product definition, theorem inventory, fixed-unit and weakened-assumption classifications, assumed-versus-derived table, arbitrary-unit result, future-unit/canonicality result, equivariance obstruction, late comparison, negative-control table (every row PROVED UNIQUE / NON-UNIQUE / IMPOSSIBLE — no UNRESOLVED entries), final dependency graph, source ledger separating imported Mathlib results from what is derived here, environment record and build/axiom reports. `README.md` now covers both tasks. `ARISTOTLE_SUMMARY.md` was left untouched.


# Summary of changes for run a3b44340-19a5-4abb-b945-abf5fb8e1eee
Task 01 is formalized and audited in full, with no `sorry`, no `admit`, and no custom axioms. Everything builds cleanly (`lake build`, Lean `v4.28.0`, Mathlib `v4.28.0` / commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365`).

Files added:
- `RequestProject/NullSectorTask01/Basic.lean` — ambient carrier `Vec4`, Lorentz form `Q4` of signature (+,−,−,−), longitudinal carrier `Long`, form `Q2`, embedding `ι(t,x) = (t,x,0,0)`; `Q4_iota : Q4 (ι X) = Q2 X`.
- `SplitComplex.lean` — split-complex product `⋆`, unit and `j` with `j ⋆ j = 1`, idempotents `e₊ = (1+j)/2`, `e₋ = (1−j)/2` with all requested identities derived (`e₊⋆e₊ = e₊`, `e₋⋆e₋ = e₋`, `e₊⋆e₋ = 0`, `e₊+e₋ = 1`, `e₊−e₋ = j`); null coordinates `q₊ = t+x`, `q₋ = t−x`, the assembly map `P a b = a•e₊ + b•e₋`, exact reconstruction `P (q₊ X) (q₋ X) = X`, `q₊(P a b) = a`, `q₋(P a b) = b`, the explicit linear equivalence `Long ≃ₗ[ℝ] ℝ × ℝ`, and the derived formula `Q2 (P a b) = invProd a b = a·b` together with `Q2 e₊ = Q2 e₋ = 0`.
- `Strata.lean` — the closed quadrant ↔ future-causal cone correspondence (`0 ≤ a ∧ 0 ≤ b ↔ 0 ≤ t ∧ 0 ≤ Q2`), the four strata (`zero`, `plusBoundary`, `minusBoundary`, `interior`) with exhaustiveness, pairwise disjointness, vanishing of `Q2` on the boundary strata, positivity on the interior, and both converses inside the sector.
- `Boost.lean` — boost `B η` and its ambient extension `B4 η` (transverse coordinates fixed), invariance `Q4 (B4 η X) = Q4 X` and `Q2 (B η X) = Q2 X`, the action `B η e₊ = exp(η) • e₊`, `B η e₋ = exp(−η) • e₋`, hence `B η (P a b) = P (exp η · a) (exp(−η) · b)`, with the exponential factors derived from `Real.cosh_add_sinh` / `Real.cosh_sub_sinh`; the invariance of `a·b` is proved twice independently — directly from exponential identities, and as a corollary of Lorentz invariance plus the null-coordinate formula.
- `Limits.lean` — the families `F₊(ε) = P(a₀,ε)`, `F₋(ε) = P(ε,b₀)` with `Q2(F₊ ε) = a₀ε`, stratum membership, and genuine topological limits in the carrier as `ε → 0⁺`; the fixed-product branch `G(b) = P(I/b, b)` with `Q2(G b) = I`, divergence of the first ordinary coordinate to `+∞`, a concrete unboundedness statement, and a proof that `G` has **no** limit in the carrier as `b → 0⁺`.
- `Task01.lean` — imports the whole development and states the principal final theorems, one per acceptance criterion.

Documentation: `README.md` (environment, layout, build) and `TASK01_AUDIT.md` with the exact definitions, theorem inventory, dependency graph (with the extra assumptions each arrow needs), causal-stratum table, boost-transformation table, invariant-product result with the dependency separation of the two proofs, the Regime A / Regime B comparison, unresolved obligations (none outstanding within scope), a source ledger separating imported standard Mathlib results from what is derived here, and the build/axiom report.

Axiom report: each principal theorem (`task01_restriction`, `task01_idempotents`, `task01_unique_decomposition`, `task01_Q2_eq_product`, `task01_strata`, `task01_boost_action`, `task01_invariant_product`, `task01_boundary_family`, `task01_boundary_family_minus`, `task01_regimes`, plus `Q4_B4` and `invProd_boost_via_Q2`) depends exactly on `propext`, `Classical.choice`, `Quot.sound`.

No physical or dynamical structure was introduced: the development contains only real carriers, quadratic forms, the split-complex algebra, real coefficients, boosts, and topological limits.