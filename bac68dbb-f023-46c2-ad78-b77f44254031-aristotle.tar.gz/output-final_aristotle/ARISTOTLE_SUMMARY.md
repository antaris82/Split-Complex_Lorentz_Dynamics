# Summary of changes for run d2d4ed8c-0706-4470-a655-bde788333956
## Null-Sector Task 02 — formal reconstruction, minimality and canonicality audit

New Lean development in `RequestProject/NullSectorTask02/`, built on the Lean 4.28.0 / Mathlib v4.28.0 (commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365`) environment already pinned by the project. Everything compiles with `lake build`; there is no `sorry`, no `admit`, and no custom axiom, and each principal theorem depends exactly on `propext`, `Classical.choice`, `Quot.sound` (reported by `#print axioms` at the end of `Task02.lean`).

### Files and firewall
`LorentzData.lean` → `CandidateProduct.lean` → `FixedUnit.lean` → {`Minimality.lean`, `GeneralUnit.lean` → `Canonicality.lean`} → `Comparison.lean` → `Task02.lean`.

The six core files import only `RequestProject.NullSectorTask01.Basic` (carrier `Long`, form `Q2`); the Task-01 split-complex layer enters solely in `Comparison.lean`. A mechanical token audit (word-boundary search for `SplitComplex`, `Boost`, `Strata`, `Limits`, `Task01`, `mulL`, `oneL`, `jL`, `ep`, `em`, `qp`, `qm`, `P`, `nullEquiv`, `invProd`) returns no matches in the core files; the substring false positives (e.g. `em` inside "theorem") are documented in the audit.

### Main results
- **Polarization.** `L2` is defined from `Q2` alone; its coordinate form `ts − xy`, bilinearity, symmetry, `L2(X,X) = Q2 X` and nondegeneracy are derived.
- **Generic product.** The unknown product is carried by `LinearMap.BilinMap ℝ Long Long`; `AdmissibleAt e μ` assumes only a two-sided unit and `Q2`-multiplicativity — no commutativity, associativity, or normalization.
- **Unit condition derived.** `Q2 e = 1` is forced (a left unit already suffices), and a two-sided unit is unique.
- **Fixed unit `u₀=(1,0)`: PROVED UNIQUE.** From a generic `μ`, the formula `μ(t,x)(s,y) = (ts+xy, ty+xs)` is forced, with `∃!` existence; the square relation `μ s₀ s₀ = u₀`, commutativity, associativity, and the whole idempotent/null structure of `p₊`, `p₋` follow as corollaries.
- **Minimality: PROVED NON-UNIQUE for left unit only.** Exactly two products exist — `(ts+xy, ty+xs)` and `(ts−xy, ty−xs)` — and they are distinct. Adding separately the right-unit law, commutativity, or associativity each restores uniqueness (Tests A, B, C).
- **Arbitrary unit.** An admissible product with unit `e` exists **iff** `Q2 e = 1`; it is then unique and equals the coordinate-free expression `μ(X,Y) = L2(X,e)·Y + L2(Y,e)·X − L2(X,Y)·e`, obtained as the output of the uniqueness analysis rather than posited.
- **Canonicality: PROVED NON-UNIQUE / PROVED IMPOSSIBLE.** An explicit rational non-identity `Q2`-preserving, future-cone-preserving linear equivalence is constructed independently of Task-01 boosts; it fixes no nonzero vector, so no future normalized vector is invariant, and **no admissible unital product is equivariant** under it. Coordinate availability of `u₀` is thereby formally separated from intrinsic determination.
- **Late comparison.** The Task-01 product, packaged as a bilinear map, is admissible at the Task-01 unit and equals the reconstructed product **by the uniqueness theorem**; `p₊, p₋` coincide with the Task-01 idempotents, and several Task-01 split-complex identities are re-derived for an arbitrary admissible product.

### Dependency verdict
`Long + Q2` (with or without the future component) does **not** determine a product; `Long + Q2 + chosen normalized unit` determines it uniquely, and the square relation and null idempotents follow. With only a left unit, exactly one further axiom (right unit, commutativity, or associativity) is required. The proposed arrow "Lorentz quadratic carrier ⇒ chosen normalized unit" fails and is replaced by the correct statement in the audit.

### Documentation
`TASK02_AUDIT.md` contains the input definitions, import-firewall report, generic product definition, theorem inventory, fixed-unit and weakened-assumption classifications, assumed-versus-derived table, arbitrary-unit result, future-unit/canonicality result, equivariance obstruction, late comparison, negative-control table (every row PROVED UNIQUE / NON-UNIQUE / IMPOSSIBLE — no UNRESOLVED entries), final dependency graph, source ledger separating imported Mathlib results from what is derived here, environment record and build/axiom reports. `README.md` now covers both tasks. `ARISTOTLE_SUMMARY.md` was left untouched.


# Summary of changes for run a3b44340-19a5-4abb-b945-abf5fb8e1eee
Task 01 is formalized and audited in full, with no `sorry`, no `admit`, and no custom axioms. Everything builds cleanly (`lake build`, Lean `v4.28.0`, Mathlib `v4.28.0` / commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365`).

Files added:
- `RequestProject/NullSectorTask01/Basic.lean` — ambient carrier `Vec4`, Lorentz form `Q4` of signature (+,−,−,−), longitudinal carrier `Long`, form `Q2`, embedding `ι(t,x) = (t,x,0,0)`; `Q4_iota : Q4 (ι X) = Q2 X`.
- `SplitComplex.lean` — split-complex product `⋆`, unit and `j` with `j ⋆ j = 1`, idempotents `e₊ = (1+j)/2`, `e₋ = (1−j)/2` with all requested identities derived (`e₊⋆e₊ = e₊`, `e₋⋆e₋ = e₋`, `e₊⋆e₋ = 0`, `e₊+e₋ = 1`, `e₊−e₋ = j`); null coordinates `q₊ = t+x`, `q₋ = t−x`, the assembly map `P a b = a•e₊ + b•e₋`, exact reconstruction `P (q₊ X) (q₋ X) = X`, `q₊(P a b) = a`, `q₋(P a b) = b`, the explicit linear equivalence `Long ≃ₗ[ℝ] ℝ × ℝ`, and the derived formula `Q2 (P a b) = invProd a b = a·b` together with `Q2 e₊ = Q2 e₋ = 0`.
- `Strata.lean` — the closed quadrant ↔ future-causal cone correspondence (`0 ≤ a ∧ 0 ≤ b ↔ 0 ≤ t ∧ 0 ≤ Q2`), the four strata (`zero`, `plusBoundary`, `minusBoundary`, `interior`) with exhaustiveness, pairwise disjointness, vanishing of `Q2` on the boundary strata, positivity on the interior, and both converses inside the sector.
- `Boost.lean` — boost `B η` and its ambient extension `B4 η` (transverse coordinates fixed), invariance `Q4 (B4 η X) = Q4 X` and `Q2 (B η X) = Q2 X`, the action `B η e₊ = exp(η) • e₊`, `B η e₋ = exp(−η) • e₋`, hence `B η (P a b) = P (exp η · a) (exp(−η) · b)`, with the exponential factors derived from `Real.cosh_add_sinh` / `Real.cosh_sub_sinh`; the invariance of `a·b` is proved twice independently — directly from exponential identities, and as a corollary of Lorentz invariance plus the null-coordinate formula.
- `Limits.lean` — the families `F₊(ε) = P(a₀,ε)`, `F₋(ε) = P(ε,b₀)` with `Q2(F₊ ε) = a₀ε`, stratum membership, and genuine topological limits in the carrier as `ε → 0⁺`; the fixed-product branch `G(b) = P(I/b, b)` with `Q2(G b) = I`, divergence of the first ordinary coordinate to `+∞`, a concrete unboundedness statement, and a proof that `G` has **no** limit in the carrier as `b → 0⁺`.
- `Task01.lean` — imports the whole development and states the principal final theorems, one per acceptance criterion.

Documentation: `README.md` (environment, layout, build) and `TASK01_AUDIT.md` with the exact definitions, theorem inventory, dependency graph (with the extra assumptions each arrow needs), causal-stratum table, boost-transformation table, invariant-product result with the dependency separation of the two proofs, the Regime A / Regime B comparison, unresolved obligations (none outstanding within scope), a source ledger separating imported standard Mathlib results from what is derived here, and the build/axiom report.

Axiom report: each principal theorem (`task01_restriction`, `task01_idempotents`, `task01_unique_decomposition`, `task01_Q2_eq_product`, `task01_strata`, `task01_boost_action`, `task01_invariant_product`, `task01_boundary_family`, `task01_boundary_family_minus`, `task01_regimes`, plus `Q4_B4` and `invProd_boost_via_Q2`) depends exactly on `propext`, `Classical.choice`, `Quot.sound`.

No physical or dynamical structure was introduced: the development contains only real carriers, quadratic forms, the split-complex algebra, real coefficients, boosts, and topological limits.