# Summary of changes for run e65666e4-8611-42a9-9e02-9cab6d32b0d5
Task 03 is complete: the whole project now builds cleanly with no `sorry`, no `admit`, and no custom axiom.

**What was finished in this session**

- Completed and repaired the Task-03 core (`RequestProject/NullSectorTask03/Core.lean`) so that it compiles: qualified the ambiguous `compl` name, rewrote the companion classification and the proper/improper transport-of-companion proofs, fixed the unordered-null-pair case analysis, and removed leftover no-op tactics. The file now compiles with zero errors and zero linter warnings.
- Completed `RequestProject/NullSectorTask03/Task03.lean` (late Task-01 comparison layer plus the principal theorems and the axiom report): corrected the statement of the stabilizer-automorphism theorem (the normalization hypothesis turned out to be unnecessary and was removed) and cleaned the remaining tactic warnings.
- Built every module of the project serially and confirmed `lake build` completes successfully (8043 jobs), with a project-wide search confirming no `sorry`/`admit`/`axiom` anywhere.
- Captured the axiom report: all 21 principal theorems (`task03_polarization_preserved` … `task03_rapidity`) depend only on `propext`, `Classical.choice`, `Quot.sound`.
- Updated `README.md` and `TASK03_AUDIT.md` to the final two-module Task-03 layout, and replaced the placeholder build report and import-firewall scan with the actual results.

**Import firewall (verified mechanically)**

`Core.lean` imports exactly one module, `RequestProject.NullSectorTask02.GeneralUnit`; none of the Task-01 `SplitComplex`/`Boost`/`Strata`/`Limits`/`Task01` modules is reachable from it. A word-boundary token scan of `Core.lean` for `Task01.SplitComplex, Task01.Boost, Task01.Strata, Task01.Limits, Task01.Task01, mulL, jL, ep, em, qp, qm, P, B, B4, oneL, invProd` produced exactly two matches, both in prose comments (the task's own labels "Case B" and "data sets A and B"); each is documented individually in §2 and §20 of the audit and the scan was not weakened. Task-01 declarations enter only in `Task03.lean`, the last module compiled.

**Results established (all formally proved)**

`Q2`-preservation implies `L2`-preservation (derived from polarization, not assumed); a concrete Lorentz normal form on the 1+1 carrier with `detL = ±1` and `PreservesFuture ↔ 0 < (T u₀).1`; future-preserving Lorentz maps act on normalized future units (and the future hypothesis is necessary — counterexample given); the covariance law `T (μ_e X Y) = μ_(T e) (T X) (T Y)` for every Lorentz map, packaged as multiplicative transport of unital products; a single Lorentz orbit of normalized future units with an explicit transporter built only from `Q2`, `L2`, `e`, `f` (no boost, no rapidity); transporters are exactly two without an orientation datum and unique with it; the stabilizer of a unit has exactly two elements, both algebra automorphisms; spacelike companions of `e` are exactly `±compl e`; the complementary null pair is derived from `(e,s)` with no Task-01 input, `s ↦ −s` exchanges the two components; the unordered pair is determined once `e` is chosen while the ordered pair is not, and is fixed exactly by adding a spatial-orientation datum; null-pair transport preserves labels in the proper case and exchanges them in the improper case; all reconstructed products form one orbit of the proper future Lorentz group; fixed-product invariance holds exactly on the stabilizer of the unit (`FixedInvariant T e ↔ T e = e`), which is formally distinguished from family covariance. In the late comparison layer, the Task-01 boost is shown to be a proper future-preserving Lorentz map that coincides with the independently constructed transporter from `u₀`, satisfies the covariance relation, and matches the independently reconstructed null pair at the reference unit; rapidity parametrization appears only as a late cross-check.

Every row of the required negative-control table is closed with a positive or negative theorem; no row is `UNRESOLVED`.


# Summary of changes for run d2d4ed8c-0706-4470-a655-bde788333956
## Null-Sector Task 02 — formal reconstruction, minimality and canonicality audit

New Lean development in `RequestProject/NullSectorTask02/`, built on the Lean 4.28.0 / Mathlib v4.28.0 (commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365`) environment already pinned by the project. Everything compiles with `lake build`; there is no `sorry`, no `admit`, and no custom axiom, and each principal theorem depends exactly on `propext`, `Classical.choice`, `Quot.sound` (reported by `#print axioms` at the end of `Task02.lean`).

### Files and firewall
`LorentzData.lean` → `CandidateProduct.lean` → `FixedUnit.lean` → {`Minimality.lean`, `GeneralUnit.lean` → `Canonicality.lean`} → `Comparison.lean` → `Task02.lean`.

The six core files import only `RequestProject.NullSectorTask01.Basic` (carrier `Long`, form `Q2`); the Task-01 split-complex layer enters solely in `Comparison.lean`. A mechanical token audit (word-boundary search for `SplitComplex`, `Boost`, `Strata`, `Limits`, `Task01`, `mulL`, `oneL`, `jL`, `ep`, `em`, `qp`, `qm`, `P`, `nullEquiv`, `invProd`) returns no matches in the core files; the substring false positives (e.g. `em` inside "theorem") are documented in the audit.

### Main results
- **Polarization.** `L2` is defined from `Q2` alone; its coordinate form `ts − xy`, bilinearity, symmetry, `L2(X,X) = Q2 X` and nondegeneracy are derived.
- **Generic product.** The unknown product is carried by `LinearMap.BilinMap ℝ Long Long`; `AdmissibleAt e μ` assumes only a two-sided unit and `Q2`-multiplicativity — no commutativity, associativity, or normalization.
- **Unit condition derived.** `Q2 e = 1` is forced (a left unit already suffices), and a two-sided unit is unique.
- **Fixed unit `u₀=(1,0)`: PROVED UNIQUE.** From a generic `μ`, the formula `μ(t,x)(s,y) = (ts+xy, ty+xs)` is forced, with `∃!` existence; the square relation `μ s₀ s₀ = u₀`, commutativity, associativity, and the whole idempotent/null structure of `p₊`, `p₋` follow as corollaries.
- **Minimality: PROVED NON-UNIQUE for left unit only.** Exactly two products exist — `(ts+xy, ty+xs)` and `(ts−xy, ty−xs)` — and they are distinct. Adding separately the right-unit law, commutativity, or associativity each restores uniqueness (Tests A, B, C).
- **Arbitrary unit.** An admissible product with unit `e` exists **iff** `Q2 e = 1`; it is then unique and equals the coordinate-free expression `μ(X,Y) = L2(X,e)·Y + L2(Y,e)·X − L2(X,Y)·e`, obtained as the output of the uniqueness analysis rather than posited.
- **Canonicality: PROVED NON-UNIQUE / PROVED IMPOSSIBLE.** An explicit rational non-identity `Q2`-preserving, future-cone-preserving linear equivalence is constructed independently of Task-01 boosts; it fixes no nonzero vector, so no future normalized vector is invariant, and **no admissible unital product is equivariant** under it. Coordinate availability of `u₀` is thereby formally separated from intrinsic determination.
- **Late comparison.** The Task-01 product, packaged as a bilinear map, is admissible at the Task-01 unit and equals the reconstructed product **by the uniqueness theorem**; `p₊, p₋` coincide with the Task-01 idempotents, and several Task-01 split-complex identities are re-derived for an arbitrary admissible product.

### Dependency verdict
`Long + Q2` (with or without the future component) does **not** determine a product; `Long + Q2 + chosen normalized unit` determines it uniquely, and the square relation and null idempotents follow. With only a left unit, exactly one further axiom (right unit, commutativity, or associativity) is required. The proposed arrow "Lorentz quadratic carrier ⇒ chosen normalized unit" fails and is replaced by the correct statement in the audit.

### Documentation
`TASK02_AUDIT.md` contains the input definitions, import-firewall report, generic product definition, theorem inventory, fixed-unit and weakened-assumption classifications, assumed-versus-derived table, arbitrary-unit result, future-unit/canonicality result, equivariance obstruction, late comparison, negative-control table (every row PROVED UNIQUE / NON-UNIQUE / IMPOSSIBLE — no UNRESOLVED entries), final dependency graph, source ledger separating imported Mathlib results from what is derived here, environment record and build/axiom reports. `README.md` now covers both tasks. `ARISTOTLE_SUMMARY.md` was left untouched.


# Summary of changes for run a3b44340-19a5-4abb-b945-abf5fb8e1eee
Task 01 is formalized and audited in full, with no `sorry`, no `admit`, and no custom axioms. Everything builds cleanly (`lake build`, Lean `v4.28.0`, Mathlib `v4.28.0` / commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365`).

Files added:
- `RequestProject/NullSectorTask01/Basic.lean` — ambient carrier `Vec4`, Lorentz form `Q4` of signature (+,−,−,−), longitudinal carrier `Long`, form `Q2`, embedding `ι(t,x) = (t,x,0,0)`; `Q4_iota : Q4 (ι X) = Q2 X`.
- `SplitComplex.lean` — split-complex product `⋆`, unit and `j` with `j ⋆ j = 1`, idempotents `e₊ = (1+j)/2`, `e₋ = (1−j)/2` with all requested identities derived (`e₊⋆e₊ = e₊`, `e₋⋆e₋ = e₋`, `e₊⋆e₋ = 0`, `e₊+e₋ = 1`, `e₊−e₋ = j`); null coordinates `q₊ = t+x`, `q₋ = t−x`, the assembly map `P a b = a•e₊ + b•e₋`, exact reconstruction `P (q₊ X) (q₋ X) = X`, `q₊(P a b) = a`, `q₋(P a b) = b`, the explicit linear equivalence `Long ≃ₗ[ℝ] ℝ × ℝ`, and the derived formula `Q2 (P a b) = invProd a b = a·b` together with `Q2 e₊ = Q2 e₋ = 0`.
- `Strata.lean` — the closed quadrant ↔ future-causal cone correspondence (`0 ≤ a ∧ 0 ≤ b ↔ 0 ≤ t ∧ 0 ≤ Q2`), the four strata (`zero`, `plusBoundary`, `minusBoundary`, `interior`) with exhaustiveness, pairwise disjointness, vanishing of `Q2` on the boundary strata, positivity on the interior, and both converses inside the sector.
- `Boost.lean` — boost `B η` and its ambient extension `B4 η` (transverse coordinates fixed), invariance `Q4 (B4 η X) = Q4 X` and `Q2 (B η X) = Q2 X`, the action `B η e₊ = exp(η) • e₊`, `B η e₋ = exp(−η) • e₋`, hence `B η (P a b) = P (exp η · a) (exp(−η) · b)`, with the exponential factors derived from `Real.cosh_add_sinh` / `Real.cosh_sub_sinh`; the invariance of `a·b` is proved twice independently — directly from exponential identities, and as a corollary of Lorentz invariance plus the null-coordinate formula.
- `Limits.lean` — the families `F₊(ε) = P(a₀,ε)`, `F₋(ε) = P(ε,b₀)` with `Q2(F₊ ε) = a₀ε`, stratum membership, and genuine topological limits in the carrier as `ε → 0⁺`; the fixed-product branch `G(b) = P(I/b, b)` with `Q2(G b) = I`, divergence of the first ordinary coordinate to `+∞`, a concrete unboundedness statement, and a proof that `G` has **no** limit in the carrier as `b → 0⁺`.
- `Task01.lean` — imports the whole development and states the principal final theorems, one per acceptance criterion.

Documentation: `README.md` (environment, layout, build) and `TASK01_AUDIT.md` with the exact definitions, theorem inventory, dependency graph (with the extra assumptions each arrow needs), causal-stratum table, boost-transformation table, invariant-product result with the dependency separation of the two proofs, the Regime A / Regime B comparison, unresolved obligations (none outstanding within scope), a source ledger separating imported standard Mathlib results from what is derived here, and the build/axiom report.

Axiom report: each principal theorem (`task01_restriction`, `task01_idempotents`, `task01_unique_decomposition`, `task01_Q2_eq_product`, `task01_strata`, `task01_boost_action`, `task01_invariant_product`, `task01_boundary_family`, `task01_boundary_family_minus`, `task01_regimes`, plus `Q4_B4` and `invProd_boost_via_Q2`) depends exactly on `propext`, `Classical.choice`, `Quot.sound`.

No physical or dynamical structure was introduced: the development contains only real carriers, quadratic forms, the split-complex algebra, real coefficients, boosts, and topological limits.