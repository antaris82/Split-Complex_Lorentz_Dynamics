# Task XVIII audit — local-to-global conversion

Connected admissibility, central bridge factors, relation coverage, and reconstruction
after explicit conversion.

---

## 0. Toolchain, revisions, build target

| item | value |
|---|---|
| Lean | `leanprover/lean4:v4.28.0` (`lean-toolchain`) |
| Mathlib | `v4.28.0`, manifest revision `8f9d9cff6bd728b17a24e163c9402775d9e6a365` |
| project | `RequestProject`, `lakefile.toml`, glob `RequestProject.+` |
| focused target | `lake build RequestProject.NullSectorTask18.Task18` |
| whole project | `lake build` |

Mathlib declarations used in Task 18 that are not elementary algebra or order lemmas
(**IMPORTED STANDARD RESULT** in each case):

| declaration | Mathlib module | used in |
|---|---|---|
| `IsPreconnected`, `IsConnected`, `IsPathConnected`, `JoinedIn` | `Mathlib/Topology/Connected/*` | Packages A, B, H |
| `isPreconnected_connectedComponentIn`, `connectedComponentIn_subset` | `Mathlib/Topology/Connected/Basic` | Package H |
| `IsPathConnected.joinedIn`, `JoinedIn.mono`, `JoinedIn.symm` | `Mathlib/Topology/Connected/PathConnected` | Package B |
| `Metric.isOpen_iff`, `Metric.continuous_iff`, `Metric.isBounded_closedBall` | `Mathlib/Topology/MetricSpace/*` | Packages B, H, I |
| `Metric.isCompact_of_isClosed_isBounded` | `Mathlib/Topology/MetricSpace/ProperSpace` | Package I |
| `IsCompact.exists_bound_of_continuousOn` | `Mathlib/Topology/Algebra/Order/Compact` | Package I |
| `ContinuousMap.exists_restrict_eq` (Tietze extension) | `Mathlib/Topology/TietzeExtension` | Package I |
| `UniformContinuous.exists_contDiff_dist_le` | `Mathlib/Analysis/Calculus/BumpFunction/SmoothApprox` | Package I |
| `HasCompactSupport.uniformContinuous_of_continuous`, `HasCompactSupport.intro` | `Mathlib/Topology/Support` | Package I |
| `Real.smoothTransition`, `.contDiff`, `.zero_of_nonpos`, `.one_of_one_le` | `Mathlib/Analysis/SpecialFunctions/SmoothTransition` | Package I |
| `ContDiff.sum`, `ContDiff.comp`, `ContDiff.of_le` | `Mathlib/Analysis/Calculus/ContDiff/*` | Package I |
| `Real.sin_eq_zero_iff`, `Real.cos_int_mul_two_pi_add_pi`, `Real.sin_int_mul_pi` | `Mathlib/Analysis/SpecialFunctions/Trigonometric/Basic` | Packages G, I |
| `smul_right_injective`, `sq_eq_sq_iff_eq_or_eq_neg` | `Mathlib/Algebra/*` | Package G |

Everything else used by Task 18 is **DERIVED IN TASK 18** or inherited from Tasks 16–17
(see the ledger in §9).

---

## 1. Reconstruction firewall report

* Task 18 enters the inherited development through **one** import only:
  `RequestProject.NullSectorTask17.RegularityAudit`, the last Task-17 *reconstruction*
  layer.
* `RequestProject.NullSectorTask17.Identification` (the Task-17 comparison module) and
  `RequestProject.NullSectorTask17.Task17` (which imports it) are imported by **no** Task-18
  module.
* The single Task-18 comparison module,
  `RequestProject.NullSectorTask18.Identification`, is imported by
  `RequestProject.NullSectorTask18.Task18` and by nothing else.
* Mechanical vocabulary scan over the Task-18 reconstruction modules for
  `spin`, `SU(2)`, `SO(3)`, `spinor`, `projective`, `covering space`, `bundle`, `Čech`,
  `cocycle`, `cohomology`, `connection`, `holonomy`, `fundamental group`, `fermion`,
  `boson`, `helicity`, `quantum`, `wavefunction`, `Hilbert`, `Born rule`, `Hamiltonian`,
  `gauge`, `field equation`: the only hits are (i) the firewall paragraph in `SafeBase`
  which lists the forbidden words, and (ii) the words *cover* / *covering* used in the bare
  point-set sense of an indexed family of **direction domains covering the unit
  directions**, as the task statement itself requires (`IsCoveringLocalSystem`,
  `CoversDirections`, `CoversRelations`).  No covering space, covering group, or covering
  map occurs anywhere.
* No central factor, sign, or local normalization is quotiented anywhere.  Negative control
  5 proves that the retained factor determines the family, so nothing was lost.
* The arbitrary spatial word problem is untouched: no Task-18 theorem needs it.

---

## 2. Exact definitions introduced in Task 18

| name | module | statement |
|---|---|---|
| `IsHalfOdd x` | `SafeBase` | `∃ k : ℤ, x = k + 1/2` |
| `e1` | `SafeBase` | the direction `(1,0,0)` |
| `LexPosOf f g k n` | `SafeBase` | lexicographic positivity for three coordinate functions |
| `lexSetOf f g k` | `SafeBase` | the unit directions that are lexicographically positive |
| `lexA`, `lexB` | `SafeBase` | the two instances, coordinate orders `(x,y,z)` and `(x,−y,z)` |
| `UnitSet D` | `ConnectedAdmissibility` | `∀ n ∈ D, IsUnitAxis n` |
| `PreconnDomain`, `ConnDomain`, `PathConnDomain`, `OpenDomain` | `ConnectedAdmissibility` | the four point-set notions for `sphSet D`, kept apart |
| `IsMaximalIn C D` | `MaximalDomains` | `C D ∧ ∀ E, C E → D ⊆ E → E = D` |
| `AdmClass`, `OpenAdmClass`, `OpenConnAdmClass`, `PreconnAdmClass` | `MaximalDomains` | the four classes in which maximality is taken |
| `AntipodalComplete D` | `MaximalDomains` | `∀ n unit, n ∈ D ∨ -n ∈ D` |
| `clampRate`, `bigCap` | `MaximalDomains` | the explicit open admissible domain strictly containing `Dom e1` |
| `HasLiteralGlobalExtension D F` | `ReconstructionPredicates` | one jointly regular global family restricting to every `F i` on `D i` |
| `HasSignRelaxedReconstruction D F` | `ReconstructionPredicates` | the same, with the global family in the sign-relaxed class |
| `HasSignRelaxedReconstructionWithFactors D F` | `ReconstructionPredicates` | the same, with explicit central conversion factors retained as data |
| `task17System` | `ReconstructionPredicates` | the Task-17 system `F_v = locFam 0` on `Dom v` |
| `Bridge U n θ` | `BridgeFactors` | `ovl U refFam n θ` |
| `IsCoveringLocalSystem D F` | `BridgeReconstruction` | unit domains, covering, jointly regular, exact |
| `bridgeNormalize U n θ` | `BridgeReconstruction` | `ovl refFam U n θ ⋆ U n θ` |
| `twoLabelSystem` | `BridgeReconstruction` | the two-member system with labels `0` and `1` |
| `IsGlobalBridge c` | `GlobalBridgeObstruction` | central factor whose product with `refFam` is jointly regular and globally exact |
| `signRate` | `GlobalBridgeObstruction` | the discontinuous half-odd reversal-odd rate |
| `Coincident n θ m φ` | `RelationCoverage` | `PhiGen n θ = PhiGen m φ` |
| `CoversDirections D`, `CoversRelations D` | `RelationCoverage` | ordinary coverage; relation coverage |
| `vecSet A` | `DisconnectedDomains` | the directions underlying a set of unit directions |
| `linRate`, `multiD`, `p35` | `DisconnectedDomains` | the explicit four-label disconnected admissible domain |
| `IsC1AdmissibleDomain D` | `RegularityAudit` | `C¹` admissibility, same quantifiers as `IsAdmissibleDomain` |
| `stair N`, `cutoff` | `RegularityAudit` | the finite `C¹` staircase and the radial cut-off profile |

---

## 3. Theorem inventory

### Package A — connected admissibility (`ConnectedAdmissibility`)

| theorem | content |
|---|---|
| `empty_preconn_not_conn` | preconnected ≠ connected (first separation of the notions) |
| `antipodal_pair_not_preconn` | admissible ⇏ preconnected (second separation) |
| `antipodalFree_of_admissible_preconn` | necessity, from constancy of the rate on preconnected domains **and** its oddness on antipodal pairs |
| `admissible_iff_antipodalFree_of_preconn` | **the named theorem**: `Admissible D ↔ AntipodalFree D` for preconnected `D` |
| `admissible_iff_antipodalFree_empty` | the empty domain satisfies both sides; nonemptiness is **not** required |
| `admissible_iff_antipodalFree_of_conn`, `..._of_pathConn` | the corollaries, derived *after* the preconnected theorem |
| `Dom_admissible_iff_antipodalFree` | specialization to the inherited domains |

### Package B — maximal connected admissible domains (`MaximalDomains`)

| theorem | content |
|---|---|
| `maximal_antipodalFree_iff_complete` | inclusion-maximality among antipodal-free sets **⇔** antipodal completeness |
| `maximal_preconnAdm_of_complete` | antipodal completeness ⇒ maximal in `PreconnAdmClass` |
| `lexA_maximal`, `lexB_maximal` | two explicit **constructed** maximal preconnected admissible domains |
| `transversal_curve` | the explicit curve leaving a domain through a boundary direction |
| `Dom_maximal_openConnAdm` | `Dom v` is maximal in `OpenConnAdmClass` |
| `Dom_not_maximal_openAdm` | **REFUTED** in `OpenAdmClass` (explicit `bigCap`) |
| `Dom_not_maximal_adm` | **REFUTED** in `AdmClass` (inherited Task-17 refutation) |
| `Dom_two_connected_extensions` | two incomparable connected admissible extensions of every `Dom v` |
| `maximal_extension_not_canonical` | non-canonicity, stated rather than resolved by convention |

### Package C — the two reconstruction problems (`ReconstructionPredicates`)

`task17System_hasLiteralGlobalExtension` (PROVED), `task17System_literal_extension_unique`,
`task17System_no_signRelaxedReconstruction` (REFUTED), `literal_and_signRelaxed_differ`.

### Package D — the bridge (`BridgeFactors`)

`refFam_rates`, `bridge_central`, `bridge_factorization`, `bridge_unique`,
`bridge_eq_zexp` (rate recovered), `bridge_rate_halfOdd` (exactness at one point suffices),
`bridge_direction_independent`, `bridge_unique_label`, `overlap_eq_bridge_difference`,
`integer_transition_from_bridges` (the Task-17 integer transition **recovered** from the
factorization).

### Package E — bridge-normalized reconstruction (`BridgeReconstruction`)

`bridge_removal`, `bridgeNormalize_eq_refFam`, `system_bridgeNormalize_eq_refFam`,
`bridge_normalized_reconstruction` (existence **and** uniqueness),
`task17System_hasSignRelaxedReconstructionWithFactors`,
`twoLabelSystem_no_literal_extension`, `three_failure_modes_distinguished`.

### Package F — the global bridge (`GlobalBridgeObstruction`)

`jointlyRegular_congr`, `transformationValued_congr`, `globalBridge_of_globalExact`,
`globalExact_of_globalBridge`, `globalExact_iff_globalBridge`, `no_global_bridge`,
`globalBridge_rate_conditions`, `signRate_halfOdd`, `signRate_odd`,
`three_conditions_pairwise_realizable`, `no_global_bridge_iff_no_rate`.

### Package G — relation coverage (`RelationCoverage`)

`antipodal_coincident`, `antipodalFree_family_not_coversRelations`,
`Dom_coversDirections_not_coversRelations`, `sin_half_eq_zero_iff`,
`coincidence_cross_classification`, `degenerate_cross_coincidence`, `locFam_full_turn`,
`degenerate_relations_satisfied`.

### Package H — disconnected domains (`DisconnectedDomains`)

`sphSet_vecSet`, `transformationValuedOn_mono`, `label_const_on_preconnected_part`,
`label_const_on_component`, `component_label_criterion`, `multiD_admissible_four_labels`,
`multiD_not_preconnected`, `labels_locally_constant`,
`admissible_labels_locally_constant`.

### Package I — arbitrary-domain `C¹` admissibility (`RegularityAudit`)

`stair_contDiff`, `stair_eq`, `isClosed_unitSet`, `isCompact_unitSet`, `rate_bounded`,
`cutoff_one`, `cutoff_eq_zero`, `exists_compactSupport_extension`, `exists_c1_rate`,
`admissible_iff_c1Admissible`, `c1_admissibility_adds_nothing`.

### Negative controls (`NegativeControls`)

1. `bridge_central_but_not_halfOdd` — centrality holds without exactness; half-oddness does
   not (explicit rate `1/3`).
2. `bridge_direction_dependent` — direction-independence genuinely needs preconnectedness
   (explicit exact representative on `multiD` with bridge rates `5/2` and `3/2`).
3. `normalization_does_not_preserve_exactness` — the normalized family is exact on no
   nonempty `Dom v`; the exactness is carried by the retained factor.
4. `bridge_locFam_ne_one` — the conversion factor is nontrivial.
5. `bridge_determines_family` — nothing is quotiented: the retained factor determines the
   family.

---

## 4. Dependency (source) order and declaration counts

```
SafeBase (39)
  → ConnectedAdmissibility (22)   Package A
  → MaximalDomains (29)           Package B
  → ReconstructionPredicates (8)  Package C
  → BridgeFactors (12)            Package D
  → BridgeReconstruction (12)     Package E
  → GlobalBridgeObstruction (13)  Package F
  → RelationCoverage (12)         Package G
  → DisconnectedDomains (18)      Package H
  → RegularityAudit (18)          Package I
  → NegativeControls (6)
  → Identification (1)            COMPARISON ONLY, imported only by Task18
  → Task18 (46)
```

Each module imports exactly its predecessor; `SafeBase` imports
`RequestProject.NullSectorTask17.RegularityAudit` and nothing else.

---

## 5. Final status table (§56)

| entry | status |
|---|---|
| preconnected admissibility `Admissible ↔ AntipodalFree` | **PROVED** |
| the same for connected / path-connected domains | **PROVED** (as corollaries) |
| empty domain: theorem holds, nonemptiness not required | **PROVED** |
| the five point-set notions are not interchangeable | **PROVED** (two explicit separations) |
| maximal connected admissible domains exist | **PROVED** (constructed, no maximality principle) |
| `Dom v` maximal among **open preconnected** admissible sets | **PROVED** |
| `Dom v` maximal among **open** admissible sets | **REFUTED** |
| `Dom v` maximal among admissible sets | **REFUTED** (inherited) |
| structural obstruction to enlargement = antipodal completeness | **PROVED** (equivalence inside the antipodal-free class) |
| more than one connected admissible extension of every `Dom v` | **PROVED** (two incomparable ones) |
| canonical selection of a maximal connected admissible extension | **REFUTED** (two different maximal ones with the same algebraic data) |
| maximal members of the plain admissible class | **OPEN** (not investigated) |
| unrestricted literal global extension of the Task-17 system | **PROVED** |
| literal sign-relaxed reconstruction of the Task-17 system | **REFUTED** |
| existence and uniqueness of local bridges | **PROVED** |
| bridge-rate classification (half-odd; one label on preconnected domains) | **PROVED** |
| bridge factorization `U = Bridge ⋆ refFam` | **PROVED** |
| overlap-as-bridge-difference; integer transition recovered | **PROVED** |
| bridge-normalized reconstruction (existence and uniqueness) | **PROVED** |
| sign-relaxed reconstruction with explicit conversion factors | **PROVED** |
| the three failure modes are distinct | **PROVED** |
| global bridge existence | **REFUTED** |
| equivalence: global exactness ↔ one global bridge | **PROVED** (both directions) |
| location of the obstruction: continuity / half-oddness / reversal | **PROVED** (all three needed; each pair realizable) |
| relation coverage by the inherited family | **REFUTED** |
| no antipodal-free family covers the relations | **PROVED** |
| classification of cross-domain coincidence relations | **PROVED** (antipodal, degenerate — the degenerate one harmless) |
| the antipodal relation is the *only* cross-domain relation | **REFUTED** |
| label constant on components; component-label criterion | **PROVED** |
| admissible domain with four different labels | **PROVED** |
| accumulation of distinct labels | **REFUTED** (labels are locally constant) |
| arbitrary-domain continuous versus `C¹` admissibility | **PROVED** (equivalent; `C¹` rate constructed) |
| arbitrary spatial word problem | **OPEN** (untouched) |

---

## 6. The required Task-XVIII verdict

> Given the Task-XVII classification of local exact representatives and their
> integer-valued relative factors, does introducing the explicit central conversion factor
> from each local exact representative to the unique global sign-relaxed reference
> completely resolve the local-to-global reconstruction mismatch?

**Yes** — at the level at which the mismatch was stated, and with a precisely located
residue.

1. Every jointly regular family factors, at every unit direction and every parameter, as
   `U n θ = Bridge U n θ ⋆ refFam n θ` with a **central**, **unique** factor whose rate is
   the already reconstructed one (`bridge_factorization`, `bridge_central`,
   `bridge_unique`, `bridge_eq_zexp`).
2. Removing that factor, while retaining it as data, sends **every** local exact
   representative to one and the same global sign-relaxed reference
   (`bridgeNormalize_eq_refFam`), and the bridge-normalized reconstruction of an arbitrary
   covering system exists and is unique (`bridge_normalized_reconstruction`).  In
   particular the Task-17 counterexample system *is* reconstructible in the sense of
   `HasSignRelaxedReconstructionWithFactors`.
3. So the Task-17 mismatch was a **literal-normalization mismatch**: it is the difference
   between requiring literal equality with the sign-relaxed reference and allowing the
   explicit central conversion factor.  The two requirements are separated at theorem level
   (`three_failure_modes_distinguished`).
4. The original global **exact** no-go does not disappear, and it is proved to be
   *equivalent* to the nonexistence of one global bridge
   (`globalExact_iff_globalBridge`, `no_global_bridge`).  Its content is exactly the
   incompatibility of three conditions on one rate function — continuity on the unit
   directions, half-oddness at every unit direction, and oddness under reversal
   (`globalBridge_rate_conditions`) — and **no two** of these already conflict
   (`three_conditions_pairwise_realizable`).  Reversal oddness alone is therefore not the
   obstruction.
5. Two further findings sharpen the picture, neither presupposed:
   * ordinary overlaps do not exhaust the visible relations, and no family of
     antipodal-free domains can (`antipodalFree_family_not_coversRelations`);
   * besides the antipodal relation there is exactly one more cross-domain class, the
     degenerate identity-parameter class, and it is satisfied by the explicit local models
     (`degenerate_relations_satisfied`), so it contributes nothing to the obstruction.

---

## 7. Failed attempts and statements that had to be weakened

* **`Dom v` maximal among open admissible sets** — attempted as a positive theorem, and it
  is **false**.  The attempted proof used antipodal-freeness of the larger domain, which
  requires preconnectedness (Package A); dropping preconnectedness allows an open
  admissible domain built from `Dom e1` together with an open cap around the reversed
  direction, with the explicit clamped rate `clampRate`.  The counterexample is preserved
  (`Dom_not_maximal_openAdm`) and the positive theorem is stated only for the class
  `OpenConnAdmClass`, where it is proved.
* **`lexA` maximal among *all* admissible sets** — attempted, and it is **false** for the
  same structural reason: an admissible superset may be disconnected, and a continuous rate
  can take the opposite half-odd value far away from the closure of `lexA`.  Maximality is
  therefore proved only in `PreconnAdmClass`, and the class is named in the statement.
* **"the antipodal relation is the only cross-domain relation"** — this was the expected
  answer to §49; the exact Task-16 coincidence classification **refutes** it.  The
  degenerate identity-parameter class relates arbitrary pairs of directions.  Rather than
  weakening the question, the second class is classified and then proved harmless.
* **A componentwise-free assignment of labels** — the naive statement that labels may be
  chosen freely on components is false: the assignment must extend to *one* continuous
  reversal-compatible rate (`component_label_criterion`), and labels cannot accumulate
  (`labels_locally_constant`).
* **Package I via a level-set/Urysohn argument** — an attempt to build the `C¹` rate by
  separating the (possibly infinitely many) level sets of the continuous rate was
  abandoned: it needs a finiteness argument for the range and a smooth Urysohn lemma for
  infinitely many closed sets.  The construction that succeeded avoids both, by composing a
  smooth approximation with an explicit finite `C¹` staircase, which is flat exactly on the
  relevant intervals.

---

## 8. Unresolved mathematical obligations

1. Whether the **plain** admissible class (no connectedness, no openness) has
   inclusion-maximal members is not decided.  Chain unions of admissible sets need not
   obviously be admissible, since each member carries its own rate function, so no
   maximality principle was applied.
2. The classification of maximal preconnected admissible domains is not complete: antipodal
   completeness is proved *sufficient* for maximality in that class, and equivalent to it
   inside the antipodal-free class, but no converse is proved inside the preconnected
   admissible class itself.
3. No structure theorem for arbitrary disconnected admissible domains is proved: the
   component-label criterion characterizes admissibility, but which *configurations* of
   components admit a prescribed family of labels is settled only through the existence of
   a continuous extension, which is not made explicit.
4. Uniqueness of the bridge-normalized reconstruction is proved at unit directions only —
   the values of a family at non-unit directions are unconstrained by every notion used
   here.
5. The arbitrary spatial word problem remains untouched, as required by the scope boundary.
6. The `C¹` result is proved for `C¹`; no statement is made about `C^k` for `k ≥ 2` or
   `C^∞`, although the construction visibly produces a `C^∞` rate whenever the staircase
   and the approximation are taken smooth.

---

## 9. Source ledger

**IMPORTED STANDARD RESULT.**  The Mathlib declarations listed in §0, and only those.  All
are standard point-set topology, metric geometry, elementary trigonometry, or the standard
smooth-approximation and Tietze machinery.

**INHERITED (Tasks 16–17), used as proved endpoints, not re-proved.**  The carrier `W` with
its product, unit and exact centre `Z`; the spatial carrier `Vec3` with the form `h3`, the
unit directions `IsUnitAxis` and the subspace `Sph`; the reference implementations `Un` and
the visible family `PhiGen`; `coincidence_iff`, `coincidence_iff_coords`,
`coincidence_add_two_pi`, `coincidence_neg_axis`, `coincidence_id_iff`; `zexp` with
`zexp_injective`, `zexp_zero_add`, `zexp_zero_val`, `zexp_zero_eq`; `famOf` and
`regular_family_arbitrary_parameters`; `IsJointlyRegularFamily`, `jointlyRegular_famOf`,
`jointlyRegular_beta_continuous`; `IsTransformationValued`,
`no_global_jointly_regular_transformationValued`; `IsSignTransformationValued`, `refFam`,
`reference_signTransformationValued`, `signValued_eq_reference`; `Dom`,
`IsTransformationValuedOn`, `locFam`, `locFam_transformationValuedOn`, `locFam_rates`;
`sphSet`, `IsAdmissibleDomain`, `AntipodalFree`, `admissible_necessary`,
`admissible_iff_exists_rate_function`, `antipodalFree_admissible`,
`antipodal_pair_admissible`, `label_const_of_preconnected`, `pointwise_rates`,
`local_exact_eq_locFam`, `locFam_injective_on_Dom`, `Dom_not_maximal`; `ovl` with
`ovl_central_and_factor`, `ovl_unique`, `ovl_explicit`, `ovl_chain3`;
`exact_local_not_signTransformationValued`, `refFam_not_exact_on_Dom`,
`no_global_halfodd_odd_rate`; `IsC1JointlyRegularFamily`; the domain geometry
`Dom_nonempty_iff`, `nrmz_mem_Dom_iff`, `Dom_antipodal_free`, `isOpen_sphSet_Dom`,
`isPreconnected_sphSet_Dom`, `isPathConnected_sphSet_Dom`, `segLin`, `segPath`,
`joinedIn_segPath`, `continuousOn_nrmz_comp`, `nrm`, `nrmz`,
`halfodd_const_of_preconnected`, `not_int_and_halfodd`.

**DERIVED IN TASK 18.**  Everything listed in §2 and §3.

---

## 10. Build and axiom report

```
$ lake build RequestProject.NullSectorTask18.Task18
Build completed successfully.

$ lake build
Build completed successfully (8226 jobs).
```

* **Warnings.**  No warning is emitted by any Task-18 module (checked module by module).
  Pre-existing warnings in Task-14 modules are unchanged and untouched.
* **Prohibited-construct scan.**  `rg` over `RequestProject/NullSectorTask18/` for `sorry`,
  `admit`, `axiom`, `@[implemented_by]`, `native_decide`, `bv_decide`, `unsafe`: **no
  hits**.
* **Axioms.**  `#print axioms` is run in `Task18.lean` for all 45 exposed endpoints,
  including the comparison-layer one.  Every one reports exactly

  ```
  [propext, Classical.choice, Quot.sound]
  ```

* **Comparison-only import audit.**  `grep "^import" RequestProject/NullSectorTask18/*.lean`
  shows the linear chain of §4; `Identification` appears exactly once as an import, in
  `Task18.lean`.
