# TASK06_AUDIT

Clean-room reconstruction of orientation-sensitive gluing, and universal
obstruction audit, inside the fixed real `3+1` Lorentz carrier.

Status vocabulary used below is restricted to:
`INPUT`, `RE-DERIVED`, `DERIVED`, `FREE DATUM`, `RIGIDITY RESULT`,
`EXISTENCE WITNESS`, `UNIQUE`, `NON-UNIQUE`, `FINITE-DIMENSIONAL`,
`INFINITE-DIMENSIONAL`, `DISCRETE FREEDOM`, `CONTINUOUS FREEDOM`,
`COUNTEREXAMPLE`, `UNIVERSAL OBSTRUCTION`, `COMPARISON ONLY`, `REPLICATED`,
`NOT REPLICATED`, `UNRESOLVED`.

---

## 1. Exact toolchain

| item | value |
|---|---|
| Lean | `leanprover/lean4:v4.28.0` (`lean-toolchain`) |
| Mathlib | `v4.28.0`, commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365` (`lake-manifest.json`) |
| build command | `lake build` |
| package | `RequestProject`, `globs = ["RequestProject.+"]` |

No toolchain change was made for Task 06.

---

## 2. Exact source ledger

New Task-06 sources, in compilation order (each file imports only the file(s)
listed):

| # | module | imports | role |
|---|---|---|---|
| 1 | `RequestProject/NullSectorTask06/SafeBase.lean` | `NullSectorTask04.GlobalExtension` | inherited data + rest-basis coordinate infrastructure |
| 2 | `RequestProject/NullSectorTask06/GenericExtension.lean` | (1) | `RE-DERIVED` generic extension theorem |
| 3 | `RequestProject/NullSectorTask06/ProperAction.lean` | (2) | stabilizer of `e₀`, orientation determinant, explicit transformations |
| 4 | `RequestProject/NullSectorTask06/UnknownDefect.lean` | (3) | equivariance of an abstract defect; temporal/spatial split |
| 5 | `RequestProject/NullSectorTask06/Rigidity.lean` | (4) | clean-room rigidity (upper bound) |
| 6 | `RequestProject/NullSectorTask06/Existence.lean` | (5) | first explicit nonzero witness, alternation, proper equivariance |
| 7 | `RequestProject/NullSectorTask06/ExactClassification.lean` | (6) | exact solution space, coordinate formula |
| 8 | `RequestProject/NullSectorTask06/OrientationReversal.lean` | (7) | orientation reversal, full isotropy |
| 9 | `RequestProject/NullSectorTask06/Identification.lean` | (8), `Mathlib.LinearAlgebra.CrossProduct` | `COMPARISON ONLY` |
| 10 | `RequestProject/NullSectorTask06/Task04Comparison.lean` | (9), `NullSectorTask04.ProperIsotropy` | `COMPARISON ONLY`, late Task-04 comparison |
| B1 | `RequestProject/NullSectorTask06/AssociativityObstruction.lean` | (2) | Phase B: universal associativity question |
| B2 | `RequestProject/NullSectorTask06/NormObstruction.lean` | (2) | Phase B: universal global-norm question |
| B3 | `RequestProject/NullSectorTask06/UniversalObstructionSummary.lean` | (B1), (B2) | Phase-B summary |
| T | `RequestProject/NullSectorTask06/Task06.lean` | (10), (B3) | principal theorems, `#print axioms` |

Phase-B modules (B1), (B2) depend on `Task06.SafeBase` and
`Task06.GenericExtension` **only**.  They do not depend on
`Task06.Rigidity`, `Task06.Existence`, `Task06.ExactClassification`,
`Task06.OrientationReversal`, `Task06.Identification` or
`Task06.Task04Comparison`.  Complete independence was achieved; no exception had
to be explained.

Total new Lean source: 2082 lines in 14 files.

---

## 3. Exact allowed imported declarations (`INPUT`)

Imported through `NullSectorTask04.GlobalExtension`, whose transitive closure is
exactly

```
RequestProject.NullSectorTask01.Basic
RequestProject.NullSectorTask02.LorentzData
RequestProject.NullSectorTask02.CandidateProduct
RequestProject.NullSectorTask02.FixedUnit
RequestProject.NullSectorTask04.Lorentz4
RequestProject.NullSectorTask04.RestSpace
RequestProject.NullSectorTask04.Sectors
RequestProject.NullSectorTask04.GlobalExtension
```

Declarations actually used:

* carrier and forms: `NullSectorTask01.Vec4`, `Q4`, `Long`, `Q2`;
* polarization: `NullSectorTask04.L4`, `L4_apply`, `L4_coord`, `L4_symm`,
  `L4_add_left/right`, `L4_smul_left/right`, `L4_sub_left`, `L4_neg_*`,
  `L4_self`, `L4_e₀_left`, `L4_e₀_right`, `vec4_ext`;
* chosen unit: `NullSectorTask04.e₀`, `e₀_fst`, `e₀_snd`, `Q4_e₀`;
* rest space: `Rest`, `mem_Rest`, `Vec3`, `sp`, `sp_add`, `sp_smul`,
  `sp_snd`, `sp_injective`, `sp_mem_Rest`, `rest_eq_sp`, `vec4_decomp`,
  `dot3` with its bilinearity lemmas, `dot3_self_nonneg`,
  `dot3_self_eq_zero_iff`, `h`, `h_sp`, `h_self`, `s₁`, `s₂`, `s₃`;
* sectors: `UnitSpacelike`, `unitSpacelike_iff`, `unitSpacelike_sp_iff`,
  `unitSpacelike_spatial`, `unitSpacelike_s₁/s₂/s₃`, `iotaS`, `muLong`,
  `muLong_apply` (the independently reconstructed `1+1` product);
* global layer: `BiProd4`, `SectorCompatible`, `Commutative4`, `Associative4`,
  `Q4Multiplicative`, `GlobalUnit`, `M_add_left/right`, `M_smul_left/right`,
  `M_unit_left`, `M_unit_right`, `M_rest_sq`, `M_rest_symm`, `M_expand`.

Library declarations used from Mathlib: standard `LinearMap.mk₂`,
`LinearMap.ext`, `Submodule` API (`Submodule.mem_span_singleton`,
`Submodule.span_le`, `Submodule.mem_bot`), `LinearEquiv.prodCongr`,
`Function.Injective`, and the tactics `ring`, `linarith`, `nlinarith`,
`norm_num`, `simp`, `abel`, `module`, `linear_combination`, `fin_cases`.
`Mathlib.LinearAlgebra.CrossProduct` (`crossProduct`) is imported **only** by
the `COMPARISON ONLY` module (9).

---

## 4. Exact rejected Task-04 modules

Not imported by any Phase-A reconstruction module or any Phase-B module:

```
RequestProject.NullSectorTask04.Classification     (contains the explicit nonzero alternating witness)
RequestProject.NullSectorTask04.IdentityAudit      (uses that witness)
RequestProject.NullSectorTask04.Isotropy           (imports IdentityAudit)
RequestProject.NullSectorTask04.ProperIsotropy     (contains the coordinate alternating map and its transport)
RequestProject.NullSectorTask04.Overlap
RequestProject.NullSectorTask04.Identification
RequestProject.NullSectorTask04.Task04
```

`NullSectorTask04.ProperIsotropy` is imported by exactly one file,
`Task06/Task04Comparison.lean`, the last Phase-A module before `Task06.lean`.
Because the generic extension theorem exists in Task 04 only inside the
contaminated `Classification` module, it was **re-proved** in
`Task06/GenericExtension.lean` (`RE-DERIVED`).  Likewise the stabilizer
machinery (which in Task 04 lives in `Isotropy`, transitively contaminated) was
re-proved in `Task06/ProperAction.lean`, and the orientation criterion was
re-defined there **without** any alternating bilinear map.

---

## 5. Experiment-1 firewall

No Experiment-1 result, source, theorem, terminology, formula, repository or
Lean declaration was consulted or used.  A token scan of all Task-06 sources for

```
Jordan, Clifford, GeometricAlgebra, geometric algebra, exterior, bivector,
pseudoscalar, spinor, Pauli, quaternion
```

returns **zero hits** in every Task-06 file (the reconstruction modules, the
Phase-B modules, the comparison modules and `Task06.lean`).

---

## 6. Terminology firewall

Scanned tokens (case-insensitive):

```
crossProduct, cross product, LeviCivita, Levi-Civita, epsilonTensor,
orientationTensor, Hodge, axial, pseudovector, quaternion, Quaternion,
Clifford, GeometricAlgebra, Pauli, altBasis, alt3
```

| file | hits |
|---|---|
| `SafeBase.lean` | 0 |
| `GenericExtension.lean` | 0 |
| `ProperAction.lean` | 0 |
| `UnknownDefect.lean` | 0 |
| `Rigidity.lean` | 0 |
| `Existence.lean` | 0 |
| `ExactClassification.lean` | 0 |
| `OrientationReversal.lean` | 0 |
| `AssociativityObstruction.lean` | 0 |
| `NormObstruction.lean` | 0 |
| `UniversalObstructionSummary.lean` | 0 |

`crossProduct` occurs only in `Identification.lean` (`COMPARISON ONLY`) and in
the corresponding principal theorem in `Task06.lean`; the Task-04 witness names
occur only in `Task04Comparison.lean` (`COMPARISON ONLY`) and in the principal
comparison theorem.  No forbidden declaration was renamed and re-used: the
Task-06 witness is constructed from scratch in `Existence.lean` and only
*afterwards* compared with the Task-04 one.

Transitive imports were audited: the import closure listed in §3 is complete and
contains none of the rejected modules of §4.

---

## 7. Structural witness firewall

Every declaration occurring **before** the rigidity theorem whose type could
encode a bilinear map `Rest → Rest → Vec4` (or `Rest → Rest → Rest`):

| declaration | file | type | verdict |
|---|---|---|---|
| `RestDefect` | GenericExtension | `Vec3 →ₗ[ℝ] Vec3 →ₗ[ℝ] Vec4` | type abbreviation only — no inhabitant defined |
| `Alternating` | GenericExtension | `RestDefect → Prop` | predicate |
| `extensionFromDefect` | GenericExtension | `RestDefect → BiProd4` | `STRUCTURAL OPERATION` (applied to an abstract argument) |
| `defectOfProd` | GenericExtension | `BiProd4 → RestDefect` | `STRUCTURAL OPERATION` (extraction from an abstract `M`) |
| `0 : RestDefect` (in `alternating_zero`, `extensionFromDefect_zero`) | GenericExtension | `RestDefect` | `ZERO ONLY` |
| `symForced` | GenericExtension | `BiProd4` | symmetric, not alternating; `M X Y = M Y X` is proved |
| `SymPart`, `AltPart` | GenericExtension | operators on an abstract `M` | `STRUCTURAL OPERATION` |
| `det3` | ProperAction | `Vec3 → Vec3 → Vec3 → ℝ` | `STRUCTURAL OPERATION` — scalar trilinear orientation criterion, **not** a bilinear map into the carrier, and not defined through any such map |
| `detRest`, `ProperStab`, `Stab` | ProperAction | predicates / scalars | `STRUCTURAL OPERATION` |
| `rho` | ProperAction | `Vec3 → Vec3 → Vec3 → Vec3 → Vec3` | linear expansion along a triple; linear in its last argument, not alternating |
| `restOf`, `liftRest`, `mkEquiv3`, `hx, hy, hz, qz, qx, refz` | ProperAction | rest-space maps `Vec3 → Vec3` | unary linear maps, not bilinear |
| `ProperEquivariant`, `FullEquivariant`, `ProperEquivariantProd`, `IsotropyEquivariantProd` | UnknownDefect | predicates | `ABSTRACT VARIABLE` context |
| `tempPart`, `spatPart` | UnknownDefect | component extractors of an abstract `A` | `ABSTRACT VARIABLE` |
| section variable `A : RestDefect` | Rigidity | `RestDefect` | `ABSTRACT VARIABLE` |

**No `NONZERO CANDIDATE` occurs before the rigidity theorem.**  The first
explicit nonzero alternating map in the whole Task-06 development is
`NullSectorTask06.wit3` / `witDefect`, defined in
`RequestProject/NullSectorTask06/Existence.lean` (see §14).

---

## 8. Source-order audit

Actual import order (a later file may import an earlier file; the reverse never
occurs — verified by the import table of §2, which is acyclic and linear):

```
SafeBase → GenericExtension → ProperAction → UnknownDefect → Rigidity
   → Existence → ExactClassification → OrientationReversal
   → Identification → Task04Comparison → Task06
```

matching the required order

```
unknown alternating defect (UnknownDefect)
        ↓
proper-isotropy constraints (ProperAction + UnknownDefect)
        ↓
rigidity / upper classification (Rigidity)
        ↓
existence question, explicit witness (Existence)
        ↓
exact solution-space theorem (ExactClassification)
        ↓
coordinate formula (ExactClassification, after the classification)
        ↓
orientation-reversal theorem (OrientationReversal)
        ↓
late conventional identification (Identification)
        ↓
late Task-04 comparison (Task04Comparison)
```

Phase B branches off after `GenericExtension`:

```
SafeBase → GenericExtension → {AssociativityObstruction, NormObstruction}
                                  → UniversalObstructionSummary
```

---

## 9. Clean generic-extension theorem (`RE-DERIVED`)

`NullSectorTask06.sectorCompatible_iff_defect`:

```lean
SectorCompatible M ↔ ∃ A : RestDefect, Alternating A ∧ M = extensionFromDefect A
```

with

* `extensionFromDefect A X Y = symForced X Y + A X.2 Y.2`;
* `symForced X Y = L4 X e₀ • Y + L4 Y e₀ • X - L4 X Y • e₀`
  (`symForced_coordfree`);
* uniqueness of the defect: `defect_unique`, `defectOfProd_extensionFromDefect`;
* symmetric/alternating split: `symPart_eq`, `altPart_eq`.

The codomain of `A` is the full `Vec4`; nothing here assumes the defect is
purely spatial.  Its vanishing temporal part is a later `RIGIDITY RESULT`
(§12) and is proved only under proper equivariance.

Packaged as `task06_generic_extension`.

---

## 10. Proper isotropy definition

`NullSectorTask06.Stab R := R e₀ = e₀ ∧ ∀ X, Q4 (R X) = Q4 X` for
`R : Vec4 ≃ₗ[ℝ] Vec4`.

`DERIVED` from that definition alone (`task06_proper_isotropy`):

* `stab_L4` — preservation of the polarized form;
* `stab_time` — preservation of the time component, and `stab_future`:
  `0 < X.1 → 0 < (R X).1`;
* `stab_rest` — preservation of the rest space;
* `stab_h` — preservation of the induced positive rest-space form;
* `restOf_dot3`, `restOf_add`, `restOf_smul`, `stab_columns` — the induced
  rest-space map is linear and orthonormal on the basis.

Orientation criterion: `det3` is the Leibniz/Sarrus scalar expression written
out by hand, `detRest R = det3 (restOf R r₁) (restOf R r₂) (restOf R r₃)`, and

```lean
ProperStab R := Stab R ∧ detRest R = 1.
```

No conventional group name was used as a proof shortcut; the group is never
identified by name in the reconstruction.

Explicit elements, each built from a coordinate formula with its determinant
computed: `hx, hy, hz` (half-turns, `det = 1`), `qz, qx` (quarter-turns,
`det = 1`), and `refz` (reflection, `det = -1`, hence `¬ ProperStab`).

---

## 11. Unknown-defect setup

`A : RestDefect` is an abstract variable.  Equivariance:

```lean
ProperEquivariant A := ∀ R, ProperStab R → ∀ v w, R (A v w) = A (restOf R v) (restOf R w)
FullEquivariant  A := ∀ R, Stab R       → ∀ v w, R (A v w) = A (restOf R v) (restOf R w)
```

Output split relative to `e₀`: `tempPart A v w = (A v w).1`,
`spatPart A v w = (A v w).2`, `A v w = tempPart • e₀ + sp spatPart`
(`defect_decomp`).  Proper isotropy acts trivially on `tempPart`
(`tempPart_invariant`) and through `restOf R` on `spatPart`
(`spatPart_equivariant`).  Neither component is assumed to vanish.

Bridges between products and defects: `properEquivariant_of_prod`,
`fullEquivariant_of_prod`, `properEquivariantProd_extensionFromDefect`,
`isotropyEquivariantProd_extensionFromDefect`.

---

## 12. Basis-pair rigidity results

All in `Task06/Rigidity.lean`; only bilinearity, alternation, orthonormality of
`r₁, r₂, r₃` and the explicit transformations of §10 are used.

| theorem | content | status |
|---|---|---|
| `rigidity_r₂r₃` | `A r₂ r₃ = c • sp r₁` with `c = (A r₂ r₃).2.1` — the half-turns `hz` and `hx` kill the temporal component and both transverse spatial components | `RIGIDITY RESULT` (alternation not even needed) |
| `rigidity_r₃r₁` | `A r₃ r₁ = c • sp r₂`, same `c` — quarter-turn `qz` | `RIGIDITY RESULT` |
| `rigidity_r₁r₂` | `A r₁ r₂ = c • sp r₃`, same `c` — quarter-turn `qx` | `RIGIDITY RESULT` |
| `rigidity_basis_pairs` | the three values together, one parameter | `RIGIDITY RESULT` |
| `rigidity_temporal_zero` | `∀ v w, tempPart A v w = 0` | `DERIVED` (not assumed) |
| `rigidity_values_in_rest` | `A v w ∈ Rest` | `DERIVED` |
| `rigidity_unique` | equal parameters ⇒ equal defects | `RIGIDITY RESULT` (upper bound) |
| `rigidity_eq_zero_of_param_zero` | parameter `0` ⇒ `A = 0` | `RIGIDITY RESULT` |

Answers to the questions of §12 of the task:

* which components must vanish: the whole `e₀`-component, and, for each basis
  pair, the two spatial components transverse to the "third" direction;
* which components may survive: exactly one spatial component per basis pair;
* which surviving components are related: all three are the **same** real number
  `c`;
* sign relations: forced — the quarter-turns fix the cyclic order and give
  `+c` in each of `(r₂,r₃) ↦ r₁`, `(r₃,r₁) ↦ r₂`, `(r₁,r₂) ↦ r₃`; alternation
  gives the opposite signs on the transposed pairs;
* one value determines the others: yes;
* additional independent values: none.

The statements mention no pre-existing conventional alternating operation.

---

## 13. Solution-space classification

`Task06/ExactClassification.lean`:

* `properEquivariant_iff`: `Alternating A ∧ ProperEquivariant A ↔ ∃ c, A = c • witDefect`;
* `properSolutions_eq_span`: `ProperSolutions = ℝ ∙ witDefect`;
* `smul_witDefect_injective`: the parameterization is injective;
* `properSolutionsEquiv : ℝ ≃ₗ[ℝ] ProperSolutions`.

Verdict: `FINITE-DIMENSIONAL`, dimension exactly `1`, `CONTINUOUS FREEDOM`
(one real parameter), `NON-UNIQUE` as a defect but `UNIQUE` once the parameter
is fixed.  The upper bound (§12) was established **before** any witness existed;
the equality of the solution space with the span uses the witness of §15.

At product level: `sectorCompatible_properEquivariant_iff`,
`glueFam_injective`, `glueFam_zero = symForced`.

---

## 14. First location of any explicit nonzero witness

```
RequestProject/NullSectorTask06/Existence.lean, line 33: def wit3
RequestProject/NullSectorTask06/Existence.lean, line 59: def witDefect
```

This is strictly after `Task06/Rigidity.lean` in the import order, and
`Rigidity.lean` does not import `Existence.lean` (the reverse holds).  No
earlier file contains an explicit alternating coordinate polynomial, a basis
multiplication table, a determinant-based alternating formula, an
orientation-tensor construction, or a library object implementing such a map
(§7).

The witness was obtained by substituting the rigidity conclusion
(`A r₂ r₃ = r₁`, `A r₃ r₁ = r₂`, `A r₁ r₂ = r₃`, `c = 1`) into the general
bilinear expansion `alternating_expand`.

---

## 15. Existence theorem

`Task06/Existence.lean`:

| theorem | content |
|---|---|
| `witDefect_alternating` | alternation |
| `wit3_proper`, `witDefect_properEquivariant` | proper equivariance, proved from orthonormality of the images of the basis, the determinant condition, the reciprocal expansion and the cofactor identity (`recip_expansion`, `wit3_of_rho`, `wit3_triple`) |
| `witDefect_ne_zero` | nontriviality (`(witDefect r₂ r₃).2.1 = 1`) |
| `exists_nonzero_properEquivariant` | `EXISTENCE WITNESS` |
| `smul_witDefect_alternating`, `smul_witDefect_properEquivariant`, `smul_witDefect_param` | the whole line of multiples |

Combined with §12 this yields the exact classification of §13.

---

## 16. Coordinate formula derived after classification

`properEquivariant_coordinate_formula` (and `task06_coordinate_formula`):

```lean
A v w = (A r₂ r₃).2.1 •
  (0, v.2.1 * w.2.2 - v.2.2 * w.2.1,
      v.2.2 * w.1   - v.1   * w.2.2,
      v.1   * w.2.1 - v.2.1 * w.1)
```

It is a consequence of the basis-pair classification (§12), bilinearity and
alternation (`alternating_expand`).  Exactly **one** scalar coefficient remains;
its role is to scale the unique surviving alternating direction, and it is a
`FREE DATUM` of the gluing problem — no Task-06 input fixes its value.  No
library operation was invoked to obtain the formula.

---

## 17. Orientation-reversal result

`Task06/OrientationReversal.lean`.  With `refz` the explicit reflection
(`detRest (liftRest refz) = -1`) and
`reverseDefect A v w = liftRest refz (A (refz v) (refz w))`:

| theorem | content | status |
|---|---|---|
| `reverseDefect_involutive` | the action has order two | `DERIVED` |
| `reverseDefect_smul_witDefect` | `reverseDefect (c • witDefect) = (-c) • witDefect` | `DERIVED` — the reflection **negates** the parameter; it neither fixes nor permutes it |
| `reverseDefect_fixed_iff` | the only fixed point is `c = 0` | `DERIVED` |

---

## 18. Full-isotropy result

| theorem | content | status |
|---|---|---|
| `fullEquivariant_iff` | `Alternating A ∧ FullEquivariant A ↔ A = 0` | `UNIQUE` (zero solution only) |
| `sectorCompatible_fullEquivariant_iff` | `SectorCompatible M ∧ IsotropyEquivariantProd M ↔ M = symForced` | `UNIQUE` |

So the full rest-space isotropy group leaves **no** gluing freedom: the surviving
`CONTINUOUS FREEDOM` of §13 is precisely the orientation-sensitive part.

---

## 19. Late conventional identification — `COMPARISON ONLY`

`Task06/Identification.lean`, first module allowed to name conventional
structures:

* `wit3_eq_crossProduct`: under `toFin3 : ℝ×ℝ×ℝ → (Fin 3 → ℝ)`,
  `toFin3 (wit3 v w) = crossProduct (toFin3 v) (toFin3 w)`
  (`crossProduct` from `Mathlib.LinearAlgebra.CrossProduct`);
* `properSolutions_eq_crossProduct_multiples`: the whole solution space consists
  of the real multiples of that conventional operation.

`IMPORTED STANDARD RESULT`: the definition of `crossProduct`
(`Mathlib.LinearAlgebra.CrossProduct`).
`DERIVED IN TASK 06`: everything else in §§9–18.

---

## 20. Task-04 comparison — `COMPARISON ONLY`

`Task06/Task04Comparison.lean` (the only Task-06 module importing
`NullSectorTask04.ProperIsotropy`):

| theorem | content |
|---|---|
| `det3_eq_task04`, `detRest_eq_task04` | the two orientation criteria are the same scalar function (Task 04 defines it through its alternating map, Task 06 by the Leibniz formula) |
| `stab_iff_task04`, `properStab_iff_task04` | the two symmetry groups are literally the same set of transformations |
| `properEquivariantProd_iff_task04` | the two equivariance predicates coincide |
| `symForced_eq_task04` | the forced symmetric branches coincide |
| `witDefect_eq_task04` | the independently reconstructed witness equals the Task-04 witness |
| `glueFam_eq_task04` | the two one-parameter families coincide term by term |
| `task06_replicates_task04` | the two reported solution spaces are the same |
| `orientation_reversal_agrees` | both developments give `c ↦ -c` |
| `full_isotropy_agrees` | both give uniqueness under full isotropy |

Task 04 was treated as a comparison target only: the Task-06 classification was
complete and compiled before this module was written, and nothing in Phase A was
adjusted to match it.

---

## 21. Replication verdict

```
TASK04 PROPER-ISOTROPY RESULT REPLICATED
```

Exact references: `NullSectorTask06.task06_task04_replication` (combining
`NullSectorTask06.sectorCompatible_properEquivariant_iff` and
`NullSectorTask04.sectorCompatible_properIsotropy_classification`),
`NullSectorTask06.glueFam_eq_task04`,
`NullSectorTask06.witDefect_eq_task04`,
`NullSectorTask06.orientation_reversal_agrees`,
`NullSectorTask06.full_isotropy_agrees`.

Methodological reading (see also §31 of the task):

* **A. Task-04 kernel correctness** — unaffected; no Task-04 theorem was found
  to be false.
* **B. Task-04 blind-reconstruction quality** — the earlier implementation
  introduced an explicit nonzero coordinate model before the symmetry
  classification had forced its form; that ordering defect is real and is what
  Task 06 repairs.
* **C. Task-06 independent replication** — the former methodological defect did
  not alter the mathematical classification, and the result has now been
  independently reconstructed under a stronger blind firewall.

This verdict concerns the formerly contaminated part only; unrelated Task-04
theorems are untouched.

---

## 22. Universal associativity result

```
ASSOCIATIVITY: impossible — UNIVERSAL OBSTRUCTION
```

`no_associative_sectorCompatible`:
`∀ M, SectorCompatible M → ¬ Associative4 M`, and the existential form
`not_exists_associative_sectorCompatible`.  Quantification is over **all**
sector-compatible bilinear products, i.e. over the whole generic defect space of
§9; no isotropy, commutativity, orientation or witness assumption occurs
(`task06_obstructions_isotropy_independent` records that adding any further
hypothesis cannot help).

---

## 23. Minimal associativity obstruction

Required basis vectors: two orthonormal rest directions, `sp r₁` and `sp r₂`.

Sector identities used:

```
M e₀ X = X,  M X e₀ = X                      (derived global unit)
M (sp r₁) (sp r₁) = e₀,  M (sp r₂) (sp r₂) = e₀      (inherited sector squares)
M (sp r₁) (sp r₂) + M (sp r₂) (sp r₁) = 0            (inherited symmetrization, dot3 r₁ r₂ = 0)
```

Cross-sector product constrained: `p := M (sp r₁) (sp r₂)`, which is exactly the
unknown defect value `A r₁ r₂` and is *a priori* completely free.

Chain (`square_of_anticommuting_units`, no coordinates, no positivity):

```
M p b = M (M a b) b = M a (M b b) = M a e₀ = a
M b p = M (M b a) b = M (-p) b = -a
M p p = M a (M b p) = M a (-a) = -e₀
```

Final incompatible equations (`associativity_incompatible_equations`,
`sq_time_component`): writing `p = τ • e₀ + sp u`,

```
τ ^ 2 + dot3 u u = -1        while        0 ≤ τ ^ 2 + dot3 u u.
```

Only two spatial directions and four products are involved; no classification
theorem of associative real algebras is used.

---

## 24. Universal global-norm result

```
GLOBAL Q4 MULTIPLICATIVITY: impossible — UNIVERSAL OBSTRUCTION
```

`no_Q4Multiplicative_sectorCompatible`:
`∀ M, SectorCompatible M → ¬ Q4Multiplicative M`, with existential form
`not_exists_Q4Multiplicative_sectorCompatible`.  Proved in a module that does
not import the associativity module; associativity is never used.

---

## 25. Minimal norm obstruction

Required basis vectors: again `sp r₁`, `sp r₂` (and their sum).

Ingredients: `M (sp r₁) (sp r₁) = e₀`, bilinearity, `Q4 (sp r₁) = -1`,
`Q4 (sp r₁ + sp r₂) = -2`, and `Q4 (X+Y) = Q4 X + 2 L4 X Y + Q4 Y`.

Two evaluations of the multiplicativity requirement, with
`p = M (sp r₁) (sp r₂) = τ • e₀ + sp u`:

```
Q4 p = Q4 (sp r₁) * Q4 (sp r₂) = 1                    ⇒  τ ^ 2 - dot3 u u = 1
Q4 (e₀ + p) = Q4 (sp r₁) * Q4 (sp r₁ + sp r₂) = 2     ⇒  (1 + τ) ^ 2 - dot3 u u = 2
```

Their difference gives `τ = 0`, hence `dot3 u u = -1`, impossible for the
positive rest-space form (`norm_incompatible_equations`).

---

## 26. Separation of the two properties

The two questions were settled in separate modules with disjoint proofs:
`AssociativityObstruction.lean` (uses associativity, never `Q4`
multiplicativity) and `NormObstruction.lean` (uses `Q4` multiplicativity, never
associativity).  Neither imports the other.  Both are `UNIVERSAL OBSTRUCTION`.
Neither impossibility was inferred from the other.

---

## 27. Optional joint theorem

`no_associative_and_Q4Multiplicative` /
`task06_joint_obstruction`: no sector-compatible product is simultaneously
associative and globally `Q4`-multiplicative.  Recorded only after the two
separate results; it is a summary, not the principal objective.

---

## 28. Updated Conservation-of-Difficulty graph

Generated from the results above, not written in advance.

```
3+1 Lorentz form Q4  +  chosen future unit e₀            [INPUT]
        ↓ polarization, rest space, positive form        [INPUT]
longitudinal sectors + reconstructed 1+1 product         [INPUT]
        ↓ SectorCompatible
forced symmetric branch  symForced                       [RE-DERIVED, forced]
        +
alternating rest-space defect A : Rest → Rest → Vec4     [FREE DATUM, unique given M]
        ↓ proper isotropy of e₀ (intrinsic, det = +1)
temporal component of A                                  [DERIVED: vanishes]
spatial component of A                                   [RIGIDITY RESULT: one real parameter]
        ↓ existence question, answered after rigidity
nonzero solution                                         [EXISTENCE WITNESS]
        ↓
solution space = ℝ ∙ witDefect                            [FINITE-DIMENSIONAL, dim 1,
                                                          CONTINUOUS FREEDOM]
        ↓ orientation reversal (det = -1)
parameter c ↦ -c                                          [DERIVED, DISCRETE FREEDOM removed:
                                                          only c = 0 is invariant]
        ↓ full isotropy
A = 0, product unique                                     [UNIQUE]

independently, from SectorCompatible alone (no isotropy):
        ↓
global associativity                                      [UNIVERSAL OBSTRUCTION]
global Q4 multiplicativity                                [UNIVERSAL OBSTRUCTION]
minimal configuration: two orthonormal rest directions    [identified]
```

Answers to the §30 questions:

1. **Yes** — the orientation-sensitive result is independently reproducible with
   no predefined nonzero candidate (§§12–15, §21).
2. Exact solution space: a one-dimensional real vector space, `ℝ ∙ witDefect`
   (§13).
3. Forced by symmetry: the vanishing of the temporal output component, the
   vanishing of the transverse spatial components on each basis pair, the
   equality of the three surviving coefficients and their signs (§12).
4. Remaining freedom after proper isotropy: exactly one real scalar
   (`CONTINUOUS FREEDOM`); no `DISCRETE FREEDOM` beyond it.
5. Orientation reversal negates that scalar (§17).
6. Under full isotropy nothing survives: the zero defect only (§18).
7. The associativity obstruction is **universal**, not specific to the
   symmetry-restricted family (§22).
8. The global-norm obstruction is **universal** as well (§24).
9. Each obstruction first appears at two orthonormal rest directions together
   with their inherited sector squares and symmetrization (§§23, 25).

---

## 29. Precise diagnostic handoff

Neutral statement (`diagnostic_handoff`, `task06_minimal_configuration`):

> Inside the fixed real `3+1` carrier, two mutually orthogonal rest directions
> cannot both satisfy the inherited sector square relations
> (`x ⋆ x = e₀`, `x ⋆ y + y ⋆ x = 0`) together with global associativity, and
> cannot both satisfy them together with global `Q4` multiplicativity: in each
> case the `e₀`-component of the square of their product is forced to be
> simultaneously a sum of squares and equal to `-1`.

Equivalently: closure inside `Vec4` is incompatible with either property under
the inherited sector identities.  No repair, enlargement, or candidate
continuation is proposed, and none is implied.

---

## 30. Build report

```
$ lake build
Build completed successfully (8068 jobs).
```

The whole project (Tasks 01–04 and the new Task 06) compiles with no errors and
no warnings.  A repository-wide scan for `sorry`, `admit`, `axiom` and
`@[implemented_by]` in `RequestProject/` returns no occurrences (the only
matches are the substring "admits" in ordinary prose).

---

## 31. Axiom report

`#print axioms` at the end of `RequestProject/NullSectorTask06/Task06.lean`
reports, for **all nineteen** principal theorems

```
task06_generic_extension, task06_proper_isotropy, task06_rigidity,
task06_rigidity_upper_bound, task06_existence, task06_exact_classification,
task06_coordinate_formula, task06_product_classification,
task06_orientation_reversal, task06_full_isotropy, task06_identification,
task06_task04_replication, task06_minimal_configuration,
task06_associativity_universal, task06_associativity_minimal_equations,
task06_norm_universal, task06_norm_minimal_equations,
task06_obstructions_isotropy_independent, task06_joint_obstruction
```

exactly

```
[propext, Classical.choice, Quot.sound]
```

No custom axiom was introduced anywhere.

---

## 32. Required negative controls

| Question | Required | Result | Theorem |
|---|---|---|---|
| Can the generic Task-04 extension theorem be imported without contaminated dependencies? | yes/no | **no** — it lives only in `NullSectorTask04.Classification`, which also contains the nonzero witness | §4 |
| If not, can it be cleanly re-derived? | prove/refute | **prove** (`RE-DERIVED`) | `sectorCompatible_iff_defect`, `task06_generic_extension` |
| Does proper isotropy force the temporal part of an alternating defect to vanish? | prove/refute | **prove** | `rigidity_temporal_zero` |
| Does proper isotropy constrain the spatial part? | classify | one real parameter; all three basis-pair values equal to it, with forced signs | `rigidity_basis_pairs` |
| What is the exact proper-equivariant solution space? | classify | `FINITE-DIMENSIONAL`, dimension `1`: `ℝ ∙ witDefect` | `properEquivariant_iff`, `properSolutions_eq_span`, `properSolutionsEquiv` |
| Does a nonzero proper-equivariant defect exist? | prove/refute | **prove** (after rigidity) | `exists_nonzero_properEquivariant` |
| Does orientation reversal act trivially on that solution space? | classify | **no** — it acts by `c ↦ -c`; only `c = 0` is fixed | `reverseDefect_smul_witDefect`, `reverseDefect_fixed_iff` |
| What is the full-isotropy solution space? | classify | zero only; the product is `UNIQUE` | `fullEquivariant_iff`, `sectorCompatible_fullEquivariant_iff` |
| Does the clean result reproduce Task 04? | compare | `REPLICATED` | `task06_task04_replication` |
| Does any sector-compatible associative extension exist? | prove/refute | **refute** — `UNIVERSAL OBSTRUCTION` | `no_associative_sectorCompatible` |
| Does any sector-compatible globally `Q4`-multiplicative extension exist? | prove/refute | **refute** — `UNIVERSAL OBSTRUCTION` | `no_Q4Multiplicative_sectorCompatible` |
| If either is impossible, is the obstruction independent of isotropy? | prove | **prove** — the theorems assume only sector compatibility | `task06_obstructions_isotropy_independent` |
| What minimal spatial configuration exhibits the obstruction? | identify | two orthonormal rest directions with their inherited sector squares and symmetrization | `task06_minimal_configuration`, §§23, 25 |

No row is `UNRESOLVED`.

---

## 33. Unresolved mathematical obligations

1. The value of the surviving real parameter `c` is a `FREE DATUM`: no Task-06
   input distinguishes any nonzero value from another.  (Only `c = 0` is
   distinguished, and only by adding orientation reversal.)
2. Group generation is not proved: it is not shown that the exhibited
   half-turns, quarter-turns and reflection generate the whole proper (resp.
   full) rest-space isotropy group.  This is not needed — both directions of
   every classification are proved: rigidity uses finitely many explicit
   transformations, and the converse verifies equivariance for *all* of them.
3. Varying the timelike unit, or varying the rest basis, is outside Task 06; the
   development is stated for the fixed unit `e₀` and the fixed coordinate basis
   used as infrastructure.  (Independence of the classification from that choice
   is not claimed.)
4. Phase B localizes the two obstructions but does not claim minimality of the
   exhibited configuration in any formal sense: it is only proved that two
   orthonormal rest directions suffice, not that fewer data can never suffice.
5. No statement is made about products that are not bilinear, not real, or not
   sector compatible; the carrier was not enlarged and no repair was attempted.
