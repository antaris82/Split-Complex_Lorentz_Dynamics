# Task XXV audit — lifted-frame torsor hardening and one-fibre interface freeze

Environment (verified against the pinned toolchain of this repository):

* Lean version: `v4.28.0` (`lean-toolchain`)
* Mathlib revision: `v4.28.0`, commit `8f9d9cff6bd728b17a24e163c9402775d9e6a365`
  (`lake-manifest.json`)
* New modules import only earlier modules of this repository (transitively Mathlib); no new
  external dependency was added, and `lakefile.toml` was not modified.

Naming convention used throughout: the informal names of the task statement correspond to the
**inherited** objects

| task statement | inherited declaration |
| --- | --- |
| `Lift` | `NullSectorTask24.LiftGrp` ( = `NullSectorTask21.LiftG`) |
| `proj` | `NullSectorTask21.projCore : LiftG →* GvisG` |
| `Gvis` | `NullSectorTask24.Gvis` ( = `NullSectorTask21.GvisG`) |
| `FramePlus` | `NullSectorTask24.FramePlus` |
| `LiftedFrame F₀` | `NullSectorTask24.LiftedFrame F₀` |
| `KerSign` | `NullSectorTask23.KerSign` ( = `projCore.ker`) |
| `signSmul` | `NullSectorTask24.signSmul` |
| `liftedFrameProj` | `NullSectorTask24.liftedFrameProj` |
| `liftedTransfer` | `NullSectorTask24.liftedTransfer` |

The identifier `Lift` was *not* introduced in Task 25, because it already denotes an inherited
*set* of the ambient algebra in an opened namespace; `LiftGrp` is used verbatim instead.

---

## 1. Scope firewall report

* **No Task-XXIV file was modified.** `git log`/`git diff` for this run touches only new files
  under `RequestProject/NullSectorTask25/` plus documentation. Not even an import-only change
  to inherited sources was necessary (item 102).
* No Task-XXIV definition was redefined; `FramePlus`, `Gvis`, `LiftGrp`, `projCore`,
  `LiftedFrame`, `KerSign`, `signSmul`, `liftedTransfer`, `frameHom` are used as inherited.
* No Task-XXIV theorem statement was altered or reinterpreted. Where a Task-XXIV theorem is
  reused (`liftedTransfer_choice`, `liftedFrame_eq_iff_sign`, `liftedTransfer_proj`,
  `existsUnique_gvis_map_frame`, `lact_stabilizer`, `lact_not_free`, `projCore_eq_iff`,
  `mem_KerSign_iff'`, `projCore_surjective`, `exists_nontrivial_gvis`) it is applied as a black
  box.
* No base space, fibre family, tangent bundle, vector bundle, principal bundle, spin
  structure, characteristic class, cohomology, connection, curvature, dynamics, field, state or
  physical spin occurs anywhere in the Task-25 layer.
* No general torsor or principal-bundle API is imported: only elementary
  `free` / `transitive` / `∃!` statements and Mathlib's `MulAction` class are used.
* No topology is introduced (item: stop-on-hard-frontier). It remains an unresolved obligation,
  exactly as recorded in Task 24.

---

## 2. Module chain

```
RequestProject/NullSectorTask24/Task24.lean        (inherited endpoint)
      ↓
NullSectorTask25/LiftedFrameAction.lean            Packages A, B, C, D
      ↓
NullSectorTask25/LiftedFrameEquivariance.lean      Packages E, F, G + negative controls 86–88
      ↓
NullSectorTask25/ReferenceTransferHardening.lean   Packages H, I, J + negative control 89
      ↓
NullSectorTask25/OneFiberInterface.lean            Packages K, M
      ↓
NullSectorTask25/Task25.lean                       principal endpoints + axiom report
```

Five new modules (target was 4–6).

---

## 3. Exact new definitions

| Name | Statement |
| --- | --- |
| `liftSmul F₀ a x` | `⟨(a * x.elt, projCore a • x.frame), _⟩` — the internal action upstairs |
| `instSMulLiftGrpLiftedFrame`, `instMulActionLiftGrpLiftedFrame` | the packaged `MulAction LiftGrp (LiftedFrame F₀)` |
| `liftsOf g` | `{u : LiftGrp | projCore u = g}`, the fibre of the projection |
| `OneFiberLiftInterface` | record of already-proved one-fibre data (see §8) |
| `ReferencePresentation`, `LiftChoice F₀ F₁` | *temporary presentation* data, kept outside the interface |
| `oneFiberInterface F₀` | the interface instance built from the Task-25 theorems |
| `InterfaceEquiv I J` | equivalence of interfaces (carrier equivalence + action + projection compatibility) |
| `oneFiberInterfaceEquiv F₀ F₁ c` | the interface equivalence attached to a chosen lift `c` |
| `someLiftChoice F₀ F₁` | *some* lift choice (never unique — there are exactly two) |
| `FiberFamilyInput` | neutral, uninstantiated record naming the first missing Task-XXVI node |

The definition of `liftSmul` discharges the lifted-frame compatibility condition inside the
subtype: `projCore (a * x.elt) • F₀ = projCore a • (projCore x.elt • F₀) = projCore a •
x.frame`.

---

## 4. Theorem inventory (principal endpoints)

Priority 1 — action upstairs (`LiftedFrameAction.lean`, `LiftedFrameEquivariance.lean`):

1. `liftSmul` — the action (definition).
2. `liftSmul_one` — identity acts trivially.
3. `liftSmul_mul` — `(a*b) • x = a • (b • x)`.
4. `liftedFrameAction_free` — the action is free; `liftedFrameAction_cancel`,
   `stabilizer_liftedFrame_eq_bot`.
5. `liftedFrameAction_transitive` — transitive, with explicit transporter `y.elt * x.elt⁻¹`
   (`liftedFrame_transporter_elt`, `liftedFrame_transporter_frame`).
6. `existsUnique_lift_map_liftedFrame` — exactly one internal element between two lifted
   frames; `liftedFrame_free_transitive` packages the three statements.
7. `liftedFrameProj_equivariant` (and `liftedFrame_commuting_square`).
8. `liftSmul_restrict_kerSign_eq_signSmul` — the restriction to `KerSign` is *exactly*
   the inherited sign action.
9. `kerSign_trivial_downstairs`.
10. `kerSign_free_upstairs`, `lNegOne_moves_liftedFrame`.
11. `fibre_free_transitive_kerSign` — corollary, not a new construction.

Priority 2 — reference-change closure (`LiftedFrameEquivariance.lean`,
`ReferenceTransferHardening.lean`):

12. `liftedEltEquiv_equivariant`, `liftedEltEquiv_symm_equivariant`,
    `liftedEltEquiv_equivariant_pair`.
13. `two_lifts_of_reference_change`, `liftsOf_reference_change_ncard` (= 2).
14. `lifts_differ_unique_kerSign`, `liftsOf_eq_kerSign_orbit`, `kerSign_inv_self`.
15. `liftedTransfer_equivariant`, `liftedTransfer_proj'`, `liftedTransfer_kerSign`.
16. `liftedTransfer_difference_unique_kerSign`, `liftedTransfer_difference_funext`,
    `liftedTransfer_sign_shift` (the converse of item 69).
17. `reference_change_downstairs_unique_upstairs_two` — the final interpretation theorem.

Priority 3 — interface (`OneFiberInterface.lean`, `Task25.lean`):

18. `oneFiberInterface`, `OneFiberLiftInterface.existsUnique`,
    `oneFiberInterface_kerSign_eq_signSmul`.
19. `oneFiberInterfaceEquiv`, `oneFiberInterface_reference_independent`,
    `oneFiberInterfaceEquiv_ambiguity`, `one_fibre_only`.
20. `task25_final` — the whole success criterion in one theorem.

Negative controls: `liftedFrameAction_free_versus_framePlus`,
`free_upstairs_not_free_downstairs` (86), `exists_nonequivariant_carrier_equiv` (87),
`exists_liftSmul_changes_fibre` (88), `reference_change_not_unique_upstairs` (89).

All Task-25 endpoints are re-exposed in `Task25.lean` under `task25_*` names.

---

## 5. Dependency graph

```
inherited: FramePlus, Gvis action (free+transitive), LiftGrp, projCore, KerSign,
           LiftedFrame F₀, liftedFrameProj, signSmul, liftedTransfer, frameHom
                                   │
                                   ▼
                liftSmul  (Package B: action laws, MulAction)
                    │                         │
     ┌──────────────┴────────────┐            └────────────┐
     ▼                           ▼                         ▼
freeness upstairs        transitivity upstairs      projection equivariance
(Package C)                  (Package D)                 (Package E)
     └──────────┬────────────────┘                         │
                ▼                                          ▼
   existsUnique_lift_map_liftedFrame           kernel restriction = signSmul
                │                                (Package F)
                │                                 │        │
                ▼                                 ▼        ▼
   liftedEltEquiv_equivariant       kerSign trivial     kerSign free
        (Package G)                  downstairs          upstairs
                                          └────┬──────────┘
                                               ▼
                       two lifts of the unique reference change (Package H)
                                               ▼
                        liftedTransfer_equivariant (Package I)
                                               ▼
              liftedTransfer_difference_unique_kerSign (Package J)
                                               ▼
                      OneFiberLiftInterface + reference independence (Package K)
                                               ▼
                        Task-XXVI frontier table (Package L) / FiberFamilyInput (M)
```

Extra assumptions used by the arrows, beyond the inherited data: **none**. Every arrow is a
plain group-theoretic consequence of the inherited group structure, the inherited surjectivity
of `projCore`, and the inherited two-element description of `KerSign`.

---

## 6. Required decision table

| Question | Verdict |
| --- | --- |
| Natural `Lift` action on `LiftedFrame` defined? | **PROVED** (`liftSmul`) |
| Action laws? | **PROVED** (`liftSmul_one`, `liftSmul_mul`, `MulAction` instance) |
| Action free? | **PROVED** (`liftedFrameAction_free`) |
| Action transitive? | **PROVED** (`liftedFrameAction_transitive`) |
| Unique `Lift` element between lifted frames? | **PROVED** (`existsUnique_lift_map_liftedFrame`) |
| Projection to ordinary frames equivariant? | **PROVED** (`liftedFrameProj_equivariant`) |
| Kernel restriction equals existing sign action? | **PROVED** (`liftSmul_restrict_kerSign_eq_signSmul`) |
| Kernel signs act trivially downstairs? | **PROVED** (`kerSign_trivial_downstairs`) |
| Kernel signs act freely upstairs? | **PROVED** (`kerSign_free_upstairs`) |
| `liftedEltEquiv` action-equivariant? | **PROVED** (`liftedEltEquiv_equivariant`) |
| Downstairs reference change unique? | **INHERITED** (`existsUnique_gvis_map_frame`) |
| Exactly two lifted reference changes? | **PROVED** (`liftsOf_reference_change_ncard`) |
| Difference of lifted reference changes exactly one kernel sign? | **PROVED** (`lifts_differ_unique_kerSign`) |
| Lifted transfer equivariant? | **PROVED** (`liftedTransfer_equivariant`) |
| One-fibre interface reference-independent? | **PROVED** (`oneFiberInterface_reference_independent`) |
| Nontrivial varying base introduced? | **NO** |
| Frame bundle constructed? | **NO** |
| Principal bundle constructed? | **NO** |
| Spin structure constructed? | **NO** |
| Physical spin derived? | **NO** |

---

## 7. Convention check for the reference transfer (item 60)

The inherited transfer map acts on the internal representative by **right** multiplication:

```
(liftedTransfer F₀ F₁ u₀ h₀ x).elt = x.elt * u₀⁻¹      (inherited, Task 24)
```

while the new action multiplies on the **left**:

```
(a • x).elt = a * x.elt                                (Task 25)
```

Associativity of the group therefore gives the *unconjugated* identity

```
T_u (a • x) = a • T_u x,
```

which is what `liftedTransfer_equivariant` states. No conjugated or right-action variant is
needed, and no inherited convention had to be changed. This was checked before the formula was
fixed, as required.

Similarly, replacing the chosen lift `u₀` by `ε * u₀` with `ε : KerSign` gives

```
T_{ε u₀} x = ε • T_{u₀} x          (liftedTransfer_sign_shift)
```

using centrality of the kernel signs (`KerSign_central`, inherited) and `kerSign_inv_self`.

---

## 8. The frozen one-fibre interface

`OneFiberLiftInterface` contains exactly:

*intrinsic data*: `Carrier`, `act : LiftGrp → Carrier → Carrier`, `proj : Carrier →
FramePlus`, and the proofs `nonempty`, `act_one`, `act_mul`, `act_free`, `act_transitive`,
`proj_equivariant`, `proj_surjective`, `kerSign_fibre`, `downstairs_free_transitive`;

*temporary presentation data* (**outside** the record): `ReferencePresentation` (a chosen
reference frame) and `LiftChoice F₀ F₁` (a chosen lift of the unique downstairs reference
change).

`oneFiberInterface F₀` instantiates the record from the Task-25 theorems;
`oneFiberInterface_kerSign_eq_signSmul` records, as model-specific information, that the
restriction of `act` to `KerSign` is literally the inherited `signSmul`.

`oneFiberInterface_reference_independent` proves that two temporary reference frames give
`InterfaceEquiv`-equivalent interfaces, and `oneFiberInterfaceEquiv_ambiguity` proves that the
equivalence itself is canonical exactly up to one kernel sign. No quotient over all reference
choices was attempted (item 74): a reference-independence theorem is what is claimed.

---

## 9. Negative controls

| Item | Statement | Status |
| --- | --- | --- |
| 86 | Non-freeness downstairs does not imply non-freeness upstairs | `free_upstairs_not_free_downstairs`, `liftedFrameAction_free_versus_framePlus` — both statements proved side by side, on their own carriers |
| 87 | A carrier bijection does not prove equivariance | `exists_nonequivariant_carrier_equiv`: an explicit bijection `LiftedFrame F₀ ≃ LiftGrp` (`liftedEltEquiv` composed with a transposition) fails the equivariance identity |
| 88 | A two-element fibre is not by itself a torsor theorem | `exists_liftSmul_changes_fibre`: the full internal action does not even preserve the fibres of `liftedFrameProj`; only the kernel restriction does |
| 89 | Unique reference change downstairs ≠ unique upstairs | `reference_change_not_unique_upstairs`, `liftsOf_reference_change_ncard = 2` |
| 90 | The residual `KerSign` ambiguity is not normalized away | No lift is ever chosen permanently: every reference-change statement quantifies over the chosen lift, and `someLiftChoice` is used only inside the existential reference-independence theorem |
| 91 | The one-fibre lifted torsor is not a frame bundle | Scope statement: no base type, no total space, no projection to a base exists in the Task-25 layer (see §10) |
| 92 | Reference independence of one fibre is not local triviality | Scope statement: `oneFiberInterface_reference_independent` compares two presentations of the *same* single fibre; no base, no open cover, no trivialization occurs |
| 93 | No spin structure constructed | Scope statement: no such declaration exists |
| 94 | No physical spin derived | Scope statement: no physical interpretation is attached anywhere |

Items 91–94 are scope statements about what the formal development contains; they are not
Lean theorems, and are not claimed to be.

---

## 10. Package L — exact frontier for Task XXVI

### Already available after Task XXV

| Item | Where |
| --- | --- |
| One fixed three-dimensional metric-oriented carrier | inherited (`E`, `h3`, `triple`) |
| Intrinsic oriented orthonormal frame carrier | inherited (`FramePlus`) |
| Free/transitive visible-group action | inherited (`framePlus_free_transitive`) |
| Free/transitive lifted-group action | **new** (`liftedFrame_free_transitive`) |
| Equivariant two-sheeted projection | **new** (`liftedFrameProj_equivariant`) + inherited two-element fibres |
| Kernel action identified with the sign action | **new** (`liftSmul_restrict_kerSign_eq_signSmul`) |
| Reference-independent one-fibre structure up to classified kernel ambiguity | **new** (`oneFiberInterface_reference_independent`, `oneFiberInterfaceEquiv_ambiguity`) |

### Still absent (not attempted, by instruction)

| Missing item | Status |
| --- | --- |
| Nontrivial base `B` | ABSENT |
| Family `E_b` varying with `b ∈ B` | ABSENT |
| Total frame space over `B` | ABSENT |
| Projection to `B` | ABSENT |
| Topology on total spaces | ABSENT (none inherited on `FramePlus` either) |
| Local trivializations over `B` | ABSENT |
| Transition functions between varying frame fibres | ABSENT |
| Compatibility of lifted transitions | ABSENT (only the *one-fibre* Task-XXIII sign compatibility is inherited) |
| Principal-bundle structure | ABSENT |
| Spin structure | ABSENT |

The first missing node is named neutrally by the record `FiberFamilyInput` (base type, fibre
assignment, fibrewise metric and orientation data). It is **not instantiated**, and no local
triviality, bundle, transition function or topology is defined. The anticipated Task-XXVI root
is therefore `base + varying metric-oriented fibres`.

---

## 11. Build report

* Focused Task-25 builds, in order, all successful:
  `lake build RequestProject.NullSectorTask25.LiftedFrameAction`,
  `... .LiftedFrameEquivariance`, `... .ReferenceTransferHardening`,
  `... .OneFiberInterface`, `... .Task25`.
* Whole-project build: `lake build` → **`Build completed successfully (8289 jobs)`**,
  0 errors, 114 warnings, **none of which is in a Task-25 module** (they are pre-existing
  `simp`-argument and `simpa` style warnings in Task-20/21 modules).
* Source scan of `RequestProject/NullSectorTask25`: no `sorry`, no `admit`, no `axiom`, no
  `native_decide`, no `bv_decide`, no `implemented_by`, no `unsafe`, no `partial`.

### Failed builds preserved (item 107)

| # | Command | Error | Diagnosis | Repair | Mathematical content changed? |
| --- | --- | --- | --- | --- | --- |
| 1 | `lake build RequestProject.NullSectorTask25.LiftedFrameEquivariance` | `rewrite failed … (fun e => y = ↑e • x) e`; `(kernel) deterministic timeout` at `liftedEltEquiv_symm_equivariant`; `unknown constant` in the following theorem | (a) goals left un-beta-reduced by `refine` on an `∃!`, so `rw` could not see the pattern; (b) proving the `symm` equivariance by subtype extensionality forced the kernel to unfold the noncomputable projection | (a) inserted explicit `show` statements; (b) reproved via injectivity of the equivalence (`Equiv.apply_symm_apply`) instead of extensionality | No — same statements, different tactics |
| 2 | `lake build RequestProject.NullSectorTask25.ReferenceTransferHardening` | `Unknown identifier w1`; invalid `▸`; `unsolved goals` on set membership; `unsolved goals` on `signSmul` vs `•` | (a) the ambient-algebra names are not in scope under the Task-25 `open`s; (b) wrong witness term; (c) `Set` insert/singleton membership was not unfolded before `rintro (rfl|rfl)`; (d) `rw` chain in the wrong direction | (a) `kerSign_inv_self` reproved abstractly from the two-element kernel description (no ambient algebra needed); (b) correct witness; (c) `simp only [Set.mem_insert_iff, Set.mem_singleton_iff]`; (d) explicit `.trans` chain | No — same statements; the involution lemma got a shorter, more general proof |
| 3 | `lake build RequestProject.NullSectorTask25.OneFiberInterface` | `failed to synthesize HSMul (↥LiftG) (oneFiberInterface F₁).Carrier` | the interface field `Carrier` is not reducibly `LiftedFrame F₁`, so instance search for `•` failed | stated the ambiguity theorem directly in terms of `liftedTransfer`, and added a `rfl`-lemma identifying the interface equivalence with it | No — the statement is the same up to the definitional unfolding of the interface field |

No failed proof revealed a false expected theorem; no boundary had to be revised (item 108).

---

## 12. Axiom report

`#print axioms` is run in `Task25.lean` on all 34 exposed endpoints. Every one reports exactly

```
[propext, Classical.choice, Quot.sound]
```

which are the standard Lean/Mathlib axioms already present in the environment. No custom axiom
is declared anywhere in the Task-25 layer.

---

## 13. Source ledger

**IMPORTED STANDARD RESULT** (Mathlib `v4.28.0`, commit
`8f9d9cff6bd728b17a24e163c9402775d9e6a365`):

* `Mathlib/Algebra/Group/Basic.lean` — elementary group identities (`mul_assoc`,
  `inv_mul_cancel`, `inv_mul_eq_one`, `inv_eq_one`, `mul_inv_rev`).
* `Mathlib/Algebra/Group/Subgroup/Basic.lean`, `.../MonoidHom.lean` — `Subgroup`,
  `MonoidHom.ker`, `MonoidHom.mem_ker`, `Subgroup.inv_mem`, `Subgroup.eq_bot_iff_forall`.
* `Mathlib/GroupTheory/GroupAction/Defs.lean`, `.../Basic.lean` — `SMul`, `MulAction`,
  `MulAction.stabilizer`, `MulAction.IsPretransitive`.
* `Mathlib/Logic/Equiv/Basic.lean`, `Mathlib/Logic/Equiv/Defs.lean` — `Equiv`, `Equiv.trans`,
  `Equiv.swap`, `Equiv.swap_apply_left`, `Equiv.swap_apply_of_ne_of_ne`,
  `Equiv.apply_symm_apply`.
* `Mathlib/Data/Set/Card.lean` — `Set.ncard`, `Set.ncard_pair`.

**INHERITED FROM EARLIER TASKS OF THIS PROJECT** (used unchanged, listed in §1).

**DERIVED IN TASK XXV**: everything listed in §3 and §4.

For the standard mathematics behind the construction (a group acting simply transitively on
itself by left multiplication; a central `Z₂` kernel of a two-fold covering homomorphism acting
freely on the total object and trivially on the base), see any standard algebra text, e.g.
Bourbaki, *Algebra I*, Ch. I (group actions, torsors).

---

## 14. Unresolved mathematical obligations

1. **Topology.** No topology on `FramePlus` or on `LiftedFrame F₀` is inherited or built;
   consequently no continuity, no local triviality and no topological torsor statement is
   available. Deliberately out of scope (Task-25 stop rule).
2. **Quotient over all reference choices.** Reference independence is proved as an equivalence
   theorem; no global object obtained by quotienting all temporary presentations is
   constructed (item 74 permits this).
3. **Cardinality of `LiftGrp`.** The exact size/structure of the internal group is inherited
   material and is not re-examined here; the Task-25 proofs use only its group structure, the
   surjectivity of `projCore`, and the two-element description of `KerSign`.
4. **Everything in the "still absent" table of §10** remains open by design; Task 25 stops at
   the boundary `base + varying metric-oriented fibres`.
